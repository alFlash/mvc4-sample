Option Strict Off

Imports Personify.ApplicationManager

Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports TIMSS.API

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Collections.Generic
Imports Telerik.Web.UI

Namespace Personify.DNN.Modules.OneClickDonations

    Public MustInherit Class OneClickDonations
      Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

        Protected WithEvents MainPageTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents oCUSMessageControl As WebControls.MessageControl
        Protected WithEvents oORDMessageControl As WebControls.MessageControl
        Protected WithEvents oFARMessageControl As WebControls.MessageControl
        Protected WithEvents Address1 As Personify.WebControls.AddressControl

#End Region

      
        Dim ECheckCodes As List(Of String)
        Dim RecurringGiftOptionSelected As Boolean = False


#Region "Properties"

        Private ReadOnly Property ControlValue(ByVal ControlId As String) As String
            Get
                Dim strReturn As String = ""

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ControlId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

        Private ReadOnly Property EditSetting_AddressTypeCode() As String
            Get
                Return CType(Settings(ModuleSettingsNames.AddressType), String)

            End Get
        End Property


        Private ReadOnly Property EditSetting_TemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.TemplateName), String)

                If strFileName Is Nothing OrElse strFileName.Length = 0 Then
                    strFileName = "OneClickdonations.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property

        Private ReadOnly Property EditSetting_ProductId() As Long
            Get
                Dim strReturn As String = ""
                Dim lngReturn As Long = -1

                If CType(Settings(ModuleSettingsNames.PageMode), String) = "QUERYSTRINGMODE" Then
                    strReturn = Request.QueryString("ProductId")
                Else
                    strReturn = CType(Settings(ModuleSettingsNames.FundProductId), String)
                End If



                If String.IsNullOrEmpty(strReturn) Then
                    Return -1
                Else
                    lngReturn = CType(strReturn, Long)
                End If

                Return lngReturn
            End Get
        End Property

        Private ReadOnly Property EditSetting_MinimumDonationAmount() As Decimal
            Get
                Dim strReturn As String
                Dim lngReturn As Decimal = -1
                strReturn = CType(Settings(ModuleSettingsNames.MinimumDonationAmount), String)

                If Not strReturn Is Nothing AndAlso strReturn.Length = 0 Then
                    Return -1
                Else
                    lngReturn = CType(strReturn, Decimal)
                End If

                Return lngReturn
            End Get
        End Property


        Private ReadOnly Property EditSetting_ProcessOrder_RedirectToOrderSummaryURL() As String
            Get
                Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToLoginURL), String)

            End Get
        End Property


        Private ReadOnly Property EditSetting_AdditionalText() As String
            Get
                Return CType(Settings(ModuleSettingsNames.AdditionalText), String)

            End Get
        End Property


#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                'get the images folder



                RegisterJSScripts("js\OneClickDonations.js", "OneClickDonations")
                RegisterJSScripts("js\Echeck.js", "Echeck")

                ECheckCodes = get_clsOrderCheckOutProcessHelper.GetECheckCodeList()




                If IsPostBack Then
                    'If CheckIfPostbackByButton("btnProcess") Then
                    '    'ProcessDonation()
                    'End If
                    If CheckIfPostbackByButton("rbGiftFrequency") Then
                        If String.Compare(ControlValues("rbGiftFrequency"), "onetime", True) <> 0 Then
                            RecurringGiftOptionSelected = True
                        End If

                    End If

                    If CheckIfPostbackByButton("btnProcess") Then
                        ProcessDonation()
                    End If
                Else
                    'Clear the message controls
                    ClearValidationIssues("ALL")
                End If

                LoadOneClickDonationTemplate()


                'if the customer is logged in default all Name and Address Fields

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub ClearValidationIssues(ByVal Mode As String)

            If Mode = "CUS" Or Mode = "ALL" Then
                If oCUSMessageControl IsNot Nothing Then
                    oCUSMessageControl.Clear()
                End If
            End If

            If Mode = "ORD" Or Mode = "ALL" Then
                If oORDMessageControl IsNot Nothing Then
                    oORDMessageControl.Clear()
                End If
            End If

            If Mode = "FAR" Or Mode = "ALL" Then
                If oFARMessageControl IsNot Nothing Then
                    oFARMessageControl.Clear()
                End If
            End If


        End Sub


        Private Sub DefaultNameAddressFieldsForLoggedInCustomer()


        End Sub
        Public Class GiftFrequency
            Public GiftFrequencyCode As String
            Public GiftFrequencyDescription As String

        End Class
        Private Function GetGiftFrequency() As GiftFrequency()

            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes

            oAppCodes = Me.GetApplicationCodes("FND", "GIFT_FREQUENCY", True)

            Dim oRetClass(oAppCodes.Count - 1) As GiftFrequency

            For i As Integer = 0 To oAppCodes.Count - 1
                oRetClass(i) = New GiftFrequency
                oRetClass(i).GiftFrequencyCode = oAppCodes(i).Code
                oRetClass(i).GiftFrequencyDescription = oAppCodes(i).Description
            Next



            Return oRetClass

        End Function

        Private Sub LoadOneClickDonationTemplate()

            Dim oProduct As TIMSS.API.WebInfo.ITmarWebProductViewList
            Dim oPRices As WebPrices

            Dim oDonorInfo As OneClickDonorInfo = Nothing

            MainPageTemplate.Visible = True
            MainPageTemplate.XSLfile = Server.MapPath(EditSetting_TemplateFile)

            If EditSetting_ProductId = -1 Then

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", "Cannot Accept Donations at this time", ResolveUrl("~/" & SiteImagesFolder & "/administrator_lock_48.gif"))
                Exit Sub

            End If

            oProduct = get_clsProductHelper.GetWebProductInfo(EditSetting_ProductId)

            If oProduct Is Nothing OrElse oProduct.Count = 0 Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", "Cannot Accept Donations at this time", ResolveUrl("~/" & SiteImagesFolder & "/administrator_lock_48.gif"))
                Exit Sub
            End If

            oPRices = get_clsProductHelper.GetProductListDefaultPrices(EditSetting_ProductId, PricingOptions.MultiplePricing)

            MainPageTemplate.AddObject("ModuleId", ModuleId)
            MainPageTemplate.AddObject("CurrencySymbol", Me.PortalCurrency.Symbol)
            MainPageTemplate.AddObject("", oProduct)

            MainPageTemplate.AddObject("", oPRices)

            'Months of the year
            MainPageTemplate.AddObject("", LoadMonths)

            'Years -- Current Year + 5
            MainPageTemplate.AddObject("", LoadYears)

            'Additional Text
            MainPageTemplate.AddObject("AdditionalText", EditSetting_AdditionalText)

            MainPageTemplate.AddObject("MinimumDonationAmount", EditSetting_MinimumDonationAmount)

            'Add object for gift frequency
            MainPageTemplate.AddObject("", GetGiftFrequency)


            If Me.IsPersonifyWebUserLoggedIn Then
                oDonorInfo = GetCustomerInformation(MasterCustomerId, SubCustomerId)
                MainPageTemplate.AddObject("", oDonorInfo)
                MainPageTemplate.AddObject("DonorFullName", String.Concat(oDonorInfo.FirstName, " ", oDonorInfo.LastName))
            End If
            Dim oVs() As ValidReceiptCodes
            Dim strError As String = ""
            oVs = get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError)


            'oVs = GetValidReceiptCodes(get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError))
            If strError.Length > 0 Then

                Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile)

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile) + "</br>" + strError, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)



            Else
                oVs = GetValidReceiptCodes(oVs)

                MainPageTemplate.AddObject("", oVs)

                Dim CheckTypeList As CheckType() = get_clsOrderCheckOutProcessHelper.GetCheckType()

                If CheckTypeList.Length > 0 Then
                    MainPageTemplate.AddObject("CheckTypeList", CheckTypeList)
                End If
                Dim oAppStates As TIMSS.API.ApplicationInfo.IApplicationStates
                oAppStates = get_clsOrderCheckOutProcessHelper.GetApplicationStates("USA")

                If Not oAppStates.Count = 0 Then
                    MainPageTemplate.AddObject("", oAppStates)
                End If

                MainPageTemplate.Display()


                Dim ddl As DropDownList = CType(FindControl(String.Concat("IDType_", ModuleId)), DropDownList)
                Dim lblPersID As Label = FindControl("lblDriversLicenseNumber")
                Dim lblAddtlInfo As Label = FindControl("lblDriversLicenseState")
                If ddl IsNot Nothing AndAlso lblPersID IsNot Nothing AndAlso lblAddtlInfo IsNot Nothing Then
                    ddl.Attributes.Add("onChange", String.Format("SetChangeLabel(this,'{0}','{1}')", lblPersID.ClientID, lblAddtlInfo.ClientID))
                End If

                If CheckIfECheck() AndAlso RecurringGiftOptionSelected = False Then
                    CType(FindControl("CreditCardPanel"), Panel).Visible = False
                    CType(FindControl("ECheckPanel"), Panel).Visible = True
                Else
                    CType(FindControl("CreditCardPanel"), Panel).Visible = True
                    CType(FindControl("ECheckPanel"), Panel).Visible = False
                End If

                Dim txtRequiredAuthorizationVerbiage As Label
                txtRequiredAuthorizationVerbiage = CType(FindControl("txtRequiredAuthorizationVerbiage"), Label)

                If txtRequiredAuthorizationVerbiage IsNot Nothing Then
                    txtRequiredAuthorizationVerbiage.Text = Localization.GetString("txtRequiredAuthorizationVerbiage", Me.LocalResourceFile)
                End If

                Dim imgTeleCheckLogo As Image
                imgTeleCheckLogo = CType(FindControl("imgTeleCheckLogo"), Image)

                If imgTeleCheckLogo IsNot Nothing Then
                    imgTeleCheckLogo.ImageUrl = String.Concat("~/", SiteImagesFolder, "/official_logo.gif")
                End If
            End If

            'Dim btnDonate As Button = CType(FindControl("btnProcess"), Button)
            'If btnDonate IsNot Nothing Then
            '    AddHandler btnDonate.Command, AddressOf MakeDonations
            'End If



            LoadAddressControl(oDonorInfo)

            LoadToolTips("RoutingNo")
            LoadToolTips("AccountNo")
        End Sub

        Private Function GetValidReceiptCodes(ByVal RxCodes As ValidReceiptCodes()) As ValidReceiptCodes()

            Dim retRxCodes() As ValidReceiptCodes
            Dim index As Integer = -1

            If RecurringGiftOptionSelected = True Then
                For Each Rx As ValidReceiptCodes In RxCodes
                    If String.Compare(Rx.ReceiptType, "echk", True) <> 0 Then
                        index = index + 1
                        ReDim Preserve retRxCodes(index)
                        retRxCodes(index) = New ValidReceiptCodes
                        retRxCodes(index).ReceiptCode = Rx.ReceiptCode
                        retRxCodes(index).ReceiptDescription = Rx.ReceiptDescription
                        retRxCodes(index).ReceiptType = Rx.ReceiptType

                    End If
                Next
            Else
                retRxCodes = RxCodes
            End If
            



            Return retRxCodes

        End Function

        Private Sub LoadToolTips(ByVal Name As String)
            Dim tempPlaceHolder As New PlaceHolder
            Dim tempTextboxPlaceHolder As New PlaceHolder
            Dim tempToolTip As New RadToolTip
            Dim tempTextbox As New TextBox

            tempTextbox.ID = String.Concat(Name, "_", ModuleId.ToString)
            tempTextbox.Width = "200"
            With tempToolTip
                .ID = String.Concat(Name, "ToolTip_", ModuleId.ToString)
                .Height = "200"
                .Width = "380"
                .TargetControlID = tempTextbox.ID
                .IsClientID = False
                .OffsetY = "4"
                .Sticky = True
                .Animation = ToolTipAnimation.Fade
                .Position = ToolTipPosition.MiddleRight
                .RelativeTo = ToolTipRelativeDisplay.Element
                .Skin = Localization.GetString("ECKToolTipSkin", Me.LocalResourceFile)
                .ShowEvent = ToolTipShowEvent.OnFocus
                .ManualClose = False
                .HideDelay = 500
                Dim tempImage As New Image
                tempImage.ID = String.Concat(Name, "Image_", ModuleId.ToString)
                tempImage.ImageUrl = ResolveUrl(String.Concat("~/", SiteImagesFolder, "/", Localization.GetString(String.Concat(Name, "Image"), Me.LocalResourceFile)))
                .Controls.Add(tempImage)
            End With

            For i As Integer = 0 To Me.Controls.Count - 1
                For j As Integer = 0 To Me.Controls(i).Controls.Count - 1
                    For k As Integer = 0 To Me.Controls(i).Controls(j).Controls.Count - 1
                        tempTextboxPlaceHolder = Me.Controls(i).Controls(j).Controls(k).FindControl(String.Concat(Name, "TextboxPlaceHolder_", ModuleId.ToString))
                        tempPlaceHolder = Me.Controls(i).Controls(j).Controls(k).FindControl(String.Concat(Name, "PlaceHolder_", ModuleId.ToString))
                        If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                            Exit For
                        End If
                    Next
                    If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                        Exit For
                    End If
                Next
                If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                    Exit For
                End If
            Next

            If tempTextboxPlaceHolder IsNot Nothing Then
                tempTextboxPlaceHolder.Controls.Add(tempTextbox)
            End If

            If (tempPlaceHolder IsNot Nothing) Then
                tempPlaceHolder.Controls.Add(tempToolTip)
            End If
        End Sub

        Private Sub MakeDonations(ByVal sender As Object, ByVal e As CommandEventArgs)

            ProcessDonation()
        End Sub
        Public Class Months
            Public MonthName As String
            Public MonthNumber As String
        End Class

        Public Class Years
            Public Year As String
        End Class

        Private Function LoadMonths() As Months()

            Dim oMonths(12) As Months

            For i As Integer = 0 To 12
                oMonths(i) = New Months
            Next
            oMonths(0).MonthName = " "
            oMonths(0).MonthNumber = " "
            oMonths(1).MonthName = "January"
            oMonths(1).MonthNumber = "1"
            oMonths(2).MonthName = "February"
            oMonths(2).MonthNumber = "2"
            oMonths(3).MonthName = "March"
            oMonths(3).MonthNumber = "3"

            oMonths(4).MonthName = "April"
            oMonths(4).MonthNumber = "4"
            oMonths(5).MonthName = "May"
            oMonths(5).MonthNumber = "5"

            oMonths(6).MonthName = "June"
            oMonths(6).MonthNumber = "6"

            oMonths(7).MonthName = "July"
            oMonths(7).MonthNumber = "7"

            oMonths(8).MonthName = "August"
            oMonths(8).MonthNumber = "8"

            oMonths(9).MonthName = "September"
            oMonths(9).MonthNumber = "9"

            oMonths(10).MonthName = "October"
            oMonths(10).MonthNumber = "10"

            oMonths(11).MonthName = "November"
            oMonths(11).MonthNumber = "11"

            oMonths(12).MonthName = "December"
            oMonths(12).MonthNumber = "12"



            Return oMonths

        End Function

        Private Function LoadYears() As Years()

            '3246-6880268
            Dim oYears(10) As Years

            Dim i As Integer = 1
            Dim StartDate As Date = Date.Now.AddYears(-1)
            oYears(0) = New Years
            oYears(0).Year = " "
            '3246-6880268
            For i = 1 To 10
                oYears(i) = New Years
                oYears(i).Year = StartDate.AddYears(i).Year
            Next

            Return oYears

        End Function

        Private Sub LoadAddressControl(ByVal pDonorInfo As OneClickDonorInfo)

            'Address1.IsCompanyAddress = False



            Dim tempPlaceHolder As New PlaceHolder

            tempPlaceHolder = CType(Me.FindControl("AddressPlaceHolder" + "_" + Convert.ToString(ModuleId)), PlaceHolder)


            If (tempPlaceHolder IsNot Nothing) Then
                Address1 = New Personify.WebControls.AddressControl
                Address1.ID = "PersonifyAddress"
                tempPlaceHolder.Controls.Add(Address1)
            End If
            'Default the address if the customer is logged in

            Address1 = CType(FindControl("PersonifyAddress"), Personify.WebControls.AddressControl)
            Address1.RecordType = "I"
            Address1.Mode = "ADD"

            Address1.AddressStructureCountryCode = GetDefaultCountryCodeForOrganization()
            Address1.HideCompanyName = True
            Address1.HideLabelName = True
            Address1.HideMailStop = True
            Address1.HideJobTitle = True
            Address1.HideAttnLine = True
            Address1.HideAddressDetailFlags = True
            Address1.HideAddressTypes = True

            If Me.IsPersonifyWebUserLoggedIn Then
                Address1.AddressType = pDonorInfo.AddrTypeCode
                Address1.AddressStructureCountryCode = pDonorInfo.CountryCode
                Address1.Address1 = pDonorInfo.AddrLine1
                Address1.Address2 = pDonorInfo.AddrLine2
                Address1.Address3 = pDonorInfo.AddrLine3
                Address1.Address4 = pDonorInfo.AddrLine4
                Address1.City = pDonorInfo.City
                Address1.State = pDonorInfo.State
                Address1.PostalCode = pDonorInfo.ZipCode
                Address1.CountryCode = pDonorInfo.CountryCode

            End If
            Address1.SetAddressVisible()


        End Sub
#End Region

#Region "Optional Interfaces"

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Code is to be moved to the Application Manager"
        Public Class OneClickDonorInfo

            Public MCID As String
            Public SCID As Integer
            Public FirstName As String
            Public LastName As String
            Public EMail As String
            Public AddrTypeCode As String

            Public AddrLine1 As String
            Public AddrLine2 As String
            Public AddrLine3 As String
            Public AddrLine4 As String
            Public City As String
            Public State As String
            Public CountryCode As String
            Public ZipCode As String


        End Class
        Private Function GetCustomerInformation(ByVal MCID As String, ByVal SCID As Integer) As OneClickDonorInfo

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            Dim oDonorInfo As New OneClickDonorInfo
            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            oCustomers.Fill(MCID, SCID)

            With oDonorInfo

                .MCID = MCID
                .SCID = SCID
                .FirstName = oCustomers(0).FirstName
                .LastName = oCustomers(0).LastName
                .EMail = oCustomers(0).PrimaryEmailAddress

                .AddrLine1 = oCustomers(0).PrimaryAddress.Address.Address1
                .AddrLine2 = oCustomers(0).PrimaryAddress.Address.Address2
                .AddrLine3 = oCustomers(0).PrimaryAddress.Address.Address3
                .AddrLine4 = oCustomers(0).PrimaryAddress.Address.Address4
                .City = oCustomers(0).PrimaryAddress.Address.City
                .State = oCustomers(0).PrimaryAddress.Address.State
                .ZipCode = oCustomers(0).PrimaryAddress.Address.PostalCode
                .CountryCode = oCustomers(0).PrimaryAddress.Address.CountryCode.Code
                .AddrTypeCode = oCustomers(0).PrimaryAddress.Address.Details(0).AddressTypeCode.Code
            End With

            Return oDonorInfo


        End Function

#End Region

        Private Function CheckIfECheck() As Boolean
            Dim oVs() As ValidReceiptCodes
            Dim strError As String = ""
            oVs = get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError)

            If strError.Length > 0 Then
                Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile)
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile) + "</br>" + strError, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                For Each echeckcode As String In ECheckCodes
                    If ControlValue(String.Concat("PaymentTypeSelect_", ModuleId.ToString)) = echeckcode Then
                        Return True
                    End If
                Next
                Return False
            End If

            Return False
        End Function

        Private Sub ProcessDonation()
            Dim ocps As OneClickDonationParameters
            Dim oReturn As New ReturnStatusOneClickDonations

            ocps = ConstructDonationObject()

            oReturn = get_clsOrderCheckOutProcessHelper.OneClickDonation(ocps, oCUSMessageControl.ValidationIssues, oORDMessageControl.ValidationIssues, oFARMessageControl.ValidationIssues)

            ocps = Nothing
            If oReturn.DonationSuccessFull = True Then
                Response.Redirect(EditSetting_ProcessOrder_RedirectToOrderSummaryURL & "&ORDERNUMBER=" + oReturn.oOrderMasters(0).OrderNumber + "&Mode=" + TIMSS.Common.Encryption.Encrypt("Anonymous"))

            Else

                If ShowValidationIssues("CUS", oReturn.oCustomers) Then
                    oCUSMessageControl.Show(oReturn.oCustomers.ValidationIssues)
                End If

                If ShowValidationIssues("ORD", , oReturn.oOrderMasters) Then
                    oORDMessageControl.Show(oReturn.oOrderMasters.ValidationIssues)
                End If

                If ShowValidationIssues("FAR", , , oReturn.oFARIssues) Then
                    oFARMessageControl.Show(oReturn.oFARIssues)
                End If
            End If


        End Sub



        Private Function ShowValidationIssues(ByVal Mode As String, Optional ByVal Customers As TIMSS.API.CustomerInfo.ICustomers = Nothing, Optional ByVal Orders As TIMSS.API.OrderInfo.IOrderMasters = Nothing, Optional ByVal FarIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As Boolean

            Dim bReturn As Boolean = False

            If Mode = "CUS" Then
                If Customers IsNot Nothing AndAlso Customers.ValidationIssues IsNot Nothing AndAlso Customers.ValidationIssues.Count > 0 Then
                    bReturn = True
                End If
            End If

            If Mode = "ORD" Then
                If Orders IsNot Nothing AndAlso Orders.ValidationIssues IsNot Nothing AndAlso Orders.ValidationIssues.Count > 0 Then
                    bReturn = True
                End If
            End If

            If Mode = "FAR" Then
                If FarIssues IsNot Nothing AndAlso FarIssues.Count > 0 Then
                    bReturn = True
                End If
            End If


            Return bReturn

        End Function

        Private ReadOnly Property ControlValues(ByVal ControlId As String) As String
            Get
                Dim ocontrolId As String = ""
                Dim strReturn As String = ""
                ocontrolId = ControlId + "_" + ModuleId.ToString

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ocontrolId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

        Private ReadOnly Property AddressValues(ByVal AddressControlId As String) As String
            Get
                Dim ocontrolId As String = ""
                Dim strReturn As String = ""
                ocontrolId = AddressControlId

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ocontrolId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

        Private Function ConstructDonationObject() As OneClickDonationParameters

            Dim oDP As New OneClickDonationParameters
            Dim strTempValue As String = ""

            With oDP
                If Me.IsPersonifyWebUserLoggedIn Then
                    .MCID = MasterCustomerId
                    .SCID = SubCustomerId
                Else
                    .MCID = ""
                End If
                .PID = EditSetting_ProductId
                .FirstName = ControlValues("txtFirstName")
                .LastName = ControlValues("txtLastName")
                If Not ControlValues("NameOnCard") = "" Then
                    .NameOnCard = ControlValues("NameOnCard")
                End If
                .EMail = ControlValues("txtEmail")

                .CCType = ControlValues("PaymentTypeSelect")
                .CCNo = ControlValues("CreditCardNo")
                .CVV2 = ControlValues("Cvv2")

                strTempValue = ControlValues("MOnths")
                If strTempValue.Length > 0 Then
                    .ExpMonth = Convert.ToInt16(strTempValue)
                End If

                strTempValue = ""

                strTempValue = ControlValues("Years")
                If strTempValue.Length > 0 Then
                    .ExpYear = Convert.ToInt16(strTempValue)
                End If

                'Set Echeck information
                .RoutingNumber = ControlValues("RoutingNo")
                .AccountNumber = ControlValues("AccountNo")
                .CheckType = ControlValues("CheckType")
                .CheckNumber = ControlValues("CheckNo")
                .IDType = ControlValues("IDType")
                If ControlValues("IDType") = "DL" Then
                    .DriversLicense = ControlValues("DriversLicenseNo")
                    .DriversLicenseState = ControlValues("DriversLicenseState")
                Else
                    .FederalTaxId = ControlValues("DriversLicenseNo")
                    .DateOfBirth = ControlValues("DriversLicenseState")
                End If

                'Set Rate Information

                Dim rbSelected As String = ""
                rbSelected = ControlValues("PriceSelect")

                If rbSelected.Length > 0 Then
                    If rbSelected.ToUpper <> "OTHER" Then

                        .RateStructure = Split(rbSelected, "_")(0)
                        .RateCode = Split(rbSelected, "_")(1)
                    Else
                        .AmountToDonate = GetAmountToDonate()

                    End If

                End If
                'One click donation, check for recurring values


                If ControlValues("rbGiftFrequency").Length > 0 AndAlso String.Compare(ControlValues("rbGiftFrequency"), "onetime", True) <> 0 Then
                    .IsRecurringDonation = True
                    .RecurringDonationFrequency = ControlValues("rbGiftFrequency")
                Else
                    .IsRecurringDonation = False
                End If


                'Dim Address1 As New Personify.WebControls.AddressControl
                'Dim oAddressPlaceHolder As PlaceHolder

                'oAddressPlaceHolder = Me.FindControl("AddressPlaceHolder" + "_" + Convert.ToString(ModuleId))
                .AddressTypeCode = EditSetting_AddressTypeCode

                .AddrCountryCode = AddressValues("ddlCountry")
                .AddrLine1 = AddressValues("txtAddress1")
                .AddrLine2 = AddressValues("txtAddress2")
                .AddrLine3 = AddressValues("txtAddress3")
                .AddrLine4 = AddressValues("txtAddress4")

                .City = AddressValues("txtCity")
                .State = AddressValues("ddlState")
                .ZipCode = AddressValues("txtPostalCode")
            End With

            Return oDP
        End Function

        Private Function GetAmountToDonate() As Decimal
            Dim amt As Decimal
            Dim rbValue As String

            rbValue = ControlValues("PriceSelect")
            If rbValue.Length > 0 Then
                If rbValue.ToUpper = "OTHER" Then
                    rbValue = ControlValues("txtAmount")
                Else
                    rbValue = Split(rbValue, "_")(0)
                End If
                amt = Convert.ToDecimal(rbValue)
           
            End If


            Return amt
        End Function



        Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
            Dim ScriptPath As String = ResolveUrl(path)
            If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
                Dim script As System.Text.StringBuilder = New System.Text.StringBuilder
                script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
                script = Nothing
            End If
        End Sub



        Private Function CheckIfPostbackByButton(ByVal ButtonName As String) As Boolean

          
            Dim bReturn As Boolean = False

            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(ButtonName) > 0 Then
                    bReturn = True
                    Exit For
                End If

            Next

            Return bReturn

        End Function



#Region "Personify Data"

        'Private Function GetWebProductInfo(ByVal ProductId As Integer) As WebInfo.ITmarWebProductViewList

        '    Dim oWebProducts As WebInfo.ITmarWebProductViewList
        '    Dim strIN As New System.Text.StringBuilder

        '    Dim strCacheKey As String



        '    strCacheKey = ProductId.ToString & "GetWebProductInfo"

        '    oWebProducts = CType(PersonifyDataCache.Fetch(strCacheKey), WebInfo.ITmarWebProductViewList)

        '    If oWebProducts Is Nothing Then

        '        oWebProducts = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebProductViewList")
        '        oWebProducts.Filter.Add("ProductId", ProductId.ToString)
        '        oWebProducts.Fill()
        '        PersonifyDataCache.Store(strCacheKey, oWebProducts)
        '    End If

        '    Return oWebProducts

        'End Function



#End Region
    End Class





End Namespace
