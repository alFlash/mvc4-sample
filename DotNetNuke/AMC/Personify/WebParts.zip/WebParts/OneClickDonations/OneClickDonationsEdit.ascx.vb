Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Imports TIMSS.API



Namespace Personify.DNN.Modules.OneClickDonations

    Public MustInherit Class OneClickDonationsEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents cboSelectTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents rbPageMode As RadioButtonList
        Protected WithEvents txtPID As TextBox

        Protected WithEvents txtAddText As DotNetNuke.UI.UserControls.TextEditor
        Protected WithEvents txtMinDonationAmount As TextBox

        Protected WithEvents chkAcceptAddress As CheckBox

        Protected WithEvents drpAddressType As System.Web.UI.WebControls.DropDownList

        Protected WithEvents ctlSummaryURL As DotNetNuke.UI.UserControls.UrlControl

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                RegisterJSScripts("OneClickDonation.js", "OneClickDonations")
                If Not Page.IsPostBack Then
                    LoadSettings()
                End If

             
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
            Dim ScriptPath As String = ResolveUrl(path)
            If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
                Dim script As System.Text.StringBuilder = New System.Text.StringBuilder
                script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
                script = Nothing
            End If
        End Sub
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting(ModuleSettingsNames.TemplateName, cboSelectTemplate.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.PageMode, rbPageMode.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.FundProductId, txtPID.Text)
                    'Additional Text - Entry Mode
                    UpdateModuleSetting(ModuleSettingsNames.Mode_AdditionalText, txtAddText.Mode)
                    If txtAddText.Mode = "BASIC" Then
                        UpdateModuleSetting(ModuleSettingsNames.AdditionalText, txtAddText.Text)

                    ElseIf txtAddText.Mode = "RICH" Then
                        UpdateModuleSetting(ModuleSettingsNames.AdditionalText, txtAddText.RichText.Text)
                    End If

                    UpdateModuleSetting(ModuleSettingsNames.MinimumDonationAmount, txtMinDonationAmount.Text)


                    UpdateModuleSetting(ModuleSettingsNames.AddressType, drpAddressType.SelectedValue)


                    'Update Prodcess Order URLS
                    UpdateModuleSetting(ModuleSettingsNames.ProcessOrder_RedirectToLoginURL, ctlSummaryURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.ProcessOrder_RedirectToLoginURLType, "T")

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
            
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


        Private Sub LoadSettings()

            'Load template
            'Load Templates
            If Not cboSelectTemplate.Items.Count > 0 Then
                Dim li As ListItem
                For Each li In GetTemplates()
                    cboSelectTemplate.Items.Add(li)
                Next
                cboSelectTemplate.SelectedIndex = cboSelectTemplate.Items.IndexOf(cboSelectTemplate.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.TemplateName))))
            End If

            If drpAddressType.Items.Count = 0 Then
                LoadAddressTypeCodes()
                drpAddressType.SelectedIndex = drpAddressType.Items.IndexOf(drpAddressType.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.AddressType))))
            End If

            If Not Settings(ModuleSettingsNames.PageMode) Is Nothing Then
                rbPageMode.SelectedValue = Settings(ModuleSettingsNames.PageMode).ToString
            Else
                rbPageMode.SelectedValue = "PIDMODE"
            End If

            If Not Settings(ModuleSettingsNames.FundProductId) Is Nothing Then
                txtPID.Text = Settings(ModuleSettingsNames.FundProductId)
            End If

            If Not Settings(ModuleSettingsNames.AdditionalText) Is Nothing Then

                txtAddText.Mode = Settings(ModuleSettingsNames.Mode_AdditionalText)
                txtAddText.Text = Settings(ModuleSettingsNames.AdditionalText)

            End If

            If Not Settings(ModuleSettingsNames.MinimumDonationAmount) Is Nothing Then
                txtMinDonationAmount.Text = Settings(ModuleSettingsNames.MinimumDonationAmount)
            End If

            'Redirect to Order Summary URL
            ctlSummaryURL.UrlType = CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToLoginURLType), String)
            ctlSummaryURL.Url = CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToLoginURL), String)

        End Sub

        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem

                ' Create a reference to the current directory.
                Dim dInfo As New System.IO.DirectoryInfo(Me.MapPathSecure((ModulePath & ModuleSettingsNames.C_TEMPLATEFOLDERNAME)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As System.IO.FileInfo() = dInfo.GetFiles(ModuleSettingsNames.C_FILEPATTERN)
                Dim fiTemp As System.IO.FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Private Sub LoadAddressTypeCodes()

            Dim oAddrTypeS As TIMSS.API.ApplicationInfo.IApplicationCodes

            oAddrTypeS = GetApplicationCodes("CUS", "ADDRESS_TYPE", True)

            drpAddressType.DataTextField = "Description"

            drpAddressType.DataValueField = "Code"
            drpAddressType.DataSource = oAddrTypeS
            drpAddressType.DataBind()




        End Sub



    End Class

End Namespace
