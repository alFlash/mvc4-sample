function SetChangeLabel(DDL, IDNumber, IDInfo)
{    
    if (DDL.value != 'SSN')
    {
        document.getElementById(IDNumber).innerHTML = "Driver\'s License";
        document.getElementById(IDInfo).innerHTML = "License State Abbriviation";        
    }
    else{
        document.getElementById(IDNumber).innerHTML = "Social Security Number";
        document.getElementById(IDInfo).innerHTML = "Date Of Birth (MM/DD/YYYY)";     
              
    }
}


