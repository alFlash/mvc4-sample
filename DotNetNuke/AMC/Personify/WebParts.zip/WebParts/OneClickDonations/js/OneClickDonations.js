function DisableECheckOption() {
alert(getElementByPartialName('PaymentType').id);
}


function getElementByPartialName(id) {
	if (document.forms[0].elements != null)
		for (i=0; i<document.forms[0].elements.length-1;i++ )
			if (document.forms[0].elements[i].name.indexOf(id)>0) {
		
				return document.forms[0].elements[i];
			}
}

function getElementByPartialId234(id) {
alert(document.forms[0].elements.length);

	if (document.forms[0].elements != null)
		for (i=0; i<document.forms[0].elements.length-1;i++ )
		{
		alert(document.forms(0).elements[i].id);
		//alert(document.forms(0).elements[i].id);
		 //if(document.forms(0).elements[i].id) 
		    {
		 	//if (document.forms[0].elements[i].id.indexOf(id)>0) 
		 	    {		
			//	return document.forms[0].elements[i];
			    }
			 }
		}
}
function getElementByPartialId(id) {
	if (document.forms[0].elements != null)
		for (i=0; i<document.forms[0].elements.length-1;i++ ) {
		//alert(document.forms[0].elements[i].name);
			if (document.forms[0].elements[i].name.indexOf(id)>0) {
		    
				return document.forms[0].elements[i];
			}
			}
}

function SetNameOnCard(FirstName,LastName, NameOnCard)
{
getElementByPartialName(NameOnCard).value = getElementByPartialName(FirstName).value + " " + getElementByPartialName(LastName).value;
}

function SetOtherAmountOption()
{
//alert('1');
var radioButtons = getElementByPartialName('PriceSelect');
//alert(radioButtons.name);
//radioButtons.value='Other';
for(i=0;i<10;i++)
eval('document.forms[0].'+radioButtons.name+'['+i+'].checked=true');
//document.getElementByPartialId('PRice_Other').checked = true ;

}
