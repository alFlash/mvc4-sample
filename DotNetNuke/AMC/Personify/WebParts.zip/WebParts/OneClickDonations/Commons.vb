
Namespace Personify.DNN.Modules.OneClickDonations

    Public Class ModuleSettingsNames

        Public Const TemplateName As String = "TemplateName"
        Public Const PageMode As String = "PageMode"
        Public Const FundProductId As String = "FundProductId"

        Public Const AdditionalText As String = "AdditionalText"
        Public Const Mode_AdditionalText As String = "Mode_AdditionalText"

        Public Const MinimumDonationAmount As String = "MinimumDonationAmount"
        Public Const AddressType As String = "AddressType"

        Public Const AcceptAddressTypeFromDonor As String = "AcceptAddressTypeFromDonor"
        


        Public Const ProcessOrder_RedirectToLoginURL As String = "ProcessOrder_RedirectToSummaryPageURL"
        Public Const ProcessOrder_RedirectToLoginURLType As String = "ProcessOrder_RedirectToSummaryPageURLType"
       
        Public Const C_TEMPLATEFOLDERNAME As String = "Templates"
        Public Const C_FILEPATTERN As String = "*.?s*" '*.xsl

    End Class

End Namespace
