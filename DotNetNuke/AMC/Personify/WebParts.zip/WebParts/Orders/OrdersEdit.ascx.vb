Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.Orders
Imports System.IO

Namespace Personify.DNN.Modules.Orders

    Public MustInherit Class OrdersEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        'Protected WithEvents chkAllowCancellations As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowPrint As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowBadge As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowStatus As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowCheckBox As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowDCDLink As System.Web.UI.WebControls.CheckBox

        Protected WithEvents chkAllowPayments As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmbPageSize As System.Web.UI.WebControls.DropDownList
        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList
        Protected WithEvents select_Template1 As System.Web.UI.WebControls.DropDownList
        Protected WithEvents rdGetOrders As System.Web.UI.WebControls.RadioButtonList
        Protected printURL As DotNetNuke.UI.UserControls.UrlControl
        Protected badgeURL As DotNetNuke.UI.UserControls.UrlControl
        Protected summaryURL As DotNetNuke.UI.UserControls.UrlControl
        'Protected cancelURL As DotNetNuke.UI.UserControls.UrlControl
        Protected payURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents printTag As System.Web.UI.WebControls.Label
        Protected WithEvents cancelTAg As System.Web.UI.WebControls.Label
        Protected WithEvents payTag As System.Web.UI.WebControls.Label
        ' Protected WithEvents allowCancellations As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents allowPayments As System.Web.UI.HtmlControls.HtmlGenericControl
        ' Protected WithEvents pageSize As System.Web.UI.HtmlControls.HtmlGenericControl
        ' Protected WithEvents customerIs As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents cancelTab As System.Web.UI.HtmlControls.HtmlGenericControl
        ' Protected WithEvents payTab As System.Web.UI.HtmlControls.HtmlGenericControl
        ' Protected WithEvents printTab As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents update As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents cancel As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents selectTemplate As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents selectTemplate1 As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents txtProductId As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtTruncateDescription As System.Web.UI.WebControls.TextBox

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            rdGetOrders.Items.FindByValue("0").Text = Localization.GetString("shipTo", LocalResourceFile)
            rdGetOrders.Items.FindByValue("1").Text = Localization.GetString("billTo", LocalResourceFile)
            rdGetOrders.Items.FindByValue("2").Text = Localization.GetString("both", LocalResourceFile)

            'allowCancellations.InnerHtml = Localization.GetString("allowCancellations", LocalResourceFile)
            'allowPayments.InnerHtml = Localization.GetString("allowPayments", LocalResourceFile)
            ' pageSize.InnerHtml = Localization.GetString("pageSize", LocalResourceFile)
            ' customerIs.InnerHtml = Localization.GetString("customerIs", LocalResourceFile)
            'cancelTab.InnerHtml = Localization.GetString("cancelTab", LocalResourceFile)
            ' payTab.InnerHtml = Localization.GetString("payTab", LocalResourceFile)
            'printTab.InnerHtml = Localization.GetString("printTab", LocalResourceFile)
            update.InnerHtml = Localization.GetString("update", LocalResourceFile)
            cancel.InnerHtml = Localization.GetString("cancel", LocalResourceFile)
            'selectTemplate.InnerHtml = Localization.GetString("selectTemplate", LocalResourceFile)
            'selectTemplate1.InnerHtml = Localization.GetString("selectTemplate1", LocalResourceFile)
            Try
                Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
                If Not Page.IsPostBack Then

                    If Not select_Template.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            If li.Text = "MyOrdersTemplate.xsl" Then
                                li.Selected = True
                            End If
                            select_Template.Items.Add(li)
                        Next
                        select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                    End If
                    If Not select_Template1.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            If li.Text = "MyOrdersDetails.xsl" Then
                                li.Selected = True
                            End If
                            select_Template1.Items.Add(li)
                        Next
                        select_Template1.SelectedIndex = select_Template1.Items.IndexOf(select_Template1.Items.FindByValue(Convert.ToString(Settings("Layout1"))))
                    End If

                    payURL.Url = CType(Settings("payURL"), String)
                    payURL.UrlType = CType(Settings("payURLType"), String)
                    '                    cancelURL.Url = CType(Settings("cancelURL"), String)
                    '                   cancelURL.UrlType = CType(Settings("cancelURLType"), String)
                    printURL.Url = CType(Settings("printURL"), String)
                    badgeURL.Url = CType(Settings("badgeURL"), String)
                    summaryURL.Url = CType(Settings("summaryURL"), String)
                    printURL.UrlType = CType(Settings("printURLType"), String)
                    badgeURL.UrlType = CType(Settings("badgeURLType"), String)
                    summaryURL.UrlType = CType(Settings("summaryURLType"), String)

                    LoadSettings()
                    If Not Null.IsNull(itemId) Then
                    Else ' security violation attempt to access item not related to this Module
                        Response.Redirect(NavigateURL(), True)
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub LoadSettings()
            Try
                '                chkAllowCancellations.Checked = CType(Settings("AllowCancellations"), Boolean)
                chkAllowPrint.Checked = CType(Settings("AllowPrint"), Boolean)
                chkShowBadge.Checked = CType(Settings("ShowBadge"), Boolean)
                chkShowStatus.Checked = CType(Settings("ShowStatus"), Boolean)
                chkShowCheckBox.Checked = CType(Settings("ShowCheckBox"), Boolean)
                chkAllowPayments.Checked = CType(Settings("AllowPayments"), Boolean)
                If Settings("ShowDCDLink") IsNot Nothing Then
                    chkShowDCDLink.Checked = CType(Settings("ShowDCDLink"), Boolean)
                End If
                cmbPageSize.Text = CType(Settings("PageSize"), String)
                rdGetOrders.Text = CType(Settings("GetOrders"), String)
                txtProductId.Text = CType(Settings("ProductId"), String)
                txtTruncateDescription.Text = CType(Settings("TruncateDescription"), String)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub UpdateSettings()
            UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
            'objModules.UpdateModuleSetting(ModuleId, "AllowCancellations", CType(chkAllowCancellations.Checked, String))
            UpdateModuleSetting("AllowPrint", CType(chkAllowPrint.Checked, String))
            UpdateModuleSetting("ShowBadge", CType(chkShowBadge.Checked, String))
            UpdateModuleSetting("ShowStatus", CType(chkShowStatus.Checked, String))
            UpdateModuleSetting("ShowCheckBox", CType(chkShowCheckBox.Checked, String))
            UpdateModuleSetting("ShowDCDLink", CType(chkShowDCDLink.Checked, String))
            UpdateModuleSetting("AllowPayments", CType(chkAllowPayments.Checked, String))
            UpdateModuleSetting("PageSize", cmbPageSize.Text)
            UpdateModuleSetting("ProductId", txtProductId.Text)
            UpdateModuleSetting("TruncateDescription", txtTruncateDescription.Text)
            UpdateModuleSetting("GetOrders", rdGetOrders.Text)
            UpdateModuleSetting("printURL", printURL.Url)
            UpdateModuleSetting("badgeURL", badgeURL.Url)
            UpdateModuleSetting("summaryURL", summaryURL.Url)

            UpdateModuleSetting("printURLType", printURL.UrlType)
            UpdateModuleSetting("badgeURLType", badgeURL.UrlType)
            UpdateModuleSetting("summaryURLType", summaryURL.UrlType)

            'objModules.UpdateModuleSetting(ModuleId, "cancelURL", cancelURL.Url)
            UpdateModuleSetting("payURL", payURL.Url)
            UpdateModuleSetting("shipBill", rdGetOrders.SelectedValue)
            UpdateModuleSetting("Layout", select_Template.SelectedValue)
            UpdateModuleSetting("Layout1", select_Template1.SelectedValue)
        End Sub

        Public Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                If Page.IsValid = True Then
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Else
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace

'<tr>
'<td style="width: 210px; border-right: black thin solid; border-top: black thin solid;
'     font-weight: bold; margin: 1px; border-left: black thin solid; color: black;
'     border-bottom: black thin solid; height: 44px;">
'     <strong><dnn:LabelControl  ID="allowCancellations" runat="server"  ResourceKey="allowCancellations" width="100%" />
'     </strong>
' </td>
'         <td style="width: 168px; table-layout: auto; margin: 1px; border-collapse: separate;
'            height: 44px; border-right: black 2px solid; border-top: black 2px solid; border-left: black 2px solid;
'            border-bottom: black 2px solid;" align="center" valign="middle">
'            <asp:CheckBox ID="chkAllowCancellations" runat="server" BorderStyle="None" 
'                TextAlign="Left" Visible="True" Width="184px" Style="border-top-width: 1px; border-left-width: 1px;
'                border-left-color: black; border-bottom-width: 1px; border-bottom-color: black;
'                border-top-color: black; border-right-width: 1px; border-right-color: black;" />
'            </td>
'    </tr>




'<dnn:LabelControl  ID="cancelTab" runat="server"  ResourceKey="cancelTab" width="100%" /> <portal:url id="cancelUrl" runat="server" width="100"  
'                showtabs="True" showfiles="False" showUrls="False" 
'                urltype="T" showlog="False" ShowNewWindow="False" showtrack="False" >
'            </portal:url>

'allowCancellations.Help Allow cancellations
'allowCancellations.Text Allow cancellations:
'cancelTab.Help  Cancel orders tab
'cancelTab.Text  Cancel orders tab: