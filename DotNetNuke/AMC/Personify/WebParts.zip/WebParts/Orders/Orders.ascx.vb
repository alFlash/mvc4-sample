Option Strict Off

Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports System.Collections.Generic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Imports Personify.WebControls
Imports Personify.DNN.Modules.Orders
Imports Personify.usercontrols
Imports DotNetNuke.Common.Utilities
Imports System.Text.RegularExpressions

Namespace Personify.DNN.Modules.Orders
    <CLSCompliant(False)> _
    Public MustInherit Class Orders
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected WithEvents cmbRecentOrders As System.Web.UI.WebControls.DropDownList
        Protected WithEvents quickOpen As System.Web.UI.WebControls.CheckBox
        Protected WithEvents detailOpen As System.Web.UI.WebControls.CheckBox
        Protected WithEvents quickOrderNum As System.Web.UI.WebControls.TextBox
        Protected WithEvents no_pages As System.Web.UI.WebControls.DropDownList
        Protected WithEvents status As System.Web.UI.WebControls.DropDownList
        Protected WithEvents sortOrders As System.Web.UI.WebControls.DropDownList
        Protected WithEvents sortBy As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents fromDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents toDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents amountRange As System.Web.UI.WebControls.DropDownList
        Protected WithEvents amount As System.Web.UI.WebControls.TextBox
        Protected tableTCMSXslTemplate As Personify.WebControls.XslTemplate
        Protected detailTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents lblSearchResults As System.Web.UI.WebControls.Label
        Protected WithEvents orderView As Personify.WebControls.DataPager
        Protected WithEvents order1View As Personify.WebControls.DataPager
        Protected WithEvents pages As System.Web.UI.WebControls.Panel
        Protected WithEvents buttons As System.Web.UI.WebControls.Panel
        Protected WithEvents p1 As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents c1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents p2 As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents c2 As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents prn1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents prn2 As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents qstitle As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents print As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents print1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents withSelected As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents withSelected1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents searchResults As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents back As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents resultsPerPage As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents pay As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents cancel As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents pay1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents show As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents cancel1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents search As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents a_nd As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents between As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents advancedSearch As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents go As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents buttons1 As System.Web.UI.WebControls.Panel
        Protected WithEvents content As System.Web.UI.WebControls.Panel
        Protected WithEvents details As System.Web.UI.WebControls.Panel
        Protected WithEvents ctrlStart As Telerik.Web.UI.RadDatePicker
        Protected WithEvents ctrlEnd As Telerik.Web.UI.RadDatePicker
        Protected clicked As String
        Public pageSize As Integer
        
        Public order As WebOrderMaster
        Public orderDetail As WebOrderDetail
        Public oMyOrdersFiltered As WebOrderMasters
        Public printURL As String
        Public badgeURL As String
        Public payURL As String
        Public err As Boolean


        Protected WithEvents imgArrowRightBlue As Image
        Protected WithEvents imgDrop As HtmlImage
        Protected WithEvents imgDrop1 As HtmlImage
        Protected WithEvents imgArrowRightBlue1 As Image
        Protected WithEvents imgPrinter As Image
        Protected WithEvents imgPay As Image
        Protected WithEvents imgPrinter2 As Image
        Protected WithEvents imgPay2 As Image
        Protected WithEvents imgView As Image
        Protected WithEvents imgView1 As Image
#End Region

#Region "Event Handlers"

        Public Property CurrentPage() As Integer
            Get
                Dim o As Object = Me.ViewState("_CurrentPage")
                If (o Is Nothing) Then
                    Return 0
                Else
                    Return CType(o, Integer)
                End If
            End Get
            Set(ByVal Value As Integer)
                Me.ViewState("_CurrentPage") = Value
            End Set
        End Property

        'Public ReadOnly Property AllowCancel() As String
        '    Get
        '        Return Convert.ToString(Settings("AllowCancellations"))
        '    End Get
        'End Property

        Public ReadOnly Property AllowPay() As String
            Get
                Return Convert.ToString(Settings("AllowPayments"))
            End Get
        End Property

        Public ReadOnly Property AllowPrint() As String
            Get
                Return Convert.ToString(Settings("AllowPrint"))
            End Get
        End Property

        Private loadAtStartup As Boolean = False

        Private Function StripHTML(ByVal objHTML As String) As String
            Try
                Dim strOutput As String
                If Not IsDBNull(objHTML) Then
                    strOutput = objHTML
                    ' create regular expression object
                    Dim objRegExp1 As Regex = New Regex("<(.|\n)+?>", RegexOptions.IgnoreCase)

                    ' replace all HTML tag matches with the empty string
                    strOutput = objRegExp1.Replace(strOutput, "")

                    ' create regular expression object
                    Dim objRegExp2 As Regex = New Regex("&lt;(.|\n)+?&gt;", RegexOptions.IgnoreCase)

                    ' replace all HTML tag matches with the empty string
                    strOutput = objRegExp2.Replace(strOutput, "")
                    ' remove breaks
                    strOutput = Replace(strOutput, ControlChars.Lf, "")
                    strOutput = Replace(strOutput, Chr(13), "")
                    Return strOutput
                Else
                    Return ""
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Private Function TruncateDescription(ByVal description As String) As String
            Dim Truncate As Integer = 0
            Try
                Truncate = Convert.ToInt32(Settings("TruncateDescription"))
            Catch ex As Exception

            End Try

            If Truncate > 0 AndAlso description IsNot Nothing AndAlso description.Length > 0 Then
                description = HtmlUtils.Shorten(StripHTML(description), Truncate, "...")
            End If
            Return description
        End Function

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            '3246-5774803
            LoadImages()
            'END 3246-5774803


            



            manageSession()

            Dim role As String
            role = Me.GetUserRole(UserInfo)

            If Not IsPostBack Then

                ClearSessionObject(SessionKeys.PersonifyOrdersViewList)

                ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.BOTH.ToString)
                ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.SHIP.ToString)
                ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.BILL.ToString)

                ClearSessionObject(SessionKeys.PersonifyMembershipRenewalsViewList)
                ClearSessionObject(SessionKeys.PersonifyPayOrderIds)

            End If
            ClearSessionObject(SessionKeys.PersonifyPayOrderIds)

            If Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin" Then
                searchResults.InnerHtml = Localization.GetString("searchResults", LocalResourceFile)
                withSelected.InnerHtml = Localization.GetString("withSelected", LocalResourceFile)
                withSelected1.InnerHtml = Localization.GetString("withSelected", LocalResourceFile)
                qstitle.InnerHtml = Localization.GetString("qstitle", LocalResourceFile)
                resultsPerPage.InnerHtml = Localization.GetString("resultsPerPage", LocalResourceFile)
                pay.InnerHtml = Localization.GetString("pay", LocalResourceFile)
                show.InnerHtml = Localization.GetString("show", LocalResourceFile)
                'cancel.InnerHtml = Localization.GetString("cancel", LocalResourceFile)
                print.InnerHtml = Localization.GetString("print", LocalResourceFile)
                pay1.InnerHtml = Localization.GetString("pay", LocalResourceFile)
                'cancel1.InnerHtml = Localization.GetString("cancel", LocalResourceFile)
                print1.InnerHtml = Localization.GetString("print", LocalResourceFile)
                back.InnerHtml = Localization.GetString("back", LocalResourceFile)
                search.InnerHtml = Localization.GetString("search", LocalResourceFile)
                a_nd.InnerHtml = Localization.GetString("a_nd", LocalResourceFile)
                between.InnerHtml = Localization.GetString("between", LocalResourceFile)
                go.InnerHtml = Localization.GetString("go", LocalResourceFile)
                advancedSearch.InnerHtml = Localization.GetString("advancedSearch", LocalResourceFile)
                cmbRecentOrders.Items.FindByValue("0").Text = Localization.GetString("lastMonth", LocalResourceFile)
                cmbRecentOrders.Items.FindByValue("1").Text = Localization.GetString("lastYear", LocalResourceFile)
                cmbRecentOrders.Items.FindByValue("2").Text = Localization.GetString("AllOrders", LocalResourceFile)
                status.Items.FindByValue("All").Text = Localization.GetString("all", LocalResourceFile)
                status.Items.FindByValue("A").Text = Localization.GetString("active", LocalResourceFile)
                status.Items.FindByValue("C").Text = Localization.GetString("cancelled", LocalResourceFile)
                status.Items.FindByValue("P").Text = Localization.GetString("proforma", LocalResourceFile)
                amountRange.Items.FindByValue("0").Text = Localization.GetString("lessThan", LocalResourceFile)
                amountRange.Items.FindByValue("1").Text = Localization.GetString("equalTo", LocalResourceFile)
                amountRange.Items.FindByValue("2").Text = Localization.GetString("moreThan", LocalResourceFile)
                sortOrders.Items.FindByValue("number11").Text = Localization.GetString("number11", LocalResourceFile)
                sortOrders.Items.FindByValue("date").Text = Localization.GetString("date", LocalResourceFile)
                sortOrders.Items.FindByValue("amount").Text = Localization.GetString("amount", LocalResourceFile).ToLower
                sortOrders.Items.FindByValue("status").Text = Localization.GetString("status", LocalResourceFile).ToLower
                sortOrders.Items.FindByValue("balance").Text = Localization.GetString("balance", LocalResourceFile).ToLower
                sortBy.InnerHtml = Localization.GetString("sortBy", LocalResourceFile)

                If Not Page.IsPostBack Then
                    Session("size") = Settings("PageSize")
                Else
                    If Not (Request.Params("__EVENTTARGET") Is Nothing) Then
                        If Request.Params("__EVENTTARGET").IndexOf("QB") >= 0 Then
                            Session("which") = "quick"
                        End If
                        If Request.Params("__EVENTTARGET").IndexOf("SB") >= 0 Then
                            Session("which") = "big"
                        End If
                    End If
                    Session("size") = no_pages.SelectedValue
                    no_pages.SelectedValue = Session("size").ToString
                End If

                If loadAtStartup = True Then
                    Session("which") = "quick"
                End If

                If MasterCustomerID <> "" Then
                    'find the PrintOrder URL
                    Dim MyTabId As Integer
                    Dim MyPayTabId As Integer
                    If Settings("printURL") Is Nothing Then
                        If Not Localization.GetString("PrintError", LocalResourceFile) Is Nothing Then
                            Skins.Skin.AddModuleMessage(Me, Localization.GetString("PrintError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        Else
                            Skins.Skin.AddModuleMessage(Me, Localization.GetString("PrintError", "~/App_GlobalResources/PersonifyResources.resx"), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If

                    End If
                    MyTabId = CType(Settings("printURL"), Integer)
                    MyPayTabId = CType(Settings("payURL"), Integer)

                    Dim list As ArrayList = Me.PortalSettings.DesktopTabs
                    Dim theitem As Object, TheTab As DotNetNuke.Entities.Tabs.TabInfo
                    For Each theitem In list
                        TheTab = CType(theitem, DotNetNuke.Entities.Tabs.TabInfo)
                        If TheTab.TabID = MyTabId And (TheTab.TabName = "" Or TheTab.TabName = "Home") Then
                            If Not Localization.GetString("PrintError", LocalResourceFile) Is Nothing Then
                                Skins.Skin.AddModuleMessage(Me, Localization.GetString("PrintError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            Else
                                Skins.Skin.AddModuleMessage(Me, Localization.GetString("PrintError", "~/App_GlobalResources/PersonifyResources.resx"), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If

                        End If
                    Next
                    printURL = NavigateURL(MyTabId)
                    payURL = NavigateURL(MyPayTabId)

                    If CType(Settings("ShowBadge"), Boolean) = True Then
                        badgeURL = NavigateURL(CType(Settings("badgeURL"), Integer))
                    End If

                    order = Nothing

                    If Request.Form("detail1") = "1" Then
                        Dim ORDERNUMBER As String = Convert.ToString(Request.Form("ordernr"))
                        Response.Redirect("~/Default.aspx?tabid=" & CType(Settings("summaryURL"), String) & "&ORDERNUMBER=" + ORDERNUMBER)

                        'details.Visible = True
                        'content.Visible = False
                        'buttons.Visible = False
                        'buttons1.Visible = False
                        'pages.Visible = False
                        'Dim orderitem As WebOrderMaster
                        'Dim oMyOrders As WebOrderMasters
                        'oMyOrders = Personify.ApplicationManager.Orders.GetMyOrders(PortalId, MasterCustomerID, SubCustomerId, CustomerMode.BOTH)

                        'For Each orderitem In oMyOrders
                        '    If orderitem.OrderNumber = Request.Form("ordernr") Then
                        '        order = orderitem
                        '    End If
                        'Next

                        'Dim myXSLorder As XSLorder = New XSLorder
                        'myXSLorder.order = order
                        'myXSLorder.pay = AllowPay()
                        'myXSLorder.cancel = AllowCancel()
                        'myXSLorder.amount = Localization.GetString("amount", LocalResourceFile)
                        'myXSLorder.balance = Localization.GetString("balance", LocalResourceFile)
                        'myXSLorder.cancelb = Localization.GetString("cancel", LocalResourceFile)
                        'myXSLorder.DateOrdered = Localization.GetString("dateOrdered", LocalResourceFile)
                        'myXSLorder.dates = Localization.GetString("dates", LocalResourceFile)
                        'myXSLorder.discount = Localization.GetString("discount", LocalResourceFile)
                        'myXSLorder.location = Localization.GetString("location", LocalResourceFile)
                        'myXSLorder.orderBalance = Localization.GetString("orderBalance", LocalResourceFile)
                        'myXSLorder.OrderNo = Localization.GetString("order", LocalResourceFile)
                        'myXSLorder.paid = Localization.GetString("paid", LocalResourceFile)
                        'myXSLorder.payb = Localization.GetString("pay", LocalResourceFile)
                        'myXSLorder.print = Localization.GetString("print", LocalResourceFile)
                        'myXSLorder.quantity = Localization.GetString("quantity", LocalResourceFile)
                        'myXSLorder.shippedTo = Localization.GetString("shippedTo", LocalResourceFile)
                        'myXSLorder.shipping = Localization.GetString("shipping", LocalResourceFile)
                        'myXSLorder.shippingStatus = Localization.GetString("shippingStatus", LocalResourceFile)
                        'myXSLorder.status = Localization.GetString("status", LocalResourceFile)
                        'myXSLorder.tax = Localization.GetString("tax", LocalResourceFile)
                        'myXSLorder.tos = Localization.GetString("to", LocalResourceFile)
                        'If (order.Details.Item(0).SubSystem = "INV") Then
                        '    myXSLorder.tracking = Localization.GetString("tracking", LocalResourceFile)
                        'End If
                        'myXSLorder.total = Localization.GetString("total", LocalResourceFile)
                        'Dim templatefile As String = ""
                        'If Settings("Layout1") Is Nothing Then
                        '    templatefile = ModulePath + "Templates\MyOrdersDetails.xsl"
                        'Else
                        '    templatefile = ModulePath + "Templates\" + Settings("Layout1").ToString
                        'End If

                        'detailTemplate.XSLfile = Server.MapPath(templatefile)
                        'detailTemplate.AddObject("", myXSLorder)
                        'detailTemplate.AddObject("badgeURL", badgeURL)
                        'detailTemplate.AddObject("ShowBadges", Localization.GetString("ShowBadges.Text", LocalResourceFile))
                        'detailTemplate.AddObject("ShowStatus", CType(Settings("ShowStatus"), Boolean))
                        'detailTemplate.AddObject("ShowCheckBox", CType(Settings("ShowCheckBox"), Boolean))
                        'detailTemplate.AddObject("MasterCustomerID", MasterCustomerID)
                        'detailTemplate.AddObject("SubCustomerId", SubCustomerId)

                        'detailTemplate.Display()
                        'details.Visible = True

                        'Dim detBtn As New HtmlControls.HtmlAnchor
                        'detBtn = CType(Me.FindControl("detBtn".ToString), HtmlControls.HtmlAnchor)
                        'Dim ids As New ArrayList()
                        'Dim theId As String
                        'theId = order.OrderNumber
                        'ids.Add(theId)
                        'ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
                        'SessionManager.AddSessionObject(PortalId, SessionManager.SessionKeys.PersonifyPayOrderIds, ids)
                        'If AllowPay = "True" Then
                        '    detBtn.Attributes("href") = payURL
                        'End If

                    Else
                        details.Visible = False
                        content.Visible = True
                        buttons.Visible = False
                        buttons1.Visible = False
                        pages.Visible = False

                        pageSize = CType(Session("size"), Integer)

                        If loadAtStartup = True Then

                            InitializePagerQuick()
                            ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
                            LoadXSLQuick()
                            clicked = "done"

                        Else

                            If Page.IsPostBack And (clicked <> "done" Or (Not (Request.Params("__EVENTTARGET") Is Nothing))) Then

                                Dim who As String
                                who = CType(Request.Form("__EVENTTARGET"), String)

                                If Not Session("which") Is Nothing Then
                                    If Session("which").ToString = "quick" Then
                                        InitializePagerQuick()
                                        If who.Contains("no_pages") Or who.Contains("backButton") Or who.Contains("sortOrders") Then
                                            'If who.Contains("no_pages") Then 'if items per page changed, go page 1
                                            '    CurrentPage = 1
                                            'End If
                                            LoadXSLQuick()
                                        End If
                                    End If

                                    If Session("which").ToString = "big" Then
                                        InitializePagerBig()
                                        If who.Contains("no_pages") Or who.Contains("backButton") Or who.Contains("sortOrders") Then
                                            'If who.Contains("no_pages") Then 'if items per page changed, go page 1
                                            '    CurrentPage = 1
                                            'End If
                                            LoadXSLBig()
                                        End If

                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            Else 'The current user does not have these attributes
                details.Visible = False
                content.Visible = False
                buttons.Visible = False
                buttons1.Visible = False
                pages.Visible = False
                DisplayUserAccessMessage(role)
            End If

        End Sub

        Public Sub InitializePagerBig()

            Dim order As WebOrderMaster
            Dim startDate As String
            Dim endDate As String
            Dim d1 As Date
            Dim d2 As Date
            'startDate = ctrlStart.Datetextbox.Text
            'endDate = ctrlEnd.Datetextbox.Text
            startDate = ctrlStart.SelectedDate.ToString
            endDate = ctrlEnd.SelectedDate.ToString
            If startDate = "" And endDate = "" And amount.Text = "" And status.Text = "All" Then
                err = True
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCriteria", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
            If startDate <> "" Or endDate <> "" Then
                Dim startinv As Boolean
                startinv = False
                err = False
                Try
                    d1 = DateTime.Parse(startDate)
                Catch ex As Exception
                    err = True
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("StartInvalid", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    startinv = True
                End Try
                Try
                    d2 = DateTime.Parse(endDate)
                Catch ex As Exception
                    err = True
                    If startinv Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("BothInvalid", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    Else
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("EndInvalid", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End Try
                If d2 < d1 Then
                    err = True
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("Greater", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If
            End If
            If amount.Text <> "" Then
                Try
                    Dim tempdec As Decimal
                    tempdec = CDec(amount.Text)
                Catch ex As Exception
                    err = True
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("AmountInvalid", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try
            End If

            If err = False Then
                Dim whichOrders As CustomerMode
                Select Case Convert.ToString(Settings("shipBill"))
                    Case "0"
                        whichOrders = CustomerMode.SHIP
                    Case "1"
                        whichOrders = CustomerMode.BILL
                    Case "2"
                        whichOrders = CustomerMode.BOTH
                    Case Nothing
                        whichOrders = CustomerMode.BOTH
                End Select

                Dim oMyOrders As WebOrderMasters
                oMyOrdersFiltered = New WebOrderMasters
                oMyOrders = GetMyOrders(MasterCustomerId, SubCustomerId, whichOrders)


                oMyOrdersFiltered = New WebOrderMasters

                For Each order In oMyOrders
                    Dim insert1 As Boolean = False
                    Dim insert2 As Boolean = False
                    Dim insert3 As Boolean = False

                    If order.OrderStatusCode = status.Text Or status.Text = "All" Then
                        insert1 = True
                    End If

                    If startDate <> "" And endDate <> "" Then
                        If order.OrderDate >= DateTime.Parse(startDate) And order.OrderDate <= DateTime.Parse(endDate) Then
                            insert2 = True
                        End If
                    Else
                        insert2 = True
                    End If



                    If amount.Text = "" Then
                        insert3 = True
                    Else
                        Select Case amountRange.Text
                            Case "0" 'less than
                                If order.OrderTotal < CDec(amount.Text) Then
                                    insert3 = True
                                End If
                            Case "1" 'equal to
                                If order.OrderTotal = CDec(amount.Text) Then
                                    insert3 = True
                                End If
                            Case "2" 'more than
                                If order.OrderTotal > CDec(amount.Text) Then
                                    insert3 = True
                                End If
                        End Select
                    End If

                    If detailOpen.Checked Then
                        If order.OrderBalance > 0 And insert1 And insert2 And insert3 Then
                            oMyOrdersFiltered.Add(order)
                        End If
                    End If
                    If Not detailOpen.Checked Then
                        If insert1 And insert2 And insert3 Then
                            oMyOrdersFiltered.Add(order)
                        End If
                    End If

                Next

                If oMyOrdersFiltered.Count <= 0 Then
                    buttons.Visible = False
                    buttons1.Visible = False
                    pages.Visible = False
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrder", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                Else
                    pages.Visible = True
                    buttons.Visible = True
                    'If AllowCancel = "True" Then
                    '    c1.Visible = True
                    '    c2.Visible = True
                    'End If
                    If AllowPay = "True" Then
                        p1.Visible = True
                        p2.Visible = True
                    End If
                    If AllowPrint = "True" Then
                        prn1.Visible = True
                        prn2.Visible = True
                    End If
                    'If c1.Visible = False AndAlso p1.Visible = False AndAlso prn1.Visible = False Then
                    If p1.Visible = False AndAlso prn1.Visible = False Then
                        withSelected.Visible = False
                        withSelected1.Visible = False
                    End If
                    buttons1.Visible = True
                End If

                'sort ---------------------------------------------------------------
                Dim buffer As New System.Collections.Generic.List(Of WebOrderMaster)
                For Each orderItem As WebOrderMaster In oMyOrdersFiltered
                    Dim element As New WebOrderMaster
                    element.BillTo = orderItem.BillTo
                    element.Description = TruncateDescription(orderItem.Description) ' + "_1"
                    element.Details = orderItem.Details
                    If element.Details IsNot Nothing AndAlso element.Details.Count > 0 Then
                        For Each detail As WebOrderDetail In element.Details
                            If detail IsNot Nothing Then
                                detail.Description = TruncateDescription(detail.Description)
                            End If
                        Next
                    End If
                    element.OrderBalance = orderItem.OrderBalance
                    element.OrderDate = orderItem.OrderDate
                    element.OrderNumber = orderItem.OrderNumber
                    element.OrderStatusCode = orderItem.OrderStatusCode
                    element.OrderStatusCodeDescr = orderItem.OrderStatusCodeDescr
                    element.OrderTotal = orderItem.OrderTotal
                    element.ShipTo = orderItem.ShipTo
                    element.TotalPayments = orderItem.TotalPayments
                    element.TotalShipping = orderItem.TotalShipping
                    element.OrderMaxBadges = orderItem.OrderMaxBadges
                    element.BillMasterCustomerID = orderItem.BillMasterCustomerID
                    element.BillSubCustomerID = orderItem.BillSubCustomerID
                    element.ShipMasterCustomerID = orderItem.ShipMasterCustomerID
                    element.ShipSubCustomerID = orderItem.ShipSubCustomerID

                    buffer.Add(element)
                Next
                Dim ordersComparer As New OrdersComparer(sortOrders.SelectedValue)
                buffer.Sort(ordersComparer)
                oMyOrdersFiltered.Clear()
                For Each orderItem As WebOrderMaster In buffer
                    Dim element As New WebOrderMaster
                    element.BillTo = orderItem.BillTo
                    element.Description = orderItem.Description '+ "_2"
                    element.Details = orderItem.Details
                    element.OrderBalance = orderItem.OrderBalance
                    element.OrderDate = orderItem.OrderDate
                    element.OrderNumber = orderItem.OrderNumber
                    element.OrderStatusCode = orderItem.OrderStatusCode
                    element.OrderStatusCodeDescr = orderItem.OrderStatusCodeDescr
                    element.OrderTotal = orderItem.OrderTotal
                    element.ShipTo = orderItem.ShipTo
                    element.TotalPayments = orderItem.TotalPayments
                    element.TotalShipping = orderItem.TotalShipping
                    element.TotalTax = orderItem.TotalTax
                    element.OrderMaxBadges = orderItem.OrderMaxBadges
                    element.BillMasterCustomerID = orderItem.BillMasterCustomerID
                    element.BillSubCustomerID = orderItem.BillSubCustomerID
                    element.ShipMasterCustomerID = orderItem.ShipMasterCustomerID
                    element.ShipSubCustomerID = orderItem.ShipSubCustomerID

                    oMyOrdersFiltered.Add(element)
                Next


                'end sort----------------------------------------------------------------------

                order1View.PageNumbersDisplay = PageNumbersDisplayType.Numbers
                order1View.ShowPageNumbers = True
                order1View.Visible = True

                order1View.DataSource = oMyOrdersFiltered
                order1View.PageSize = pageSize
                order1View.PagingMode = Personify.WebControls.PagingModeType.PostBack

                order1View.DataBind()
            Else
                buttons.Visible = False
                buttons1.Visible = False
            End If

        End Sub

        Public Sub LoadXSLBig()
            Dim myIds As New ArrayList()
            If err = False Then

                Dim who As String
                who = CType(Request.Form("__EVENTTARGET"), String)
                If who.Contains("no_pages") Then 'if items per page changed, go page 1
                    order1View.EnableViewState = False
                    CurrentPage = 1
                    order1View.CurrentPage = 1
                    order1View.DataSourcePaged.CurrentPageIndex = CurrentPage - 1
                    '                orderView.MaxPages = 22
                Else
                    order1View.EnableViewState = True
                    CurrentPage = order1View.CurrentPage
                    order1View.DataSourcePaged.CurrentPageIndex = CurrentPage - 1
                End If

                Dim bodyMembers(order1View.DataSourcePaged.Count - 1) As WebOrderMaster
                Dim j As Integer = 0
                Dim ie As IEnumerator = order1View.DataSourcePaged.GetEnumerator

                While ie.MoveNext
                    bodyMembers(j) = New WebOrderMaster()
                    bodyMembers(j) = CType(ie.Current, WebOrderMaster)
                    j = j + 1
                End While

                Dim templatefile As String = ""
                If Settings("Layout") Is Nothing Then
                    templatefile = ModulePath + "Templates\MyOrdersTemplate.xsl"
                Else
                    templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
                End If
                tableTCMSXslTemplate.XSLfile = Server.MapPath(templatefile)

                '3246-5774803
                Dim ExpandImageURL As String = GetExpandImageURL()
                tableTCMSXslTemplate.AddObject("ExpandImageURL", ExpandImageURL)
                Dim CollapseImageURL As String = GetCollapseImageURL()
                tableTCMSXslTemplate.AddObject("CollapseImageURL", CollapseImageURL)
                'end 3246-5774803

                Dim myXSLBodyMembers As New XSLbodyMembers
                Dim myBodyMembers(order1View.DataSourcePaged.Count - 1) As BodyMember
                Dim k As Integer
                k = 0
                For Each member As WebOrderMaster In bodyMembers
                    Dim item As New BodyMember()
                    item.bodymember = member
                    If Not member Is Nothing Then
                        Dim ids As New ArrayList()
                        If Not GetSessionObject(SessionKeys.PersonifyPayOrderIds) Is Nothing Then
                            ids = CType(GetSessionObject(SessionKeys.PersonifyPayOrderIds), ArrayList)
                        End If

                        If ids.Contains(member.OrderNumber) Then
                            item.checked = "true"
                        Else
                            item.checked = "false"
                        End If
                    End If
                    myBodyMembers(k) = item
                    k = k + 1
                Next
                myXSLBodyMembers.bodyMembers = myBodyMembers
                myXSLBodyMembers.quote = Localization.GetString("quote", LocalResourceFile)

                tableTCMSXslTemplate.AddObject("", myXSLBodyMembers)
                tableTCMSXslTemplate.AddObject("badgeURL", badgeURL)
                tableTCMSXslTemplate.AddObject("ShowBadges", Localization.GetString("ShowBadges.Text", LocalResourceFile))
                tableTCMSXslTemplate.AddObject("ShowStatus", CType(Settings("ShowStatus"), Boolean))
                tableTCMSXslTemplate.AddObject("ShowCheckBox", CType(Settings("ShowCheckBox"), Boolean))
                'DCD link
                If Settings("ShowDCDLink") IsNot Nothing Then
                    tableTCMSXslTemplate.AddObject("ShowDCDLink", CType(Settings("ShowDCDLink"), Boolean))
                Else
                    tableTCMSXslTemplate.AddObject("ShowDCDLink", False)
                End If
                tableTCMSXslTemplate.AddObject("MasterCustomerID", MasterCustomerID)
                tableTCMSXslTemplate.AddObject("SubCustomerId", SubCustomerId)
                Dim Symbol As String = Me.PortalCurrency.Symbol
                tableTCMSXslTemplate.AddObject("Symbol", Symbol)

                If bodyMembers.Length >= 1 Then
                    tableTCMSXslTemplate.Display()
                    Dim orderNo As New HtmlGenericControl
                    Dim shortName As New HtmlGenericControl
                    Dim theDate As New HtmlGenericControl
                    Dim status1 As New HtmlGenericControl
                    Dim total As New HtmlGenericControl
                    Dim paid As New HtmlGenericControl
                    Dim balance As New HtmlGenericControl
                    Dim btnPay1 As New HtmlControls.HtmlAnchor
                    Dim btnPay2 As New HtmlControls.HtmlAnchor

                    btnPay1 = CType(Me.FindControl("btnPay1".ToString), HtmlControls.HtmlAnchor)
                    btnPay2 = CType(Me.FindControl("btnPay2".ToString), HtmlControls.HtmlAnchor)

                    btnPay1.Attributes("href") = Page.ClientScript.GetPostBackEventReference(Me, "anything")
                    btnPay2.Attributes("href") = Page.ClientScript.GetPostBackEventReference(Me, "anything")

                    orderNo = CType(Me.FindControl("orderNo".ToString), HtmlGenericControl)
                    shortName = CType(Me.FindControl("shortName".ToString), HtmlGenericControl)
                    theDate = CType(Me.FindControl("theDate".ToString), HtmlGenericControl)
                    status1 = CType(Me.FindControl("status1".ToString), HtmlGenericControl)
                    total = CType(Me.FindControl("total".ToString), HtmlGenericControl)
                    paid = CType(Me.FindControl("paid".ToString), HtmlGenericControl)
                    balance = CType(Me.FindControl("balance".ToString), HtmlGenericControl)



                    orderNo.InnerHtml = Localization.GetString("order", LocalResourceFile)
                    shortName.InnerHtml = Localization.GetString("shortName", LocalResourceFile)
                    theDate.InnerHtml = Localization.GetString("theDate", LocalResourceFile)
                    If status1 IsNot Nothing Then status1.InnerHtml = Localization.GetString("status", LocalResourceFile)
                    total.InnerHtml = Localization.GetString("total", LocalResourceFile)
                    paid.InnerHtml = Localization.GetString("paid", LocalResourceFile)
                    balance.InnerHtml = Localization.GetString("balance", LocalResourceFile)
                End If
            End If
        End Sub

        Public Sub InitializePagerQuick()


            Dim whichOrders As CustomerMode
            Select Case Convert.ToString(Settings("shipBill"))
                Case "0"
                    whichOrders = CustomerMode.SHIP
                Case "1"
                    whichOrders = CustomerMode.BILL
                Case "2"
                    whichOrders = CustomerMode.BOTH
                Case Nothing
                    whichOrders = CustomerMode.BOTH
            End Select

            Dim oMyOrders As WebOrderMasters
            oMyOrders = GetMyOrders(MasterCustomerId, SubCustomerId, whichOrders)
            oMyOrdersFiltered = New WebOrderMasters

            Dim order As WebOrderMaster

            Dim productIDs As String = CType(Settings("ProductId"), String)
            Dim aProductID() As String = Nothing
            If productIDs IsNot Nothing AndAlso productIDs.Trim().Length > 0 Then
                aProductID = productIDs.Split(CType(",", Char))
            End If

            If aProductID IsNot Nothing AndAlso aProductID.Length > 0 Then
                For Each order In oMyOrders
                    Dim includeOrder As Boolean = False
                    If order IsNot Nothing AndAlso order.Details IsNot Nothing AndAlso order.Details.Count > 0 Then
                        For Each wod As WebOrderDetail In order.Details
                            For Each apid As String In aProductID
                                If apid IsNot Nothing AndAlso apid.Length > 0 AndAlso wod.ProductId.ToString = apid.Trim Then
                                    includeOrder = True
                                    Exit For
                                End If
                            Next
                        Next
                    End If
                    If includeOrder = True Then
                        oMyOrdersFiltered.Add(order)
                    End If

                Next

            Else
                If quickOrderNum.Text = Nothing Then
                    If quickOpen.Checked Then

                        Select Case cmbRecentOrders.Text
                            Case "0" ' within the last month
                                For Each order In oMyOrders
                                    If order.OrderBalance > 0 And order.OrderDate > DateTime.Now.AddMonths(-1) Then
                                        oMyOrdersFiltered.Add(order)
                                    End If
                                Next
                            Case "1" ' within the last year
                                For Each order In oMyOrders
                                    If order.OrderBalance > 0 And order.OrderDate > DateTime.Now.AddYears(-1) Then
                                        oMyOrdersFiltered.Add(order)
                                    End If
                                Next
                            Case "2" ' within all
                                For Each order In oMyOrders
                                    If order.OrderBalance > 0 Then
                                        oMyOrdersFiltered.Add(order)
                                    End If
                                Next
                        End Select
                    End If
                    If Not quickOpen.Checked Then
                        Select Case cmbRecentOrders.Text
                            Case "0" ' within the last month
                                For Each order In oMyOrders
                                    If order.OrderDate > DateTime.Now.AddMonths(-1) Then
                                        oMyOrdersFiltered.Add(order)
                                    End If
                                Next
                            Case "1" ' within the last year
                                For Each order In oMyOrders
                                    If order.OrderDate > DateTime.Now.AddYears(-1) Then
                                        oMyOrdersFiltered.Add(order)
                                    End If
                                Next
                            Case "2" ' within all
                                For Each order In oMyOrders
                                    oMyOrdersFiltered.Add(order)
                                Next
                        End Select
                    End If
                Else
                    For Each order In oMyOrders
                        If order.OrderNumber = quickOrderNum.Text Then
                            oMyOrdersFiltered.Add(order)
                        End If
                    Next
                End If
            End If

            If oMyOrdersFiltered.Count <= 0 Then
                buttons.Visible = False
                buttons1.Visible = False
                pages.Visible = False
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrder", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            Else
                pages.Visible = True
                buttons.Visible = True
                'If AllowCancel = "True" Then
                '    c1.Visible = True
                '    c2.Visible = True
                'End If
                If AllowPay = "True" Then
                    p1.Visible = True
                    p2.Visible = True
                End If
                If AllowPrint = "True" Then
                    prn1.Visible = True
                    prn2.Visible = True
                End If
                '                If c1.Visible = False AndAlso p1.Visible = False AndAlso prn1.Visible = False Then
                If p1.Visible = False AndAlso prn1.Visible = False Then
                    withSelected.Visible = False
                    withSelected1.Visible = False
                End If

                buttons1.Visible = True
            End If
            'sort ---------------------------------------------------------------
            Dim buffer As New System.Collections.Generic.List(Of WebOrderMaster)
            For Each orderItem As WebOrderMaster In oMyOrdersFiltered
                Dim element As New WebOrderMaster
                element.BillTo = orderItem.BillTo
                element.Description = TruncateDescription(orderItem.Description) ' + "_3"
                element.Details = orderItem.Details
                If element.Details IsNot Nothing AndAlso element.Details.Count > 0 Then
                    For Each detail As WebOrderDetail In element.Details
                        If detail IsNot Nothing Then
                            detail.Description = TruncateDescription(detail.Description)
                        End If
                    Next
                End If
                element.OrderBalance = orderItem.OrderBalance
                element.OrderDate = orderItem.OrderDate
                element.OrderNumber = orderItem.OrderNumber
                element.OrderStatusCode = orderItem.OrderStatusCode
                element.OrderStatusCodeDescr = orderItem.OrderStatusCodeDescr
                element.OrderTotal = orderItem.OrderTotal
                element.ShipTo = orderItem.ShipTo
                element.TotalPayments = orderItem.TotalPayments
                element.TotalShipping = orderItem.TotalShipping
                element.TotalTax = orderItem.TotalTax
                element.OrderMaxBadges = orderItem.OrderMaxBadges
                element.BillMasterCustomerID = orderItem.BillMasterCustomerID
                element.BillSubCustomerID = orderItem.BillSubCustomerID
                element.ShipMasterCustomerID = orderItem.ShipMasterCustomerID
                element.ShipSubCustomerID = orderItem.ShipSubCustomerID

                buffer.Add(element)
            Next
            Dim ordersComparer As New OrdersComparer(sortOrders.SelectedValue)
            buffer.Sort(ordersComparer)
            oMyOrdersFiltered.Clear()
            For Each orderItem As WebOrderMaster In buffer
                Dim element As New WebOrderMaster
                element.BillTo = orderItem.BillTo
                element.Description = orderItem.Description '+ "_4"
                element.Details = orderItem.Details
                element.OrderBalance = orderItem.OrderBalance
                element.OrderDate = orderItem.OrderDate
                element.OrderNumber = orderItem.OrderNumber
                element.OrderStatusCode = orderItem.OrderStatusCode
                element.OrderStatusCodeDescr = orderItem.OrderStatusCodeDescr
                element.OrderTotal = orderItem.OrderTotal
                element.ShipTo = orderItem.ShipTo
                element.TotalPayments = orderItem.TotalPayments
                element.TotalShipping = orderItem.TotalShipping
                element.TotalTax = orderItem.TotalTax
                element.OrderMaxBadges = orderItem.OrderMaxBadges
                element.BillMasterCustomerID = orderItem.BillMasterCustomerID
                element.BillSubCustomerID = orderItem.BillSubCustomerID
                element.ShipMasterCustomerID = orderItem.ShipMasterCustomerID
                element.ShipSubCustomerID = orderItem.ShipSubCustomerID

                oMyOrdersFiltered.Add(element)
            Next


            'end sort----------------------------------------------------------------------
            orderView.PageNumbersDisplay = PageNumbersDisplayType.Numbers
            orderView.ShowPageNumbers = True
            orderView.Visible = True
            orderView.DataSource = oMyOrdersFiltered
            orderView.PageSize = pageSize
            orderView.PagingMode = Personify.WebControls.PagingModeType.PostBack
            orderView.DataBind()

        End Sub

        Public Sub LoadXSLQuick()
            Dim myIds As New ArrayList()

            Dim who As String
            who = CType(Request.Form("__EVENTTARGET"), String)
            'Fix CQ31531
            If Session("size") IsNot Nothing Then
                orderView.PageSize = CType(Session("size").ToString, Integer)
            End If
            If (who IsNot Nothing AndAlso who.Contains("no_pages")) OrElse loadAtStartup = True Then 'if items per page changed, go page 1
                orderView.EnableViewState = False
                CurrentPage = 1
                orderView.CurrentPage = 1
                orderView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1

                '                orderView.MaxPages = 22
            Else
                orderView.EnableViewState = True
                'fix CQ31401
                If (orderView.CurrentPage > orderView.PageCount) Then
                    orderView.CurrentPage = 1
                End If
                CurrentPage = orderView.CurrentPage
                orderView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1
            End If


            Dim bodyMembers(orderView.DataSourcePaged.Count - 1) As WebOrderMaster
            Dim j As Integer = 0
            Dim ie As IEnumerator = orderView.DataSourcePaged.GetEnumerator

            While ie.MoveNext
                bodyMembers(j) = New WebOrderMaster()
                bodyMembers(j) = CType(ie.Current, WebOrderMaster)
                j = j + 1
            End While
            Dim templatefile As String = ""
            If Settings("Layout") Is Nothing Then
                templatefile = ModulePath + "Templates\MyOrdersTemplate.xsl"
            Else
                templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
            End If
            tableTCMSXslTemplate.XSLfile = Server.MapPath(templatefile)

            

            Dim myXSLBodyMembers As New XSLbodyMembers
            Dim myBodyMembers(orderView.DataSourcePaged.Count - 1) As BodyMember
            Dim k As Integer
            k = 0
            For Each member As WebOrderMaster In bodyMembers
                Dim item As New BodyMember()
                item.bodymember = member
                If Not member Is Nothing Then
                    Dim ids As New ArrayList()
                    ids = CType(GetSessionObject(SessionKeys.PersonifyPayOrderIds), ArrayList)
                    If Not ids Is Nothing Then
                        If ids.Contains(member.OrderNumber) Then
                            item.checked = "true"
                        Else
                            item.checked = "false"
                        End If
                    Else
                        item.checked = "false"
                    End If
                End If
                myBodyMembers(k) = item
                k = k + 1
            Next
            myXSLBodyMembers.bodyMembers = myBodyMembers
            myXSLBodyMembers.quote = Localization.GetString("quote", LocalResourceFile)

            tableTCMSXslTemplate.AddObject("", myXSLBodyMembers)
            '3246-5774803
            Dim ExpandImageURL As String = GetExpandImageURL()
            tableTCMSXslTemplate.AddObject("ExpandImageURL", ExpandImageURL)
            Dim CollapseImageURL As String = GetCollapseImageURL()
            tableTCMSXslTemplate.AddObject("CollapseImageURL", CollapseImageURL)
            'end 3246-5774803
            tableTCMSXslTemplate.AddObject("badgeURL", badgeURL)
            tableTCMSXslTemplate.AddObject("ShowBadges", Localization.GetString("ShowBadges.Text", LocalResourceFile))
            tableTCMSXslTemplate.AddObject("ShowStatus", CType(Settings("ShowStatus"), Boolean))
            tableTCMSXslTemplate.AddObject("ShowCheckBox", CType(Settings("ShowCheckBox"), Boolean))
            'DCD link
            If Settings("ShowDCDLink") IsNot Nothing Then
                tableTCMSXslTemplate.AddObject("ShowDCDLink", CType(Settings("ShowDCDLink"), Boolean))
            Else
                tableTCMSXslTemplate.AddObject("ShowDCDLink", False)
            End If
            tableTCMSXslTemplate.AddObject("MasterCustomerID", MasterCustomerID)
            tableTCMSXslTemplate.AddObject("SubCustomerId", SubCustomerId)
            Dim Symbol As String = Me.PortalCurrency.Symbol
            tableTCMSXslTemplate.AddObject("Symbol", Symbol)

            If bodyMembers.Length >= 1 Then
                Try
                    tableTCMSXslTemplate.Display()
                Catch ex As Exception

                End Try

                Dim orderNo As New HtmlGenericControl
                Dim shortName As New HtmlGenericControl
                Dim theDate As New HtmlGenericControl
                Dim status1 As New HtmlGenericControl
                Dim total As New HtmlGenericControl
                Dim paid As New HtmlGenericControl
                Dim balance As New HtmlGenericControl
                'Dim sortOrders As New System.Web.UI.WebControls.DropDownList
                'Dim sortBy As New System.Web.UI.HtmlControls.HtmlGenericControl

                'sortBy = CType(Me.FindControl("sortBy".ToString), HtmlGenericControl)
                'sortOrders = CType(Me.FindControl("sortOrders".ToString), System.Web.UI.WebControls.DropDownList)
                orderNo = CType(Me.FindControl("orderNo".ToString), HtmlGenericControl)
                shortName = CType(Me.FindControl("shortName".ToString), HtmlGenericControl)
                theDate = CType(Me.FindControl("theDate".ToString), HtmlGenericControl)
                status1 = CType(Me.FindControl("status1".ToString), HtmlGenericControl)
                total = CType(Me.FindControl("total".ToString), HtmlGenericControl)
                paid = CType(Me.FindControl("paid".ToString), HtmlGenericControl)
                balance = CType(Me.FindControl("balance".ToString), HtmlGenericControl)

                'sortOrders.Items.FindByValue("number").Text = Localization.GetString("numberl", LocalResourceFile)
                'sortOrders.Items.FindByValue("date").Text = Localization.GetString("date", LocalResourceFile)
                'sortOrders.Items.FindByValue("amount").Text = Localization.GetString("amount", LocalResourceFile).ToLower
                'sortOrders.Items.FindByValue("status").Text = Localization.GetString("status", LocalResourceFile).ToLower
                'sortOrders.Items.FindByValue("balance").Text = Localization.GetString("balance", LocalResourceFile).ToLower

                'sortBy.InnerHtml = Localization.GetString("sortBy", LocalResourceFile)
                orderNo.InnerHtml = Localization.GetString("order", LocalResourceFile)
                shortName.InnerHtml = Localization.GetString("shortName", LocalResourceFile)
                theDate.InnerHtml = Localization.GetString("theDate", LocalResourceFile)
                If status1 IsNot Nothing Then status1.InnerHtml = Localization.GetString("status", LocalResourceFile)
                total.InnerHtml = Localization.GetString("total", LocalResourceFile)
                paid.InnerHtml = Localization.GetString("paid", LocalResourceFile)
                balance.InnerHtml = Localization.GetString("balance", LocalResourceFile)
            End If
        End Sub
        Public Sub manageSession()
            Dim ids As New ArrayList()
            Dim trueString As String
            Dim falseString As String
            Dim trueIds() As String
            Dim falseIds() As String
            Dim exists As Boolean

            trueString = Request.Form("hdnTrue")
            falseString = Request.Form("hdnFalse")


            If Not trueString Is Nothing And Not falseString Is Nothing Then

                If Not GetSessionObject(SessionKeys.PersonifyPayOrderIds) Is Nothing Then
                    ids = CType(GetSessionObject(SessionKeys.PersonifyPayOrderIds), ArrayList)
                End If

                trueIds = trueString.Split(CType(";", Char))
                falseIds = falseString.Split(CType(";", Char))

                If Not ids Is Nothing Then
                    For Each id As String In trueIds
                        exists = False
                        For Each sesId As String In ids
                            If sesId = id Then
                                exists = True
                            End If
                        Next
                        If exists = False Then
                            ids.Add(id)
                        End If
                    Next
                Else
                    If Not trueIds Is "" Then
                        For Each id As String In trueIds
                            ids.Add(id)
                        Next
                    End If


                End If
                If Not ids Is Nothing Then
                    For Each id As String In falseIds
                        exists = False
                        For Each sesId As String In ids
                            If sesId = id Then
                                exists = True
                            End If
                        Next
                        If exists = True Then
                            ids.Remove(id)
                        End If
                    Next
                End If

                ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
                AddSessionObject(SessionKeys.PersonifyPayOrderIds, ids)
            End If
        End Sub

        Public Sub cmdGo_Click(ByVal Source As Object, ByVal E As EventArgs)
            ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
            Session("size") = Settings("PageSize")
            no_pages.SelectedValue = Session("size").ToString
            LoadXSLQuick()
            clicked = "done"
        End Sub

        Public Sub cmdSearch_Click(ByVal Source As Object, ByVal E As EventArgs)
            ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
            LoadXSLBig()
            clicked = "done"
        End Sub

        Public Sub cmd_Pay(ByVal Source As Object, ByVal E As EventArgs)
            manageSession()
            Response.Redirect(payURL)
        End Sub

        Public Sub cmd_DetailPay(ByVal Source As Object, ByVal E As EventArgs)
            Dim ids As New ArrayList()
            Dim theId As String
            theId = order.OrderNumber
            ids.Add(theId)
            ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
            AddSessionObject(SessionKeys.PersonifyPayOrderIds, ids)
            Response.Redirect(payURL)
        End Sub

        Public Sub cmdBack(ByVal Source As Object, ByVal E As EventArgs)
            details.Visible = False
            pages.Visible = True
            buttons.Visible = True
            'If AllowCancel = "True" Then
            '    c1.Visible = True
            '    c2.Visible = True
            'End If
            If AllowPay = "True" Then
                p1.Visible = True
                p2.Visible = True
            End If
            If AllowPrint = "True" Then
                prn1.Visible = True
                prn2.Visible = True
            End If
            'If c1.Visible = False AndAlso p1.Visible = False AndAlso prn1.Visible = False Then
            If p1.Visible = False AndAlso prn1.Visible = False Then
                withSelected.Visible = False
                withSelected1.Visible = False
            End If

            buttons1.Visible = True
        End Sub

        Private Sub orderView_Change() Handles orderView.Change
            If CurrentPage >= 1 Then
                LoadXSLQuick()
            End If
        End Sub

        Private Sub order1View_Change() Handles order1View.Change
            If CurrentPage >= 1 Then
                LoadXSLBig()
            End If
        End Sub

#End Region

#Region "Image Functions"
        '3246-5774803
        Private Sub LoadImages()


            imgArrowRightBlue.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/arrow_right_blue.gif")
            imgDrop.Src = ResolveUrl("~/" & SiteImagesFolder & "/drpdown.gif")
            imgDrop1.Src = ResolveUrl("~/" & SiteImagesFolder & "/drpdown.gif")
            imgArrowRightBlue1.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/arrow_right_blue.gif")
            imgPrinter.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/printer.gif")
            imgPay.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/arrow_right_blue.gif")
            imgPrinter2.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/printer.gif")
            imgPay2.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/arrow_right_blue.gif")
            imgView.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/view.gif")
            imgView1.ImageUrl = ResolveUrl("~/" & SiteImagesFolder & "/view.gif")
        End Sub

        Private Function GetExpandImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/expand.gif")
        End Function
        Private Function GetCollapseImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/collapse.gif")
        End Function
        Private Function GetPixelImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/1pixel.gif")
        End Function       
        'END 3246-5774803
#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Personify"
        Private Function GetMyOrders(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal mode As CustomerMode _
) As WebOrderMasters

            'Dim ProductId As Integer = 4

            Dim oWebOrderMasters As New WebOrderMasters
            Dim oWebOrderMaster As WebOrderMaster = Nothing
            Dim oWebOrderDetail As WebOrderDetail = Nothing
            Dim oWebOrderDetails As WebOrderDetails
            Dim ids As New List(Of String)
            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters

            Dim appendToKey As String = MasterCustomerId + SubCustomerId.ToString + mode.ToString

            If Not GetSessionObject(SessionKeys.PersonifyWebOrderMaster, appendToKey) Is Nothing Then
                oWebOrderMasters = GetSessionObject(SessionKeys.PersonifyWebOrderMaster, appendToKey)
            Else


                oOrderMasters = GetMyOrderMasters(MasterCustomerId, SubCustomerId, mode)

                For Each oOM As TIMSS.API.OrderInfo.IOrderMaster In oOrderMasters
                    ids.Add(oOM.OrderNumber)
                    oWebOrderMaster = oWebOrderMasters.AddNewOrderMaster
                    oWebOrderMaster.OrderNumber = oOM.OrderNumber
                    oWebOrderMaster.OrderDate = oOM.OrderDate
                    If oOM.Details.Count = 1 Then
                        oWebOrderMaster.Description = oOM.Details(0).Description
                    Else
                        oWebOrderMaster.Description = "Please expand for details"
                    End If


                    oWebOrderMaster.OrderStatusCode = oOM.OrderStatusCode.Code
                    oWebOrderMaster.OrderStatusCodeDescr = oOM.OrderStatusCode.Description
                    oWebOrderMaster.OrderTotal = oOM.TotalOrderAmount
                    oWebOrderMaster.OrderBalance = oOM.OrderBalance
                    'TODO - HACK
                    oWebOrderMaster.TotalPayments = oOM.OrderFinancialAnalysis.InvClearedReceipts
                    'Add additional Order Master Properties
                    oWebOrderMaster.BillTo = oOM.BillAddressDetailInfo.FormattedDetail
                    oWebOrderMaster.ShipTo = oOM.ShipAddressDetailInfo.FormattedDetail
                    oWebOrderMaster.TotalShipping = oOM.TotalShippingAmount
                    oWebOrderMaster.TotalTax = oOM.TotalTaxAmount

                    oWebOrderMaster.ShipMasterCustomerID = oOM.ShipMasterCustomerId
                    oWebOrderMaster.ShipSubCustomerID = oOM.ShipSubCustomerId
                    oWebOrderMaster.BillMasterCustomerID = oOM.BillMasterCustomerId
                    oWebOrderMaster.BillSubCustomerID = oOM.BillSubCustomerId

                    oWebOrderDetails = New WebOrderDetails

                    For Each oOd As TIMSS.API.OrderInfo.IOrderDetail In oOM.Details
                        oWebOrderDetail = oWebOrderDetails.AddNewOrderDetail()
                        oWebOrderDetail.SubSystem = oOd.Subsystem
                        oWebOrderDetail.OrderNumber = oOd.OrderNumber
                        oWebOrderDetail.OrderLineNumber = oOd.OrderLineNumber
                        oWebOrderDetail.OrderLineStatusCode = oOd.LineStatusCode.Code
                        oWebOrderDetail.OrderLineStatusCodeDescr = oOd.LineStatusCode.Description
                        oWebOrderDetail.OrderLineTotal = oOd.ActualTotalAmount

                        oWebOrderDetail.OrderLineBalance = oOd.LineBalanceAmount
                        oWebOrderDetail.TotalLinePayments = oOd.LinePaymentsAmount
                        oWebOrderDetail.Description = oOd.Description
                        'Add additional Order Detail Properties
                        oWebOrderDetail.TrackingNumber = oOd.TrackingNumber
                        oWebOrderDetail.OrderDate = oOd.OrderDate
                        oWebOrderDetail.OrderQuantity = oOd.OrderQuantity
                        oWebOrderDetail.LineDescription = oOd.LineStatusCode.Description
                        oWebOrderDetail.CycleEndDate = oOd.CycleEndDate
                        oWebOrderDetail.CycleBeginDate = oOd.CycleBeginDate
                        oWebOrderDetail.ShipCustomer = oOd.ShipCustomer.LabelName
                        oWebOrderDetail.ShipAddress = oOd.ShipAddress.FormattedAddress
                        oWebOrderDetail.ShippingStatus = oOd.FulfillStatusCode.Description
                        oWebOrderDetail.Amount = oOd.ActualUnitPrice
                        oWebOrderDetail.Discount = oOd.ActualUnitDiscount
                        oWebOrderDetail.Tax = oOd.ActualTaxAmount
                        oWebOrderDetail.Shipping = oOd.ActualShipAmount
                        oWebOrderDetail.Paid = oOd.PaidAmount
                        oWebOrderDetail.Total = oOd.ActualTotalAmount
                        oWebOrderDetail.Product = oOd.ProductCode
                        oWebOrderDetail.ProductId = oOd.ProductId
                        If oOd.Product IsNot Nothing AndAlso oOd.Product.RateCodes IsNot Nothing AndAlso oOd.Product.RateCodes.Count > 0 Then
                            For j As Integer = 0 To oOd.Product.RateCodes.Count - 1
                                Dim currentRateCode As String = oOd.Product.RateCodes(j).RateCodeString
                                Dim currentRateStructureString As String = oOd.Product.RateCodes(j).RateStructureString
                                If currentRateCode.ToString = oOd.RateCodeString.ToString And currentRateStructureString = oOd.RateStructureString Then
                                    oWebOrderDetail.MaxBadges = oOd.Product.RateCodes(j).MaxBadges
                                    oWebOrderMaster.OrderMaxBadges += oWebOrderDetail.MaxBadges
                                End If
                            Next
                        End If

                        Try
                            oWebOrderDetail.MeetingLocation = oOd.Product.MeetingProduct.PrimaryLocation.Customer.PrimaryAddress.AddressLabel
                        Catch de As NullReferenceException
                            oWebOrderDetail.MeetingLocation = ""
                        End Try

                    Next
                    oWebOrderMaster.Details = oWebOrderDetails

                Next



                AddSessionObject(SessionKeys.PersonifyWebOrderMaster, oWebOrderMasters, appendToKey)
            End If


            Return oWebOrderMasters

        End Function

        Private Function GetMyOrderMasters(ByVal MasterCustomerId As String, ByVal SubcustomerId As Integer, ByVal mode As CustomerMode) As TIMSS.API.OrderInfo.IOrderMasters

            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters

            oOrderMasters = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderMasters")

            'added mode selection, filter accordingly
            Select Case mode
                Case CustomerMode.SHIP
                    oOrderMasters.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
                    oOrderMasters.Filter.Add("ShipSubCustomerId", SubcustomerId)
                Case CustomerMode.BILL
                    oOrderMasters.Filter.Add("BillMasterCustomerId", MasterCustomerId)
                    oOrderMasters.Filter.Add("BillSubCustomerId", SubcustomerId)
                Case CustomerMode.BOTH
                    'if both, first of all we get the shipto orders
                    'oOrderMasters.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
                    'oOrderMasters.Filter.Add("ShipSubCustomerId", SubCustomerId)
                    oOrderMasters.Filter.Add(New TIMSS.API.Core.FilterItem("((Ship_Master_Customer_Id =  '" + MasterCustomerId.ToString + "' ) and (Ship_Sub_Customer_Id = " + SubcustomerId.ToString + " )) or ((Bill_Master_Customer_Id =  '" + MasterCustomerId.ToString + "' ) and (Bill_Sub_Customer_Id = " + SubcustomerId.ToString + " ))"))
            End Select

            oOrderMasters.Filter.Add("CurrencyCode", PortalCurrency.Code)
            oOrderMasters.Fill()
            Return oOrderMasters

        End Function
#End Region

    End Class
    Public Class XSLorder
        Public order As WebOrderMaster
        Public pay As String
        'Public cancel As String
        Public OrderNo As String
        Public DateOrdered As String
        Public quantity As String
        Public status As String
        Public dates As String
        Public location As String
        Public shippedTo As String
        Public tracking As String
        Public shippingStatus As String
        Public amount As String
        Public discount As String
        Public tax As String
        Public shipping As String
        Public total As String
        Public paid As String
        Public balance As String
        Public orderBalance As String
        Public print As String
        Public cancelb As String
        Public payb As String
        Public tos As String
    End Class
    Public Class BodyMember
        Public bodymember As WebOrderMaster
        Public checked As String
    End Class
    Public Class XSLbodyMembers
        Public bodyMembers() As BodyMember
        Public quote As String
    End Class
    Public Class OrdersComparer
        Implements System.Collections.Generic.IComparer(Of WebOrderMaster)

        Private whatToCompare As String

        Public Sub New(ByVal what As String)
            whatToCompare = what
        End Sub


        Public Function Compare(ByVal x As WebOrderMaster, ByVal y As WebOrderMaster) As Integer Implements System.Collections.Generic.IComparer(Of WebOrderMaster).Compare

            Select Case whatToCompare
                'Case "numbers"
                '    Dim xo As String = x.OrderNumber
                '    Dim yo As String = y.OrderNumber
                '    Dim len As Integer = Math.Max(xo.Length, yo.Length)
                '    For i As Integer = xo.Length To len
                '        xo = "0" + xo
                '    Next
                '    For i As Integer = yo.Length To len
                '        yo = "0" + yo
                '    Next

                '    If xo > yo Then
                '        Return +1
                '    End If
                '    If xo < yo Then
                '        Return -1
                '    End If
                '    If xo = yo Then
                '        Return 0
                '    End If
                Case "date"
                    Return Date.Compare(x.OrderDate, y.OrderDate)
                Case "status"
                    Return String.Compare(x.OrderStatusCode, y.OrderStatusCode)
                Case "balance"
                    If CType(x.OrderBalance, Double) > CType(y.OrderBalance, Double) Then
                        Return +1
                    End If
                    If CType(x.OrderBalance, Double) < CType(y.OrderBalance, Double) Then
                        Return -1
                    End If
                    If CType(x.OrderBalance, Double) = CType(y.OrderBalance, Double) Then
                        Return 0
                    End If
                Case "amount"
                    If CType(x.OrderTotal, Double) > CType(y.OrderTotal, Double) Then
                        Return +1
                    End If
                    If CType(x.OrderTotal, Double) < CType(y.OrderTotal, Double) Then
                        Return -1
                    End If
                    If CType(x.OrderTotal, Double) = CType(y.OrderTotal, Double) Then
                        Return 0
                    End If
                Case Else
                    Dim xo As String = x.OrderNumber
                    Dim yo As String = y.OrderNumber
                    Dim len As Integer = Math.Max(xo.Length, yo.Length)
                    For i As Integer = xo.Length To len
                        xo = "0" + xo
                    Next
                    For i As Integer = yo.Length To len
                        yo = "0" + yo
                    Next

                    If xo > yo Then
                        Return +1
                    End If
                    If xo < yo Then
                        Return -1
                    End If
                    If xo = yo Then
                        Return 0
                    End If
            End Select
        End Function


    End Class
End Namespace

