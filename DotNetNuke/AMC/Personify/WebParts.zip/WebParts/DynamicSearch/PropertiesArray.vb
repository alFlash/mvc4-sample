Imports System.Collections

Namespace Personify.DNN.Modules.DynamicSearch

    <Serializable()> _
    Public Class PropertiesArray
        Public PropertyName As String
        Public Collection As String
        Public OperatorType As String
        Public RenderAs As String
        Public ShowInQuery As Boolean
        Public ShowInResults As Boolean

        Public DefaultValue As String
        Public Text As String
        Public Required As Boolean
        Public Value As String
        Public GetValueFromQueryString As Boolean
        Public DisplayOrderForSearch As Integer

        Public SortDirection As String
        Public SortOrder As Integer
        Public TextAlign As String
        Public ColumnWidth As Integer
        Public DisplayOrder As Integer

        Public IncludePropertyAsQueryStringParameter As Boolean
        Public QueryStringParameterName As String
        Public UseAsEmailAddress As Boolean
        Public PersonifyDynamicSearchSettingsID As Integer
    End Class

    Public Enum RenderAs
        TextBox = 0
        Combobox = 1
        RadioButtonList = 2
        DatePicker = 3
    End Enum

    Public Enum TextAlign
        Right = 0
        Left = 1
        Center = 2
    End Enum

    Public Class PropertiesArrayComparer
        Implements IComparer

        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer _
             Implements IComparer.Compare
            Dim xProp As PropertiesArray = CType(x, PropertiesArray)
            Dim yProp As PropertiesArray = CType(y, PropertiesArray)

            Return New CaseInsensitiveComparer().Compare(xProp.DisplayOrder, yProp.DisplayOrder)
        End Function
        
    End Class
    Public Class DisplayOrderForSearchComparer
        Implements IComparer

        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer _
             Implements IComparer.Compare
            Dim xProp As PropertiesArray = CType(x, PropertiesArray)
            Dim yProp As PropertiesArray = CType(y, PropertiesArray)

            Return New CaseInsensitiveComparer().Compare(xProp.DisplayOrderForSearch, yProp.DisplayOrderForSearch)
        End Function
    End Class

End Namespace

