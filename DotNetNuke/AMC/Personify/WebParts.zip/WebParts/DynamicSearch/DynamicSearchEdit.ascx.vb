Option Strict Off

Imports System
Imports System.Xml
Imports System.Xml.Schema
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data.SqlClient
Imports Personify.DNN.Modules.DynamicSearch.Business

Namespace Personify.DNN.Modules.DynamicSearch

    Public MustInherit Class DynamicSearchEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents lblError As Label

        Protected WithEvents lblDisplayResultsAsURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkDisplayResultsAsURL As CheckBox
        Protected WithEvents pnlDisplayResultsAsURL As Panel
        Protected WithEvents urlOnClickNavigatetoPage As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents lblAllowImpersonation As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkAllowImpersonation As CheckBox
        Protected WithEvents pnlAllowImpersonationActionURL As Panel
        Protected WithEvents urlAllowImpersonationActionURL As DotNetNuke.UI.UserControls.UrlControl


        Protected WithEvents lblAutomaticSearchEnabled As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkAutomaticSearchEnabled As CheckBox
        Protected WithEvents pnlHideSearchParameterSection As Panel
        Protected WithEvents lblHideSearchParameterSection As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkHideSearchParameterSection As CheckBox


        Protected WithEvents lblSearchCaption As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents txtSearchCaption As TextBox
        Protected WithEvents lblEnforceLimits As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkEnforceLimits As CheckBox

        Protected WithEvents lblMaxRows As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents txtMaxRows As TextBox
        Protected WithEvents publishDrop As DropDownList



        'Protected WithEvents lblErrorCountLimit As DotNetNuke.UI.UserControls.LabelControl
        'Protected WithEvents txtErrorCountLimit As TextBox
        'Protected WithEvents lblWarningCountLimit As DotNetNuke.UI.UserControls.LabelControl
        'Protected WithEvents txtWarningCountLimit As TextBox

        Protected WithEvents lblSendEmailEnabled As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkSendEmailEnabled As CheckBox
        Protected WithEvents pnlSendEmailActionURL As Panel
        Protected WithEvents urlSendEmailActionURL As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents cboTemplate As WebControls.WebPartTemplateDropDownList

        Protected WithEvents lblPageSize As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpPageSize As DropDownList

        Protected WithEvents lblNamespace As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpNamespaces As DropDownList

        Protected WithEvents lblTargetCollection As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpTargetCollections As DropDownList

        Protected WithEvents btnReset As Button

        Protected WithEvents lblSelectedCollection As Label
        Protected WithEvents lstAvailableProperties As ListBox

        Protected WithEvents btnAddProperty As LinkButton

        Protected WithEvents dlProperties As DataList
        Protected WithEvents publishButton As Button

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdPublish As System.Web.UI.WebControls.LinkButton


        'Vcard
        Protected WithEvents chkVcard As CheckBox
        Protected WithEvents PanelVcardURL As Panel
        Protected WithEvents UrlVcardPage As DotNetNuke.UI.UserControls.UrlControl

        'Export
        Protected WithEvents rblExportOption As RadioButtonList


#End Region
#Region "Properties"
        
        Public Property SelectedCollection() As String
            Get
                Dim o As Object = Me.ViewState("_SelectedCollection")
                Return CType(o, String)

            End Get
            Set(ByVal Value As String)
                Me.ViewState("_SelectedCollection") = Value
            End Set
        End Property

        Public Property ErrorMessage() As String
            Get
                Dim o As Object = Me.ViewState("_ErrorMessage")
                If o IsNot Nothing Then
                    Return CType(o, String)
                Else
                    Return String.Empty
                End If
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_ErrorMessage") = Value
            End Set
        End Property
        Public Property Properties() As ArrayList
            Get
                Return CType(Me.ViewState("_SelectedProperties"), ArrayList)
            End Get
            Set(ByVal Value As ArrayList)
                Me.ViewState("_SelectedProperties") = Value
            End Set
        End Property
        
#End Region
#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                lblError.Text = ""
                Dim resetMessage As String = Localization.GetString("ResetMessage", LocalResourceFile)
                btnReset.Attributes.Add("onclick", "return confirm('" & resetMessage & "');")
                If Not Page.IsPostBack Then
                    If Properties Is Nothing Then
                        Properties = New ArrayList
                    End If
                End If
                Dim publishPath As String
                Dim dir As System.IO.DirectoryInfo
                publishPath = System.AppDomain.CurrentDomain.BaseDirectory() + "PublishedPersonifySearches/"

                dir = New System.IO.DirectoryInfo(publishPath)
                If (Not dir.Exists) Then
                    dir.Create()
                End If
                Dim aryFi As IO.FileInfo() = dir.GetFiles("*.xml")
                Dim fi As IO.FileInfo
                Dim defaultitem As New ListItem
                defaultitem.Text = Localization.GetString("ChoosFileMsg", LocalResourceFile)
                defaultitem.Value = ""
                publishDrop.Items.Add(defaultitem)
                For Each fi In aryFi
                    Dim listitem As New ListItem
                    listitem.Text = fi.Name
                    listitem.Value = fi.FullName
                    publishDrop.Items.Add(listitem)
                Next

                If Page.IsPostBack Then
                    '3246-5948308 
                    'If Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").IndexOf("btnReset") >= 0 Then
                    Dim reset As Boolean = False
                    For Each key As String In Request.Params.AllKeys
                        If key.IndexOf("btnReset") >= 0 Then
                            reset = True
                            Exit For
                        End If
                    Next
                    If reset Then
                        Dim LocalConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

                        Dim sqlParamArray(1) As SqlParameter
                        sqlParamArray(0) = New SqlParameter("@ModuleId", SqlDbType.Int)
                        sqlParamArray(0).Value = ModuleId.ToString

                        Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "DeletePersonifyDynamicSearchSettings", sqlParamArray(0))

                        Properties.Clear()
                        dlProperties.DataSource = Properties
                        dlProperties.DataBind()
                    End If
                    
                    'End If
                    'end 3246-5948308 
                    If Request.Params("lstAvailablePropertiesHidden") IsNot Nothing AndAlso Request.Params("lstAvailablePropertiesHidden") = "doubleclicked" Then
                        ' was double click on lstAvailableProperties                        
                        Dim selectedProperty As String = lstAvailableProperties.SelectedItem.Text
                        If selectedProperty.IndexOf("..") > 1 Then
                            selectedProperty = selectedProperty.Substring(0, selectedProperty.Length - 2)
                            SelectedCollection = SelectedCollection & "." & selectedProperty
                            With lstAvailableProperties
                                .Items.Clear()
                                .DataSource = GetPropertiesDepth(drpNamespaces.SelectedValue, SelectedCollection, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                                .DataBind()
                                Dim oListItem As New System.Web.UI.WebControls.ListItem
                                oListItem.Text = ".."
                                oListItem.Value = "-1"
                                .Items.Insert(0, oListItem)
                            End With
                        ElseIf selectedProperty.IndexOf("..") = 0 Then
                            If SelectedCollection.LastIndexOf(".") > 0 Then
                                SelectedCollection = SelectedCollection.Substring(0, SelectedCollection.LastIndexOf("."))
                                With lstAvailableProperties
                                    .Items.Clear()
                                    .DataSource = GetPropertiesDepth(drpNamespaces.SelectedValue, SelectedCollection, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                                    .DataBind()
                                    Dim oListItem As New System.Web.UI.WebControls.ListItem
                                    oListItem.Text = ".."
                                    oListItem.Value = "-1"
                                    .Items.Insert(0, oListItem)
                                End With
                            End If
                        End If
                    Else
                    End If

                Else

                    With drpNamespaces
                        .DataSource = GetNamespaces()
                        .DataBind()
                    End With
                    With drpTargetCollections
                        .DataSource = GetCollections(drpNamespaces.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                        .DataBind()
                    End With
                    With lstAvailableProperties
                        .Items.Clear()
                        .DataSource = GetPropertiesDepth(drpNamespaces.SelectedValue, drpTargetCollections.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                        .DataBind()
                        Dim oListItem As New System.Web.UI.WebControls.ListItem
                        oListItem.Text = ".."
                        oListItem.Value = "-1"
                        .Items.Insert(0, oListItem)
                    End With
                    LoadSettings()
                    If SelectedCollection = String.Empty Then
                        SelectedCollection = drpTargetCollections.SelectedValue
                    End If
                End If

                lblSelectedCollection.Text = SelectedCollection
                If Properties.Count > 0 Then 'Or (Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").IndexOf("btnAddProperty") >= 0) Then
                    drpNamespaces.Enabled = False
                    drpTargetCollections.Enabled = False
                Else
                    drpNamespaces.Enabled = True
                    drpTargetCollections.Enabled = True
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub cmdPublish_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdPublish.Click
            If Page.IsValid Then
                Try
                    If PublishSettings() Then
                        Response.Redirect(NavigateURL(), True)
                    End If

                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            If Page.IsValid Then
                Try
                    If UpdateSettings() Then
                        Response.Redirect(NavigateURL(), True)
                    End If

                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub

        Private Sub btnReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReset.Click
            If Page.IsValid Then
                Try                   
                    drpNamespaces.Enabled = True
                    drpTargetCollections.Enabled = True
                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub

        Private Sub btnAddProperty_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddProperty.Click
            Try
                If lstAvailableProperties.SelectedIndex = -1 Then
                    ErrorMessage = Localization.GetString("NoPropertyError", LocalResourceFile)
                    lblError.Text = ErrorMessage
                ElseIf lstAvailableProperties.SelectedIndex = 0 Then
                    ErrorMessage = Localization.GetString("RootPropertyError", LocalResourceFile)
                    lblError.Text = ErrorMessage
                ElseIf lstAvailableProperties.SelectedValue.IndexOf("..") >= 0 Then
                    ErrorMessage = Localization.GetString("CollectionTypePropertyError", LocalResourceFile).Replace("%s", lstAvailableProperties.SelectedValue.Replace("..", ""))
                    lblError.Text = ErrorMessage
                Else
                    If Properties.Contains(lstAvailableProperties.SelectedValue) Then 'AndAlso CType(Properties(lstAvailableProperties.SelectedValue), PropertiesArray).Collection = (drpNamespaces.SelectedValue & "." & SelectedCollection) Then
                        ErrorMessage = Localization.GetString("DuplicatePropertyError", LocalResourceFile).Replace("%s", lstAvailableProperties.SelectedValue.Replace("..", ""))
                        lblError.Text = ErrorMessage
                    Else
                        Dim p As PropertiesArray
                        p = New PropertiesArray
                        p.Collection = drpNamespaces.SelectedValue & "." & SelectedCollection
                        p.PropertyName = lstAvailableProperties.SelectedValue
                        p.OperatorType = "Equals"
                        p.RenderAs = "-"
                        p.Required = True
                        p.ShowInQuery = True
                        p.ShowInResults = True
                        p.DisplayOrder = 0
                        p.DisplayOrderForSearch = 0
                        p.SortDirection = "Ascending"
                        p.IncludePropertyAsQueryStringParameter = False
                        p.QueryStringParameterName = "-"
                        Dim schemaInfo As SchemaInfo = GetSchemaInfo(p.Collection, p.PropertyName)
                        p.RenderAs = schemaInfo.Control
                        p.Text = schemaInfo.Caption
                        Select Case schemaInfo.DataType
                            Case "string"
                                p.TextAlign = "Left"
                            Case "numeric"
                                p.TextAlign = "Right"
                        End Select


                        Properties.Add(p)

                        dlProperties.DataSource = Properties
                        dlProperties.DataBind()

                        drpNamespaces.Enabled = False
                        drpTargetCollections.Enabled = False
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub cmdPublishBtn_Click(ByVal sender As Object, ByVal e As EventArgs) Handles publishButton.Click
            Try
                Dim filename As String = publishDrop.SelectedValue
                Dim objModules As New Entities.Modules.ModuleController
                If filename = "" Then
                    ErrorMessage = Localization.GetString("NoFileError", LocalResourceFile)
                    lblError.Text = ErrorMessage
                Else
                    Dim SettingsDoc As New XmlDocument()
                    Dim TempNode As XmlElement
                    Dim TempNode1 As XmlElement
                    Dim x As Integer
                    Dim y As Integer
                    Dim publishPath As String = System.AppDomain.CurrentDomain.BaseDirectory() + "PublishedPersonifySearches/"
                    SettingsDoc.Load(filename)
                    Dim DocRoot As XmlElement = SettingsDoc.DocumentElement

                    'delete DB settings
                    Dim LocalConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
                    Dim sqlParamArray(1) As SqlParameter
                    sqlParamArray(0) = New SqlParameter("@ModuleId", SqlDbType.Int)
                    sqlParamArray(0).Value = ModuleId.ToString
                    Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "DeletePersonifyDynamicSearchSettings", sqlParamArray(0))


                    For x = 0 To DocRoot.ChildNodes.Count - 1

                        TempNode = CType(DocRoot.ChildNodes(x), XmlElement)
                        If Not TempNode.HasChildNodes Then
                            'Normal settings
                            If Not TempNode.GetAttribute("value") = "NULL" Then
                                objModules.UpdateModuleSetting(Me.ModuleId, TempNode.Name, TempNode.GetAttribute("value"))
                            Else
                                objModules.DeleteModuleSetting(Me.ModuleId, TempNode.Name)
                            End If
                        Else
                            'DB settings
                            Dim sqlParamArr(20) As SqlParameter
                            sqlParamArr(0) = New SqlParameter("@ModuleId", SqlDbType.Int)
                            sqlParamArr(0).Value = ModuleId.ToString
                            sqlParamArr(1) = New SqlParameter("@PropertyName", SqlDbType.NVarChar, 256)
                            sqlParamArr(1).Value = TempNode.Name
                            For y = 0 To TempNode.ChildNodes.Count - 1
                                TempNode1 = CType(TempNode.ChildNodes(y), XmlElement)
                                
                                If TempNode1.Name = "Collection" Then
                                    sqlParamArr(2) = New SqlParameter("@Collection", SqlDbType.NVarChar, 256)
                                    sqlParamArr(2).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "ColumnWidth" Then
                                    sqlParamArr(3) = New SqlParameter("@ColumnWidth", SqlDbType.NVarChar, 256)
                                    sqlParamArr(3).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "DefaultValue" Then
                                    sqlParamArr(4) = New SqlParameter("@DefaultValue", SqlDbType.NVarChar, 256)
                                    sqlParamArr(4).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "OperatorType" Then
                                    sqlParamArr(5) = New SqlParameter("@OperatorType", SqlDbType.NVarChar, 256)
                                    sqlParamArr(5).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "RenderAs" Then
                                    sqlParamArr(6) = New SqlParameter("@RenderAs", SqlDbType.NVarChar, 256)
                                    sqlParamArr(6).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "Required" Then
                                    sqlParamArr(7) = New SqlParameter("@Required", SqlDbType.NVarChar, 256)
                                    sqlParamArr(7).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "ShowInQuery" Then
                                    sqlParamArr(8) = New SqlParameter("@ShowInQuery", SqlDbType.NVarChar, 256)
                                    sqlParamArr(8).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "ShowInResults" Then
                                    sqlParamArr(9) = New SqlParameter("@ShowInResults", SqlDbType.NVarChar, 256)
                                    sqlParamArr(9).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "SortDirection" Then
                                    sqlParamArr(10) = New SqlParameter("@SortDirection", SqlDbType.NVarChar, 256)
                                    sqlParamArr(10).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "SortOrder" Then
                                    sqlParamArr(11) = New SqlParameter("@SortOrder", SqlDbType.NVarChar, 256)
                                    sqlParamArr(11).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "Text" Then
                                    sqlParamArr(12) = New SqlParameter("@Text", SqlDbType.NVarChar, 256)
                                    sqlParamArr(12).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "TextAlign" Then
                                    sqlParamArr(13) = New SqlParameter("@TextAlign", SqlDbType.NVarChar, 256)
                                    sqlParamArr(13).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "Value" Then
                                    sqlParamArr(14) = New SqlParameter("@Value", SqlDbType.NVarChar, 256)
                                    sqlParamArr(14).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "DisplayOrder" Then
                                    sqlParamArr(15) = New SqlParameter("@DisplayOrder", SqlDbType.NVarChar, 256)
                                    sqlParamArr(15).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "IncludePropertyAsQueryStringParameter" Then
                                    sqlParamArr(16) = New SqlParameter("@IncludePropertyAsQueryStringParameter", SqlDbType.NVarChar, 256)
                                    sqlParamArr(16).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "QueryStringParameterName" Then
                                    sqlParamArr(17) = New SqlParameter("@QueryStringParameterName", SqlDbType.NVarChar, 256)
                                    sqlParamArr(17).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "UseAsEmailAddress" Then
                                    sqlParamArr(18) = New SqlParameter("@UseAsEmailAddress", SqlDbType.NVarChar, 256)
                                    sqlParamArr(18).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "GetValueFromQueryString" Then
                                    sqlParamArr(19) = New SqlParameter("@GetValueFromQueryString", SqlDbType.NVarChar, 256)
                                    sqlParamArr(19).Value = TempNode1.GetAttribute("value")
                                End If
                                If TempNode1.Name = "DisplayOrderForSearch" Then
                                    sqlParamArr(20) = New SqlParameter("@DisplayOrderForSearch", SqlDbType.NVarChar, 256)
                                    sqlParamArr(20).Value = TempNode1.GetAttribute("value")
                                End If


                            Next
                            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "AddPersonifyDynamicSearchSettings", sqlParamArr(0), _
sqlParamArr(1), sqlParamArr(2), sqlParamArr(3), sqlParamArr(4), sqlParamArr(5), sqlParamArr(6), sqlParamArr(7), sqlParamArr(8), sqlParamArr(9), sqlParamArr(10), sqlParamArr(11), sqlParamArr(12), sqlParamArr(13), sqlParamArr(14), sqlParamArr(15), sqlParamArr(16), sqlParamArr(17), sqlParamArr(18), sqlParamArr(19), sqlParamArr(20))
                            'test
                        End If



                    Next
                End If
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        '3246-5747347
        Private Sub chkAllowImpersonation_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAllowImpersonation.CheckedChanged
            If chkAllowImpersonation.Checked Then
                pnlAllowImpersonationActionURL.Visible = True
            Else
                pnlAllowImpersonationActionURL.Visible = False
            End If
        End Sub

        Private Sub chkDisplayResultsAsURL_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDisplayResultsAsURL.CheckedChanged
            If chkDisplayResultsAsURL.Checked Then
                pnlDisplayResultsAsURL.Visible = True                
            Else
                pnlDisplayResultsAsURL.Visible = False
            End If
        End Sub

        Private Sub chkVcard_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkVcard.CheckedChanged

            If chkVcard.Checked Then
                Me.PanelVcardURL.Visible = True
            Else
                PanelVcardURL.Visible = False
            End If
        End Sub

        Private Sub chkSendEmailEnabled_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSendEmailEnabled.CheckedChanged
            If chkSendEmailEnabled.Checked Then
                pnlSendEmailActionURL.Visible = True
            Else
                pnlSendEmailActionURL.Visible = False
            End If
        End Sub

        Private Sub chkAutomaticSearchEnabled_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAutomaticSearchEnabled.CheckedChanged
            If chkAutomaticSearchEnabled.Checked Then
                pnlHideSearchParameterSection.Visible = True
            Else
                'START 3246-5759921 - hide search Parameter section shouldn't be disabled
                pnlHideSearchParameterSection.Visible = False
                chkHideSearchParameterSection.Checked = False
                'EMD 3246-5759921 - hide search Parameter section shouldn't be disabled
            End If
        End Sub

        Private Sub drpTargetCollections_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles drpTargetCollections.SelectedIndexChanged
            lblSelectedCollection.Text = drpTargetCollections.SelectedValue
            With lstAvailableProperties
                .Items.Clear()
                .DataSource = GetPropertiesDepth(drpNamespaces.SelectedValue, drpTargetCollections.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                .DataBind()
                Dim oListItem As New System.Web.UI.WebControls.ListItem
                oListItem.Text = ".."
                oListItem.Value = "-1"
                .Items.Insert(0, oListItem)
            End With
            SelectedCollection = drpTargetCollections.SelectedValue
        End Sub


        Private Sub drpNamespaces_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles drpNamespaces.SelectedIndexChanged
            
            With Me.drpTargetCollections
                .DataSource = GetCollections(drpNamespaces.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                .DataBind()
            End With
            lblSelectedCollection.Text = drpTargetCollections.SelectedValue
            With lstAvailableProperties
                .Items.Clear()
                .DataSource = GetPropertiesDepth(drpNamespaces.SelectedValue, drpTargetCollections.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                .DataBind()
                Dim oListItem As New System.Web.UI.WebControls.ListItem
                oListItem.Text = ".."
                oListItem.Value = "-1"
                .Items.Insert(0, oListItem)
            End With
            SelectedCollection = drpTargetCollections.SelectedValue
        End Sub

        
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Helper Functions"
        Private Sub LoadSettings()

            If Settings("DisplayResultsAsURL") IsNot Nothing Then
                If CStr(Settings("DisplayResultsAsURL")) = "Y" Then
                    chkDisplayResultsAsURL.Checked = True
                    pnlDisplayResultsAsURL.Visible = True
                    If Settings("OnClickNavigatetoPage") IsNot Nothing Then
                        If CStr(Settings("OnClickNavigatetoPage")) <> String.Empty Then
                            urlOnClickNavigatetoPage.Url = CStr(Settings("OnClickNavigatetoPage"))
                       End If
                   End If
                Else
                    chkDisplayResultsAsURL.Checked = False
                    pnlDisplayResultsAsURL.Visible = False
                End If
            Else
                chkDisplayResultsAsURL.Checked = False
                pnlDisplayResultsAsURL.Visible = False
            End If

            '3246-5747347
            If Settings("AllowImpersonation") IsNot Nothing Then
                If CStr(Settings("AllowImpersonation")) = "Y" Then
                    chkAllowImpersonation.Checked = True
                    pnlAllowImpersonationActionURL.Visible = True
                    If Settings("AllowImpersonationActionURL") IsNot Nothing Then
                        If CStr(Settings("AllowImpersonationActionURL")) <> String.Empty Then
                            urlAllowImpersonationActionURL.Url = CStr(Settings("AllowImpersonationActionURL"))
                        End If
                    End If
                Else
                    chkAllowImpersonation.Checked = False
                    pnlAllowImpersonationActionURL.Visible = False
                End If
            Else
                chkAllowImpersonation.Checked = False
                pnlAllowImpersonationActionURL.Visible = False
            End If

            If Settings("ShowVcardURL") IsNot Nothing Then
                If CStr(Settings("ShowVcardURL")) = "Y" Then
                    chkVcard.Checked = True
                    PanelVcardURL.Visible = True
                    If Settings("VcardURLValue") IsNot Nothing Then
                        If CStr(Settings("VcardURLValue")) <> String.Empty Then
                            UrlVcardPage.Url = CStr(Settings("VcardURLValue"))
                        End If
                    End If
                Else
                    chkVcard.Checked = False
                    PanelVcardURL.Visible = False
                End If
            Else
                chkVcard.Checked = False
                PanelVcardURL.Visible = False
            End If



            If Settings("AutomaticSearchEnabled") IsNot Nothing Then
                If CStr(Settings("AutomaticSearchEnabled")) = "Y" Then
                    chkAutomaticSearchEnabled.Checked = True
                    pnlHideSearchParameterSection.Visible = True
                    If Settings("HideSearchParameterSection") IsNot Nothing Then
                        If CStr(Settings("HideSearchParameterSection")) = "Y" Then
                            chkHideSearchParameterSection.Checked = True
                        Else
                            chkHideSearchParameterSection.Checked = False
                        End If
                    Else
                        chkHideSearchParameterSection.Checked = False
                    End If
                Else
                    chkAutomaticSearchEnabled.Checked = False
                    pnlHideSearchParameterSection.Visible = False
                End If
            Else
                chkAutomaticSearchEnabled.Checked = False
                pnlHideSearchParameterSection.Visible = False
            End If
            txtSearchCaption.Text = CStr(Settings("SearchCaption"))
            txtMaxRows.Text = CStr(Settings("MaxRows"))
            'txtErrorCountLimit.Text = CStr(Settings("ErrorCountLimit"))
            'txtWarningCountLimit.Text = CStr(Settings("WarningCountLimit"))
            If Settings("EnforceLimits") IsNot Nothing Then
                chkEnforceLimits.Checked = CBool(IIf(CStr(Settings("EnforceLimits")) = "Y", True, False))
            End If
            
            If Settings("SendEmailEnabled") IsNot Nothing Then
                chkSendEmailEnabled.Checked = CBool(IIf(CStr(Settings("SendEmailEnabled")) = "Y", True, False))
                If CStr(Settings("SendEmailEnabled")) = "Y" Then
                    If Settings("SendEmailActionURL") IsNot Nothing Then
                        urlSendEmailActionURL.Url = CStr(Settings("SendEmailActionURL"))
                    End If
                    pnlSendEmailActionURL.Visible = True
                Else
                    pnlSendEmailActionURL.Visible = False
                End If
            Else
                chkSendEmailEnabled.Checked = False
                pnlSendEmailActionURL.Visible = False
            End If


            If Settings("PageSize") IsNot Nothing Then
                drpPageSize.SelectedValue = CStr(Settings("PageSize"))
            End If

            'Export
            If Settings("Export") IsNot Nothing Then
                Me.rblExportOption.SelectedValue = CStr(Settings("Export"))
            End If

            'Template
            cboTemplate.WebPartTemplateFolder = ModulePath
            If (Not (CType(Settings("Template"), String)) Is Nothing) Then
                cboTemplate.DefaultValue = CType(Settings("Template"), String)
            Else
                cboTemplate.SelectedIndex = 0
            End If

            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifyDynamicSearchSettings", ModuleId), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    Dim p As PropertiesArray
                    p = New PropertiesArray
                    p.PropertyName = CStr(oSiteData.Item("PropertyName"))
                    p.Collection = CStr(oSiteData.Item("Collection"))
                    p.ColumnWidth = CType(oSiteData.Item("ColumnWidth"), Integer)
                    p.DefaultValue = CStr(oSiteData.Item("DefaultValue"))
                    p.OperatorType = CStr(oSiteData.Item("OperatorType"))
                    p.RenderAs = CStr(oSiteData.Item("RenderAs"))
                    p.Required = CBool(oSiteData.Item("Required"))
                    p.ShowInQuery = CBool(oSiteData.Item("ShowInQuery"))
                    p.ShowInResults = CBool(oSiteData.Item("ShowInResults"))
                    p.SortDirection = CStr(oSiteData.Item("SortDirection"))
                    p.SortOrder = CInt(oSiteData.Item("SortOrder"))
                    p.Text = CStr(oSiteData.Item("Text"))
                    p.TextAlign = CStr(oSiteData.Item("TextAlign"))
                    p.Value = CStr(oSiteData.Item("Value"))
                    p.GetValueFromQueryString = CBool(oSiteData.Item("GetValueFromQueryString"))
                    p.DisplayOrderForSearch = CInt(oSiteData.Item("DisplayOrderForSearch"))
                    p.DisplayOrder = CInt(CStr(oSiteData.Item("DisplayOrder")))
                    p.IncludePropertyAsQueryStringParameter = CBool(oSiteData.Item("IncludePropertyAsQueryStringParameter"))
                    p.QueryStringParameterName = CStr(oSiteData.Item("QueryStringParameterName"))
                    p.UseAsEmailAddress = CBool(oSiteData.Item("UseAsEmailAddress"))

                    Properties.Add(p)

                End While
            End If
            oSiteData.Close()
            oSiteData = Nothing


            drpNamespaces.SelectedValue = CStr(Settings("Namespace"))
            With Me.drpTargetCollections
                .DataSource = GetCollections(drpNamespaces.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                .DataBind()
            End With

            drpTargetCollections.SelectedValue = CStr(Settings("Collection"))
            SelectedCollection = drpTargetCollections.SelectedValue
            'lblSelectedCollection.Text = SelectedCollection
            With lstAvailableProperties
                .Items.Clear()
                .DataSource = GetPropertiesDepth(drpNamespaces.SelectedValue, drpTargetCollections.SelectedValue, GetType(TIMSS.API.Core.IBusinessObjectCollection))
                .DataBind()
                Dim oListItem As New System.Web.UI.WebControls.ListItem
                oListItem.Text = ".."
                oListItem.Value = "-1"
                .Items.Insert(0, oListItem)
            End With

            dlProperties.DataSource = Properties
            dlProperties.DataBind()


        End Sub
        Private Function ValidateProperties() As Boolean

            'Dim pItem As DictionaryEntry
            For Each pItem As PropertiesArray In Properties
                Dim propertyItem As PropertiesArray
                propertyItem = pItem

                If propertyItem.Text = String.Empty Then
                    ErrorMessage = Localization.GetString("MissingTextPropertyError", LocalResourceFile).Replace("%s", propertyItem.PropertyName)
                    Return False
                End If
            Next

            Return True
        End Function
        Private Function PublishSettings() As Boolean
            Dim Doc As New XmlDocument()
            Dim newAtt As XmlAttribute
            Dim TempNode As XmlElement

            If String.IsNullOrEmpty(Settings("SearchCaption")) Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                Return False
            Else
                Dim dec As XmlDeclaration = Doc.CreateXmlDeclaration("1.0", _
                                                 Nothing, Nothing)
                Doc.AppendChild(dec)
                Dim DocRoot As XmlElement = Doc.CreateElement("Settings")
                Doc.AppendChild(DocRoot)

                Dim Node_DisplayResultsAsURL As XmlNode = Doc.CreateElement("DisplayResultsAsURL")
                newAtt = Doc.CreateAttribute("value")
                If Settings("DisplayResultsAsURL") IsNot Nothing Then
                    newAtt.Value = Settings("DisplayResultsAsURL").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_DisplayResultsAsURL.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_DisplayResultsAsURL)

                '3246-5747347
                Dim Node_AllowImpersonation As XmlNode = Doc.CreateElement("AllowImpersonation")
                newAtt = Doc.CreateAttribute("value")
                If Settings("AllowImpersonation") IsNot Nothing Then
                    newAtt.Value = Settings("AllowImpersonation").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_AllowImpersonation.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_AllowImpersonation)

                Dim Node_AllowImpersonationActionURL As XmlNode = Doc.CreateElement("AllowImpersonationActionURL")
                newAtt = Doc.CreateAttribute("value")
                If Settings("AllowImpersonationActionURL") IsNot Nothing Then
                    newAtt.Value = Settings("AllowImpersonationActionURL").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_AllowImpersonationActionURL.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_AllowImpersonationActionURL)

                Dim Node_OnClickNavigatetoPage As XmlNode = Doc.CreateElement("OnClickNavigatetoPage")
                newAtt = Doc.CreateAttribute("value")
                If Settings("OnClickNavigatetoPage") IsNot Nothing Then
                    newAtt.Value = Settings("OnClickNavigatetoPage").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_OnClickNavigatetoPage.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_OnClickNavigatetoPage)

                Dim Node_AutomaticSearchEnabled As XmlNode = Doc.CreateElement("AutomaticSearchEnabled")
                newAtt = Doc.CreateAttribute("value")
                If Settings("AutomaticSearchEnabled") IsNot Nothing Then
                    newAtt.Value = Settings("AutomaticSearchEnabled").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_AutomaticSearchEnabled.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_AutomaticSearchEnabled)

                Dim Node_HideSearchParameterSection As XmlNode = Doc.CreateElement("HideSearchParameterSection")
                newAtt = Doc.CreateAttribute("value")
                If Settings("HideSearchParameterSection") IsNot Nothing Then
                    newAtt.Value = Settings("HideSearchParameterSection").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_HideSearchParameterSection.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_HideSearchParameterSection)

                Dim Node_SearchCaption As XmlNode = Doc.CreateElement("SearchCaption")
                newAtt = Doc.CreateAttribute("value")
                If Settings("SearchCaption") IsNot Nothing Then
                    newAtt.Value = Settings("SearchCaption").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_SearchCaption.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_SearchCaption)

                Dim Node_EnforceLimits As XmlNode = Doc.CreateElement("EnforceLimits")
                newAtt = Doc.CreateAttribute("value")
                If Settings("EnforceLimits") IsNot Nothing Then
                    newAtt.Value = Settings("EnforceLimits").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_EnforceLimits.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_EnforceLimits)

                Dim Node_MaxRows As XmlNode = Doc.CreateElement("MaxRows")
                newAtt = Doc.CreateAttribute("value")
                If Settings("MaxRows") IsNot Nothing Then
                    newAtt.Value = Settings("MaxRows").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_MaxRows.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_MaxRows)

                Dim Node_SendEmailEnabled As XmlNode = Doc.CreateElement("SendEmailEnabled")
                newAtt = Doc.CreateAttribute("value")
                If Settings("SendEmailEnabled") IsNot Nothing Then
                    newAtt.Value = Settings("SendEmailEnabled").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_SendEmailEnabled.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_SendEmailEnabled)

                Dim Node_SendEmailActionURL As XmlNode = Doc.CreateElement("SendEmailActionURL")
                newAtt = Doc.CreateAttribute("value")
                If Settings("SendEmailActionURL") IsNot Nothing Then
                    newAtt.Value = Settings("SendEmailActionURL").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_SendEmailActionURL.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_SendEmailActionURL)

                Dim Node_PageSize As XmlNode = Doc.CreateElement("PageSize")
                newAtt = Doc.CreateAttribute("value")
                If Settings("PageSize") IsNot Nothing Then
                    newAtt.Value = Settings("PageSize").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_PageSize.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_PageSize)

                Dim Node_Namespace As XmlNode = Doc.CreateElement("Namespace")
                newAtt = Doc.CreateAttribute("value")
                If Settings("Namespace") IsNot Nothing Then
                    newAtt.Value = Settings("Namespace").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_Namespace.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_Namespace)

                Dim Node_Collection As XmlNode = Doc.CreateElement("Collection")
                newAtt = Doc.CreateAttribute("value")
                If Settings("Collection") IsNot Nothing Then
                    newAtt.Value = Settings("Collection").ToString
                Else
                    newAtt.Value = "NULL"
                End If
                Node_Collection.Attributes.Append(newAtt)
                DocRoot.AppendChild(Node_Collection)

                'DB settings -----------------------------------------------

                Dim DocRootDB As XmlElement
                Dim oSiteDataObj As System.Data.SqlClient.SqlDataReader
                Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
                oSiteDataObj = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifyDynamicSearchSettings", ModuleId), System.Data.SqlClient.SqlDataReader)

                If oSiteDataObj.HasRows Then
                    While oSiteDataObj.Read
                        DocRootDB = Doc.CreateElement(CStr(oSiteDataObj.Item("PropertyName")))
                        DocRoot.AppendChild(DocRootDB)
                        Dim Node_DB As XmlNode

                        Node_DB = Doc.CreateElement("Collection")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("Collection"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("ColumnWidth")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("ColumnWidth"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("DefaultValue")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("DefaultValue"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("OperatorType")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("OperatorType"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("RenderAs")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("RenderAs"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("Required")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("Required"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("ShowInQuery")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("ShowInQuery"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("ShowInResults")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("ShowInResults"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("SortDirection")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("SortDirection"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("SortOrder")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("SortOrder"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("Text")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("Text"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("TextAlign")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("TextAlign"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("Value")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("Value"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("GetValueFromQueryString")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("GetValueFromQueryString"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("DisplayOrderForSearch")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("DisplayOrderForSearch"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("DisplayOrder")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("DisplayOrder"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("IncludePropertyAsQueryStringParameter")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("IncludePropertyAsQueryStringParameter"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("QueryStringParameterName")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("QueryStringParameterName"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                        Node_DB = Doc.CreateElement("UseAsEmailAddress")
                        newAtt = Doc.CreateAttribute("value")
                        newAtt.Value = CStr(oSiteDataObj.Item("UseAsEmailAddress"))
                        Node_DB.Attributes.Append(newAtt)
                        DocRootDB.AppendChild(Node_DB)

                    End While
                End If
                oSiteDataObj.Close()
                oSiteDataObj = Nothing


                Dim savepath As String
                Dim di As System.IO.DirectoryInfo
                savepath = System.AppDomain.CurrentDomain.BaseDirectory() + "PublishedPersonifySearches/"
                di = New System.IO.DirectoryInfo(savepath)

                If (Not di.Exists) Then
                    di.Create()
                End If
                Doc.Save(savepath + Settings("SearchCaption").ToString + ".xml")
                Return True
            End If
        End Function

        Private Function UpdateSettings() As Boolean
            Dim objModules As New Entities.Modules.ModuleController
            Dim propertiesNames As String = String.Empty
            'Dim pItem As DictionaryEntry

            If ValidateProperties() Then
                UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)


                Dim LocalConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

                Dim sqlParamArray(1) As SqlParameter
                sqlParamArray(0) = New SqlParameter("@ModuleId", SqlDbType.Int)
                sqlParamArray(0).Value = ModuleId.ToString

                Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "DeletePersonifyDynamicSearchSettings", sqlParamArray(0))

                For Each pItem As PropertiesArray In Properties
                    Dim propertyItem As PropertiesArray
                    propertyItem = pItem

                    Dim sqlParamArr(20) As SqlParameter
                    sqlParamArr(0) = New SqlParameter("@ModuleId", SqlDbType.Int)
                    sqlParamArr(0).Value = ModuleId.ToString
                    sqlParamArr(1) = New SqlParameter("@PropertyName", SqlDbType.NVarChar, 256)
                    sqlParamArr(1).Value = propertyItem.PropertyName
                    sqlParamArr(2) = New SqlParameter("@Collection", SqlDbType.NVarChar, 256)
                    sqlParamArr(2).Value = propertyItem.Collection
                    sqlParamArr(3) = New SqlParameter("@ColumnWidth", SqlDbType.Int)
                    sqlParamArr(3).Value = propertyItem.ColumnWidth
                    sqlParamArr(4) = New SqlParameter("@DefaultValue", SqlDbType.NVarChar, 256)
                    If propertyItem.DefaultValue Is Nothing Then
                        sqlParamArr(4).Value = String.Empty
                    Else
                        sqlParamArr(4).Value = propertyItem.DefaultValue
                    End If
                    sqlParamArr(5) = New SqlParameter("@OperatorType", SqlDbType.NVarChar, 30)
                    sqlParamArr(5).Value = propertyItem.OperatorType
                    sqlParamArr(6) = New SqlParameter("@RenderAs", SqlDbType.NVarChar, 30)
                    sqlParamArr(6).Value = propertyItem.RenderAs
                    sqlParamArr(7) = New SqlParameter("@Required", SqlDbType.Bit)
                    sqlParamArr(7).Value = propertyItem.Required
                    sqlParamArr(8) = New SqlParameter("@ShowInQuery", SqlDbType.Bit)
                    sqlParamArr(8).Value = propertyItem.ShowInQuery
                    sqlParamArr(9) = New SqlParameter("@ShowInResults", SqlDbType.Bit)
                    sqlParamArr(9).Value = propertyItem.ShowInResults
                    sqlParamArr(10) = New SqlParameter("@SortDirection", SqlDbType.NVarChar, 30)
                    sqlParamArr(10).Value = propertyItem.SortDirection
                    sqlParamArr(11) = New SqlParameter("@SortOrder", SqlDbType.Int)
                    sqlParamArr(11).Value = propertyItem.SortOrder
                    sqlParamArr(12) = New SqlParameter("@Text", SqlDbType.NVarChar, 256)
                    If propertyItem.Text Is Nothing Then
                        sqlParamArr(12).Value = String.Empty
                    Else
                        sqlParamArr(12).Value = propertyItem.Text
                    End If
                    sqlParamArr(13) = New SqlParameter("@TextAlign", SqlDbType.NVarChar, 30)
                    sqlParamArr(13).Value = propertyItem.TextAlign
                    sqlParamArr(14) = New SqlParameter("@Value", SqlDbType.NVarChar, 256)
                    If propertyItem.Value Is Nothing Then
                        sqlParamArr(14).Value = String.Empty
                    Else
                        sqlParamArr(14).Value = propertyItem.Value
                    End If
                    sqlParamArr(15) = New SqlParameter("@DisplayOrder", SqlDbType.Int)
                    sqlParamArr(15).Value = propertyItem.DisplayOrder
                    sqlParamArr(16) = New SqlParameter("@IncludePropertyAsQueryStringParameter", SqlDbType.Bit)
                    sqlParamArr(16).Value = propertyItem.IncludePropertyAsQueryStringParameter
                    sqlParamArr(17) = New SqlParameter("@QueryStringParameterName", SqlDbType.NVarChar, 256)
                    sqlParamArr(17).Value = propertyItem.QueryStringParameterName
                    sqlParamArr(18) = New SqlParameter("@UseAsEmailAddress", SqlDbType.Bit)
                    sqlParamArr(18).Value = propertyItem.UseAsEmailAddress
                    sqlParamArr(19) = New SqlParameter("@GetValueFromQueryString", SqlDbType.Bit)
                    sqlParamArr(19).Value = propertyItem.GetValueFromQueryString
                    sqlParamArr(20) = New SqlParameter("@DisplayOrderForSearch", SqlDbType.Int)
                    sqlParamArr(20).Value = propertyItem.DisplayOrderForSearch



                    Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "AddPersonifyDynamicSearchSettings", sqlParamArr(0), _
    sqlParamArr(1), sqlParamArr(2), sqlParamArr(3), sqlParamArr(4), sqlParamArr(5), sqlParamArr(6), sqlParamArr(7), sqlParamArr(8), sqlParamArr(9), sqlParamArr(10), sqlParamArr(11), sqlParamArr(12), sqlParamArr(13), sqlParamArr(14), sqlParamArr(15), sqlParamArr(16), sqlParamArr(17), sqlParamArr(18), sqlParamArr(19), sqlParamArr(20))

                Next

                objModules.UpdateModuleSetting(Me.ModuleId, "DisplayResultsAsURL", CStr(IIf(chkDisplayResultsAsURL.Checked, "Y", "N")))
                If chkDisplayResultsAsURL.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, "OnClickNavigatetoPage", urlOnClickNavigatetoPage.Url)
                End If

                '3246-5747347
                objModules.UpdateModuleSetting(Me.ModuleId, "AllowImpersonation", CStr(IIf(chkAllowImpersonation.Checked, "Y", "N")))
                If chkAllowImpersonation.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, "AllowImpersonationActionURL", urlAllowImpersonationActionURL.Url)
                End If

                objModules.UpdateModuleSetting(Me.ModuleId, "ShowVcardURL", CStr(IIf(Me.chkVcard.Checked, "Y", "N")))
                If chkVcard.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, "VcardURLValue", UrlVcardPage.Url)
                End If

                objModules.UpdateModuleSetting(Me.ModuleId, "AutomaticSearchEnabled", CStr(IIf(chkAutomaticSearchEnabled.Checked, "Y", "N")))
                If chkAutomaticSearchEnabled.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, "HideSearchParameterSection", CStr(IIf(chkHideSearchParameterSection.Checked, "Y", "N")))
                End If
                objModules.UpdateModuleSetting(Me.ModuleId, "SearchCaption", txtSearchCaption.Text)
                objModules.UpdateModuleSetting(Me.ModuleId, "EnforceLimits", CStr(IIf(chkEnforceLimits.Checked, "Y", "N")))
                objModules.UpdateModuleSetting(Me.ModuleId, "MaxRows", txtMaxRows.Text)
                'objModules.UpdateModuleSetting(Me.ModuleId, "ErrorCountLimit", txtErrorCountLimit.Text)
                'objModules.UpdateModuleSetting(Me.ModuleId, "WarningCountLimit", txtWarningCountLimit.Text)
                objModules.UpdateModuleSetting(Me.ModuleId, "SendEmailEnabled", CStr(IIf(chkSendEmailEnabled.Checked, "Y", "N")))
                If chkSendEmailEnabled.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, "SendEmailActionURL", CStr(urlSendEmailActionURL.Url))
                End If
                objModules.UpdateModuleSetting(Me.ModuleId, "PageSize", drpPageSize.SelectedValue)

                objModules.UpdateModuleSetting(Me.ModuleId, "Namespace", drpNamespaces.SelectedValue)
                objModules.UpdateModuleSetting(Me.ModuleId, "Collection", drpTargetCollections.SelectedValue)

                'Export
                objModules.UpdateModuleSetting(Me.ModuleId, "Export", rblExportOption.SelectedValue)

                'Template
                objModules.UpdateModuleSetting(ModuleId, "Template", cboTemplate.SelectedValue)
                Return True
            Else
                lblError.Text = ErrorMessage
                Return False
            End If

        End Function

        Private Function GetNamespaces() As ArrayList
            Dim namespaces As New ArrayList
            For Each NamespaceName As String In System.Enum.GetNames(GetType(TIMSS.Enumerations.NamespaceEnum))
                namespaces.Add(NamespaceName)
            Next
            namespaces.Sort()
            Return namespaces
        End Function



        Private Function GetCollections(ByVal NamespaceName As String, ByVal InterfaceType As Type) As ArrayList
            Dim oAsm As System.Reflection.Assembly
            Dim strPrefix As String
            Dim oType As Type
            Dim a As Integer
            Dim TypeList As ArrayList
            Dim InterfaceName As String



            TypeList = New ArrayList
            InterfaceName = InterfaceType.FullName
            
            For a = 0 To TIMSS.Global.App.TypeCache.Libraries.Count - 1
                oAsm = TIMSS.Global.App.TypeCache.Libraries(a).Assembly
                If Not oAsm Is Nothing Then
                    
                    strPrefix = TIMSS.Global.App.TypeCache.Libraries(a).RootNamespace & "." & NamespaceName & "."
                    For Each oType In oAsm.GetTypes()
                        If oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") And NamespaceName = "UserDefinedInfo" Then
                            strPrefix = "TIMSS.API.USER."
                            If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                If Not TypeList.Contains(oType.FullName.Substring(strPrefix.Length)) Then
                                    TypeList.Add(oType.FullName.Substring(strPrefix.Length))
                                End If
                            End If
                        ElseIf Not oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") Then
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper) Then
                                ' Assemblies generated from the Database Designer contain both the interfaces and the classes;
                                ' we check Not IsInterface because we only want to show the classes. 
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    If Not TypeList.Contains(oType.FullName.Substring(strPrefix.Length)) Then
                                        TypeList.Add(oType.FullName.Substring(strPrefix.Length))
                                    End If
                                End If
                            End If
                        End If
                    Next

                End If
            Next
            TypeList.Sort()
            Return TypeList
        End Function



        Private Function GetPropertiesDepth(ByVal namespaceName As String, ByVal collection As String, ByVal InterfaceType As Type) As ArrayList

            Dim properties As New ArrayList
            Dim oAsm As System.Reflection.Assembly
            Dim strPrefix As String
            Dim oType As Type
            Dim a As Integer
            Dim InterfaceName As String


            InterfaceName = InterfaceType.FullName

            For a = 0 To TIMSS.Global.App.TypeCache.Libraries.Count - 1
                oAsm = TIMSS.Global.App.TypeCache.Libraries(a).Assembly
                If Not oAsm Is Nothing Then
                    For Each oType In oAsm.GetTypes()                        
                        If oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") And namespaceName = "UserDefinedInfo" Then
                            Dim colArray() As String = collection.Split(CChar("."))
                            If colArray.Length >= 2 Then
                                strPrefix = "TIMSS.API.USER" & "." & colArray(0) & "." & colArray(1)
                            Else
                                strPrefix = "TIMSS.API.USER" & "." & collection
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper = strPrefix.ToUpper Then
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    properties = GetTypeProperties(oType, collection, namespaceName)
                                    Return properties
                                End If
                            End If
                        Else                   ''AN FIX - 3246-6976988 If Not oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") Then
                            If collection.IndexOf(".") >= 0 Then
                                strPrefix = namespaceName & "." & collection.Substring(0, collection.IndexOf("."))
                            Else
                                If collection = String.Empty Then
                                    strPrefix = namespaceName
                                Else
                                    strPrefix = namespaceName & "." & collection
                                End If
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper.EndsWith(strPrefix.ToUpper) Then
                                ' Assemblies generated from the Database Designer contain both the interfaces and the classes;
                                ' we check Not IsInterface because we only want to show the classes. 
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    properties = GetTypeProperties(oType, collection, namespaceName)
                                    Return properties
                                End If
                            End If
                        End If
                    Next
                End If
            Next


            Return Nothing
        End Function
        Private Function GetTypeProperties(ByVal oType As Type, ByVal collection As String, ByVal namespaceName As String) As ArrayList
            Dim properties As New ArrayList
            Dim oProperties As Reflection.PropertyInfo() = oType.GetProperties()
            Dim objectToReturn As Reflection.PropertyInfo = Nothing
            Dim oTargetType As Type
            Dim colArray() As String = collection.Split(CChar("."))
            collection = String.Empty
            For i As Integer = 1 To colArray.Length - 1
                If collection = String.Empty Then
                    collection = colArray(i)
                Else
                    collection = collection & "." & colArray(i)
                End If

            Next
            Dim UserDefinedinfo As Boolean = False
            If namespaceName = "UserDefinedInfo" Then
                UserDefinedinfo = True
            End If
            For Each Item As Reflection.PropertyInfo In oProperties
                If (Item.Name = "Item") Then
                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        'Dim APIItemType As Type

                        'APIItemType = TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType)
                        'If Not APIItemType Is Nothing Then

                        'End If
                        'Fix - User Defined fields not getting displayed

                        oTargetType = TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType)
                        oPropertiesItem = oTargetType.GetProperties()

                        'Dim parentInstance As TIMSS.API.Core.BusinessObjectCollection = CType(oType.Assembly.CreateInstance(oType.FullName), TIMSS.API.Core.BusinessObjectCollection)
                        'Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                        Dim instance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(oType)
                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                If IsCollection(p.PropertyType) Then
                                    properties.Add(p.Name & "..")

                                Else
                                    If (instance.Schema(p.Name) IsNot Nothing AndAlso instance.Schema(p.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Relationship) Then
                                        If IsItem(p.PropertyType) Then
                                            properties.Add(p.Name & "..")
                                        Else
                                            properties.Add(p.Name)
                                        End If
                                    Else
                                        If (instance.Schema(p.Name) IsNot Nothing AndAlso CType(instance.Schema(p.Name), TIMSS.API.Core.IValuePropertyInfo).ColumnName() <> String.Empty) Then
                                            If IsItem(p.PropertyType) Then
                                                properties.Add(p.Name & "..")
                                            Else
                                                properties.Add(p.Name)
                                            End If
                                        End If
                                    End If
                                End If
                            Else
                                properties = GetTypeProperties(Item.PropertyType, collection, namespaceName)
                                properties.Sort()
                                Return properties
                            End If

                        Next
                        properties.Sort()

                        Return properties
                    End If
                ElseIf (Item.Name = colArray(0)) Or (colArray.Length >= 2 AndAlso (Item.Name = colArray(1) And UserDefinedinfo)) Then

                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then

                        ''AN FIX - 3246-6976988 - 
                        'TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType)
                        'Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        Dim oPropertiesItem As Reflection.PropertyInfo() = TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType).GetProperties()
                        Dim ItemFound As Boolean = False
                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If (p.Name = "Item") Then
                                ItemFound = True
                                ''AN FIX - 3246-6976988

                                'Dim oPropertiesItem1 As Reflection.PropertyInfo() = p.PropertyType.GetProperties()
                                Dim oPropertiesItem1 As Reflection.PropertyInfo() = TIMSS.Global.App.GetAPITypeForInterface(p.PropertyType).GetProperties

                                Dim instance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(Item.PropertyType)

                                'Dim parentInstance As TIMSS.API.Core.BusinessObjectCollection = CType(t.Assembly.CreateInstance(t.FullName), TIMSS.API.Core.BusinessObjectCollection)
                                'Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)

                                For Each p1 As Reflection.PropertyInfo In oPropertiesItem1
                                    If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                        If IsCollection(p1.PropertyType) Then
                                            properties.Add(p1.Name & "..")

                                        Else
                                            If (instance.Schema(p1.Name) IsNot Nothing AndAlso _
                                                    instance.Schema(p1.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Relationship) Then
                                                If IsItem(p1.PropertyType) Then
                                                    properties.Add(p1.Name & "..")
                                                Else
                                                    properties.Add(p1.Name)
                                                End If
                                            Else
                                                If (instance.Schema(p1.Name) IsNot Nothing AndAlso _
                                                CType(instance.Schema(p1.Name), TIMSS.API.Core.IValuePropertyInfo).ColumnName() <> String.Empty) Then
                                                    If IsItem(p1.PropertyType) Then
                                                        properties.Add(p1.Name & "..")
                                                    Else
                                                        properties.Add(p1.Name)
                                                    End If
                                                End If
                                            End If
                                        End If
                                    Else
                                        properties = GetTypeProperties(p.PropertyType, collection, namespaceName)
                                        properties.Sort()
                                        Return properties
                                    End If
                                Next
                                properties.Sort()
                                Return properties
                            ElseIf colArray.Length >= 2 Then
                                If p.Name = colArray(1) Or (colArray.Length >= 3 AndAlso (p.Name = colArray(2) And UserDefinedinfo)) Then
                                    '3246-6246496
                                    Dim oPropertiesItem1 As Reflection.PropertyInfo() = p.PropertyType.GetProperties()


                                    For Each p1 As Reflection.PropertyInfo In oPropertiesItem1
                                        If (p1.Name = "Item") Then
                                            ItemFound = True
                                            Dim oPropertiesItem2 As Reflection.PropertyInfo() = p1.PropertyType.GetProperties()

                                            Dim instance1 As TIMSS.API.Core.IBusinessObjectCollection = Nothing
                                            If IsCollection(p.PropertyType) Then
                                                instance1 = PersonifyGetCollection(p.PropertyType)
                                            Else
                                                instance1 = PersonifyGetCollection(TIMSS.Global.GetItem(p.PropertyType).ContainerType)
                                            End If

                                            If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                                If IsCollection(p1.PropertyType) Then
                                                    properties.Add(p1.Name & "..")

                                                Else
                                                    If (instance1.Schema(p1.Name) IsNot Nothing AndAlso instance1.Schema(p1.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Relationship) Then
                                                        If IsItem(p1.PropertyType) Then
                                                            properties.Add(p1.Name & "..")
                                                        Else
                                                            properties.Add(p1.Name)
                                                        End If
                                                    Else
                                                        If (instance1.Schema(p1.Name) IsNot Nothing AndAlso CType(instance1.Schema(p1.Name), TIMSS.API.Core.IValuePropertyInfo).ColumnName() <> String.Empty) Then
                                                            If IsItem(p1.PropertyType) Then
                                                                properties.Add(p1.Name & "..")
                                                            Else
                                                                properties.Add(p1.Name)
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            Else
                                                properties = GetTypeProperties(p.PropertyType, collection, namespaceName)
                                                properties.Sort()
                                                Return properties
                                            End If
                                            properties.Sort()
                                            Return properties
                                        End If
                                        If Not ItemFound Then
                                            properties = GetTypeProperties(Item.PropertyType, collection, namespaceName)
                                            properties.Sort()
                                            Return properties
                                        End If
                                        'If IsCollection(p1.PropertyType) Then
                                        'properties.Add(p1.Name & "..")

                                        'Else
                                        'If (instance.Schema(p1.Name) IsNot Nothing AndAlso instance.Schema(p1.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Relationship) Then
                                        'If IsItem(p1.PropertyType) Then
                                        'properties.Add(p1.Name & "..")
                                        'Else
                                        'properties.Add(p1.Name)
                                        'End If
                                        'Else
                                        'If (instance.Schema(p1.Name) IsNot Nothing AndAlso CType(instance.Schema(p1.Name), TIMSS.API.Core.IValuePropertyInfo).ColumnName() <> String.Empty) Then
                                        'If IsItem(p1.PropertyType) Then
                                        'properties.Add(p1.Name & "..")
                                        'Else
                                        'properties.Add(p1.Name)
                                        'End If
                                        'End If
                                        'End If



                                    Next
                                    properties.Sort()
                                    Return properties
                                    'END 3246-6246496


                                End If

                            End If
                        Next
                        If Not ItemFound AndAlso (collection = String.Empty Or (collection.IndexOf(".") < 0 And UserDefinedinfo)) Then
                            ' Dim instance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(TIMSS.Global.GetItem(Item.PropertyType).ContainerType)
                            Dim instance As TIMSS.API.Core.IBusinessObjectCollection = ReturnBOC(Item.PropertyType)
                            For Each p As Reflection.PropertyInfo In oPropertiesItem
                                If IsCollection(p.PropertyType) Then
                                    properties.Add(p.Name & "..")

                                Else
                                    If (instance.Schema(p.Name) IsNot Nothing AndAlso instance.Schema(p.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Relationship) Then
                                        If IsItem(p.PropertyType) Then
                                            properties.Add(p.Name & "..")
                                        Else
                                            properties.Add(p.Name)
                                        End If
                                    Else
                                        If (instance.Schema(p.Name) IsNot Nothing AndAlso CType(instance.Schema(p.Name), TIMSS.API.Core.IValuePropertyInfo).ColumnName() <> String.Empty) Then
                                            If IsItem(p.PropertyType) Then
                                                properties.Add(p.Name & "..")
                                            Else
                                                properties.Add(p.Name)
                                            End If
                                        End If
                                    End If
                                End If
                            Next
                            properties.Sort()
                            Return properties
                        End If

                    End If
                End If

            Next
            Return Nothing
        End Function
        Private Function ReturnBOC(ByVal pType As System.Type) As TIMSS.API.Core.IBusinessObjectCollection

            Dim instance As TIMSS.API.Core.IBusinessObjectCollection
            Dim AllInterfaceTypes() As System.Type
            Dim i As Integer = 0
            Dim strOrigNameSpace As String = ""

            Dim strTokenizeNamespace() As String = pType.FullName.Split(".")
            If strTokenizeNamespace.Length > 2 Then
                strOrigNameSpace = String.Format("{0}.{1}.{2}", strTokenizeNamespace(0), strTokenizeNamespace(1), strTokenizeNamespace(2))

            End If


            AllInterfaceTypes = TIMSS.Global.GetItem(pType).ContainerType.GetInterfaces()

            For i = 0 To AllInterfaceTypes.Length - 1
                If AllInterfaceTypes(i).Namespace = strOrigNameSpace Then
                    Exit For
                End If
            Next

            instance = PersonifyGetCollection(AllInterfaceTypes(i))

            Return instance
        End Function

        Private Function ImplementsInterface(ByVal ClassType As Type, ByVal InterfaceType As Type) As Boolean
            Return (ClassType Is InterfaceType) OrElse Not (ClassType.GetInterface(InterfaceType.FullName) Is Nothing)
        End Function

        Private Function IsCollection(ByVal ItemType As Type) As Boolean
            Return ImplementsInterface(ItemType, GetType(TIMSS.API.Core.IBusinessObjectCollection))
        End Function

        Private Function IsItem(ByVal ItemType As Type) As Boolean
            Return ImplementsInterface(ItemType, GetType(TIMSS.API.Core.IBusinessObject))
        End Function

        Private Function IsCode(ByVal ItemType As Type) As Boolean
            Return ImplementsInterface(ItemType, GetType(TIMSS.API.Core.ICode))
        End Function

        Private Function IsValue(ByVal ItemType As Type) As Boolean
            Return Not (IsCollection(ItemType) OrElse IsItem(ItemType) OrElse IsCode(ItemType))
        End Function

#End Region
#Region "DataList Functions"
        Private Sub dlProperties_ItemDataBound(ByVal sender As Object, ByVal e As DataListItemEventArgs) Handles dlProperties.ItemDataBound
            If e.Item.ItemType = ListItemType.EditItem Then
                If e.Item.FindControl("drpOperatorEdit") IsNot Nothing Then
                    Dim drpOperatorEdit As DropDownList = CType(e.Item.FindControl("drpOperatorEdit"), DropDownList)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)

                    With drpOperatorEdit
                        For Each operatorT As String In [Enum].GetNames(GetType(TIMSS.Enumerations.QueryOperatorEnum))
                            .Items.Add(New ListItem(operatorT, operatorT))
                        Next
                        .SelectedValue = propertyItem.OperatorType
                    End With
                End If

                If e.Item.FindControl("drpSortDirectionEdit") IsNot Nothing Then
                    Dim drpSortDirectionEdit As DropDownList = CType(e.Item.FindControl("drpSortDirectionEdit"), DropDownList)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)

                    With drpSortDirectionEdit
                        For Each operatorT As String In [Enum].GetNames(GetType(TIMSS.Enumerations.SortDirection))
                            .Items.Add(New ListItem(operatorT, operatorT))
                        Next
                        .SelectedValue = propertyItem.SortDirection
                    End With
                End If

                If e.Item.FindControl("lblRenderAsEdit1") IsNot Nothing Then
                    Dim lblRenderAsEdit1 As Label = CType(e.Item.FindControl("lblRenderAsEdit1"), Label)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)

                    lblRenderAsEdit1.Text = CutDetails(propertyItem.RenderAs)
                    'For Each operatorT As String In [Enum].GetNames(GetType(RenderAs))
                    '.Items.Add(New ListItem(operatorT, operatorT))
                    'Next
                    '.SelectedValue = propertyItem.RenderAs

                End If

                If e.Item.FindControl("drpTextAlignEdit") IsNot Nothing Then
                    Dim drpTextAlignEdit As DropDownList = CType(e.Item.FindControl("drpTextAlignEdit"), DropDownList)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)

                    With drpTextAlignEdit
                        For Each operatorT As String In [Enum].GetNames(GetType(TextAlign))
                            .Items.Add(New ListItem(operatorT, operatorT))
                        Next
                        .SelectedValue = propertyItem.TextAlign
                    End With
                End If
                If e.Item.FindControl("chkSystemDateEdit") IsNot Nothing Then
                    Dim chkSystemDateEdit As CheckBox = CType(e.Item.FindControl("chkSystemDateEdit"), CheckBox)
                    Dim lblSystemDateEdit As Label = CType(e.Item.FindControl("lblSystemDateEdit"), Label)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    If CutDetails(propertyItem.RenderAs) = "DatePicker" Then
                        lblSystemDateEdit.Visible = True
                        chkSystemDateEdit.Visible = True
                        If propertyItem.DefaultValue = "02/02/2200" Then '3246-5422015
                            chkSystemDateEdit.Checked = True
                        Else
                            chkSystemDateEdit.Checked = False
                        End If
                    Else
                        lblSystemDateEdit.Visible = False
                        chkSystemDateEdit.Visible = False
                    End If
                End If
                'START 3246-5422015 - add new edit option to use system date for value field.
                If e.Item.FindControl("chkSystemDateValueEdit") IsNot Nothing Then
                    Dim chkSystemDateValueEdit As CheckBox = CType(e.Item.FindControl("chkSystemDateValueEdit"), CheckBox)
                    Dim lblSystemDateValueEdit As Label = CType(e.Item.FindControl("lblSystemDateValueEdit"), Label)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    If CutDetails(propertyItem.RenderAs) = "DatePicker" Then
                        lblSystemDateValueEdit.Visible = True
                        chkSystemDateValueEdit.Visible = True
                        If propertyItem.Value = "01/01/2100" Then
                            chkSystemDateValueEdit.Checked = True
                        Else
                            chkSystemDateValueEdit.Checked = False
                        End If
                    Else
                        lblSystemDateValueEdit.Visible = False
                        chkSystemDateValueEdit.Visible = False
                    End If
                End If

                If e.Item.FindControl("txtDefaultValueEdit") IsNot Nothing Then
                    Dim txtDefaultValueEdit As TextBox = CType(e.Item.FindControl("txtDefaultValueEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    If propertyItem.DefaultValue <> "02/02/2200" Then
                        txtDefaultValueEdit.Text = propertyItem.DefaultValue
                    Else
                        txtDefaultValueEdit.Text = ""
                    End If
                End If
                'END 3246-5422015 
                If e.Item.FindControl("chkRequiredEdit") IsNot Nothing Then
                    Dim chkRequiredEdit As CheckBox = CType(e.Item.FindControl("chkRequiredEdit"), CheckBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    chkRequiredEdit.Checked = propertyItem.Required
                End If
                If e.Item.FindControl("txtTextEdit") IsNot Nothing Then
                    Dim txtTextEdit As TextBox = CType(e.Item.FindControl("txtTextEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(e.Item.DataItem, PropertiesArray) 'CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    txtTextEdit.Text = propertyItem.Text
                End If
                If e.Item.FindControl("chkUseInQueryEdit") IsNot Nothing Then
                    Dim chkUseInQueryEdit As CheckBox = CType(e.Item.FindControl("chkUseInQueryEdit"), CheckBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    chkUseInQueryEdit.Checked = propertyItem.ShowInQuery
                End If
                If e.Item.FindControl("txtValueEdit") IsNot Nothing Then
                    Dim txtValueEdit As TextBox = CType(e.Item.FindControl("txtValueEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    If propertyItem.Value <> "01/01/2100" Then
                        txtValueEdit.Text = propertyItem.Value
                    Else
                        txtValueEdit.Text = ""
                    End If
                End If

                If e.Item.FindControl("chkGetValueFromQueryStringEdit") IsNot Nothing Then
                    Dim chkGetValueFromQueryStringEdit As CheckBox = CType(e.Item.FindControl("chkGetValueFromQueryStringEdit"), CheckBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    chkGetValueFromQueryStringEdit.Checked = propertyItem.GetValueFromQueryString
                End If
                If e.Item.FindControl("txtDisplayOrderForSearchEdit") IsNot Nothing Then
                    Dim txtDisplayOrderForSearchEdit As TextBox = CType(e.Item.FindControl("txtDisplayOrderForSearchEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    txtDisplayOrderForSearchEdit.Text = CStr(propertyItem.DisplayOrderForSearch)
                End If
                If e.Item.FindControl("chkShowInResultsEdit") IsNot Nothing Then
                    Dim chkShowInResultsEdit As CheckBox = CType(e.Item.FindControl("chkShowInResultsEdit"), CheckBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    chkShowInResultsEdit.Checked = propertyItem.ShowInResults
                End If

                If e.Item.FindControl("txtSortOrderEdit") IsNot Nothing Then
                    Dim txtSortOrderEdit As TextBox = CType(e.Item.FindControl("txtSortOrderEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    txtSortOrderEdit.Text = CType(propertyItem.SortOrder, String)
                End If
                If e.Item.FindControl("txtColumnWidthEdit") IsNot Nothing Then
                    Dim txtColumnWidthEdit As TextBox = CType(e.Item.FindControl("txtColumnWidthEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    txtColumnWidthEdit.Text = CType(propertyItem.ColumnWidth, String)
                End If
                If e.Item.FindControl("txtDisplayOrderEdit") IsNot Nothing Then
                    Dim txtDisplayOrderEdit As TextBox = CType(e.Item.FindControl("txtDisplayOrderEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    txtDisplayOrderEdit.Text = CType(propertyItem.DisplayOrder, String)
                End If

                If e.Item.FindControl("txtQueryStringParameterNameEdit") IsNot Nothing Then
                    Dim txtQueryStringParameterNameEdit As TextBox = CType(e.Item.FindControl("txtQueryStringParameterNameEdit"), TextBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    txtQueryStringParameterNameEdit.Text = CType(propertyItem.QueryStringParameterName, String)
                End If
                If e.Item.FindControl("chkIncludePropertyAsQueryStringParameterEdit") IsNot Nothing Then
                    Dim chkIncludePropertyAsQueryStringParameterEdit As CheckBox = CType(e.Item.FindControl("chkIncludePropertyAsQueryStringParameterEdit"), CheckBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    chkIncludePropertyAsQueryStringParameterEdit.Checked = propertyItem.IncludePropertyAsQueryStringParameter
                End If
                If e.Item.FindControl("chkUseAsEmailAddressEdit") IsNot Nothing Then
                    Dim chkUseAsEmailAddressEdit As CheckBox = CType(e.Item.FindControl("chkUseAsEmailAddressEdit"), CheckBox)
                    Dim propertyItem As PropertiesArray
                    propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                    chkUseAsEmailAddressEdit.Checked = propertyItem.UseAsEmailAddress
                End If

            End If

        End Sub
        Sub Edit_Command(ByVal sender As Object, ByVal e As DataListCommandEventArgs)

            dlProperties.EditItemIndex = e.Item.ItemIndex
            dlProperties.DataSource = Properties
            dlProperties.DataBind()
        End Sub
        Sub Update_Command(ByVal sender As Object, ByVal e As DataListCommandEventArgs)

            If e.Item.FindControl("drpOperatorEdit") IsNot Nothing Then
                Dim drpOperatorEdit As DropDownList = CType(e.Item.FindControl("drpOperatorEdit"), DropDownList)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.OperatorType = drpOperatorEdit.SelectedValue
            End If

            If e.Item.FindControl("drpSortDirectionEdit") IsNot Nothing Then
                Dim drpSortDirectionEdit As DropDownList = CType(e.Item.FindControl("drpSortDirectionEdit"), DropDownList)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.SortDirection = drpSortDirectionEdit.SelectedValue
            End If

            If e.Item.FindControl("drpRenderAsEdit") IsNot Nothing Then
                Dim drpRenderAsEdit As DropDownList = CType(e.Item.FindControl("drpRenderAsEdit"), DropDownList)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.RenderAs = drpRenderAsEdit.SelectedValue
            End If

            If e.Item.FindControl("drpTextAlignEdit") IsNot Nothing Then
                Dim drpTextAlignEdit As DropDownList = CType(e.Item.FindControl("drpTextAlignEdit"), DropDownList)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.TextAlign = drpTextAlignEdit.SelectedValue
            End If

            If e.Item.FindControl("chkSystemDateEdit") IsNot Nothing Then
                Dim chkSystemDateEdit As CheckBox = CType(e.Item.FindControl("chkSystemDateEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                If CutDetails(propertyItem.RenderAs) = "DatePicker" Then
                    If chkSystemDateEdit.Checked Then
                        propertyItem.DefaultValue = "02/02/2200" '3246-5422015
                    Else
                        propertyItem.DefaultValue = ""
                    End If
                End If
            End If
            'START 3246-5422015
            If e.Item.FindControl("txtDefaultValueEdit") IsNot Nothing Then
                Dim txtDefaultValueEdit As TextBox = CType(e.Item.FindControl("txtDefaultValueEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                If propertyItem.DefaultValue <> "02/02/2200" Then
                    propertyItem.DefaultValue = txtDefaultValueEdit.Text
                End If
            End If
            'END 3246-5422015

            If e.Item.FindControl("chkRequiredEdit") IsNot Nothing Then
                Dim chkRequiredEdit As CheckBox = CType(e.Item.FindControl("chkRequiredEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.Required = chkRequiredEdit.Checked
            End If
            If e.Item.FindControl("txtTextEdit") IsNot Nothing Then
                Dim txtTextEdit As TextBox = CType(e.Item.FindControl("txtTextEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.Text = txtTextEdit.Text
            End If
            If e.Item.FindControl("chkUseInQueryEdit") IsNot Nothing Then
                Dim chkUseInQueryEdit As CheckBox = CType(e.Item.FindControl("chkUseInQueryEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.ShowInQuery = chkUseInQueryEdit.Checked
            End If
            'START 3246-5422015
            If e.Item.FindControl("chkSystemDateValueEdit") IsNot Nothing Then
                Dim chkSystemDateValueEdit As CheckBox = CType(e.Item.FindControl("chkSystemDateValueEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                If CutDetails(propertyItem.RenderAs) = "DatePicker" Then
                    If chkSystemDateValueEdit.Checked Then
                        propertyItem.Value = "01/01/2100"
                    Else
                        propertyItem.Value = ""
                    End If
                End If
            End If
            'END 3246-5422015

            If e.Item.FindControl("txtValueEdit") IsNot Nothing Then
                Dim txtValueEdit As TextBox = CType(e.Item.FindControl("txtValueEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                If propertyItem.Value <> "01/01/2100" Then
                    propertyItem.Value = txtValueEdit.Text
                End If
            End If
            If e.Item.FindControl("chkGetValueFromQueryStringEdit") IsNot Nothing Then
                Dim chkGetValueFromQueryStringEdit As CheckBox = CType(e.Item.FindControl("chkGetValueFromQueryStringEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.GetValueFromQueryString = chkGetValueFromQueryStringEdit.Checked
            End If
            If e.Item.FindControl("txtDisplayOrderForSearchEdit") IsNot Nothing Then
                Dim txtDisplayOrderForSearchEdit As TextBox = CType(e.Item.FindControl("txtDisplayOrderForSearchEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.DisplayOrderForSearch = CType(txtDisplayOrderForSearchEdit.Text, Integer)
            End If
            If e.Item.FindControl("chkShowInResultsEdit") IsNot Nothing Then
                Dim chkShowInResultsEdit As CheckBox = CType(e.Item.FindControl("chkShowInResultsEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.ShowInResults = chkShowInResultsEdit.Checked
            End If

            If e.Item.FindControl("txtSortOrderEdit") IsNot Nothing Then
                Dim txtSortOrderEdit As TextBox = CType(e.Item.FindControl("txtSortOrderEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.SortOrder = CType(txtSortOrderEdit.Text, Integer)
            End If
            If e.Item.FindControl("txtColumnWidthEdit") IsNot Nothing Then
                Dim txtColumnWidthEdit As TextBox = CType(e.Item.FindControl("txtColumnWidthEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.ColumnWidth = CType(txtColumnWidthEdit.Text, Integer)
            End If
            If e.Item.FindControl("txtDisplayOrderEdit") IsNot Nothing Then
                Dim txtDisplayOrderEdit As TextBox = CType(e.Item.FindControl("txtDisplayOrderEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.DisplayOrder = CType(txtDisplayOrderEdit.Text, Integer)
            End If

            If e.Item.FindControl("txtQueryStringParameterNameEdit") IsNot Nothing Then
                Dim txtQueryStringParameterNameEdit As TextBox = CType(e.Item.FindControl("txtQueryStringParameterNameEdit"), TextBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.QueryStringParameterName = txtQueryStringParameterNameEdit.Text
            End If
            If e.Item.FindControl("chkIncludePropertyAsQueryStringParameterEdit") IsNot Nothing Then
                Dim chkIncludePropertyAsQueryStringParameterEdit As CheckBox = CType(e.Item.FindControl("chkIncludePropertyAsQueryStringParameterEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.IncludePropertyAsQueryStringParameter = chkIncludePropertyAsQueryStringParameterEdit.Checked
            End If
            If e.Item.FindControl("chkUseAsEmailAddressEdit") IsNot Nothing Then
                Dim chkUseAsEmailAddressEdit As CheckBox = CType(e.Item.FindControl("chkUseAsEmailAddressEdit"), CheckBox)
                Dim propertyItem As PropertiesArray
                propertyItem = CType(Properties(e.Item.ItemIndex), PropertiesArray)
                propertyItem.UseAsEmailAddress = chkUseAsEmailAddressEdit.Checked
            End If
            dlProperties.EditItemIndex = -1
            dlProperties.DataSource = Properties
            dlProperties.DataBind()

        End Sub

        Sub Delete_Command(ByVal sender As Object, ByVal e As DataListCommandEventArgs)

            Properties.RemoveAt(e.Item.ItemIndex)
            dlProperties.DataSource = Properties
            dlProperties.DataBind()
        End Sub
        Public Function DisplayImage(ByVal Value As Boolean) As String
            If Value = True Then
                Return String.Format("<img src=""{0}"">", GetCheckImageURL())
            Else
                Return String.Format("<img src=""{0}"">", GetDeleteImageURL())
            End If
        End Function

        Private Function GetSchemaInfo(ByVal Collection As String, ByVal PropertyName As String) As SchemaInfo
            Dim schemaInfo As SchemaInfo

            Dim namespaceName As String = Collection.Substring(0, Collection.IndexOf(CChar(".")))
            Dim collectionName As String = Collection.Substring(Collection.IndexOf(CChar(".")) + 1)
            schemaInfo = GetPropertyRenderDepth(namespaceName, collectionName, GetType(TIMSS.API.Core.IBusinessObjectCollection), PropertyName)

            Return schemaInfo
        End Function

        
        Private Function GetPropertyRenderDepth(ByVal namespaceName As String, ByVal collection As String, ByVal InterfaceType As Type, ByVal PropertyName As String) As SchemaInfo

            Dim properties As New ArrayList
            Dim oAsm As System.Reflection.Assembly
            Dim strPrefix As String
            Dim oType As Type
            Dim a As Integer
            Dim InterfaceName As String


            InterfaceName = InterfaceType.FullName

            For a = 0 To TIMSS.Global.App.TypeCache.Libraries.Count - 1
                oAsm = TIMSS.Global.App.TypeCache.Libraries(a).Assembly
                If Not oAsm Is Nothing Then
                    For Each oType In oAsm.GetTypes()
                        If oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") And namespaceName = "UserDefinedInfo" Then
                            Dim colArray() As String = collection.Split(CChar("."))
                            If colArray.Length >= 2 Then
                                strPrefix = "TIMSS.API.USER" & "." & colArray(0) & "." & colArray(1)
                            Else
                                strPrefix = "TIMSS.API.USER" & "." & collection
                            End If                            
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper = strPrefix.ToUpper Then
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    Return GetPropertyRender(oType, collection, PropertyName, namespaceName)
                                End If
                            End If
                        Else          ' 'AN FIX - 3246-6976988 If Not oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") Then
                            If collection.IndexOf(".") >= 0 Then
                                strPrefix = namespaceName & "." & collection.Substring(0, collection.IndexOf("."))
                            Else
                                If collection = String.Empty Then
                                    strPrefix = namespaceName
                                Else
                                    strPrefix = namespaceName & "." & collection
                                End If
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper.EndsWith(strPrefix.ToUpper) Then
                                ' Assemblies generated from the Database Designer contain both the interfaces and the classes;
                                ' we check Not IsInterface because we only want to show the classes. 
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    Return GetPropertyRender(oType, collection, PropertyName, namespaceName)
                                End If
                            End If
                        End If
                    Next
                End If
            Next
            Return Nothing
        End Function
        Private Function GetPropertyRender(ByVal oType As Type, ByVal collection As String, ByVal PropertyName As String, ByVal namespaceName As String) As SchemaInfo
            Dim properties As New ArrayList
            Dim oTargetType As System.Type



            Dim oProperties As Reflection.PropertyInfo() = oType.GetProperties()
            Dim objectToReturn As Reflection.PropertyInfo = Nothing

            Dim colArray() As String = collection.Split(CChar("."))
            collection = String.Empty
            For i As Integer = 1 To colArray.Length - 1
                If collection = String.Empty Then
                    collection = colArray(i)
                Else
                    collection = collection & "." & colArray(i)
                End If

            Next

            Dim UserDefinedinfo As Boolean = False
            If namespaceName = "UserDefinedInfo" Then
                UserDefinedinfo = True
            End If
            For Each Item As Reflection.PropertyInfo In oProperties
                If (Item.Name = "Item") Then
                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        oTargetType = TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType)
                        ' Fix User defined fields
                        ' Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        Dim oPropertiesItem As Reflection.PropertyInfo()
                        oPropertiesItem = oTargetType.GetProperties()

                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                If p.Name = PropertyName Then
                                    Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(oType)
                                    Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                    Dim schemaInfo As SchemaInfo = New SchemaInfo
                                    schemaInfo.Caption = instance.Schema(PropertyName).Caption
                                    schemaInfo.DataType = "string"
                                    Select Case instance.Schema(PropertyName).Type.Name
                                        Case "Boolean"
                                            schemaInfo.Control = "ComboBoxBoolean"
                                            Return schemaInfo
                                        Case "DateTime"
                                            schemaInfo.Control = "DatePicker"
                                            Return schemaInfo
                                        Case "AppCode"
                                            schemaInfo.Control = "ComboBox"
                                            Return schemaInfo
                                        Case "String"
                                            schemaInfo.Control = "TextBox"
                                            Return schemaInfo
                                        Case Else
                                            If "Int16|Int32|Int64|Decimal|Long|Amount|Single".IndexOf(instance.Schema(PropertyName).Type.Name) >= 0 Then
                                                schemaInfo.DataType = "numeric"
                                                schemaInfo.Control = "TextBoxNumeric"
                                                Return schemaInfo
                                            Else
                                                If instance.Schema(PropertyName).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                                    schemaInfo.Control = "ComboBox"
                                                    Return schemaInfo
                                                End If
                                            End If

                                    End Select

                                Else
                                End If
                            Else
                                Return GetPropertyRender(Item.PropertyType, collection, PropertyName, namespaceName)
                            End If

                        Next
                    End If
                ElseIf (Item.Name = colArray(0)) Or (colArray.Length >= 2 AndAlso (Item.Name = colArray(1) And UserDefinedinfo)) Then

                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        'Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        ''AN FIX - 3246-6976988
                        Dim oPropertiesItem As Reflection.PropertyInfo() = TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType).GetProperties()
                        Dim ItemFound As Boolean = False
                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If (p.Name = "Item") Then
                                ItemFound = True
                                ''AN FIX - 3246-6976988
                                Dim oPropertiesItem1 As Reflection.PropertyInfo() = TIMSS.Global.App.GetAPITypeForInterface(p.PropertyType).GetProperties()

                                For Each p1 As Reflection.PropertyInfo In oPropertiesItem1
                                    If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                        If p1.Name = PropertyName Then
                                            Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(p.ReflectedType)
                                            Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                            Dim schemaInfo As SchemaInfo = New SchemaInfo
                                            schemaInfo.Caption = instance.Schema(PropertyName).Caption
                                            schemaInfo.DataType = "string"
                                            Select Case instance.Schema(PropertyName).Type.Name
                                                Case "Boolean"
                                                    schemaInfo.Control = "ComboBoxBoolean"
                                                    Return schemaInfo
                                                Case "DateTime"
                                                    schemaInfo.Control = "DatePicker"
                                                    Return schemaInfo
                                                Case "AppCode"
                                                    schemaInfo.Control = "ComboBox"
                                                    Return schemaInfo
                                                Case "String"
                                                    schemaInfo.Control = "TextBox"
                                                    Return schemaInfo
                                                Case Else
                                                    If "Int16|Int32|Int64|Decimal|Long|Amount|Single".IndexOf(instance.Schema(PropertyName).Type.Name) >= 0 Then
                                                        schemaInfo.Control = "TextBoxNumeric"
                                                        schemaInfo.DataType = "numeric"
                                                        Return schemaInfo
                                                    Else
                                                        If instance.Schema(PropertyName).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                                            schemaInfo.Control = "ComboBox"
                                                            Return schemaInfo
                                                        End If
                                                    End If

                                            End Select
                                        Else
                                        End If
                                    Else
                                        Return GetPropertyRender(p.PropertyType, collection, PropertyName, namespaceName)
                                    End If
                                Next
                            ElseIf colArray.Length >= 2 Then
                                If p.Name = colArray(1) Or (colArray.Length >= 3 AndAlso (p.Name = colArray(2) And UserDefinedinfo)) Then
                                    '3246-6246496
                                    'Return GetPropertyRender(p.PropertyType, collection, PropertyName)
                                    Dim oPropertiesItem1 As Reflection.PropertyInfo() = p.PropertyType.GetProperties()


                                    For Each p1 As Reflection.PropertyInfo In oPropertiesItem1
                                        If (p1.Name = "Item") Then
                                            ItemFound = True
                                            Dim oPropertiesItem2 As Reflection.PropertyInfo() = p1.PropertyType.GetProperties()

                                            Dim instance1 As TIMSS.API.Core.IBusinessObjectCollection = Nothing
                                            If IsCollection(p.PropertyType) Then
                                                instance1 = PersonifyGetCollection(p.PropertyType)
                                            Else
                                                instance1 = PersonifyGetCollection(TIMSS.Global.GetItem(p.PropertyType).ContainerType)
                                            End If

                                            If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                                For Each p2 As Reflection.PropertyInfo In oPropertiesItem1
                                                    If p2.Name = PropertyName Then
                                                        Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(TIMSS.Global.GetItem(p1.PropertyType).ContainerType)
                                                        Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                                        Dim schemaInfo As SchemaInfo = New SchemaInfo
                                                        schemaInfo.Caption = instance.Schema(PropertyName).Caption
                                                        schemaInfo.DataType = "string"
                                                        Select Case instance.Schema(PropertyName).Type.Name
                                                            Case "Boolean"
                                                                schemaInfo.Control = "ComboBoxBoolean"
                                                                Return schemaInfo
                                                            Case "DateTime"
                                                                schemaInfo.Control = "DatePicker"
                                                                Return schemaInfo
                                                            Case "AppCode"
                                                                schemaInfo.Control = "ComboBox"
                                                                Return schemaInfo
                                                            Case "String"
                                                                schemaInfo.Control = "TextBox"
                                                                Return schemaInfo
                                                            Case Else
                                                                If "Int16|Int32|Int64|Decimal|Long|Amount|Single".IndexOf(instance.Schema(PropertyName).Type.Name) >= 0 Then
                                                                    schemaInfo.Control = "TextBoxNumeric"
                                                                    schemaInfo.DataType = "numeric"
                                                                    Return schemaInfo
                                                                Else
                                                                    If instance.Schema(PropertyName).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                                                        schemaInfo.Control = "ComboBox"
                                                                        Return schemaInfo
                                                                    End If
                                                                End If

                                                        End Select
                                                    Else
                                                    End If
                                                Next
                                            Else
                                                Return GetPropertyRender(p.PropertyType, collection, PropertyName, namespaceName)
                                            End If
                                        End If

                                        If Not ItemFound Then
                                            Return GetPropertyRender(Item.PropertyType, collection, PropertyName, namespaceName)
                                        End If

                                    Next



                                    'END 3246-6246496
                                End If
                            End If

                        Next

                        If Not ItemFound AndAlso (collection = String.Empty Or (collection.IndexOf(".") < 0 And UserDefinedinfo)) Then
                            For Each p As Reflection.PropertyInfo In oPropertiesItem
                                If p.Name = PropertyName Then
                                    ''AN FIX - 3246-6976988
                                    'Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = Me.PersonifyGetCollection(TIMSS.Global.GetItem(Item.PropertyType).ContainerType)
                                    Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = ReturnBOC(Item.PropertyType)
                                    Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                    Dim schemaInfo As SchemaInfo = New SchemaInfo
                                    schemaInfo.Caption = instance.Schema(PropertyName).Caption
                                    schemaInfo.DataType = "string"
                                    Select Case instance.Schema(PropertyName).Type.Name
                                        Case "Boolean"
                                            schemaInfo.Control = "ComboBoxBoolean"
                                            Return schemaInfo
                                        Case "DateTime"
                                            schemaInfo.Control = "DatePicker"
                                            Return schemaInfo
                                        Case "AppCode"
                                            schemaInfo.Control = "ComboBox"
                                            Return schemaInfo
                                        Case "String"
                                            schemaInfo.Control = "TextBox"
                                            Return schemaInfo
                                        Case Else
                                            If "Int16|Int32|Int64|Decimal|Long|Amount|Single".IndexOf(instance.Schema(PropertyName).Type.Name) >= 0 Then
                                                schemaInfo.Control = "TextBoxNumeric"
                                                schemaInfo.DataType = "numeric"
                                                Return schemaInfo
                                            Else
                                                If instance.Schema(PropertyName).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                                    schemaInfo.Control = "ComboBox"
                                                    Return schemaInfo
                                                End If
                                            End If

                                    End Select
                                Else
                                End If
                            Next

                        End If

                    End If
                End If

            Next
            Return Nothing
        End Function

        Public Function CutDetails(ByVal Value As String) As String
            If Value.IndexOf("ComboBox") >= 0 Then
                Return "ComboBox"
            ElseIf Value.IndexOf("TextBox") >= 0 Then
                Return "TextBox"
            Else
                Return Value
            End If
        End Function

        '3246-5774803
        Private Function GetCheckImageURL() As String

            Return ResolveUrl("~/" & siteimagesFolder & "/check.gif")
        End Function
        Private Function GetDeleteImageURL() As String

            Return ResolveUrl("~/" & siteimagesFolder & "/delete.gif")
        End Function
        'END 3246-5774803
#End Region

        Public Class SchemaInfo
            Public Control As String
            Public Caption As String
            Public DataType As String
        End Class

        
    End Class

End Namespace
