Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports Personify.DNN.Modules.DynamicSearch.Business

Namespace Personify.DNN.Modules.DynamicSearch

    Public MustInherit Class Settings
        Inherits Entities.Modules.ModuleSettingsBase

#Region "Controls"
#End Region

        Public Overrides Sub LoadSettings()
            Try
                If Not Page.IsPostBack Then
                    ' Load settings from TabModuleSettings: specific to this instance
                    Dim setting1 As String = CType(TabModuleSettings("settingname1"), String)

                    ' Load settings from ModuleSettings: general for all instances
                    Dim setting2 As String = CType(Settings("settingname2"), String)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Overrides Sub UpdateSettings()
            Try
                Dim objModules As New Entities.Modules.ModuleController

                ' Update TabModuleSettings
                objModules.UpdateTabModuleSetting(TabModuleId, "settingname1", "value")

                ' Update ModuleSettings
                objModules.UpdateModuleSetting(ModuleId, "settingname2", "value")


                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
