Option Strict Off
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.DynamicSearch.Business
Imports TIMSS.API.Core

Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Xml.Xsl
Imports Personify.ApplicationManager.PersonifyEnumerations


Namespace Personify.DNN.Modules.DynamicSearch

    Public MustInherit Class DynamicSearch
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable


#Region "Controls"
        Protected WithEvents pnlMain As System.Web.UI.WebControls.Panel
        Protected WithEvents lblError As System.Web.UI.WebControls.Label

        Protected WithEvents pnlSearch As System.Web.UI.WebControls.Panel
        Protected WithEvents tblSearch As System.Web.UI.HtmlControls.HtmlTable

        'Protected WithEvents tblResults As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents xslResults As WebControls.XslTemplate
        Protected WithEvents pnlResults As System.Web.UI.WebControls.Panel
        Protected WithEvents btnSearch As System.Web.UI.WebControls.Button

        Protected WithEvents dpResults As WebControls.DataPager


        'Private oResults As System.Data.DataTable

        Protected WithEvents moSearchObject As TIMSS.API.Core.SearchObject

        Protected WithEvents butExcel As Button
        Protected WithEvents butCVS As Button
        Protected WithEvents butXML As Button
        Protected WithEvents PanelExportResult As Panel


#End Region

#Region "Properties"

        Private _DisplayResultQuerystringName As String = "DSResult"

        Public Property Properties() As Hashtable
            Get
                Return CType(Me.ViewState("_SelectedProperties"), Hashtable)
            End Get
            Set(ByVal Value As Hashtable)
                Me.ViewState("_SelectedProperties") = Value
            End Set
        End Property

        Public Property AutomaticSearchEnabled() As Boolean
            Get
                Return CType(Me.ViewState("_AutomaticSearchEnabled"), Boolean)
            End Get
            Set(ByVal Value As Boolean)
                Me.ViewState("_AutomaticSearchEnabled") = Value
            End Set
        End Property

        Public Property HideSearchParameterSection() As Boolean
            Get
                Return CType(Me.ViewState("_HideSearchParameterSection"), Boolean)
            End Get
            Set(ByVal Value As Boolean)
                Me.ViewState("_HideSearchParameterSection") = Value
            End Set
        End Property

        Public Property SearchCaption() As String
            Get
                Return CType(Me.ViewState("_SearchCaption"), String)
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_SearchCaption") = Value
            End Set
        End Property
        Public Property EnforceLimits() As Boolean
            Get
                Return CType(Me.ViewState("_EnforceLimits"), Boolean)
            End Get
            Set(ByVal Value As Boolean)
                Me.ViewState("_EnforceLimits") = Value
            End Set
        End Property


        Public Property PNamespace() As String
            Get
                Return CType(Me.ViewState("_Namespace"), String)
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_Namespace") = Value
            End Set
        End Property
        Public Property Collection() As String
            Get
                Return CType(Me.ViewState("_Collection"), String)
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_Collection") = Value
            End Set
        End Property

        Public Property CurrentPage() As Integer
            Get
                Dim o As Object = Me.ViewState("_CurrentPage")
                If (o Is Nothing) Then
                    Return 0
                Else
                    Return CType(o, Integer)
                End If
            End Get
            Set(ByVal Value As Integer)
                Me.ViewState("_CurrentPage") = Value
            End Set
        End Property
#End Region




#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not ReadSettings() Then
                    'lblError.Text = Localization.GetString("MissingSettingsError", LocalResourceFile)
                    pnlMain.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))

                Else

                    dpResults = New WebControls.DataPager()
                    If Settings("PageSize") IsNot Nothing Then
                        dpResults.PageSize = CInt(Settings("PageSize"))
                    Else
                        dpResults.PageSize = 10
                    End If
                    dpResults.PagingMode = WebControls.PagingModeType.PostBack
                    dpResults.Visible = True
                    pnlResults.Controls.Add(dpResults)

                    LoadSearchInterface()
                    If HideSearchParameterSection AndAlso AutomaticSearchEnabled Then
                        pnlSearch.Visible = False
                    Else
                        pnlSearch.Visible = True
                    End If

                    If QueryResultExist() And Not IsPostBack Or (btnXMLPressed()) Then
                        'Display result based on query string parameters                    
                        SearchResults()
                    ElseIf Not AutomaticSearchEnabled Then
                        lblError.Text = ""
                        pnlMain.Visible = True
                        'LoadSearchInterface()
                        If Not Page.IsPostBack Then
                            pnlResults.Visible = False
                        End If
                    ElseIf Not Page.IsPostBack Then
                        'Automatic search is enabled                 
                        RedirectWithParameters()
                    End If

                End If




                For Each key As String In Request.Params.AllKeys
                    If key IsNot Nothing AndAlso key.IndexOf("btnSearch") >= 0 AndAlso Request.Params(key) IsNot Nothing Then
                        CurrentPage = 1
                        dpResults.CurrentPage = 1
                        Exit For
                    End If
                Next

                If Page.IsPostBack And Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").Replace("$", "_").IndexOf(dpResults.ClientID) >= 0 Then
                    BuildResults()
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
            If Page.IsValid Then
                Try
                    RedirectWithParameters()
                    'SearchResults()
                Catch exIgnore As Threading.ThreadAbortException

                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub

        Private Sub dpResults_Change() Handles dpResults.Change
            'this event is triggered if DataPager is moving to another page
            If CurrentPage >= 1 Then
                SearchResults()
            End If
        End Sub

        Private Sub QueryLimitError(ByVal sender As Object, ByVal e As TIMSS.API.Core.QueryLimitErrorEventArgs) Handles moSearchObject.QueryLimitError
            lblError.Text = Localization.GetString("NoMatchingRecordsError", LocalResourceFile)
            pnlResults.Visible = False
        End Sub

        Private Sub QueryLimitWarning(ByVal sender As Object, ByVal e As TIMSS.API.Core.QueryLimitWarningEventArgs) Handles moSearchObject.QueryLimitWarning
            lblError.Text = Localization.GetString("WarningCountLimit", LocalResourceFile).Replace("#no#", CStr(Settings("WarningCountLimit")))
            pnlResults.Visible = False
        End Sub


        Private Sub butExcel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butExcel.Click

            Dim _clsExport As New Personify.ApplicationManager.ExportExcel


            ExportData(ExportType.Excel)
        End Sub

        Private Sub butCVS_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butCVS.Click
            ExportData(ExportType.CSV)
        End Sub

        

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

#Region "Helper Functions"

        Private Sub BuildResults()

            Dim oResults As DataTable
            oResults = GetResultDataTable()

            oResults = moSearchObject.Results.ToTable
            If oResults.Rows.Count > 0 Then
                dpResults.MaxPages = CInt(Integer.MaxValue / dpResults.PageSize) - 1  'Parature: 3246-5758565
                dpResults.DataSource = oResults.Rows
                dpResults.DataBind()

                CurrentPage = dpResults.CurrentPage

                dpResults.DataSourcePaged.CurrentPageIndex = CurrentPage - 1
            End If
        End Sub

        Private Sub SearchResults()
            pnlResults.Visible = True
            Dim AllowSolicitationFlagDefined As Boolean = False
            Dim AllowEmailFlagDefined As Boolean = False
            Dim isImpersonation As Boolean = CheckImpersonation()



            Dim oResults As DataTable
            oResults = GetResultDataTable(AllowSolicitationFlagDefined, AllowEmailFlagDefined)

            If oResults.Rows.Count > 0 Then
                dpResults.MaxPages = CInt(Integer.MaxValue / dpResults.PageSize) - 1 'Parature: 3246-5758565
                dpResults.DataSource = oResults.Rows
                dpResults.DataBind()

                CurrentPage = dpResults.CurrentPage

                dpResults.DataSourcePaged.CurrentPageIndex = CurrentPage - 1

                'build the Result table header
                Dim tr As HtmlTableRow = New HtmlTableRow


                Dim propertiesT As ArrayList = GetSortedPropertyItems()

                Dim header As New ArrayList
                For Each propertyItem As PropertiesArray In propertiesT
                    If propertyItem.ShowInResults Then
                        Dim column As New HeaderColumns
                        With column
                            .Text = propertyItem.Text
                            .TextAlign = propertyItem.TextAlign
                            .ColumnWidth = propertyItem.ColumnWidth
                        End With
                        header.Add(column)
                    End If
                Next

                'Show Vcard column based on edit setting vcard flag
                If Settings("ShowVcardURL") IsNot Nothing AndAlso CStr(Settings("ShowVcardURL")) = "Y" Then
                    Dim VcardColumn As New HeaderColumns
                    With VcardColumn
                        .Text = "VCard"
                    End With
                    header.Add(VcardColumn)
                End If

                'Show Export options based on edit setting export flag
                If Settings("Export") IsNot Nothing Then
                    Select Case CStr(Settings("Export"))
                        Case "NONE"
                            PanelExportResult.Visible = False
                        Case "EXCELCSV"
                            PanelExportResult.Visible = True
                            butXML.Visible = False
                        Case "EXCEL"
                            PanelExportResult.Visible = True
                            butExcel.Visible = True
                            butCVS.Visible = False
                            butXML.Visible = False
                        Case "CSV"
                            PanelExportResult.Visible = True
                            butExcel.Visible = False
                            butCVS.Visible = True
                            butXML.Visible = False
                        Case "XML"
                            'Export as XML
                            PanelExportResult.Visible = True
                            butExcel.Visible = False
                            butCVS.Visible = False
                            butXML.Visible = True
                    End Select
                Else
                    PanelExportResult.Visible = False
                End If

                '3246-5747347 - Impersonation column
                If isImpersonation Then
                    Dim ImpersonationColumn As New HeaderColumns
                    With ImpersonationColumn
                        .Text = "Impersonation"
                    End With
                    header.Add(ImpersonationColumn)
                End If
                'END 3246-5747347

                Dim headerRow(header.Count - 1) As HeaderColumns
                Dim index As Integer = 0
                For Each h As HeaderColumns In header
                    headerRow(index) = h
                    index = index + 1
                Next



                Dim bodyRows As New ArrayList
                'build the Result body
                For Each dr As DataRow In dpResults.DataSourcePaged
                    Dim bRows As New BodyRows
                    Dim urlArguments As String = String.Empty
                    Dim urlArgumentsImpersonation As String = String.Empty

                    If Settings("DisplayResultsAsURL") IsNot Nothing AndAlso CStr(Settings("DisplayResultsAsURL")) = "Y" OrElse _
CheckImpersonationPropertiesSet() Then
                        For Each propertyItem As PropertiesArray In propertiesT

                            Dim propertyName As String = GetPropertyName(propertyItem.PropertyName, propertyItem.Collection)

                            If propertyItem.IncludePropertyAsQueryStringParameter Then
                                If Not IsDBNull(dr.Item(propertyName)) Then
                                    '5921903
                                    If propertyItem.QueryStringParameterName.ToUpper.Contains("MCID") OrElse propertyItem.QueryStringParameterName.ToUpper.Contains("SCID") Then
                                        'encrypte ids
                                        Dim encryptedId As String = Me.TIMSSURLEncryption(CStr(dr.Item(propertyName)))
                                        urlArguments = urlArguments & "&" & propertyItem.QueryStringParameterName & "=" & encryptedId
                                        urlArgumentsImpersonation = urlArgumentsImpersonation & "&" & propertyItem.QueryStringParameterName & "=" & encryptedId
                                    Else
                                        urlArguments = urlArguments & "&" & propertyItem.QueryStringParameterName & "=" & CStr(dr.Item(propertyName))
                                        urlArgumentsImpersonation = urlArgumentsImpersonation & "&" & propertyItem.QueryStringParameterName & "=" & CStr(dr.Item(propertyName))
                                    End If
                                End If
                            End If

                        Next
                    End If

                    Dim bodyColumns As New ArrayList
                    For Each propertyItem As PropertiesArray In propertiesT

                        Dim propertyName As String = GetPropertyName(propertyItem.PropertyName, propertyItem.Collection)

                        If propertyItem.ShowInResults Then
                            Dim bColumns As New BodyColumns
                            With bColumns
                                .Type = "Text"
                                .ColumnWidth = propertyItem.ColumnWidth
                                .TextAlign = propertyItem.TextAlign
                            End With
                            If propertyItem.UseAsEmailAddress AndAlso Settings("SendEmailEnabled") IsNot Nothing AndAlso CStr(Settings("SendEmailEnabled")) = "Y" AndAlso _
                                AllowEmailFlagDefined AndAlso AllowSolicitationFlagDefined Then
                                Dim link As String

                                If Not IsDBNull(dr.Item(propertyName)) Then
                                    bColumns.Type = "Email"

                                    Dim navigate As String = NavigateURL(CInt(Settings("SendEmailActionURL")), "", "EmailAddresses=" & CStr(dr.Item(propertyName)))
                                    Dim picture As String = GetEmailImageURL()
                                    link = "<a id=""" & Me.UniqueID & """ href=""" & navigate & """><img src=""" & picture & """ width=""16"" height=""16""></a>"
                                Else
                                    link = "-"
                                End If
                                bColumns.Text = link

                            ElseIf Settings("DisplayResultsAsURL") IsNot Nothing AndAlso CStr(Settings("DisplayResultsAsURL")) = "Y" Then

                                bColumns.Type = "Link"
                                Dim linkText As String
                                If Not IsDBNull(dr.Item(propertyName)) Then
                                    linkText = CStr(dr.Item(propertyName))
                                Else
                                    linkText = "-"
                                End If
                                Dim linkNavigateUrl As String
                                linkNavigateUrl = NavigateURL(CType(Settings("OnClickNavigatetoPage"), Integer), "", urlArguments)
                                bColumns.Text = "<a href=""" & linkNavigateUrl & """>" & linkText & "</a>"


                            Else
                                If Not IsDBNull(dr.Item(propertyName)) Then
                                    bColumns.Text = CStr(dr.Item(propertyName))
                                Else
                                    bColumns.Text = "-"
                                End If
                            End If

                            bodyColumns.Add(bColumns)
                        End If

                    Next

                    If Settings("ShowVcardURL") IsNot Nothing AndAlso CStr(Settings("ShowVcardURL")) = "Y" Then
                        'Add vcard body column
                        Dim VcardBodyColumn As New BodyColumns
                        VcardBodyColumn.Type = "Link"
                        Dim vCardNavigateUrl As String = NavigateURL(CType(Settings("VcardURLValue"), Integer), "", urlArguments)
                        Dim vCardIcon As String = GetVCardImageURL()
                        VcardBodyColumn.Text = "<a id=""" & Me.UniqueID & """ href=""" & vCardNavigateUrl & """><img src=""" & vCardIcon & """ width=""16"" height=""16""></a>"
                        bodyColumns.Add(VcardBodyColumn)
                        'end vcard body column
                    End If


                    '3246-5747347 - Impersonation column
                    If isImpersonation Then
                        'Dim lg As New Personify.WebUtility.LoginCustomer
                        'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)
                        Dim encryptedId As String = Me.TIMSSURLEncryption(MasterCustomerId)

                        urlArgumentsImpersonation = urlArgumentsImpersonation & "&lmcid=" & encryptedId
                        Dim ImpersonationBodyColumn As New BodyColumns
                        ImpersonationBodyColumn.Type = "Link"
                        Dim linkText As String
                        linkText = Localization.GetString("Impersonation", LocalResourceFile)
                        Dim linkNavigateUrl As String
                        linkNavigateUrl = NavigateURL(CType(Settings("AllowImpersonationActionURL"), Integer), "", urlArgumentsImpersonation)
                        ImpersonationBodyColumn.Text = "<a href=""" & linkNavigateUrl & """>" & linkText & "</a>"

                        bodyColumns.Add(ImpersonationBodyColumn)
                    End If
                    'END 3246-5747347


                    Dim cells(bodyColumns.Count - 1) As BodyColumns
                    index = 0
                    For Each bc As BodyColumns In bodyColumns
                        cells(index) = bc
                        index = index + 1
                    Next
                    bRows.Cells = cells
                    bodyRows.Add(bRows)
                Next


                Dim body(bodyRows.Count - 1) As BodyRows
                index = 0
                For Each b As BodyRows In bodyRows
                    body(index) = b
                    index = index + 1
                Next


                'Template
                Dim TemplateFile As String = "DynamicSearchResults.xsl"
                If Settings("Template") IsNot Nothing AndAlso CType(Settings("Template"), String) <> String.Empty Then
                    TemplateFile = CType(Settings("Template"), String)
                End If


                xslResults.XSLfile = Server.MapPath(ModulePath + "/Templates/" & TemplateFile)
                xslResults.AddObject("", headerRow)
                xslResults.AddObject("", body)
                xslResults.Display()
                'Export as XML
                If btnXMLPressed() Then
                    Response.Clear()
                    Response.ClearHeaders()
                    Response.ClearContent()
                    'Response.SuppressContent = True
                    'Response.Buffer = True
                    Response.ContentType = "application/octet-stream" '"text/xml"
                    Response.AddHeader("Content-Disposition", "attachment; filename=template.xml")
                    Response.AddHeader("Content-Length", CStr(xslResults.XMLString.Length))
                    Response.Write(xslResults.XMLString)

                    'Response.BufferOutput = True
                    Response.[End]()
                    'Response.Close()
                    'Response.Flush()
                End If

            Else
                lblError.Text = Localization.GetString("NoMatchingRecordsError", LocalResourceFile)
                pnlResults.Visible = False
            End If
        End Sub

        Private Function ReadSettings() As Boolean
            If Settings("AutomaticSearchEnabled") IsNot Nothing Then
                AutomaticSearchEnabled = CBool(IIf(CStr(Settings("AutomaticSearchEnabled")) = "Y", True, False))
                If Settings("HideSearchParameterSection") IsNot Nothing Then
                    HideSearchParameterSection = CBool(IIf(CStr(Settings("HideSearchParameterSection")) = "Y", True, False))
                Else
                    HideSearchParameterSection = False
                End If
            Else
                Return False
            End If

            If Settings("SearchCaption") IsNot Nothing Then
                SearchCaption = CStr(Settings("SearchCaption"))
            Else
                Return False
            End If
            If Settings("MaxRows") Is Nothing Then

                Return False
            End If

            If Settings("EnforceLimits") IsNot Nothing Then
                EnforceLimits = CBool(IIf(CStr(Settings("EnforceLimits")) = "Y", True, False))
            Else
                Return False
            End If

            If Settings("Namespace") IsNot Nothing Then
                PNamespace = CStr(Settings("Namespace"))
            Else
                Return False
            End If
            If Settings("Collection") IsNot Nothing Then
                Collection = CStr(Settings("Collection"))
            Else
                Return False
            End If

            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
            Properties = New Hashtable

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifyDynamicSearchSettings", ModuleId), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    Dim p As PropertiesArray
                    p = New PropertiesArray
                    p.PropertyName = CStr(oSiteData.Item("PropertyName"))
                    p.Collection = CStr(oSiteData.Item("Collection"))
                    p.ColumnWidth = CType(oSiteData.Item("ColumnWidth"), Integer)
                    p.DefaultValue = CStr(oSiteData.Item("DefaultValue"))
                    p.OperatorType = CStr(oSiteData.Item("OperatorType"))
                    p.RenderAs = CStr(oSiteData.Item("RenderAs"))
                    p.Required = CBool(oSiteData.Item("Required"))
                    p.ShowInQuery = CBool(oSiteData.Item("ShowInQuery"))
                    p.ShowInResults = CBool(oSiteData.Item("ShowInResults"))
                    p.SortDirection = CStr(oSiteData.Item("SortDirection"))
                    p.SortOrder = CInt(oSiteData.Item("SortOrder"))
                    p.Text = CStr(oSiteData.Item("Text"))
                    p.TextAlign = CStr(oSiteData.Item("TextAlign"))
                    p.Value = CStr(oSiteData.Item("Value"))
                    p.DisplayOrder = CInt(CStr(oSiteData.Item("DisplayOrder")))
                    p.IncludePropertyAsQueryStringParameter = CBool(CStr(oSiteData.Item("IncludePropertyAsQueryStringParameter")))
                    p.QueryStringParameterName = CStr(oSiteData.Item("QueryStringParameterName"))
                    p.UseAsEmailAddress = CBool(CStr(oSiteData.Item("UseAsEmailAddress")))
                    p.DisplayOrderForSearch = CInt(CStr(oSiteData.Item("DisplayOrderForSearch")))
                    p.PersonifyDynamicSearchSettingsID = CInt(CStr(oSiteData.Item("PersonifyDynamicSearchSettingsID")))
                    Properties.Add(String.Concat(p.PropertyName, p.PersonifyDynamicSearchSettingsID), p)

                End While
            Else
                Return False
            End If
            oSiteData.Close()
            oSiteData = Nothing
            Return True
        End Function

        Private Sub LoadSearchInterface()
            Dim pItem As DictionaryEntry
            Dim nextTR As Boolean = True
            Dim tr As New HtmlTableRow

            Dim comparer As DisplayOrderForSearchComparer = New DisplayOrderForSearchComparer
            Dim propertiesT As New ArrayList
            For Each pItem In Properties
                Dim propertyItem As PropertiesArray
                propertyItem = CType(pItem.Value, PropertiesArray)
                propertiesT.Add(propertyItem)
            Next
            propertiesT.Sort(comparer)

            For Each propertyItem As PropertiesArray In propertiesT
                'For Each pItem In Properties
                'Dim propertyItem As PropertiesArray
                'propertyItem = CType(pItem.Value, PropertiesArray)
                If propertyItem.ShowInQuery And (Not (propertyItem.RenderAs = "DatePicker" And propertyItem.Value = "01/01/2100")) Then
                    If propertyItem.Value = String.Empty Or AutomaticSearchEnabled Then

                        Dim value As String = String.Empty
                        Dim enablePropertyField As Boolean = True
                      
                        'start D00031513
                        If propertyItem.Value IsNot Nothing AndAlso propertyItem.Value.Trim <> "" Then
                            value = propertyItem.Value 'From the setting
                            enablePropertyField = False
                        ElseIf Me.CheckQueryParameterExists(propertyItem.QueryStringParameterName) Then
                            value = GetQueryStringValue(propertyItem.QueryStringParameterName)
                        ElseIf Me.CheckQueryParameterExists(propertyItem.PropertyName) Then
                            value = GetQueryStringValue(propertyItem.PropertyName)
                        End If
                        'end D00031513
                    

                        If nextTR Then
                            tr = New HtmlTableRow
                        End If
                        nextTR = Not nextTR
                        Dim td As HtmlTableCell
                        td = New HtmlTableCell
                        td.NoWrap = True
                        td.Attributes.Add("style", "width: 1%;")
                        Dim lblSearchCriteria As System.Web.UI.WebControls.Label = New System.Web.UI.WebControls.Label
                        If propertyItem.Text = String.Empty Then
                            lblSearchCriteria.Text = propertyItem.PropertyName
                        Else
                            lblSearchCriteria.Text = propertyItem.Text
                        End If
                        td.Controls.Add(lblSearchCriteria)
                        tr.Cells.Add(td)
                        td = New HtmlTableCell
                        Select Case propertyItem.RenderAs
                            Case "TextBox"
                                Dim txtSearchCriteria As System.Web.UI.WebControls.TextBox = New System.Web.UI.WebControls.TextBox()
                                txtSearchCriteria.ID = propertyItem.PropertyName + CType(propertyItem.PersonifyDynamicSearchSettingsID, String)
                                If Not QueryResultExist() Then
                                    txtSearchCriteria.Text = propertyItem.DefaultValue
                                End If
                                If value <> String.Empty Then 'propertyItem.Value <> String.Empty Then
                                    txtSearchCriteria.Text = value 'propertyItem.Value

                                    txtSearchCriteria.Enabled = enablePropertyField
                                End If
                                td.Controls.Add(txtSearchCriteria)
                            Case "TextBoxNumeric"
                                Dim txtSearchCriteria As System.Web.UI.WebControls.TextBox = New System.Web.UI.WebControls.TextBox()
                                txtSearchCriteria.ID = propertyItem.PropertyName + CType(propertyItem.PersonifyDynamicSearchSettingsID, String)
                                If Not QueryResultExist() Then
                                    txtSearchCriteria.Text = propertyItem.DefaultValue
                                End If
                                If value <> String.Empty Then 'propertyItem.Value <> String.Empty Then
                                    txtSearchCriteria.Text = value 'propertyItem.Value

                                    txtSearchCriteria.Enabled = enablePropertyField

                                End If
                                td.Controls.Add(txtSearchCriteria)
                                Dim valSearchCriteria As System.Web.UI.WebControls.RegularExpressionValidator = New System.Web.UI.WebControls.RegularExpressionValidator
                                valSearchCriteria.ID = "val" & propertyItem.PropertyName
                                valSearchCriteria.ControlToValidate = propertyItem.PropertyName
                                valSearchCriteria.ValidationExpression = "^(\d*)((,)(\d*))*$"
                                valSearchCriteria.ErrorMessage = Localization.GetString("NumericValueRequired", LocalResourceFile)
                                td.Controls.Add(valSearchCriteria)
                                'Case "ComboBox"
                                '    Dim drpSearchCriteria As System.Web.UI.WebControls.DropDownList = New System.Web.UI.WebControls.DropDownList
                                '    drpSearchCriteria.ID = propertyItem.PropertyName
                                '    'drpSearchCriteria.SelectedValue = propertyItem.DefaultValue
                                '    Dim namespaceName As String = propertyItem.Collection.Substring(0, propertyItem.Collection.IndexOf(CChar(".")))
                                '    Dim collectionName As String = propertyItem.Collection.Substring(propertyItem.Collection.IndexOf(CChar(".")) + 1)
                                '    'AN FIX
                                '    drpSearchCriteria.DataSource = GetDatasource(namespaceName, collectionName, propertyItem.PropertyName)
                                '    'drpSearchCriteria.DataSource = GetPropertiesDepth(namespaceName, collectionName, GetType(TIMSS.API.Core.IBusinessObjectCollection), propertyItem.PropertyName).List
                                '    drpSearchCriteria.DataTextField = "Description"
                                '    drpSearchCriteria.DataValueField = "Code"
                                '    drpSearchCriteria.DataBind()
                                '    If propertyItem.PropertyName = "CountryCode" And propertyItem.DefaultValue = String.Empty Then
                                '        drpSearchCriteria.SelectedValue = "USA"
                                '    Else
                                '        If Not QueryResultExist() Then
                                '            drpSearchCriteria.SelectedValue = propertyItem.DefaultValue
                                '        End If
                                '    End If

                                '    If value <> String.Empty Then 'propertyItem.Value <> String.Empty Then
                                '        drpSearchCriteria.SelectedValue = value 'propertyItem.Value                               
                                '        drpSearchCriteria.Enabled = enablePropertyField
                                '    End If
                                '    'TimssControls.Add(txtFirstName.ID, txtFirstName.ID)
                                '    td.Controls.Add(drpSearchCriteria)
                            Case "ComboBox"
                                Dim namespaceName As String = propertyItem.Collection.Substring(0, propertyItem.Collection.IndexOf(CChar(".")))
                                Dim collectionName As String = propertyItem.Collection.Substring(propertyItem.Collection.IndexOf(CChar(".")) + 1)

                                
                                Dim drpSearchCriteria As System.Web.UI.WebControls.DropDownList = New System.Web.UI.WebControls.DropDownList
                                drpSearchCriteria.ID = propertyItem.PropertyName + CType(propertyItem.PersonifyDynamicSearchSettingsID, String)
                                'drpSearchCriteria.SelectedValue = propertyItem.DefaultValue

                                'AN FIX - 3246-6976988 - added function getdatasource ... the GetPropertiesDepth function was too inefficient
                                drpSearchCriteria.DataSource = GetDatasource(namespaceName, collectionName, propertyItem.PropertyName)
                                'drpSearchCriteria.DataSource = GetPropertiesDepth(namespaceName, collectionName, GetType(TIMSS.API.Core.IBusinessObjectCollection), propertyItem.PropertyName).List
                                drpSearchCriteria.DataTextField = "Description"
                                drpSearchCriteria.DataValueField = "Code"
                                drpSearchCriteria.DataBind()
                                'drpSearchCriteria.Items.Add("")
                                drpSearchCriteria.Items.Insert(0, "")

                                If propertyItem.PropertyName = "CountryCode" And propertyItem.DefaultValue = String.Empty Then
                                    drpSearchCriteria.SelectedValue = "USA"
                                Else
                                    If Not QueryResultExist() Then
                                        drpSearchCriteria.SelectedValue = propertyItem.DefaultValue
                                    End If
                                End If

                                If value <> String.Empty Then 'propertyItem.Value <> String.Empty Then
                                    drpSearchCriteria.SelectedValue = value 'propertyItem.Value                               
                                    drpSearchCriteria.Enabled = enablePropertyField
                                Else
                                    drpSearchCriteria.SelectedValue = ""
                                End If


                                'TimssControls.Add(txtFirstName.ID, txtFirstName.ID)
                                td.Controls.Add(drpSearchCriteria)

                            Case "ComboBoxBoolean"
                                Dim drpSearchCriteria As System.Web.UI.WebControls.DropDownList = New System.Web.UI.WebControls.DropDownList
                                drpSearchCriteria.ID = propertyItem.PropertyName + CType(propertyItem.PersonifyDynamicSearchSettingsID, String)
                                'drpSearchCriteria.SelectedValue = propertyItem.DefaultValue
                                drpSearchCriteria.Items.Add(New ListItem("None", "None"))
                                drpSearchCriteria.Items.Add(New ListItem("Yes", "Y"))
                                drpSearchCriteria.Items.Add(New ListItem("No", "N"))
                                drpSearchCriteria.SelectedValue = "None"
                                If value <> String.Empty Then 'propertyItem.Value <> String.Empty Then
                                    drpSearchCriteria.SelectedValue = value 'propertyItem.Value

                                    drpSearchCriteria.Enabled = enablePropertyField
                                End If
                                td.Controls.Add(drpSearchCriteria)
                                'Case "RadioButtonList"
                                'Dim rdSearchCriteria As System.Web.UI.WebControls.RadioButtonList = New System.Web.UI.WebControls.RadioButtonList
                                'rdSearchCriteria.ID = propertyItem.PropertyName
                                'rdSearchCriteria.SelectedValue = propertyItem.DefaultValue

                                'Dim namespaceName As String = propertyItem.Collection.Substring(0, propertyItem.Collection.IndexOf(CChar(".")))
                                'Dim collectionName As String = propertyItem.Collection.Substring(propertyItem.Collection.IndexOf(CChar(".")) + 1)
                                'rdSearchCriteria.DataSource = GetPropertiesDepth(namespaceName, collectionName, GetType(TIMSS.API.Core.IBusinessObjectCollection), propertyItem.PropertyName).List
                                'rdSearchCriteria.DataTextField = "Description"
                                'rdSearchCriteria.DataValueField = "Code"
                                'rdSearchCriteria.DataBind()
                                'rdSearchCriteria.SelectedValue = propertyItem.DefaultValue
                                'If propertyItem.Value <> String.Empty Then
                                'rdSearchCriteria.SelectedValue = propertyItem.Value
                                'rdSearchCriteria.Enabled = False
                                'End If
                                'TimssControls.Add(txtFirstName.ID, txtFirstName.ID)
                                'td.Controls.Add(rdSearchCriteria)
                            Case "DatePicker"
                                If propertyItem.Value <> "01/01/2100" Then
                                    'Dim calSearchCriteria As System.Web.UI.WebControls.Calendar = New System.Web.UI.WebControls.Calendar
                                    'Dim calSearchCriteria As UserControls.CalendarCtrl = CType(LoadControl("~\controls\CalendarCtrl.ascx"), UserControls.CalendarCtrl)
                                    Dim calSearchCriteria As New Telerik.Web.UI.RadDatePicker
                                    calSearchCriteria.MinDate = "01/01/1900"
                                    calSearchCriteria.ID = propertyItem.PropertyName + CType(propertyItem.PersonifyDynamicSearchSettingsID, String)
                                    calSearchCriteria.EnableViewState = True
                                    If Not Me.QueryResultExist Then
                                        If propertyItem.DefaultValue <> String.Empty AndAlso IsDate(propertyItem.DefaultValue) Then
                                            'calSearchCriteria.SelectedDate = CDate(propertyItem.DefaultValue)
                                            'START 3246-5422015
                                            If propertyItem.DefaultValue = "02/02/2200" Then
                                                calSearchCriteria.SelectedDate = Date.Now
                                            Else
                                                calSearchCriteria.SelectedDate = propertyItem.DefaultValue
                                            End If
                                            'END 3246-5422015
                                        End If
                                    End If

                                    If value <> String.Empty Then 'propertyItem.Value <> String.Empty Then
                                        calSearchCriteria.SelectedDate = value 'propertyItem.Value

                                        'calSearchCriteria.Datetextbox.ReadOnly = enablePropertyField
                                        'calSearchCriteria.CalendarLink.Enabled = enablePropertyField

                                    End If

                                    td.Controls.Add(calSearchCriteria)
                                    td.NoWrap = True
                                    'td.Attributes.Add("style", "width: 40%;")
                                    tblSearch.Attributes.Add("style", "width: 100%;")
                                End If
                        End Select
                        tr.Cells.Add(td)
                        If nextTR Then
                            tblSearch.Rows.Add(tr)
                        End If
                    End If
                End If
            Next
            If Not nextTR Then
                tblSearch.Rows.Add(tr)
            End If

        End Sub

       
        Private Function GetPropertiesDepth(ByVal namespaceName As String, ByVal collection As String, ByVal InterfaceType As Type, ByVal PropertyName As String) As TIMSS.API.Core.ICode
            Dim oCodes As TIMSS.API.Core.ICode
            Dim oAsm As System.Reflection.Assembly
            Dim strPrefix As String
            Dim oType As Type
            Dim a As Integer
            Dim InterfaceName As String


            InterfaceName = InterfaceType.FullName
           
            For a = 0 To TIMSS.Global.App.TypeCache.Libraries.Count - 1
                oAsm = TIMSS.Global.App.TypeCache.Libraries(a).Assembly
                If Not oAsm Is Nothing Then
                    For Each oType In oAsm.GetTypes()
                        If oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") And namespaceName = "UserDefinedInfo" Then
                            Dim colArray() As String = collection.Split(CChar("."))
                            If colArray.Length >= 2 Then
                                strPrefix = "TIMSS.API.USER" & "." & colArray(0) & "." & colArray(1)
                            Else
                                strPrefix = "TIMSS.API.USER" & "." & collection
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper = strPrefix.ToUpper Then
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    oCodes = GetTypeProperties(oType, collection, PropertyName, namespaceName)
                                    Return oCodes
                                End If
                            End If
                        ElseIf Not oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") Then
                            If collection.IndexOf(".") >= 0 Then
                                strPrefix = namespaceName & "." & collection.Substring(0, collection.IndexOf("."))
                            Else
                                If collection = String.Empty Then
                                    strPrefix = namespaceName
                                Else
                                    strPrefix = namespaceName & "." & collection
                                End If
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper.EndsWith(strPrefix.ToUpper) Then
                                ' Assemblies generated from the Database Designer contain both the interfaces and the classes;
                                ' we check Not IsInterface because we only want to show the classes. 
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    oCodes = GetTypeProperties(oType, collection, PropertyName, namespaceName)
                                    Return oCodes
                                End If
                            End If
                        End If                        
                    Next
                End If
            Next


            Return Nothing
        End Function

        Private Function GetTypeProperties(ByVal oType As Type, ByVal collection As String, ByVal PropertyName As String, ByVal namespaceName As String) As TIMSS.API.Core.ICode
            Dim oCodes As TIMSS.API.Core.ICode


            Dim oProperties As Reflection.PropertyInfo() = oType.GetProperties()
            Dim objectToReturn As Reflection.PropertyInfo = Nothing

            Dim colArray() As String = collection.Split(CChar("."))
            collection = String.Empty
            For i As Integer = 1 To colArray.Length - 1
                If collection = String.Empty Then
                    collection = colArray(i)
                Else
                    collection = collection & "." & colArray(i)
                End If
            Next

            Dim UserDefinedinfo As Boolean = False
            If namespaceName = "UserDefinedInfo" Then
                UserDefinedinfo = True
            End If

            For Each Item As Reflection.PropertyInfo In oProperties
                If (Item.Name = "Item") Then
                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        ''AN FIX - 3246-6976988 - 
                        'Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        Dim oPropertiesItem As Reflection.PropertyInfo() = TIMSS.Global.App.GetAPITypeForInterface(Item.PropertyType).GetProperties()

                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If p.Name = PropertyName Then
                                If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                    'Dim parentInstance As TIMSS.API.Core.BusinessObjectCollection = CType(oType.Assembly.CreateInstance(oType.FullName), TIMSS.API.Core.BusinessObjectCollection)
                                    'Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                    Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(oType)
                                    Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)

                                    oCodes = instance.GetCodeInfo(CType(instance.Schema(PropertyName), TIMSS.API.Core.ICodePropertyInfo))
                                    Return oCodes
                                    'Else
                                    'oCodes = GetTypeProperties(Item.PropertyType, collection, PropertyName, namespaceName)
                                    'Return oCodes
                                End If
                            ElseIf p.Name = collection Then
                                oCodes = GetTypeProperties(Item.PropertyType, collection, PropertyName, namespaceName)
                                Return oCodes
                            ElseIf p.Name = colArray(0) Or (colArray.Length >= 3 AndAlso (p.Name = colArray(2) And UserDefinedinfo)) Then
                                oCodes = GetTypeProperties(p.PropertyType, collection, PropertyName, namespaceName)
                                Return oCodes
                            ElseIf collection.IndexOf(p.Name & ".") = 0 Then
                                oCodes = GetTypeProperties(p.PropertyType, collection.Substring(p.Name.Length + 1), PropertyName, namespaceName)
                                Return oCodes
                            End If
                        Next
                    End If
                ElseIf (Item.Name = colArray(0)) Or (colArray.Length >= 2 AndAlso (Item.Name = colArray(1) And UserDefinedinfo)) Then

                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If (p.Name = "Item") Then
                                Dim oPropertiesItem1 As Reflection.PropertyInfo() = p.PropertyType.GetProperties()
                                For Each p1 As Reflection.PropertyInfo In oPropertiesItem1
                                    If p1.Name = PropertyName Then

                                        If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                            'Dim parentInstance As TIMSS.API.Core.BusinessObjectCollection = CType(oType.Assembly.CreateInstance(oType.FullName), TIMSS.API.Core.BusinessObjectCollection)

                                            'Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = TIMSS.Global.GetCollection(Personify.ApplicationManager.Commons.PersonifyOrgId_Get, Personify.ApplicationManager.Commons.PersonifyOrgUnitId_Get,oType)
                                            Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(p.ReflectedType)
                                            Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                            oCodes = instance.GetCodeInfo(CType(instance.Schema(PropertyName), TIMSS.API.Core.ICodePropertyInfo))
                                            Return oCodes
                                        Else
                                            oCodes = GetTypeProperties(p.PropertyType, collection, PropertyName, namespaceName)
                                            'oCodes = GetTypeProperties(oType, collection, PropertyName)
                                            Return oCodes
                                        End If
                                    ElseIf p1.Name = collection Then
                                        oCodes = GetTypeProperties(p.PropertyType, collection, PropertyName, namespaceName)
                                        Return oCodes
                                    ElseIf collection.IndexOf(p1.Name & ".") = 0 Then
                                        oCodes = GetTypeProperties(p.PropertyType, collection.Substring(p1.Name.Length + 1), PropertyName, namespaceName)
                                        Return oCodes
                                    End If
                                Next
                                '5926088
                            ElseIf p.Name = PropertyName Then
                                If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then

                                    Dim parentInstance As TIMSS.API.Core.IBusinessObjectCollection = PersonifyGetCollection(TIMSS.Global.GetItem(p.ReflectedType).ContainerType)
                                    Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                    oCodes = instance.GetCodeInfo(CType(instance.Schema(PropertyName), TIMSS.API.Core.ICodePropertyInfo))
                                    Return oCodes
                                End If
                                'end 5926088
                            End If
                        Next

                    End If
                End If

            Next
            Return Nothing
        End Function

        Private Function GetCollectionDepth(ByVal namespaceName As String, ByVal collection As String, ByVal InterfaceType As Type) As TIMSS.API.Core.IBusinessObjectCollection
            Dim oAsm As System.Reflection.Assembly
            Dim strPrefix As String
            Dim oType As Type
            Dim a As Integer
            Dim InterfaceName As String


            InterfaceName = InterfaceType.FullName

            For a = 0 To TIMSS.Global.App.TypeCache.Libraries.Count - 1
                oAsm = TIMSS.Global.App.TypeCache.Libraries(a).Assembly
                If Not oAsm Is Nothing Then
                    For Each oType In oAsm.GetTypes()
                        If oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") And namespaceName = "UserDefinedInfo" Then
                            Dim colArray() As String = collection.Split(CChar("."))
                            If colArray.Length >= 2 Then
                                strPrefix = "TIMSS.API.USER" & "." & colArray(0) & "." & colArray(1)
                            Else
                                strPrefix = "TIMSS.API.USER" & "." & collection
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper = strPrefix.ToUpper Then
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    Return GetTypeCollection(oType, collection, namespaceName)
                                End If
                            End If
                        ElseIf Not oType.FullName.ToUpper.StartsWith("TIMSS.API.USER.") Then
                            If collection.IndexOf(".") >= 0 Then
                                strPrefix = namespaceName & "." & collection.Substring(0, collection.IndexOf("."))
                            Else
                                If collection = String.Empty Then
                                    strPrefix = namespaceName
                                Else
                                    strPrefix = namespaceName & "." & collection
                                End If
                            End If
                            If oType.FullName.ToUpper.Contains(strPrefix.ToUpper & ".") Or oType.FullName.ToUpper.EndsWith(strPrefix.ToUpper) Then
                                ' Assemblies generated from the Database Designer contain both the interfaces and the classes;
                                ' we check Not IsInterface because we only want to show the classes. 
                                If Not oType.IsInterface AndAlso Not oType.GetInterface(InterfaceName) Is Nothing Then
                                    Return GetTypeCollection(oType, collection, namespaceName)
                                End If
                            End If
                        End If                        
                    Next
                End If
            Next


            Return Nothing
        End Function

        Private Function GetTypeCollection(ByVal oType As Type, ByVal collection As String, ByVal namespaceName As String) As TIMSS.API.Core.IBusinessObjectCollection

            Dim oProperties As Reflection.PropertyInfo() = oType.GetProperties()
            Dim objectToReturn As Reflection.PropertyInfo = Nothing

            Dim colArray() As String = collection.Split(CChar("."))
            collection = String.Empty

            For i As Integer = 1 To colArray.Length - 1
                If collection = String.Empty Then
                    collection = colArray(i)
                Else
                    collection = collection & "." & colArray(i)
                End If

            Next
            Dim UserDefinedinfo As Boolean = False
            If namespaceName = "UserDefinedInfo" Then
                UserDefinedinfo = True
            End If
            For Each Item As Reflection.PropertyInfo In oProperties
                If (Item.Name = "Item") Then
                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        For Each p As Reflection.PropertyInfo In oPropertiesItem
                            If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                                Dim parentInstance As TIMSS.API.Core.BusinessObjectCollection = CType(oType.Assembly.CreateInstance(oType.FullName), TIMSS.API.Core.BusinessObjectCollection)
                                'Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                                Return parentInstance
                            Else
                                Return GetTypeCollection(Item.PropertyType, collection, namespaceName)
                            End If
                        Next
                        Return Nothing
                    End If
                ElseIf (Item.Name = colArray(0)) Or (colArray.Length >= 2 AndAlso (Item.Name = colArray(1) And UserDefinedinfo)) Then

                    If Item.PropertyType IsNot GetType(TIMSS.API.Core.IBusinessObject) Then
                        'Dim oPropertiesItem As Reflection.PropertyInfo() = Item.PropertyType.GetProperties()
                        'For Each p As Reflection.PropertyInfo In oPropertiesItem
                        'If (p.Name = "Item") Then
                        'Dim oPropertiesItem1 As Reflection.PropertyInfo() = p.PropertyType.GetProperties()
                        'For Each p1 As Reflection.PropertyInfo In oPropertiesItem1
                        If collection = String.Empty Or (colArray.Length = 2 And UserDefinedinfo) Then
                            Dim parentInstance As TIMSS.API.Core.BusinessObjectCollection = CType(Item.PropertyType.Assembly.CreateInstance(Item.PropertyType.FullName), TIMSS.API.Core.BusinessObjectCollection)
                            'Dim instance As TIMSS.API.Core.BusinessObject = CType(parentInstance.AddNew(), TIMSS.API.Core.BusinessObject)
                            Return parentInstance

                        Else
                            Return GetTypeCollection(Item.PropertyType, collection, namespaceName)
                        End If
                        'Next
                        'Return Nothing
                        'End If
                        'Next

                    End If
                End If

            Next
            Return Nothing
        End Function

        Private Function ImplementsInterface(ByVal ClassType As Type, ByVal InterfaceType As Type) As Boolean
            Return (ClassType Is InterfaceType) OrElse Not (ClassType.GetInterface(InterfaceType.FullName) Is Nothing)
        End Function

        Private Function IsCollection(ByVal ItemType As Type) As Boolean
            Return ImplementsInterface(ItemType, GetType(TIMSS.API.Core.IBusinessObjectCollection))
        End Function

        Private Function IsItem(ByVal ItemType As Type) As Boolean
            Return ImplementsInterface(ItemType, GetType(TIMSS.API.Core.IBusinessObject))
        End Function

        Private Function IsCode(ByVal ItemType As Type) As Boolean
            Return ImplementsInterface(ItemType, GetType(TIMSS.API.Core.ICode))
        End Function

        Private Function IsValue(ByVal ItemType As Type) As Boolean
            Return Not (IsCollection(ItemType) OrElse IsItem(ItemType) OrElse IsCode(ItemType))
        End Function
        Private Function CheckImpersonationPropertiesSet() As Boolean
            Dim isImpersonationChecked As Boolean = False

            If Settings("AllowImpersonation") IsNot Nothing AndAlso CType(Settings("AllowImpersonation"), String) = "Y" Then
                If Settings("AllowImpersonationActionURL") IsNot Nothing Then
                    isImpersonationChecked = True
                End If
            End If

            Return (isImpersonationChecked)

        End Function

        '3246-5747347
        Private Function CheckImpersonation() As Boolean
            Dim isStaff As Boolean = False
            Dim isImpersonationChecked As Boolean = False
            Dim isMCIDProperty As Boolean = False
            Dim isSCIDProperty As Boolean = False
            Dim isLabelNameProperty As Boolean = False

            Dim role As String
            role = Me.GetUserRole(UserInfo)
            If role = "personifyuser" Or role = "personifyadmin" Then
                Dim oRoleCtrl As New DotNetNuke.Security.Roles.RoleController
                Dim oPersonifyRoles() As String
                oPersonifyRoles = oRoleCtrl.GetRolesByUser(UserId, PortalId)
                If oPersonifyRoles IsNot Nothing AndAlso oPersonifyRoles.Length > 0 Then
                    For Each oPersonifyRole As String In oPersonifyRoles
                        If oPersonifyRole = "PersonifyStaff" Then
                            isStaff = True
                        End If
                    Next
                End If
            End If

            'If Settings("AllowImpersonation") IsNot Nothing AndAlso CType(Settings("AllowImpersonation"), String) = "Y" Then
            '    If Settings("AllowImpersonationActionURL") IsNot Nothing Then
            isImpersonationChecked = CheckImpersonationPropertiesSet()
            '    End If
            'End If

            Dim pItem As DictionaryEntry
            For Each pItem In Properties
                Dim propertyItem As PropertiesArray
                propertyItem = CType(pItem.Value, PropertiesArray)
                If propertyItem.PropertyName = "MasterCustomerId" Then
                    If propertyItem.QueryStringParameterName = "mcid" AndAlso propertyItem.ShowInResults = True Then
                        isMCIDProperty = True
                    End If
                End If
                If propertyItem.PropertyName = "SubCustomerId" Then
                    If propertyItem.QueryStringParameterName = "scid" AndAlso propertyItem.ShowInResults = True Then
                        isSCIDProperty = True
                    End If
                End If
                If propertyItem.PropertyName = "LabelName" Then
                    If propertyItem.QueryStringParameterName = "labelname" AndAlso propertyItem.ShowInResults = True Then
                        isLabelNameProperty = True
                    End If
                End If
            Next
            If isStaff And isImpersonationChecked And isMCIDProperty And isSCIDProperty And isLabelNameProperty Then
                Return True
            Else
                Return False
            End If
        End Function
        'END 3246-5747347

        '3246-5774803
        Private Function GetEmailImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/emailicon.gif")
        End Function
        Private Function GetVCardImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/icon_vcard.gif")
        End Function
        'END 3246-5774803
#End Region

#Region "Added helper functions"
        'AN FIX - 3246-6976988
        Private Function GetDatasource(ByVal NameSp As String, ByVal pcollection As String, ByVal PropName As String) As TIMSS.API.Core.CodeList

            Dim oBOC As TIMSS.API.Core.IBusinessObjectCollection
            Dim PropertyInfo As TIMSS.API.Core.IPropertyInfo
            Dim strCode As String = ""
            Dim strSubSystem As String = ""

            Dim Code As ICode
            'Get the collection based on teh global setting
            oBOC = PersonifyGetCollection(String.Format("{0}.{1}", PNamespace, Collection))
            oBOC.AddNew()

            Dim strPropertyPath As String = String.Empty

            Dim int As Integer
            int = pcollection.Split(".").Length
            If int > 1 Then
                strPropertyPath = String.Concat(pcollection.Split(".")(int - 1), ".", PropName)
            Else
                strPropertyPath = PropName
            End If

            PropertyInfo = oBOC.Schema.Find(strPropertyPath)

            If PropertyInfo.PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then



                With CType(PropertyInfo, ICodePropertyInfo)

                    Dim arg() As Object = New Object() {New TIMSS.API.Core.BusinessContext(OrganizationId, OrganizationUnitId)}

                    Code = .Type.Assembly.CreateInstance(.Type.FullName, False, Reflection.BindingFlags.CreateInstance, Nothing, arg, Nothing, Nothing)

                    For Each CodeParameter As ICodeParameter In .Parameters
                        Code.Parameters.Add(CodeParameter)
                    Next
                    'Code.FillList()
                End With
            End If


            Return Code.List

        End Function

        'AN FIX - 3246-6976988
        Private Function GetTargetCollection(ByVal NameSp As String, ByVal collection As String) As TIMSS.API.Core.IBusinessObjectCollection


            Dim oBOC As TIMSS.API.Core.IBusinessObjectCollection

            oBOC = PersonifyGetCollection(NameSp + "." + collection)

            Return oBOC


        End Function

        Private Function GetResultDataTable(Optional ByRef AllowSolicitationFlagDefined As Boolean = False, Optional ByRef AllowEmailFlagDefined As Boolean = False) As DataTable

            moSearchObject = New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            Dim tmpResult As DataTable

            Dim oParm As TIMSS.API.Core.SearchProperty

            moSearchObject = New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)

            'Target Collection, Enforce Limits, Warning Limit, Error Limit will come from EDIT Settings. 

            ''AN FIX - 3246-6976988
            moSearchObject.Target = GetTargetCollection(PNamespace, Collection)
            'moSearchObject.Target = GetCollectionDepth(PNamespace, Collection, GetType(TIMSS.API.Core.IBusinessObjectCollection))

            moSearchObject.ErrorLimit = CInt(Settings("MaxRows"))
            moSearchObject.WarningLimit = CInt(Settings("MaxRows"))
            If Settings("EnforceLimits") IsNot Nothing Then
                moSearchObject.EnforceLimits = CBool(IIf(CStr(Settings("EnforceLimits")) = "Y", True, False))
            End If

            'Based on the properties set in the EDIT Settings, following Search Object Parameters will be declared for each property 
            Dim pItem As DictionaryEntry
            For Each pItem In Properties
                Dim propertyItem As PropertiesArray
                propertyItem = CType(pItem.Value, PropertiesArray)
                Dim propertyName As String = GetPropertyName(propertyItem.PropertyName, propertyItem.Collection)

                If propertyName = "AllowSolicitationFlag" Then
                    AllowSolicitationFlagDefined = True
                End If
                If propertyName = "AllowEmailFlag" Then
                    AllowEmailFlagDefined = True
                End If

                oParm = New TIMSS.API.Core.SearchProperty(propertyName)
                For Each operatorT As String In [Enum].GetNames(GetType(TIMSS.Enumerations.QueryOperatorEnum))
                    If operatorT = propertyItem.OperatorType Then
                        oParm.Operator = CType([Enum].Parse(GetType(TIMSS.Enumerations.QueryOperatorEnum), operatorT), TIMSS.Enumerations.QueryOperatorEnum)
                        Exit For
                    End If
                Next

                oParm.Caption = propertyItem.Text
                oParm.ShowInQuery = propertyItem.ShowInQuery
                oParm.Required = propertyItem.Required
                oParm.ShowInResults = True 'propertyItem.ShowInResults Or propertyItem.IncludePropertyAsQueryStringParameter
                Select Case propertyItem.SortDirection
                    Case "Ascending"
                        oParm.SortDirection = TIMSS.Enumerations.SortDirection.Ascending
                    Case "Descending"
                        oParm.SortDirection = TIMSS.Enumerations.SortDirection.Descending
                End Select

                oParm.SortOrder = propertyItem.SortOrder

                If propertyItem.ShowInQuery Then

                    If Me.CheckQueryParameterExists(propertyItem.QueryStringParameterName) AndAlso propertyItem.Value.Trim = "" Then
                        oParm.Value = GetQueryStringValue(propertyItem.QueryStringParameterName)
                    Else
                        oParm.Value = GetPropertyValue(propertyItem.RenderAs, propertyItem.PropertyName, propertyItem.Value, propertyItem.PersonifyDynamicSearchSettingsID)
                    End If

                End If
                oParm.Value = oParm.Value.ToString.Replace("'", "''")
                moSearchObject.Parameters.Add(oParm)
            Next

            moSearchObject.Search()

            tmpResult = moSearchObject.Results.ToTable

            Return tmpResult
        End Function

        Private Function GetSortedPropertyItems() As ArrayList

            'Get sorted propertyname
            Dim pItem As DictionaryEntry
            Dim comparer As PropertiesArrayComparer = New PropertiesArrayComparer
            Dim propertiesT As New ArrayList
            For Each pItem In Properties
                Dim propertyItem As PropertiesArray
                propertyItem = CType(pItem.Value, PropertiesArray)
                propertiesT.Add(propertyItem)
            Next
            propertiesT.Sort(comparer)

            Return propertiesT
        End Function

        Private Function TIMSSURLEncryption(ByVal value As String, Optional ByVal decrypt As Boolean = False) As String
            Dim result As String = ""

            If Not decrypt Then
                result = TIMSS.Common.Encryption.Encrypt(value)
                result = Replace(Server.UrlEncode(result), "", "+")
            Else
                result = TIMSS.Common.Encryption.Decrypt(value)
            End If

            Return result
        End Function

        Private Function GetPropertyValue(ByVal renderAs As String, ByVal propertyName As String, ByVal propertyValue As String, ByVal PersonifyDynamicSearchSettingsID As Long) As String
            Return GetPropertyValue(renderAs, propertyName + CType(PersonifyDynamicSearchSettingsID, String), propertyValue)
        End Function

        Private Function GetPropertyValue(ByVal renderAs As String, ByVal propertyName As String, ByVal propertyValue As String) As String
            Dim value As String = ""

            'START 3246-5422015 - fixed the string comparsion for datepicker
            If renderAs.ToUpper <> "DATEPICKER" AndAlso propertyValue IsNot Nothing AndAlso propertyValue.Trim <> "" Then
                Return propertyValue
            End If
            'END 3246-5422015 

            Select Case renderAs
                Case "TextBox"
                    If CType(FindControl(propertyName), TextBox) IsNot Nothing Then
                        value = CType(FindControl(propertyName), TextBox).Text
                    End If
                Case "TextBoxNumeric"
                    If CType(FindControl(propertyName), TextBox) IsNot Nothing Then
                        value = CType(FindControl(propertyName), TextBox).Text
                    End If
                Case "ComboBox"
                    If CType(FindControl(propertyName), DropDownList) IsNot Nothing Then
                        value = CType(FindControl(propertyName), DropDownList).SelectedValue
                    End If
                Case "ComboBoxBoolean"
                    If CType(FindControl(propertyName), DropDownList) IsNot Nothing Then
                        value = CType(FindControl(propertyName), DropDownList).SelectedValue
                    End If
                    'Case "RadioButtonList"
                    '    oParm.Value = CType(FindControl(propertyItem.PropertyName), RadioButtonList).SelectedValue
                Case "DatePicker"
                    If propertyValue IsNot Nothing AndAlso (propertyValue = "01/01/2100") Then
                        value = Date.Now.ToShortDateString
                    Else
                        If CType(FindControl(propertyName), Telerik.Web.UI.RadDatePicker) IsNot Nothing Then
                            If Not CType(FindControl(propertyName), Telerik.Web.UI.RadDatePicker).IsEmpty Then


                                value = CType(FindControl(propertyName), Telerik.Web.UI.RadDatePicker).SelectedDate
                            End If
                        End If
                    End If
            End Select



            Return value
        End Function

        Private Function GetPropertyName(ByVal propertyName As String, ByVal propertyCollection As String) As String

            Dim colArray() As String = propertyCollection.Split(CChar("."))
            Dim i As Integer = colArray.Length - 1
            If propertyCollection.IndexOf("UserDefinedInfo.") >= 0 Then
                While i >= 3
                    propertyName = colArray(i) & "." & propertyName
                    i = i - 1
                End While
            Else
                While i >= 2
                    propertyName = colArray(i) & "." & propertyName
                    i = i - 1
                End While
            End If
            Return propertyName

        End Function

        Private Function QueryResultExist() As Boolean

            'Use value T to display the result. Otherwise false
            If Request(_DisplayResultQuerystringName) IsNot Nothing AndAlso Request(_DisplayResultQuerystringName).ToUpper = "T" Then
                Return True
            End If

            Return False
        End Function

        Private Function GetQueryStringValue(ByVal key As String, Optional ByVal decryptValue As Boolean = True) As String
            Dim value As String = ""
            If Request(key) IsNot Nothing Then
                value = Request(key)
                '5921903
                If (key.ToUpper.Contains("MCID") OrElse key.ToUpper.Contains("SCID")) AndAlso decryptValue Then
                    value = TIMSSURLEncryption(value, True)
                End If
            End If
            Return value
        End Function

        Private Sub BuildResultQueryString(ByRef strParameters As System.Text.StringBuilder, ByVal key As String, ByVal value As String)

            'Do not build the result if value is empty
            If value Is Nothing OrElse value = "" Then
                Exit Sub
            End If


            strParameters.Append("&")
            strParameters.Append(key)
            strParameters.Append("=")
            strParameters.Append(Replace(Server.UrlEncode(value), "", "+"))

        End Sub

        Private Function CheckQueryParameterExists(ByVal parameterName As String) As Boolean
            If Request(parameterName) IsNot Nothing Then
                Return True
            End If

            Return False
        End Function

        Private Sub RedirectWithParameters()



            Dim strParameters As New System.Text.StringBuilder
            BuildResultQueryString(strParameters, _DisplayResultQuerystringName, "T") 'T reprsents value to process the result query


            Dim pItem As DictionaryEntry
            For Each pItem In Properties
                Dim propertyItem As PropertiesArray
                propertyItem = CType(pItem.Value, PropertiesArray)

                Dim propertyName As String = GetPropertyName(propertyItem.PropertyName, propertyItem.Collection)

                If propertyItem.ShowInQuery Then

                    Dim Parameter As String = propertyItem.QueryStringParameterName
                    '3246-6400434

                    If (CheckQueryParameterExists(propertyItem.QueryStringParameterName) And GetPropertyValue(propertyItem.RenderAs, propertyItem.PropertyName, propertyItem.Value, propertyItem.PersonifyDynamicSearchSettingsID) <> String.Empty) Then
                        If GetPropertyValue(propertyItem.RenderAs, propertyItem.PropertyName, propertyItem.Value, propertyItem.PersonifyDynamicSearchSettingsID) = GetQueryStringValue(Parameter, False) Then
                            BuildResultQueryString(strParameters, Parameter.ToLower, _
                             GetQueryStringValue(Parameter, False))
                        Else
                            Dim value As String
                            value = GetPropertyValue(propertyItem.RenderAs, propertyItem.PropertyName, propertyItem.Value, propertyItem.PersonifyDynamicSearchSettingsID)
                            BuildResultQueryString(strParameters, propertyItem.PropertyName, value)
                        End If
                    Else
                        Dim value As String
                        value = GetPropertyValue(propertyItem.RenderAs, propertyItem.PropertyName, propertyItem.Value, propertyItem.PersonifyDynamicSearchSettingsID)
                        BuildResultQueryString(strParameters, propertyItem.PropertyName, value)
                    End If

                    'end 3246-6400434
                End If

            Next

            Dim returnString As String = NavigateURL(TabId, "", strParameters.ToString)
            Response.Redirect(returnString, True)
        End Sub

        Private Sub ExportData(ByVal exportType As ExportType)

            Dim oResults As DataTable = GetResultDataTable()
            Dim oExport As New Personify.ApplicationManager.ExportExcel

            If oResults.Rows.Count > 0 Then

                Dim fileName As String = "Results_" & Date.Now.ToShortDateString.Replace("/", "-")
                Dim indexColumnArrary As New Generic.List(Of Integer)
                Dim displayColumnArrary As New Generic.List(Of String)

                Dim propertiesT As ArrayList = GetSortedPropertyItems()
                For i As Integer = 0 To propertiesT.Count - 1
                    Dim propertyItem As PropertiesArray = CType(propertiesT(i), PropertiesArray)
                    If propertyItem.ShowInResults Then
                        Dim propertyName As String = GetPropertyName(propertyItem.PropertyName, propertyItem.Collection)
                        If oResults.Columns(propertyName) IsNot Nothing Then
                            indexColumnArrary.Add(oResults.Columns(propertyName).Ordinal)
                            displayColumnArrary.Add(propertyItem.Text)
                        End If
                    End If
                Next

                Select Case exportType
                    Case exportType.CSV
                        oExport.ExportData(oResults, indexColumnArrary.ToArray, displayColumnArrary.ToArray, exportType.CSV, fileName & ".csv")
                    Case exportType.Excel
                        oExport.ExportData(oResults, indexColumnArrary.ToArray, displayColumnArrary.ToArray, exportType.Excel, fileName & ".xls")
                End Select


            End If
        End Sub

        Private Function btnXMLPressed() As Boolean
            Dim value As Boolean = False

            For Each key As String In Request.Params.AllKeys
                If key IsNot Nothing AndAlso key.IndexOf("butXML") >= 0 Then
                    value = True
                    Exit For
                End If
            Next

            Return value
        End Function
#End Region

#Region "MISC Class"
        Class HeaderColumns
            Public Text As String
            Public TextAlign As String
            Public ColumnWidth As Integer
        End Class

        Class BodyColumns
            Public Type As String
            Public Text As String
            Public TextAlign As String
            Public ColumnWidth As Integer
        End Class

        Class BodyRows
            Public Cells() As BodyColumns
        End Class
#End Region







        'Public Sub ExportToExcelHTML(ByVal name As String)

        '    Response.Clear()
        '    Response.AddHeader("content-disposition", "attachment filename=abc.xls")

        '    Response.Charset = ""

        '    Response.Cache.SetCacheability(HttpCacheability.NoCache)

        '    'Response.ContentType = "application/vnd.xls"
        '    Response.ContentType = "application/vnd.ms-excel"

        '    Dim outputWrite As System.IO.StringWriter = New System.IO.StringWriter
        '    Dim outputHtmlWrite As System.Web.UI.HtmlTextWriter = New HtmlTextWriter(outputWrite)

        '    'xslResults.RenderControl(")
        '    Me.dpResults.RenderControl(outputHtmlWrite)

        '    Response.Write(outputWrite.ToString())

        '    Response.End()

        'End Sub

        'Public Shared Sub ExportToSpreadsheet(ByVal table As DataTable, ByVal name As String)
        '    Dim context As HttpContext = HttpContext.Current
        '    context.Response.Clear()
        '    For Each column As DataColumn In Table.Columns
        '        context.Response.Write(column.ColumnName + ";")
        '    Next
        '    context.Response.Write(Environment.NewLine)
        '    For Each row As DataRow In Table.Rows
        '        For i As Integer = 0 To Table.Columns.Count - 1
        '            context.Response.Write(row(i).ToString().Replace(";", String.Empty) + ";")
        '        Next
        '        context.Response.Write(Environment.NewLine)
        '    Next
        '    context.Response.ContentType = "text/csv"
        '    context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + name + ".csv")
        '    context.Response.[End]()
        'End Sub



    End Class

End Namespace



