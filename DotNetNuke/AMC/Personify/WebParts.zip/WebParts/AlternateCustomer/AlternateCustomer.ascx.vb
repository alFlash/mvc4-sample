Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Namespace Personify.DNN.Modules.AlternateCustomer

    Public MustInherit Class AlternateCustomer
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable
        Private Class LoginCustomer
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
            Public LabelName As String
            Public isLoggedin As Boolean
        End Class

#Region "Controls"
        Protected WithEvents ClearButton As LinkButton
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Request.QueryString("mcid") IsNot Nothing AndAlso Request.QueryString("scid") IsNot Nothing AndAlso Request.QueryString("labelname") IsNot Nothing Then
                    '3246-5747347 - impersonate when coming from DynamicSearch
                    Dim lgtemp As New LoginCustomer

                    Dim strQueryString As String = Request.Url.Query
                    Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                    Dim strQueryParam As String

                    Dim LoggedMCID As String = String.Empty
                    For Each strQueryParam In arrQueryString
                        If strQueryParam.IndexOf("mcid") <> -1 And strQueryParam.IndexOf("lmcid") = -1 Then
                            Dim MasterCustomerId As String = strQueryParam.Replace("mcid=", "")
                            lgtemp.MasterCustomerId = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(MasterCustomerId))
                        ElseIf strQueryParam.IndexOf("scid") <> -1 Then
                            Dim SubCustomerId As String = strQueryParam.Replace("scid=", "")
                            lgtemp.SubCustomerId = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(SubCustomerId))
                        ElseIf strQueryParam.IndexOf("lmcid") <> -1 Then
                            LoggedMCID = strQueryParam.Replace("lmcid=", "")
                            LoggedMCID = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(LoggedMCID))
                        ElseIf strQueryParam.IndexOf("labelname") <> -1 Then
                            lgtemp.LabelName = Server.UrlDecode(strQueryParam.Replace("labelname=", ""))
                        End If
                    Next

                    If LoggedMCID = MasterCustomerId Then
                        SaveStaffCustomer(lgtemp)
                    End If
                    'END 3246-5747347 - impersonate when coming from DynamicSearch
                Else
                    Dim role As String
                    role = Me.GetUserRole(UserInfo)
                    If role = "personifyuser" Or role = "personifyadmin" Then
                        Dim isStaff As Boolean = False
                        Dim oRoleCtrl As New DotNetNuke.Security.Roles.RoleController
                        Dim oPersonifyRoles() As String
                        oPersonifyRoles = oRoleCtrl.GetRolesByUser(UserId, PortalId)
                        If oPersonifyRoles IsNot Nothing AndAlso oPersonifyRoles.Length > 0 Then
                            For Each oPersonifyRole As String In oPersonifyRoles
                                If oPersonifyRole = "PersonifyStaff" Then
                                    isStaff = True
                                End If
                            Next
                        End If

                        If isStaff = False Then
                            SaveStaffCustomer(Nothing)
                        End If
                    Else
                        DisplayUserAccessMessage(role)
                        
                    End If
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub ClearButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClearButton.Click
            SaveStaffCustomer(Nothing)
        End Sub

#Region "Personify Data"
        Private Sub SaveStaffCustomer(ByVal lg As LoginCustomer)
            If Not HttpContext.Current.Session Is Nothing Then
                If lg IsNot Nothing Then
                    HttpContext.Current.Session("staffmcid") = lg.MasterCustomerId
                    HttpContext.Current.Session("staffscid") = lg.SubCustomerId
                    HttpContext.Current.Session("staffln") = lg.LabelName
                Else
                    HttpContext.Current.Session("staffmcid") = Nothing
                    HttpContext.Current.Session("staffscid") = Nothing
                    HttpContext.Current.Session("staffln") = Nothing

                End If
            End If
        End Sub

#End Region
    End Class

End Namespace
