Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.MyCertifications.Business

Namespace Personify.DNN.Modules.MyCertifications

    Public MustInherit Class MyCertifications

        Inherits ApplicationManager.PersonifyDNNBaseForm

        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected MyCertificationsXslTemplate As Personify.WebControls.XslTemplate
        Protected lblNothing As Label

        Const C_TEMPLATES As String = "Templates"
        Const C_DISPLAY_NUMBER As String = "DisplayNumber"
        Const C_DETAILS_ACTION As String = "DetailsActionURL"
        Const C_EDIT_ACTION As String = "EditActionURL"
        Const C_VIEWALL_ACTION As String = "ViewAllActionURL"
        'Const C_ADDCertification_ACTION As String = "AddCertification"
        'Const C_SHOWADDCertification_ACTION As String = "ShowAddCertification"
        'Const C_SHOWDETAILS_ACTION As String = "ShowDetails"
        Const C_DISPLAY_EXPIRED_CERTIFICATES As String = "DisplayExpiredCertificates"

#End Region

#Region "Event Handlers"

        Public Class Certificate
            Public CertificationCode As String
            Public CertificationDate As String
            Public Description As String
            Public CertificationStatusCode As String
        End Class

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)


                'If MasterCustomerId Is Nothing OrElse Not MasterCustomerId.Length > 0 Then
                If Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin" Then

                    If Not Settings(C_TEMPLATES) Is Nothing Then
                        Dim DisplayExpiredCertificates As Boolean = True
                        If Not Settings(C_DISPLAY_EXPIRED_CERTIFICATES) Is Nothing Then
                            DisplayExpiredCertificates = CType(Settings(C_DISPLAY_EXPIRED_CERTIFICATES), Boolean)
                        End If

                        Dim Certifications As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications
                        Certifications = GetCertifications(MasterCustomerId, SubCustomerId, DisplayExpiredCertificates)

                        Dim DisplayNumber As Integer = 0
                        If Not Settings(C_DISPLAY_NUMBER) Is Nothing Then
                            DisplayNumber = CType(Settings(C_DISPLAY_NUMBER), Integer)
                        End If

                        Dim templatefile As String = ""
                        'templatefile = ModulePath + "Templates\MyCertifications.xsl"
                        templatefile = ModulePath + "Templates\" + Settings(C_TEMPLATES).ToString

                        MyCertificationsXslTemplate.XSLfile = Server.MapPath(templatefile)
                        MyCertificationsXslTemplate.AddObject("ModuleId", ModuleId)

                        'If Certifications IsNot Nothing AndAlso Certifications.Count > 0 Then

                        '    Dim HowManyToInclude As Integer = 0
                        '    Dim DisplayExpiredCertifivates As Boolean = True
                        '    If Not Settings(C_DISPLAY_EXPIRED_CERTIFICATES) Is Nothing Then
                        '        DisplayExpiredCertifivates = CType(Settings(C_DISPLAY_EXPIRED_CERTIFICATES), Boolean)
                        '    End If

                        '    For i As Integer = 0 To Certifications..Count - 1
                        '        If Certifications(i).ce("CertificationExpirationDate") Is DBNull.Value OrElse DisplayExpiredCertifivates = True OrElse Convert.ToDateTime(Certifications.Rows(i)("CertificationExpirationDate")) > DateTime.Now Then
                        '            HowManyToInclude = HowManyToInclude + 1
                        '        End If
                        '    Next


                        '    If HowManyToInclude > 0 Then


                        '        Dim aCertifications(HowManyToInclude - 1) As Certificate
                        '        Dim index As Integer = 0

                        '        For i As Integer = 0 To Certifications.Rows.Count - 1
                        '            Dim include As Boolean = False
                        '            If Certifications.Rows(i)("CertificationExpirationDate") Is DBNull.Value OrElse DisplayExpiredCertifivates = True OrElse Convert.ToDateTime(Certifications.Rows(i)("CertificationExpirationDate")) > DateTime.Now Then
                        '                include = True
                        '            End If
                        '            If include = True Then

                        '                aCertifications(index) = New Certificate
                        '                aCertifications(index).CertificationId = Convert.ToInt32(Certifications.Rows(i)("CertificationId"))
                        '                aCertifications(index).Description = Convert.ToString(Certifications.Rows(i)("CertificationInfo.Description"))
                        '                aCertifications(index).CertificationStatusCode = Convert.ToString(Certifications.Rows(i)("CertificationStatusCode"))
                        '                aCertifications(index).CertificationExpirationDate = Nothing
                        '                If Certifications.Rows(i)("CertificationExpirationDate") IsNot DBNull.Value Then
                        '                    Try
                        '                        aCertifications(index).CertificationExpirationDate = Convert.ToDateTime(Certifications.Rows(i)("CertificationExpirationDate"))
                        '                    Catch ex As Exception

                        '                    End Try

                        '                End If
                        '                index = index + 1
                        '            End If

                        '        Next

                        If Certifications IsNot Nothing AndAlso Certifications.Count > 0 Then

                            Dim aCertifications(Certifications.Count - 1) As Certificate
                            For i As Integer = 0 To Certifications.Count - 1
                                aCertifications(i) = New Certificate
                                aCertifications(i).CertificationCode = Convert.ToString(Certifications(i).CertificationCodeString.ToString)
                                aCertifications(i).Description = Convert.ToString(Certifications(i).CertificationInfo.Description)
                                aCertifications(i).CertificationStatusCode = Convert.ToString(Certifications(i).CertificationStatusCodeString)
                                aCertifications(i).CertificationDate = Certifications(i).RegistrationDate.ToString("MMddyyyy")
                            Next

                            'MyCertificationsXslTemplate.AddObject("", Certifications)
                            MyCertificationsXslTemplate.AddObject("", aCertifications)
                        End If

                        MyCertificationsXslTemplate.AddObject("DisplayNumber", DisplayNumber)


                        MyCertificationsXslTemplate.Display()


                        Dim HyperLinkShowAll As HyperLink
                        HyperLinkShowAll = CType(Me.FindControl("HyperLinkShowAll" + ModuleId.ToString), HyperLink)
                        If HyperLinkShowAll IsNot Nothing Then
                            HyperLinkShowAll.NavigateUrl = NavigateURL(CType(Settings(C_VIEWALL_ACTION), Integer))
                        End If

                        'Dim HyperLinkAddCertification As HyperLink
                        'HyperLinkAddCertification = CType(Me.FindControl("HyperLinkAddCertification" + ModuleId.ToString), HyperLink)
                        'If HyperLinkAddCertification IsNot Nothing Then
                        '    HyperLinkAddCertification.NavigateUrl = NavigateURL(CType(Settings(C_ADDCertification_ACTION), Integer))

                        '    Dim ShowAddCertification As Boolean = False
                        '    If Not Settings(C_SHOWADDCertification_ACTION) Is Nothing Then
                        '        ShowAddCertification = CType(Settings(C_SHOWADDCertification_ACTION), Boolean)
                        '    End If
                        '    HyperLinkAddCertification.Visible = ShowAddCertification

                        'End If

                        'Dim HyperLinkDetails As HyperLink
                        'HyperLinkDetails = CType(Me.FindControl("HyperLinkDetails" + ModuleId.ToString), HyperLink)
                        'If HyperLinkDetails IsNot Nothing Then
                        '    HyperLinkDetails.NavigateUrl = NavigateURL(CType(Settings(C_DETAILS_ACTION), Integer))

                        '    Dim ShowDetails As Boolean = False
                        '    If Not Settings(C_SHOWDETAILS_ACTION) Is Nothing Then
                        '        ShowDetails = CType(Settings(C_SHOWDETAILS_ACTION), Boolean)
                        '    End If
                        '    HyperLinkDetails.Visible = ShowDetails

                        'End If
                        'Const C_EDIT_ACTION As String = "EditActionURL"
                        If Certifications IsNot Nothing AndAlso Certifications.Count > 0 Then
                            For i As Integer = 0 To Certifications.Count - 1
                                Dim hypCertification As HyperLink
                                hypCertification = CType(Me.FindControl("hypCertification" + ModuleId.ToString + "_" + Certifications(i).CertificationCodeString.ToString + "_" + Certifications(i).RegistrationDate.ToString("MMddyyyy")), HyperLink)
                                If hypCertification IsNot Nothing Then
                                    Dim aNavigateURL As String = NavigateURL(CType(Settings(C_EDIT_ACTION), Integer))
                                    If aNavigateURL.IndexOf("?") > 0 Then
                                        aNavigateURL += "&"
                                    Else
                                        aNavigateURL += "?"
                                    End If
                                    hypCertification.NavigateUrl = aNavigateURL + _
                                    "C=" + Certifications(i).CertificationCodeString.ToString + _
                                    "&RD=" + Certifications(i).RegistrationDate.ToString("MM/dd/yyyy")
                                End If
                            Next


                            '<asp:HyperLink ID="hypCertification{$ModuleId}_{$id}" Runat="server" CssClass="" NavigateUrl="url">
                            '</asp:HyperLink>

                        Else
                            lblNothing.Visible = True
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    End If

                    'MasterCustomerId = "000000000155"
                    'SubCustomerId = 0


                Else
                    DisplayUserAccessMessage(role)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Perosnify"
        Private Function GetCertifications(ByVal MasterCustomerID As String, ByVal SubCustomerID As Integer, ByVal IncludeExpiredCertificates As Boolean) As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications

            Dim oCertifications As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications

            oCertifications = Me.PErsonifyGetCollection( TIMSS.Enumerations.NamespaceEnum.CertificationInfo, "CertificationCustomerCertifications")

            oCertifications.Filter.Add("MasterCustomerID", MasterCustomerID)
            oCertifications.Filter.Add("SubCustomerID", SubCustomerID)

            If IncludeExpiredCertificates = False Then
                oCertifications.Filter.Add(New TIMSS.API.Core.FilterItem("Certification_Expiration_Date is null or Certification_Expiration_Date >= '" & DateTime.Now.ToString & "'"))
            End If

            oCertifications.Fill()
            Return oCertifications

        End Function


#End Region
    End Class

End Namespace
