Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO

Namespace Personify.DNN.Modules.MyCertifications

    Public MustInherit Class MyCertificationsEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton


        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl
        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList

        Protected WithEvents txtDisplayNumber As System.Web.UI.WebControls.TextBox
        Protected WithEvents rvDisplayNumber As System.Web.UI.WebControls.RangeValidator
        Protected WithEvents rfDisplayNumber As System.Web.UI.WebControls.RequiredFieldValidator

        Const C_TEMPLATES As String = "Templates"
        Const C_DISPLAY_NUMBER As String = "DisplayNumber"
        'Const C_DETAILS_ACTION As String = "DetailsActionURL"
        Const C_VIEWALL_ACTION As String = "ViewAllActionURL"
        Const C_EDIT_ACTION As String = "EditActionURL"
        'Const C_ADDCertification_ACTION As String = "AddCertification"
        'Const C_SHOWADDCertification_ACTION As String = "ShowAddCertification"
        Const C_DISPLAY_EXPIRED_CERTIFICATES As String = "DisplayExpiredCertificates"

        Protected WithEvents drpViewAllAction As System.Web.UI.WebControls.DropDownList
        Protected WithEvents drpEditAction As System.Web.UI.WebControls.DropDownList

        Protected WithEvents CheckBoxDisplayExpired As System.Web.UI.WebControls.CheckBox

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"

        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                Dim _portalSettings As Entities.Portals.PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), Entities.Portals.PortalSettings)

                If Not select_Template.Items.Count > 0 Then
                    Dim li As ListItem
                    For Each li In GetTemplates()
                        If li.Text = "MyCertifications.xsl" Then
                            li.Selected = True
                        End If
                        select_Template.Items.Add(li)
                    Next
                    select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings(C_TEMPLATES))))
                End If

                If Not Page.IsPostBack Then

                    '**Get a list of tabs in the portal
                    Dim arrTabs As ArrayList = GetPortalTabs(_portalSettings.DesktopTabs, True, True)

                    '**Bind the RenewAll dropdown list
                    'With drpDetailsAction
                    '    .DataSource = arrTabs
                    '    .DataValueField = "TabId"
                    '    .DataTextField = "TabName"
                    '    .DataBind()
                    'End With

                    With drpEditAction
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    '**Bind the ViewAll dropdown list
                    With drpViewAllAction
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    'With drpAddCertificationAction
                    '    .DataSource = arrTabs
                    '    .DataValueField = "TabId"
                    '    .DataTextField = "TabName"
                    '    .DataBind()
                    'End With

                    '**Details Action URL
                    'If Not Settings(C_DETAILS_ACTION) Is Nothing Then
                    '    If Not Me.drpDetailsAction.Items.FindByValue(Settings(C_DETAILS_ACTION).ToString) Is Nothing Then
                    '        Me.drpDetailsAction.Items.FindByValue(Settings(C_DETAILS_ACTION).ToString).Selected = True
                    '    Else
                    '        Me.drpDetailsAction.Items(0).Selected = True
                    '    End If
                    'End If

                    If Not Settings(C_EDIT_ACTION) Is Nothing Then
                        If Not Me.drpEditAction.Items.FindByValue(Settings(C_EDIT_ACTION).ToString) Is Nothing Then
                            Me.drpEditAction.Items.FindByValue(Settings(C_EDIT_ACTION).ToString).Selected = True
                        Else
                            Me.drpEditAction.Items(0).Selected = True
                        End If
                    End If

                    '**View All Action URL
                    If Not Settings(C_VIEWALL_ACTION) Is Nothing Then
                        If Not Me.drpViewAllAction.Items.FindByValue(Settings(C_VIEWALL_ACTION).ToString) Is Nothing Then
                            Me.drpViewAllAction.Items.FindByValue(Settings(C_VIEWALL_ACTION).ToString).Selected = True
                        Else
                            Me.drpViewAllAction.Items(0).Selected = True
                        End If
                    End If

                    'If Not Settings(C_ADDCertification_ACTION) Is Nothing Then
                    '    If Not Me.drpAddCertificationAction.Items.FindByValue(Settings(C_ADDCertification_ACTION).ToString) Is Nothing Then
                    '        Me.drpAddCertificationAction.Items.FindByValue(Settings(C_ADDCertification_ACTION).ToString).Selected = True
                    '    Else
                    '        Me.drpAddCertificationAction.Items(0).Selected = True
                    '    End If
                    'End If

                    Dim DisplayNumber As Integer = 0
                    If Not Settings(C_DISPLAY_NUMBER) Is Nothing Then
                        DisplayNumber = CType(Settings(C_DISPLAY_NUMBER), Integer)
                    End If
                    txtDisplayNumber.Text = DisplayNumber.ToString

                    'Dim ShowAddCertification As Boolean = False
                    'If Not Settings(C_SHOWADDCertification_ACTION) Is Nothing Then
                    '    ShowAddCertification = CType(Settings(), Boolean)
                    'End If
                    'CheckBoxShowAddCertification.Checked = ShowAddCertification

                    Dim ShowDetails As Boolean = False
                    If Not Settings(C_DISPLAY_EXPIRED_CERTIFICATES) Is Nothing Then
                        ShowDetails = CType(Settings(C_DISPLAY_EXPIRED_CERTIFICATES), Boolean)
                    End If
                    CheckBoxDisplayExpired.Checked = ShowDetails

                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting(C_DISPLAY_NUMBER, txtDisplayNumber.Text)
                    UpdateModuleSetting(C_TEMPLATES, select_Template.SelectedValue)

                    UpdateModuleSetting(C_VIEWALL_ACTION, drpViewAllAction.SelectedValue)
                    UpdateModuleSetting(C_EDIT_ACTION, drpEditAction.SelectedValue)

                    UpdateModuleSetting(C_DISPLAY_EXPIRED_CERTIFICATES, CheckBoxDisplayExpired.Checked.ToString)
                    '.UpdateModuleSetting(ModuleId, C_DETAILS_ACTION, drpDetailsAction.SelectedValue)

                    '.UpdateModuleSetting(ModuleId, C_SHOWADDCertification_ACTION, CheckBoxShowAddCertification.Checked.ToString)
                    '.UpdateModuleSetting(ModuleId, C_ADDCertification_ACTION, drpAddCertificationAction.SelectedValue)

                    

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                If Not Null.IsNull(itemId) Then
                    'Dim objCtlMyCertifications As New MyCertificationsController
                    'objCtlMyCertifications.Delete(itemId)
                End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
