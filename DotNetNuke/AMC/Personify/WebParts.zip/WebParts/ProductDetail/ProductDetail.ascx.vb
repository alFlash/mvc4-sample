Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web.UI.WebControls
Imports System.Configuration
Imports System.Text.RegularExpressions
Imports System.Collections.Specialized
Imports DotNetNuke
Imports DotNetNuke.Security
Imports TIMSS
Imports Personify
Imports DotNetNuke.Common.Lists
Imports DotNetNuke.Common.Utilities

Imports DotNetNuke.Services.Localization
Imports System.Text



Namespace Personify.DNN.Modules.ProductDetail

    Public Class ProductDetail
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Implements Entities.Modules.Communications.IModuleCommunicator
        Implements Entities.Modules.Communications.IModuleListener



#Region " Fields "

        'Private MasterCustomerId As String = String.Empty
        'Private SubCustomerId As Integer = 0
        'Private tmpisLoggedin As Boolean = False
        Private PM As ProductDetailModel
        'Protected WithEvents DCDAddToCartButton As Button
        '<p>
        '<PSNF:XslTemplate ID="DCDXslTemplate" runat="server">
        '</PSNF:XslTemplate>
        '</p>
        Private _ProductDetails As ProductDetails ' for ProductDetails object
        Private _ShowAddToCartMeeting As Boolean
        Private _AddRemoveSessions As Boolean
        Private _UpdateOrder As Boolean
        Private _CartItemId As Integer
        Private _OrderNumber As String
        Private _OrderLineNumber As Integer
        Private _ProductID As Integer
        Private Const C_SIMPLE_PRICE_LAYOUT As String = "DefaultPricing"
        Protected WithEvents HyperLinkBack As HyperLink
        Protected DCDXslTemplate As WebControls.XslTemplate
        Protected ProductDetailTemplate As WebControls.XslTemplate
        Protected UpSellXslTemplate As WebControls.XslTemplate
        Protected XSellXslTemplate As WebControls.XslTemplate
        Protected PackageXslTemplate As WebControls.XslTemplate
        Protected MeetingXslTemplate As WebControls.XslTemplate
        Protected WithEvents DCDAddToCartControl As Button
        Protected WithEvents DCDAddToWishListControl As Button
        Protected WithEvents DCDBuyForGroupControl As Button
        Protected WithEvents MeetingAddToCartControl As Button
        Protected WithEvents MeetingUpdateCartControl As Button
        Protected WithEvents MeetingAddToWishListControl As Button
        Protected WithEvents MeetingBuyForGroupControl As Button
        Protected WithEvents MeetingUpdateOrderControl As Button

     
        'Protected MessageControl As WebControls.MessageControl

        'Template controls
        'start 3246-5875068
        Protected WithEvents txtCustomDonateAmount As New TextBox
        Protected WithEvents tblCustomPrice As HtmlTable
#End Region

#Region " Properties "

        ''' <summary>
        ''' use private _ProductID
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProductID() As Integer
            Get
                Return _ProductID
            End Get
            Set(ByVal value As Integer)
                _ProductID = value
            End Set
        End Property


        ''' <summary>
        ''' use private _ProductDetails to keep ApplicationManager.ProductDetails
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProductDetails() As ProductDetails
            Get
                Return _ProductDetails
            End Get
            Set(ByVal value As ProductDetails)
                _ProductDetails = value
            End Set
        End Property

        Public Property ShowAddToCartMeeting() As Boolean
            Get
                Return _ShowAddToCartMeeting
            End Get
            Set(ByVal value As Boolean)
                _ShowAddToCartMeeting = value
            End Set
        End Property
        Private _ShowBadgesHyperlink As Boolean
        Public Property ShowBadgesHyperlink() As Boolean
            Get
                Return _ShowBadgesHyperlink
            End Get
            Set(ByVal value As Boolean)
                _ShowBadgesHyperlink = value
            End Set
        End Property
        Public Property AddRemoveSessions() As Boolean
            Get
                Return _AddRemoveSessions
            End Get
            Set(ByVal value As Boolean)
                _AddRemoveSessions = value
            End Set
        End Property

        Public Property UpdateOrder() As Boolean
            Get
                Return _UpdateOrder
            End Get
            Set(ByVal value As Boolean)
                _UpdateOrder = value
            End Set
        End Property

        Public Property CartItemId() As Integer
            Get
                Return _CartItemId
            End Get
            Set(ByVal value As Integer)
                _CartItemId = value
            End Set
        End Property

        Public Property OrderNumber() As String
            Get
                Return _OrderNumber
            End Get
            Set(ByVal value As String)
                _OrderNumber = value
            End Set
        End Property

        Public Property OrderLineNumber() As Integer
            Get
                Return _OrderLineNumber
            End Get
            Set(ByVal value As Integer)
                _OrderLineNumber = value
            End Set
        End Property

#End Region


#Region " Private Sub/Functions "

        'CODEREVIEW
        Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
            Dim ScriptPath As String = ResolveUrl(path)
            If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
                Dim script As StringBuilder = New StringBuilder
                script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
                script = Nothing
            End If
        End Sub

        ''' <summary>
        ''' fill ProductDetailModel object
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadPM()
            Try
                'CODEREVIEW - think of caching this information
                PM = New ProductDetailModel(ModuleId)
                PM.Load()
                PM.CrossSell.Load()
                PM.UpSell.Load()

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' <summary>
        ''' load all product lists
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadData()
            Try
                LoadProductDetail()
                If Settings("PD_DisplayProductComponentsSettingsKey") = "Y" Then
                    LoadPackage()
                End If


                If ProductDetails.Subsystem.ToLower = "mtg" Then LoadSubProducts()
                If ProductDetails.Subsystem.ToUpper = "ECD" Then LoadDCD()

                LoadUpSell()
                LoadXSell()
                'LoadXSellDataList()
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Public Class Product
            Public SmallImageFileName As String
            Public LargeImageFileName As String

            Public WebShortDescription As String
            Public WebLongDescription As String

            Public LongName As String
            Public ShortName As String

            'MTG subsystem properties
            Public StartDate As String
            Public EndDate As String
            Public FacilityState As String
            Public FacilityCity As String
            Public FacilityLabelName As String
            Public Status As String

            'INV subsystem properties
            Public NextInvReceiptDate As String

            Public ProductId As Integer
            Public Code As String
            Public ParentCode As String
            'Public AllowSessionConflicts As Boolean

            'DCD subsystem properties
            'Public FileName As String
            'Public DocumentTitle As String
            'Public Description As String
            'Public ValidFrom As String
            'Public ValidTo As String
            'Public DisplayCopyright As Boolean
            'Public CopyrightText As String

        End Class

        Private Sub LoadProductDetail()
            Try
                Dim aProduct As New Product

                Dim loadFNDCustomerPrice As Boolean  '3246-5875068

                ShowAddToCartMeeting = True

                Dim tempSettings As Object = Settings("PD_DisplayProductImageSettingsKey")
                If tempSettings IsNot Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE") Then
                    aProduct.SmallImageFileName = ProductDetails.ProductInfo(0).SmallImageFileName
                    aProduct.LargeImageFileName = ProductDetails.ProductInfo(0).LargeImageFileName
                End If


                aProduct.WebShortDescription = ProductDetails.ProductInfo(0).WebShortDescription
                aProduct.WebLongDescription = TruncateDescription(ProductDetails.ProductInfo(0).WebLongDescription, "PD_TruncateDescriptionSettingsKey")
                aProduct.LongName = ProductDetails.ProductInfo(0).LongName
                aProduct.ShortName = ProductDetails.ProductInfo(0).ShortName
                aProduct.FacilityLabelName = ""
                aProduct.FacilityCity = ""
                aProduct.FacilityState = ""
                aProduct.StartDate = ""
                aProduct.EndDate = ""
                'If ProductDetails.MeetingInfo IsNot Nothing AndAlso ProductDetails.MeetingInfo.Count > 0 AndAlso ProductDetails.MeetingInfo(0) IsNot Nothing Then
                'aProduct.FacilityLabelName = ProductDetails.MeetingInfo(0).FacilityLabelName
                'aProduct.StartDate = ProductDetails.MeetingInfo(0).StartDate.ToString("MMMM d, yyyy")
                'End If




                Select Case ProductDetails.Subsystem.ToUpper

                    Case "MTG"
                        'aProduct.FacilityLabelName = ProductDetails.ProductInfo(0).FacilityName
                        aProduct.StartDate = ProductDetails.ProductInfo(0).MeetingStartDate.ToString("MMMM d, yyyy hh:mmtt")
                        aProduct.EndDate = ProductDetails.ProductInfo(0).MeetingEndDate.ToString("MMMM d, yyyy hh:mmtt")
                        'Dim oAddress As TIMSS.API.CustomerInfo.ICustomerAddressViewList
                        Dim oFacInfo As FacilityInformation = Nothing
                        oFacInfo = get_clsProductHelper.GetFacilityInfo(ProductDetails.ProductInfo(0).FacilityMasterCustomerId, ProductDetails.ProductInfo(0).FacilitySubCustomerId)
                        If oFacInfo IsNot Nothing Then
                            aProduct.FacilityLabelName = oFacInfo.FacilityName
                            aProduct.FacilityCity = oFacInfo.City
                            aProduct.FacilityState = oFacInfo.State
                        End If

                        'an performance related change
                        'oAddress = GetPrimaryAddress(ProductDetails.ProductInfo(0).FacilityMasterCustomerId, ProductDetails.ProductInfo(0).FacilitySubCustomerId)
                        'If oAddress IsNot Nothing AndAlso oAddress.Count > 0 Then
                        '    aProduct.FacilityCity = oAddress(0).City
                        '    aProduct.FacilityState = oAddress(0).State
                        'End If
                        If ProductDetails.ProductInfo(0).MeetingCapacity > ProductDetails.ProductInfo(0).MeetingRegistrations Then
                            aProduct.Status = Localization.GetString("AvailableMessage", LocalResourceFile)
                        End If
                        If ProductDetails.ProductInfo(0).MeetingCapacity = ProductDetails.ProductInfo(0).MeetingRegistrations And ProductDetails.ProductInfo(0).MeetingWaitListCapacity > ProductDetails.ProductInfo(0).MeetingWaitListRegistrations Then
                            aProduct.Status = Localization.GetString("WaitlistedMessage", LocalResourceFile)
                        End If
                        If (ProductDetails.ProductInfo(0).MeetingCapacity = ProductDetails.ProductInfo(0).MeetingRegistrations And ProductDetails.ProductInfo(0).MeetingWaitListCapacity = ProductDetails.ProductInfo(0).MeetingWaitListRegistrations) And (ProductDetails.ProductInfo(0).ProductTypeCodeString = "M" Or ProductDetails.ProductInfo(0).ProductTypeCodeString = "S") Then
                            aProduct.Status = Localization.GetString("FullMessage", LocalResourceFile)
                            ShowAddToCartMeeting = False
                        End If



                    Case "INV"
                        If ProductDetails.ProductInfo(0).InventoryFlag = False Then
                            aProduct.Status = Localization.GetString("InStockMessage", LocalResourceFile)
                        Else
                            If ProductDetails.ProductInfo(0).TotalAvailableInventory > 0 Then
                                aProduct.Status = Localization.GetString("InStockMessage", LocalResourceFile)
                            Else
                                aProduct.Status = Localization.GetString("OutOfStockMessage", LocalResourceFile)
                                If ProductDetails.ProductInfo(0).NextInvReceiptDate <> "#12:00:00 AM#" Then
                                    aProduct.NextInvReceiptDate = ProductDetails.ProductInfo(0).NextInvReceiptDate.ToString("MM/dd/yyyy")
                                Else
                                    aProduct.NextInvReceiptDate = Localization.GetString("UnavailableDateMessage", LocalResourceFile)
                                End If
                            End If
                        End If

                    Case "MBR"
                        'needs to get start date / end date
                        Dim oMembershipProduct As TIMSS.API.MembershipInfo.IMembershipProduct
                        oMembershipProduct = get_clsProductHelper.GetMembershipInfo(ProductDetails.ProductId)
                        aProduct.StartDate = oMembershipProduct.MembershipStartDate.ToString("MM/dd/yyyy")
                        aProduct.EndDate = oMembershipProduct.MembershipEndDate.ToString("MM/dd/yyyy")

                    Case "SUB"
                        'Dim oSubscriptionProduct As TIMSS.API.SubscriptionInfo.ISubscriptionProduct
                        'oSubscriptionProduct = ApplicationManager.WebProduct.GetSubscriptionInfo(PortalId, ProductDetails.ProductId)

                        'aProduct.StartDate = oSubscriptionProduct.Issues(0).IssueDate.ToString("MM/dd/yyyy")
                        'aProduct.EndDate = oSubscriptionProduct.Issues(oSubscriptionProduct.Issues.Count - 1).IssueEndDate.ToString("MM/dd/yyyy")


                    Case "FND" 'START 3246-5875068
                        'ProductDetails.ProductInfo(0).direct()
                        'Dim t As TIMSS.API.FundRaisingInfo.IFundRaisingProduct
                        't.ProductInfo.DirectPriceUpdateFlag
                        'Dim a As TIMSS.API.InventoriedProductInfo.IInventoryProduct
                        'a.Product.DirectPriceUpdateFlag

                        'Dim e As TIMSS.API.MeetingInfo.IMeetingProduct
                        'e.ProductInfo.DirectPriceUpdateFlag
                        Dim oFundRaisingProduct As TIMSS.API.FundRaisingInfo.IFundRaisingProduct
                        oFundRaisingProduct = get_clsProductHelper.GetFundRaisingInfo(ProductDetails.ProductId)
                        If oFundRaisingProduct IsNot Nothing Then
                            If oFundRaisingProduct.ProductInfo.DirectPriceUpdateFlag AndAlso Settings("FUNDRaisingAllowCustomPrice") IsNot Nothing AndAlso CType(Settings("FUNDRaisingAllowCustomPrice"), Boolean) Then
                                loadFNDCustomerPrice = True
                            End If
                        End If
                        'END 3246-5875068

                End Select




                Dim isAdmin As Boolean = False
                'CODEREVIEW - check this logic
                If Not Me.IsPersonifyWebUserLoggedIn Then
                    If UserInfo.UserID <> -1 Then
                        aProduct.ProductId = ProductDetails.ProductInfo(0).ProductId
                        aProduct.Code = ProductDetails.ProductInfo(0).ProductCode
                        aProduct.ParentCode = ProductDetails.ProductInfo(0).ParentProduct
                        isAdmin = True
                    End If
                End If

                Dim templatefile As String = ""

                Try
                    templatefile = ModulePath + "Templates\" + Settings("PD_LayoutTemplateSettingsKey").ToString()
                Catch ex As Exception
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
                End Try

                ProductDetailTemplate.XSLfile = Server.MapPath(templatefile)
                ProductDetailTemplate.AddObject("UpdateOrder", UpdateOrder)
                ProductDetailTemplate.AddObject("", aProduct)
                ProductDetailTemplate.AddObject("ModuleId", ModuleId)

                ProductDetailTemplate.AddObject("IsAdmin", isAdmin)

                Dim ProductImageURL As String = ProductImagesFolder
                ProductDetailTemplate.AddObject("ProductImageURL", ProductImageURL)
                ProductDetailTemplate.AddObject("MeetingDetailURL", MeetingDetail_GetURL(ProductID))

                If CheckIfModeIsNEwReg() Then
                    ProductDetailTemplate.AddObject("MeetingDetailBackURL", MeetingDetail_BackURL(ProductID))
                End If

                ProductDetailTemplate.Display()

                'START 3246-5875068
                'CODEREVIEW- do this only for fund products and if edit setting is true
                txtCustomDonateAmount = (CType(Me.FindControl("txtCustomDonateAmount".ToString), TextBox))
                tblCustomPrice = (CType(Me.FindControl("tblCustomPrice".ToString), HtmlTable))
                If tblCustomPrice IsNot Nothing Then
                    tblCustomPrice.Visible = loadFNDCustomerPrice
                End If
                'END 3246-5875068

                Dim aPricingControl As New WebControls.PricingControl

                aPricingControl.ID = "ProductPricingControl" + ModuleId.ToString
                aPricingControl.PortalID = PortalId

                aPricingControl.Visible = True
                aPricingControl.AllPrices = ProductDetails.AllPrices
                'ANMC
                aPricingControl.PortalCurrency = PortalCurrency
                aPricingControl.ListPrices = ProductDetails.ListPrices
                aPricingControl.MemberPrices = ProductDetails.MemberPrices
                'CODEREVIEW - if a custome ris not logged in, do not process customer price
                aPricingControl.YourPrices = ProductDetails.CustomerPrice

                aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)
                'Fixed Ticket #3246-8157039 : Set the below three properties of aPricingControl
                aPricingControl.IsFromProductDetail = True
                aPricingControl.ScheduledPriceLabel = Localization.GetString("ScheduledPriceLabel.Text", LocalResourceFile)
                aPricingControl.HideSchedulePriceLabelMessage = Localization.GetString("HideSchedulePriceLabelMessage.Text", LocalResourceFile)

                If Settings("DisplayRateCodeSettingsKey_" + ProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                    aPricingControl.ShowRateCode = True
                End If

                If Me.IsPersonifyWebUserLoggedIn = True Then
                    aPricingControl.IsMember = True
                Else
                    aPricingControl.IsMember = False
                End If

                Dim tempPlaceHolder As New PlaceHolder


                tempPlaceHolder = Me.FindControl("ProductPricePlaceHolder")

                'CODEREVIEW - for ECD do not add pricing control to the page.

                If (tempPlaceHolder IsNot Nothing) Then
                    If ProductDetails.Subsystem.ToUpper = "ECD" Then
                        aPricingControl.Visible = False
                    End If
                    tempPlaceHolder.Controls.Add(aPricingControl)
                End If


                If ShowAddToCartMeeting Then
                    Dim aAddToCartControl As New WebControls.AddToCartControl

                    aAddToCartControl.ID = "ProductAddToCartControl" + ModuleId.ToString

                    aAddToCartControl.Visible = True

                    'Note: must set the properties here - do not move
                    aAddToCartControl.VisibleAddToCart = PM.Settings.ShowAddtoCart AndAlso ProductDetails.ProductInfo(0).AddToCartFlag
                    aAddToCartControl.VisibleWishList = PM.Settings.ShowWishList
                    aAddToCartControl.VisibleBuyForGroup = PM.Settings.ShowBuyForGroup

                    ' aAddToCartControl.VisibleAddToCart = True
                    '  aAddToCartControl.VisibleWishList = True
                    ' aAddToCartControl.VisibleBuyForGroup = False

                    If Settings("PD_DefaultQuantitySettingsKey") IsNot Nothing Then
                        aAddToCartControl.Quantity = CType(Settings("PD_DefaultQuantitySettingsKey"), Integer)
                    Else
                        aAddToCartControl.Quantity = 1
                    End If
                    Select Case ProductDetails.Subsystem.ToUpper
                        Case "INV", "MISC", "SUB"
                            aAddToCartControl.VisibleQuantity = True
                        Case "MTG"
                            'what is this?
                            If ProductDetails IsNot Nothing AndAlso ProductDetails.CustomerPrice IsNot Nothing AndAlso ProductDetails.CustomerPrice.Count > 0 AndAlso ProductDetails.CustomerPrice(0).MaxBadges >= 1 Then
                                aAddToCartControl.VisibleQuantity = True
                            Else
                                aAddToCartControl.VisibleQuantity = False
                            End If
                        Case Else
                            aAddToCartControl.VisibleQuantity = False
                    End Select

                    'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                    'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
                    If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                        aAddToCartControl.VisibleBuyForGroup = True
                    End If

                    Try
                        'CODEREVIEW - check this code, if this needs to be hidded do not calculate all teh above stuff
                        'Fixed #3246-8311751:Modified the below condition to show add to cart button if there is no sub products in a meeting product.
                        If ProductDetails.Subsystem.ToLower = "ecd" OrElse (ProductDetails.Subsystem.ToUpper = "MTG" AndAlso ProductDetails.SubProducts IsNot Nothing AndAlso ProductDetails.SubProducts.Length > 0) Then
                            aAddToCartControl.Visible = False
                        End If
                    Catch ex As Exception

                    End Try

                    'CODEREVIEW - if show buttons is false why do all the above stuff
                    'CODEREVIEW - evaluate need for SHOW BUTTONS edit setting. If might not be needed

                    If PM.Settings.ShowButtons Then

                        aAddToCartControl.ProductId = ProductID
                        aAddToCartControl.Text = Localization.GetString("AddToCart.Text", LocalResourceFile)
                        aAddToCartControl.WishListText = Localization.GetString("AddToWishList.Text", LocalResourceFile)
                        aAddToCartControl.BuyForGroupText = Localization.GetString("BuyForGroup.Text", LocalResourceFile)
                        aAddToCartControl.ButtonCss = "btna"

                        aAddToCartControl.ButtonMode = WebControls.AddToCartControl.EnumButtonMode.Button
                        '3246-5774803
                        aAddToCartControl.ImageURL = GetAddToCartImageURL() 'ModulePath & "images/btn_addtocart.gif"
                        aAddToCartControl.WishListImageURL = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                        aAddToCartControl.BuyForGroupImageURL = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                        'end 3246-5774803


                        tempPlaceHolder = Me.FindControl("ProductAddToCartPlaceHolder")

                        If (tempPlaceHolder IsNot Nothing) Then
                            tempPlaceHolder.Controls.Add(aAddToCartControl)
                        End If
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Class aComponent
            Public ListPrice As String
            Public CustomerPrice As String
            Public MemberPrice As String
            Public ProductId As Integer
            Public ProductLink As String
            Public ShortName As String
            Public SmallImageFileName As String
            Public WebShortDescription As String
            Public WebLongDescription As String
        End Class

        Private Sub LoadPackage()
            Try
                Dim ComponentsWarningMessage As String = String.Empty
                If (ProductDetails.Components IsNot Nothing) Then
                    If (ProductDetails.Components.Count > 0) Then
                        Dim Components(ProductDetails.Components.Count) As aComponent

                        ComponentsWarningMessage = Localization.GetString("ComponentsWarningMessage", LocalResourceFile)
                        Dim i As Integer
                        For i = 0 To ProductDetails.Components.Count - 1
                            If (ProductDetails.Components(i) IsNot Nothing) Then
                                Components(i) = New aComponent
                                Components(i).CustomerPrice = ProductDetails.Components(i).CustomerPrice
                                Components(i).ListPrice = ProductDetails.Components(i).ListPrice
                                Components(i).MemberPrice = ProductDetails.Components(i).MemberPrice
                                Components(i).ProductId = ProductDetails.Components(i).ProductId
                                Components(i).ShortName = ProductDetails.Components(i).ShortName
                                If ProductDetails.Components(i).SmallImageFileName.Length > 0 And CType(Settings("PD_ShowComponentsImagesSettingsKey"), String) = "Y" Then
                                    Components(i).SmallImageFileName = ProductDetails.Components(i).SmallImageFileName
                                End If
                                Components(i).WebShortDescription = TruncateDescription(ProductDetails.Components(i).WebShortDescription, "PD_TruncateComponentsDescriptionSettingsKey")
                                Components(i).WebLongDescription = ProductDetails.Components(i).WebLongDescription
                                'CODEREVIEW - use string.format here
                                If ProductDetails.Components(i).IsWebEnabledProduct = True Then
                                    Components(i).ProductLink = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("US_ProductURLSettingsKey"), Integer)))
                                    If Components(i).ProductLink.IndexOf("?") > 0 Then
                                        Components(i).ProductLink += "&"
                                    Else
                                        Components(i).ProductLink += "?"
                                    End If
                                    Components(i).ProductLink += "ProductId=" + ProductDetails.Components(i).ProductId.ToString
                                End If
                            End If
                        Next
                        Dim templatefile As String = ""

                        Try
                            templatefile = ModulePath + "Templates\" + Settings("PD_LayoutPackageTemplateSettingsKey").ToString()
                        Catch ex As Exception
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
                        End Try

                        PackageXslTemplate.XSLfile = Server.MapPath(templatefile)
                        PackageXslTemplate.AddObject("", Components)
                        PackageXslTemplate.AddObject("ModuleId", ModuleId)

                        Dim ProductImageURL As String = ProductImagesFolder
                        PackageXslTemplate.AddObject("ProductImageURL", ProductImageURL)

                        PackageXslTemplate.AddObject("ComponentsWarningMessage", ComponentsWarningMessage)

                        PackageXslTemplate.Display()
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Public Class SubProductmenu
            Public TitleDate As String
            Public TitleTime As String
            Public Description As String
            Public TitleFee As String
        End Class

        Public Class SubProductitem
            Implements System.IComparable

            Public ProductId As String
            Public StartDate As DateTime
            Public EndDate As DateTime
            Public AvailableStartDate As String
            Public OldStartDate As String ' for
            Public AvailableStartTime As String
            Public AvailableStopDate As String
            Public AvailableShortStopDate As String
            Public AvailableStopTime As String
            Public LongName As String
            Public ImageFileName As String
            Public speakers() As Speaker
            Public WebLongDescription As String
            Public Track As String
            Public Status As String
            Public NextInvReceiptDate As String
            Public AllowSessionConflict As Boolean
            Public Checked As Boolean
            Public Disabled As Boolean
            Public ProductType As String
            'AN FIX
            Public MaxTickets As Integer
            Public Quantity As Integer
            Public CanUpdateQuantity As Boolean

            Public MemberPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public ListPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public AllPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public CustomerPrice As ApplicationManager.PersonifyDataObjects.WebPrices

            Public Function CompareTo(ByVal obj As Object) As Integer _
             Implements System.IComparable.CompareTo

                Dim Compare As SubProductitem = CType(obj, SubProductitem)
                Dim result As Integer = Me.StartDate.CompareTo(Compare.StartDate)
                'CODEREVIEW - chekc  out this logic - if result = 0, the next compare should be done by another fields
                If result = 0 Then
                    result = Me.EndDate.CompareTo(Compare.EndDate)
                End If
                Return result

            End Function
        End Class

        Public Class Speaker
            Public SpeakerName As String
            Public SpeakerSession As String
        End Class

        Public Class OptionItem
            Public value As String
            Public text As String
        End Class


        Private Sub LoadSubProducts()

            Dim CList As ArrayList

            Try
                If ProductDetails IsNot Nothing Then
                    If ProductDetails.SubProducts IsNot Nothing Then
                        If ProductDetails.SubProducts.Length > 0 Then

                            Dim aSubProductmenu As New SubProductmenu


                            aSubProductmenu.TitleDate = Localization.GetString("SubProductTitleDate.Text", LocalResourceFile)
                            aSubProductmenu.TitleTime = Localization.GetString("SubProductTitleTime.Text", LocalResourceFile)
                            aSubProductmenu.Description = Localization.GetString("SubProductDescription.Text", LocalResourceFile)
                            aSubProductmenu.TitleFee = Localization.GetString("SubProductTitleFee.Text", LocalResourceFile)


                            Dim ASubProductitems As New ArrayList()
                            Dim i As Integer

                            Dim aTrack As New ArrayList
                            Dim aClass As New ArrayList
                            Dim aStartDate As New ArrayList

                            Dim searchtype As String = "0"
                            Dim searchvalue As String = ""

                            Dim aRC As New ArrayList

                            'Add/Remove Sessions functionality
                            'Dim oCartSubProducts As New ArrayList
                            'an cuna fix
                            Dim ohsCartSubProducts As New Hashtable


                            If ProductDetails.Subsystem = "MTG" And AddRemoveSessions Then
                                Dim oManager As New ShoppingCartManager.Business.ShoppingCartController

                                CList = oManager.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, False, CartItemId)
                                If CList.Count > 0 Then
                                    'Form the subproducts list from Cart
                                    For i = 0 To CList.Count - 1
                                        If CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).Subsystem = "MTG" And CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).ProductId = ProductDetails.ProductId Then
                                            'oCartSubProducts.Add(CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).SubProductId)

                                            ohsCartSubProducts.Add(CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).SubProductId, CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).Quantity)
                                        End If
                                    Next
                                End If
                            End If
                            'an cuna fix
                            'Dim oOrderSubProducts As New ArrayList
                            Dim ohsOrderSubProducts As New Hashtable
                            If UpdateOrder = True Then
                                Dim oEntireOrderSummary As EntireOrderSummary
                                oEntireOrderSummary = New EntireOrderSummary(OrganizationId, OrganizationUnitId, OrderNumber.ToString, True, Me.BaseCurrency, Me.PortalCurrency, FetchOnDemand)
                                If oEntireOrderSummary IsNot Nothing AndAlso oEntireOrderSummary.OrderDetails IsNot Nothing AndAlso oEntireOrderSummary.OrderDetails.Length > 0 Then
                                    For i = 0 To oEntireOrderSummary.OrderDetails.Length - 1
                                        'an cuna fix
                                        'oOrderSubProducts.Add(oEntireOrderSummary.OrderDetails(i).ProductId)
                                        If oEntireOrderSummary.OrderDetails(i).LineStatusCode <> "Cancelled" Then
                                            If Not ohsOrderSubProducts.Contains(oEntireOrderSummary.OrderDetails(i).ProductId) Then
                                                ohsOrderSubProducts.Add(oEntireOrderSummary.OrderDetails(i).ProductId, oEntireOrderSummary.OrderDetails(i).Quantity)
                                            End If
                                        End If



                                        If oEntireOrderSummary.OrderDetails(i).ProductId = ProductID Then
                                            OrderLineNumber = oEntireOrderSummary.OrderDetails(i).OrderLineNumber
                                        End If

                                    Next
                                End If
                            End If
                            'CODEREVIEW - look at this

                            For i = 0 To ProductDetails.SubProducts.Length - 1
                                Dim aSetting As String = Settings("MeetingInclusionSettingsKey_" + ProductDetails.SubProducts(i).ProductType.ToString)

                                If ProductDetails.SubProducts(i).MeetingInfo(0).SessionTrackCode IsNot Nothing _
                                AndAlso ProductDetails.SubProducts(i).MeetingInfo(0).SessionTrackCode.Code.Length > 0 Then
                                    If Not (aTrack.IndexOf(ProductDetails.SubProducts(i).MeetingInfo(0).SessionTrackCode.Code) >= 0) Then
                                        aTrack.Add(ProductDetails.SubProducts(i).MeetingInfo(0).SessionTrackCode.Code)
                                    End If
                                End If

                                If Not (aClass.IndexOf(ProductDetails.SubProducts(i).ProductInfo(0).ProductClassCode.Code) >= 0) Then
                                    aClass.Add(ProductDetails.SubProducts(i).ProductInfo(0).ProductClassCode.Code)
                                End If

                                If Not (aStartDate.IndexOf(ProductDetails.SubProducts(i).MeetingInfo(0).StartDate.ToString("MMMM d, yyyy")) >= 0) Then
                                    aStartDate.Add(ProductDetails.SubProducts(i).MeetingInfo(0).StartDate.ToString("MMMM d, yyyy"))
                                End If


                                Dim include As Boolean = False
                                If aSetting IsNot Nothing AndAlso aSetting <> String.Empty Then

                                    searchtype = Convert.ToString(Request("SearchType" + "_" + ModuleId.ToString))
                                    searchvalue = Convert.ToString(Request("SearchValue" + "_" + ModuleId.ToString + "_" + searchtype))


                                    Select Case searchtype
                                        Case "0"
                                            If ProductDetails.SubProducts(i).ProductInfo(0).LongName.ToLower.IndexOf(searchvalue.ToLower) >= 0 Then
                                                include = True
                                            End If
                                        Case "1"
                                            If ProductDetails.SubProducts(i).MeetingInfo(0).SessionTrackCode.Code.ToLower.IndexOf(searchvalue.ToLower) >= 0 Then
                                                include = True
                                            End If
                                        Case "2"
                                            If ProductDetails.SubProducts(i).ProductInfo(0).ProductClassCode.Code.ToLower.IndexOf(searchvalue.ToLower) >= 0 Then
                                                include = True
                                            End If
                                        Case "3"
                                            If ProductDetails.SubProducts(i).MeetingInfo(0).StartDate.ToString("MMMM d, yyyy").ToLower.IndexOf(searchvalue.ToLower) >= 0 Then
                                                include = True
                                            End If
                                        Case "4"
                                            If ProductDetails.SubProducts(i).MeetingInfo(0).FacilityLocation.ToLower.IndexOf(searchvalue.ToLower) >= 0 Then
                                                include = True
                                            End If
                                        Case Else
                                            include = True
                                    End Select
                                End If


                                If include = True Then

                                    Dim spi As New SubProductitem
                                    spi.ProductId = ProductDetails.SubProducts(i).ProductId
                                    spi.MemberPrices = ProductDetails.SubProducts(i).MemberPrices
                                    spi.ListPrices = ProductDetails.SubProducts(i).ListPrices
                                    spi.AllPrices = ProductDetails.SubProducts(i).AllPrices
                                    spi.CustomerPrice = ProductDetails.SubProducts(i).CustomerPrice

                                    spi.StartDate = ProductDetails.SubProducts(i).MeetingInfo(0).StartDate
                                    spi.EndDate = ProductDetails.SubProducts(i).MeetingInfo(0).EndDate
                                    spi.AvailableStartDate = ProductDetails.SubProducts(i).MeetingInfo(0).StartDate.ToString("MMMM d, yyyy")
                                    spi.AvailableStopDate = ProductDetails.SubProducts(i).MeetingInfo(0).EndDate.ToString("MMMM d, yyyy")

                                    spi.AvailableShortStopDate = ProductDetails.SubProducts(i).MeetingInfo(0).EndDate.ToString("MMMM d, yyyy")

                                    spi.AvailableStartTime = ProductDetails.SubProducts(i).MeetingInfo(0).StartDate.ToString("h:mm tt")
                                    spi.AvailableStopTime = ProductDetails.SubProducts(i).MeetingInfo(0).EndDate.ToString("h:mm tt")
                                    spi.LongName = ProductDetails.SubProducts(i).ProductInfo(0).LongName.ToString()
                                    spi.ImageFileName = ProductDetails.SubProducts(i).ProductInfo(0).SmallImageFileName
                                    'AN FIX
                                    spi.MaxTickets = ProductDetails.SubProducts(i).ProductInfo(0).MaximumTickets

                                    If spi.MaxTickets > 1 OrElse ProductDetails.SubProducts(i).ProductType = "BADGE" Then
                                        spi.CanUpdateQuantity = True
                                    Else
                                        spi.CanUpdateQuantity = False
                                    End If
                                    spi.Checked = False
                                    spi.Disabled = False


                                    If ProductDetails.SubProducts(i).Subsystem = "MTG" Then
                                        '3246-6117099
                                        spi.ProductType = ProductDetails.SubProducts(i).ProductType
                                        If ProductDetails.SubProducts(i).ProductType = "BADGE" Then
                                            spi.Status = Localization.GetString("AvailableMessage", LocalResourceFile)
                                        ElseIf ProductDetails.SubProducts(i).ProductType = "F" Then
                                            spi.Status = ""
                                            'spi.Checked = True  'by Aseem you need to select it
                                            'spi.Disabled = True
                                        Else
                                            Dim MeetingCapacity As Integer = ProductDetails.SubProducts(i).ProductInfo(0).MeetingCapacity
                                            Dim MeetingRegistrations As Integer = ProductDetails.SubProducts(i).ProductInfo(0).MeetingRegistrations
                                            Dim MeetingWaitListCapacity As Integer = ProductDetails.SubProducts(i).ProductInfo(0).MeetingWaitListCapacity
                                            Dim MeetingWaitListRegistrations As Integer = ProductDetails.SubProducts(i).ProductInfo(0).MeetingWaitListRegistrations

                                            If MeetingCapacity > MeetingRegistrations Then
                                                spi.Status = Localization.GetString("AvailableMessage", LocalResourceFile)
                                            End If
                                            If MeetingCapacity = MeetingRegistrations And MeetingWaitListCapacity > MeetingWaitListRegistrations Then
                                                spi.Status = Localization.GetString("WaitlistMessage", LocalResourceFile)
                                            End If
                                            If MeetingCapacity = MeetingRegistrations And MeetingWaitListCapacity = MeetingWaitListRegistrations Then
                                                spi.Status = Localization.GetString("FullMessage", LocalResourceFile)
                                            End If
                                        End If
                                        'end 3246-6117099
                                        spi.AllowSessionConflict = ProductDetails.MeetingInfo(0).AllowSessionConflictFlag

                                        'Add/Remove Sessions functionality
                                        'If oCartSubProducts.Contains(ProductDetails.SubProducts(i).ProductId) Then
                                        '    spi.Checked = True
                                        '    'AN Cuna Fix


                                        'End If
                                        If ohsCartSubProducts.Contains(ProductDetails.SubProducts(i).ProductId) Then
                                            spi.Checked = True
                                            'AN Cuna Fix
                                            spi.Quantity = ohsCartSubProducts.Item(ProductDetails.SubProducts(i).ProductId)

                                        Else
                                            'spi.Quantity = 1
                                        End If
                                        'an cuna fix

                                        'If oOrderSubProducts.Contains(ProductDetails.SubProducts(i).ProductId.ToString) Then
                                        '    spi.Checked = True
                                        '    spi.Disabled = True


                                        'End If

                                        If ohsOrderSubProducts.Contains(ProductDetails.SubProducts(i).ProductId.ToString) Then
                                            spi.Checked = True
                                            spi.Disabled = True

                                            spi.Quantity = ohsOrderSubProducts.Item(ProductDetails.SubProducts(i).ProductId.ToString)
                                        End If


                                    End If

                                    If ProductDetails.SubProducts(i).Subsystem = "INV" Then
                                        If ProductDetails.SubProducts(i).ProductInfo(0).InventoryFlag = False Then
                                            spi.Status = Localization.GetString("InStockMessage", LocalResourceFile)
                                        Else
                                            If ProductDetails.SubProducts(i).ProductInfo(0).TotalAvailableInventory > 0 Then
                                                spi.Status = Localization.GetString("InStockMessage", LocalResourceFile)
                                            Else
                                                spi.Status = Localization.GetString("OutOfStockMessage", LocalResourceFile)
                                                If ProductDetails.SubProducts(i).ProductInfo(0).NextInvReceiptDate.ToString("MMMM d, yyyy") = "01/01/0001" Then
                                                    spi.NextInvReceiptDate = ProductDetails.SubProducts(i).ProductInfo(0).NextInvReceiptDate.ToString("MMMM d, yyyy")
                                                Else
                                                    spi.NextInvReceiptDate = Nothing
                                                End If

                                            End If
                                        End If
                                    End If

                                    Dim aSpeaker As New ArrayList
                                    If ProductDetails.SubProducts(i).RelatedCustomers IsNot Nothing Then
                                        For k As Integer = 0 To ProductDetails.SubProducts(i).RelatedCustomers.Count - 1
                                            If ProductDetails.SubProducts(i).RelatedCustomers(k).CusrelationCodeString.ToLower() = "speaker" Then
                                                Dim asp As New Speaker
                                                asp.SpeakerName = ProductDetails.SubProducts(i).RelatedCustomers(k).LabelName
                                                asp.SpeakerSession = ProductDetails.SubProducts(i).ProductInfo(0).LongName.ToString()
                                                aSpeaker.Add(asp)
                                                aRC.Add(asp)
                                            End If
                                        Next
                                    End If
                                    If aSpeaker IsNot Nothing Then
                                        If aSpeaker.Count > 0 Then
                                            Dim Speakers(aSpeaker.Count - 1) As Speaker
                                            aSpeaker.CopyTo(Speakers)
                                            spi.speakers = Speakers
                                        End If
                                    End If


                                    spi.WebLongDescription = ProductDetails.SubProducts(i).ProductInfo(0).WebLongDescription

                                    spi.Track = ProductDetails.SubProducts(i).MeetingInfo(0).SessionTrackCode.Code.ToString

                                    ASubProductitems.Add(spi)
                                End If

                            Next

                            ASubProductitems.Sort()


                            Dim SubProductitems(ASubProductitems.Count - 1) As SubProductitem
                            ASubProductitems.CopyTo(SubProductitems)


                            If SubProductitems.Length > 0 Then
                                SubProductitems(0).OldStartDate = "no"
                                For j As Integer = 1 To SubProductitems.Length - 1
                                    SubProductitems(j).OldStartDate = SubProductitems(j - 1).AvailableStartDate
                                Next
                            End If


                            Dim oTrack(aTrack.Count - 1) As OptionItem
                            Dim oClass(aClass.Count - 1) As OptionItem
                            Dim oStartDate(aStartDate.Count - 1) As OptionItem

                            aTrack.Sort()
                            If aTrack IsNot Nothing Then
                                If (aTrack.Count > 0) Then
                                    For x As Integer = 0 To aTrack.Count - 1
                                        oTrack(x) = New OptionItem
                                        oTrack(x).value = aTrack(x)
                                    Next
                                Else
                                    ReDim oTrack(1)
                                    oTrack(0) = New OptionItem
                                    oTrack(0).text = "Not Available"
                                    oTrack(0).value = ""
                                End If
                            End If

                            aStartDate.Sort()
                            If aStartDate IsNot Nothing Then
                                If (aStartDate.Count > 0) Then
                                    For x As Integer = 0 To aStartDate.Count - 1
                                        oStartDate(x) = New OptionItem
                                        oStartDate(x).value = aStartDate(x)
                                    Next
                                End If
                            End If

                            aClass.Sort()
                            If aClass IsNot Nothing Then
                                If (aClass.Count > 0) Then
                                    For x As Integer = 0 To aClass.Count - 1
                                        oClass(x) = New OptionItem
                                        oClass(x).value = aClass(x)
                                    Next
                                End If
                            End If

                            Dim templatefile As String = ""

                            Try
                                templatefile = ModulePath + "Templates\" + Settings("PD_LayoutMeetingTemplateSettingsKey").ToString()
                            Catch ex As Exception
                                'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End Try

                            MeetingXslTemplate.XSLfile = Server.MapPath(templatefile)


                            Page.Session("SubProductitems" + ProductDetails.ProductId.ToString) = SubProductitems



                            If ProductDetails.RelatedCustomers IsNot Nothing Then
                                If ProductDetails.RelatedCustomers.Count > 0 Then
                                    'Dim aRC As New ArrayList
                                    For k As Integer = 0 To ProductDetails.RelatedCustomers.Count - 1
                                        If ProductDetails.RelatedCustomers(k) IsNot Nothing Then
                                            If ProductDetails.RelatedCustomers(k).CusrelationCodeString.ToLower() = "speaker" Then
                                                Dim sp As New Speaker
                                                sp.SpeakerName = ProductDetails.RelatedCustomers(k).LabelName
                                                sp.SpeakerSession = ProductDetails.ProductInfo(0).LongName
                                                aRC.Add(sp)
                                            End If
                                        End If
                                    Next

                                    If aRC.Count > 0 Then
                                        Dim Speakers(aRC.Count - 1) As Speaker
                                        aRC.CopyTo(Speakers)
                                        MeetingXslTemplate.AddObject("", Speakers)
                                    End If
                                End If
                            End If

                            Dim oSearchType(4) As OptionItem
                            oSearchType(0) = New OptionItem
                            oSearchType(0).value = "0"
                            oSearchType(0).text = Localization.GetString("SessionName.Text", LocalResourceFile)
                            oSearchType(1) = New OptionItem
                            oSearchType(1).value = "1"
                            oSearchType(1).text = Localization.GetString("MeetingTrack.Text", LocalResourceFile)
                            oSearchType(2) = New OptionItem
                            oSearchType(2).value = "2"
                            oSearchType(2).text = Localization.GetString("ProductClass.Text", LocalResourceFile)
                            oSearchType(3) = New OptionItem
                            oSearchType(3).value = "3"
                            oSearchType(3).text = Localization.GetString("Date.Text", LocalResourceFile)
                            oSearchType(4) = New OptionItem
                            oSearchType(4).value = "4"
                            oSearchType(4).text = Localization.GetString("MeetingLocation.Text", LocalResourceFile)

                            If (searchtype Is Nothing) Then searchtype = "0"

                            Dim ErrorSearchMessage As String = Localization.GetString("ErrorSearchMessage.Text", LocalResourceFile)
                            If SubProductitems IsNot Nothing Then
                                If SubProductitems.Length > 0 Then
                                    MeetingXslTemplate.AddObject("", SubProductitems)
                                    ErrorSearchMessage = ""
                                End If
                            End If
                            MeetingXslTemplate.AddObject("", aSubProductmenu)
                            If oSearchType IsNot Nothing AndAlso oSearchType.Length > 0 Then MeetingXslTemplate.AddObject("oSearchType", oSearchType)
                            If oTrack IsNot Nothing AndAlso oTrack.Length > 0 Then MeetingXslTemplate.AddObject("oTrack", oTrack)
                            If oClass IsNot Nothing AndAlso oClass.Length > 0 Then MeetingXslTemplate.AddObject("oClass", oClass)
                            MeetingXslTemplate.AddObject("oStartDate", oStartDate)
                            MeetingXslTemplate.AddObject("ModuleId", ModuleId)
                            MeetingXslTemplate.AddObject("searchtype", searchtype)
                            MeetingXslTemplate.AddObject("searchvalue", searchvalue)
                            MeetingXslTemplate.AddObject("ErrorSearchMessage", ErrorSearchMessage)

                            Dim ProductImageURL As String = ProductImagesFolder
                            MeetingXslTemplate.AddObject("ProductImageURL", ProductImageURL)
                            MeetingXslTemplate.AddObject("UpdateOrder", UpdateOrder)
                            MeetingXslTemplate.AddObject("AddRemoveSessions", AddRemoveSessions)
                            MeetingXslTemplate.AddObject("ShowBadgesHyperlink", ShowBadgesHyperlink)
                            MeetingXslTemplate.Display()

                            EditBadges_SetURL(ProductID)

                            Dim lblSummaryOfSessionSpeakers As Label
                            lblSummaryOfSessionSpeakers = CType(FindControl("lblSummaryOfSessionSpeakers"), Label)
                            If lblSummaryOfSessionSpeakers IsNot Nothing Then
                                lblSummaryOfSessionSpeakers.Text = Localization.GetString("lblSummaryOfSessionSpeakers", LocalResourceFile)
                            End If

                            If SubProductitems.Length > 0 Then

                                For j As Integer = 0 To SubProductitems.Length - 1
                                    Dim aPricingControl As New WebControls.PricingControl

                                    aPricingControl.ID = "ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(j).ProductId
                                    aPricingControl.PortalID = PortalId
                                    'ANMC
                                    aPricingControl.PortalCurrency = PortalCurrency
                                    aPricingControl.AllPrices = SubProductitems(j).AllPrices
                                    aPricingControl.ListPrices = SubProductitems(j).ListPrices
                                    aPricingControl.MemberPrices = SubProductitems(j).MemberPrices
                                    aPricingControl.YourPrices = SubProductitems(j).CustomerPrice

                                    aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)

                                    If Settings("DisplayRateCodeSettingsKey_" + ProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                                        aPricingControl.ShowRateCode = True
                                    End If


                                    Dim tempPricePlaceHolder As New PlaceHolder

                                    tempPricePlaceHolder = Me.FindControl("SubProductPricePlaceHolder" + SubProductitems(j).ProductId)
                                    If (tempPricePlaceHolder IsNot Nothing) Then
                                        tempPricePlaceHolder.Controls.Add(aPricingControl)
                                    End If

                                Next
                            End If
                            Dim tempPlaceHolder As New PlaceHolder
                           
                            If ShowAddToCartMeeting AndAlso PM.Settings.ShowButtons Then
                                'Show Add to Cart button
                                If PM.Settings.ShowAddtoCart = True AndAlso UpdateOrder = False Then
                                    LoadAddToCartInPlaceHolder()
                                End If
                                If AddRemoveSessions Then
                                    LoadUpdateCartInPlaceHolder()
                                End If
                            End If

                            If PM.Settings.ShowWishList = True And Not AddRemoveSessions AndAlso UpdateOrder = False Then
                                'if Add/Remove Sessions then WishList button is not shown
                                MeetingAddToWishListControl = New Button

                                MeetingAddToWishListControl.ID = "MeetingAddToWishListControl" + ModuleId.ToString + "_" + ProductID.ToString
                                MeetingAddToWishListControl.Visible = True
                                '3246-5774803
                                'MeetingAddToWishListControl.ImageUrl = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                                MeetingAddToWishListControl.Text = Localization.GetString("MtgAddToWishList.Text", LocalResourceFile) '"Add to Wish List"
                                'end 3246-5774803
                                MeetingAddToWishListControl.CssClass = "Button"
                                'AddHandler MeetingAddToWishListControl.Click, AddressOf SubProductAddToWishListButton_Click
                                'Dim tempPlaceHolder As New PlaceHolder
                                tempPlaceHolder = Me.FindControl("SubProductAddToWishListButtonPlaceHolder" + "_" + ModuleId.ToString)
                                If (tempPlaceHolder IsNot Nothing) Then
                                    tempPlaceHolder.Controls.Add(MeetingAddToWishListControl)
                                End If

                            End If

                            If PM.Settings.ShowBuyForGroup = True Then
                                'Dim lg As New Personify.WebUtility.LoginCustomer
                                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                                '                            Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                                '                           Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)


                                If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                    MeetingBuyForGroupControl = New Button

                                    MeetingBuyForGroupControl.ID = "MeetingBuyForGroupControl" + ModuleId.ToString + "_" + ProductID.ToString
                                    MeetingBuyForGroupControl.Visible = True

                                    '3246-5774803
                                    'MeetingBuyForGroupControl.ImageUrl = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                                    MeetingBuyForGroupControl.Text = Localization.GetString("BuyForGroup.Text", LocalResourceFile) '"Buy For Group"
                                    MeetingBuyForGroupControl.CssClass = "Button"
                                    'end 3246-5774803
                                    'AddHandler MeetingAddToWishListControl.Click, AddressOf SubProductAddToWishListButton_Click
                                    'Dim tempPlaceHolder As New PlaceHolder
                                    tempPlaceHolder = Me.FindControl("SubProductBuyForGroupButtonPlaceHolder" + "_" + ModuleId.ToString)
                                    If (tempPlaceHolder IsNot Nothing) Then
                                        tempPlaceHolder.Controls.Add(MeetingBuyForGroupControl)
                                    End If
                                End If
                            End If

                            If PM.Settings.ShowUpdateOrder = True AndAlso UpdateOrder = True Then
                                'Dim lg As New Personify.WebUtility.LoginCustomer
                                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                                'Dim MasterCustomerId As String = lg.MasterCustomerId
                                'Dim SubCustomerId As Integer = lg.SubCustomerId

                                'should check if it your order
                                'If (ApplicationManager.AffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                MeetingUpdateOrderControl = New Button

                                MeetingUpdateOrderControl.ID = "MeetingUpdateOrderControl" + ModuleId.ToString + "_" + ProductID.ToString
                                MeetingUpdateOrderControl.Visible = True

                                'MeetingUpdateOrderControl.ImageUrl = GetUpdateOrderImageURL() 'ModulePath & "images/btn_UpdateOrder.gif"
                                MeetingUpdateOrderControl.Text = Localization.GetString("MtgUpdateOrder.Text", LocalResourceFile) '"Update Order"
                                MeetingUpdateOrderControl.CssClass = "Button"
                                tempPlaceHolder = Me.FindControl("SubProductUpdateOrderButtonPlaceHolder" + "_" + ModuleId.ToString)
                                If (tempPlaceHolder IsNot Nothing) Then
                                    tempPlaceHolder.Controls.Add(MeetingUpdateOrderControl)
                                    'End If
                                End If
                            End If

                        End If
                    End If
                Else

                    'Dim searchtype As String = "0"
                    'Dim searchvalue As String = ""

                    Dim templatefile As String = ""

                    Try
                        templatefile = ModulePath + "Templates\" + Settings("PD_LayoutMeetingTemplateSettingsKey").ToString()
                    Catch ex As Exception

                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End Try

                    MeetingXslTemplate.XSLfile = Server.MapPath(templatefile)


                    MeetingXslTemplate.AddObject("ModuleId", ModuleId)


                    Dim ProductImageURL As String = ProductImagesFolder
                    MeetingXslTemplate.AddObject("ProductImageURL", ProductImageURL)
                    MeetingXslTemplate.AddObject("UpdateOrder", UpdateOrder)
                    MeetingXslTemplate.Display()



                    If ShowAddToCartMeeting AndAlso PM.Settings.ShowButtons Then

                        Dim tempPlaceHolder As New PlaceHolder
                        tempPlaceHolder = Me.FindControl("SubProductAddToCartButtonPlaceHolder" + "_" + ModuleId.ToString)


                        If PM.Settings.ShowAddtoCart = True Then
                            MeetingAddToCartControl = New Button

                            MeetingAddToCartControl.ID = "MeetingAddToCartControl" + ModuleId.ToString + "_" + ProductID.ToString
                            MeetingAddToCartControl.Visible = True

                            '3246-5774803
                            'MeetingAddToCartControl.ImageUrl = GetAddToCartImageURL() 'ModulePath & "images/btn_addtocart.gif"
                            'end 3246-5774803
                            MeetingAddToCartControl.Text = Localization.GetString("MtgAddToCart.Text", LocalResourceFile) ' "Add to Cart"

                            MeetingAddToCartControl.CssClass = "Button"
                            'AddHandler MeetingAddToCartControl.Click, AddressOf SubProductAddToCartButton_Click
                            If (tempPlaceHolder IsNot Nothing) Then
                                tempPlaceHolder.Controls.Add(MeetingAddToCartControl)
                            End If
                        End If

                        If PM.Settings.ShowWishList = True Then
                            MeetingAddToWishListControl = New Button

                            MeetingAddToWishListControl.ID = "MeetingAddToWishListControl" + ModuleId.ToString + "_" + ProductID.ToString
                            MeetingAddToWishListControl.Visible = True

                            '3246-5774803
                            'MeetingAddToWishListControl.ImageUrl = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                            MeetingAddToWishListControl.Text = Localization.GetString("MtgAddToWishList.Text", LocalResourceFile) ' "Add to Wish List"
                            MeetingAddToWishListControl.CssClass = "Button"
                            'end 3246-5774803
                            'AddHandler MeetingAddToWishListControl.Click, AddressOf SubProductAddToWishListButton_Click
                            'Dim tempPlaceHolder As New PlaceHolder
                            tempPlaceHolder = Me.FindControl("SubProductAddToWishListButtonPlaceHolder" + "_" + ModuleId.ToString)
                            If (tempPlaceHolder IsNot Nothing) Then
                                tempPlaceHolder.Controls.Add(MeetingAddToWishListControl)
                            End If

                        End If
                        If PM.Settings.BuyForGroupURL = True Then

                            'Dim lg As New Personify.WebUtility.LoginCustomer
                            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                            'Dim MasterCustomerId As String = lg.MasterCustomerId
                            'Dim SubCustomerId As Integer = lg.SubCustomerId

                            If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                MeetingBuyForGroupControl = New Button

                                MeetingBuyForGroupControl.ID = "MeetingBuyForGroupControl" + ModuleId.ToString + "_" + ProductID.ToString
                                MeetingBuyForGroupControl.Visible = True

                                '3246-5774803
                                'MeetingBuyForGroupControl.ImageUrl = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                                'end 3246-5774803
                                MeetingBuyForGroupControl.Text = Localization.GetString("BuyForGroup.Text", LocalResourceFile) '"Buy For Group"
                                MeetingBuyForGroupControl.CssClass = "Button"
                                'AddHandler MeetingAddToWishListControl.Click, AddressOf SubProductAddToWishListButton_Click
                                'Dim tempPlaceHolder As New PlaceHolder
                                tempPlaceHolder = Me.FindControl("SubProductBuyForGroupButtonPlaceHolder" + "_" + ModuleId.ToString)
                                If (tempPlaceHolder IsNot Nothing) Then
                                    tempPlaceHolder.Controls.Add(MeetingBuyForGroupControl)
                                End If
                            End If
                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub
       
        Private Sub LoadAddToCartInPlaceHolder()
            Dim tempPHolder As New PlaceHolder
            tempPHolder = Me.FindControl("SubProductAddToCartButtonPlaceHolder" + "_" + ModuleId.ToString)

            MeetingAddToCartControl = New Button
            MeetingAddToCartControl.ID = "MeetingAddToCartControl" + ModuleId.ToString + "_" + ProductID.ToString
            MeetingAddToCartControl.Visible = True
            '3246-5774803
            'MeetingAddToCartControl.ImageUrl = GetAddToCartImageURL()
            If AddRemoveSessions Then
                MeetingAddToCartControl.Text = Localization.GetString("MtgAddToCartAlternate.Text", LocalResourceFile)
            Else
                MeetingAddToCartControl.Text = Localization.GetString("MtgAddToCart.Text", LocalResourceFile)
            End If
            ' "Add to Cart"
            'end 3246-5774803
            ' MeetingAddToCartControl.Style.Add("Class", "button")
            MeetingAddToCartControl.CssClass = "Button"
            If (tempPHolder IsNot Nothing) Then
                tempPHolder.Controls.Add(MeetingAddToCartControl)
            End If

        End Sub

        Private Sub LoadUpdateCartInPlaceHolder()
            Dim tempPHolder As New PlaceHolder
            tempPHolder = Me.FindControl("SubProductUpdateCartButtonPlaceHolder" + "_" + ModuleId.ToString)

            MeetingUpdateCartControl = New Button

            MeetingUpdateCartControl.ID = "MeetingUpdateCartControl" + ModuleId.ToString + "_" + ProductID.ToString
            MeetingUpdateCartControl.Visible = True
            '3246-5774803
            'MeetingUpdateCartControl.ImageUrl = GetUpdateCartImageURL() 'ModulePath & "images/btn_updatecart.gif"
            MeetingUpdateCartControl.Text = Localization.GetString("MtgUpdateCart.Text", LocalResourceFile) '"Update Shopping Cart"

            MeetingUpdateCartControl.CssClass = "Button"
            'end 3246-5774803
            If (tempPHolder IsNot Nothing) Then
                tempPHolder.Controls.Add(MeetingUpdateCartControl)
            End If
        End Sub
        Private Sub UpdateCartButton_Click( _
   ByVal MasterCustomerId As String, _
   ByVal SubCustomerId As Integer, _
   ByVal isWishList As Boolean)

            Try
               
                Dim tempCheckBox As CheckBox
                Dim clsCartItemStatus As clsCheckIfItemExistsInCart
                Dim NewCartItemQty As Integer
                Dim hListOfNewlyAddedItems As New Hashtable


                Dim aPrice As Decimal = Convert.ToDecimal(Request("ProductPricingControl" + ModuleId.ToString + "_price"))
                Dim aRateCode As String = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_rs"))
                'Fixed Ticket #3246-8157039

                Dim HasValidScheduledPrice As Boolean
                If Request("ProductPricingControl" + ModuleId.ToString + "_hasValidScheduledPrice") IsNot Nothing Then
                    HasValidScheduledPrice = Convert.ToBoolean(Request("ProductPricingControl" + ModuleId.ToString + "_hasValidScheduledPrice"))
                End If


                Dim MainCartItemId As Integer = CartItemId
                'Get components from shopping cart
                Dim CList As System.Collections.ArrayList

                Dim oManager As New ShoppingCartManager.Business.ShoppingCartController

                CList = oManager.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, False, CartItemId)

                'Main Cart Item Id NOT REQUIRED
                'MainCartItemId = AddToCart(MasterCustomerId, SubCustomerId, CType(ProductDetails.ProductId, Integer), 0, ProductDetails, 1, aRateCode, aRateStructure, aPrice, isWishList, HasValidScheduledPrice)
                'MainProductAdded = True	''add only once
                'End If

                Dim SubProductitems() As SubProductitem = CType(Page.Session("SubProductitems" + ProductDetails.ProductId.ToString), SubProductitem())


                If SubProductitems IsNot Nothing AndAlso SubProductitems.Length > 0 Then
                    For i As Integer = 0 To SubProductitems.Length - 1
                        If SubProductitems(i) IsNot Nothing Then
                            tempCheckBox = Me.FindControl("SubProductCheckBox_" + ModuleId.ToString + "_" + SubProductitems(i).ProductId.ToString)

                            If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then

                                If Request(tempCheckBox.UniqueID) = "on" Then
                                    'Add list of newly added items to hastable. This is used for deleting the items inthe cart
                                    hListOfNewlyAddedItems.Add(SubProductitems(i).ProductId, "Added")

                                    NewCartItemQty = GetQuantity(CType(SubProductitems(i).ProductId, Long))

                                    clsCartItemStatus = CheckIfItemExistsInCart(SubProductitems(i).ProductId, CList, NewCartItemQty)

                                    If clsCartItemStatus.IsItemInCart = True Then
                                        If clsCartItemStatus.IsQuanityChangeRequired = True Then
                                            oManager.UpdateCartQuantityByCartItemId(MasterCustomerId, SubCustomerId, clsCartItemStatus.CartItemId, NewCartItemQty)
                                        End If

                                    Else

                                        Dim aProductDetails As ProductDetails
                                        aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(SubProductitems(i).ProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True, , , , , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))

                                        aPrice = Convert.ToDecimal(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_price"))
                                        aRateCode = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_rc"))
                                        aRateStructure = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_rs"))
                                        'Fixed Ticket #3246-8157039
                                        If Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_hasValidScheduledPrice") IsNot Nothing Then
                                            HasValidScheduledPrice = Convert.ToBoolean(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_hasValidScheduledPrice"))
                                        End If



                                        ' add each subproduct
                                        AddToCart(MasterCustomerId, SubCustomerId, ProductDetails.ProductId, CType(SubProductitems(i).ProductId, Integer), aProductDetails, GetQuantity(CType(SubProductitems(i).ProductId, Long)), aRateCode, aRateStructure, aPrice, isWishList, HasValidScheduledPrice, MainCartItemId)

                                    End If


                                    'check if the product already exists in cart


                                End If
                            End If
                        End If
                    Next
                End If

                'delete remaining items from the cart
                For i As Integer = 0 To CList.Count - 1
                    If Not hListOfNewlyAddedItems.Contains(CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).SubProductId.ToString) Then

                        oManager.DeleteCartItemByCartItemId(MasterCustomerId, SubCustomerId, CType(CList(i), ShoppingCartManager.Business.ShoppingCartInfo).CartItemId, False)
                        ' oManager.DeleteShoppingCartComponentsItemByCartItemId(MasterCustomerId, SubCustomerId, CType(CList(0), ShoppingCartManager.Business.ShoppingCartInfo).CartItemId)
                    End If

                Next


                Dim url As String = String.Empty

                If Settings("US_MeetingURLSettingsKey") IsNot Nothing AndAlso Settings("US_MeetingURLSettingsKey").ToString <> String.Empty AndAlso Settings("US_MeetingURLTypeSettingsKey").ToString <> "N" Then
                    If Not Settings("US_MeetingURLTypeSettingsKey").ToString Is Nothing AndAlso Settings("US_MeetingURLTypeSettingsKey").ToString = "T" Then
                        Url = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("US_MeetingURLSettingsKey"), Integer)))
                        Response.Redirect(Url + "?productid=" + ProductDetails.ProductId.ToString)
                    End If
                End If
          
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Class clsCheckIfItemExistsInCart
            Public IsItemInCart As Boolean
            Public IsQuanityChangeRequired As Boolean
            Public CartItemId As Integer
        End Class
        Private Function CheckIfItemExistsInCart(ByVal PID As Long, ByVal pComponentList As System.Collections.ArrayList, ByVal NewQty As Integer) As clsCheckIfItemExistsInCart

            Dim retCls As New clsCheckIfItemExistsInCart
            retCls.IsQuanityChangeRequired = False
            retCls.IsItemInCart = False
            ' CType(pComponentList(0), ShoppingCartManager.Business.ShoppingCartInfo).
            For i As Integer = 0 To pComponentList.Count - 1
                If CType(pComponentList(i), ShoppingCartManager.Business.ShoppingCartInfo).SubProductId = PID Then
                    retCls.IsItemInCart = True
                    If CType(pComponentList(i), ShoppingCartManager.Business.ShoppingCartInfo).Quantity <> NewQty Then
                        retCls.IsQuanityChangeRequired = True
                    End If
                    retCls.CartItemId = CType(pComponentList(i), ShoppingCartManager.Business.ShoppingCartInfo).CartItemId
                    Exit For
                End If

            Next

            Return retCls
        End Function


        Private Sub SubProductButton_Click( _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
        ByVal isWishList As Boolean)

            Try
                'an update meeting fix
                'If AddRemoveSessions Then
                '    'if Add/Remove Sessions then delete CartItemId - then Add to Cart
                '    UpdateCart_DeleteItemsFromCart(MasterCustomerId, SubCustomerId, CartItemId)
                'End If

                Dim quantity As Integer = 1

                'Dim MainProductAdded = False

                Dim aPrice As Decimal = Convert.ToDecimal(Request("ProductPricingControl" + ModuleId.ToString + "_price"))
                Dim aRateCode As String = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_rs"))
                'Fixed Ticket #3246-8157039
                Dim HasValidScheduledPrice As Boolean
                If Request("ProductPricingControl" + ModuleId.ToString + "_hasValidScheduledPrice") IsNot Nothing Then
                    HasValidScheduledPrice = Convert.ToBoolean(Request("ProductPricingControl" + ModuleId.ToString + "_hasValidScheduledPrice"))
                End If
                'If MainProductAdded = False Then
                ' add main product
                Dim MainCartItemId As Integer

                MainCartItemId = AddToCart(MasterCustomerId, SubCustomerId, CType(ProductDetails.ProductId, Integer), 0, ProductDetails, 1, aRateCode, aRateStructure, aPrice, isWishList, HasValidScheduledPrice)
                'MainProductAdded = True	''add only once
                'End If

                Dim SubProductitems() As SubProductitem = CType(Page.Session("SubProductitems" + ProductDetails.ProductId.ToString), SubProductitem())
                Dim sProductIds As String = ""
                If SubProductitems IsNot Nothing Then
                    If SubProductitems.Length > 0 Then
                        Dim tempCheckBox As CheckBox
                        Dim i As Integer
                        For i = 0 To SubProductitems.Length - 1
                            If SubProductitems(i) IsNot Nothing Then
                                tempCheckBox = Me.FindControl("SubProductCheckBox_" + ModuleId.ToString + "_" + SubProductitems(i).ProductId.ToString)

                                If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
                                    'If (DirectCast(tempCheckBox, CheckBox).Checked = True) Then
                                    If Request(tempCheckBox.UniqueID) = "on" Then

                                        Dim aProductDetails As ProductDetails
                                        aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(SubProductitems(i).ProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True, , , , , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))

                                        aPrice = Convert.ToDecimal(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_price"))
                                        aRateCode = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_rc"))
                                        aRateStructure = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_rs"))
                                        'Fixed Ticket #3246-8157039
                                        If Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_hasValidScheduledPrice") IsNot Nothing Then
                                            HasValidScheduledPrice = Convert.ToBoolean(Request("ProductPricingControl" + ModuleId.ToString + "_" + SubProductitems(i).ProductId + "_hasValidScheduledPrice"))
                                        End If


                                        If UpdateOrder = True Then
                                            'add each subproduct to order
                                            If sProductIds.Length > 0 Then
                                                sProductIds = sProductIds + ","
                                            End If
                                            'sProductIds = sProductIds + SubProductitems(i).ProductId.ToString
                                            'AN CUNA FIX - got to add the qty to the URL also
                                            sProductIds = String.Concat(sProductIds, SubProductitems(i).ProductId.ToString, "q", GetQuantity(CType(SubProductitems(i).ProductId, Long)))


                                        Else
                                            ' add each subproduct
                                            AddToCart(MasterCustomerId, SubCustomerId, ProductDetails.ProductId, CType(SubProductitems(i).ProductId, Integer), aProductDetails, GetQuantity(CType(SubProductitems(i).ProductId, Long)), aRateCode, aRateStructure, aPrice, isWishList, HasValidScheduledPrice, MainCartItemId)

                                        End If

                                        quantity = quantity + 1

                                    End If
                                End If
                            End If
                        Next
                    End If
                End If

                'If the user is updating the cart, then badges need to be transferred to the new cart tiem id


                Dim url As String = String.Empty

                If UpdateOrder = True Then
                    If Settings("UpdateOrderURLSettingsKey") IsNot Nothing AndAlso Settings("UpdateOrderURLSettingsKey").ToString <> String.Empty AndAlso Settings("UpdateOrderURLTypeSettingsKey").ToString <> "N" Then
                        If Not Settings("UpdateOrderURLTypeSettingsKey").ToString Is Nothing AndAlso Settings("UpdateOrderURLTypeSettingsKey").ToString = "T" Then
                            url = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("UpdateOrderURLSettingsKey"), Integer)))
                            Response.Redirect(url + "?MODE=EDITORDER&ORDERNUMBER=" + OrderNumber.ToString + "&ORDERLINENUMBER=" + OrderLineNumber.ToString + "&PRODUCTID=" + sProductIds.ToString)
                        End If
                    End If
                Else
                    If Settings("US_MeetingURLSettingsKey") IsNot Nothing AndAlso Settings("US_MeetingURLSettingsKey").ToString <> String.Empty AndAlso Settings("US_MeetingURLTypeSettingsKey").ToString <> "N" Then
                        If Not Settings("US_MeetingURLTypeSettingsKey").ToString Is Nothing AndAlso Settings("US_MeetingURLTypeSettingsKey").ToString = "T" Then
                            url = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("US_MeetingURLSettingsKey"), Integer)))
                            Response.Redirect(url + "?productid=" + ProductDetails.ProductId.ToString)
                        End If
                    End If
                End If

                'http://localhost/Personify/m3/tabid/172/Default.aspx?MODE=EDITORDER&ORDERNUMBER=1000000607&ORDERLINENUMBER=2&PRODUCTID=430


                'MessageControl.ShowMessage(Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), WebControls.MessageControl.TIMMSMessageType.GreenSuccess)
                If isWishList = False Then
                    'MessageControl.ShowMessage(Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), WebControls.MessageControl.TIMMSMessageType.GreenSuccess)
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Else
                    'MessageControl.ShowMessage(Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), WebControls.MessageControl.TIMMSMessageType.GreenSuccess)
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub UpdateCart_DeleteItemsFromCart(ByVal MCID As String, ByVal SCID As Integer, ByVal CItemID As Integer)
            Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
            oCartController.DeleteCartItemByCartItemId(MasterCustomerId, SubCustomerId, CartItemId, False)
        End Sub




        Private Function GetQuantity(ByVal PID As Long) As Integer


            Dim intQty As Integer = 1
            Dim txtQty As TextBox

            txtQty = Me.FindControl("txtQty_" + ModuleId.ToString + "_" + PID.ToString)
            If txtQty IsNot Nothing Then
                If Not String.IsNullOrEmpty(Request(txtQty.UniqueID)) Then
                    intQty = CInt(Request(txtQty.UniqueID))
                End If

            End If

            Return intQty
        End Function

        Private Sub SubProductAddToCartButton_Click()


            SubProductButton_Click(MasterCustomerId, SubCustomerId, False)
        End Sub

        Private Sub SubProductAddToWishListButton_Click()
            SubProductButton_Click(MasterCustomerId, SubCustomerId, True)
        End Sub

        Private Sub SubProductBuyforGroupButton_Click()

            Dim guid As String = Convert.ToString(AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId))
            If guid Is Nothing Then
                guid = System.Guid.NewGuid().ToString("N").ToUpper()
                If guid.Length > 20 Then
                    guid = guid.Substring(1, 20)
                End If
                AffiliateManagementSessionHelper.SetGroupPurchaseInfo(PortalId, guid)
            End If

            SubProductButton_Click(guid, 0, False)

            'Dim intTabId As Integer = AffiliateManagementSessionHelper.GetCurrentSegmentGroupPurchaseActionURL(0)
            'If intTabId = 0 Then
            '    Response.Redirect(NavigateURL(CType(Settings("PD_BUYFORGROUPURLSettingsKey"), Integer)))
            'Else
            '    Response.Redirect(NavigateURL(intTabId))
            'End If


        End Sub

        Private Sub SubProductUpdateOrderButton_Click()

            SubProductButton_Click(0, 0, False)
            'Response.Redirect(NavigateURL(CType(Settings("PD_UpdateOrderURLSettingsKey"), Integer)))

        End Sub
        Public Class DCDmenu
            Public DocumentTitle As String
            Public TitleFee As String
        End Class

        Public Class DCDitem
            Public FileId As String
            Public FileName As String
            Public DocumentTitle As String
            Public Description As String
            Public Quantity As String
            Public AllPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public ListPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public MemberPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public CustomerPrices As ApplicationManager.PersonifyDataObjects.WebPrices
            Public DisplayCopyright As Boolean
            Public CopyrightText As String
        End Class

        Private Sub LoadDCD()
            Try
                If ProductDetails IsNot Nothing Then
                    If ProductDetails.DCDFileListing IsNot Nothing Then
                        If ProductDetails.DCDFileListing.Count > 0 Then
                            Dim aDCDmenu As New DCDmenu

                            aDCDmenu.DocumentTitle = Localization.GetString("DocumentTitle.Text", LocalResourceFile)
                            aDCDmenu.TitleFee = Localization.GetString("TitleFee.Text", LocalResourceFile)

                            Dim DCDitems(ProductDetails.DCDFileListing.Count - 1) As DCDitem
                            Dim i As Integer
                            For i = 0 To ProductDetails.DCDFileListing.Count - 1
                                DCDitems(i) = New DCDitem
                                DCDitems(i).FileId = ProductDetails.DCDFileListing(i).FileId
                                DCDitems(i).FileName = ProductDetails.DCDFileListing(i).FileName
                                DCDitems(i).DocumentTitle = ProductDetails.DCDFileListing(i).DocumentTitle
                                DCDitems(i).Description = ProductDetails.DCDFileListing(i).Description
                                DCDitems(i).DisplayCopyright = ProductDetails.DCDFileListing(i).DisplayCopyrightFlag
                                DCDitems(i).CopyrightText = ProductDetails.DCDFileListing(i).CopyrightText
                                DCDitems(i).Quantity = "1"
                                Try
                                    DCDitems(i).AllPrices = ProductDetails.AllPrices
                                Catch ex As Exception

                                End Try
                                Try
                                    DCDitems(i).ListPrices = ProductDetails.ListPrices
                                Catch ex As Exception
                                End Try
                                Try
                                    DCDitems(i).MemberPrices = ProductDetails.MemberPrices
                                Catch ex As Exception
                                End Try
                                Try
                                    DCDitems(i).CustomerPrices = ProductDetails.CustomerPrice
                                Catch ex As Exception
                                End Try
                            Next

                            Dim templatefile As String = ""

                            Try
                                templatefile = ModulePath + "Templates\" + Settings("PD_LayoutDCDTemplateSettingsKey").ToString()
                            Catch ex As Exception
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                                'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
                            End Try

                            DCDXslTemplate.XSLfile = Server.MapPath(templatefile)

                            Page.Session(String.Concat("DCDitems", ProductDetails.ProductId.ToString)) = DCDitems
                            DCDXslTemplate.AddObject("", DCDitems)
                            DCDXslTemplate.AddObject("", aDCDmenu)
                            DCDXslTemplate.AddObject("ModuleId", ModuleId)
                            PM.Settings.Load()
                            DCDXslTemplate.AddObject("DisplayDownloadTerm", PM.Settings.DisplayDownloadTerm)

                            DCDXslTemplate.Display()

                            If DCDitems.Length > 0 Then

                                For j As Integer = 0 To DCDitems.Length - 1
                                    Dim aPricingControl As New WebControls.PricingControl

                                    aPricingControl.ID = String.Concat("DCDPricingControl", ModuleId.ToString, "_", DCDitems(j).FileId)
                                    aPricingControl.PortalID = PortalId
                                    'ANMC
                                    aPricingControl.PortalCurrency = PortalCurrency
                                    aPricingControl.AllPrices = DCDitems(j).AllPrices
                                    aPricingControl.ListPrices = DCDitems(j).ListPrices
                                    aPricingControl.MemberPrices = DCDitems(j).MemberPrices
                                    aPricingControl.YourPrices = DCDitems(j).CustomerPrices

                                    aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)

                                    If Settings("DisplayRateCodeSettingsKey_" + ProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                                        aPricingControl.ShowRateCode = True
                                    End If

                                    If Me.IsPersonifyWebUserLoggedIn Then
                                        aPricingControl.IsMember = True
                                    Else
                                        aPricingControl.IsMember = False
                                    End If

                                    Dim tempPricePlaceHolder As New PlaceHolder

                                    tempPricePlaceHolder = Me.FindControl(String.Concat("DCDPricePlaceHolder", DCDitems(j).FileId))
                                    If (tempPricePlaceHolder IsNot Nothing) Then
                                        tempPricePlaceHolder.Controls.Add(aPricingControl)
                                    End If

                                Next
                            End If

                            Dim tempPlaceHolder As PlaceHolder
                            If PM.Settings.ShowAddtoCart And Not AddRemoveSessions Then
                                DCDAddToCartControl = New Button

                                DCDAddToCartControl.ID = String.Concat("DCDAddToCartControl", ModuleId.ToString, "_", ProductID.ToString)
                                DCDAddToCartControl.Visible = True
                                'DCDAddToCartControl.ImageUrl = GetAddToCartImageURL()
                                DCDAddToCartControl.Text = Localization.GetString("AddToCart.Text", LocalResourceFile) ' "Add to Cart"
                                DCDAddToCartControl.CssClass = "Button"
                                tempPlaceHolder = New PlaceHolder
                                tempPlaceHolder = Me.FindControl(String.Concat("DCDAddToCartButtonPlaceHolder_", ModuleId.ToString))
                                If (tempPlaceHolder IsNot Nothing) Then
                                    tempPlaceHolder.Controls.Add(DCDAddToCartControl)
                                End If
                            End If

                            If PM.Settings.ShowWishList And Not AddRemoveSessions Then
                                DCDAddToWishListControl = New Button

                                DCDAddToWishListControl.ID = String.Concat("DCDAddToWishListControl", ModuleId.ToString, "_", ProductID.ToString)
                                DCDAddToWishListControl.Visible = True
                                'DCDAddToWishListControl.ImageUrl = GetWishListImageURL()
                                DCDAddToWishListControl.Text = Localization.GetString("AddToWishList.Text", LocalResourceFile) ' "Add to Wish List"
                                DCDAddToWishListControl.CssClass = "Button"
                                tempPlaceHolder = New PlaceHolder
                                tempPlaceHolder = Me.FindControl(String.Concat("DCDAddToWishListButtonPlaceHolder_", ModuleId.ToString))
                                If (tempPlaceHolder IsNot Nothing) Then
                                    tempPlaceHolder.Controls.Add(DCDAddToWishListControl)
                                End If
                            End If

                            If PM.Settings.BuyForGroupURL = True Then
                                'Dim lg As New Personify.WebUtility.LoginCustomer
                                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                                'Dim MasterCustomerId As String = lg.MasterCustomerId
                                'Dim SubCustomerId As Integer = lg.SubCustomerId

                                If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                    DCDBuyForGroupControl = New Button

                                    DCDBuyForGroupControl.ID = String.Concat("DCDBuyForGroupControl", ModuleId.ToString, "_", ProductID.ToString)
                                    DCDBuyForGroupControl.Visible = True
                                    'DCDBuyForGroupControl.ImageUrl = GetBuyForGroupImageURL()
                                    DCDBuyForGroupControl.Text = Localization.GetString("BuyForGroup.Text", LocalResourceFile) '"Buy For Group"
                                    DCDBuyForGroupControl.CssClass = "Button"
                                    tempPlaceHolder = New PlaceHolder
                                    tempPlaceHolder = Me.FindControl(String.Concat("DCDBuyForGroupButtonPlaceHolder_", ModuleId.ToString))
                                    If (tempPlaceHolder IsNot Nothing) Then
                                        tempPlaceHolder.Controls.Add(DCDBuyForGroupControl)
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub DCDProductButton_Click( _
 ByVal MasterCustomerId As String, _
 ByVal SubCustomerId As Integer, _
 ByVal isWishList As Boolean)
            If ValidateAddDCDProduct() Then
                Try
                    'If AddRemoveSessions Then
                    '    'if Add/Remove Sessions then delete CartItemId - then Add to Cart
                    '    Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                    '    oCartController.DeleteCartItemByCartItemId(MasterCustomerId, SubCustomerId, CartItemId, False)
                    'End If

                    Dim quantity As Integer = 1

                    'Dim MainProductAdded = False

                    Dim aPrice As Decimal = 0
                    Dim aRateCode As String = ""
                    Dim aRateStructure As String = ""
                    Dim MainCartItemId As Integer
                    Dim DCDProductItems() As DCDitem = CType(Page.Session(String.Concat("DCDitems", ProductDetails.ProductId.ToString)), DCDitem())
                    Dim DCDFileIds As String = ""

                    If DCDProductItems IsNot Nothing Then
                        If DCDProductItems.Length > 0 Then
                            aPrice = Convert.ToDecimal(Request(String.Concat("DCDPricingControl", ModuleId.ToString, "_", DCDProductItems(0).FileId, "_price")))
                            aRateCode = Convert.ToString(Request(String.Concat("DCDPricingControl", ModuleId.ToString, "_", DCDProductItems(0).FileId, "_rc")))
                            aRateStructure = Convert.ToString(Request(String.Concat("DCDPricingControl", ModuleId.ToString + "_", DCDProductItems(0).FileId, "_rs")))
                            MainCartItemId = AddToCart(MasterCustomerId, SubCustomerId, CType(ProductDetails.ProductId, Integer), 0, ProductDetails, 1, aRateCode, aRateStructure, aPrice, isWishList, False)
                            Dim tempCheckBox As CheckBox
                            Dim i As Integer
                            Dim oDCDFilesCartInfo As ShoppingCartManager.Business.ShoppingCartDCDFilesInfo
                            Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                            For i = 0 To DCDProductItems.Length - 1
                                If DCDProductItems(i) IsNot Nothing Then
                                    tempCheckBox = Me.FindControl(String.Concat("DCDCheckBox_", ModuleId.ToString, "_", DCDProductItems(i).FileId.ToString))

                                    If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
                                        If Request(tempCheckBox.UniqueID) = "on" Then
                                            'aPrice = Convert.ToDecimal(Request(String.Concat("DCDPricingControl", ModuleId.ToString, "_", DCDProductItems(i).FileId, "_price")))
                                            'aRateCode = Convert.ToString(Request(String.Concat("DCDPricingControl", ModuleId.ToString, "_", DCDProductItems(i).FileId, "_rc")))
                                            'aRateStructure = Convert.ToString(Request(String.Concat("DCDPricingControl", ModuleId.ToString + "_", DCDProductItems(i).FileId, "_rs")))

                                            'If UpdateOrder = True Then
                                            '    'add each subproduct to order
                                            '    If sProductIds.Length > 0 Then
                                            '        sProductIds = sProductIds + ","
                                            '    End If
                                            '    sProductIds = sProductIds + SubProductitems(i).ProductId.ToString
                                            'Else
                                            ' add each subproduct
                                            'AddToCart(MasterCustomerId, SubCustomerId, ProductDetails.ProductId, CType(DCDProductItems(i).FileId, Integer), aProductDetails, 1, aRateCode, aRateStructure, aPrice, isWishList, MainCartItemId)

                                            'End If


                                            oDCDFilesCartInfo = New ShoppingCartManager.Business.ShoppingCartDCDFilesInfo

                                            With oDCDFilesCartInfo
                                                .CartItemId = MainCartItemId
                                                .MasterCustomerId = MasterCustomerId
                                                .SubCustomerId = SubCustomerId
                                                .ProductId = ProductDetails.ProductId
                                                .CopyrightText = DCDProductItems(i).CopyrightText
                                                .DisplayCopyright = DCDProductItems(i).DisplayCopyright
                                                .FileId = DCDProductItems(i).FileId
                                                .FileName = DCDProductItems(i).FileName
                                                .DocumentTitle = DCDProductItems(i).DocumentTitle
                                                .IsWishList = isWishList
                                                .ModuleId = ModuleId
                                                .PortalId = PortalId
                                                .AddDate = Date.Now()
                                                .ModDate = Date.Now()
                                            End With

                                            oCartController.AddShoppingCartDCDFiles(oDCDFilesCartInfo)

                                            quantity = quantity + 1
                                        End If
                                    End If
                                End If
                            Next
                            If Not oCartController Is Nothing Then
                                oCartController.Dispose()
                            End If
                        End If
                    End If

                    Dim url As String = String.Empty

                    If isWishList = False Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", quantity.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    End If

                Catch exc As Exception
                    ProcessModuleLoadException(Me, exc)
                End Try
            End If
        End Sub

        Private Function ValidateAddDCDProduct() As Boolean
            Try
                Dim DCDProductItems() As DCDitem = CType(Page.Session(String.Concat("DCDitems", ProductDetails.ProductId.ToString)), DCDitem())
                Dim DCDFileIds As String = ""
                Dim AtLeastOneFileSelected As Boolean = False
                Dim AcceptedTerm As Boolean = True
                If DCDProductItems IsNot Nothing Then
                    If DCDProductItems.Length > 0 Then
                        Dim tempCheckBox As CheckBox
                        Dim i As Integer
                        For i = 0 To DCDProductItems.Length - 1
                            If DCDProductItems(i) IsNot Nothing Then
                                tempCheckBox = Me.FindControl(String.Concat("DCDCheckBox_", ModuleId.ToString, "_", DCDProductItems(i).FileId.ToString))
                                If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
                                    If Request(tempCheckBox.UniqueID) = "on" Then
                                        AtLeastOneFileSelected = True
                                        If DCDProductItems(i).DisplayCopyright Then
                                            tempCheckBox = Me.FindControl(String.Concat("chkAcceptTerm_", ModuleId.ToString, "_", DCDProductItems(i).FileId.ToString))
                                            If tempCheckBox IsNot Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
                                                If Not Request(tempCheckBox.UniqueID) = "on" Then
                                                    AcceptedTerm = False
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        Next
                    End If
                End If

                Dim url As String = String.Empty

                If Not AtLeastOneFileSelected Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SelectDCDFile.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                Else
                    If Not AcceptedTerm Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AcceptTerm.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
                Return False
            End Try
            Return True
        End Function

        Private Sub DCDProductAddToCartButton_Click()

            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId


            DCDProductButton_Click(MasterCustomerId, SubCustomerId, False)
        End Sub

        Private Sub DCDProductAddToWishListButton_Click()
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            DCDProductButton_Click(MasterCustomerId, SubCustomerId, True)
        End Sub

        Private Sub DCDProductBuyforGroupButton_Click()

            Dim guid As String = Convert.ToString(AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId))
            If guid Is Nothing Then
                guid = System.Guid.NewGuid().ToString("N").ToUpper()
                If guid.Length > 20 Then
                    guid = guid.Substring(1, 20)
                End If
                AffiliateManagementSessionHelper.SetGroupPurchaseInfo(PortalId, guid)
            End If

            DCDProductButton_Click(guid, 0, False)

        End Sub

        'Private Sub DCDAddToCartButton_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles DCDAddToCartControl.Click

        '    Try
        '        Dim s As String = ""
        '        Dim DCDitems() As DCDitem = CType(Page.Session("DCDitems" + ModuleId.ToString), DCDitem())
        '        If DCDitems IsNot Nothing Then
        '            If DCDitems.Length > 0 Then
        '                Dim tempCheckBox As CheckBox
        '                Dim i As Integer
        '                For i = 0 To DCDitems.Length - 1
        '                    If DCDitems(i) IsNot Nothing Then
        '                        tempCheckBox = Me.FindControl("DCDCheckBox" + DCDitems(i).FileId.ToString)

        '                        If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
        '                            'If (DirectCast(tempCheckBox, CheckBox).Checked = True) Then
        '                            If Request(tempCheckBox.UniqueID) = "on" Then

        '                                s += DCDitems(i).FileId + " " + DCDitems(i).Description + " "

        '                            End If
        '                        End If
        '                    End If
        '                Next
        '            End If
        '        End If

        '        Page.Title = s

        '    Catch exc As Exception
        '        ProcessModuleLoadException(Me, exc)
        '    End Try
        'End Sub

        Public Class Sell
            Public ProductID As Integer
            Public URLToGo As String
            Public ShortName As String
            Public SmallImageFileName As String
            Public WebShortDescription As String
        End Class

        Public Class SellRow
            Public row() As Sell
        End Class

        Private Sub LoadUpSell()
            Try

                If ShowUpSell() Then
                    UpSellXslTemplate.Visible = True
                Else
                    UpSellXslTemplate.Visible = False
                End If

                If (ShowUpSell() = True) Then
                    If PM IsNot Nothing Then

                        If ProductDetails.UpSellProducts IsNot Nothing Then
                            If (ProductDetails.UpSellProducts.Count > 0) Then

                                Dim MaximunNumberOfProducts As Integer = ProductDetails.UpSellProducts.Count
                                Dim MaximunNumberOfProductsSetting As Integer = ProductDetails.UpSellProducts.Count

                                If Settings("US_MaximunNumberOfProductsSettingsKey") IsNot Nothing Then
                                    If Settings("US_MaximunNumberOfProductsSettingsKey").ToString <> String.Empty Then
                                        MaximunNumberOfProductsSetting = Convert.ToInt32(Settings("US_MaximunNumberOfProductsSettingsKey"))
                                    End If
                                End If
                                If MaximunNumberOfProductsSetting > 0 Then
                                    If MaximunNumberOfProductsSetting < MaximunNumberOfProducts Then
                                        MaximunNumberOfProducts = MaximunNumberOfProductsSetting
                                    End If
                                End If

                                Dim d(MaximunNumberOfProducts - 1) As Sell

                                Dim i As Integer
                                For i = 0 To MaximunNumberOfProducts - 1
                                    d(i) = New Sell

                                    d(i).ProductID = ProductDetails.UpSellProducts(i).ProductId

                                    d(i).URLToGo = String.Empty
                                    If Settings("US_ProductURLSettingsKey") IsNot Nothing AndAlso Settings("US_ProductURLSettingsKey").ToString <> String.Empty AndAlso Settings("US_ProductURLTypeSettingsKey").ToString <> "N" Then
                                        If Not Settings("US_ProductURLTypeSettingsKey").ToString Is Nothing AndAlso Settings("US_ProductURLTypeSettingsKey").ToString = "T" Then
                                            d(i).URLToGo = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("US_ProductURLSettingsKey"), Integer)))
                                            If d(i).URLToGo.IndexOf("?") > 0 Then
                                                d(i).URLToGo += "&"
                                            Else
                                                d(i).URLToGo += "?"
                                            End If
                                            d(i).URLToGo += "ProductId=" + ProductDetails.UpSellProducts(i).ProductId.ToString()
                                        End If
                                    Else
                                        d(i).URLToGo = String.Empty
                                    End If

                                    d(i).ShortName = ProductDetails.UpSellProducts(i).ShortName.ToString()

                                    'display optional image
                                    Dim tempSettings As Object
                                    tempSettings = Settings("US_DisplayProductImageSettingsKey")
                                    If Not tempSettings Is Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE") Then
                                        d(i).SmallImageFileName = ProductDetails.UpSellProducts(i).SmallImageFileName.ToString()
                                    End If

                                    d(i).WebShortDescription = TruncateDescription(ProductDetails.UpSellProducts(i).WebShortDescription.ToString, "US_TruncateDescriptionSettingsKey")
                                Next

                                'Session("UpSellData") = d

                                Dim RepeatDirection As System.Web.UI.WebControls.RepeatDirection = CType([Enum].Parse(GetType(RepeatDirection), PM.UpSell.RepeatDirection), RepeatDirection)
                                Dim RepeatColumns As Integer = PM.UpSell.NumberOfColumns

                                Dim rownr As Integer = d.Length / RepeatColumns
                                If (d.Length / RepeatColumns - rownr) > 0 Then
                                    rownr = rownr + 1
                                End If

                                Dim us(rownr - 1) As SellRow

                                Dim x As Integer
                                Dim y As Integer


                                For x = 0 To us.Length - 1
                                    us(x) = New SellRow
                                    Dim row(RepeatColumns) As Sell
                                    For y = 0 To RepeatColumns - 1
                                        row(y) = New Sell

                                        Dim index As Integer
                                        If (RepeatDirection = Web.UI.WebControls.RepeatDirection.Horizontal) Then
                                            index = x * RepeatColumns + y
                                        Else
                                            index = y * RepeatColumns + x
                                        End If

                                        If index < d.Length Then
                                            row(y) = d(index)
                                        End If
                                    Next
                                    us(x).row = row
                                Next

                                Dim templatefile As String = ""

                                Try
                                    templatefile = ModulePath + "Templates\" + Settings("US_LayoutTemplateSettingsKey").ToString()
                                Catch ex As Exception
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                                    'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
                                End Try

                                UpSellXslTemplate.XSLfile = Server.MapPath(templatefile)

                                'Session("UpSellItems") = us
                                UpSellXslTemplate.AddObject("", us)
                                UpSellXslTemplate.AddObject("ModuleId", ModuleId)

                                Dim ProductImageURL As String = ProductImagesFolder
                                UpSellXslTemplate.AddObject("ProductImageURL", ProductImageURL)

                                '3246-5774803
                                Dim BlankImageURL As String = GetBlankImageURL()
                                XSellXslTemplate.AddObject("BlankImageURL", BlankImageURL)
                                Dim DivideRBGImageURL As String = GetDivideRBGImageURL()
                                XSellXslTemplate.AddObject("DivideRBGImageURL", DivideRBGImageURL)
                                'end 3246-5774803

                                UpSellXslTemplate.Display()


                                Dim UpSellTitle As String = String.Empty

                                If ProductDetails IsNot Nothing AndAlso ProductDetails.ProductInfo IsNot Nothing AndAlso ProductDetails.ProductInfo.Item(0) IsNot Nothing Then
                                    UpSellTitle = ProductDetails.ProductInfo.Item(0).ProductClassCodeString
                                    UpSellTitle = CapitalizeFirstLetter(UpSellTitle)

                                    'Dim URLToGo As String = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("US_ProductClassSettingsKey"), Integer)))

                                    'UpSellTitle = "<a href='" + URLToGo + "'>" + UpSellTitle + "</a>"
                                End If

                                UpSellTitle = DotNetNuke.Services.Localization.Localization.GetString("UpSellTitle.Text", Me.LocalResourceFile).Replace("$product_title$", UpSellTitle)


                                Dim LabelBaseUpSellTitle As New WebControls.LabelBase
                                LabelBaseUpSellTitle.Text = UpSellTitle

                                Dim atempPlaceHolder As New PlaceHolder
                                atempPlaceHolder = Me.FindControl("UpSellTitlePlaceHolder" + ModuleId.ToString)
                                If (atempPlaceHolder IsNot Nothing) Then
                                    atempPlaceHolder.Controls.Add(LabelBaseUpSellTitle)
                                End If


                                For x = 0 To d.Length - 1
                                    If d(x).ProductID > 0 Then


                                        Dim aProductDetails As ProductDetails
                                        aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(d(x).ProductID, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True, , , , , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))



                                        Dim aPricingControl As New WebControls.PricingControl

                                        aPricingControl.ID = "uPricingControl" + ModuleId.ToString + "_" + d(x).ProductID.ToString
                                        aPricingControl.PortalID = PortalId
                                        'ANMC
                                        aPricingControl.PortalCurrency = PortalCurrency
                                        aPricingControl.AllPrices = aProductDetails.AllPrices
                                        aPricingControl.ListPrices = aProductDetails.ListPrices
                                        aPricingControl.MemberPrices = aProductDetails.MemberPrices
                                        aPricingControl.YourPrices = aProductDetails.CustomerPrice

                                        aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                                        aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                                        aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)

                                        If Settings("DisplayRateCodeSettingsKey_" + aProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                                            aPricingControl.ShowRateCode = True
                                        End If

                                        Dim tempPlaceHolder As New PlaceHolder

                                        tempPlaceHolder = Me.FindControl("UpSellPricePlaceHolder" + d(x).ProductID.ToString)
                                        If (tempPlaceHolder IsNot Nothing) Then
                                            tempPlaceHolder.Controls.Add(aPricingControl)
                                        End If

                                        Dim tempSettings As Object = Settings("US_DisplayAddToCartSettingsKey")
                                        Dim tempSettings2 As Object = Settings("US_DisplayAddToWishListSettingsKey")
                                        Dim tempSettings3 As Object = Settings("US_DisplayBuyForGroupSettingsKey")

                                        If (Not tempSettings Is Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE")) _
                                         Or (Not tempSettings2 Is Nothing AndAlso (tempSettings2.ToString.ToUpper = "TRUE")) _
                                         Or (Not tempSettings3 Is Nothing AndAlso (tempSettings3.ToString.ToUpper = "TRUE")) _
                                        Then

                                            If PM.Settings.ShowButtons = True Then
                                                Dim aAddToCartControl As New WebControls.AddToCartControl

                                                aAddToCartControl.Visible = True
                                                aAddToCartControl.ProductId = d(x).ProductID
                                                aAddToCartControl.ID = "UpSellAddToCartControl" + ModuleId.ToString + "_" + d(x).ProductID.ToString

                                                aAddToCartControl.Text = Localization.GetString("AddToCart.Text", LocalResourceFile)
                                                aAddToCartControl.WishListText = Localization.GetString("AddToWishList.Text", LocalResourceFile)
                                                aAddToCartControl.BuyForGroupText = Localization.GetString("BuyForGroup.Text", LocalResourceFile)

                                                aAddToCartControl.ButtonCss = "btna"

                                                If (Not tempSettings Is Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE")) Then
                                                    aAddToCartControl.VisibleAddToCart = True
                                                Else
                                                    aAddToCartControl.VisibleAddToCart = False
                                                End If
                                                If (Not tempSettings2 Is Nothing AndAlso (tempSettings2.ToString.ToUpper = "TRUE")) Then
                                                    aAddToCartControl.VisibleWishList = True
                                                Else
                                                    aAddToCartControl.VisibleWishList = False
                                                End If

                                                aAddToCartControl.VisibleBuyForGroup = False


                                                'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                                                'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
                                                'Dim lg As New Personify.WebUtility.LoginCustomer
                                                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                                                'Dim MasterCustomerId As String = lg.MasterCustomerId
                                                'Dim SubCustomerId As Integer = lg.SubCustomerId

                                                If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                                    If (Not tempSettings3 Is Nothing AndAlso (tempSettings3.ToString.ToUpper = "TRUE")) Then
                                                        aAddToCartControl.VisibleBuyForGroup = True
                                                    End If
                                                End If



                                                aAddToCartControl.ButtonMode = WebControls.AddToCartControl.EnumButtonMode.Button
                                                '3246-5774803
                                                aAddToCartControl.ImageURL = GetAddToCartImageURL() 'ModulePath & "images/btn_addtocart.gif"
                                                aAddToCartControl.WishListImageURL = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                                                aAddToCartControl.BuyForGroupImageURL = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                                                'end 3246-5774803
                                                If Settings("US_DefaultQuantitySettingsKey") IsNot Nothing Then
                                                    aAddToCartControl.Quantity = CType(Settings("US_DefaultQuantitySettingsKey"), Integer)
                                                Else
                                                    aAddToCartControl.Quantity = 1
                                                End If
                                                Select Case aProductDetails.Subsystem.ToUpper
                                                    Case "INV", "MISC", "SUB"
                                                        aAddToCartControl.VisibleQuantity = True
                                                    Case Else
                                                        aAddToCartControl.VisibleQuantity = False
                                                End Select

                                                tempPlaceHolder = Me.FindControl("UpSellAddToCartPlaceHolder" + d(x).ProductID.ToString)
                                                If (tempPlaceHolder IsNot Nothing) Then
                                                    tempPlaceHolder.Controls.Add(aAddToCartControl)
                                                End If
                                            End If
                                        End If
                                    End If

                                Next
                            End If
                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadXSell()

            Try
                If ShowXSell() Then
                    XSellXslTemplate.Visible = True

                Else
                    XSellXslTemplate.Visible = False
                End If

                If (ShowXSell() = True) Then
                    If PM IsNot Nothing Then

                        If ProductDetails.CrossSellProducts IsNot Nothing Then
                            If (ProductDetails.CrossSellProducts.Count > 0) Then


                                Dim MaximunNumberOfProducts As Integer = ProductDetails.CrossSellProducts.Count()
                                Dim MaximunNumberOfProductsSetting As Integer = ProductDetails.CrossSellProducts.Count

                                If Settings("CS_MaximunNumberOfProductsSettingsKey") IsNot Nothing Then
                                    If Settings("CS_MaximunNumberOfProductsSettingsKey").ToString <> String.Empty Then
                                        MaximunNumberOfProductsSetting = Convert.ToInt32(Settings("CS_MaximunNumberOfProductsSettingsKey"))
                                    End If
                                End If
                                If MaximunNumberOfProductsSetting > 0 Then
                                    If MaximunNumberOfProductsSetting < MaximunNumberOfProducts Then
                                        MaximunNumberOfProducts = MaximunNumberOfProductsSetting
                                    End If
                                End If

                                Dim d(MaximunNumberOfProducts - 1) As Sell

                                Dim i As Integer
                                For i = 0 To MaximunNumberOfProducts - 1
                                    d(i) = New Sell

                                    d(i).ProductID = ProductDetails.CrossSellProducts(i).ProductId

                                    d(i).URLToGo = String.Empty
                                    If Settings("CS_ProductURLSettingsKey") IsNot Nothing AndAlso Settings("CS_ProductURLSettingsKey").ToString <> String.Empty AndAlso Settings("US_ProductURLTypeSettingsKey").ToString <> "N" Then
                                        If Not Settings("CS_ProductURLTypeSettingsKey").ToString Is Nothing AndAlso Settings("CS_ProductURLTypeSettingsKey").ToString = "T" Then
                                            d(i).URLToGo = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("CS_ProductURLSettingsKey"), Integer)))
                                            If d(i).URLToGo.IndexOf("?") > 0 Then
                                                d(i).URLToGo += "&"
                                            Else
                                                d(i).URLToGo += "?"
                                            End If
                                            d(i).URLToGo += "ProductId=" + ProductDetails.CrossSellProducts(i).ProductId.ToString()
                                            'Else
                                            '	d(i).URLToGo = RemoveLastBackSlashFromURL(Settings("CS_ProductURLSettingsKey").ToString)
                                            '	If d(i).URLToGo.IndexOf("?") > 0 Then
                                            '		d(i).URLToGo += "&"
                                            '	Else
                                            '		d(i).URLToGo += "?"
                                            '	End If
                                        End If
                                    Else
                                        d(i).URLToGo = String.Empty
                                    End If

                                    d(i).ShortName = ProductDetails.CrossSellProducts(i).ShortName.ToString()

                                    'display optional image
                                    Dim tempSettings As Object
                                    tempSettings = Settings("CS_DisplayProductImageSettingsKey")
                                    If Not tempSettings Is Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE") Then
                                        d(i).SmallImageFileName = ProductDetails.CrossSellProducts(i).SmallImageFileName.ToString()
                                    End If

                                    d(i).WebShortDescription = TruncateDescription(ProductDetails.CrossSellProducts(i).WebShortDescription.ToString, "CS_TruncateDescriptionSettingsKey")
                                Next

                                'Session("XSellData") = d

                                Dim RepeatDirection As System.Web.UI.WebControls.RepeatDirection = CType([Enum].Parse(GetType(RepeatDirection), PM.CrossSell.RepeatDirection), RepeatDirection)
                                Dim RepeatColumns As Integer = PM.CrossSell.NumberOfColumns

                                Dim rownr As Integer = d.Length / RepeatColumns
                                If (d.Length / RepeatColumns - rownr) > 0 Then
                                    rownr = rownr + 1
                                End If

                                Dim us(rownr - 1) As SellRow

                                Dim x As Integer
                                Dim y As Integer


                                For x = 0 To us.Length - 1
                                    us(x) = New SellRow
                                    Dim row(RepeatColumns) As Sell
                                    For y = 0 To RepeatColumns - 1
                                        row(y) = New Sell

                                        Dim index As Integer
                                        If (RepeatDirection = Web.UI.WebControls.RepeatDirection.Horizontal) Then
                                            index = x * RepeatColumns + y
                                        Else
                                            index = y * RepeatColumns + x
                                        End If

                                        If index < d.Length Then
                                            row(y) = d(index)
                                        End If
                                    Next
                                    us(x).row = row
                                Next

                                Dim templatefile As String = ""
                                Try
                                    templatefile = ModulePath + "Templates\" + Settings("CS_LayoutTemplateSettingsKey").ToString()
                                Catch ex As Exception
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                                    'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
                                End Try


                                XSellXslTemplate.XSLfile = Server.MapPath(templatefile)
                                XSellXslTemplate.AddObject("", us)
                                XSellXslTemplate.AddObject("ModuleId", ModuleId)

                                Dim ProductImageURL As String = ProductImagesFolder
                                XSellXslTemplate.AddObject("ProductImageURL", ProductImageURL)

                                '3246-5774803
                                Dim BlankImageURL As String = GetBlankImageURL()
                                XSellXslTemplate.AddObject("BlankImageURL", BlankImageURL)
                                Dim DivideRBGImageURL As String = GetDivideRBGImageURL()
                                XSellXslTemplate.AddObject("DivideRBGImageURL", DivideRBGImageURL)
                                'end 3246-5774803

                                XSellXslTemplate.Display()

                                Dim XSellTitle As String = String.Empty

                                If ProductDetails IsNot Nothing AndAlso ProductDetails.ProductInfo IsNot Nothing AndAlso ProductDetails.ProductInfo.Item(0) IsNot Nothing Then
                                    XSellTitle = ProductDetails.ProductInfo.Item(0).ProductClassCodeString
                                    XSellTitle = CapitalizeFirstLetter(XSellTitle)

                                    Dim URLToGo As String = RemoveLastBackSlashFromURL(NavigateURL(CType(Settings("CS_ProductClassSettingsKey"), Integer)))

                                    If URLToGo.IndexOf("?") > 0 Then
                                        URLToGo += "&"
                                    Else
                                        URLToGo += "?"
                                    End If

                                    URLToGo += "ProdClass=" + XSellTitle.ToString()

                                    XSellTitle = "<a href='" + URLToGo + "'>" + XSellTitle + "</a>"
                                End If

                                XSellTitle = DotNetNuke.Services.Localization.Localization.GetString("XSellTitle.Text", Me.LocalResourceFile).Replace("$product_class$", XSellTitle)


                                Dim LabelBaseXSellTitle As New WebControls.LabelBase
                                LabelBaseXSellTitle.Text = XSellTitle

                                Dim atempPlaceHolder As New PlaceHolder
                                atempPlaceHolder = Me.FindControl("XSellTitlePlaceHolder" + ModuleId.ToString)
                                If (atempPlaceHolder IsNot Nothing) Then
                                    atempPlaceHolder.Controls.Add(LabelBaseXSellTitle)
                                End If

                                For x = 0 To d.Length - 1

                                    Dim aProductDetails As ProductDetails
                                    aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(d(x).ProductID, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True, , , , , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))

                                    Dim aPricingControl As New WebControls.PricingControl

                                    aPricingControl.ID = "xPricingControl" + ModuleId.ToString + "_" + d(x).ProductID.ToString
                                    aPricingControl.PortalID = PortalId
                                    'ANMC
                                    aPricingControl.PortalCurrency = PortalCurrency
                                    aPricingControl.AllPrices = aProductDetails.AllPrices
                                    aPricingControl.ListPrices = aProductDetails.ListPrices
                                    aPricingControl.MemberPrices = aProductDetails.MemberPrices
                                    aPricingControl.YourPrices = aProductDetails.CustomerPrice

                                    aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)

                                    If Settings("DisplayRateCodeSettingsKey_" + aProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                                        aPricingControl.ShowRateCode = True
                                    End If

                                    Dim tempPlaceHolder As New PlaceHolder

                                    tempPlaceHolder = Me.FindControl("XSellPricePlaceHolder" + d(x).ProductID.ToString)
                                    If (tempPlaceHolder IsNot Nothing) Then
                                        tempPlaceHolder.Controls.Add(aPricingControl)
                                    End If

                                    Dim tempSettings As Object = Settings("CS_DisplayAddToCartSettingsKey")
                                    Dim tempSettings2 As Object = Settings("CS_DisplayAddToWishListSettingsKey")
                                    Dim tempSettings3 As Object = Settings("CS_DisplayBuyForGroupSettingsKey")

                                    If (Not tempSettings Is Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE")) _
                                      Or (Not tempSettings2 Is Nothing AndAlso (tempSettings2.ToString.ToUpper = "TRUE")) _
                                      Or (Not tempSettings3 Is Nothing AndAlso (tempSettings3.ToString.ToUpper = "TRUE")) _
                                    Then

                                        If PM.Settings.ShowButtons = True Then


                                            Dim aAddToCartControl As New WebControls.AddToCartControl

                                            aAddToCartControl.Visible = True

                                            If (Not tempSettings Is Nothing AndAlso (tempSettings.ToString.ToUpper = "TRUE")) Then
                                                aAddToCartControl.VisibleAddToCart = True
                                            Else
                                                aAddToCartControl.VisibleAddToCart = False
                                            End If
                                            If (Not tempSettings2 Is Nothing AndAlso (tempSettings2.ToString.ToUpper = "TRUE")) Then
                                                aAddToCartControl.VisibleWishList = True
                                            Else
                                                aAddToCartControl.VisibleWishList = False
                                            End If
                                            aAddToCartControl.VisibleBuyForGroup = False

                                            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                                            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
                                            'Dim lg As New Personify.WebUtility.LoginCustomer
                                            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                                            'Dim MasterCustomerId As String = lg.MasterCustomerId
                                            'Dim SubCustomerId As Integer = lg.SubCustomerId

                                            If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                                If (Not tempSettings3 Is Nothing AndAlso (tempSettings3.ToString.ToUpper = "TRUE")) Then
                                                    aAddToCartControl.VisibleBuyForGroup = True
                                                End If
                                            End If



                                            aAddToCartControl.ProductId = d(x).ProductID

                                            aAddToCartControl.ID = "XSellAddToCartControl" + ModuleId.ToString + "_" + d(x).ProductID.ToString

                                            aAddToCartControl.Text = Localization.GetString("AddToCart.Text", LocalResourceFile)
                                            aAddToCartControl.WishListText = Localization.GetString("AddToWishList.Text", LocalResourceFile)
                                            aAddToCartControl.BuyForGroupText = Localization.GetString("BuyForGroup.Text", LocalResourceFile)

                                            aAddToCartControl.ButtonCss = "btna"

                                            aAddToCartControl.ButtonMode = WebControls.AddToCartControl.EnumButtonMode.Button
                                            '3246-5774803
                                            aAddToCartControl.ImageURL = GetAddToCartImageURL() 'ModulePath & "images/btn_addtocart.gif"
                                            aAddToCartControl.WishListImageURL = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                                            aAddToCartControl.BuyForGroupImageURL = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                                            'end 3246-5774803


                                            If Settings("CS_DefaultQuantitySettingsKey") IsNot Nothing Then
                                                aAddToCartControl.Quantity = CType(Settings("CS_DefaultQuantitySettingsKey"), Integer)
                                            Else
                                                aAddToCartControl.Quantity = 1
                                            End If
                                            Select Case aProductDetails.Subsystem.ToUpper
                                                Case "INV", "MISC", "SUB"
                                                    aAddToCartControl.VisibleQuantity = True
                                                Case Else
                                                    aAddToCartControl.VisibleQuantity = False
                                            End Select

                                            tempPlaceHolder = Me.FindControl("XSellAddToCartPlaceHolder" + d(x).ProductID.ToString)
                                            If (tempPlaceHolder IsNot Nothing) Then
                                                tempPlaceHolder.Controls.Add(aAddToCartControl)

                                            End If
                                        End If
                                    End If
                                Next
                            End If
                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' <summary>
        ''' determine if we should show CrossSell
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' 

        Private Function EditSetting_ShowXSell(ByVal Subsystem As String) As Boolean

            If Settings("XSellInclusionSettingsKey_" + Subsystem) IsNot Nothing Then
                Return True
            Else
                Return False
            End If


            Return False
        End Function
        Private Function EditSetting_ShowUpSell(ByVal Subsystem As String) As Boolean

            If Settings("UpSellInclusionSettingsKey_" + Subsystem) IsNot Nothing Then
                Return True
            Else
                Return False
            End If


            Return False
        End Function
        Private Function ShowXSell() As Boolean
            Try
                If Settings("XSellInclusionSettingsKey_" + ProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                    If ProductDetails IsNot Nothing AndAlso ProductDetails.ProductInfo IsNot Nothing AndAlso ProductDetails.ProductInfo.Count > 0 AndAlso ProductDetails.CrossSellProducts IsNot Nothing Then
                        Return True
                    Else
                        Return False
                    End If
                End If
                Return False
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return False
        End Function

        ''' <summary>
        ''' determine if we shoul show UpSell
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' 
        Private Function GetSubsystemsWithSettingEnabled(ByVal Key As String) As String

            Dim AppSubs As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            Dim strsubsystem As String = ""

            AppSubs = TIMSS.API.CachedApplicationData.ApplicationDataCache.SubSystems

            For i As Integer = 0 To AppSubs.Count - 1
                If AppSubs(i).ProductFlag = True AndAlso AppSubs(i).ActiveFlag = True Then
                    If Settings(String.Concat(Key, "_", AppSubs(i).Subsystem)) IsNot Nothing Then
                        If strsubsystem.Length = 0 Then
                            'START 3246-7580178 Cross Sell/Up Sell - check UpSellTemplate.xsl fixed as well
                            strsubsystem = AppSubs(i).Subsystem
                        Else
                            strsubsystem = strsubsystem + "," + AppSubs(i).Subsystem
                        End If


                    End If
                End If

            Next

            Return strsubsystem
        End Function
        Private Function ShowUpSell() As Boolean
            Try


                If Settings("UpSellInclusionSettingsKey_" + ProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                    If ProductDetails IsNot Nothing AndAlso ProductDetails.ProductInfo IsNot Nothing AndAlso ProductDetails.ProductInfo.Count > 0 AndAlso ProductDetails.UpSellProducts IsNot Nothing Then
                        Return True
                    Else
                        Return False
                    End If

                Else
                    Return False
                End If


                'If ProductDetails IsNot Nothing AndAlso ProductDetails.ProductInfo IsNot Nothing AndAlso ProductDetails.ProductInfo.Count > 0 AndAlso ProductDetails.UpSellProducts IsNot Nothing Then
                '    If Settings("UpSellInclusionSettingsKey_" + ProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                '        Return True
                '    Else
                '        Return False
                '    End If
                'End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return False
        End Function


        ''' <summary>
        ''' Capitalize First Letter
        ''' </summary>
        ''' <param name="inString"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function CapitalizeFirstLetter(ByVal inString As String) As String
            Dim tmpString As String = String.Empty
            Try

                If inString = String.Empty Then
                    Return String.Empty
                End If
                Try
                    tmpString = inString.Substring(0, 1)
                    inString = inString.Substring(1, inString.Length - 1)
                    Return tmpString.ToUpper + inString.ToLower
                Catch ex As Exception

                End Try

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

            Return tmpString
        End Function

        ''' <summary>
        ''' Remove Last Back Slash From URL
        ''' </summary>
        ''' <param name="URL"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function RemoveLastBackSlashFromURL(ByVal URL As String) As String
            Try
                If URL = String.Empty Then
                    Return URL
                Else
                    If URL.Chars(URL.Length - 1) = "/" Then
                        Return URL.Substring(0, URL.Length - 1)
                    Else
                        Return URL
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return String.Empty
        End Function

        ''' <summary>
        ''' Truncate Long Description
        ''' </summary>
        ''' <param name="LongDescription"></param>
        ''' <param name="TruncateKey"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function TruncateDescription(ByVal LongDescription As String, ByVal TruncateKey As String) As String
            Dim tempSettings As Object
            Dim newLength As Integer
            'CODEREVIEW - do not strip html if the length is less than edit setting. REevaluate the need for truncation
            Try
                If LongDescription Is Nothing OrElse LongDescription = String.Empty Then
                    Return String.Empty
                End If
                tempSettings = Settings(TruncateKey)
                If Not tempSettings Is Nothing AndAlso CType(tempSettings.ToString, Integer) > 0 Then
                    LongDescription = StripHTML(LongDescription)
                    newLength = CType(tempSettings.ToString, Integer)
                    If newLength >= LongDescription.Length Then
                        Return LongDescription
                    Else
                        Return LongDescription.Substring(0, newLength) + DotNetNuke.Services.Localization.Localization.GetString("TruncateDescriptionSuffix.Text", Me.LocalResourceFile)
                    End If
                Else
                    Return LongDescription
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

            Return String.Empty
        End Function


        ''' <summary>
        ''' Strip HTML (replace all HTML tag matches with the empty string)
        ''' </summary>
        ''' <param name="objHTML"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Function StripHTML(ByVal objHTML As String) As String
            Try
                'CODEREVIEW - think of optimizing this function
                Dim strOutput As String
                If Not IsDBNull(objHTML) Then
                    strOutput = objHTML
                    ' create regular expression object
                    Dim objRegExp1 As Regex = New Regex("<(.|\n)+?>", RegexOptions.IgnoreCase)
                    ' replace all HTML tag matches with the empty string
                    strOutput = objRegExp1.Replace(strOutput, "")
                    ' create regular expression object
                    Dim objRegExp2 As Regex = New Regex("&lt;(.|\n)+?&gt;", RegexOptions.IgnoreCase)
                    ' replace all HTML tag matches with the empty string
                    strOutput = objRegExp2.Replace(strOutput, "")
                    ' remove breaks
                    strOutput = Replace(strOutput, ControlChars.Lf, "")
                    strOutput = Replace(strOutput, Chr(13), "")
                    Return strOutput
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return String.Empty
        End Function

        ''' <summary>
        ''' read ProductID from query string 
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub ReadProductId()

            Try
                If UpdateOrder = True Then
                    ProductID = CType(Request.QueryString("ProductId"), Integer)

                Else

                    If PM.Settings.ProductId > 0 Then
                        ProductID = PM.Settings.ProductId
                    Else
                        Dim ProductIdInfo As DictionaryEntry

                        Dim arrProductIdParameters() As String
                        arrProductIdParameters = Nothing
                        If PM.Settings.ProductIdParameters IsNot Nothing Then
                            arrProductIdParameters = CType(PM.Settings.ProductIdParameters, String).Split(New [Char]() {","c, ";"c})
                        End If

                        Dim coll As NameValueCollection
                        'Dim de As DictionaryEntry
                        coll = Page.Request.QueryString

                        If coll.Item("ProductId") IsNot Nothing Then
                            Try
                                ProductID = CType(coll.Item("ProductId"), Integer)
                                ProductIdInfo = New DictionaryEntry("ProductId", coll.Item("ProductId"))
                                Page.Session("ProductIdInfo") = ProductIdInfo
                            Catch ex As Exception

                            End Try
                        Else

                            If arrProductIdParameters IsNot Nothing Then
                                For i As Integer = 0 To arrProductIdParameters.Length - 1
                                    If coll.Item(arrProductIdParameters(i)) IsNot Nothing Then
                                        Try
                                            ProductID = CType(coll.Item(arrProductIdParameters(i)), Integer)
                                            ProductIdInfo = New DictionaryEntry(arrProductIdParameters(i), coll.Item(arrProductIdParameters(i)))
                                            Page.Session("ProductIdInfo") = ProductIdInfo
                                        Catch ex As Exception

                                        End Try
                                    End If
                                Next
                            End If
                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' <summary>
        ''' return ProductID
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetProductIDFrom() As Integer
            Try
                Return ProductID
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' <summary>
        ''' split string into arrays of integer
        ''' </summary>
        ''' <param name="ListOfIntegers"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetArrayOfIntegersFromString(ByVal ListOfIntegers As String) As Integer()
            Try
                Dim delimStr As String = ",;"
                Dim delimiter As Char() = delimStr.ToCharArray()
                Dim tmpArray() As String = ListOfIntegers.Split(delimiter)
                Dim Integers() As Integer
                ReDim Integers(tmpArray.Length - 1)


                Dim i As Integer

                For i = 0 To tmpArray.Length - 1
                    Integers(i) = CType(tmpArray(i), Integer)
                Next
                Return Integers

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

            Return Nothing

        End Function

        ''' <summary>
        ''' generic add to cart function
        ''' </summary>
        ''' <param name="ProductID"></param>
        ''' <param name="SubProductId"></param>
        ''' <param name="ProductDetails"></param>
        ''' <param name="Quantity"></param>
        ''' <param name="Price"></param>
        ''' <remarks></remarks>
        Private Function AddToCart( _
    ByVal MasterCustomerId As String, _
  ByVal SubCustomerId As Integer, _
   ByVal ProductID As Integer, _
  ByVal SubProductId As Integer, _
  ByVal ProductDetails _
  As ProductDetails, _
  ByVal Quantity As Integer, _
  ByVal RateCode As String, _
  ByVal RateStructure As String, _
  ByVal Price As Decimal, _
  ByVal IsWishList As Boolean, _
  ByVal HasValidScheduledPrice As Boolean, _
  Optional ByVal RelatedCartItemId As Integer = -1, _
  Optional ByVal isDirectPriceUpdate As Boolean = False) As Integer
            'ByVal RateStructure As String, _			'ByVal RateCode As String _
            Try
                Dim CartItemId As Integer
                Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                Dim oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
                With oCartInfo
                    .Subsystem = ProductDetails.ProductInfo(0).Subsystem
                    .ProductType = ProductDetails.ProductInfo(0).ProductTypeCodeString
                    .RateStructure = RateStructure
                    .RateCode = RateCode
                    .MasterCustomerId = MasterCustomerId 'ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                    .SubCustomerId = SubCustomerId '0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
                    .LongName = ProductDetails.ProductInfo(0).LongName
                    .ShortName = ProductDetails.ProductInfo(0).ShortName
                    'Fixed Ticket #3246-8157039 
                    .HasValidScheduledPrice = HasValidScheduledPrice
                    'AN FIX
                    .MaximumTickets = ProductDetails.ProductInfo(0).MaximumTickets
                    .Price = Price
                    .Quantity = Quantity
                    .ProductId = ProductID
                    .SubProductId = SubProductId 'not 0
                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .MaxBadges = 0
                    .IsWishList = IsWishList
                    .IsDirectPriceUpdate = isDirectPriceUpdate

                    If ProductDetails.Components.Count > 0 Then
                        .ComponentExists = True
                    Else
                        .ComponentExists = False
                    End If

                    If RelatedCartItemId <> -1 Then
                        'Set here
                        .RelatedCartItemId = RelatedCartItemId
                    End If

                    'AN CUNA FIX + 3246-7611874  
                    .MaxBadges = GetMaxBadges(ProductDetails, .RelatedCartItemId, .RateStructure, .RateCode)


                    


                End With
                CartItemId = oCartController.AddToCart(oCartInfo)
                '3246-7459082  - First Badge Info Should Default1
                If oCartInfo.MaxBadges > 0 AndAlso Me.IsPersonifyWebUserLoggedIn Then
                    Dim odtDefaultBAdge As DefaultBadgeInfo = GetDefaultBadgeInformation()
                    If odtDefaultBAdge IsNot Nothing Then
                        oCartController.AddUpdateBadge(CartItemId, 1, "SELF", odtDefaultBAdge.FirstName, odtDefaultBAdge.LabelName, odtDefaultBAdge.CompanyName, odtDefaultBAdge.City, odtDefaultBAdge.State, odtDefaultBAdge.PostalCode)
                    End If

                End If


                'Add to Shopping Cart Component
                Dim oComponentCartInfo As ShoppingCartManager.Business.ShoppingCartComponentInfo
                If ProductDetails.Components.Count > 0 Then
                    For i As Integer = 0 To ProductDetails.Components.Count - 1
                        oComponentCartInfo = New ShoppingCartManager.Business.ShoppingCartComponentInfo

                        With oComponentCartInfo
                            .CartItemId = CartItemId
                            .MasterCustomerId = MasterCustomerId
                            .SubCustomerId = SubCustomerId
                            .ProductId = ProductDetails.ProductId
                            .ComponentProductId = ProductDetails.Components(i).ProductId
                            .LongName = ProductDetails.Components(i).LongName
                            .ShortName = ProductDetails.Components(i).ShortName
                            .IsWishList = IsWishList
                            .ModuleId = ModuleId
                            .PortalId = PortalId
                            .AddDate = Date.Now()
                            .ModDate = Date.Now()
                        End With

                        oCartController.AddShoppingCartComponents(oComponentCartInfo)
                    Next
                End If

                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If

                Return (CartItemId)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function
        '3246-7459082  - First Badge Info Should Default1
        Private Class DefaultBadgeInfo

            Public FirstName As String
            Public LastName As String
            Public LabelName As String
            Public CompanyName As String
            Public City As String
            Public State As String
            Public PostalCode As String

        End Class
        Private Function GetDefaultBadgeInformation() As DefaultBadgeInfo

            Dim RetDefaultBadgeInfo As DefaultBadgeInfo

            ' Dim abc As TIMSS.API.CustomerInfo.ICustomerPrimaryInfoViewList

            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerPrimaryInfoViewList")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty

            oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = MasterCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = SubCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("FirstName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("LastName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("LabelName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("CompanyName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("City")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("State")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)


            oParm = New TIMSS.API.Core.SearchProperty("PostalCode")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            searchObj.Search()

            If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
                RetDefaultBadgeInfo = New DefaultBadgeInfo
                With RetDefaultBadgeInfo


                    .FirstName = IIf(searchObj.Results.Table.Rows(0)("FirstName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("FirstName"))

                    .LastName = IIf(searchObj.Results.Table.Rows(0)("LastName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("LastName"))
                    .LabelName = IIf(searchObj.Results.Table.Rows(0)("LabelName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("LabelName"))
                    .CompanyName = IIf(searchObj.Results.Table.Rows(0)("CompanyName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("CompanyName"))
                    .City = IIf(searchObj.Results.Table.Rows(0)("City") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("City"))
                    .State = IIf(searchObj.Results.Table.Rows(0)("State") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("State"))
                    .PostalCode = IIf(searchObj.Results.Table.Rows(0)("PostalCode") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("PostalCode"))
                End With

                Return RetDefaultBadgeInfo
            Else
                Return Nothing
            End If



        End Function

        'AN CUNA FIX
        Private Function GetMaxBadges(ByVal pProductDetails As ProductDetails, ByVal pRelatedCartItemId As Integer, ByVal pRateStructure As String, ByVal pRateCode As String) As Integer

            Dim intMaxBadges As Integer = 0
            Dim bRateFound As Boolean = False
            If pRelatedCartItemId <> 0 Then
                intMaxBadges = 0
            Else

                'the badge information should come from teh customer price. 3246-7611874  
                If pProductDetails.CustomerPrice IsNot Nothing AndAlso pProductDetails.CustomerPrice.Count > 0 Then
                    For i As Integer = 0 To pProductDetails.CustomerPrice.Count - 1
                        If pProductDetails.CustomerPrice(i).RateStructure = pRateStructure And pProductDetails.CustomerPrice(i).RateCode = pRateCode Then
                            intMaxBadges = pProductDetails.CustomerPrice(i).MaxBadges
                            bRateFound = True
                        End If
                    Next
                End If


                'if the user is not logged in, then go for the list price.
                If Not bRateFound AndAlso pProductDetails.ListPrices IsNot Nothing AndAlso pProductDetails.ListPrices.Count > 0 Then
                    For i As Integer = 0 To pProductDetails.ListPrices.Count - 1
                        If pProductDetails.ListPrices(i).RateStructure = pRateStructure And pProductDetails.ListPrices(i).RateCode = pRateCode Then
                            intMaxBadges = pProductDetails.ListPrices(i).MaxBadges
                            bRateFound = True
                        End If
                    Next

                End If

                If Not bRateFound AndAlso pProductDetails.MemberPrices IsNot Nothing AndAlso pProductDetails.MemberPrices.Count > 0 Then

                    For i As Integer = 0 To pProductDetails.MemberPrices.Count - 1
                        If pProductDetails.MemberPrices(i).RateStructure = pRateStructure And pProductDetails.MemberPrices(i).RateCode = pRateCode Then
                            intMaxBadges = pProductDetails.MemberPrices(i).MaxBadges
                            bRateFound = True
                        End If
                    Next
                End If

            End If


            Return intMaxBadges

        End Function

        ''' <summary>
        ''' main AddToCartControl onclick
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub AddToCommonControl_ButtonClick( _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
         ByVal tempAddToCartControl As WebControls.AddToCartControl, _
        ByVal e As System.EventArgs, _
        ByVal isWishList As Boolean _
        )
            Try
                Dim aproductID As Integer = 0
                Try
                    aproductID = CType(ProductDetails.ProductInfo(0).ProductId, Integer)
                Catch ex As Exception
                    aproductID = ProductID
                End Try


                Dim aPrice As Decimal
                Dim isDirectPriceUpdate As Boolean = False
                If ProductDetails.Subsystem.ToUpper = "FND" Then
                    Dim FNDPrice As String = GetFNDPrice()
                    If FNDPrice IsNot Nothing AndAlso FNDPrice.ToUpper = "-9999" Then
                        'error occur - number is invalid
                        DisplayCustomPriceError()
                    ElseIf FNDPrice Is Nothing Then
                        'use default price
                        aPrice = Convert.ToDecimal(Request("ProductPricingControl" + ModuleId.ToString + "_price"))
                    Else
                        'use input price
                        aPrice = CType(Me.GetFNDPrice, Decimal)
                        isDirectPriceUpdate = True
                    End If
                Else
                    aPrice = Convert.ToDecimal(Request("ProductPricingControl" + ModuleId.ToString + "_price"))
                End If

                Dim aRateCode As String = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("ProductPricingControl" + ModuleId.ToString + "_rs"))
                'Fixed Ticket #3246-8157039
                Dim HasValidScheduledPrice As Boolean
                If Request("ProductPricingControl" + ModuleId.ToString + "_hasValidScheduledPrice") IsNot Nothing Then
                    HasValidScheduledPrice = Convert.ToBoolean(Request("ProductPricingControl" + ModuleId.ToString + "_hasValidScheduledPrice"))
                End If

                Dim q As Integer = Convert.ToInt32(Request(tempAddToCartControl.txtQuantity.UniqueID))
                '3246-7465871
                AddToCart( _
                  MasterCustomerId, SubCustomerId, _
                  aproductID, _
                0, _
                ProductDetails, _
                q, _
                aRateCode, _
                aRateStructure, _
                aPrice, isWishList, HasValidScheduledPrice, -1, isDirectPriceUpdate)

                If isWishList = False Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub AddToCartControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            AddToCommonControl_ButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, e, False)
        End Sub

        Private Sub AddToWishListControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            AddToCommonControl_ButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, e, True)
        End Sub

        Private Sub BuyforGroupControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
            Dim guid As String = Convert.ToString(AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId))
            If guid Is Nothing Then
                guid = System.Guid.NewGuid().ToString("N").ToUpper()
                If guid.Length > 20 Then
                    guid = guid.Substring(1, 20)
                End If
                AffiliateManagementSessionHelper.SetGroupPurchaseInfo(PortalId, guid)
            End If

            AddToCommonControl_ButtonClick(guid, 0, tempAddToCartControl, e, False)

            Dim intTabId As Integer = AffiliateManagementSessionHelper.GetCurrentSegmentGroupPurchaseActionURL(0)
            If intTabId = 0 Then
                Response.Redirect(NavigateURL(CType(Settings("PD_BUYFORGROUPURLSettingsKey"), Integer)))
            Else
                Response.Redirect(NavigateURL(intTabId))
            End If


        End Sub
        'Private Sub AddToCartControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
        '	AddToCommonControl_ButtonClick(tempAddToCartControl, e, False)
        'End Sub

        'Private Sub AddToWishListControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
        '	AddToCommonControl_ButtonClick(tempAddToCartControl, e, True)
        'End Sub

        ''' <summary>
        ''' UpSell products add to cart
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub UpSell_ButtonClick( _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
         ByVal tempAddToCartControl As WebControls.AddToCartControl, _
         ByVal isWishList As Boolean)

            Try



                Dim tempPricingControl As WebControls.PricingControl

                tempPricingControl = CType(Me.FindControl("uPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString), WebControls.PricingControl)

                Dim aProductDetails As ProductDetails
                aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(tempAddToCartControl.ProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True, , , , , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))

                Dim aPrice As Decimal = Convert.ToDecimal(Request("uPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_price"))
                Dim aRateCode As String = Convert.ToString(Request("uPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("uPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_rs"))
                'Fixed Ticket #3246-8157039
                Dim HasValidScheduledPrice As Boolean
                If Request("uPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_hasValidScheduledPrice") IsNot Nothing Then
                    HasValidScheduledPrice = Convert.ToBoolean(Request("uPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_hasValidScheduledPrice"))
                End If

                Dim q As Integer = Convert.ToInt32(Request(tempAddToCartControl.txtQuantity.UniqueID))

                ' add upsell product
                AddToCart(MasterCustomerId, SubCustomerId, CType(tempAddToCartControl.ProductId, Integer), 0, aProductDetails, q, aRateStructure, aRateCode, aPrice, isWishList, HasValidScheduledPrice)


                If isWishList = False Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub UpSellAddToCartControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl)
            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            UpSell_ButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, False)
        End Sub

        Private Sub UpSellAddToWishListControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl)
            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            UpSell_ButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, True)
        End Sub

        Private Sub UpSellBuyforGroupControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl)
            Dim guid As String = Convert.ToString(AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId))
            If guid Is Nothing Then
                guid = System.Guid.NewGuid().ToString("N").ToUpper()
                If guid.Length > 20 Then
                    guid = guid.Substring(1, 20)
                End If
                AffiliateManagementSessionHelper.SetGroupPurchaseInfo(PortalId, guid)
            End If
            UpSell_ButtonClick(guid, 0, tempAddToCartControl, False)

            Dim intTabId As Integer = AffiliateManagementSessionHelper.GetCurrentSegmentGroupPurchaseActionURL(0)
            If intTabId = 0 Then
                Response.Redirect(NavigateURL(CType(Settings("PD_BUYFORGROUPURLSettingsKey"), Integer)))
            Else
                Response.Redirect(NavigateURL(intTabId))
            End If


        End Sub

        Private Function CheckIfPostBackByButton(ByVal strControlName As String, ByVal strWitch As String) As String
            Dim bReturn As String = ""
            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(strControlName) > 0 Then
                    If Key.IndexOf(strWitch) > 0 Then
                        bReturn = Key
                        Exit For
                    End If
                End If
            Next
            Return bReturn
        End Function

        Private Sub XSellButtonClick( _
          ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
         ByVal tempAddToCartControl As WebControls.AddToCartControl, _
         ByVal isWishList As Boolean)

            Try

                Dim tempPricingControl As WebControls.PricingControl

                tempPricingControl = CType(Me.FindControl("xPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString), WebControls.PricingControl)

                Dim aProductDetails As ProductDetails
                aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(tempAddToCartControl.ProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True, , , , , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))

                Dim aPrice As Decimal = Convert.ToDecimal(Request("xPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_price"))
                Dim aRateCode As String = Convert.ToString(Request("xPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("xPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_rs"))
                'Fixed Ticket #3246-8157039
                Dim HasValidScheduledPrice As Boolean
                If Request("xPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_hasValidScheduledPrice") IsNot Nothing Then
                    HasValidScheduledPrice = Convert.ToBoolean(Request("xPricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_hasValidScheduledPrice"))
                End If
                Dim q As Integer = Convert.ToInt32(Request(tempAddToCartControl.txtQuantity.UniqueID))

                'add xsell product
                AddToCart(MasterCustomerId, SubCustomerId, CType(tempAddToCartControl.ProductId, Integer), 0, aProductDetails, q, aRateStructure, aRateCode, aPrice, isWishList, HasValidScheduledPrice)

                If isWishList = False Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If



            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' <summary>
        ''' UpSell products add to cart
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub XSellAddToCartControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl)
            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            XSellButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, False)
        End Sub

        Private Sub XSellAddToWishListControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl)
            'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'Dim MasterCustomerId As String = lg.MasterCustomerId
            'Dim SubCustomerId As Integer = lg.SubCustomerId

            XSellButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, True)
        End Sub

        Private Sub XSellBuyForGroupControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl)
            Dim guid As String = Convert.ToString(AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId))
            If guid Is Nothing Then
                guid = System.Guid.NewGuid().ToString("N").ToUpper()
                If guid.Length > 20 Then
                    guid = guid.Substring(1, 20)
                End If
                AffiliateManagementSessionHelper.SetGroupPurchaseInfo(PortalId, guid)
            End If
            XSellButtonClick(guid, 0, tempAddToCartControl, False)

            Dim intTabId As Integer = AffiliateManagementSessionHelper.GetCurrentSegmentGroupPurchaseActionURL(0)
            If intTabId = 0 Then
                Response.Redirect(NavigateURL(CType(Settings("PD_BUYFORGROUPURLSettingsKey"), Integer)))
            Else
                Response.Redirect(NavigateURL(intTabId))
            End If

        End Sub

        Private Sub ShowNoProduct()
            Try
                'TCMSAddToCartControl1.Visible = False
                'LabelProductNotFound.EnableViewState = False
                'LabelProductNotFound.Visible = True
                'LabelProductNotFound.Text = 
                Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("ProductNotFound.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                'MessageControl.Clear()
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' <summary>
        ''' ???
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetChosenPrice() As WebPrice
            Dim tmpSelectPriceLabel As String = Services.Localization.Localization.GetString("SelectedPriceLabel")
            Dim tmpValues(2) As String

            Try
                tmpSelectPriceLabel = Services.Localization.Localization.GetString("SelectedPriceLabel")

                If Me.Page.Request.Form.Item("PriceType_List Price:") <> tmpSelectPriceLabel Then
                    tmpValues = Me.Page.Request.Form.Item("PriceType_List Price:").Split(","c)
                    Return GetWebPriceFromRatecodePrice(tmpValues(1), CType(tmpValues(2), Decimal), ProductDetails.ListPrices)
                ElseIf Me.Page.Request.Form.Item("PriceType_Member Price:") <> tmpSelectPriceLabel Then
                    tmpValues = Me.Page.Request.Form.Item("PriceType_Member Price:").Split(","c)
                    Return GetWebPriceFromRatecodePrice(tmpValues(1), CType(tmpValues(2), Decimal), ProductDetails.MemberPrices)
                ElseIf Me.Page.Request.Form.Item("PriceType_Your Price:") <> tmpSelectPriceLabel Then
                    tmpValues = Me.Page.Request.Form.Item("PriceType_Your Price:").Split(","c)
                    Return GetWebPriceFromRatecodePrice(tmpValues(1), CType(tmpValues(2), Decimal), ProductDetails.MemberPrices)
                Else
                    Return Nothing
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

            Return Nothing
        End Function


        ''' <summary>
        ''' get the right price based on Rarecode
        ''' </summary>
        ''' <param name="RateCode"></param>
        ''' <param name="Price"></param>
        ''' <param name="Prices"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetWebPriceFromRatecodePrice(ByVal RateCode As String, ByVal Price As Decimal, ByVal Prices As ApplicationManager.PersonifyDataObjects.WebPrices) As WebPrice
            Dim tmpPrice As WebPrice
            Try
                For Each tmpPrice In Prices
                    If tmpPrice.Price = Price AndAlso tmpPrice.RateCode = RateCode Then
                        Return tmpPrice
                    End If
                Next
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

            Return Nothing
        End Function

        ''' <summary>
        ''' return ProductDetails.ListPrices(0)
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetListPrice() As WebPrice
            Try
                If ProductDetails IsNot Nothing AndAlso ProductDetails.ListPrices IsNot Nothing Then
                    Return ProductDetails.ListPrices(0)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return Nothing
        End Function

        ''' <summary>
        ''' return ProductDetails.MemberPrices(0)
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetYourPrice() As WebPrice
            Try
                If ProductDetails IsNot Nothing AndAlso ProductDetails.MemberPrices IsNot Nothing Then
                    Return ProductDetails.MemberPrices(0)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return Nothing
        End Function

#End Region


#Region " Event Handlers "

        Private Function DoesMeetingAlreadyExistInCart(ByVal pProductId As Long) As Long

            Dim scList As ArrayList
            Dim retCartItemId As Long = 0

            Dim oManager As New ShoppingCartManager.Business.ShoppingCartController

            scList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False, False)

            'Form the subproducts list from Cart
            For i As Integer = 0 To scList.Count - 1
                If CType(scList(i), ShoppingCartManager.Business.ShoppingCartInfo).Subsystem = "MTG" And CType(scList(i), ShoppingCartManager.Business.ShoppingCartInfo).ProductId = pProductId Then
                    retCartItemId = CType(scList(i), ShoppingCartManager.Business.ShoppingCartInfo).CartItemId
                    Exit For
                End If
            Next

            Return retCartItemId

        End Function

        Private Function EditBadges_SetURL(ByVal PID As Long) As String
            Return String.Concat("~/Default.aspx?tabid=", PM.Meeting.BadgesURL, "&ProductId=", PID.ToString)
        End Function

        Private Function CheckIfUserRegisteredForMeeting(ByVal MCID As String, ByVal SCID As Integer, ByVal PID As Long) As String


            'Dim ood As TIMSS.API.OrderInfo.IOrderDetail


            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetails")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty

            oParm = New TIMSS.API.Core.SearchProperty("ShipMasterCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = MCID
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("ShipSubCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = SCID
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("ProductId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = PID
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("OrderNumber")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("LineStatusCode")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Operator = Enumerations.QueryOperatorEnum.IsIn
            oParm.Value = "A,W"
            searchObj.Parameters.Add(oParm)

            searchObj.Search()

            If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
                Return searchObj.Results.Table.Rows(0).Item("OrderNumber")
            Else
                Return ""
            End If

        End Function


        Private Function MeetingDetail_GetURL(ByVal PID As Long) As String
            Return NavigateURL(TabId, "", String.Concat("&ProductId=", PID, "&Mode=", "NewReg"))
        End Function
        Private Function MeetingDetail_BackURL(ByVal PID As Long) As String
            Return NavigateURL(TabId, "", String.Concat("&ProductId=", PID))
        End Function
        Private Function CheckIfModeIsNEwReg() As Boolean
            If Request.QueryString("Mode") IsNot Nothing AndAlso Request.QueryString("Mode").Length > 0 AndAlso Request.QueryString("Mode") = "NewReg" Then
                Return True
            End If

            Return False
        End Function




        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                'Fixed Ticket #3246-8277698
                If IsPostBack Then
                    GetRefreshState()
                End If

                RegisterJSScripts("js\hintbox.js", "HintBox")
                RegisterJSScripts("js\search.js", "SearchBox")


                If Request.QueryString("OrderNumber") IsNot Nothing Then
                    UpdateOrder = True
                    OrderNumber = CType(Request.QueryString("OrderNumber"), String)
                Else
                    UpdateOrder = False
                End If



                'where to go back
                If Me.Request IsNot Nothing AndAlso Me.Request.UrlReferrer IsNot Nothing AndAlso Me.Request.UrlReferrer.OriginalString IsNot Nothing Then
                    If Not IsPostBack Then
                        HyperLinkBack.Visible = True
                        HyperLinkBack.Text = Services.Localization.Localization.GetString("HyperLinkBack.Text", Me.LocalResourceFile)
                        HyperLinkBack.NavigateUrl = Me.Request.UrlReferrer.OriginalString
                    End If
                Else
                    HyperLinkBack.Visible = False
                End If

                LoadPM() 'fill ProductDetailModel object

                ReadProductId() 'read ProductID from query string 

                'get all ProductDetails
                If GetProductIDFrom() > 0 Then
                    ProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(GetProductIDFrom, True, True, True, True, False, PM.GetALLSubsystemPriceLayout, Me.IsPersonifyWebUserLoggedIn, MasterCustomerId, SubCustomerId, True, True, True, True, True, , GetSubsystemsWithSettingEnabled("XSellInclusionSettingsKey"), GetSubsystemsWithSettingEnabled("UpSellInclusionSettingsKey"))
                End If


                'After getting the product information, check if the user has already registered for the meeting. If Update Order is True, order number is already in the URL. This functionlaity should be disabled with affiliate management.
                If Not (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) OrElse PM.Settings.ShowBuyForGroup = False Then
                    If UpdateOrder = False AndAlso IsPersonifyWebUserLoggedIn AndAlso ProductDetails.Subsystem = "MTG" AndAlso Not CheckIfModeIsNEwReg() Then
                        Dim ordno As String
                        ordno = CheckIfUserRegisteredForMeeting(MasterCustomerId, SubCustomerId, ProductID)
                        If ordno.Length > 0 Then
                            Dim returnString As String = NavigateURL(TabId, "", String.Concat("&OrderNumber=", ordno, "&ProductId=", ProductID))
                            Response.Redirect(returnString, True)
                        End If
                    End If
                End If
                If (ProductDetails Is Nothing OrElse ProductDetails.ProductInfo Is Nothing OrElse ProductDetails.ProductInfo.Count = 0) Then
                    If ProductID > 0 Then
                        ShowNoProduct() 'if nothing to show
                        Exit Sub
                    Else
                        Dim role As String
                        role = Me.GetUserRole(UserInfo)
                        If role <> "none" AndAlso role <> "host" AndAlso role <> "personifyadmin" AndAlso role <> "admin" Then
                            Response.Redirect(NavigateURL(PortalSettings.HomeTabId), True)
                        End If
                    End If
                End If
                'Add/Remove Sessions functionality  . AN Update Meeting Fix

                'If Request.QueryString("CartItemId") IsNot Nothing Then
                '    AddRemoveSessions = True
                '    CartItemId = CType(Request.QueryString("CartItemId"), Integer)
                'Else
                '    AddRemoveSessions = False
                '    CartItemId = -1
                'End If
                'this check is done only for meetings and only for new meeting, not for an existing order
                If UpdateOrder = False Then
                    If ProductDetails IsNot Nothing AndAlso ProductDetails.Subsystem = "MTG" Then
                        'if cart item is passed from query string.. . else take it from shopping cart
                        If String.IsNullOrEmpty(Request.QueryString("CartItemId")) Then
                            CartItemId = DoesMeetingAlreadyExistInCart(ProductID)
                        Else
                            CartItemId = CType(Request.QueryString("CartItemId"), Integer)
                        End If

                        If CartItemId > 0 Then
                            AddRemoveSessions = True
                            '


                            If PM.Meeting.BadgesURL Is Nothing OrElse PM.Meeting.BadgesURL.Length = 0 Then
                                ShowBadgesHyperlink = False
                            Else
                                ShowBadgesHyperlink = True
                            End If
                        Else
                            AddRemoveSessions = False
                            ShowBadgesHyperlink = False
                            CartItemId = -1
                        End If
                    End If
                End If


                If ProductDetails IsNot Nothing AndAlso ProductDetails.ProductInfo IsNot Nothing AndAlso ProductDetails.ProductInfo.Count > 0 Then
                    ' show the page
                    LoadData()
                End If

                'If Not (IsPostBack) Then MessageControl.Clear()

                '' handle events

                'Fixed Ticket #3246-8277698
                If Not IsPageRefreshed() Then


                    If Request("__EVENTTARGET") IsNot Nothing AndAlso Request("__EVENTTARGET").IndexOf("lnkEditBadges") > 0 Then
                        'UpdateCart_DeleteItemsFromCart(MasterCustomerId, SubCustomerId, CartItemId)
                        'SubProductAddToCartButton_Click()
                        UpdateCartButton_Click(MasterCustomerId, SubCustomerId, False)
                        Response.Redirect(EditBadges_SetURL(ProductID))
                    End If


                    Dim PressedButton As String = CheckIfPostBackByButton("ProductAddToCartControl" + ModuleId.ToString, "Add_To_Cart")  '  + "_" + AllProducts(x).ProductId.ToString
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        AddToCartControl_ButtonClick(aAddToCartControl, Nothing)

                    End If
                    PressedButton = CheckIfPostBackByButton("ProductAddToCartControl" + ModuleId.ToString, "Add_To_Wish_List")   ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        AddToWishListControl_ButtonClick(aAddToCartControl, Nothing)
                    End If

                    PressedButton = CheckIfPostBackByButton("ProductAddToCartControl" + ModuleId.ToString, "Buy_For_Group")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        BuyforGroupControl_ButtonClick(aAddToCartControl, Nothing)
                    End If

                    PressedButton = CheckIfPostBackByButton("MeetingAddToCartControl" + ModuleId.ToString, "_")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        SubProductAddToCartButton_Click()
                    End If

                    'an update meeting
                    PressedButton = CheckIfPostBackByButton("MeetingUpdateCartControl" + ModuleId.ToString, "_")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        'UpdateCart_DeleteItemsFromCart(MasterCustomerId, SubCustomerId, CartItemId)

                        'SubProductAddToCartButton_Click()
                        UpdateCartButton_Click(MasterCustomerId, SubCustomerId, False)
                    End If


                    PressedButton = CheckIfPostBackByButton("MeetingAddToWishListControl" + ModuleId.ToString, "_")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        SubProductAddToWishListButton_Click()
                    End If

                    PressedButton = CheckIfPostBackByButton("MeetingBuyForGroupControl" + ModuleId.ToString, "_")    ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        SubProductBuyforGroupButton_Click()
                    End If


                    PressedButton = CheckIfPostBackByButton("MeetingUpdateOrderControl" + ModuleId.ToString, "_")    ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        SubProductUpdateOrderButton_Click()
                    End If

                    'DCD
                    PressedButton = CheckIfPostBackByButton(String.Concat("DCDAddToCartControl", ModuleId.ToString), "_")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        DCDProductAddToCartButton_Click()
                    End If

                    PressedButton = CheckIfPostBackByButton(String.Concat("DCDAddToWishListControl", ModuleId.ToString), "_")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        DCDProductAddToWishListButton_Click()
                    End If

                    PressedButton = CheckIfPostBackByButton(String.Concat("DCDBuyForGroupControl", ModuleId.ToString), "_")    ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")

                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        DCDProductBuyforGroupButton_Click()
                    End If

                    PressedButton = CheckIfPostBackByButton("XSellAddToCartControl" + ModuleId.ToString, "Add_To_Cart")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        XSellAddToCartControl_ButtonClick(aAddToCartControl)
                    End If

                    PressedButton = CheckIfPostBackByButton("XSellAddToCartControl" + ModuleId.ToString, "Add_To_Wish_List") ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        XSellAddToWishListControl_ButtonClick(aAddToCartControl)
                    End If

                    PressedButton = CheckIfPostBackByButton("XSellAddToCartControl" + ModuleId.ToString, "Buy_For_Group") ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        XSellBuyForGroupControl_ButtonClick(aAddToCartControl)
                    End If


                    PressedButton = CheckIfPostBackByButton("UpSellAddToCartControl" + ModuleId.ToString, "Add_To_Cart")
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        UpSellAddToCartControl_ButtonClick(aAddToCartControl)
                    End If

                    PressedButton = CheckIfPostBackByButton("UpSellAddToCartControl" + ModuleId.ToString, "Add_To_Wish_List")
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        UpSellAddToWishListControl_ButtonClick(aAddToCartControl)
                    End If

                    PressedButton = CheckIfPostBackByButton("UpSellAddToCartControl" + ModuleId.ToString, "Buy_For_Group")
                    'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        UpSellBuyforGroupControl_ButtonClick(aAddToCartControl)
                    End If

                    '                GetProductIDs()
                End If
                'Fixed Ticket #3246-8277698
                SaveRefreshState()
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try


        End Sub


#End Region



#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object


        ''' <summary>
        ''' load required templates 
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "helper functions"

        Private Sub DisplayCustomPriceError()

        End Sub
        'START 3246-5875068
        Private Function GetFNDPrice() As String

            Dim price As Double
            Dim priceValue As String = Request(txtCustomDonateAmount.UniqueID)
            If Not priceValue Is Nothing AndAlso _
                IsNumeric(priceValue) AndAlso CType(priceValue, Double) > 0 Then
                Try
                    price = CType(priceValue, Double)
                    Return Math.Round(price, 2)
                Catch ex As Exception
                    Return "-9999"
                End Try
            ElseIf priceValue IsNot Nothing AndAlso priceValue.Trim <> "" Then
                Return "-9999"
            End If

            Return Nothing

        End Function
        'END 3246-5875068
        Private Function GetProductIDs() As String
            Try
                'an cuna fix
                Dim r As String = String.Concat(ProductDetails.ProductId.ToString, "q", 1)

                Dim SubProductitems() As SubProductitem = CType(Page.Session("SubProductitems" + ProductDetails.ProductId.ToString), SubProductitem())
                If SubProductitems IsNot Nothing Then
                    If SubProductitems.Length > 0 Then
                        Dim tempCheckBox As CheckBox
                        Dim i As Integer
                        For i = 0 To SubProductitems.Length - 1
                            If SubProductitems(i) IsNot Nothing Then
                                tempCheckBox = Me.FindControl("SubProductCheckBox_" + ModuleId.ToString + "_" + SubProductitems(i).ProductId.ToString)

                                If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
                                    If Request(tempCheckBox.UniqueID) = "on" Then
                                        'an cuna fix
                                        'r = r + "," + SubProductitems(i).ProductId.ToString
                                        r = String.Concat(r, ",", SubProductitems(i).ProductId.ToString, "q", GetQuantity(SubProductitems(i).ProductId))

                                    End If
                                End If
                            End If
                        Next
                    End If
                End If

                Return r
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return Nothing
        End Function

#End Region

#Region "Image Functions"
        '3246-5774803
        Private Function GetBlankImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/blank.gif")
        End Function
        Private Function GetDivideRBGImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/dividerbg.gif")
        End Function
        Private Function GetAddToCartImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_addtocart.gif")
        End Function
        Private Function GetBuyForGroupImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_buyforgroup.gif")
        End Function
        Private Function GetUpdateOrderImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_updateorder.gif")
        End Function
        Private Function GetUpdateCartImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_updatecartdetail.gif")
        End Function
        Private Function GetWishListImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_wishlist.gif")
        End Function
        'END 3246-5774803
#End Region
        Public Event ModuleCommunication(ByVal sender As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleCommunicator.ModuleCommunication

        Public Sub OnModuleCommunication(ByVal s As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleListener.OnModuleCommunication

            Dim strPIDs As String = ""
            Select Case DirectCast(s, PersonifyCheckOut_ModuleCommunicationKeys)
                Case PersonifyCheckOut_ModuleCommunicationKeys.RequestProductIdsFromProductDetailWebPart
                    strPIDs = GetProductIDs()
                    'START 3246-5875068
                    If ProductDetails.Subsystem.ToUpper = "FND" Then
                        e.Value = GetFNDPrice()
                        If e.Value IsNot Nothing AndAlso e.Value = "-9999" Then
                            e.Type = "ERROR"
                        End If
                    End If
                    e.Text = strPIDs
                    e.Sender = PersonifyCheckOut_ModuleCommunicationKeys.RequestProductIdsFromProductDetailWebPart
                    'RaiseEvent ModuleCommunication(PersonifyCheckOut_ModuleCommunicationKeys.SelectedProductIds, e)
                    If e.Type Is Nothing OrElse e.Type <> "ERROR" Then
                        RaiseEvent ModuleCommunication(PersonifyCheckOut_ModuleCommunicationKeys.SelectedProductIds, e)
                    Else
                        'Must be FND error
                        'Custom price is invalid
                        DisplayCustomPriceError()
                    End If
                    'END 3246-5875068


                Case PersonifyCheckOut_ModuleCommunicationKeys.CheckForSamePageCheckout
                    strPIDs = GetProductIDs()
                    e.Text = strPIDs
                    e.Sender = PersonifyCheckOut_ModuleCommunicationKeys.SamePageCheckOutEnabled
            End Select



            'If s.ToString = "REQUESTPRODUCTIDS" Then
            '    strPIDs = GetProductIDs()
            '    e.Text = strPIDs
            '    RaiseEvent ModuleCommunication("PRODUCTIDS", e)
            'End If
        End Sub


#Region "Personify Data"

        'Private Function GetPrimaryAddress(ByVal pMasterCustomerId As String, _
        '     ByVal pSubCustomerId As String) As TIMSS.API.CustomerInfo.ICustomerAddressViewList

        '    If pMasterCustomerId.Length = 0 Then
        '        Return Nothing
        '    End If

        '    Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
        '    oAddresses = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")

        '    With oAddresses.Filter
        '        .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
        '        .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
        '        .Add("PrioritySeq", 0)
        '    End With
        '    oAddresses.Fill()


        '    Return oAddresses


        'End Function
#End Region


    End Class

End Namespace
