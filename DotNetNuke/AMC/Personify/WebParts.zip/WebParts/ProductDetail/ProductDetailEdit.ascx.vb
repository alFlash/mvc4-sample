Imports System
Imports System.Web.UI.WebControls
Imports Personify
Imports Personify.DNN.Modules.ProductDetail.Business
Imports DotNetNuke.Common.Lists
Imports DotNetNuke.Common.Utilities
Imports System.IO
Imports System.Collections.Specialized
Imports System.Collections
Imports System.Text

Namespace Personify.DNN.Modules.ProductDetail

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Class ProductDetailEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region " Controls "

#Region " Product Detail "

        Protected WithEvents SectionheadcontrolProductSettings As DotNetNuke.UI.UserControls.SectionHeadControl
        Protected WithEvents LabelControlPD_DisplayProductImage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBasePD_DisplayProductImage As DropDownList
        Protected WithEvents LabelControlPD_UrlProductIdParameter As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBasePD_UrlProductIdParameter As WebControls.TextBoxBase
        Protected WithEvents LabelControlPD_TruncateDescription As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBasePD_TruncateDescription As WebControls.TextBoxBase
        Protected WithEvents LabelControlPD_DefaultQuantity As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBasePD_DefaultQuantity As WebControls.TextBoxBase
        Protected WithEvents LabelControlPD_TruncateComponentsDescription As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBasePD_TruncateComponentsDescription As WebControls.TextBoxBase
        Protected WithEvents LabelControlPD_DisplayProductComponents As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents CheckBoxBasePD_DisplayProductComponents As System.Web.UI.WebControls.CheckBox
        Protected WithEvents pnlProductComponents As System.Web.UI.WebControls.Panel
        Protected WithEvents LabelControlPD_ShowComponentsImages As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents CheckBoxBasePD_ShowComponentsImages As System.Web.UI.WebControls.CheckBox 'WebControls.CheckBoxBase
        Protected WithEvents LabelControlPD_LayoutTemplate As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBasePD_LayoutTemplate As DropDownList
        'Protected WithEvents DropDownListBasePD_ECDLayoutTemplate As DropDownList
		Protected WithEvents DropDownListBasePD_PackageLayoutTemplate As DropDownList
        Protected WithEvents DropDownListBasePD_MeetingLayoutTemplate As DropDownList
        Protected WithEvents DropDownListBasePD_DCDLayoutTemplate As DropDownList

		Protected WithEvents LabelControlPD_Searchable As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBasePD_Searchable As DropDownList

        Protected WithEvents LabelControlPD_DisplayDownloadTerm As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBasePD_DisplayDownloadTerm As DropDownList

        Protected WithEvents Urlcontrol_BuyForGroup As DotNetNuke.UI.UserControls.UrlControl

        'new
        Protected WithEvents ShowButtons_CheckBox As System.Web.UI.WebControls.CheckBox
        Protected WithEvents TextBoxBase_ProductID As WebControls.TextBoxBase

        Protected WithEvents DropDownList_AddToCart As DropDownList
        Protected WithEvents DropDownList_AddToWishList As DropDownList
        Protected WithEvents DropDownList_UpdateOrder As DropDownList
        Protected WithEvents DropDownList_BuyForGroup As DropDownList



#End Region

#Region " Cross & Up Sell "

        Protected WithEvents SectionHeadControlCrossUpSellTable As DotNetNuke.UI.UserControls.SectionHeadControl
		'Protected WithEvents LabelControlCrossUpSell As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DataListCrossUpSellInclusion As DataList
		Protected WithEvents SectionHeadControlMeetingTable As DotNetNuke.UI.UserControls.SectionHeadControl
		'Protected WithEvents LabelControlMeeting As DotNetNuke.UI.UserControls.LabelControl

		'Protected WithEvents XSell_ALL As CheckBox
		'Protected WithEvents UPSell_ALL As CheckBox
		'Protected WithEvents PriceLayout_ALL As DropDownList
		'Protected WithEvents DisplayRateCode_ALL As CheckBox

		Protected WithEvents DataListMeetingInclusion As DataList


#End Region

#Region " Up Sell "

        Protected WithEvents SectionHeadControlUpSellSettings As DotNetNuke.UI.UserControls.SectionHeadControl
		'Protected WithEvents LabelControlUS_DisplayProductImage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseUS_DisplayProductImage As DropDownList
		'Protected WithEvents LabelControlUS_NumberOfColumns As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseUS_NumberOfColumns As DropDownList
		'Protected WithEvents LabelControlUS_RepeatDirection As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseUS_RepeatDirection As DropDownList
		'Protected WithEvents LabelControlUS_MaximumNumberOfProducts As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBaseUS_MaximumNumberOfProducts As WebControls.TextBoxBase
		'Protected WithEvents LabelControlUS_DisplayAddToCart As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseUS_DisplayAddToCart As DropDownList
		'Protected WithEvents LabelControlUS_DisplayAddToWishList As DotNetNuke.UI.UserControls.LabelControl
		Protected WithEvents DropDownListBaseUS_DisplayAddToWishList As DropDownList
        Protected WithEvents DropDownListBaseUS_DisplayBuyForGroup As DropDownList
        Protected WithEvents DropDownListBaseUS_DisplayUpdateOrder As DropDownList
		'Protected WithEvents LabelControlUS_TruncateDescription As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBaseUS_TruncateDescription As WebControls.TextBoxBase
		'Protected WithEvents LabelControlUS_LayoutTemplate As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseUS_LayoutTemplate As DropDownList
		'Protected WithEvents LabelControlUS_ProductUrl As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents UrlcontrolUS_ProductUrl As DotNetNuke.UI.UserControls.UrlControl
        'Protected WithEvents LabelControlPD_DefaultQuantity As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBaseUS_DefaultQuantity As WebControls.TextBoxBase

#End Region

#Region " Meeting "
		Protected WithEvents LabelControlUS_MeetingUrl As DotNetNuke.UI.UserControls.LabelControl
		Protected WithEvents UrlcontrolUS_MeetingUrl As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents UrlcontrolUpdateOrderUrl As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents UrlBadges As DotNetNuke.UI.UserControls.UrlControl
#End Region

#Region " Cross Sell "

        Protected WithEvents SectionHeadControlCrossSellSettings As DotNetNuke.UI.UserControls.SectionHeadControl
		'Protected WithEvents LabelControlCS_DisplayProductImage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseCS_DisplayProductImage As DropDownList
		'Protected WithEvents LabelControlCS_NumberOfColumns As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseCS_NumberOfColumns As DropDownList
		'Protected WithEvents LabelControlCS_RepeatDirection As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseCS_RepeatDirection As DropDownList
		'Protected WithEvents LabelControlCS_MaximumNumberOfProducts As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBaseCS_MaximumNumberOfProducts As WebControls.TextBoxBase
		'Protected WithEvents LabelControlCS_DisplayAddToCart As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseCS_DisplayAddToCart As DropDownList

		Protected WithEvents DropDownListBaseCS_DisplayAddToWishList As DropDownList
		Protected WithEvents DropDownListBaseCS_DisplayBuyForGroup As DropDownList
		'Protected WithEvents LabelControlCS_TruncateDescription As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBaseCS_TruncateDescription As WebControls.TextBoxBase
		'Protected WithEvents LabelControlCS_LayoutTemplate As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents DropDownListBaseCS_LayoutTemplate As DropDownList
		'Protected WithEvents LabelControlCS_ProductUrl As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents UrlcontrolCS_ProductUrl As DotNetNuke.UI.UserControls.UrlControl
		'Protected WithEvents LabelControlCS_ProductClassLink As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents UrlcontrolCS_ProductClassLink As DotNetNuke.UI.UserControls.UrlControl
        'Protected WithEvents LabelControlPD_DefaultQuantity As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents TextBoxBaseCS_DefaultQuantity As WebControls.TextBoxBase


#End Region

#Region " Update & Cancel "

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

#End Region

#Region " Validation "

        Protected WithEvents ValidationSummaryBaseProductListingEdit As ValidationSummary
        Protected WithEvents RegularExpressionValidatorPD_URLParameter As RegularExpressionValidator
        Protected WithEvents RegularExpressionValidatorPD_TruncateDescription As RegularExpressionValidator
        Protected WithEvents RangeValidatorPD_DefaultQuantity As RangeValidator
        Protected WithEvents RegularExpressionValidatorPD_TruncateComponentsDescription As RegularExpressionValidator
        Protected WithEvents RegularExpressionValidatorXSell_NumberOfProducts As RegularExpressionValidator
        Protected WithEvents RegularExpressionValidatorXSell_TruncateDescription As RegularExpressionValidator
        Protected WithEvents RangeValidatorXSell_DefaultQuantity As RangeValidator
        Protected WithEvents RegularExpressionValidatorUpSell_NumberOfProducts As RegularExpressionValidator
        Protected WithEvents RegularExpressionValidatorUpSell_TruncateDescription As RegularExpressionValidator
        Protected WithEvents RangeValidatorUpSell_DefaultQuantity As RangeValidator

#End Region

#Region "Fund Raising"
        Protected WithEvents chkCustomPrice As CheckBox
#End Region

#End Region

#Region "Private Members"

        Private itemId As Integer
        Private PM As ProductDetailModel
        Private Const C_NO As String = "NO"
        Private Const C_YES As String = "YES"
        Private Const C_TRUE As String = "true"
        Private Const C_FALSE As String = "false"
        Private Const C_NUMBEROFCOLUMNS As String = "NumberOfColumns"
        Private Const C_REPEATDIRECTION As String = "RepeatDirection"
		Private Const c_TEXT As String = "Text"
        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl
        Private Const C_XSELL As String = "XSell"
		Private Const C_UPSELL As String = "UPSell"
		Private Const C_Meeting As String = "MeetingType"
		Private Const C_DATALISTCROSSUPSELLINCLUSION As String = "DataListCrossUpSellInclusion"
		Private Const C_DATALISTMEETINGINCLUSION As String = "DataListMeetingInclusion"
        Private Const C_PRICELAYOUT As String = "PriceLayout"
        Private Const C_DISPLAYRATECODE As String = "DisplayRateCode"

#End Region

#Region "Private Sub/Functions"

        ''' <summary>
        ''' get templates from subdirectory
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function

        ''' <summary>
        ''' GetLocalizedYesNo from local resource file
        ''' </summary>
        ''' <param name="YesNo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetLocalizedYesNo(ByVal YesNo As String) As String
            Try
                If YesNo.ToUpper = C_YES Then
                    Return Localization.GetString(C_YES + c_TEXT, Me.LocalResourceFile)
                Else
                    Return Localization.GetString(C_NO + c_TEXT, Me.LocalResourceFile)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return String.Empty
        End Function

        ''' <summary>
        ''' populate dropdowns
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadDropDowns()
            Try
                Dim ctlEntry As New ListController
                Dim EI As ListEntryInfo

                For Each EI In ctlEntry.GetListEntryInfoCollection(C_NUMBEROFCOLUMNS)
                    DropDownListBaseCS_NumberOfColumns.Items.Add(New ListItem(EI.Text.ToString, EI.Value.ToString))
                    DropDownListBaseUS_NumberOfColumns.Items.Add(New ListItem(EI.Text.ToString, EI.Value.ToString))
                Next

                For Each EI In ctlEntry.GetListEntryInfoCollection(C_REPEATDIRECTION)
                    DropDownListBaseCS_RepeatDirection.Items.Add(New ListItem(EI.Text.ToString, EI.Value.ToString))
                    DropDownListBaseUS_RepeatDirection.Items.Add(New ListItem(EI.Text.ToString, EI.Value.ToString))
                Next

                DropDownListBaseCS_DisplayAddToCart.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBaseCS_DisplayAddToCart.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))
				DropDownListBaseCS_DisplayAddToWishList.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
				DropDownListBaseCS_DisplayAddToWishList.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))
				DropDownListBaseCS_DisplayBuyForGroup.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
				DropDownListBaseCS_DisplayBuyForGroup.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

				DropDownListBaseCS_DisplayProductImage.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBaseCS_DisplayProductImage.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownListBasePD_DisplayProductImage.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBasePD_DisplayProductImage.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownListBaseUS_DisplayAddToCart.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBaseUS_DisplayAddToCart.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))
				DropDownListBaseUS_DisplayAddToWishList.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
				DropDownListBaseUS_DisplayAddToWishList.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))
				DropDownListBaseUS_DisplayBuyForGroup.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
				DropDownListBaseUS_DisplayBuyForGroup.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

				DropDownListBaseUS_DisplayProductImage.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBaseUS_DisplayProductImage.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

				DropDownListBasePD_Searchable.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBasePD_Searchable.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownListBasePD_DisplayDownloadTerm.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownListBasePD_DisplayDownloadTerm.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownList_AddToCart.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownList_AddToCart.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownList_AddToWishList.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownList_AddToWishList.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownList_UpdateOrder.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownList_UpdateOrder.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

                DropDownList_BuyForGroup.Items.Add(New ListItem(GetLocalizedYesNo(C_YES), C_TRUE))
                DropDownList_BuyForGroup.Items.Add(New ListItem(GetLocalizedYesNo(C_NO), C_FALSE))

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' <summary>
        ''' update all settings and save
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub Update()

            Try
                UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

                UpdateProductSettings()
                UpdateCrossUpSellInclusion()
                UpdatePriceLayout()
                UpdateDisplayRateCode()
                UpdateUpSell()
                UpdateCrossSell()
                UpdateMeetingInclusion()
                UpdateFundRaisingSetting()
                PM.Save()
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try


        End Sub

        ''' <summary>
        ''' update ProductDetailModel with ProductSettings
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub UpdateProductSettings()
            Try
                If PM Is Nothing Then
                    PM = New ProductDetailModel(ModuleId)
                    PM.Load()
                End If
                If PM IsNot Nothing AndAlso PM.Settings IsNot Nothing Then
                    If PM IsNot Nothing AndAlso PM.Settings IsNot Nothing Then
                        With PM.Settings
                            .DisplayProductImage = Convert.ToBoolean(DropDownListBasePD_DisplayProductImage.SelectedValue)
                            .TruncateDescription = Integer.Parse(TextBoxBasePD_TruncateDescription.Text)
                            .DefaultQuantity = Integer.Parse(TextBoxBasePD_DefaultQuantity.Text)
                            .DisplayProductComponents = CheckBoxBasePD_DisplayProductComponents.Checked
                            Dim truncate As Integer = 0
                            Try
                                truncate = Convert.ToInt32(TextBoxBasePD_TruncateComponentsDescription.Text)
                            Catch ex As Exception

                            End Try
                            .TruncateComponentsDescription = truncate
                            .ShowComponentsImages = CheckBoxBasePD_ShowComponentsImages.Checked
                            .ProductIdParameters = TextBoxBasePD_UrlProductIdParameter.Text
                            .LayoutTemplate = DropDownListBasePD_LayoutTemplate.SelectedValue
							.LayoutPackageTemplate = DropDownListBasePD_PackageLayoutTemplate.SelectedValue
                            .LayoutMeetingTemplate = DropDownListBasePD_MeetingLayoutTemplate.SelectedValue
                            .LayoutDCDTemplate = DropDownListBasePD_DCDLayoutTemplate.SelectedValue

                            .Searchable = Convert.ToBoolean(DropDownListBasePD_Searchable.SelectedValue)
                            .DisplayDownloadTerm = Convert.ToBoolean(DropDownListBasePD_DisplayDownloadTerm.SelectedValue)

                            .ShowAddtoCart = Convert.ToBoolean(Me.DropDownList_AddToCart.SelectedValue)
                            .ShowWishList = Convert.ToBoolean(Me.DropDownList_AddToWishList.SelectedValue)
                            .ShowUpdateOrder = Convert.ToBoolean(Me.DropDownList_UpdateOrder.SelectedValue)
                            .ShowBuyForGroup = Convert.ToBoolean(Me.DropDownList_BuyForGroup.SelectedValue)

							.BuyForGroupURL = Urlcontrol_BuyForGroup.Url
                            .BuyForGroupURLType = Urlcontrol_BuyForGroup.UrlType

                            Dim product_id As Integer = 0
                            Try
                                product_id = Convert.ToInt32(TextBoxBase_ProductID.Text)
                            Catch ex As Exception

                            End Try

                            .ProductId = product_id
                            .ShowButtons = ShowButtons_CheckBox.Checked

						End With
					End If
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' <summary>
		''' update ProductDetailModel with UpdateCrossSell Settings
		''' </summary>
		''' <remarks></remarks>
		Private Sub UpdateCrossSell()
			Try
				If PM IsNot Nothing AndAlso PM.CrossSell IsNot Nothing Then
					With PM.CrossSell
						.DisplayProductImage = Convert.ToBoolean(DropDownListBaseCS_DisplayProductImage.SelectedValue)
						.NumberOfColumns = Integer.Parse(DropDownListBaseCS_NumberOfColumns.SelectedValue)
						.RepeatDirection = DropDownListBaseCS_RepeatDirection.SelectedValue.ToString
						.MaximumNumberOfProducts = Integer.Parse(TextBoxBaseCS_MaximumNumberOfProducts.Text)
						.DisplayAddToCart = Convert.ToBoolean(DropDownListBaseCS_DisplayAddToCart.SelectedValue)
						.DisplayAddToWishList = Convert.ToBoolean(DropDownListBaseCS_DisplayAddToWishList.SelectedValue)
						.DisplayBuyForGroup = Convert.ToBoolean(DropDownListBaseCS_DisplayBuyForGroup.SelectedValue)
                        .TruncateDescription = Integer.Parse(TextBoxBaseCS_TruncateDescription.Text)
                        .DefaultQuantity = Integer.Parse(TextBoxBaseCS_DefaultQuantity.Text)
						.LayoutTemplate = DropDownListBaseCS_LayoutTemplate.SelectedValue
						.ProductURL = UrlcontrolCS_ProductUrl.Url
						.ProductURLType = UrlcontrolCS_ProductUrl.UrlType
						.ProductClass = UrlcontrolCS_ProductClassLink.Url
						.ProductClassType = UrlcontrolCS_ProductClassLink.UrlType
					End With
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' <summary>
		''' update ProductDetailModel with UpSell Settings
		''' </summary>
		''' <remarks></remarks>
		Private Sub UpdateUpSell()
			Try
				If PM IsNot Nothing AndAlso PM.UpSell IsNot Nothing Then
					With PM.UpSell
						.DisplayProductImage = Convert.ToBoolean(DropDownListBaseUS_DisplayProductImage.SelectedValue)
						.NumberOfColumns = Convert.ToInt32(DropDownListBaseUS_NumberOfColumns.SelectedValue)
						.RepeatDirection = DropDownListBaseUS_RepeatDirection.SelectedValue.ToString
						.MaximumNumberOfProducts = Convert.ToInt32(TextBoxBaseUS_MaximumNumberOfProducts.Text)
						.DisplayAddToCart = Convert.ToBoolean(DropDownListBaseUS_DisplayAddToCart.SelectedValue)
						.DisplayAddToWishList = Convert.ToBoolean(DropDownListBaseUS_DisplayAddToWishList.SelectedValue)
						.DisplayBuyForGroup = Convert.ToBoolean(DropDownListBaseUS_DisplayBuyForGroup.SelectedValue)
                        .TruncateDescription = Convert.ToInt32(TextBoxBaseUS_TruncateDescription.Text)
                        .DefaultQuantity = Convert.ToInt32(TextBoxBaseUS_DefaultQuantity.Text)
						.LayoutTemplate = DropDownListBaseUS_LayoutTemplate.SelectedValue
						.ProductURL = UrlcontrolUS_ProductUrl.Url
						.ProductURLType = UrlcontrolUS_ProductUrl.UrlType
					End With
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' <summary>
		''' load All settings from ProductDetailModel
		''' </summary>
		''' <remarks></remarks>
		Private Sub SetValues()
			Try
				If PM IsNot Nothing Then
					PM.Load()
					If PM.Settings IsNot Nothing Then
						With PM.Settings
							.Load()
							DropDownListBasePD_DisplayProductImage.SelectedIndex = DropDownListBasePD_DisplayProductImage.Items.IndexOf(DropDownListBasePD_DisplayProductImage.Items.FindByValue(.DisplayProductImage.ToString.ToLower))
							DropDownListBasePD_LayoutTemplate.SelectedIndex = DropDownListBasePD_LayoutTemplate.Items.IndexOf(DropDownListBasePD_LayoutTemplate.Items.FindByValue(.LayoutTemplate))
                            DropDownListBasePD_DCDLayoutTemplate.SelectedIndex = DropDownListBasePD_DCDLayoutTemplate.Items.IndexOf(DropDownListBasePD_DCDLayoutTemplate.Items.FindByValue(.LayoutDCDTemplate))
							DropDownListBasePD_PackageLayoutTemplate.SelectedIndex = DropDownListBasePD_PackageLayoutTemplate.Items.IndexOf(DropDownListBasePD_PackageLayoutTemplate.Items.FindByValue(.LayoutPackageTemplate))
							DropDownListBasePD_MeetingLayoutTemplate.SelectedIndex = DropDownListBasePD_MeetingLayoutTemplate.Items.IndexOf(DropDownListBasePD_MeetingLayoutTemplate.Items.FindByValue(.LayoutMeetingTemplate))
                            TextBoxBasePD_TruncateDescription.Text = .TruncateDescription.ToString
                            TextBoxBasePD_DefaultQuantity.Text = .DefaultQuantity.ToString
                            CheckBoxBasePD_DisplayProductComponents.Checked = .DisplayProductComponents
                            If .DisplayProductComponents Then
                                TextBoxBasePD_TruncateComponentsDescription.Text = .TruncateComponentsDescription.ToString
                                CheckBoxBasePD_ShowComponentsImages.Checked = .ShowComponentsImages
                                pnlProductComponents.Visible = True
                            Else
                                pnlProductComponents.Visible = False
                            End If
                            TextBoxBasePD_UrlProductIdParameter.Text = .ProductIdParameters
							DropDownListBasePD_Searchable.SelectedIndex = DropDownListBasePD_Searchable.Items.IndexOf(DropDownListBasePD_Searchable.Items.FindByValue(.Searchable.ToString.ToLower))
                            DropDownListBasePD_DisplayDownloadTerm.SelectedIndex = DropDownListBasePD_DisplayDownloadTerm.Items.IndexOf(DropDownListBasePD_DisplayDownloadTerm.Items.FindByValue(.DisplayDownloadTerm.ToString.ToLower))

                            DropDownList_AddToCart.SelectedIndex = DropDownList_AddToCart.Items.IndexOf(DropDownList_AddToCart.Items.FindByValue(.ShowAddtoCart.ToString.ToLower))
                            DropDownList_AddToWishList.SelectedIndex = DropDownList_AddToWishList.Items.IndexOf(DropDownList_AddToWishList.Items.FindByValue(.ShowWishList.ToString.ToLower))
                            DropDownList_UpdateOrder.SelectedIndex = DropDownList_UpdateOrder.Items.IndexOf(DropDownList_UpdateOrder.Items.FindByValue(.ShowUpdateOrder.ToString.ToLower))
                            DropDownList_BuyForGroup.SelectedIndex = DropDownList_BuyForGroup.Items.IndexOf(DropDownList_BuyForGroup.Items.FindByValue(.ShowBuyForGroup.ToString.ToLower))

							Urlcontrol_BuyForGroup.Url = .BuyForGroupURL
							Urlcontrol_BuyForGroup.UrlType = .BuyForGroupURLType

                            ShowButtons_CheckBox.Checked = .ShowButtons
                            TextBoxBase_ProductID.Text = .ProductId.ToString
						End With
					End If

					If PM.CrossSell IsNot Nothing Then
						With PM.CrossSell
							.Load()
							DropDownListBaseCS_DisplayProductImage.SelectedIndex = DropDownListBaseCS_DisplayProductImage.Items.IndexOf(DropDownListBaseCS_DisplayProductImage.Items.FindByValue(.DisplayProductImage.ToString.ToLower))
							DropDownListBaseCS_NumberOfColumns.SelectedIndex = DropDownListBaseCS_NumberOfColumns.Items.IndexOf(DropDownListBaseCS_NumberOfColumns.Items.FindByValue(.NumberOfColumns.ToString))
							DropDownListBaseCS_RepeatDirection.SelectedIndex = DropDownListBaseCS_RepeatDirection.Items.IndexOf(DropDownListBaseCS_RepeatDirection.Items.FindByValue(.RepeatDirection))
							TextBoxBaseCS_MaximumNumberOfProducts.Text = .MaximumNumberOfProducts.ToString
							DropDownListBaseCS_DisplayAddToCart.SelectedIndex = DropDownListBaseCS_DisplayAddToCart.Items.IndexOf(DropDownListBaseCS_DisplayAddToCart.Items.FindByValue(.DisplayAddToCart.ToString.ToLower))
							DropDownListBaseCS_DisplayAddToWishList.SelectedIndex = DropDownListBaseCS_DisplayAddToWishList.Items.IndexOf(DropDownListBaseCS_DisplayAddToWishList.Items.FindByValue(.DisplayAddToWishList.ToString.ToLower))
							DropDownListBaseCS_DisplayBuyForGroup.SelectedIndex = DropDownListBaseCS_DisplayBuyForGroup.Items.IndexOf(DropDownListBaseCS_DisplayBuyForGroup.Items.FindByValue(.DisplayBuyForGroup.ToString.ToLower))
                            TextBoxBaseCS_TruncateDescription.Text = .TruncateDescription.ToString
                            TextBoxBaseCS_DefaultQuantity.Text = .DefaultQuantity.ToString
							DropDownListBaseCS_LayoutTemplate.SelectedIndex = DropDownListBaseCS_LayoutTemplate.Items.IndexOf(DropDownListBaseCS_LayoutTemplate.Items.FindByValue(.LayoutTemplate))
							UrlcontrolCS_ProductUrl.Url = .ProductURL
							UrlcontrolCS_ProductUrl.UrlType = .ProductURLType

							UrlcontrolCS_ProductClassLink.Url = .ProductClass
							UrlcontrolCS_ProductClassLink.UrlType = .ProductClassType
						End With
					End If

					If PM.UpSell IsNot Nothing Then
						With PM.UpSell
							.Load()
							DropDownListBaseUS_DisplayProductImage.SelectedIndex = DropDownListBaseUS_DisplayProductImage.Items.IndexOf(DropDownListBaseUS_DisplayProductImage.Items.FindByValue(.DisplayProductImage.ToString.ToLower))
							DropDownListBaseUS_NumberOfColumns.SelectedIndex = DropDownListBaseUS_NumberOfColumns.Items.IndexOf(DropDownListBaseUS_NumberOfColumns.Items.FindByValue(.NumberOfColumns.ToString))
							DropDownListBaseUS_RepeatDirection.SelectedIndex = DropDownListBaseUS_RepeatDirection.Items.IndexOf(DropDownListBaseUS_RepeatDirection.Items.FindByValue(.RepeatDirection))
							TextBoxBaseUS_MaximumNumberOfProducts.Text = .MaximumNumberOfProducts.ToString
							DropDownListBaseUS_DisplayAddToCart.SelectedIndex = DropDownListBaseUS_DisplayAddToCart.Items.IndexOf(DropDownListBaseUS_DisplayAddToCart.Items.FindByValue(.DisplayAddToCart.ToString.ToLower))
							DropDownListBaseUS_DisplayAddToWishList.SelectedIndex = DropDownListBaseUS_DisplayAddToWishList.Items.IndexOf(DropDownListBaseUS_DisplayAddToWishList.Items.FindByValue(.DisplayAddToWishList.ToString.ToLower))
							DropDownListBaseUS_DisplayBuyForGroup.SelectedIndex = DropDownListBaseUS_DisplayBuyForGroup.Items.IndexOf(DropDownListBaseUS_DisplayBuyForGroup.Items.FindByValue(.DisplayBuyForGroup.ToString.ToLower))
                            TextBoxBaseUS_TruncateDescription.Text = .TruncateDescription.ToString
                            TextBoxBaseUS_DefaultQuantity.Text = .DefaultQuantity.ToString
							DropDownListBaseUS_LayoutTemplate.SelectedIndex = DropDownListBaseUS_LayoutTemplate.Items.IndexOf(DropDownListBaseUS_LayoutTemplate.Items.FindByValue(.LayoutTemplate))
							UrlcontrolUS_ProductUrl.Url = .ProductURL
							UrlcontrolUS_ProductUrl.UrlType = .ProductURLType
						End With
					End If

					If PM.Meeting IsNot Nothing Then
						UrlcontrolUS_MeetingUrl.Url = PM.Meeting.MeetingURL
						UrlcontrolUS_MeetingUrl.UrlType = PM.Meeting.MeetingURLType

                        UrlcontrolUpdateOrderUrl.Url = PM.Meeting.UpdateOrderURL
                        UrlcontrolUpdateOrderUrl.UrlType = PM.Meeting.UpdateOrderURLType

                        UrlBadges.Url = PM.Meeting.BadgesURL
                        UrlBadges.UrlType = PM.Meeting.BadgesURLType

                    End If

				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

        ''' <summary>
        ''' load template lists
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadTemplates()
            Dim li As ListItem
            Try
                For Each li In GetTemplates()
                    DropDownListBasePD_LayoutTemplate.Items.Add(li)
                Next

                For Each li In GetTemplates()
                    DropDownListBasePD_DCDLayoutTemplate.Items.Add(li)
                Next

                For Each li In GetTemplates()
                    DropDownListBasePD_PackageLayoutTemplate.Items.Add(li)
                Next

                For Each li In GetTemplates()
                    DropDownListBasePD_MeetingLayoutTemplate.Items.Add(li)
                Next

                For Each li In GetTemplates()
                    DropDownListBaseUS_LayoutTemplate.Items.Add(li)
                Next

                For Each li In GetTemplates()
                    DropDownListBaseCS_LayoutTemplate.Items.Add(li)
                Next

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' <summary>
        ''' calls LoadTemplates() and LoadDropDowns()
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadValues()
            Try
                LoadTemplates()
                LoadDropDowns()
            Catch ex As Exception

            End Try
        End Sub

        ''' <summary>
        ''' get info about the subsystem
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetSubsystems() As StringDictionary
            Try
                Dim Subs As New StringDictionary
                Dim AppSubs As TIMSS.API.ApplicationInfo.IApplicationSubsystems
                Dim AppSub As TIMSS.API.ApplicationInfo.IApplicationSubsystem

                AppSubs = TIMSS.API.CachedApplicationData.ApplicationDataCache.SubSystems

                For Each AppSub In AppSubs
                    If AppSub.ProductFlag = True AndAlso AppSub.ActiveFlag = True Then
                        Subs.Add(AppSub.SubsystemName, AppSub.Subsystem)
                    End If

                Next

                Return Subs
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
            Return Nothing
        End Function


		Private Function GetMeetingProductTypes() As StringDictionary
			Try
				Dim ProductTypes As New StringDictionary
				Dim AppProductTypes As TIMSS.API.ApplicationInfo.IApplicationCodes
				Dim AppProductType As TIMSS.API.ApplicationInfo.IApplicationCode

                AppProductTypes = GetApplicationCodes( "MTG", "PRODUCT_TYPE",true)

				For Each AppProductType In AppProductTypes
					ProductTypes.Add(AppProductType.Description, AppProductType.Code)
				Next

				Return ProductTypes
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
			Return Nothing
		End Function

		''' <summary>
		''' update ProductDetailModel with cross and up sell inclusion settings
		''' </summary>
		''' <remarks></remarks>
		Private Sub UpdateCrossUpSellInclusion()

			Try
				Dim oControl As Control
				Dim oCheckBox As CheckBox
				Dim UpSellInclusion As New ArrayList
				Dim XSellInclusion As New ArrayList
				Dim tmpDataListItem As DataListItem

				Dim tmpDataList As DataList
				tmpDataList = CType(Me.FindControl(C_DATALISTCROSSUPSELLINCLUSION), DataList)
				For Each tmpDataListItem In tmpDataList.Items
					For Each oControl In tmpDataListItem.Controls
						If TypeOf oControl Is CheckBox Then
							oCheckBox = DirectCast(oControl, CheckBox)
							If oCheckBox.Checked Then
								If oCheckBox.ID.IndexOf(C_UPSELL) <> -1 Then
									UpSellInclusion.Add(GetSubsystemNameFromID(oCheckBox.ID))
								ElseIf oCheckBox.ID.IndexOf(C_XSELL) <> -1 Then
									XSellInclusion.Add(GetSubsystemNameFromID(oCheckBox.ID))
								End If
							End If
						End If
					Next
				Next
				PM.CrossSellSubsystemInclusion = XSellInclusion
				PM.UpSellSubsystemInclusion = UpSellInclusion
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		Private Sub UpdateMeetingInclusion()

			Try
				Dim oControl As Control
				Dim oCheckBox As CheckBox
				Dim MeetingInclusion As New ArrayList
				Dim tmpDataListItem As DataListItem

				Dim tmpDataList As DataList
				tmpDataList = CType(Me.FindControl(C_DATALISTMEETINGINCLUSION), DataList)
				For Each tmpDataListItem In tmpDataList.Items
					For Each oControl In tmpDataListItem.Controls
						If TypeOf oControl Is CheckBox Then
							oCheckBox = DirectCast(oControl, CheckBox)
							If oCheckBox.Checked Then
								If oCheckBox.ID.IndexOf(C_Meeting) <> -1 Then
									MeetingInclusion.Add(GetSubsystemNameFromID(oCheckBox.ID))
								End If
							End If
						End If
					Next
				Next
				PM.Meeting.MeetingInclusion = MeetingInclusion

				PM.Meeting.MeetingURL = UrlcontrolUS_MeetingUrl.Url
				PM.Meeting.MeetingURLType = UrlcontrolUS_MeetingUrl.UrlType

                PM.Meeting.UpdateOrderURL = UrlcontrolUpdateOrderUrl.Url
                PM.Meeting.UpdateOrderURLType = UrlcontrolUpdateOrderUrl.UrlType

                PM.Meeting.BadgesURL = UrlBadges.Url
                PM.Meeting.BadgesURLType = UrlBadges.UrlType
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' <summary>
		''' update ProductDetailModel with display rate code settings
		''' </summary>
		''' <remarks></remarks>
		Private Sub UpdateDisplayRateCode()

			Try
				Dim oControl As Control
				Dim oCheckBox As CheckBox
				Dim DisplayRateCode As New ArrayList
				Dim tmpDataListItem As DataListItem

				Dim tmpDataList As DataList
				tmpDataList = CType(Me.FindControl(C_DATALISTCROSSUPSELLINCLUSION), DataList)
				For Each tmpDataListItem In tmpDataList.Items
					For Each oControl In tmpDataListItem.Controls
						If TypeOf oControl Is CheckBox Then
							oCheckBox = DirectCast(oControl, CheckBox)
							If oCheckBox.Checked Then
								If oCheckBox.ID.IndexOf(C_DISPLAYRATECODE) <> -1 Then
									DisplayRateCode.Add(GetSubsystemNameFromID(oCheckBox.ID))
								End If
							End If
						End If
					Next
				Next
				PM.DisplayRateCode = DisplayRateCode

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' <summary>
		''' update ProductDetailModel with price layout settings
		''' </summary>
		''' <remarks></remarks>
		Private Sub UpdatePriceLayout()
			Try
				Dim oControl As Control
				Dim oDropDownList As DropDownList
				Dim PriceLayoutList As New StringDictionary
				Dim tmpDataListItem As DataListItem

				Dim tmpDataList As DataList
				tmpDataList = CType(Me.FindControl(C_DATALISTCROSSUPSELLINCLUSION), DataList)
				For Each tmpDataListItem In tmpDataList.Items
					For Each oControl In tmpDataListItem.Controls
						If TypeOf oControl Is DropDownList Then
							oDropDownList = DirectCast(oControl, DropDownList)
							If oDropDownList.ID.IndexOf(C_PRICELAYOUT) <> -1 Then
                                PriceLayoutList.Add(GetSubsystemNameFromID(oDropDownList.ID), oDropDownList.SelectedValue)
                                'Right now only set it to default pricing.
                                'PriceLayoutList.Add(GetSubsystemNameFromID(oDropDownList.ID), "DefaultPricing")
							End If
						End If
					Next
				Next
				PM.PriceLayout = PriceLayoutList

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' <summary>
		''' return subsystem name
		''' </summary>
		''' <param name="cbID"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function GetSubsystemNameFromID(ByVal cbID As String) As String
			Try
				If cbID <> String.Empty AndAlso cbID.IndexOf("_") <> -1 Then
					Return cbID.Substring(cbID.IndexOf("_") + 1, cbID.Length - cbID.IndexOf("_") - 1)
				End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
			Return String.Empty
		End Function

		''' <summary>
		''' first char of each word uppercase
		''' </summary>
		''' <param name="inWord"></param>
		''' <returns></returns>
		''' <remarks></remarks>
		Private Function CapitalizeWords(ByVal inWord As String) As String

			Try
				Dim delimStr As String = " "
				Dim delimiter As Char() = delimStr.ToCharArray()
				Dim words() As String = inWord.Split(delimiter)

				Dim sb As New StringBuilder

				Dim tmpWord As String

				For Each tmpWord In words
					sb.Append(tmpWord.Substring(0, 1).ToUpper + tmpWord.Substring(1, tmpWord.Length - 1))
					sb.Append(" ")
				Next

				Return sb.ToString.Substring(0, sb.ToString.Length - 1)

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
			Return String.Empty
		End Function

		''' <summary>
		''' load validation messages from local resources
		''' </summary>
		''' <remarks></remarks>
		Private Sub SetValidationMessages()
			Try
				RegularExpressionValidatorPD_URLParameter.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorPD_URLParameter.Text", Me.LocalResourceFile)
                RegularExpressionValidatorPD_TruncateDescription.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorPD_TruncateDescription.Text", Me.LocalResourceFile)
                RangeValidatorPD_DefaultQuantity.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RangeValidatorPD_DefaultQuantity.Text", Me.LocalResourceFile)
                RegularExpressionValidatorPD_TruncateComponentsDescription.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorPD_TruncateComponentsDescription.Text", Me.LocalResourceFile)
				RegularExpressionValidatorXSell_NumberOfProducts.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorXSell_NumberOfProducts.Text", Me.LocalResourceFile)
                RegularExpressionValidatorXSell_TruncateDescription.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorXSell_TruncateDescription.Text", Me.LocalResourceFile)
                RangeValidatorXSell_DefaultQuantity.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RangeValidatorXSell_DefaultQuantity.Text", Me.LocalResourceFile)
				RegularExpressionValidatorUpSell_NumberOfProducts.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorUpSell_NumberOfProducts.Text", Me.LocalResourceFile)
                RegularExpressionValidatorUpSell_TruncateDescription.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RegularExpressionValidatorUpSell_TruncateDescription.Text", Me.LocalResourceFile)
                RangeValidatorUpSell_DefaultQuantity.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("RangeValidatorUpSell_DefaultQuantity.Text", Me.LocalResourceFile)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region "Event Handlers"

		''' <summary>
		''' build the page by loading module settings and messages. ItemId from query string???
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks></remarks>
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Dim objCtlProductDetail As ProductDetailController
			Dim objProductDetail As ProductDetailInfo
			Try
				objCtlProductDetail = New ProductDetailController
				objProductDetail = New ProductDetailInfo
				' Determine ItemId
				If Not (Request.Params("ItemId") Is Nothing) Then
					itemId = Int32.Parse(Request.Params("ItemId"))
				Else
					itemId = Null.NullInteger()
				End If
				If Not Page.IsPostBack Then
					PM = New ProductDetailModel(ModuleId)
					PM.Load()
					LoadValues()
					SetValues()
					SetValidationMessages()

                    LoadFundRaisingSetting()
	

				End If
				LoadInclusionList()
				LoadMeetingInclusionList()

				LoadSettingForALL()

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			Finally
				objCtlProductDetail = Nothing
				objProductDetail = Nothing
			End Try
		End Sub

		Private Sub LoadSettingForALL()

			'Private XSellall As Boolean = False
			'Private UpSellall As Boolean = False
			'Private DisplayRateCodeall As Boolean = False

			If Not IsPostBack Then

				Dim tempObject As Object

				tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("PriceLayout_ALL")
				If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.DropDownList) Then
					'to prerender
					'[DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).SelectedIndex = PriceLayoutall
					tempObject.Attributes.Add("onClick", "javascript: selectall(this, 'PriceLayout_');")
				End If

				tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("XSell_ALL")
				If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = XSellall
					tempObject.Attributes.Add("onClick", "javascript: selectall(this, 'XSell_');")
				End If

				tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("UPSell_ALL")
				If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = UpSellall
					tempObject.Attributes.Add("onClick", "javascript: selectall(this, 'UPSell_');")
				End If

				tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("DisplayRateCode_ALL")
				If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = DisplayRateCodeall
					tempObject.Attributes.Add("onClick", "javascript: selectall(this, 'DisplayRateCode');")
				End If

				tempObject = DataListMeetingInclusion.Controls(0).FindControl("Meeting_ALL")
				If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = MeetingALL
					tempObject.Attributes.Add("onClick", "javascript: selectall(this, 'MeetingType_');")
				End If
			End If
		
		End Sub

		''' <summary>
		''' load inclusion list from GetSubsystems ???
		''' </summary>
		''' <remarks></remarks>
		Private Sub LoadInclusionList()
			Try
				Dim sc As StringDictionary = GetSubsystems()
				DataListCrossUpSellInclusion.DataSource = sc
				DataListCrossUpSellInclusion.DataBind()

				'load select all list on top

				'Dim tempItem As DictionaryEntry
				Dim tempObject As Object
				Dim PriceLayouts As Hashtable
				tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("PriceLayout_ALL")
				If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.DropDownList) Then
					PriceLayouts = DNN.Modules.ProductDetail.SharedProductDetail.GetPriceLayoutList(Me.LocalResourceFile)
					DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataSource = PriceLayouts
					DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataTextField = "key"
					DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataValueField = "value"
					DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataBind()
				End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub LoadMeetingInclusionList()
			Try

				Dim sc As StringDictionary = GetMeetingProductTypes()
				DataListMeetingInclusion.DataSource = sc
				DataListMeetingInclusion.DataBind()
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub


		Private Function ReturnURL() As String

			Dim ProductIdInfo As DictionaryEntry
			Dim tmpQueryString As String = String.Empty

			If Page.Session("ProductIdInfo") IsNot Nothing Then
				ProductIdInfo = CType(Page.Session("ProductIdInfo"), DictionaryEntry)
			End If

			Dim baselink As String = NavigateURL()

			If baselink.IndexOf("?") > 0 Then
				tmpQueryString = "&"
			Else
				tmpQueryString = "?"
			End If
			If ProductIdInfo.Key IsNot Nothing Then
				tmpQueryString += ProductIdInfo.Key.ToString + "=" + ProductIdInfo.Value.ToString
			End If
			baselink += tmpQueryString

			Return baselink

		End Function

		''' <summary>
		''' update settings and redirect to product page
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks></remarks>
		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
			Try

				If Page.IsValid Then
					Update()

					'Dim MC As New DotNetNuke.Entities.Modules.ModuleController

					'Dim tempObject As Object

					'tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("PriceLayout_ALL")
					'If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.DropDownList) Then
					'	MC.UpdateModuleSetting(ModuleId, "PriceLayout_ALL", DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).SelectedValue)
					'End If

					'tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("XSell_ALL")
					'If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					'	MC.UpdateModuleSetting(ModuleId, "XSell_ALL", DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked)
					'End If

					'tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("UPSell_ALL")
					'If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					'	MC.UpdateModuleSetting(ModuleId, "UPSell_ALL", DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked)
					'End If

					'tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("DisplayRateCode_ALL")
					'If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
					'	MC.UpdateModuleSetting(ModuleId, "DisplayRateCode_ALL", DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked)
					'End If


					Response.Redirect(ReturnURL())
				End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' <summary>
		''' on cancel go back
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks></remarks>
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(ReturnURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' <summary>
		''' nothing inside ???
		''' </summary>
		''' <remarks></remarks>
		Private Sub UpdateUpAndCrossSell()
			Try
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private XSellall As Boolean = True
		Private UpSellall As Boolean = True
		Private DisplayRateCodeall As Boolean = True

		''' <summary>
		''' load inclusion list and set the aspx controls values
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks></remarks>
		Private Sub DataListCrossUpSellExlclusion_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles DataListCrossUpSellInclusion.ItemDataBound
			Try
				Dim tempObject As Object
				Dim tempItem As DictionaryEntry

				If e.Item.DataItem IsNot Nothing AndAlso TypeOf e.Item.DataItem Is DictionaryEntry Then
					tempItem = DirectCast(e.Item.DataItem, DictionaryEntry)
				End If


				If tempItem.Key IsNot Nothing Then

					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl("SubName")
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.Label) Then
						DirectCast(tempObject, System.Web.UI.WebControls.Label).ID = DirectCast(tempObject, System.Web.UI.WebControls.Label).ID + "_" + tempItem.Value.ToString
						DirectCast(tempObject, System.Web.UI.WebControls.Label).Text = CapitalizeWords(tempItem.Key.ToString)

					End If

					'XSell
					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl("XSell")
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
						DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).ID = "XSell" + "_" + tempItem.Value.ToString
						If PM IsNot Nothing AndAlso PM.CrossSellSubsystemInclusion IsNot Nothing AndAlso PM.CrossSellSubsystemInclusion.Contains(tempItem.Value.ToString) Then
							DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = True
							XSellall = XSellall And True
						Else
							XSellall = XSellall And False
						End If

					End If

					'UpSell
					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl("UPSell")
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
						DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).ID = "UPSell" + "_" + tempItem.Value.ToString
						If PM IsNot Nothing AndAlso PM.UpSellSubsystemInclusion IsNot Nothing AndAlso PM.UpSellSubsystemInclusion.Contains(tempItem.Value.ToString) Then
							DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = True
							UpSellall = UpSellall And True
						Else
							UpSellall = UpSellall And False
						End If
					End If

					'DisplayRateCode
					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl("DisplayRateCode")
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
						DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).ID = "DisplayRateCode" + "_" + tempItem.Value.ToString
						If PM IsNot Nothing AndAlso PM.DisplayRateCode IsNot Nothing AndAlso PM.DisplayRateCode.Contains(tempItem.Value.ToString) Then
							DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = True
							DisplayRateCodeall = DisplayRateCodeall And True
						Else
							DisplayRateCodeall = DisplayRateCodeall And False
						End If
					End If


					'Price Layout
					Dim PriceLayouts As Hashtable
					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl(C_PRICELAYOUT)
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.DropDownList) Then
						PriceLayouts = DNN.Modules.ProductDetail.SharedProductDetail.GetPriceLayoutList(Me.LocalResourceFile)
						DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).ID = C_PRICELAYOUT + "_" + tempItem.Value.ToString
						DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataSource = PriceLayouts
						DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataTextField = "key"
						DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataValueField = "value"
						DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).DataBind()
					End If
				End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Public MeetingALL As Boolean = True

		Private Sub DataListMeetingInclusion_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles DataListMeetingInclusion.ItemDataBound
			Try
				Dim tempObject As Object
				Dim tempItem As DictionaryEntry

				If e.Item.DataItem IsNot Nothing AndAlso TypeOf e.Item.DataItem Is DictionaryEntry Then
					tempItem = DirectCast(e.Item.DataItem, DictionaryEntry)
				End If


				If tempItem.Key IsNot Nothing Then

					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl("Description")
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.Label) Then
						DirectCast(tempObject, System.Web.UI.WebControls.Label).ID = DirectCast(tempObject, System.Web.UI.WebControls.Label).ID + "_" + tempItem.Value.ToString
						DirectCast(tempObject, System.Web.UI.WebControls.Label).Text = CapitalizeWords(tempItem.Key.ToString)

					End If

					'Meeting
					tempObject = CType(e.Item, System.Web.UI.WebControls.DataListItem).Controls(0).FindControl(C_Meeting)
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.CheckBox) Then
						DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).ID = C_Meeting + "_" + tempItem.Value.ToString
						If PM IsNot Nothing AndAlso PM.Meeting IsNot Nothing AndAlso PM.Meeting.MeetingInclusion.Contains(tempItem.Value.ToString) Then
							DirectCast(tempObject, System.Web.UI.WebControls.CheckBox).Checked = True
							MeetingALL = MeetingALL And True
						Else
							MeetingALL = MeetingALL And False
						End If
					End If


				End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub


		Private PriceLayoutall As Integer = 0
		''' <summary>
		''' 
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks></remarks>
		Private Sub DataListCrossUpSellInclusion_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataListCrossUpSellInclusion.PreRender
			Try
				Dim tempObject As Object
				Dim tempOuterObject As Object
				Dim tmpDropDownList As DropDownList
				Dim tmpDictionaryEntry As DictionaryEntry
				If Not IsPostBack Then
					For Each tempOuterObject In CType(sender, DataList).Controls
						For Each tempObject In CType(tempOuterObject, DataListItem).Controls
							If tempObject.GetType Is GetType(DropDownList) Then
								tmpDropDownList = CType(tempObject, DropDownList)
								If PM IsNot Nothing AndAlso PM.PriceLayout IsNot Nothing Then	' IsNot Nothing AndAlso PM.PriceLayout.Item(PM.PriceLayoutSettingsKey + "_" + tempItem.Value.ToString) IsNot Nothing Then
									For Each tmpDictionaryEntry In PM.PriceLayout
										'DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).SelectedIndex = DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).Items.IndexOf(DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).Items.FindByText(PM.PriceLayout.Item(PM.PriceLayoutSettingsKey + "_" + tempItem.Value.ToString)))
										Dim tmpLI As ListItem
										If tmpDictionaryEntry.Key.ToString.Substring(tmpDictionaryEntry.Key.ToString.IndexOf("_") + 1, tmpDictionaryEntry.Key.ToString.Length - 1 - tmpDictionaryEntry.Key.ToString.IndexOf("_")).ToLower = tmpDropDownList.ID.Substring(tmpDropDownList.ID.IndexOf("_") + 1, tmpDropDownList.ID.Length - 1 - tmpDropDownList.ID.IndexOf("_")).ToLower Then
											For Each tmpLI In tmpDropDownList.Items
												tmpLI.Selected = False
												If tmpLI.Value = tmpDictionaryEntry.Value.ToString Then
													tmpLI.Selected = True
													If tmpDropDownList.SelectedIndex > PriceLayoutall Then PriceLayoutall = tmpDropDownList.SelectedIndex
												End If
											Next
										End If
									Next
								End If
							End If
						Next
					Next
				End If

				If Not IsPostBack Then
					tempObject = DataListCrossUpSellInclusion.Controls(0).FindControl("PriceLayout_ALL")
					If Not tempObject Is Nothing AndAlso tempObject.GetType Is GetType(System.Web.UI.WebControls.DropDownList) Then
						DirectCast(tempObject, System.Web.UI.WebControls.DropDownList).SelectedIndex = PriceLayoutall
						'tempObject.Attributes.Add("onClick", "javascript: selectall(this, 'PriceLayout_');")
					End If
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

        Private Sub CheckBoxBasePD_DisplayProductComponents_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBoxBasePD_DisplayProductComponents.CheckedChanged
            Try
                If CheckBoxBasePD_DisplayProductComponents.Checked Then
                    pnlProductComponents.Visible = True
                Else
                    pnlProductComponents.Visible = False
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "helper functions"

        Private Sub LoadFundRaisingSetting()
            If Settings("FUNDRaisingAllowCustomPrice") IsNot Nothing Then
                Me.chkCustomPrice.Checked = CType(Settings("FUNDRaisingAllowCustomPrice"), Boolean)
            End If
        End Sub

        Private Sub UpdateFundRaisingSetting()
            Dim objModules As New Entities.Modules.ModuleController
            objModules.UpdateModuleSetting(Me.ModuleId, "FUNDRaisingAllowCustomPrice", Me.chkCustomPrice.Checked)
        End Sub

#End Region
        Private Sub cmdUpdate_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Load

        End Sub

    End Class
End Namespace
