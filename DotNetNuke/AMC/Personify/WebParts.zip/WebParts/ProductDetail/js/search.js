function hideID(id) {
      //safe function to hide an element with a specified id
      if (document.getElementById) { // DOM3 = IE5, NS6
            document.getElementById(id).style.display = 'none';
      }
      else {
            if (document.layers) { // Netscape 4
                  document.id.display = 'none';
            }
            else { // IE 4
                  document.all.id.style.display = 'none';
            }
      }
}
 
function showID(id) {
      //safe function to show an element with a specified id
              
      if (document.getElementById) { // DOM3 = IE5, NS6
            document.getElementById(id).style.display = 'inline';
      }
      else {
            if (document.layers) { // Netscape 4
                  document.id.display = 'inline';
            }
            else { // IE 4
                  document.all.id.style.display = 'inline';
            }
      }
}
 
function ShowSearch(x, v, startindex, stopindex) {
      for(i=startindex;i<=stopindex;i++) hideID(v+""+i);
      showID(v+""+x);
}
 
function check(theElement,txtQty) {

   if  (typeof getElementByPartialIdDetail(txtQty)!='undefined') 
   {  
      if (theElement.checked) 
        getElementByPartialIdDetail(txtQty).value=1;
      else 
        getElementByPartialIdDetail(txtQty).value=0;
    
   }
    
    
    if (theElement.checked)
    {
        index1= theElement.name.indexOf("SubProductCheckBox");
shortname=theElement.name.substring(index1);
        hidden = document.getElementById("Hidden"+theElement.name.substring(index1));
     
	 if (hidden != null)
	 {
        index1=hidden.value.indexOf(";");
 
        startDate = hidden.value.substring(0, index1-1);
        arrStartDate=startDate.split("T");
        dateStartDate = arrStartDate[0].split("-");
        timeStartDate = arrStartDate[1].split(":");
        sDate = new Date(dateStartDate[0], dateStartDate[1]-1, dateStartDate[2], timeStartDate[0], timeStartDate[1], timeStartDate[2]);
 
        endDate = hidden.value.substring(index1+1);
        arrEndDate=endDate.split("T");
        dateEndDate = arrEndDate[0].split("-");
        timeEndDate = arrEndDate[1].split(":");
        eDate = new Date(dateEndDate[0], dateEndDate[1]-1, dateEndDate[2], timeEndDate[0], timeEndDate[1], timeEndDate[2]);
  
        z=0;
        theForm = theElement.form;
        conflict=false;
        while (z != theForm.length)
        {
            if(theForm[z].type == 'hidden')
            { 
                if (theForm[z].name.indexOf('HiddenSubProductCheckBox') >= 0)
                {
                    if (!(theForm[z].name.indexOf(shortname)>=0 )) 
                    {
						//is this session checked? if not is no conflict!
						index1= theElement.id.indexOf("SubProductCheckBox");
						name2=theElement.id.substring(0,index1);
						name2 = theForm[z].id.replace("HiddenSubProductCheckBox", name2+"SubProductCheckBox");
						element2 = document.getElementById(name2);
     
                        if (element2!=null) {
						if  (element2.checked==true)
						{
						    index1=theForm[z].value.indexOf(";");
 
		                    startDateTemp = theForm[z].value.substring(0, index1-1);
				            arrStartDateTemp=startDateTemp.split("T");
						    dateStartDateTemp = arrStartDateTemp[0].split("-");
		                    timeStartDateTemp = arrStartDateTemp[1].split(":");
				            sDateTemp = new Date(dateStartDateTemp[0], dateStartDateTemp[1]-1, dateStartDateTemp[2], timeStartDateTemp[0], timeStartDateTemp[1], timeStartDateTemp[2]);
 
						    endDateTemp = theForm[z].value.substring(index1+1);
		                    arrEndDateTemp=endDateTemp.split("T");
				            dateEndDateTemp = arrEndDateTemp[0].split("-");
						    timeEndDateTemp = arrEndDateTemp[1].split(":");
		                    eDateTemp = new Date(dateEndDateTemp[0], dateEndDateTemp[1]-1, dateEndDateTemp[2], timeEndDateTemp[0], timeEndDateTemp[1], timeEndDateTemp[2]);
 
							if (sDate<= eDateTemp) if (eDate> sDateTemp) { conflict = true; }
		                    if (sDateTemp<= eDate) if (eDateTemp> sDate) { conflict = true; }      
						}}
                }}
            }
            z++;
        }
 
        if (conflict)
        {
            alert("A session has already been selected for the same Date and time please select a different session.");
            theElement.checked = false;
        }
 	 }

    }
}
 
function SelectOnQtyEdit(txtQty,chkSelect,MaxValue){
            
       

            if ((txtQty.value==0) && !(getElementByPartialIdDetail(chkSelect).disabled))
               {
              
					getElementByPartialIdDetail(chkSelect).checked=false;
				}
			else
			    {
			     /// alert('2');
			    if (txtQty.value<=MaxValue)
			        {
			      
			        getElementByPartialIdDetail(chkSelect).checked=true;
			         
			        }
			     else
			        {
			        getElementByPartialIdDetail(chkSelect).checked=false;
			        }
			    }
					//alert(getElementByPartialIdDetail(chkSelect).id);
					}


function getElementByPartialIdDetail(id) {

   
	if (document.forms[0].elements != null)
	     
		for (i=0; i<document.forms[0].elements.length-1;i++ )
		   
			if (document.forms[0].elements[i].name.indexOf(id)>0) 
			{
			  
			    //alert(document.forms[0].elements[i].name.indexOf('hidden'));
			    if  (document.forms[0].elements[i].type != 'hidden') 
			    {
			       // alert('found');
			        //alert(document.forms[0].elements[i].name);
				    return document.forms[0].elements[i];
				 }
			}
}