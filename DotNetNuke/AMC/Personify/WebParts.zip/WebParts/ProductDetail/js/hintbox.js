var horizontal_offset="9px" //horizontal offset of hint box from anchor link

/////No further editting needed

var vertical_offset="0" //horizontal offset of hint box from anchor link. No need to change.
var ie=document.all
var ns6=document.getElementById&&!document.all

function getposOffset(what, offsettype){
var totaloffset=(offsettype=="left")? what.offsetLeft : what.offsetTop;
var parentEl=what.offsetParent;
while (parentEl!=null){
totaloffset=(offsettype=="left")? totaloffset+parentEl.offsetLeft : totaloffset+parentEl.offsetTop;
parentEl=parentEl.offsetParent;
}
return totaloffset;
}

function iecompattest(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function clearbrowseredge(obj, whichedge){
var edgeoffset=(whichedge=="rightedge")? parseInt(horizontal_offset)*-1 : parseInt(vertical_offset)*-1
if (whichedge=="rightedge"){
var windowedge=ie && !window.opera? iecompattest().scrollLeft+iecompattest().clientWidth-30 : window.pageXOffset+window.innerWidth-40
dropmenuobj.contentmeasure=dropmenuobj.offsetWidth
if (windowedge-dropmenuobj.x < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure+obj.offsetWidth+parseInt(horizontal_offset)
}
else{
var windowedge=ie && !window.opera? iecompattest().scrollTop+iecompattest().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj.contentmeasure=dropmenuobj.offsetHeight
if (windowedge-dropmenuobj.y < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure-obj.offsetHeight
}
return edgeoffset
}

function showhint(divid, obj, e, tipwidth){
if ((ie||ns6) && document.getElementById("bubble_tooltip")){
dropmenuobj=document.getElementById("bubble_tooltip")
//dropmenuobj.innerHTML='<div class=\'bubble_top\'><span></span></div><div class=\'bubble_middle\'><span id=\'bubble_tooltip_content\'>'+menucontents+'</span></div><div class=\'bubble_bottom\'></div>';
//dropmenuobj.innerHTML=dropmenuobj.innerHTML.replace('_menucontents_',menucontents);

cont = document.getElementById("bubble_tooltip_content");
divcontent = document.getElementById(divid);
cont.innerHTML=divcontent.innerHTML

dropmenuobj.style.left=dropmenuobj.style.top=-500
if (tipwidth!=""){
dropmenuobj.widthobj=dropmenuobj.style
dropmenuobj.widthobj.width=tipwidth
}
dropmenuobj.x=getposOffset(obj, "left")
dropmenuobj.y=getposOffset(obj, "top")
dropmenuobj.style.left=dropmenuobj.x-clearbrowseredge(obj, "rightedge")+obj.offsetWidth+"px"
dropmenuobj.style.top=dropmenuobj.y-clearbrowseredge(obj, "bottomedge")+"px"
dropmenuobj.style.visibility="visible"
obj.onmouseout=hidetip
}
}

function hidetip(e){
dropmenuobj.style.visibility="hidden"
dropmenuobj.style.left="-500px"
}

function createbubble_tooltip(){
var divblock=document.createElement("div")
divblock.setAttribute("id", "hintbox")
document.body.appendChild(divblock)

hintb = document.getElementById("hintbox");
hintb.innerHTML = '<div id="bubble_tooltip"><TABLE border=0 cellpadding=0 cellspacing="0"><TR><TD class="bubble_top1" height="1%"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD><TD class="bubble_top2" height="1%"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD><TD class="bubble_top3" height="1%"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD></TR><TR><TD class="bubble_middle1"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD><TD class="bubble_middle2"><span id="bubble_tooltip_content"></span></TD><TD class="bubble_middle3"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD></TR><TR><TD class="bubble_bottom1"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD><TD class="bubble_bottom2"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD><TD class="bubble_bottom3"><img src="../../DefaultPersonifyImages/1x1.gif" height="1"></TD></TR></TABLE></div>';
}

if (window.addEventListener)
window.addEventListener("load", createbubble_tooltip, false)
else if (window.attachEvent)
window.attachEvent("onload", createbubble_tooltip)
else if (document.getElementById)
window.onload=createbubble_tooltip
