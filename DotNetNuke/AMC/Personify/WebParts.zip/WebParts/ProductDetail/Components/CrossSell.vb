Imports System.Web


Namespace Personify.DNN.Modules.ProductDetail

    Public Class CrossSell
        Inherits Sell


#Region "Fields"

        Private _ProductClassLink As String

        Private Const C_VISIBLESETTINGSKEY As String = "CS_VisibleSettingsKey"
        Private Const C_DISPLAYPRODUCTIMAGESETTINGSKEY As String = "CS_DisplayProductImageSettingsKey"
        Private Const C_NUMBEROFCOLUMNSSETTINGSKEY As String = "CS_NumberOfColumnsSettingsKey"
        Private Const C_REPEATDIRECTIONSETTINGSKEY As String = "CS_RepeatDirectionSettingsKey"
        Private Const C_MAXIMUNNUMBEROFPRODUCTSSETTINGSKEY As String = "CS_MaximunNumberOfProductsSettingsKey"
		Private Const C_DISPLAYADDTOCARTSETTINGSKEY As String = "CS_DisplayAddToCartSettingsKey"
		Private Const C_DISPLAYADDTOWISHLISTSETTINGSKEY As String = "CS_DisplayAddToWishListSettingsKey"
		Private Const C_DISPLAYBUYFORGROUPSETTINGSKEY As String = "CS_DisplayBuyForGroupSettingsKey"
        Private Const C_TRUNCATEDESCRIPTIONSETTINGSKEY As String = "CS_TruncateDescriptionSettingsKey"
        Private Const C_DEFAULTQUANTITYSETTINGSKEY As String = "CS_DefaultQuantitySettingsKey"
        Private Const C_LAYOUTTEMPLATESETTINGSKEY As String = "CS_LayoutTemplateSettingsKey"
        Private Const C_PRODUCTURLSETTINGSKEY As String = "CS_ProductURLSettingsKey"
        Private Const C_PRODUCTURLTYPESETTINGSKEY As String = "CS_ProductURLTypeSettingsKey"

        Private Const C_PRODUCTCLASSSETTINGSKEY As String = "CS_ProductClassSettingsKey"
        Private Const C_PRODUCTCLASSTYPESETTINGSKEY As String = "CS_ProductClassTypeSettingsKey"

#End Region


#Region "Constructors"

        ''' <summary>
        ''' constructor  + set settingskeys for UpSell object
        ''' </summary>
        ''' <param name="ModuleId"></param>
        ''' <remarks></remarks>
        Public Sub New(ByVal ModuleId As Integer)
            MyBase.New(ModuleId)
            SetKeys()
        End Sub

        ''' <summary>
        ''' default constructor - no ModuleID
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            MyBase.New()
            SetKeys()
        End Sub

#End Region


#Region "Private Sub/Functions"

        ''' <summary>
        ''' Set settings keys
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub SetKeys()
            VisibleSettingsKey = C_VISIBLESETTINGSKEY
            DisplayProductImageSettingsKey = C_DISPLAYPRODUCTIMAGESETTINGSKEY
            NumberOfColumnsSettingsKey = C_NUMBEROFCOLUMNSSETTINGSKEY
            RepeatDirectionSettingsKey = C_REPEATDIRECTIONSETTINGSKEY
            MaximunNumberOfProductsSettingsKey = C_MAXIMUNNUMBEROFPRODUCTSSETTINGSKEY
			DisplayAddToCartSettingsKey = C_DISPLAYADDTOCARTSETTINGSKEY
			DisplayAddToWishListSettingsKey = C_DISPLAYADDTOWISHLISTSETTINGSKEY
			DisplayBuyForGroupSettingsKey = C_DISPLAYBUYFORGROUPSETTINGSKEY
            TruncateDescriptionSettingsKey = C_TRUNCATEDESCRIPTIONSETTINGSKEY
            DefaultQuantitySettingsKey = C_DEFAULTQUANTITYSETTINGSKEY
            LayoutTemplateSettingsKey = C_LAYOUTTEMPLATESETTINGSKEY
            ProductURLSettingsKey = C_PRODUCTURLSETTINGSKEY
            ProductURLTypeSettingsKey = C_PRODUCTURLTYPESETTINGSKEY
            ProductClassSettingsKey = C_PRODUCTCLASSSETTINGSKEY
            ProductClassTypeSettingsKey = C_PRODUCTCLASSTYPESETTINGSKEY
        End Sub

#End Region


#Region "Properties"
        ''' <summary>
        ''' crosssell specific !! not saved
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProductClassLink() As String
            Get
                Return _ProductClassLink
            End Get
            Set(ByVal value As String)
                _ProductClassLink = value
            End Set
        End Property

#End Region


    End Class

End Namespace