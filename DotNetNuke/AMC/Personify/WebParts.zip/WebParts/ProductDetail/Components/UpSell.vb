Imports System.Web


Namespace Personify.DNN.Modules.ProductDetail

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Class UpSell
        Inherits Sell


#Region "Fields"

        Private Const C_VISIBLESETTINGSKEY As String = "US_VisibleSettingsKey"

        Private Const C_DISPLAYPRODUCTIMAGESETTINGSKEY As String = "US_DisplayProductImageSettingsKey"
        Private Const C_NUMBEROFCOLUMNSSETTINGSKEY As String = "US_NumberOfColumnsSettingsKey"
        Private Const C_REPEATDIRECTIONSETTINGSKEY As String = "US_RepeatDirectionSettingsKey"
        Private Const C_MAXIMUNNUMBEROFPRODUCTSSETTINGSKEY As String = "US_MaximunNumberOfProductsSettingsKey"
		Private Const C_DISPLAYADDTOCARTSETTINGSKEY As String = "US_DisplayAddToCartSettingsKey"
		Private Const C_DISPLAYADDTOWISHLISTSETTINGSKEY As String = "US_DisplayAddToWishListSettingsKey"
		Private Const C_DISPLAYBUYFORGROUPSETTINGSKEY As String = "US_DisplayBuyForGroupSettingsKey"

        Private Const C_TRUNCATEDESCRIPTIONSETTINGSKEY As String = "US_TruncateDescriptionSettingsKey"
        Private Const C_DEFAULTQUANTITYSETTINGSKEY As String = "US_DefaultQuantitySettingsKey"
        Private Const C_LAYOUTTEMPLATESETTINGSKEY As String = "US_LayoutTemplateSettingsKey"
        Private Const C_PRODUCTURLSETTINGSKEY As String = "US_ProductURLSettingsKey"
        Private Const C_PRODUCTURLTYPESETTINGSKEY As String = "US_ProductURLTypeSettingsKey"
        Private Const C_PRODUCTCLASSSETTINGSKEY As String = "US_ProductClassSettingsKey"
        Private Const C_PRODUCTCLASSTYPESETTINGSKEY As String = "US_ProductClassTypeSettingsKey"

#End Region


#Region "Constructors"

        ''' <summary>
        ''' constructor  + set settingskeys for UpSell object
        ''' </summary>
        ''' <param name="ModuleId"></param>
        ''' <remarks></remarks>
        Public Sub New(ByVal ModuleId As Integer)
            MyBase.New(ModuleId)
            SetKeys()
        End Sub

        ''' <summary>
        ''' default constructor - no ModuleID
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            MyBase.New()
            SetKeys()
        End Sub

#End Region



#Region "Private Sub/Functions"

        ''' <summary>
        ''' Set settings keys
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub SetKeys()
            VisibleSettingsKey = C_VISIBLESETTINGSKEY
            DisplayProductImageSettingsKey = C_DISPLAYPRODUCTIMAGESETTINGSKEY
            NumberOfColumnsSettingsKey = C_NUMBEROFCOLUMNSSETTINGSKEY
            RepeatDirectionSettingsKey = C_REPEATDIRECTIONSETTINGSKEY
            MaximunNumberOfProductsSettingsKey = C_MAXIMUNNUMBEROFPRODUCTSSETTINGSKEY
			DisplayAddToCartSettingsKey = C_DISPLAYADDTOCARTSETTINGSKEY
			DisplayAddToWishListSettingsKey = C_DISPLAYADDTOWISHLISTSETTINGSKEY
			DisplayBuyForGroupSettingsKey = C_DISPLAYBUYFORGROUPSETTINGSKEY
            TruncateDescriptionSettingsKey = C_TRUNCATEDESCRIPTIONSETTINGSKEY
            DefaultQuantitySettingsKey = C_DEFAULTQUANTITYSETTINGSKEY
            LayoutTemplateSettingsKey = C_LAYOUTTEMPLATESETTINGSKEY
            ProductURLSettingsKey = C_PRODUCTURLSETTINGSKEY
            ProductURLTypeSettingsKey = C_PRODUCTURLTYPESETTINGSKEY

            ProductClassSettingsKey = C_PRODUCTCLASSSETTINGSKEY
            ProductClassTypeSettingsKey = C_PRODUCTCLASSTYPESETTINGSKEY
        End Sub

#End Region



    End Class

End Namespace