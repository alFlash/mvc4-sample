Imports System.Web
Imports DotNetNuke.Entities.Modules.ModuleSettingsBase

Namespace Personify.DNN.Modules.ProductDetail


    Public Class Sell


#Region "Fields"

        Private _ModuleId As Integer
        Private _ModuleSettings As Hashtable

        Private _Visible As Boolean
        Private _DisplayProductImage As Boolean
        Private _NumberOfColumns As Integer
        Private _RepeatDirection As String
        Private _MaximunNumberOfProducts As Integer
        Private _DisplayAddToCart As Boolean
		Private _DisplayAddToWishList As Boolean
		Private _DisplayBuyForGroup As Boolean
        Private _TruncateDescription As Integer
        Private _DefaultQuantity As Integer
        Private _LayoutTemplate As String
        Private _ProductURL As String
        Private _ProductURLType As String

        Private _ProductClass As String
        Private _ProductClassType As String

        Private _ValidationIssues As Hashtable

        Private _VisibleSettingsKey As String
        Private _DisplayProductImageSettingsKey As String
        Private _NumberOfColumnsSettingsKey As String
        Private _RepeatDirectionSettingsKey As String
        Private _MaximunNumberOfProductsSettingsKey As String
        Private _DisplayAddToCartSettingsKey As String
		Private _DisplayAddToWishListSettingsKey As String
		Private _DisplayBuyForGroupSettingsKey As String
        Private _TruncateDescriptionSettingsKey As String
        Private _DefaultQuantitySettingsKey As String
        Private _LayoutTemplateSettingsKey As String
        Private _ProductURLSettingsKey As String
        Private _ProductURLTypeSettingsKey As String

        Private _ProductClassSettingsKey As String
        Private _ProductClassTypeSettingsKey As String

#End Region


#Region "Properties"

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal value As Integer)
                _ModuleId = value
            End Set
        End Property

        Public Property Visible() As Boolean
            Get
                Return _Visible
            End Get
            Set(ByVal value As Boolean)
                _Visible = value
            End Set
        End Property
        Public Property DisplayProductImage() As Boolean
            Get
                Return _DisplayProductImage
            End Get
            Set(ByVal value As Boolean)
                _DisplayProductImage = value
            End Set
        End Property
        Public Property NumberOfColumns() As Integer
            Get
                Return _NumberOfColumns
            End Get
            Set(ByVal value As Integer)
                _NumberOfColumns = value
            End Set
        End Property
        Public Property RepeatDirection() As String
            Get
                Return _RepeatDirection
            End Get
            Set(ByVal value As String)
                _RepeatDirection = value
            End Set
        End Property
        Public Property MaximumNumberOfProducts() As Integer
            Get
                Return _MaximunNumberOfProducts
            End Get
            Set(ByVal value As Integer)
                _MaximunNumberOfProducts = value
            End Set
        End Property
        Public Property DisplayAddToCart() As Boolean
            Get
                Return _DisplayAddToCart
            End Get
            Set(ByVal value As Boolean)
                _DisplayAddToCart = value
            End Set
        End Property
		Public Property DisplayAddToWishList() As Boolean
			Get
				Return _DisplayAddToWishList
			End Get
			Set(ByVal value As Boolean)
				_DisplayAddToWishList = value
			End Set
		End Property
		Public Property DisplayBuyForGroup() As Boolean
			Get
				Return _DisplayBuyForGroup
			End Get
			Set(ByVal value As Boolean)
				_DisplayBuyForGroup = value
			End Set
		End Property
		Public Property TruncateDescription() As Integer
			Get
				Return _TruncateDescription
			End Get
			Set(ByVal value As Integer)
				_TruncateDescription = value
			End Set
        End Property
        Public Property DefaultQuantity() As Integer
            Get
                Return _DefaultQuantity
            End Get
            Set(ByVal value As Integer)
                _DefaultQuantity = value
            End Set
        End Property
        Public Property LayoutTemplate() As String
            Get
                Return _LayoutTemplate
            End Get
            Set(ByVal value As String)
                _LayoutTemplate = value
            End Set
        End Property
        Public Property ProductURL() As String
            Get
                Return _ProductURL
            End Get
            Set(ByVal value As String)
                _ProductURL = value
            End Set
        End Property
        Public Property ProductURLType() As String
            Get
                Return _ProductURLType
            End Get
            Set(ByVal value As String)
                _ProductURLType = value
            End Set
        End Property

        Public Property ProductClass() As String
            Get
                Return _ProductClass
            End Get
            Set(ByVal value As String)
                _ProductClass = value
            End Set
        End Property
        Public Property ProductClassType() As String
            Get
                Return _ProductClassType
            End Get
            Set(ByVal value As String)
                _ProductClassType = value
            End Set
        End Property

        Public Property ValidationIssues() As Hashtable
            Get
                Return _ValidationIssues
            End Get
            Set(ByVal value As Hashtable)
                _ValidationIssues = value
            End Set
        End Property

        Public Property VisibleSettingsKey() As String
            Get
                Return _VisibleSettingsKey
            End Get
            Set(ByVal value As String)
                _VisibleSettingsKey = value
            End Set
        End Property
        Public Property DisplayProductImageSettingsKey() As String
            Get
                Return _DisplayProductImageSettingsKey
            End Get
            Set(ByVal value As String)
                _DisplayProductImageSettingsKey = value
            End Set
        End Property
        Public Property NumberOfColumnsSettingsKey() As String
            Get
                Return _NumberOfColumnsSettingsKey
            End Get
            Set(ByVal value As String)
                _NumberOfColumnsSettingsKey = value
            End Set
        End Property
        Public Property RepeatDirectionSettingsKey() As String
            Get
                Return _RepeatDirectionSettingsKey
            End Get
            Set(ByVal value As String)
                _RepeatDirectionSettingsKey = value
            End Set
        End Property
        Public Property MaximunNumberOfProductsSettingsKey() As String
            Get
                Return _MaximunNumberOfProductsSettingsKey
            End Get
            Set(ByVal value As String)
                _MaximunNumberOfProductsSettingsKey = value
            End Set
        End Property
        Public Property DisplayAddToCartSettingsKey() As String
            Get
                Return _DisplayAddToCartSettingsKey
            End Get
            Set(ByVal value As String)
                _DisplayAddToCartSettingsKey = value
            End Set
        End Property
		Public Property DisplayAddToWishListSettingsKey() As String
			Get
				Return _DisplayAddToWishListSettingsKey
			End Get
			Set(ByVal value As String)
				_DisplayAddToWishListSettingsKey = value
			End Set
		End Property
		Public Property DisplayBuyForGroupSettingsKey() As String
			Get
				Return _DisplayBuyForGroupSettingsKey
			End Get
			Set(ByVal value As String)
				_DisplayBuyForGroupSettingsKey = value
			End Set
		End Property
		Public Property TruncateDescriptionSettingsKey() As String
			Get
				Return _TruncateDescriptionSettingsKey
			End Get
			Set(ByVal value As String)
				_TruncateDescriptionSettingsKey = value
			End Set
        End Property
        Public Property DefaultQuantitySettingsKey() As String
            Get
                Return _DefaultQuantitySettingsKey
            End Get
            Set(ByVal value As String)
                _DefaultQuantitySettingsKey = value
            End Set
        End Property
        Public Property LayoutTemplateSettingsKey() As String
            Get
                Return _LayoutTemplateSettingsKey
            End Get
            Set(ByVal value As String)
                _LayoutTemplateSettingsKey = value
            End Set
        End Property
        Public Property ProductURLSettingsKey() As String
            Get
                Return _ProductURLSettingsKey
            End Get
            Set(ByVal value As String)
                _ProductURLSettingsKey = value
            End Set
        End Property
        Public Property ProductURLTypeSettingsKey() As String
            Get
                Return _ProductURLTypeSettingsKey
            End Get
            Set(ByVal value As String)
                _ProductURLTypeSettingsKey = value
            End Set
        End Property

        Public Property ProductClassSettingsKey() As String
            Get
                Return _ProductClassSettingsKey
            End Get
            Set(ByVal value As String)
                _ProductClassSettingsKey = value
            End Set
        End Property
        Public Property ProductClassTypeSettingsKey() As String
            Get
                Return _ProductClassTypeSettingsKey
            End Get
            Set(ByVal value As String)
                _ProductClassTypeSettingsKey = value
            End Set
        End Property

#End Region


#Region "Constructors"


        ''' <summary>
        ''' default constructor - default values
        ''' </summary>
        ''' <remarks></remarks>
        Sub New()

            Try
                InitializeFields()
            Catch ex As Exception

            End Try

        End Sub

        ''' <summary>
        ''' constructor + load settings from Hashtable
        ''' </summary>
        ''' <param name="Settings"></param>
        ''' <remarks></remarks>
        Sub New(ByVal Settings As Hashtable)
            Me.New()
            _ModuleSettings = Settings

        End Sub

        ''' <summary>
        ''' constructor + ModuleID ???
        ''' </summary>
        ''' <param name="ModuleId"></param>
        ''' <remarks></remarks>
        Sub New(ByVal ModuleId As Integer)
            Me.New()
            _ModuleId = ModuleId
        End Sub

        ''' <summary>
        ''' constructor + load settings from Hashtable + ModuleID ???
        ''' </summary>
        ''' <param name="ModuleId"></param>
        ''' <param name="Settings"></param>
        ''' <remarks></remarks>
        Sub New(ByVal ModuleId As Integer, ByVal Settings As Hashtable)
            Me.New()
            _ModuleId = ModuleId
            _ModuleSettings = Settings
        End Sub

#End Region


#Region "Public Sub/Functions"

        ''' <summary>
        ''' Save Settings
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Save() As Boolean
            Try
                SaveSettings()
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        ''' <summary>
        ''' nothing inside
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Validate() As Boolean

        End Function

        ''' <summary>
        ''' load settings from Hasstable ???
        ''' </summary>
        ''' <param name="Settings"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Load(ByVal Settings As Hashtable) As Boolean
            Try
                _ModuleSettings = Settings
                LoadSettings()
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        ''' <summary>
        ''' Load Settings
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Load() As Boolean
            Try
                LoadSettings()
            Catch ex As Exception
                Throw ex
            End Try
        End Function

#End Region


#Region "Protected Sub/Functions"

        ''' <summary>
        ''' new DotNetNuke.Entities.Modules.ModuleController
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Protected Function GetController() As DotNetNuke.Entities.Modules.ModuleController
            Try
                Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
                Return objMC
            Catch ex As Exception
                Throw ex
            End Try
            Return Nothing
        End Function

        ''' <summary>
        ''' load settings from DotNetNuke.Entities.Modules.ModuleController
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Protected Function GetModuleSettings() As Hashtable
            Try
                If _ModuleSettings IsNot Nothing Then
                    Return _ModuleSettings
                Else
                    If _ModuleId <> 0 Then
                        Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
                        Return objMC.GetModuleSettings(_ModuleId)
                    Else
                        Return Nothing
                    End If
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return Nothing
        End Function

#End Region


#Region "Private Sub/Functions"

        ''' <summary>
        ''' load settings from DotNetNuke.Entities.Modules.ModuleController into the object
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadSettings()
            Try
                Dim objMS As Hashtable
                objMS = GetModuleSettings()

                If objMS(_VisibleSettingsKey) IsNot Nothing Then
                    _Visible = CType(objMS(_VisibleSettingsKey), Boolean)
                End If
                If objMS(_DisplayProductImageSettingsKey) IsNot Nothing Then
                    _DisplayProductImage = CType(objMS(_DisplayProductImageSettingsKey), Boolean)
                End If
                If objMS(_NumberOfColumnsSettingsKey) IsNot Nothing Then
                    _NumberOfColumns = CType(objMS(_NumberOfColumnsSettingsKey), Integer)
                End If
                If objMS(_RepeatDirectionSettingsKey) IsNot Nothing Then
                    _RepeatDirection = CType(objMS(_RepeatDirectionSettingsKey), String)
                End If
                If objMS(_MaximunNumberOfProductsSettingsKey) IsNot Nothing Then
                    _MaximunNumberOfProducts = CType(objMS(_MaximunNumberOfProductsSettingsKey), Integer)
                End If
                If objMS(_DisplayAddToCartSettingsKey) IsNot Nothing Then
                    _DisplayAddToCart = CType(objMS(_DisplayAddToCartSettingsKey), Boolean)
                End If
				If objMS(_DisplayAddToWishListSettingsKey) IsNot Nothing Then
					_DisplayAddToWishList = CType(objMS(_DisplayAddToWishListSettingsKey), Boolean)
				End If
				If objMS(_DisplayBuyForGroupSettingsKey) IsNot Nothing Then
					_DisplayBuyForGroup = CType(objMS(_DisplayBuyForGroupSettingsKey), Boolean)
				End If
				If objMS(_TruncateDescriptionSettingsKey) IsNot Nothing Then
					_TruncateDescription = CType(objMS(_TruncateDescriptionSettingsKey), Integer)
                End If
                If objMS(_DefaultQuantitySettingsKey) IsNot Nothing Then
                    _DefaultQuantity = CType(objMS(_DefaultQuantitySettingsKey), Integer)              
                End If
                If objMS(_LayoutTemplateSettingsKey) IsNot Nothing Then
                    _LayoutTemplate = CType(objMS(_LayoutTemplateSettingsKey), String)
                End If

                If objMS(_ProductURLSettingsKey) IsNot Nothing Then
                    _ProductURL = CType(objMS(_ProductURLSettingsKey), String)
                End If
                If objMS(_ProductURLTypeSettingsKey) IsNot Nothing Then
                    _ProductURLType = CType(objMS(_ProductURLTypeSettingsKey), String)
                End If

                If objMS(_ProductClassSettingsKey) IsNot Nothing Then
                    _ProductClass = CType(objMS(_ProductClassSettingsKey), String)
                End If
                If objMS(_ProductURLTypeSettingsKey) IsNot Nothing Then
                    _ProductClassType = CType(objMS(_ProductClassTypeSettingsKey), String)
                End If

            Catch ex As Exception
                Throw ex
            End Try





        End Sub

        ''' <summary>
        ''' set settings to DotNetNuke.Entities.Modules.ModuleController
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub SaveSettings()
            Try

                Dim objMS As DotNetNuke.Entities.Modules.ModuleController
                objMS = GetController()

                objMS.UpdateModuleSetting(_ModuleId, _VisibleSettingsKey, CType(_Visible, String))
                objMS.UpdateModuleSetting(_ModuleId, _DisplayProductImageSettingsKey, CType(_DisplayProductImage, String))
                objMS.UpdateModuleSetting(_ModuleId, _NumberOfColumnsSettingsKey, CType(_NumberOfColumns, String))
                objMS.UpdateModuleSetting(_ModuleId, _RepeatDirectionSettingsKey, CType(_RepeatDirection, String))
                objMS.UpdateModuleSetting(_ModuleId, _MaximunNumberOfProductsSettingsKey, CType(_MaximunNumberOfProducts, String))
                objMS.UpdateModuleSetting(_ModuleId, _DisplayAddToCartSettingsKey, CType(_DisplayAddToCart, String))
				objMS.UpdateModuleSetting(_ModuleId, _DisplayAddToWishListSettingsKey, CType(_DisplayAddToWishList, String))
				objMS.UpdateModuleSetting(_ModuleId, _DisplayBuyForGroupSettingsKey, CType(_DisplayBuyForGroup, String))
                objMS.UpdateModuleSetting(_ModuleId, _TruncateDescriptionSettingsKey, CType(_TruncateDescription, String))
                objMS.UpdateModuleSetting(_ModuleId, _DefaultQuantitySettingsKey, CType(_DefaultQuantity, String))
                objMS.UpdateModuleSetting(_ModuleId, _LayoutTemplateSettingsKey, CType(_LayoutTemplate, String))

                objMS.UpdateModuleSetting(_ModuleId, _ProductURLSettingsKey, CType(_ProductURL, String))
                objMS.UpdateModuleSetting(_ModuleId, _ProductURLTypeSettingsKey, CType(_ProductURLType, String))
				If _ProductClass IsNot Nothing Then
					objMS.UpdateModuleSetting(_ModuleId, _ProductClassSettingsKey, CType(_ProductClass, String))
					objMS.UpdateModuleSetting(_ModuleId, _ProductClassTypeSettingsKey, CType(_ProductClassType, String))
				End If


			Catch ex As Exception
				Throw ex
			End Try

        End Sub

        ''' <summary>
        ''' set default values
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub InitializeFields()

            _ModuleId = Nothing
            _ModuleSettings = Nothing

            _Visible = False
            _DisplayProductImage = False
            _NumberOfColumns = 1
            _RepeatDirection = String.Empty
            _MaximunNumberOfProducts = 1
            _DisplayAddToCart = False
			_DisplayAddToWishList = False
			_DisplayBuyForGroup = False
            _TruncateDescription = 0
            _DefaultQuantity = 1
            _LayoutTemplate = String.Empty
            _ProductURL = String.Empty
            _ProductURLType = String.Empty

            _ValidationIssues = Nothing

            _VisibleSettingsKey = String.Empty
            _DisplayProductImageSettingsKey = String.Empty
            _NumberOfColumnsSettingsKey = String.Empty
            _RepeatDirectionSettingsKey = String.Empty
            _MaximunNumberOfProductsSettingsKey = String.Empty
            _DisplayAddToCartSettingsKey = String.Empty
			_DisplayAddToWishListSettingsKey = String.Empty
			_DisplayBuyForGroupSettingsKey = String.Empty
            _TruncateDescriptionSettingsKey = String.Empty
            _DefaultQuantitySettingsKey = String.Empty
            _LayoutTemplateSettingsKey = String.Empty

            _ProductURLSettingsKey = String.Empty
            _ProductURLTypeSettingsKey = String.Empty

            _ProductClassSettingsKey = String.Empty
            _ProductClassTypeSettingsKey = String.Empty

        End Sub

#End Region


    End Class
End Namespace