Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports DotNetNuke
Imports System.Collections.Specialized


Namespace Personify.DNN.Modules.ProductDetail


    Public Class ProductDetailModel


#Region " Fields "

        Private _ModuleId As Integer

        'section 1
        Private _Settings As ProductDetailSettings

        'section 2
        Private _UpSellSubsystemInclusion As ArrayList
        Private _CrossSellSubsystemInclusion As ArrayList
        Private _PriceLayout As StringDictionary
        Private _DisplayRateCode As ArrayList
        Private Const C_UPSELLINCLUSIONSETTINGSKEY As String = "UpSellInclusionSettingsKey"
        Private Const C_XSELLINCLUSIONSETTINGSKEY As String = "XSellInclusionSettingsKey"
        Private Const C_PRICELAYTOUSETTINGSKEY As String = "PriceLayoutSettingsKey"
		Private Const C_DISPLAYRATECODESETTINGSKEY As String = "DisplayRateCodeSettingsKey"
		Private Const C_MEETINGINCLUSIONSETTINGSKEY As String = "MeetingInclusionSettingsKey"

        'section 3
        Private _UpSell As UpSell

        'section 4
		Private _CrossSell As CrossSell

		'section 5

		Private _Meeting As Meeting


#End Region


#Region " Constructors "

        ''' <summary>
        ''' ProductDetailModel constructor
        ''' </summary>
        ''' <param name="ModuleId"></param>
        ''' <remarks></remarks>
        Public Sub New(ByVal ModuleId As Integer)
            _ModuleId = ModuleId

            _Settings = New ProductDetailSettings(ModuleId)

            _UpSellSubsystemInclusion = New ArrayList
            _CrossSellSubsystemInclusion = New ArrayList
            _PriceLayout = New StringDictionary
            'not _DisplayRateCode ???

            _UpSell = New UpSell(ModuleId)

			_CrossSell = New CrossSell(ModuleId)

			_Meeting = New Meeting(ModuleId)


        End Sub
#End Region


#Region " Properties "


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DisplayRateCode() As ArrayList
            Get
                Return _DisplayRateCode
            End Get
            Set(ByVal value As ArrayList)
                _DisplayRateCode = value
            End Set
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property PriceLayoutSettingsKey() As String
            Get
                Return C_PRICELAYTOUSETTINGSKEY
            End Get
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PriceLayout() As StringDictionary
            Get
                Return _PriceLayout
            End Get
            Set(ByVal value As StringDictionary)
                _PriceLayout = value
            End Set
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal value As Integer)
                _ModuleId = value
            End Set
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Settings() As ProductDetailSettings
            Get
                Return _Settings
            End Get
            Set(ByVal value As ProductDetailSettings)
                _Settings = value
            End Set
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property UpSell() As UpSell
            Get
                Return _UpSell
            End Get
            Set(ByVal value As UpSell)
                _UpSell = value
            End Set
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CrossSell() As CrossSell
            Get
                Return _CrossSell
            End Get
            Set(ByVal value As CrossSell)
                _CrossSell = value
            End Set
        End Property

		Public Property Meeting() As Meeting
			Get
				Return _Meeting
			End Get
			Set(ByVal value As Meeting)
				_Meeting = value
			End Set
		End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CrossSellSubsystemInclusion() As ArrayList
            Get
                Return _CrossSellSubsystemInclusion
            End Get
            Set(ByVal value As ArrayList)
                _CrossSellSubsystemInclusion = value
            End Set
        End Property


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property UpSellSubsystemInclusion() As ArrayList
            Get
                Return _UpSellSubsystemInclusion
            End Get
            Set(ByVal value As ArrayList)
                _UpSellSubsystemInclusion = value
            End Set
        End Property



#End Region


#Region " Public Sub/Functions "


		''' <summary>
		''' 
		''' </summary>
		''' <param name="SetKey"></param>
		''' <returns></returns>
		''' <remarks></remarks>
        Public Function GetSubsystemFromSettingKey(ByVal SetKey As String) As String
            Try
                Dim i As Integer = SetKey.IndexOf("_")
                If i <> -1 Then
                    Return SetKey.Substring(i + 1, SetKey.Length - i - 1)
                End If
            Catch ex As Exception

            End Try
            Return Nothing
        End Function


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Load() As Boolean

            Dim MS As Hashtable
            Dim objMS As New DotNetNuke.Entities.Modules.ModuleController
            Dim SettingsKey As String
            '1
            _Settings.Load()

            '2
            _UpSellSubsystemInclusion = New ArrayList
            _CrossSellSubsystemInclusion = New ArrayList
            _DisplayRateCode = New ArrayList
            _PriceLayout = New StringDictionary

            If _ModuleId <> -1 Then
                MS = objMS.GetModuleSettings(_ModuleId)

                For Each SettingsKey In MS.Keys
                    If SettingsKey.IndexOf(C_UPSELLINCLUSIONSETTINGSKEY) <> -1 Then
                        _UpSellSubsystemInclusion.Add(MS(SettingsKey).ToString)
                    ElseIf SettingsKey.IndexOf(C_XSELLINCLUSIONSETTINGSKEY) <> -1 Then
                        _CrossSellSubsystemInclusion.Add(MS(SettingsKey).ToString)
                    ElseIf SettingsKey.IndexOf(C_PRICELAYTOUSETTINGSKEY) <> -1 Then
                        _PriceLayout.Add(SettingsKey, MS(SettingsKey).ToString.Trim)
                    ElseIf SettingsKey.IndexOf(C_DISPLAYRATECODESETTINGSKEY) <> -1 Then
                        _DisplayRateCode.Add(MS(SettingsKey).ToString)
                    End If


                Next
            End If

            '5
            _Meeting.Load()


        End Function


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Save() As Boolean
            Try
                '1
                If _Settings IsNot Nothing Then
                    _Settings.Save()
                End If
			Catch ex As Exception
				Throw ex
			End Try

			Try
				'2
				SaveUpXSellInclusion()
				SaveDisplayRateCode()
				SavePriceLayoutList()
			Catch ex As Exception
				Throw ex
			End Try

			Try

				'3
				If _CrossSell IsNot Nothing Then
					_CrossSell.Save()
				End If
			Catch ex As Exception
				Throw ex
			End Try

			Try

				'4
				If _UpSell IsNot Nothing Then
					_UpSell.Save()
				End If
			Catch ex As Exception
				Throw ex
			End Try

			Try
				'5
				If _Meeting IsNot Nothing Then
					_Meeting.Save()
				End If

			Catch ex As Exception
				Throw ex
			End Try
        End Function


        ''' <summary>
        ''' nothing inside
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Validate() As Boolean

        End Function


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="subsystem"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetSubsystemPriceLayout(ByVal subsystem As String) As String
            Try
                Dim dictionaryKey As String
                If _PriceLayout IsNot Nothing Then
                    For Each dictionaryKey In _PriceLayout.Keys
                        If dictionaryKey.Substring(dictionaryKey.Length - 3, 3).ToLower = subsystem.ToLower Then
                            Return _PriceLayout(dictionaryKey)
                        End If
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return String.Empty
        End Function


        Public Function GetALLSubsystemPriceLayout() As SubSystem_PricingOption()
            Try
                Dim dictionaryKey As String
                If _PriceLayout IsNot Nothing Then
                    Dim SubSystemPricingOption(_PriceLayout.Keys.Count - 1) As SubSystem_PricingOption
                    Dim i As Integer = 0
                    For Each dictionaryKey In _PriceLayout.Keys
                        SubSystemPricingOption(i) = New SubSystem_PricingOption
                        SubSystemPricingOption(i).Subsystem = dictionaryKey.Substring(dictionaryKey.Length - 3, 3).ToLower
                        SubSystemPricingOption(i).PricingOption = PricingOptions.DefaultPricing
                        If _PriceLayout(dictionaryKey) <> "DefaultPricing" Then
                            SubSystemPricingOption(i).PricingOption = PricingOptions.MultiplePricing
                        End If
                        i = i + 1
                    Next
                    Return SubSystemPricingOption
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return Nothing
        End Function


#End Region


#Region " Private Sub/Functions "

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub SaveUpXSellInclusion()
            Try
                Dim temSub As String
                Dim objMS As DotNetNuke.Entities.Modules.ModuleController
                objMS = GetController()

                Dim tmpHT As Hashtable
                Dim tmpKey As String
                tmpHT = objMS.GetModuleSettings(ModuleId)
                Dim keysToBeRemoved As New ArrayList

                For Each tmpKey In tmpHT.Keys
                    If tmpKey.IndexOf(C_UPSELLINCLUSIONSETTINGSKEY) <> -1 Or tmpKey.IndexOf(C_XSELLINCLUSIONSETTINGSKEY) <> -1 Then
                        keysToBeRemoved.Add(tmpKey)
                    End If
                Next

                For Each tmpKey In keysToBeRemoved
                    objMS.DeleteModuleSetting(_ModuleId, tmpKey)
                Next

                For Each temSub In _UpSellSubsystemInclusion
                    objMS.UpdateModuleSetting(_ModuleId, C_UPSELLINCLUSIONSETTINGSKEY + "_" + temSub, temSub)
                Next

                For Each temSub In _CrossSellSubsystemInclusion
                    objMS.UpdateModuleSetting(_ModuleId, C_XSELLINCLUSIONSETTINGSKEY + "_" + temSub, temSub)
                Next


            Catch ex As Exception
                Throw ex
            End Try
        End Sub


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub SaveDisplayRateCode()
            Try
                Dim temSub As String
                Dim objMS As DotNetNuke.Entities.Modules.ModuleController
                objMS = GetController()

                Dim tmpHT As Hashtable
                Dim tmpKey As String
                tmpHT = objMS.GetModuleSettings(ModuleId)
                Dim keysToBeRemoved As New ArrayList

                For Each tmpKey In tmpHT.Keys
                    If tmpKey.IndexOf(C_DISPLAYRATECODESETTINGSKEY) <> -1 Then
                        keysToBeRemoved.Add(tmpKey)
                    End If
                Next

                For Each tmpKey In keysToBeRemoved
                    objMS.DeleteModuleSetting(_ModuleId, tmpKey)
                Next

                For Each temSub In _DisplayRateCode
                    objMS.UpdateModuleSetting(_ModuleId, C_DISPLAYRATECODESETTINGSKEY + "_" + temSub, temSub)
                Next



            Catch ex As Exception
                Throw ex
            End Try
        End Sub


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub SavePriceLayoutList()
            Try
                Dim temSub As String
                Dim objMS As DotNetNuke.Entities.Modules.ModuleController
                objMS = GetController()

                For Each temSub In _PriceLayout.Keys
                    objMS.UpdateModuleSetting(_ModuleId, C_PRICELAYTOUSETTINGSKEY + "_" + temSub, _PriceLayout.Item(temSub).Trim)
                Next

            Catch ex As Exception
                Throw ex
            End Try
        End Sub


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetController() As DotNetNuke.Entities.Modules.ModuleController
            Try
                Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
                Return objMC
            Catch ex As Exception
                Throw ex
            End Try
            Return Nothing
        End Function


#End Region


    End Class
End Namespace