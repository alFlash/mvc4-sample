Imports System.Web
Imports DotNetNuke
Imports DotNetNuke.Services

Namespace Personify.DNN.Modules.ProductDetail


    Public Class ProductDetailSettings


#Region " Fields "

        Private _ModuleId As Integer
        Private _ModuleSettings As Hashtable

		'parameters to be saved
        Private _DisplayProductImage As Boolean
        Private _ProductIdParameters As String
        Private _TruncateDescription As Integer
        Private _DefaultQuantity As Integer
        Private _DisplayProductComponents As Boolean
        Private _TruncateComponentsDescription As Integer
        Private _ShowComponentsImages As Boolean
        Private _LayoutTemplate As String
        Private _LayoutDCDTemplate As String
		Private _LayoutPackageTemplate As String
		Private _LayoutMeetingTemplate As String
        Private _Searchable As Boolean
        Private _DisplayDownloadTerm As Boolean

        'where parameters to be saved
        Private _DisplayProductImageSettingsKey As String
        Private _ProductIdParametersSettingsKey As String
        Private _LayoutTemplateSettingsKey As String
        Private _LayoutDCDTemplateSettingsKey As String
		Private _LayoutPackageTemplateSettingsKey As String
		Private _LayoutMeetingTemplateSettingsKey As String
        Private _TruncateDescriptionSettingsKey As String
        Private _DefaultQuantitySettingsKey As String
        Private _DisplayProductComponentsSettingsKey As String
        Private _TruncateComponentsDescriptionSettingsKey As String
        Private _ShowComponentsImagesSettingsKey As String
        Private _SearchableSettingsKey As String
        Private _DisplayDownloadTermSettingsKey As String
        Private _ShowAddtoCartKey As String
        Private _ShowWishListKey As String
        Private _ShowUpdateOrderKey As String
        Private _ShowBuyForGroupKey As String


        Private _ProductID As Integer
        Private _ShowButtons As Boolean
        Private _ShowAddtoCart As Boolean
        Private _ShowWishList As Boolean
        Private _ShowUpdateOrder As Boolean
        Private _ShowBuyForGroup As Boolean


        Private Const C_DISPLAYPRODUCTIMAGESETTINGSKEY As String = "PD_DisplayProductImageSettingsKey"
        Private Const C_PRODUCTIDPARAMETERSSETTINGSKEY As String = "PD_ProductIdParametersSettingsKey"
        Private Const C_TRUNCATEDESCRIPTIONSETTINGSKEY As String = "PD_TruncateDescriptionSettingsKey"
        Private Const C_DEFAULTQUANTITYSETTINGSKEY As String = "PD_DefaultQuantitySettingsKey"
        Private Const C_DISPLAYPRODUCTCOMPONENTSSETTINGSKEY As String = "PD_DisplayProductComponentsSettingsKey"
        Private Const C_TRUNCATECOMPONENTSDESCRIPTIONSETTINGSKEY As String = "PD_TruncateComponentsDescriptionSettingsKey"
        Private Const C_SHOWCOMPONENTSIMAGESSETTINGSKEY As String = "PD_ShowComponentsImagesSettingsKey"
        Private Const C_LAYOUTTEMPLATESETTINGSKEY As String = "PD_LayoutTemplateSettingsKey"
        Private Const C_LAYOUTDCDTEMPLATESETTINGSKEY As String = "PD_LayoutDCDTemplateSettingsKey"
		Private Const C_LAYOUTPACKAGETEMPLATESETTINGSKEY As String = "PD_LayoutPackageTemplateSettingsKey"
		Private Const C_LAYOUTMEETINGTEMPLATESETTINGSKEY As String = "PD_LayoutMeetingTemplateSettingsKey"
        Private Const C_SEARCHABLESETTINGSKEY As String = "Searchable"
        Private Const C_DISPLAYDOWNLOADTERMSETTINGSKEY As String = "DisplayDownloadTerm"

		Private Const C_BUYFORGROUPURLSETTINGSKEY As String = "PD_BUYFORGROUPURLSettingsKey"
		Private Const C_BUYFORGROUPURLTYPESETTINGSKEY As String = "PD_BUYFORGROUPURLTypeSettingsKey"

        Private Const C_PRODUCTID As String = "PD_ProductId"
        Private Const C_SHOWBUTTONS As String = "PD_ShowButtons"
        Private Const C_SHOWADDTOCART As String = "PD_SHOWADDTOCART"
        Private Const C_SHOWWISHLIST As String = "PD_SHOWWISHLIST"
        Private Const C_SHOWUPDATEORDER As String = "PD_SHOWUPDATEORDER"
        Private Const C_SHOWBUYFORGROUP As String = "PD_SHOWBUYFORGROUP"

		Private _BuyForGroupURL As String
		Private _BuyForGroupURLLType As String


		Private _BuyForGroupURLSettingsKey As String
        Private _BuyForGroupURLLTypeSettingsKey As String

        Private _ProductIDKey As String
        Private _ShowButtonsKey As String

#End Region


#Region " Constructors "

        ''' <summary>
        ''' default constructor
        ''' </summary>
        ''' <param name="ModuleId"></param>
        ''' <remarks></remarks>
        Sub New(ByVal ModuleId As Integer)
            _ModuleId = ModuleId
            _DisplayProductImageSettingsKey = C_DISPLAYPRODUCTIMAGESETTINGSKEY
            _ProductIdParametersSettingsKey = C_PRODUCTIDPARAMETERSSETTINGSKEY
            _TruncateDescriptionSettingsKey = C_TRUNCATEDESCRIPTIONSETTINGSKEY
            _DefaultQuantitySettingsKey = C_DEFAULTQUANTITYSETTINGSKEY
            _DisplayProductComponentsSettingsKey = C_DISPLAYPRODUCTCOMPONENTSSETTINGSKEY
            _TruncateComponentsDescriptionSettingsKey = C_TRUNCATECOMPONENTSDESCRIPTIONSETTINGSKEY
            _ShowComponentsImagesSettingsKey = C_SHOWCOMPONENTSIMAGESSETTINGSKEY
            _LayoutTemplateSettingsKey = C_LAYOUTTEMPLATESETTINGSKEY
            _LayoutDCDTemplateSettingsKey = C_LAYOUTDCDTEMPLATESETTINGSKEY
			_LayoutPackageTemplateSettingsKey = C_LAYOUTPACKAGETEMPLATESETTINGSKEY
			_LayoutMeetingTemplateSettingsKey = C_LAYOUTMEETINGTEMPLATESETTINGSKEY

			_BuyForGroupURLSettingsKey = C_BUYFORGROUPURLSETTINGSKEY
			_BuyForGroupURLLTypeSettingsKey = C_BUYFORGROUPURLTYPESETTINGSKEY
            _SearchableSettingsKey = C_SEARCHABLESETTINGSKEY
            _DisplayDownloadTermSettingsKey = C_DISPLAYDOWNLOADTERMSETTINGSKEY

            _ProductIDKey = C_PRODUCTID
            ' _ShowButtonsKey = C_SHOWBUTTONS

            '  C_SHOWADDTOCART
            '  C_SHOWWISHLIST
            '  C_SHOWBUYFORGROUP

		End Sub

#End Region


#Region " Properties "

        Public Property ShowAddtoCartKey() As String
            Get
                Return _ShowAddtoCartKey
            End Get
            Set(ByVal value As String)
                _ShowAddtoCartKey = value
            End Set
        End Property


        Public Property ShowWishListKey() As String
            Get
                Return _ShowWishListKey
            End Get
            Set(ByVal value As String)
                _ShowWishListKey = value
            End Set
        End Property

        Public Property ShowUpdateOrderKey() As String
            Get
                Return _ShowUpdateOrderKey
            End Get
            Set(ByVal value As String)
                _ShowUpdateOrderKey = value
            End Set
        End Property


        Public Property ShowBuyForGroupKey() As String
            Get
                Return _ShowBuyForGroupKey
            End Get
            Set(ByVal value As String)
                _ShowBuyForGroupKey = value
            End Set
        End Property


		Public Property BuyForGroupURLTypeSettingsKey() As String
			Get
				Return _BuyForGroupURLLTypeSettingsKey
			End Get
			Set(ByVal value As String)
				_BuyForGroupURLLTypeSettingsKey = value
			End Set
		End Property

		Public Property BuyForGroupURL() As String
			Get
				Return _BUYFORGROUPURL
			End Get
			Set(ByVal value As String)
				_BuyForGroupURL = value
			End Set
		End Property
		Public Property BuyForGroupURLType() As String
			Get
				Return _BuyForGroupURLLType
			End Get
			Set(ByVal value As String)
				_BuyForGroupURLLType = value
			End Set
		End Property


        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal value As Integer)
                _ModuleId = value
            End Set
        End Property
        Public Property ModuleSettings() As Hashtable
            Get
                Return _ModuleSettings
            End Get
            Set(ByVal value As Hashtable)
                _ModuleSettings = value
            End Set
        End Property

        Public Property DisplayProductImageSettingsKey() As String
            Get
                Return _DisplayProductImageSettingsKey
            End Get
            Set(ByVal value As String)
                _DisplayProductImageSettingsKey = value
            End Set
        End Property
        Public Property ProductIdParametersSettingsKey() As String
            Get
                Return _ProductIdParametersSettingsKey
            End Get
            Set(ByVal value As String)
                _ProductIdParametersSettingsKey = value
            End Set
        End Property
        Public Property TruncateDescriptionSettingsKey() As String
            Get
                Return _TruncateDescriptionSettingsKey
            End Get
            Set(ByVal value As String)
                _TruncateDescriptionSettingsKey = value
            End Set
        End Property
        Public Property DefaultQuantitySettingsKey() As String
            Get
                Return _DefaultQuantitySettingsKey
            End Get
            Set(ByVal value As String)
                _DefaultQuantitySettingsKey = value
            End Set
        End Property
        Public Property LayoutTemplateSettingsKey() As String
            Get
                Return _LayoutTemplateSettingsKey
            End Get
            Set(ByVal value As String)
                _LayoutTemplateSettingsKey = value
            End Set
        End Property
        Public Property DisplayProductComponentsSettingsKey() As String
            Get
                Return _DisplayProductComponentsSettingsKey
            End Get
            Set(ByVal value As String)
                _DisplayProductComponentsSettingsKey = value
            End Set
        End Property
        Public Property TruncateComponentsDescriptionSettingsKey() As String
            Get
                Return _TruncateComponentsDescriptionSettingsKey
            End Get
            Set(ByVal value As String)
                _TruncateComponentsDescriptionSettingsKey = value
            End Set
        End Property
        Public Property ShowComponentsImagesSettingsKey() As String
            Get
                Return _ShowComponentsImagesSettingsKey
            End Get
            Set(ByVal value As String)
                _ShowComponentsImagesSettingsKey = value
            End Set
        End Property
        
        Public Property LayoutDCDTemplateSettingsKey() As String
            Get
                Return _LayoutDCDTemplateSettingsKey
            End Get
            Set(ByVal value As String)
                _LayoutDCDTemplateSettingsKey = value
            End Set
        End Property

        Public Property LayoutPackageTemplateSettingsKey() As String
            Get
                Return _LayoutPackageTemplateSettingsKey
            End Get
            Set(ByVal value As String)
                _LayoutPackageTemplateSettingsKey = value
            End Set
        End Property

		Public Property LayoutMeetingTemplateSettingsKey() As String
			Get
				Return _LayoutMeetingTemplateSettingsKey
			End Get
			Set(ByVal value As String)
				_LayoutMeetingTemplateSettingsKey = value
			End Set
		End Property


        Public Property DisplayProductImage() As Boolean
            Get
                Return _DisplayProductImage
            End Get
            Set(ByVal value As Boolean)
                _DisplayProductImage = value
            End Set
        End Property

		Public Property ProductIdParameters() As String
			Get
				Return _ProductIdParameters
			End Get
			Set(ByVal value As String)
				_ProductIdParameters = value
			End Set
		End Property
        Public Property TruncateDescription() As Integer
            Get
                Return _TruncateDescription
            End Get
            Set(ByVal value As Integer)
                _TruncateDescription = value
            End Set
        End Property
        Public Property DefaultQuantity() As Integer
            Get
                Return _DefaultQuantity
            End Get
            Set(ByVal value As Integer)
                _DefaultQuantity = value
            End Set
        End Property
        Public Property DisplayProductComponents() As Integer
            Get
                Return _DisplayProductComponents
            End Get
            Set(ByVal value As Integer)
                _DisplayProductComponents = value
            End Set
        End Property
        Public Property TruncateComponentsDescription() As Integer
            Get
                Return _TruncateComponentsDescription
            End Get
            Set(ByVal value As Integer)
                _TruncateComponentsDescription = value
            End Set
        End Property
        Public Property ShowComponentsImages() As Integer
            Get
                Return _ShowComponentsImages
            End Get
            Set(ByVal value As Integer)
                _ShowComponentsImages = value
            End Set
        End Property

        Public Property LayoutTemplate() As String
            Get
                Return _LayoutTemplate
            End Get
            Set(ByVal value As String)
                _LayoutTemplate = value
            End Set
        End Property

        Public Property LayoutDCDTemplate() As String
            Get
                Return _LayoutDCDTemplate
            End Get
            Set(ByVal value As String)
                _LayoutDCDTemplate = value
            End Set
        End Property
        Public Property LayoutPackageTemplate() As String
            Get
                Return _LayoutPackageTemplate
            End Get
            Set(ByVal value As String)
                _LayoutPackageTemplate = value
            End Set
        End Property

		Public Property LayoutMeetingTemplate() As String
			Get
				Return _LayoutMeetingTemplate
			End Get
			Set(ByVal value As String)
				_LayoutMeetingTemplate = value
			End Set
		End Property

		Public Property Searchable() As Boolean
			Get
				Return _Searchable
			End Get
			Set(ByVal value As Boolean)
				_Searchable = value
			End Set
        End Property

		Public Property SearchableSettingsKey() As String
			Get
				Return _SearchableSettingsKey
			End Get
			Set(ByVal value As String)
				_SearchableSettingsKey = value
			End Set
        End Property

        Public Property DisplayDownloadTerm() As Boolean
            Get
                Return _DisplayDownloadTerm
            End Get
            Set(ByVal value As Boolean)
                _DisplayDownloadTerm = value
            End Set
        End Property

        Public Property DisplayDownloadTermSettingsKey() As Boolean
            Get
                Return _DisplayDownloadTermSettingsKey
            End Get
            Set(ByVal value As Boolean)
                _DisplayDownloadTermSettingsKey = value
            End Set
        End Property

        Public Property ProductId() As Integer
            Get
                Return _ProductId
            End Get
            Set(ByVal value As Integer)
                _ProductId = value
            End Set
        End Property

        Public Property ShowButtons() As Boolean
            Get
                Return _ShowButtons
            End Get
            Set(ByVal value As Boolean)
                _ShowButtons = value
            End Set
        End Property

        Public Property ShowAddtoCart() As Boolean
            Get
                Return Me._ShowAddtoCart
            End Get
            Set(ByVal value As Boolean)
                _ShowAddtoCart = value
            End Set
        End Property


        Public Property ShowWishList() As Boolean
            Get
                Return Me._ShowWishList
            End Get
            Set(ByVal value As Boolean)
                _ShowWishList = value
            End Set
        End Property

        Public Property ShowUpdateOrder() As Boolean
            Get
                Return Me._ShowUpdateOrder
            End Get
            Set(ByVal value As Boolean)
                _ShowUpdateOrder = value
            End Set
        End Property

        Public Property ShowBuyForGroup() As Boolean
            Get
                Return Me._ShowBuyForGroup
            End Get
            Set(ByVal value As Boolean)
                _ShowBuyForGroup = value
            End Set
        End Property

#End Region



#Region " Private Sub/Functions "

        ''' <summary>
        ''' get module settings from DotNetNuke.Entities.Modules.ModuleController
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetModuleSettings() As Hashtable
            Try
                If _ModuleSettings IsNot Nothing Then
                    Return _ModuleSettings
                Else
                    If _ModuleId <> 0 Then
                        Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
                        Return objMC.GetModuleSettings(_ModuleId)
                    Else
                        Return Nothing
                    End If
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return Nothing
        End Function

        ''' <summary>
        ''' load module settings into the object
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadSettings()
            Try
                Dim objMS As Hashtable
                objMS = GetModuleSettings()

                If objMS(_DisplayProductImageSettingsKey) IsNot Nothing Then
                    _DisplayProductImage = CType(objMS(_DisplayProductImageSettingsKey), Boolean)
                End If

                If objMS(_ProductIdParametersSettingsKey) IsNot Nothing Then
                    _ProductIdParameters = CType(objMS(_ProductIdParametersSettingsKey), String)
                End If

                If objMS(_TruncateDescriptionSettingsKey) IsNot Nothing Then
                    _TruncateDescription = CType(objMS(_TruncateDescriptionSettingsKey), Integer)
                End If

                If objMS(_DefaultQuantitySettingsKey) IsNot Nothing Then
                    _DefaultQuantity = CType(objMS(_DefaultQuantitySettingsKey), Integer)
                Else
                    _DefaultQuantity = 1
                End If

                If objMS(_DisplayProductComponentsSettingsKey) IsNot Nothing Then
                    _DisplayProductComponents = IIf(objMS(_DisplayProductComponentsSettingsKey) = "Y", True, False)
                    If _DisplayProductComponents Then
                        If objMS(_TruncateComponentsDescriptionSettingsKey) IsNot Nothing Then
                            _TruncateComponentsDescription = CType(objMS(_TruncateComponentsDescriptionSettingsKey), Integer)
                        End If

                        If objMS(_ShowComponentsImagesSettingsKey) IsNot Nothing Then
                            _ShowComponentsImages = IIf(objMS(_ShowComponentsImagesSettingsKey) = "Y", True, False)
                        Else
                            _ShowComponentsImages = False
                        End If
                    End If

                End If

                

                If objMS(_LayoutTemplateSettingsKey) IsNot Nothing Then
                    _LayoutTemplate = CType(objMS(_LayoutTemplateSettingsKey), String)
                End If

                If objMS(_LayoutDCDTemplateSettingsKey) IsNot Nothing Then
                    _LayoutDCDTemplate = CType(objMS(_LayoutDCDTemplateSettingsKey), String)
                End If

                If objMS(_LayoutPackageTemplateSettingsKey) IsNot Nothing Then
                    _LayoutPackageTemplate = CType(objMS(_LayoutPackageTemplateSettingsKey), String)
                End If

				If objMS(_LayoutMeetingTemplateSettingsKey) IsNot Nothing Then
					_LayoutMeetingTemplate = CType(objMS(_LayoutMeetingTemplateSettingsKey), String)
				End If

				If objMS(_SearchableSettingsKey) IsNot Nothing Then
					_Searchable = CType(objMS(_SearchableSettingsKey), Boolean)
				End If

                If objMS(_DisplayDownloadTermSettingsKey) IsNot Nothing Then
                    _DisplayDownloadTerm = CType(objMS(_DisplayDownloadTermSettingsKey), Boolean)
                End If

				If objMS(C_BUYFORGROUPURLSETTINGSKEY) IsNot Nothing Then
					_BUYFORGROUPURL = CType(objMS(C_BUYFORGROUPURLSETTINGSKEY), String)
				End If
				If objMS(C_BUYFORGROUPURLTYPESETTINGSKEY) IsNot Nothing Then
					_BuyForGroupURLLType = CType(objMS(C_BUYFORGROUPURLTYPESETTINGSKEY), String)
				End If

                If objMS(C_SHOWBUTTONS) IsNot Nothing Then
                    _ShowButtons = CType(objMS(C_SHOWBUTTONS), Boolean)
                End If

                If objMS(C_SHOWADDTOCART) IsNot Nothing Then
                    _ShowAddtoCart = CType(objMS(C_SHOWADDTOCART), Boolean)
                End If
                If objMS(C_SHOWWISHLIST) IsNot Nothing Then
                    _ShowWishList = CType(objMS(C_SHOWWISHLIST), Boolean)
                End If
                If objMS(C_SHOWUPDATEORDER) IsNot Nothing Then
                    _ShowUpdateOrder = CType(objMS(C_SHOWUPDATEORDER), Boolean)
                End If
                If objMS(C_SHOWBUYFORGROUP) IsNot Nothing Then
                    _ShowBuyForGroup = CType(objMS(C_SHOWBUYFORGROUP), Boolean)
                End If

                If objMS(C_PRODUCTID) IsNot Nothing Then
                    _ProductID = CType(objMS(C_PRODUCTID), Integer)
                Else
                    _ProductID = 0
                End If
			Catch ex As Exception
				Throw ex
			End Try

		End Sub

		''' <summary>
		''' new DotNetNuke.Entities.Modules.ModuleController
		''' </summary>
		''' <returns></returns>
		''' <remarks></remarks>
		Protected Function GetController() As DotNetNuke.Entities.Modules.ModuleController
			Try
				Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
				Return objMC
			Catch ex As Exception
				Throw ex
			End Try
			Return Nothing
		End Function

		''' <summary>
		''' save module settings into DotNetNuke.Entities.Modules.ModuleController
		''' </summary>
		''' <remarks></remarks>
		Private Sub SaveSettings()
			Try

				Dim objMS As DotNetNuke.Entities.Modules.ModuleController
				objMS = GetController()

				objMS.UpdateModuleSetting(_ModuleId, _DisplayProductImageSettingsKey, CType(_DisplayProductImage, String))
				objMS.UpdateModuleSetting(_ModuleId, _ProductIdParametersSettingsKey, CType(_ProductIdParameters, String))
                objMS.UpdateModuleSetting(_ModuleId, _TruncateDescriptionSettingsKey, CType(_TruncateDescription, String))
                objMS.UpdateModuleSetting(_ModuleId, _DefaultQuantitySettingsKey, CType(_DefaultQuantity, String))
                objMS.UpdateModuleSetting(_ModuleId, _DisplayProductComponentsSettingsKey, CType(IIf(_DisplayProductComponents, "Y", "N"), String))
                If _DisplayProductComponents Then
                    objMS.UpdateModuleSetting(_ModuleId, _TruncateComponentsDescriptionSettingsKey, CType(_TruncateComponentsDescription, String))
                    objMS.UpdateModuleSetting(_ModuleId, _ShowComponentsImagesSettingsKey, CType(IIf(_ShowComponentsImages, "Y", "N"), String))
                End If
                objMS.UpdateModuleSetting(_ModuleId, _LayoutTemplateSettingsKey, CType(_LayoutTemplate, String))
                'D00030947
                If _LayoutDCDTemplate IsNot Nothing Then
                    objMS.UpdateModuleSetting(_ModuleId, _LayoutDCDTemplateSettingsKey, CType(_LayoutDCDTemplate, String))
                End If
                objMS.UpdateModuleSetting(_ModuleId, _LayoutPackageTemplateSettingsKey, CType(_LayoutPackageTemplate, String))
                objMS.UpdateModuleSetting(_ModuleId, _LayoutMeetingTemplateSettingsKey, CType(_LayoutMeetingTemplate, String))

                objMS.UpdateModuleSetting(_ModuleId, _BuyForGroupURLSettingsKey, CType(_BuyForGroupURL, String))
                objMS.UpdateModuleSetting(_ModuleId, _BuyForGroupURLLTypeSettingsKey, CType(_BuyForGroupURLLType, String))

                'Calvin 
                objMS.UpdateModuleSetting(_ModuleId, _SearchableSettingsKey, CType(_Searchable, String))
                objMS.UpdateModuleSetting(_ModuleId, _DisplayDownloadTermSettingsKey, CType(_DisplayDownloadTerm, String))
                objMS.UpdateModuleSetting(_ModuleId, "Subsystem", "ALL")

                objMS.UpdateModuleSetting(_ModuleId, C_SHOWBUTTONS, _ShowButtons.ToString)

                objMS.UpdateModuleSetting(_ModuleId, C_SHOWADDTOCART, _ShowAddtoCart.ToString)
                objMS.UpdateModuleSetting(_ModuleId, C_SHOWWISHLIST, _ShowWishList.ToString)
                objMS.UpdateModuleSetting(_ModuleId, C_SHOWUPDATEORDER, _ShowUpdateOrder.ToString)
                objMS.UpdateModuleSetting(_ModuleId, C_SHOWBUYFORGROUP, _ShowBuyForGroup.ToString)

                objMS.UpdateModuleSetting(_ModuleId, C_PRODUCTID, _ProductID.ToString)

            Catch ex As Exception
                Throw ex
            End Try

		End Sub


#End Region


#Region " Public Sub/Functions "

        ''' <summary>
        ''' load settings from Hashtable?
        ''' </summary>
        ''' <param name="Settings"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Load(ByVal Settings As Hashtable) As Boolean
            Try
                _ModuleSettings = Settings
                LoadSettings()
            Catch ex As Exception
                Throw ex
            End Try
        End Function


        ''' <summary>
        ''' load settings
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Load() As Boolean
            Try
                LoadSettings()
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        ''' <summary>
        ''' save settings
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Save() As Boolean
            Try
                SaveSettings()
            Catch ex As Exception

            End Try
        End Function

        ''' <summary>
        ''' nothing inside
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function Validate() As Boolean

        End Function

#End Region


    End Class
End Namespace