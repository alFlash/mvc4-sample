Imports System.Collections.Specialized

Namespace Personify.DNN.Modules.ProductDetail

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Class SharedProductDetail

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks></remarks>
		Private Const C_PRICELISTLAYOUT As String = "PriceLayout.List"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="ResFile"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function GetPriceLayoutList(ByVal ResFile As String) As Hashtable
            Dim tmpString As String
            Dim PriceLayout As New Hashtable
            Dim LabelValue() As String
			Try
				tmpString = Localization.GetString(C_PRICELISTLAYOUT, ResFile)

				If tmpString IsNot String.Empty Then
					Dim tmpArray() As String = tmpString.Split(New Char() {","c})
					For i As Integer = 0 To tmpArray.Length - 1
						LabelValue = tmpArray(i).Split(New Char() {";"c})
						If LabelValue IsNot Nothing AndAlso LabelValue(0) IsNot Nothing AndAlso LabelValue(1) IsNot Nothing Then
							PriceLayout.Add(LabelValue(0).Trim, LabelValue(1).Trim)
						End If
						LabelValue = Nothing
					Next
				End If
				Return PriceLayout
			Catch ex As Exception

			End Try
            Return Nothing
		End Function

	End Class

End Namespace