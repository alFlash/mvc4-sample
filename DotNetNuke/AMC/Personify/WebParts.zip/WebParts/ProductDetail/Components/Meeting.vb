Imports DotNetNuke
Imports System.Collections.Specialized


Namespace Personify.DNN.Modules.ProductDetail


	Public Class Meeting

		Private _ModuleId As Integer

		Private Const C_MEETINGINCLUSIONSETTINGSKEY As String = "MeetingInclusionSettingsKey"
		Private Const C_MEETINGURLSETTINGSKEY As String = "US_MeetingURLSettingsKey"
		Private Const C_MEETINGURLTYPESETTINGSKEY As String = "US_MeetingURLTypeSettingsKey"

		Private _MeetingURL As String
		Private _MeetingURLType As String

        Private Const C_UPDATEORDERURLSETTINGSKEY As String = "UpdateOrderURLSettingsKey"
        Private Const C_UPDATEORDERURLTYPESETTINGSKEY As String = "UpdateOrderURLTypeSettingsKey"

        Private Const C_BADGEURLSETTINGSKEY As String = "BadgeURLSettingsKey"
        Private Const C_BADGEURLTYPESETTINGSKEY As String = "BadgeURLTypeSettingsKey"


        Private _UpdateOrderURL As String
        Private _UpdateOrderURLType As String

        Private _BadgeURL As String
        Private _BadgeURLType As String

        Public Property MeetingURL() As String
            Get
                Return _MeetingURL
            End Get
            Set(ByVal value As String)
                _MeetingURL = value
            End Set
        End Property
        Public Property MeetingURLType() As String
            Get
                Return _MeetingURLType
            End Get
            Set(ByVal value As String)
                _MeetingURLType = value
            End Set
        End Property

        Public Property UpdateOrderURL() As String
            Get
                Return _UpdateOrderURL
            End Get
            Set(ByVal value As String)
                _UpdateOrderURL = value
            End Set
        End Property
        Public Property UpdateOrderURLType() As String
            Get
                Return _UpdateOrderURLType
            End Get
            Set(ByVal value As String)
                _UpdateOrderURLType = value
            End Set
        End Property

        Public Property BadgesURL() As String
            Get
                Return _BadgeURL
            End Get
            Set(ByVal value As String)
                _BadgeURL = value
            End Set
        End Property
        Public Property BadgesURLType() As String
            Get
                Return _BadgeURLType
            End Get
            Set(ByVal value As String)
                _BadgeURLType = value
            End Set
        End Property

		Private _MeetingInclusion As ArrayList

		Public Sub New(ByVal ModuleId As Integer)
			_ModuleId = ModuleId
			_MeetingInclusion = New ArrayList
		End Sub


		Public Property ModuleId() As Integer
			Get
				Return _ModuleId
			End Get
			Set(ByVal value As Integer)
				_ModuleId = value
			End Set
		End Property

		''' <remarks></remarks>
		Public Property MeetingInclusion() As ArrayList
			Get
				Return _MeetingInclusion
			End Get
			Set(ByVal value As ArrayList)
				_MeetingInclusion = value
			End Set
		End Property

		Public Function Load() As Boolean
			Try
				Dim MS As Hashtable
				Dim objMS As New DotNetNuke.Entities.Modules.ModuleController
				Dim SettingsKey As String

				_MeetingInclusion = New ArrayList
				If _ModuleId <> -1 Then
					MS = objMS.GetModuleSettings(_ModuleId)

					For Each SettingsKey In MS.Keys
						If SettingsKey.IndexOf(C_MEETINGINCLUSIONSETTINGSKEY) <> -1 Then
							_MeetingInclusion.Add(MS(SettingsKey).ToString)
						End If
					Next


					If MS(C_MEETINGURLSETTINGSKEY) IsNot Nothing Then
						_MeetingURL = CType(MS(C_MEETINGURLSETTINGSKEY), String)
					End If
					If MS(C_MEETINGURLTYPESETTINGSKEY) IsNot Nothing Then
						_MeetingURLType = CType(MS(C_MEETINGURLTYPESETTINGSKEY), String)
					End If

                    If MS(C_UPDATEORDERURLSETTINGSKEY) IsNot Nothing Then
                        _UpdateOrderURL = CType(MS(C_UPDATEORDERURLSETTINGSKEY), String)
                    End If
                    If MS(C_UPDATEORDERURLTYPESETTINGSKEY) IsNot Nothing Then
                        _UpdateOrderURLType = CType(MS(C_UPDATEORDERURLTYPESETTINGSKEY), String)
                    End If

                    'an upadte meeting fix
                    If MS(C_BADGEURLSETTINGSKEY) IsNot Nothing Then
                        _BadgeURL = CType(MS(C_BADGEURLSETTINGSKEY), String)
                    End If
                    If MS(C_BADGEURLTYPESETTINGSKEY) IsNot Nothing Then
                        _BadgeURLType = CType(MS(C_BADGEURLTYPESETTINGSKEY), String)
                    End If


				End If

			Catch ex As Exception
				Throw ex
			End Try
		End Function

		Public Function Save() As Boolean
			Try
				SaveMeetingInclusion()
			Catch ex As Exception
				Throw ex
			End Try
		End Function


		Private Sub SaveMeetingInclusion()
			Try
				Dim temSub As String
				Dim objMS As DotNetNuke.Entities.Modules.ModuleController

				objMS = GetController()

				Dim tmpHT As Hashtable
				Dim tmpKey As String
				tmpHT = objMS.GetModuleSettings(ModuleId)
				Dim keysToBeRemoved As New ArrayList

				For Each tmpKey In tmpHT.Keys
					If tmpKey.IndexOf(C_MEETINGINCLUSIONSETTINGSKEY) <> -1 Or tmpKey.IndexOf(C_MEETINGINCLUSIONSETTINGSKEY) <> -1 Then
						keysToBeRemoved.Add(tmpKey)
					End If
				Next

				For Each tmpKey In keysToBeRemoved
					objMS.DeleteModuleSetting(_ModuleId, tmpKey)
				Next

				For Each temSub In _MeetingInclusion
					objMS.UpdateModuleSetting(_ModuleId, C_MEETINGINCLUSIONSETTINGSKEY + "_" + temSub, temSub)
				Next

				objMS.UpdateModuleSetting(_ModuleId, C_MEETINGURLSETTINGSKEY, CType(_MeetingURL, String))
				objMS.UpdateModuleSetting(_ModuleId, C_MEETINGURLTYPESETTINGSKEY, CType(_MeetingURLType, String))

                objMS.UpdateModuleSetting(_ModuleId, C_UPDATEORDERURLSETTINGSKEY, CType(_UpdateOrderURL, String))
                objMS.UpdateModuleSetting(_ModuleId, C_UPDATEORDERURLTYPESETTINGSKEY, CType(_UpdateOrderURLType, String))

                'an update meeting
                objMS.UpdateModuleSetting(_ModuleId, C_BADGEURLSETTINGSKEY, CType(_BadgeURL, String))
                objMS.UpdateModuleSetting(_ModuleId, C_BADGEURLTYPESETTINGSKEY, CType(_BadgeURLType, String))

			Catch ex As Exception
				Throw ex
			End Try
		End Sub

		Private Function GetController() As DotNetNuke.Entities.Modules.ModuleController
			Try
				Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
				Return objMC
			Catch ex As Exception
				Throw ex
			End Try
			Return Nothing
		End Function

	End Class

End Namespace
