Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Threading
Imports System.Web.Mail
Imports TIMSS.Server.BusinessMessages.EmailAndFax
Imports Personify.DNN.Modules.Email.Business

Namespace Personify.DNN.Modules.Email

    Public MustInherit Class Email
		Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"
        Protected WithEvents plEmail As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents plCC As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents plBcc As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents plSubject As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents txtToEmailAddress As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtBcc As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtSubject As System.Web.UI.WebControls.TextBox
        Protected WithEvents teMessage As DotNetNuke.UI.UserControls.TextEditor
        Protected WithEvents txtCc As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblFrom As System.Web.UI.WebControls.Label
        Protected WithEvents pnlMain As System.Web.UI.WebControls.Panel
        Protected WithEvents lblFromEmailAddress As System.Web.UI.WebControls.Label
        Protected WithEvents btnSendEmail As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelEmail As System.Web.UI.WebControls.Button
        Protected WithEvents browseFile As System.Web.UI.WebControls.FileUpload
        Protected allowTr As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents pnlContinue As System.Web.UI.WebControls.Panel
        Protected WithEvents btnContinue As System.Web.UI.WebControls.Button

        Protected WithEvents lblSegmentDesc As System.Web.UI.WebControls.Label

        Dim affiliateListTabId As Integer = 0
#End Region



#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
              role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    Dim segmentinfo As AffiliateManagementSessionHelper.SegmentInfo
                    'get current segment information
                    segmentinfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)

                    'description of the current segment on top of the page
                    lblSegmentDesc.Text = segmentinfo.SegmentDescr

                    affiliateListTabId = segmentinfo.AffiliateListTabId

                    'panel to be shown only after a succesfull sending of the email
                    pnlContinue.Visible = False

                    If Settings("AllowAttach") Is Nothing Then
                        allowTr.Visible = False
                    ElseIf Settings("AllowAttach").ToString = "False" Then
                        allowTr.Visible = False
                    Else
                        allowTr.Visible = True
                    End If
                    If Not Page.IsPostBack Then
                        If Settings("SubjectLength") Is Nothing Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            pnlMain.Visible = False
                            pnlContinue.Visible = False
                        Else
                            'If affiliateListTabId = 0 Then
                            'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingSegmentInformation", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            'Else
                            InitializeForm()
                            'End If
                        End If
                Else
                    If Page.Request.Params("__EVENTTARGET").IndexOf("teMessage") < 0 Then
                        'panel to be shown only after a succesfull sending of the email
                        pnlMain.Visible = False
                        pnlContinue.Visible = True
                    End If
                End If
                
                Else
                    pnlMain.Visible = False
                    btnContinue.Visible = False
                    DisplayUserAccessMessage(role)
                End If
                
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
 
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
        Private Sub btnSendEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click

            Try
                If Page.IsValid Then
                    pnlMain.Visible = False
                    'If teMessage.Text.Length > 0 Then

                    ' load emails specified in email distribution list
                    Dim strEmail As String
                    Dim arrEmail As Array

                    Dim Subject As String

                    If txtSubject.Text <> "" Then
                        'mail subject must not exceed the length specified in Settings
                        If txtSubject.Text.Length <= CType(Settings("SubjectLength"), Integer) Then
                            Subject = txtSubject.Text
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("MessageSubjectLength", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Exit Sub
                        End If
                    Else
                        Subject = Localization.GetString("DefaultSubject", LocalResourceFile)
                    End If


                    Dim oEmail As New SendEmailRequest
                    Dim AddressFrom As String = GetEmailAddressFrom()
                    'Convert.ToString(Personify.ApplicationManager.Commons.GetSiteSettings(PortalId).AdminEmailAddress)
                    oEmail.From.Address = AddressFrom 'lblFromEmailAddress.Text
                    oEmail.From.DisplayName = AddressFrom 'lblFromEmailAddress.Text
                    oEmail.Body = teMessage.Text
                    oEmail.Subject = Subject
                    'attachment
                    If browseFile.FileName <> String.Empty Then
                        Dim att As New EmailAttachment
                        att.AttachmentName = browseFile.FileName
                        att.Content = browseFile.FileBytes
                        oEmail.Attachments.Add(att)
                    End If

                    'create an array to hold destionation email addresses
                    arrEmail = Split(txtToEmailAddress.Text, ";")
                    Dim toEmail As EmailAddress

                    For Each strEmail In arrEmail
                        toEmail = New EmailAddress(strEmail, strEmail)
                        oEmail.To.Add(toEmail)
                    Next


                    If txtCc.Text <> String.Empty Then
                        'create an array to hold CC email addresses
                        arrEmail = Split(txtCc.Text, ";")
                        Dim cc As EmailAddress

                        For Each strEmail In arrEmail
                            cc = New EmailAddress(strEmail, strEmail)
                            oEmail.Cc.Add(cc)
                        Next

                    End If

                    If txtBcc.Text <> String.Empty Then
                        'create an array to hold BCC email addresses
                        arrEmail = Split(txtBcc.Text, ";")
                        Dim bcc As EmailAddress
                        For Each strEmail In arrEmail
                            bcc = New EmailAddress(strEmail, strEmail)
                            oEmail.Bcc.Add(bcc)
                        Next

                    End If


                    TIMSS.Global.App.CurrentDeliveryStrategy.ProcessSync(oEmail)
                    ' completed
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("MessageSent", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)

                    'End If
                End If
            Catch exc As System.Net.Mail.SmtpFailedRecipientException
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("UserDoesNotExists", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                pnlMain.Visible = True
                pnlContinue.Visible = False
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub
        Private Sub InitializeForm()
            'initialize the form
            'get the source email address
            lblFromEmailAddress.Text = GetEmailAddressFrom()
            'If affiliateListTabId = 0 Then
            'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingSegmentInformation", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            'Else
            'get the destination email addresses
            txtToEmailAddress.Text = GetEmailAddressesTo()
            'End If

            txtBcc.Text = ""
            txtCc.Text = ""
            txtSubject.Text = ""
            teMessage.Text = String.Empty
            If Settings("SubjectLength") IsNot Nothing Then
                txtSubject.MaxLength = CInt(Settings("SubjectLength"))
            End If
        End Sub

        Private Sub btnCancelEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelEmail.Click, btnContinue.Click
            Response.Redirect(NavigateURL(affiliateListTabId))
        End Sub
        

        Private Function GetEmailAddressesTo() As String
            Dim strQueryString As String = Request.Url.Query
            Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
            Dim strQueryParam As String

            Dim toEmailAddresses As String = String.Empty
            For Each strQueryParam In arrQueryString
                If strQueryParam.IndexOf("EmailAddresses") <> -1 Then
                    'if SendEmail to only one customer (SendEmail from ContextMenu)
                    toEmailAddresses = strQueryParam.Replace("EmailAddresses=", "")
                    'for Friendly URL set - address iun querystring will be like aaa%40bbb.com
                    toEmailAddresses = toEmailAddresses.Replace("%40", "@")
                End If
            Next
            If toEmailAddresses = String.Empty Then
                'if SendEmail to more than one customer (SendEmail button)
                Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
                Dim first As Boolean = True
                If arrGroupActionInfo IsNot Nothing Then
                    For Each strucGroupActionInfo In arrGroupActionInfo
                        If strucGroupActionInfo.EmailAddress IsNot Nothing AndAlso strucGroupActionInfo.EmailAddress <> String.Empty Then
                            If first Then
                                toEmailAddresses = strucGroupActionInfo.EmailAddress
                                first = False
                            Else
                                toEmailAddresses = toEmailAddresses & ";" & strucGroupActionInfo.EmailAddress
                            End If
                        End If
                    Next
                End If                
            End If

            Return toEmailAddresses
        End Function

        'get the email address for the current user
        Private Function GetEmailAddressFrom() As String
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            Dim strMasterCustomerId As String = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
            Dim strSubCustomerId As String = UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString

            'get the email address for the curent user
            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", MasterCustomerId)
                .Filter.Add("SubCustomerId", SubCustomerId)
                .Fill()
            End With

            Return oCustomers(0).PrimaryEmailAddress
        End Function
    End Class




End Namespace
