Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.Email.Business

Namespace Personify.DNN.Modules.Email

	Public MustInherit Class EmailEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents txtSubjectLength As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboPriority As System.Web.UI.WebControls.DropDownList
        Protected WithEvents optSendAction As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents allowChk As System.Web.UI.WebControls.CheckBox
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    allowChk.Checked = CType(Settings("AllowAttach"), Boolean)
                    SetPage()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub SetPage()
            If CType(Settings("Priority"), String) <> "" Then
                cboPriority.Items.FindByValue(CType(Settings("Priority"), String)).Selected = True
            Else
                cboPriority.SelectedIndex = 1 '"Normal"
            End If

            If CType(Settings("SendAction"), String) <> "" Then
                optSendAction.Items.FindByText(CType(Settings("SendAction"), String)).Selected = True
            Else
                optSendAction.SelectedIndex = 1 'Synchronous
            End If

            If CType(Settings("SubjectLength"), String) <> "" Then
                txtSubjectLength.Text = CType(Settings("SubjectLength"), String)
            Else
                txtSubjectLength.Text = CStr(500)
            End If
        End Sub
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    ' Update TabModuleSettings
                    UpdateModuleSetting( "AllowAttach", CType(allowChk.Checked, String))

                   UpdateModuleSetting( "Priority", cboPriority.SelectedItem.Value)
                   UpdateModuleSetting( "SendAction", optSendAction.SelectedItem.Text)
                   UpdateModuleSetting( "SubjectLength", txtSubjectLength.Text)

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
