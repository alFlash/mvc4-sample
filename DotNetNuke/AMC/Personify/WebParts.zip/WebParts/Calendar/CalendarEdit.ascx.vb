Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.Calendar.Business
Imports Telerik.Web.ui

Imports TIMSS.API.Core

Namespace Personify.DNN.Modules.Calendar

    Public MustInherit Class CalendarEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents RadEditorCalendarTitle As Telerik.Web.UI.RadEditor
        Protected WithEvents drpDetailWindowActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpProductDetailActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpCalendarSkin As DropDownList

        Protected WithEvents rdCalendarTimeFrame As RadioButtonList
        Protected WithEvents txtCalendarTimeFrameDate As TextBox
        Protected WithEvents chkMeetingsFromNonMembers As CheckBox
        Protected WithEvents chkEnableTextMode As CheckBox
        Protected WithEvents chkAllowPrinting As CheckBox
        Protected WithEvents drpCalendarDefaultDisplay As DropDownList


        Protected WithEvents xslRestrictions As WebControls.XslTemplate

        Protected WithEvents RadColorPickerCellBackgroundColor As Telerik.Web.UI.RadColorPicker
        Protected WithEvents RadColorPickerCellBorderColor As Telerik.Web.UI.RadColorPicker
        Protected WithEvents RadColorPickerMeetingBackgroundColor As Telerik.Web.UI.RadColorPicker

        Protected WithEvents rdCalendarMode As RadioButtonList
        Protected WithEvents pnlCalendarMode As Panel
        Protected WithEvents pnlDetailWindowMode As Panel

        Protected WithEvents RadMaskedTextBoxDetailWindowWidth As Telerik.Web.UI.RadMaskedTextBox
        Protected WithEvents RadMaskedTextBoxDetailWindowHeight As Telerik.Web.UI.RadMaskedTextBox

        Protected WithEvents txtReportPath As TextBox
#End Region

#Region "Constants"
        Private Const C_CALENDAR_TITLE As String = "CalendarTitle"
        Private Const C_CALENDAR_Detail_WINDOW_ACTION_URL As String = "CalendarDetailWindowActionURL"
        Private Const C_CALENDAR_PRODUCT_DETAIL_ACTION_URL As String = "CalendarProductDetailActionURL"
        Private Const C_CALENDAR_SKIN As String = "CalendarSkin"
        Private Const C_CALENDAR_TIMEFRAME As String = "CalendarTimeFrame"
        Private Const C_CALENDAR_TIMEFRAME_DATE As String = "CalendarTimeFrameDate"


        Private Const C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS As String = "CalendarHideMembersOnlyFromNonMembers"
        Private Const C_ENABLE_TEXT_MODE As String = "CalendarEnableTextMode"
        Private Const C_ALLOW_PRINTING As String = "CalendarAllowPrinting"
        Private Const C_DEFAULT_DISPLAY_MODE As String = "CalendarDefaultDisplayMode"

        Private Const C_CELL_BORDER_COLOR As String = "CellBorderColor"
        Private Const C_CELL_BACKGROUND_COLOR As String = "CellBackgroundColor"
        Private Const C_MEETING_BACKGROUND_COLOR As String = "MeetingBackgroundColor"

        Private Const C_CALENDAR_MODE As String = "CalendarMode"

        Private Const C_DETAIL_WINDOW_WIDTH As String = "DetailWindowWidth"
        Private Const C_DETAIL_WINDOW_HEIGHT As String = "DetailWindowHeight"

        Private Const C_REPORT_PATH As String = "ReportPath"
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    LoadSettings()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    UpdateSettings()

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Protected Sub rdCalendarMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdCalendarMode.SelectedIndexChanged
            If rdCalendarMode.SelectedValue = "0" Then
                pnlCalendarMode.Visible = True
                pnlDetailWindowMode.Visible = False
            Else
                pnlCalendarMode.Visible = False
                pnlDetailWindowMode.Visible = True
            End If

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "Helper functions"
        Private Sub LoadSettings()

            If Settings(C_CALENDAR_MODE) IsNot Nothing Then
                rdCalendarMode.SelectedValue = CStr(Settings(C_CALENDAR_MODE))
            End If
            If rdCalendarMode.SelectedValue = "0" Then
                pnlCalendarMode.Visible = True
                pnlDetailWindowMode.Visible = False

                RadEditorCalendarTitle.Content = CStr(Settings(C_CALENDAR_TITLE))
                RadEditorCalendarTitle.ToolsFile = ResolveUrl("BasicTools.xml") 'Server.MapPath(ModulePath + "/BasicTools.xml")
                If Settings(C_CALENDAR_Detail_WINDOW_ACTION_URL) IsNot Nothing Then
                    drpDetailWindowActionURL.Url = CStr(Settings(C_CALENDAR_Detail_WINDOW_ACTION_URL))
                End If
                If Settings(C_CALENDAR_PRODUCT_DETAIL_ACTION_URL) IsNot Nothing Then
                    drpProductDetailActionURL.Url = CStr(Settings(C_CALENDAR_PRODUCT_DETAIL_ACTION_URL))
                End If
                If Settings(C_CALENDAR_SKIN) IsNot Nothing Then
                    drpCalendarSkin.SelectedValue = CStr(Settings(C_CALENDAR_SKIN))
                End If


                If Settings(C_CALENDAR_TIMEFRAME) Is Nothing Then
                    rdCalendarTimeFrame.SelectedValue = "0"
                Else
                    rdCalendarTimeFrame.SelectedValue = CStr(Settings(C_CALENDAR_TIMEFRAME))
                    If CStr(Settings(C_CALENDAR_TIMEFRAME)) = "3" Then
                        txtCalendarTimeFrameDate.Text = CStr(Settings(C_CALENDAR_TIMEFRAME_DATE))
                    End If
                End If

                If Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS) IsNot Nothing Then
                    chkMeetingsFromNonMembers.Checked = CBool(IIf(CStr(Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS)) = "Y", True, False))
                End If

                If Settings(C_ENABLE_TEXT_MODE) IsNot Nothing Then
                    chkEnableTextMode.Checked = CBool(IIf(CStr(Settings(C_ENABLE_TEXT_MODE)) = "Y", True, False))
                End If

                If Settings(C_ALLOW_PRINTING) IsNot Nothing Then
                    chkAllowPrinting.Checked = CBool(IIf(CStr(Settings(C_ALLOW_PRINTING)) = "Y", True, False))
                End If

                If Settings(C_DEFAULT_DISPLAY_MODE) Is Nothing Then
                    drpCalendarDefaultDisplay.SelectedValue = "0"
                Else
                    drpCalendarDefaultDisplay.SelectedValue = CStr(Settings(C_DEFAULT_DISPLAY_MODE))
                End If

                'GetMeetingsByProductClass

                Dim oCodes1 As TIMSS.API.ApplicationInfo.IApplicationCodes
                oCodes1 = GetMeetingsByProductClass()

                Dim codes1(oCodes1.Count - 1) As CodeInfo

                Dim i As Integer = 0
                For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oCodes1
                    codes1(i) = New CodeInfo
                    codes1(i).Code = ReplaceSpecialCharacters(oCode.Code)
                    codes1(i).CodeDescription = oCode.Description

                    If Not Settings("RestrictMeetingsByProductClass_" & ReplaceSpecialCharacters(oCode.Code)) Is Nothing AndAlso CStr(Settings("RestrictMeetingsByProductClass_" & ReplaceSpecialCharacters(oCode.Code))) = "Y" Then
                        codes1(i).checked = True
                    Else
                        codes1(i).checked = False
                    End If
                    i = i + 1
                Next

                'GetBreakOutSessionsByProductClass
                Dim oCodes2 As ArrayList
                oCodes2 = GetBreakOutSessionsByProductClass()

                Dim codes2(oCodes2.Count - 1) As CodeInfo

                i = 0
                For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oCodes2
                    codes2(i) = New CodeInfo
                    codes2(i).Code = ReplaceSpecialCharacters(oCode.Code)
                    codes2(i).CodeDescription = oCode.Description

                    If Not Settings("RestrictBreakOutSessionsByProductClass_" & ReplaceSpecialCharacters(oCode.Code)) Is Nothing AndAlso CStr(Settings("RestrictBreakOutSessionsByProductClass_" & ReplaceSpecialCharacters(oCode.Code))) = "Y" Then
                        codes2(i).checked = True
                    Else
                        codes2(i).checked = False
                    End If
                    i = i + 1
                Next

                'GetMeetingsByProductCategory
                Dim oCodes3 As TIMSS.API.ApplicationInfo.IApplicationCodes
                oCodes3 = GetMeetingsByProductCategory()

                Dim codes3(oCodes3.Count - 1) As CodeInfo

                i = 0
                For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oCodes3
                    codes3(i) = New CodeInfo
                    codes3(i).Code = ReplaceSpecialCharacters(oCode.Code)
                    codes3(i).CodeDescription = oCode.Description

                    If Not Settings("RestrictMeetingsByProductCategory_" & ReplaceSpecialCharacters(oCode.Code)) Is Nothing AndAlso CStr(Settings("RestrictMeetingsByProductCategory_" & ReplaceSpecialCharacters(oCode.Code))) = "Y" Then
                        codes3(i).checked = True
                    Else
                        codes3(i).checked = False
                    End If
                    i = i + 1
                Next

                With xslRestrictions
                    .XSLfile = Server.MapPath(ModulePath + "/Templates/CalendarEditTemplate.xsl")
                    If codes1.Length > 0 Then
                        .AddObject("RestrictMeetingsByProductClass", codes1)
                    End If
                    If codes2.Length > 0 Then
                        .AddObject("RestrictBreakOutSessionsByProductClass", codes2)
                    End If
                    If codes3.Length > 0 Then
                        .AddObject("RestrictMeetingsByProductCategory", codes3)
                    End If
                    .Display()
                End With

                RadColorPickerCellBorderColor.SelectedColor = ColorTranslator.FromHtml(CStr(Settings(C_CELL_BORDER_COLOR)))
                RadColorPickerCellBackgroundColor.SelectedColor = ColorTranslator.FromHtml(CStr(Settings(C_CELL_BACKGROUND_COLOR)))
                RadColorPickerMeetingBackgroundColor.SelectedColor = ColorTranslator.FromHtml(CStr(Settings(C_MEETING_BACKGROUND_COLOR)))

                If Settings(C_DETAIL_WINDOW_WIDTH) IsNot Nothing Then
                    RadMaskedTextBoxDetailWindowWidth.Text = CStr(Settings(C_DETAIL_WINDOW_WIDTH))
                End If
                If Settings(C_DETAIL_WINDOW_HEIGHT) IsNot Nothing Then
                    RadMaskedTextBoxDetailWindowHeight.Text = CStr(Settings(C_DETAIL_WINDOW_HEIGHT))
                End If

                If Settings(C_REPORT_PATH) IsNot Nothing Then
                    txtReportPath.Text = CStr(Settings(C_REPORT_PATH))
                End If
            Else
                pnlCalendarMode.Visible = False
                pnlDetailWindowMode.Visible = True


                If Settings(C_MEETING_BACKGROUND_COLOR) IsNot Nothing Then
                    RadColorPickerMeetingBackgroundColor.SelectedColor = ColorTranslator.FromHtml(CStr(Settings(C_MEETING_BACKGROUND_COLOR)))
                End If
            End If
        End Sub


        Private Sub UpdateSettings()

            UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

            UpdateModuleSetting(C_CALENDAR_MODE, rdCalendarMode.SelectedValue)
            If rdCalendarMode.SelectedValue = "0" Then
                UpdateModuleSetting(C_CALENDAR_TITLE, RadEditorCalendarTitle.Content)
                UpdateModuleSetting(C_CALENDAR_Detail_WINDOW_ACTION_URL, drpDetailWindowActionURL.Url)
                UpdateModuleSetting(C_CALENDAR_PRODUCT_DETAIL_ACTION_URL, drpProductDetailActionURL.Url)
                UpdateModuleSetting(C_CALENDAR_SKIN, drpCalendarSkin.SelectedValue)
                UpdateModuleSetting(C_CALENDAR_TIMEFRAME, rdCalendarTimeFrame.SelectedValue)
                If rdCalendarTimeFrame.SelectedValue = "3" Then
                    UpdateModuleSetting(C_CALENDAR_TIMEFRAME_DATE, txtCalendarTimeFrameDate.Text)
                End If
                UpdateModuleSetting(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS, CStr(IIf(chkMeetingsFromNonMembers.Checked, "Y", "N")))
                UpdateModuleSetting(C_ENABLE_TEXT_MODE, CStr(IIf(chkEnableTextMode.Checked, "Y", "N")))
                UpdateModuleSetting(C_ALLOW_PRINTING, CStr(IIf(chkAllowPrinting.Checked, "Y", "N")))
                UpdateModuleSetting(C_DEFAULT_DISPLAY_MODE, drpCalendarDefaultDisplay.SelectedValue)

                Dim oCodes1 As TIMSS.API.ApplicationInfo.IApplicationCodes
                oCodes1 = GetMeetingsByProductClass()
                Dim i As Integer = 0
                For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oCodes1
                    Dim setted As Boolean = False
                    For Each ctl As String In Request.Params.AllKeys
                        If ctl.IndexOf("chkRestrictMeetingsByProductClassCode" & ReplaceSpecialCharacters(oCode.Code)) >= 0 Then
                            UpdateModuleSetting("RestrictMeetingsByProductClass_" & ReplaceSpecialCharacters(oCode.Code), "Y")
                            setted = True
                            Exit For
                        End If
                    Next
                    If Not setted Then
                        UpdateModuleSetting("RestrictMeetingsByProductClass_" & ReplaceSpecialCharacters(oCode.Code), "N")
                    End If
                Next
                Dim oCodes2 As ArrayList
                oCodes2 = GetBreakOutSessionsByProductClass()
                i = 0
                For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oCodes2
                    Dim setted As Boolean = False
                    For Each ctl As String In Request.Params.AllKeys
                        If ctl.IndexOf("chkRestrictBreakOutSessionsByProductClassCode" & ReplaceSpecialCharacters(oCode.Code)) >= 0 Then
                            UpdateModuleSetting("RestrictBreakOutSessionsByProductClass_" & ReplaceSpecialCharacters(oCode.Code), "Y")
                            setted = True
                            Exit For
                        End If
                    Next
                    If Not setted Then
                        UpdateModuleSetting("RestrictBreakOutSessionsByProductClass_" & ReplaceSpecialCharacters(oCode.Code), "N")
                    End If
                Next
                Dim oCodes3 As TIMSS.API.ApplicationInfo.IApplicationCodes
                oCodes3 = GetMeetingsByProductCategory()
                i = 0
                For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oCodes3
                    Dim setted As Boolean = False
                    For Each ctl As String In Request.Params.AllKeys
                        If ctl.IndexOf("chkRestrictMeetingsByProductCategoryCode" & ReplaceSpecialCharacters(oCode.Code)) >= 0 Then
                            UpdateModuleSetting("RestrictMeetingsByProductCategory_" & ReplaceSpecialCharacters(oCode.Code), "Y")
                            setted = True
                            Exit For
                        End If
                    Next
                    If Not setted Then
                        UpdateModuleSetting("RestrictMeetingsByProductCategory_" & ReplaceSpecialCharacters(oCode.Code), "N")
                    End If
                Next


                UpdateModuleSetting(C_CELL_BACKGROUND_COLOR, ColorTranslator.ToHtml(RadColorPickerCellBackgroundColor.SelectedColor))
                UpdateModuleSetting(C_CELL_BORDER_COLOR, ColorTranslator.ToHtml(RadColorPickerCellBorderColor.SelectedColor))
                UpdateModuleSetting(C_MEETING_BACKGROUND_COLOR, ColorTranslator.ToHtml(RadColorPickerMeetingBackgroundColor.SelectedColor))
                UpdateModuleSetting(C_DETAIL_WINDOW_WIDTH, RadMaskedTextBoxDetailWindowWidth.Text)
                UpdateModuleSetting(C_DETAIL_WINDOW_HEIGHT, RadMaskedTextBoxDetailWindowHeight.Text)
                UpdateModuleSetting(C_REPORT_PATH, txtReportPath.Text)
            End If
            UpdateModuleSetting(C_MEETING_BACKGROUND_COLOR, ColorTranslator.ToHtml(RadColorPickerMeetingBackgroundColor.SelectedColor))


        End Sub
#End Region

#Region "DB Access"
        Private Function GetMeetingsByProductClass() As TIMSS.API.ApplicationInfo.IApplicationCodes
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            oAppCodes = GetApplicationCodes("MTG", "Product_Class", True)

            Return oAppCodes
        End Function

        Private Function GetBreakOutSessionsByProductClass() As ArrayList
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            Dim appCodes As New ArrayList
            oAppCodes = GetApplicationCodes("MTG", "Product_Class", True)
            For Each appCode As TIMSS.API.ApplicationInfo.IApplicationCode In oAppCodes
                If appCode.Option1 = "S" Then
                    appCodes.Add(appCode)
                End If
            Next

            Return appCodes
        End Function

        Private Function GetMeetingsByProductCategory() As TIMSS.API.ApplicationInfo.IApplicationCodes
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            oAppCodes = GetApplicationCodes("MTG", "Product_Category", True)

            Return oAppCodes
        End Function

        Private Function ReplaceSpecialCharacters(ByVal Code As String) As String
            Return Code.Replace("/", "")
        End Function

#End Region


        Class CodeInfo
            Public Code As String
            Public CodeDescription As String
            Public checked As Boolean
        End Class
        
    End Class

End Namespace
