Option Strict Off
Imports System
Imports System.Web.UI.WebControls
Imports Personify
Imports Telerik.Web.ui

Namespace Personify.DNN.Modules.Calendar
    Public MustInherit Class AdvancedEditForm
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase



#Region "Controls"
        Public WithEvents lblTimeValue As Label
        Public WithEvents lblLocationValue As Label
        Public WithEvents lblName As Label
        Public WithEvents lblDescription As Label

        Public WithEvents lnkRegister As LinkButton
        Public WithEvents lnkAddToWaitList As LinkButton
#End Region
#Region "Properties"

#End Region




        Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim i As Integer
            i = 0



        End Sub




    End Class
End Namespace

