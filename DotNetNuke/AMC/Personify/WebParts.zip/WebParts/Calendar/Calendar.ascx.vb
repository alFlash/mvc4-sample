Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Threading
Imports System.Web.Mail
Imports Personify.DNN.Modules.Calendar.Business
Imports Personify.ShoppingCartManager.Business
Imports TIMSS.SQLObjects
Imports Telerik.Web.ui

Namespace Personify.DNN.Modules.Calendar

    Public MustInherit Class Calendar
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


#Region "Controls"
        Public WithEvents RadSchedulerCalendar As Telerik.Web.UI.RadScheduler
        'Public WithEvents RadAjaxManager1 As Telerik.Web.UI.RadAjaxManager
        Public WithEvents RadWindowManager1AdvancedForm As Telerik.Web.UI.RadWindowManager
        Public EditForm As String

        Public WithEvents lblCalendarTitle As Label

        Public WithEvents lblFilterByMeeting As Label
        Public WithEvents drpFilterByMeeting As DropDownList
        Public WithEvents lblFilterByTrack As Label
        Public WithEvents drpFilterByTrack As DropDownList

        Public WithEvents cmdSwitchToTextMode As LinkButton
        Public WithEvents cmdPrintCalendar As LinkButton

        Public WithEvents pnlMain As Panel

        Public WithEvents lblTimeValue As Label
        Public WithEvents lblLocationValue As Label
        Public WithEvents lnkName As LinkButton
        Public WithEvents lblDescription As Label
        Public WithEvents MeetingPricePlaceHolder As PlaceHolder

        Public WithEvents lnkRegister As LinkButton
        Public WithEvents lnkAddToWishList As LinkButton
        Public WithEvents pnlEdit As Panel

        Public WithEvents pnlTextMode As Panel
        Public WithEvents dlMeetingsTextMode As DataList
        Public WithEvents drpSortTextMode As DropDownList
#End Region

#Region "Constants"
        Private Const C_CALENDAR_TITLE As String = "CalendarTitle"
        Private Const C_CALENDAR_Detail_WINDOW_ACTION_URL As String = "CalendarDetailWindowActionURL"
        Private Const C_CALENDAR_PRODUCT_DETAIL_ACTION_URL As String = "CalendarProductDetailActionURL"
        Private Const C_CALENDAR_SKIN As String = "CalendarSkin"

        Private Const C_CALENDAR_TIMEFRAME As String = "CalendarTimeFrame"
        Private Const C_CALENDAR_TIMEFRAME_DATE As String = "CalendarTimeFrameDate"


        Private Const C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS As String = "CalendarHideMembersOnlyFromNonMembers"
        Private Const C_ENABLE_TEXT_MODE As String = "CalendarEnableTextMode"
        Private Const C_ALLOW_PRINTING As String = "CalendarAllowPrinting"
        Private Const C_DEFAULT_DISPLAY_MODE As String = "CalendarDefaultDisplayMode"


        Private Const C_CELL_BORDER_COLOR As String = "CellBorderColor"
        Private Const C_CELL_BACKGROUND_COLOR As String = "CellBackgroundColor"
        Private Const C_MEETING_BACKGROUND_COLOR As String = "MeetingBackgroundColor"

        Private Const C_CALENDAR_MODE As String = "CalendarMode"

        Private Const C_DETAIL_WINDOW_WIDTH As String = "DetailWindowWidth"
        Private Const C_DETAIL_WINDOW_HEIGHT As String = "DetailWindowHeight"
        Private Const C_REPORT_PATH As String = "ReportPath"
#End Region

#Region "Properties"
        Public MeetingOrSession As String

        Public CellBorderColor As String
        Public CellBackgroundColor As String
        Public MeetingBackgroundColor As String

        Private DetailWindowActionURL As Integer

        Public DetailWindowMode As Boolean
        Public ParentProduct As String

        Public DetailWindowWidth As Integer
        Public DetailWindowHeight As Integer

        Public DetailProductId As Integer
        Public Property ProductDetailWindow() As Integer
            'store thye ProductId which will be opened in ProductDetail 
            Get
                If Session("ProductDetailWindow") Is Nothing Then
                    Return 0
                Else
                    Return CInt(Session("ProductDetailWindow"))
                End If
            End Get
            Set(ByVal value As Integer)
                Session("ProductDetailWindow") = value
            End Set
        End Property
        Private Property TextMode() As Boolean
            Get
                If ViewState("TextMode") Is Nothing Then
                    Return False
                Else
                    Return CBool(ViewState("TextMode"))
                End If
            End Get
            Set(ByVal value As Boolean)
                ViewState("TextMode") = value
            End Set
        End Property
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If ProductDetailWindow > 0 And Page.IsPostBack Then
                    If Settings(C_CALENDAR_PRODUCT_DETAIL_ACTION_URL) IsNot Nothing Then
                        Dim ProductDetailTabId As Integer = 0
                        ProductDetailTabId = CInt(Settings(C_CALENDAR_PRODUCT_DETAIL_ACTION_URL))
                        Response.Redirect(NavigateURL(ProductDetailTabId, "", "ProductId=" & ProductDetailWindow))
                    End If
                End If

                DetailWindowMode = False
                If Settings(C_CALENDAR_MODE) IsNot Nothing Then
                    If CStr(Settings(C_CALENDAR_MODE)) <> "0" Then
                        DetailWindowMode = True
                    End If
                End If


                Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "WindowClose", "<script language='javascript'>WindowClose()</script>")

                MeetingOrSession = Localization.GetString("Meeting", LocalResourceFile)
                MeetingBackgroundColor = String.Empty


                'when Switch to text mode button is pressed
                If Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").IndexOf("cmdSwitchToTextMode") >= 0 Then
                    TextMode = True
                End If

                If Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").IndexOf("lnkAddToWishList") >= 0 Then
                    AddToWishList()
                End If

                If Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").IndexOf("lnkRegister") >= 0 Then
                    AddToCart()
                End If

                If TextMode And Not DetailWindowMode Then
                    'TextMode panel is shown
                    ShowTextModePanel()
                    ProductDetailWindow = 0
                Else
                    'Calendar panel is shown
                    If Request.QueryString("Mode") Is Nothing And Not DetailWindowMode Then
                        ShowCalendarPanel()
                        ProductDetailWindow = 0
                    ElseIf Request.QueryString("Mode") IsNot Nothing AndAlso Request.QueryString("Mode").IndexOf("Edit") >= 0 AndAlso DetailWindowMode Then
                        ShowDetailPanelByAppointmentId()
                    ElseIf Request.QueryString("Mode") IsNot Nothing AndAlso Request.QueryString("Mode").IndexOf("TextMode") >= 0 AndAlso DetailWindowMode Then
                        ShowDetailPanelByMeetingId()
                    Else
                        pnlMain.Visible = False
                        pnlEdit.Visible = False
                        pnlTextMode.Visible = False
                    End If

                End If

                If Not DetailWindowMode Then
                    'this will fix the calendar on the first available Meeting
                    FixOnFirstMeeting()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        
        Private Sub AddToCart() 'lnkRegister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkRegister.Click
            'Add to cart
            Dim mi As MeetingInfo = Nothing
            If Request.QueryString("AppointmentId") IsNot Nothing Then
                mi = FindById(Request.QueryString("AppointmentId").ToString)
            End If

            If Request.QueryString("MeetingId") IsNot Nothing Then
                mi = FindByMeetingId(CInt(Request.QueryString("MeetingId").ToString))
            End If
            If mi IsNot Nothing Then
                Dim meetingId As Integer = CInt(mi.MeetingID)

                'Dim lg As New Personify.WebUtility.LoginCustomer
                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)
                'If lg IsNot Nothing Then
                '    Dim MasterCustomerId As String = lg.MasterCustomerId
                '    Dim SubCustomerId As Integer = lg.SubCustomerId

                AddToCommonControl_ButtonClick(MasterCustomerId, SubCustomerId, meetingId, False)
                'End If
            End If
        End Sub
        Private Sub AddToWishList() '_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkAddToWishList.Click
            'Add to WishList
            Dim mi As MeetingInfo = Nothing
            If Request.QueryString("AppointmentId") IsNot Nothing Then
                mi = FindById(Request.QueryString("AppointmentId").ToString)
            End If

            If Request.QueryString("MeetingId") IsNot Nothing Then
                mi = FindByMeetingId(CInt(Request.QueryString("MeetingId").ToString))
            End If
            If mi IsNot Nothing Then
                Dim meetingId As Integer = CInt(mi.MeetingID)

                'Dim lg As New Personify.WebUtility.LoginCustomer
                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)
                'If lg IsNot Nothing Then
                '    Dim MasterCustomerId As String = lg.MasterCustomerId
                '    Dim SubCustomerId As Integer = lg.SubCustomerId

                AddToCommonControl_ButtonClick(MasterCustomerId, SubCustomerId, meetingId, True)
                'End If
            End If
        End Sub

        Private Sub lnkName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkName.Click
            'Add to cart
            Dim mi As MeetingInfo = Nothing
            If Request.QueryString("AppointmentId") IsNot Nothing Then
                mi = FindById(Request.QueryString("AppointmentId").ToString)
            End If

            If Request.QueryString("MeetingId") IsNot Nothing Then
                mi = FindByMeetingId(CInt(Request.QueryString("MeetingId").ToString))
            End If
            If mi IsNot Nothing Then
                Dim meetingId As Integer = CInt(mi.MeetingID)

                ProductDetailWindow = meetingId
                Response.Redirect(NavigateURL(TabId, "", "Mode=Edit&MeetingId=mi.MeetingId"))
            End If
        End Sub

        Private Sub cmdPrintCalendar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrintCalendar.Click
            'when Print button is pressed
            Dim ReportPath As String = CStr(Settings(C_REPORT_PATH)) '"PersonifyEBIZ/Data Analyzer Reports/Meetings/Calendar Report For Meetings (Web Enabled)" '"Personify711/Data Analyzer Reports/Meetings/Calendar Report For Meetings (Web Enabled)"
            Dim status As String = String.Empty
            Dim ReportParameters As New System.Collections.Specialized.NameValueCollection
            Dim StartDate As DateTime = DateTime.Now
            Dim EndDate As Date = Nothing
            If Settings(C_CALENDAR_TIMEFRAME) IsNot Nothing AndAlso CStr(Settings(C_CALENDAR_TIMEFRAME)) <> String.Empty Then
                Select Case CInt(Settings(C_CALENDAR_TIMEFRAME))
                    Case 0
                        'current date+ 3 months
                        EndDate = Date.Now.AddMonths(3)
                    Case 1
                        'current date+ 6 months
                        EndDate = Date.Now.AddMonths(6)
                    Case 2
                        'current date+ 12 months
                        EndDate = Date.Now.AddMonths(12)
                    Case 3
                        'till date
                        EndDate = Date.Parse(CStr(Settings(C_CALENDAR_TIMEFRAME_DATE)))
                End Select
            End If
            Dim MeetingMembersOnly As String = "N"
            If Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS) IsNot Nothing Then
                MeetingMembersOnly = CStr(Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS))
            End If
            ReportParameters.Add("StartDate", StartDate.ToString("MM/dd/yyyy"))
            ReportParameters.Add("EndDate", EndDate.ToString("MM/dd/yyyy"))
            ReportParameters.Add("MeetingMembersOnly", MeetingMembersOnly)
            Dim url As String = String.Empty
            'url = Personify.ApplicationManager.Reporting.GetReportURL(PortalId, ReportPath, ReportParameters, status)
            Dim ReportInstance As Boolean = False
            Dim ReportKind As String = ""
            Dim LastRunDateTime As String = ""

            Dim _clsReport As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)

            url = _clsReport.GenerateReportURL(PortalId, ReportPath, ReportInstance, status, ReportKind, LastRunDateTime)
            _clsReport = Nothing
            If url.Length > 0 Then
                url = url & "&lsSStartDate=" & StartDate & "&lsSEndDate=" & EndDate & "&lsSMeetingMembersOnly=" & MeetingMembersOnly
                Response.Write("<script type='text/javascript'>detailedresults=window.open('" & url & "');</script>")
            Else
                Exit Sub
            End If
        End Sub
    

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


        Protected Sub RadSchedulerCalendar_TimeSlotCreated(ByVal sender As System.Object, ByVal e As TimeSlotCreatedEventArgs) Handles RadSchedulerCalendar.TimeSlotCreated
            'display meetings within the following timeframe
            Dim CalendarEndDate As Date = Nothing
            If Settings(C_CALENDAR_TIMEFRAME) IsNot Nothing AndAlso CStr(Settings(C_CALENDAR_TIMEFRAME)) <> String.Empty Then
                Select Case CInt(Settings(C_CALENDAR_TIMEFRAME))
                    Case 0
                        'current date+ 3 months
                        CalendarEndDate = Date.Now.AddMonths(3)
                    Case 1
                        'current date+ 6 months
                        CalendarEndDate = Date.Now.AddMonths(6)
                    Case 2
                        'current date+ 12 months
                        CalendarEndDate = Date.Now.AddMonths(12)
                    Case 3
                        'till date
                        CalendarEndDate = Date.Parse(CStr(Settings(C_CALENDAR_TIMEFRAME_DATE)))
                End Select
            End If
            If Not (e.TimeSlot.Start >= Date.Now And e.TimeSlot.End <= CalendarEndDate) Then
                e.TimeSlot.CssClass = "enforceTimeFrame"
            End If
        End Sub

        Public Class MeetingInfo
            Private _id As String
            Private _subject As String
            Private _start As DateTime
            Private _end As DateTime
            Private _location As String
            Private _parentProduct As String
            Private _productTypeCode As String
            Private _track As String

            Private _recurParentID As String
            Private _recurData As String
            Private _recurState As RecurrenceState

            Private _description As String

            Private _meetingId As Integer

            Public Property ID() As String
                Get
                    Return _id
                End Get
                Set(ByVal value As String)
                    _id = value
                End Set
            End Property
            Public Property Subject() As String
                Get
                    Return _subject
                End Get
                Set(ByVal value As String)
                    _subject = value
                End Set
            End Property
            Public Property Start() As DateTime
                Get
                    Return _start
                End Get
                Set(ByVal value As DateTime)
                    _start = value
                End Set
            End Property
            Public Property [End]() As DateTime
                Get
                    Return _end
                End Get
                Set(ByVal value As DateTime)
                    _end = value
                End Set
            End Property
            Public Property Location() As String
                Get
                    Return _location
                End Get
                Set(ByVal value As String)
                    _location = value
                End Set
            End Property
            Public Property ParentProduct() As String
                Get
                    Return _parentProduct
                End Get
                Set(ByVal value As String)
                    _parentProduct = value
                End Set
            End Property

            Public Property ProductTypeCode() As String
                Get
                    Return _productTypeCode
                End Get
                Set(ByVal value As String)
                    _productTypeCode = value
                End Set
            End Property

            Public Property Track() As String
                Get
                    Return _track
                End Get
                Set(ByVal value As String)
                    _track = value
                End Set
            End Property


            Public Property Description() As String
                Get
                    Return _description
                End Get
                Set(ByVal value As String)
                    _description = value
                End Set
            End Property

            Public Property MeetingID() As Integer
                Get
                    Return _meetingId
                End Get
                Set(ByVal value As Integer)
                    _meetingId = value
                End Set
            End Property


            Public Property RecurrenceRule() As String
                Get
                    Return _recurData
                End Get
                Set(ByVal value As String)
                    _recurData = value
                End Set
            End Property
            Public Property RecurrenceParentID() As String
                Get
                    Return _recurParentID
                End Get
                Set(ByVal value As String)
                    _recurParentID = value
                End Set
            End Property
            Public Property RecurrenceState() As RecurrenceState
                Get
                    Return _recurState
                End Get
                Set(ByVal value As RecurrenceState)
                    _recurState = value
                End Set
            End Property

            Private Sub New()
                Me.ID = Guid.NewGuid().ToString()
            End Sub
            Public Sub New(ByVal subject As String, ByVal start As DateTime, _
                           ByVal [end] As DateTime, ByVal location As String, ByVal parentProduct As String, ByVal productTypeCode As String, ByVal track As String, ByVal description As String, ByVal meetingID As Integer)
                Me.New()
                Me._subject = subject
                Me._start = start
                Me._end = [end]
                Me._location = location
                Me._parentProduct = parentProduct
                Me._productTypeCode = productTypeCode
                Me._track = track
                Me._description = Description
                Me._meetingId = meetingID
            End Sub            
        End Class





#Region "Helper functions"
        Private Const AppointmentsKey As String = _
                      "Telerik.Examples.Scheduler.BindToList_Apts"
        Private Property Meetings() As ArrayList
            Get
                Dim sessApts As ArrayList = _
                  TryCast(Session(AppointmentsKey), ArrayList)
                If sessApts Is Nothing Then
                    sessApts = New ArrayList
                    Session(AppointmentsKey) = sessApts
                End If
                Return sessApts
            End Get
            Set(ByVal value As ArrayList)
                Dim sessApts As New ArrayList
                Session(AppointmentsKey) = sessApts
            End Set
        End Property


        Private Function FindById(ByVal ID As String) As MeetingInfo
            For Each ai As MeetingInfo In Meetings
                If ai.ID = ID Then
                    Return ai
                End If
            Next
            Return Nothing
        End Function

        Private Function FindByMeetingId(ByVal MeetingID As Integer) As MeetingInfo
            For Each ai As MeetingInfo In Meetings
                If ai.MeetingID = MeetingID Then
                    Return ai
                End If
            Next
            Return Nothing
        End Function


        Private Sub LoadMeetings()
            Meetings = New ArrayList
            'filter by meeting
            Dim meetingId As Integer = 0
            If Not TextMode Then
                meetingId = CInt(drpFilterByMeeting.SelectedValue)
            End If
            'filter by track
            Dim trackCode As String = String.Empty
            If Not TextMode Then
                trackCode = CStr(drpFilterByTrack.SelectedValue)
                If trackCode = "0" Then trackCode = String.Empty
            End If

            'members only
            Dim MembersOnly As Boolean = False
            If Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS) IsNot Nothing Then
                MembersOnly = CBool(IIf(CStr(Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS)) = "Y", True, False))
            End If

            'restrict meetings by product class          
            Dim codesRestrictMeetingsByProductClass As String =  GetMeetingsByProductClass()

            'restrict break out sessions by product class
            Dim codesRestrictBreakOutSessionsByProductClass As String = GetBreakOutSessionsByProductClass()

            'restrict meetings/events by category
            Dim codesRestrictMeetingsByProductCategory As String = GetMeetingsByProductCategory()

            'display meetings within the following timeframe
            Dim CalendarEndDate As Date = Nothing
            If Settings(C_CALENDAR_TIMEFRAME) IsNot Nothing AndAlso CStr(Settings(C_CALENDAR_TIMEFRAME)) <> String.Empty Then
                Select Case CInt(Settings(C_CALENDAR_TIMEFRAME))
                    Case 0
                        'current date+ 3 months
                        CalendarEndDate = Date.Now.AddMonths(3)
                    Case 1
                        'current date+ 6 months
                        CalendarEndDate = Date.Now.AddMonths(6)
                    Case 2
                        'current date+ 12 months
                        CalendarEndDate = Date.Now.AddMonths(12)
                    Case 3
                        'till date
                        CalendarEndDate = Date.Parse(CStr(Settings(C_CALENDAR_TIMEFRAME_DATE)))
                End Select
            End If

            Dim SortByDate As Boolean = False
            Dim SortByMeeting As Boolean = False
            If Not TextMode Then
                SortByDate = False
                SortByMeeting = False
            Else
                If drpSortTextMode.SelectedValue = "0" Then
                    SortByDate = True
                    SortByMeeting = False
                Else
                    SortByDate = False
                    SortByMeeting = True
                End If
            End If

            Dim oQueryResult As IQueryResult
            oQueryResult = GetExecRequestMeetings(meetingId, trackCode, MembersOnly, codesRestrictMeetingsByProductClass, codesRestrictBreakOutSessionsByProductClass, codesRestrictMeetingsByProductCategory, CalendarEndDate, SortByDate, SortByMeeting)
            Dim tempMeetings As New ArrayList

            If oQueryResult IsNot Nothing Then
                If oQueryResult.ValidationMessages IsNot Nothing AndAlso oQueryResult.ValidationMessages.Count > 0 Then
                Else
                    For Each row As DataRow In oQueryResult.DataSet.Tables(0).Rows
                        Dim newApp As MeetingInfo = AddMeetingToMeetings(row)
                        If newApp IsNot Nothing Then                            
                            tempMeetings.Add(newApp)
                        End If
                    Next
                End If
            End If

            'extract only sessions and meetings without sessions to be shown in Calendar
            For Each m As MeetingInfo In tempMeetings
                If m.ProductTypeCode = "S" Then
                    Meetings.Add(m)
                End If
                If m.ProductTypeCode = "M" Then
                    Dim MeetingWithSessions As Boolean = False
                    For Each mSession As MeetingInfo In tempMeetings
                        If mSession.ProductTypeCode = "S" And mSession.ParentProduct = m.ParentProduct Then
                            MeetingWithSessions = True
                            Exit For
                        End If
                    Next
                    If Not MeetingWithSessions Then
                        Meetings.Add(m)
                    End If
                End If

            Next

        End Sub



        Private Sub LoadSettings()
            If Settings(C_CALENDAR_TITLE) IsNot Nothing Then
                lblCalendarTitle.Text = CStr(Settings(C_CALENDAR_TITLE))
            End If

            If Settings(C_CALENDAR_Detail_WINDOW_ACTION_URL) IsNot Nothing Then
                DetailWindowActionURL = CInt(Settings(C_CALENDAR_Detail_WINDOW_ACTION_URL))
            Else
                DetailWindowActionURL = TabId
            End If
            EditForm = NavigateURL(DetailWindowActionURL) 'TabId) ', "EDITFORM", "")
            If Settings(C_CALENDAR_SKIN) IsNot Nothing Then
                RadSchedulerCalendar.Skin = CStr(Settings(C_CALENDAR_SKIN))
           End If

            If Not IsPostBack Then
                If Settings(C_DEFAULT_DISPLAY_MODE) IsNot Nothing Then
                    Select Case CInt(Settings(C_DEFAULT_DISPLAY_MODE))
                        Case 0
                            'day view
                            RadSchedulerCalendar.SelectedView = SchedulerViewType.DayView
                        Case 1
                            'week view
                            RadSchedulerCalendar.SelectedView = SchedulerViewType.WeekView
                        Case 2
                            'month view
                            RadSchedulerCalendar.SelectedView = SchedulerViewType.MonthView
                        Case 3
                            'timeline view
                            RadSchedulerCalendar.SelectedView = SchedulerViewType.TimelineView
                    End Select
                End If
            End If

            'members only
            Dim MeetingsList As New ArrayList
            Dim MembersOnly As Boolean = False
            If Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS) IsNot Nothing Then
                MembersOnly = CBool(IIf(CStr(Settings(C_HIDE_MEMBERS_ONLY_FROM_NON_MEMBERS)) = "Y", True, False))
            End If

            'restrict meetings by product class          
            Dim codesRestrictMeetingsByProductClass As String = GetMeetingsByProductClass()

            'restrict break out sessions by product class
            Dim codesRestrictBreakOutSessionsByProductClass As String = GetBreakOutSessionsByProductClass()

            'restrict meetings/events by category
            Dim codesRestrictMeetingsByProductCategory As String = GetMeetingsByProductCategory()


            'display meetings within the following timeframe
            Dim CalendarEndDate As Date = Nothing
            If Settings(C_CALENDAR_TIMEFRAME) IsNot Nothing AndAlso CStr(Settings(C_CALENDAR_TIMEFRAME)) <> String.Empty Then
                Select Case CInt(Settings(C_CALENDAR_TIMEFRAME))
                    Case 0
                        'current date+ 3 months
                        CalendarEndDate = Date.Now.AddMonths(3)
                    Case 1
                        'current date+ 6 months
                        CalendarEndDate = Date.Now.AddMonths(6)
                    Case 2
                        'current date+ 12 months
                        CalendarEndDate = Date.Now.AddMonths(12)
                    Case 3
                        'till date
                        CalendarEndDate = Date.Parse(CStr(Settings(C_CALENDAR_TIMEFRAME_DATE)))
                End Select
            End If

            Dim oQueryResult As IQueryResult
            oQueryResult = GetExecRequestMeetings(0, String.Empty, MembersOnly, codesRestrictMeetingsByProductClass, codesRestrictBreakOutSessionsByProductClass, codesRestrictMeetingsByProductCategory, CalendarEndDate, False, True)

            Dim tracks As New Hashtable
            Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("MTG", "SESSION_TRACK", True)

            If oQueryResult IsNot Nothing Then
                If oQueryResult.ValidationMessages IsNot Nothing AndAlso oQueryResult.ValidationMessages.Count > 0 Then
                Else
                    For Each row As DataRow In oQueryResult.DataSet.Tables(0).Rows
                        Dim StartDate As DateTime = DateTime.Now
                        Dim EndDate As DateTime = DateTime.Now
                        If row("START_DATE") IsNot System.DBNull.Value Then
                            StartDate = CType(row("START_DATE"), DateTime)
                        End If
                        If row("END_DATE") IsNot System.DBNull.Value Then
                            EndDate = CType(row("END_DATE"), DateTime)
                        End If
                        If StartDate < EndDate Then
                            If row("PRODUCT_TYPE_CODE") IsNot System.DBNull.Value Then
                                If CStr(row("PRODUCT_TYPE_CODE")) <> "S" Then
                                    Dim newApp As MeetingInfo = AddMeetingToMeetings(row)
                                    MeetingsList.Add(newApp)
                                End If
                                If row("SESSION_TRACK_CODE") IsNot System.DBNull.Value Then
                                    If CStr(row("SESSION_TRACK_CODE")) <> String.Empty Then
                                        If Not tracks.ContainsKey(CStr(row("SESSION_TRACK_CODE"))) Then
                                            For Each code As TIMSS.API.ApplicationInfo.IApplicationCode In appCodes
                                                If code.Code = CStr(row("SESSION_TRACK_CODE")) Then
                                                    tracks.Add(code.Code, code.Description)
                                                End If
                                            Next                                           
                                        End If
                                    End If
                                End If

                            End If
                        End If
                    Next

                End If
            End If


            If MeetingsList IsNot Nothing Then
                If Not Page.IsPostBack Then
                    For Each meeting As MeetingInfo In MeetingsList
                        drpFilterByMeeting.Items.Add(New ListItem(meeting.Subject, CStr(meeting.MeetingID)))
                    Next
                End If
            End If

            'load tracks
            If Not Page.IsPostBack Then
                For Each track As String In tracks.Keys                    
                    drpFilterByTrack.Items.Add(New ListItem(CStr(tracks(track)), track))
                Next
            End If


            'Switch to Text Mode linkbutton
            If Settings(C_ENABLE_TEXT_MODE) IsNot Nothing Then
                cmdSwitchToTextMode.Visible = CBool(IIf(CStr(Settings(C_ENABLE_TEXT_MODE)) = "Y", True, False))
            End If

            'Print Calendar linkbutton
            If Settings(C_ALLOW_PRINTING) IsNot Nothing Then
                cmdPrintCalendar.Visible = CBool(IIf(CStr(Settings(C_ALLOW_PRINTING)) = "Y", True, False))
                If cmdPrintCalendar.Visible Then
                    'set the onclick attribute for Print button to trigger the JavaScript function PrintWindow
                    cmdPrintCalendar.Attributes.Add("onclick", "PrintWindow(this)")
                End If
            End If

            CellBackgroundColor = String.Empty
            If Settings(C_CELL_BACKGROUND_COLOR) IsNot Nothing Then
                CellBackgroundColor = CStr(Settings(C_CELL_BACKGROUND_COLOR))
            End If
            CellBorderColor = String.Empty
            If Settings(C_CELL_BORDER_COLOR) IsNot Nothing Then
                CellBorderColor = CStr(Settings(C_CELL_BORDER_COLOR))
            End If

            If Settings(C_DETAIL_WINDOW_WIDTH) IsNot Nothing Then
                DetailWindowWidth = CInt(Settings(C_DETAIL_WINDOW_WIDTH))
            End If
            If Settings(C_DETAIL_WINDOW_HEIGHT) IsNot Nothing Then
                DetailWindowHeight = CInt(Settings(C_DETAIL_WINDOW_HEIGHT))
            End If
        End Sub

        Public Function AddMeetingToMeetings(ByVal row As DataRow) As MeetingInfo
            Dim StartDate As DateTime = DateTime.Now
            Dim EndDate As DateTime = DateTime.Now
            Dim ShortName As String = String.Empty
            Dim FacilityName As String = String.Empty
            Dim parentProduct As String = String.Empty
            Dim ProductTypeCode As String = String.Empty
            Dim SessionTrack As String = String.Empty
            Dim Description As String = String.Empty
            Dim mID As Integer = 0

            If row("START_DATE") IsNot System.DBNull.Value Then
                StartDate = CType(row("START_DATE"), DateTime)
            End If
            If row("END_DATE") IsNot System.DBNull.Value Then
                EndDate = CType(row("END_DATE"), DateTime)
            End If
            If row("SHORT_NAME") IsNot System.DBNull.Value Then
                ShortName = CStr(row("SHORT_NAME"))
            End If

            If row("FACILITYNAME") IsNot System.DBNull.Value Then
                FacilityName = CStr(row("FACILITYNAME"))
            End If

            If row("PARENT_NAME") IsNot System.DBNull.Value Then
                parentProduct = CStr(row("PARENT_NAME"))
            End If

            If row("PRODUCT_TYPE_CODE") IsNot System.DBNull.Value Then
                ProductTypeCode = CStr(row("PRODUCT_TYPE_CODE"))
            End If

            If row("SESSION_TRACK_CODE") IsNot System.DBNull.Value Then
                SessionTrack = CStr(row("SESSION_TRACK_CODE"))
            End If

            If row("WEB_LONG_DESCRIPTION") IsNot System.DBNull.Value Then
                Description = CStr(row("WEB_LONG_DESCRIPTION"))
            End If

            If row("PRODUCT_ID") IsNot System.DBNull.Value Then
                mID = CInt(row("PRODUCT_ID"))
            End If
            If StartDate < EndDate Then
                Dim newApp As New MeetingInfo(ShortName, StartDate, EndDate, FacilityName, parentProduct, ProductTypeCode, SessionTrack, Description, mID)
                Return newApp
            Else
                Return Nothing
            End If
        End Function
        ''' <summary>
        ''' main AddToCartControl onclick
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub AddToCommonControl_ButtonClick( _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
         ByVal ProductId As Integer, _
        ByVal isWishList As Boolean _
        )
            Try


                Dim q As Integer = 1
                Dim ProductDetails As ProductDetails = _
                                    get_clsProductHelper.GetAllDetailsForAProduct(ProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True)

                If ProductDetails.ProductType = "S" Then
                    'product to be added its a session of a meeting

                    Dim ParentProductId As Integer = CInt(GetMeetingInfo(ProductId)(0).ParentProductID) 'CInt(ProductDetails.MeetingInfo(0).ParentProductID)
                    Dim MeetingExists As Boolean = False
                    Dim SessionExists As Boolean = False

                    Dim MainCartItemId As Integer = 0

                    Dim oCartInfo As New MiniShoppingCartInfo
                    Dim oManager As New ShoppingCartController
                    'Dim lg As New Personify.WebUtility.LoginCustomer
                    'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                    Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, isWishList, True)
                    For Each item As ShoppingCartInfo In AList
                        If item.ProductId = ParentProductId And item.RelatedCartItemId = 0 Then
                            MeetingExists = True
                            MainCartItemId = item.CartItemId
                        End If
                        If item.SubProductId = ProductId Then
                            SessionExists = True
                        End If
                    Next
                    If MeetingExists Then
                        If Not SessionExists Then

                            AddToCart(MasterCustomerId, SubCustomerId, ParentProductId, ProductId, ProductDetails, q, isWishList, MainCartItemId)
                        End If
                    Else
                        Dim ParentProductDetails As ProductDetails = _
                                                            get_clsProductHelper.GetAllDetailsForAProduct(ParentProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True)
                        MainCartItemId = AddToCart(MasterCustomerId, SubCustomerId, ParentProductId, 0, ParentProductDetails, q, isWishList, -1)

                        AddToCart(MasterCustomerId, SubCustomerId, ParentProductId, ProductId, ProductDetails, q, isWishList, MainCartItemId)
                    End If

                Else
                    'product to be added its a meeting
                    AddToCart(MasterCustomerId, SubCustomerId, ProductId, 0, ProductDetails, q, isWishList, -1)
                End If

                If isWishList = False Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        ''' <summary>
        ''' generic add to cart function
        ''' </summary>

        Private Function AddToCart( _
    ByVal MasterCustomerId As String, _
  ByVal SubCustomerId As Integer, _
   ByVal ProductID As Integer, _
  ByVal SubProductId As Integer, _
  ByVal ProductDetails _
  As ProductDetails, _
  ByVal Quantity As Integer, _
  ByVal IsWishList As Boolean, _
  Optional ByVal RelatedCartItemId As Integer = -1, _
  Optional ByVal isDirectPriceUpdate As Boolean = False) As Integer
            Try
                Dim CartItemId As Integer
                Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                Dim oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
                With oCartInfo
                    .Subsystem = ProductDetails.ProductInfo(0).Subsystem
                    .ProductType = ProductDetails.ProductInfo(0).ProductTypeCodeString
                    .RateStructure = ProductDetails.ListPrices(0).RateStructure
                    .RateCode = ProductDetails.ListPrices(0).RateCode
                    .MasterCustomerId = MasterCustomerId
                    .SubCustomerId = SubCustomerId
                    .LongName = ProductDetails.ProductInfo(0).LongName
                    .ShortName = ProductDetails.ProductInfo(0).ShortName
                    .Price = ProductDetails.ListPrices(0).Price
                    .Quantity = Quantity
                    .ProductId = ProductID
                    .SubProductId = SubProductId 'not 0
                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .MaxBadges = 0
                    .IsWishList = IsWishList
                    .IsDirectPriceUpdate = isDirectPriceUpdate

                    If ProductDetails.Components.Count > 0 Then
                        .ComponentExists = True
                    Else
                        .ComponentExists = False
                    End If

                    If RelatedCartItemId <> -1 Then
                        'Set here
                        .RelatedCartItemId = RelatedCartItemId
                    End If

                    If ProductDetails.ListPrices IsNot Nothing Then
                        If ProductDetails.ListPrices.Count > 0 Then
                            For i As Integer = 0 To ProductDetails.ListPrices.Count - 1
                                If ProductDetails.ListPrices(i).RateStructure = .RateStructure And ProductDetails.ListPrices(i).RateCode = .RateCode Then
                                    .MaxBadges = ProductDetails.ListPrices(i).MaxBadges
                                End If
                            Next
                        End If
                    End If

                    If ProductDetails.MemberPrices IsNot Nothing Then
                        If ProductDetails.MemberPrices.Count > 0 Then
                            For i As Integer = 0 To ProductDetails.MemberPrices.Count - 1
                                If ProductDetails.MemberPrices(i).RateStructure = .RateStructure And ProductDetails.MemberPrices(i).RateCode = .RateCode Then
                                    .MaxBadges = ProductDetails.MemberPrices(i).MaxBadges
                                End If
                            Next
                        End If
                    End If
                End With
                CartItemId = oCartController.AddToCart(oCartInfo)

                'Add to Shopping Cart Component
                Dim oComponentCartInfo As ShoppingCartManager.Business.ShoppingCartComponentInfo
                If ProductDetails.Components.Count > 0 Then
                    For i As Integer = 0 To ProductDetails.Components.Count - 1
                        oComponentCartInfo = New ShoppingCartManager.Business.ShoppingCartComponentInfo

                        With oComponentCartInfo
                            .CartItemId = CartItemId
                            .MasterCustomerId = MasterCustomerId
                            .SubCustomerId = SubCustomerId
                            .ProductId = ProductDetails.ProductId
                            .ComponentProductId = ProductDetails.Components(i).ProductId
                            .LongName = ProductDetails.Components(i).LongName
                            .ShortName = ProductDetails.Components(i).ShortName
                            .IsWishList = IsWishList
                            .ModuleId = ModuleId
                            .PortalId = PortalId
                            .AddDate = Date.Now()
                            .ModDate = Date.Now()
                        End With

                        oCartController.AddShoppingCartComponents(oComponentCartInfo)
                    Next
                End If

                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If

                Return (CartItemId)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Public Sub ShowCalendarPanel()
            pnlMain.Visible = True
            pnlEdit.Visible = False
            pnlTextMode.Visible = False


            LoadSettings()
           
            If Not IsPostBack Then

                Session.Remove(AppointmentsKey)
                RadSchedulerCalendar.DataKeyField = "ID"
                RadSchedulerCalendar.DataStartField = "Start"
                RadSchedulerCalendar.DataEndField = "End"
                RadSchedulerCalendar.DataSubjectField = "Subject"
                RadSchedulerCalendar.DataRecurrenceField = "RecurrenceRule"
                RadSchedulerCalendar.DataRecurrenceParentKeyField = "RecurrenceParentID"

                LoadMeetings()
                RadSchedulerCalendar.DataSource = Meetings
                'RadSchedulerCalendar.DataBind()
                dlMeetingsTextMode.DataBind()

            Else
                If Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").Contains("drpFilterBy") Then
                    LoadMeetings()
                    RadSchedulerCalendar.DataSource = Meetings
                    dlMeetingsTextMode.DataBind()
                End If
            End If
        End Sub
        Public Sub ShowDetailPanelByAppointmentId()
            pnlMain.Visible = False
            pnlEdit.Visible = True

            pnlTextMode.Visible = False
            If Request.QueryString("AppointmentId") IsNot Nothing Then
                Dim mi As MeetingInfo = FindById(Request.QueryString("AppointmentId").ToString)
                If mi IsNot Nothing Then
                    LoadDetailWindow(mi)
                End If
            End If

            If Settings(C_MEETING_BACKGROUND_COLOR) IsNot Nothing Then
                MeetingBackgroundColor = CStr(Settings(C_MEETING_BACKGROUND_COLOR))
            End If
        End Sub
        Public Sub ShowDetailPanelByMeetingId()
            pnlMain.Visible = False
            pnlEdit.Visible = True

            pnlTextMode.Visible = False
            If Request.QueryString("MeetingId") IsNot Nothing Then
                Dim mi As MeetingInfo = FindByMeetingId(CInt(Request.QueryString("MeetingId").ToString))
                If mi IsNot Nothing Then
                    LoadDetailWindow(mi)
                End If
            End If
            If Settings(C_MEETING_BACKGROUND_COLOR) IsNot Nothing Then
                MeetingBackgroundColor = CStr(Settings(C_MEETING_BACKGROUND_COLOR))
            End If
           
        End Sub
        Public Sub FixOnFirstMeeting()
            If Not ((Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Request.Params("__EVENTTARGET").IndexOf("RadSchedulerCalendar") >= 0)) Or Not Page.IsPostBack Then
                If Meetings IsNot Nothing AndAlso Meetings.Count > 0 Then
                    Dim minDateMeeting As MeetingInfo = Nothing
                    Dim firstLoop As Boolean = True
                    For Each meeting As MeetingInfo In Meetings
                        If firstLoop Then
                            minDateMeeting = meeting
                            firstLoop = False
                        End If
                        If meeting.Start < minDateMeeting.Start Then
                            minDateMeeting = meeting
                        End If
                    Next
                    RadSchedulerCalendar.SelectedDate = minDateMeeting.Start
                End If
            End If
        End Sub
#End Region

#Region "TextMode functions"

        Public Sub ShowTextModePanel()
            pnlMain.Visible = False
            pnlEdit.Visible = False
            pnlTextMode.Visible = True
            ParentProduct = String.Empty
            If Settings(C_CALENDAR_Detail_WINDOW_ACTION_URL) IsNot Nothing Then
                DetailWindowActionURL = CInt(Settings(C_CALENDAR_Detail_WINDOW_ACTION_URL))
            Else
                DetailWindowActionURL = TabId
            End If
            EditForm = NavigateURL(DetailWindowActionURL)
            LoadMeetings()
            dlMeetingsTextMode.DataSource = Meetings
            dlMeetingsTextMode.DataBind()

            If Settings(C_DETAIL_WINDOW_WIDTH) IsNot Nothing Then
                DetailWindowWidth = CInt(Settings(C_DETAIL_WINDOW_WIDTH))
            End If
            If Settings(C_DETAIL_WINDOW_HEIGHT) IsNot Nothing Then
                DetailWindowHeight = CInt(Settings(C_DETAIL_WINDOW_HEIGHT))
            End If
        End Sub
        Public Function ShowField1BasedOnSortCriteria(ByVal meeting As MeetingInfo) As String
            'based on sorting criterias Field1 can be Date or MeetingName 
            Dim field1 As String = String.Empty

            If TextMode Then
                If drpSortTextMode.SelectedValue = "0" Then
                    field1 = CStr(meeting.Start)
                Else
                    'If meeting.ProductTypeCode = "S" Then
                    If meeting.ParentProduct = ParentProduct Then
                        field1 = String.Empty
                    Else
                        field1 = meeting.ParentProduct
                        ParentProduct = meeting.ParentProduct
                    End If

                    'Else
                    'field1 = "<a href=""javascript:MeetingEdit('" & meeting.MeetingID & "')"">" & meeting.Subject & "</a>"
                    'End If
                End If
            End If
            Return field1
        End Function

        Public Function ShowField2BasedOnSortCriteria(ByVal meeting As MeetingInfo) As String
            'based on sorting criterias Field2 can be MeetingName-SessionName, MeetingName or Date
            Dim field2 As String = String.Empty
            If TextMode Then
                If drpSortTextMode.SelectedValue = "0" Then
                    If meeting.ProductTypeCode = "S" Then
                        field2 = "<a id=""" & meeting.MeetingID & """ href=""javascript:MeetingEdit('" & meeting.MeetingID & "')"">" & meeting.ParentProduct + ", " + meeting.Subject & "</a>"
                    Else
                        field2 = "<a id=""" & meeting.MeetingID & """ href=""javascript:MeetingEdit('" & meeting.MeetingID & "')"">" & meeting.Subject & "</a>"
                    End If
                Else
                    field2 = CStr(meeting.Start)
                End If
            End If
            Return field2
        End Function


        Public Function ShowField3BasedOnSortCriteria(ByVal meeting As MeetingInfo) As String
            'based on sorti-ng criterias Field3 can be SessionName
            Dim field3 As String = String.Empty
            If TextMode Then
                If drpSortTextMode.SelectedValue = "0" Then
                Else
                    'If meeting.ProductTypeCode = "S" Then
                    field3 = "<a id=""" & meeting.MeetingID & """ href=""javascript:MeetingEdit('" & meeting.MeetingID & "');"">" & meeting.Subject & "</a>"
                    'End If
                End If
            End If
            Return field3
        End Function

        Public Sub LoadDetailWindow(ByVal mi As MeetingInfo)

            If mi.ProductTypeCode = "S" Then
                lnkName.Text = mi.ParentProduct & " - " & mi.Subject
            Else
                lnkName.Text = mi.Subject
            End If
            lblTimeValue.Text = mi.Start.ToString("d") + "  " + mi.Start.ToShortTimeString + " - " + mi.End.ToShortTimeString
            lblLocationValue.Text = mi.Location

            Dim meetingDetails As ProductDetails = _
 get_clsProductHelper.GetAllDetailsForAProduct(mi.MeetingID, True, True, True, True, , , , , , True, True)


            Dim ExistsWishList As Boolean = False
            Dim ExistsCartList As Boolean = False

            If meetingDetails.ProductType = "S" Then
                'product to be added its a session of a meeting

                Dim ParentProductId As Integer = CInt(GetMeetingInfo(mi.MeetingID)(0).ParentProductID)
               
                Dim MainCartItemId As Integer = 0

                Dim oCartInfo As New MiniShoppingCartInfo
                Dim oManager As New ShoppingCartController
                'Dim lg As New Personify.WebUtility.LoginCustomer
                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)
                'Cart List
                Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False, True)
                For Each item As ShoppingCartInfo In AList                    
                    If item.SubProductId = mi.MeetingID Then
                        ExistsCartList = True
                        Exit For
                    End If
                Next
                AList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, True, True)
                For Each item As ShoppingCartInfo In AList
                    If item.SubProductId = mi.MeetingID Then
                        ExistsWishList = True
                        Exit For
                    End If
                Next
                

            Else
                Dim oCartInfo As New MiniShoppingCartInfo
                Dim oManager As New ShoppingCartController
                'Dim lg As New Personify.WebUtility.LoginCustomer
                'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)
                'Cart List
                Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False, True)
                For Each item As ShoppingCartInfo In AList
                    If item.ProductId = mi.MeetingID Then
                        ExistsCartList = True
                    End If
                Next
                'Wish List
                AList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, True, True)
                For Each item As ShoppingCartInfo In AList
                    If item.ProductId = mi.MeetingID Then
                        ExistsWishList = True
                        Exit For
                    End If
                Next

            End If


            If ExistsWishList Then
                lnkAddToWishList.Enabled = False
            Else
                lnkAddToWishList.Enabled = True
            End If
            If ExistsCartList Then
                lnkRegister.Enabled = False
            Else
                lnkRegister.Enabled = True
            End If

            Dim aPricingControl As New WebControls.PricingControl

            aPricingControl.ID = "ProductPricingControl" + ModuleId.ToString + "_" + mi.MeetingID.ToString
            aPricingControl.PortalID = PortalId
            aPricingControl.AllPrices = meetingDetails.AllPrices
            aPricingControl.ListPrices = meetingDetails.ListPrices
            aPricingControl.MemberPrices = meetingDetails.MemberPrices
            aPricingControl.YourPrices = meetingDetails.CustomerPrice

            aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
            aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
            aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)

            MeetingPricePlaceHolder.Controls.Add(aPricingControl)
            lblDescription.Text = mi.Description

        End Sub


#End Region

#Region "DB Access"
        Private Function GetMeetingsByProductClass() As String
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            oAppCodes = GetApplicationCodes("MTG", "Product_Class", True)

            Dim codes As String = String.Empty
            For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oAppCodes
                If Not Settings("RestrictMeetingsByProductClass_" & oCode.Code) Is Nothing AndAlso CStr(Settings("RestrictMeetingsByProductClass_" & oCode.Code)) = "Y" Then
                    If codes = String.Empty Then
                        codes = oCode.Code
                    Else
                        codes = codes + "," + oCode.Code
                    End If

                End If
            Next
            Return codes
        End Function

        Private Function GetBreakOutSessionsByProductClass() As String
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            Dim appCodes As New ArrayList
            oAppCodes = GetApplicationCodes("MTG", "Product_Class", True)
            For Each appCode As TIMSS.API.ApplicationInfo.IApplicationCode In oAppCodes
                If appCode.Option1 = "S" Then
                    appCodes.Add(appCode)
                End If
            Next


            Dim codes As String = String.Empty

            For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oAppCodes
                If Not Settings("RestrictBreakOutSessionsByProductClass_" & oCode.Code) Is Nothing AndAlso CStr(Settings("RestrictBreakOutSessionsByProductClass_" & oCode.Code)) = "Y" Then
                    If codes = String.Empty Then
                        codes = oCode.Code
                    Else
                        codes = codes + "," + oCode.Code
                    End If
                End If
            Next

            Return codes
        End Function

        Private Function GetMeetingsByProductCategory() As String
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            oAppCodes = GetApplicationCodes("MTG", "Product_Category", True)

            Dim codes As String = String.Empty

            For Each oCode As TIMSS.API.ApplicationInfo.IApplicationCode In oAppCodes
                If Not Settings("RestrictMeetingsByProductCategory_" & oCode.Code) Is Nothing AndAlso CStr(Settings("RestrictMeetingsByProductCategory_" & oCode.Code)) = "Y" Then
                    If codes = String.Empty Then
                        codes = oCode.Code
                    Else
                        codes = codes + "," + oCode.Code
                    End If
                End If
            Next
            Return codes
        End Function

#End Region

#Region "Personify"
        Private Function GetExecRequestMeetings(ByVal MeetingId As Integer, ByVal TrackCode As String, ByVal MembersOnly As Boolean, ByVal MeetingsProductClassCodes As String, ByVal BreakOutSessionsProductClassCodes As String, ByVal MeetingsProductCategoryCodes As String, ByVal MeetingDate As Date, ByVal SortByDate As Boolean, ByVal SortByMeeting As Boolean) As IQueryResult
            Try


                Dim strCacheKey As String = "PersonifyMeetingsForCalendar" & SortByDate & SortByMeeting & MeetingId & TrackCode & PortalId.ToString
                If PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then
                    Dim oQueryResult As IQueryResult
                    Dim query As IQueryRequest = GetExecRequest_T_Meetings(OrganizationId, OrganizationUnitId, MeetingId, TrackCode, MembersOnly, MeetingsProductClassCodes, BreakOutSessionsProductClassCodes, MeetingsProductCategoryCodes, MeetingDate, SortByDate, SortByMeeting)
                    oQueryResult = TIMSS.Global.App.Execute(query)

                    If oQueryResult.Success Then
                        PersonifyDataCache.Store(strCacheKey, oQueryResult)
                        Return PersonifyDataCache.Fetch(strCacheKey)
                    End If

                    Return Nothing
                Else
                    Return PersonifyDataCache.Fetch(strCacheKey)
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Private Function GetExecRequest_T_Meetings(ByVal OrganizationId As String, _
          ByVal OrganizationUnitId As String, _
          ByVal MeetingId As Integer, ByVal TrackCode As String, ByVal MembersOnly As Boolean, _
          ByVal MeetingsProductClassCodes As String, _
          ByVal BreakOutSessionsProductClassCodes As String, _
          ByVal MeetingsProductCategoryCodes As String, ByVal MeetingDate As Date, _
          ByVal SortByDate As Boolean, ByVal SortByMeeting As Boolean) _
          As IQueryRequest

            Dim nullString As String = Nothing
            Dim MeetingsStoredProcedureRequest As IStoredProcedureRequest = New StoredProcedureRequest("GET_CALENDAR_MEETINGS_SP")

            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_org_id", OrganizationId, ParameterDirection.Input))
            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_org_unit_id", OrganizationUnitId, ParameterDirection.Input))

            Dim filter_criteria As String = String.Empty
            If MeetingId <> 0 Then
                filter_criteria = "WEB1.PRODUCT_ID =" & MeetingId
            End If
            If TrackCode IsNot Nothing AndAlso TrackCode <> String.Empty Then
                If filter_criteria = String.Empty Then
                    filter_criteria = "WEB.SESSION_TRACK_CODE ='" & TrackCode & "'"
                Else
                    filter_criteria = filter_criteria & " AND WEB.SESSION_TRACK_CODE ='" & TrackCode & "'"
                End If
            End If

            If MeetingsProductClassCodes IsNot Nothing AndAlso MeetingsProductClassCodes <> String.Empty Then
                Dim codes As String = String.Empty
                For Each code As String In MeetingsProductClassCodes.Split(",")
                    If codes = String.Empty Then
                        codes = codes & "'" & code & "'"
                    Else
                        codes = codes & ", '" & code & "'"
                    End If
                Next
                If filter_criteria = String.Empty Then
                    filter_criteria = "WEB.PRODUCT_CLASS_CODE in (" & codes & ")"
                Else
                    filter_criteria = filter_criteria & " AND WEB.PRODUCT_CLASS_CODE in (" & codes & ")"
                End If

            End If
            'MembersOnly
            If MembersOnly Then
                If filter_criteria = String.Empty Then
                    filter_criteria = "WEB.MEMBERS_ONLY_FLAG ='" & IIf(MembersOnly, "Y", "N") & "'"
                Else
                    filter_criteria = filter_criteria & " AND WEB.MEMBERS_ONLY_FLAG ='" & IIf(MembersOnly, "Y", "N") & "'"
                End If
            End If

            'CurentDate
            Dim CurrentDate As Date = Date.Now
            If filter_criteria = String.Empty Then
                filter_criteria = "WEB.START_DATE >='" & CurrentDate & "'"
            Else
                filter_criteria = filter_criteria & " AND WEB.START_DATE >= '" & CurrentDate & "'"
            End If
            'MeetingDate
            If filter_criteria = String.Empty Then
                filter_criteria = "WEB.END_DATE >='" & MeetingDate & "'"
            Else
                filter_criteria = filter_criteria & " AND WEB.END_DATE <= '" & MeetingDate & "'"
            End If


            If BreakOutSessionsProductClassCodes IsNot Nothing AndAlso BreakOutSessionsProductClassCodes <> String.Empty Then
                Dim codes As String = String.Empty
                For Each code As String In BreakOutSessionsProductClassCodes.Split(",")
                    If codes = String.Empty Then
                        codes = codes & "'" & code & "'"
                    Else
                        codes = codes & ", '" & code & "'"
                    End If
                Next
                If filter_criteria = String.Empty Then
                    filter_criteria = "WEB.PRODUCT_CLASS_CODE in (" & codes & ") AND WEB.PRODUCT_TYPE_CODE = 'S'"
                Else
                    filter_criteria = filter_criteria & " AND WEB.PRODUCT_CLASS_CODE in (" & codes & ") AND WEB.PRODUCT_TYPE_CODE = 'S'"
                End If

            End If

            If MeetingsProductCategoryCodes IsNot Nothing AndAlso MeetingsProductCategoryCodes <> String.Empty Then
                Dim codes As String = String.Empty
                For Each code As String In MeetingsProductCategoryCodes.Split(",")
                    If codes = String.Empty Then
                        codes = codes & "'" & code & "'"
                    Else
                        codes = codes & ", '" & code & "'"
                    End If
                Next
                If filter_criteria = String.Empty Then
                    filter_criteria = "PC.CATEGORY in (" & codes & ")"
                Else
                    filter_criteria = filter_criteria & " AND PC.CATEGORY in (" & codes & ")"
                End If

            End If

            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_filter_criteria", filter_criteria, ParameterDirection.Input))

            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("sort_by_date", CStr(IIf(SortByDate, "Y", "N")), ParameterDirection.Input))
            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("sort_by_meeting", CStr(IIf(SortByMeeting, "Y", "N")), ParameterDirection.Input))


            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("op_ErrorNo", "", ParameterDirection.Output))
            MeetingsStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("op_ErrorMessage", "", ParameterDirection.Output))

            Return New QueryRequest(MeetingsStoredProcedureRequest)
        End Function

        Private Function GetMeetingInfo(ByVal ProductId As Integer) As TIMSS.API.MeetingInfo.IMeetingProducts

            Dim oMeetingProducts As TIMSS.API.MeetingInfo.IMeetingProducts
            Dim strIN As New System.Text.StringBuilder


            Dim strCacheKey As String

            strCacheKey = ProductId.ToString & "GetMeetingInfo"

            oMeetingProducts = CType(PersonifyDataCache.Fetch(strCacheKey), TIMSS.API.MeetingInfo.IMeetingProducts)

            If oMeetingProducts Is Nothing Then

                oMeetingProducts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.MeetingInfo, "MeetingProducts")
                oMeetingProducts.Filter.Add("ProductId", ProductId.ToString)
                oMeetingProducts.Fill()
                PersonifyDataCache.Store(strCacheKey, oMeetingProducts)
            End If

            Return oMeetingProducts
        End Function
#End Region
       

    End Class




End Namespace
