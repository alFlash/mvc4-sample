Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.PrintOrder



Namespace Personify.DNN.Modules.PrintOrder
    Class MyItems

        Dim pos As Integer
        Dim id As String

        Public Sub New(ByVal thepos As Integer, ByVal theid As String)
            MyBase.New()
            pos = thepos
            id = theid
        End Sub

        ReadOnly Property ThePos() As Integer
            Get
                Return pos
            End Get
        End Property

        ReadOnly Property TheId() As String
            Get
                Return id
            End Get
        End Property

    End Class

    Public MustInherit Class PrintOrder
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable
        Public Repeater1 As System.Web.UI.WebControls.Repeater



#Region "Controls"
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim role As String
            role = Me.GetUserRole(UserInfo)
            If role = "personifyuser" Or role = "personifyadmin" Then
                If Request.QueryString("ids") IsNot Nothing Then
                    Dim ids() As String = Nothing
                    Dim item As String
                    If Request.QueryString("ids") IsNot Nothing Then
                        Dim s As String = Request.QueryString("ids")
                        If s IsNot Nothing AndAlso s.Length > 0 Then

                            ids = s.Split(CChar("y"))
                        End If
                    End If

                    Dim values As ArrayList = New ArrayList()
                    Dim i As Integer = 0

                    If ids IsNot Nothing Then
                        For Each item In ids
                            If item <> "" Then
                                values.Add(New MyItems(i, item))
                            End If
                        Next

                    End If

                    Repeater1.DataSource = values
                    Repeater1.DataBind()

                    ' order1.orderID = Request.QueryString("ids")
                End If
            Else
                DisplayUserAccessMessage(role)
            End If
            
        End Sub


#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
