Imports System
Imports System.Web.Caching
Imports System.Reflection

Namespace CompanyName.DNN.Modules.PrintOrder.Data

    Public MustInherit Class DataProvider

#Region "Shared/Static Methods"
        ' singleton reference to the instantiated object 
        Private Shared objProvider As DataProvider = Nothing

        ' constructor
        Shared Sub New()
            CreateProvider()
        End Sub

        ' dynamically create provider
        Private Shared Sub CreateProvider()
            objProvider = CType(Framework.Reflection.CreateObject("data", "CompanyName.DNN.Modules.PrintOrder.Data", "CompanyName.DNN.Modules.PrintOrder"), DataProvider)
        End Sub

        ' return the provider
        Public Shared Shadows Function Instance() As DataProvider
            Return objProvider
        End Function
#End Region

#Region "Abstract Methods"
	    '---------------------------------------------------------------------
	    ' TODO Declare DAL methods. Should be implemented in each DAL DataProvider
        ' Use CodeSmith templates to generate this code
    	'---------------------------------------------------------------------

        Public MustOverride Function ListPrintOrder() As IDataReader
        Public MustOverride Function GetPrintOrderByModules(ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function GetPrintOrder(ByVal ItemID As Integer, ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function AddPrintOrder(ByVal ModuleId As Integer,  ByVal Field1 as String ) as integer
        Public MustOverride Sub UpdatePrintOrder(ByVal ItemId As Integer, ByVal Field1 as String )
        Public MustOverride Sub DeletePrintOrder(ByVal ItemID As Integer)
#End Region

    End Class

End Namespace
