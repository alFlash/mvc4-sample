Imports System
Imports System.Data
Imports CompanyName.DNN.Modules.PrintOrder.Data

Namespace CompanyName.DNN.Modules.PrintOrder.Business

    Public Class PrintOrderController
        'Implements Entities.Modules.ISearchable
        'Implements Entities.Modules.IPortable

#Region "Pulic Methods"
        '---------------------------------------------------------------------
        ' TODO Implement BLL methods
        ' You can use CodeSmith templates to generate this code
        '---------------------------------------------------------------------
        Public Function List() As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().ListPrintOrder(), GetType(PrintOrderInfo))
        End Function

        Public Function GetByModules(ByVal ModuleId As Integer) As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().GetPrintOrderByModules(ModuleId), GetType(PrintOrderInfo))
        End Function
        
        Public Function [Get](ByVal ItemID As Integer, ByVal ModuleId As Integer) As PrintOrderInfo
            Return CType(CBO.FillObject(DataProvider.Instance().GetPrintOrder(ItemId, ModuleId), GetType(PrintOrderInfo)), PrintOrderInfo)
        End Function

        Public Function Add(ByVal objPrintOrder As PrintOrderInfo) as integer
            Return CType(DataProvider.Instance().AddPrintOrder(objPrintOrder.ModuleId, objPrintOrder.Field1),Integer)
        End Function
        
        Public Sub Update(ByVal objPrintOrder As PrintOrderInfo)
            DataProvider.Instance().UpdatePrintOrder(objPrintOrder.ItemId, objPrintOrder.Field1)
        End Sub

        Public Sub Delete(ByVal ItemID As Integer)
            DataProvider.Instance().DeletePrintOrder(ItemId)
        End Sub
#End Region

#Region "Optional Interfaces"
        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

        'End Function

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

        'End Sub
#End Region

    End Class

End Namespace
