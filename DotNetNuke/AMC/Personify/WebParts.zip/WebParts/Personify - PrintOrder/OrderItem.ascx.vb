Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects


Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.PrintOrder
Imports System.Collections.Generic



Namespace Personify.DNN.Modules.PrintOrder

    Public MustInherit Class OrderItem
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

        Public orderID As String
        Public order As WebOrderMaster
        Public orderDetail As WebOrderDetail
       

#Region "Controls"
        Protected detailTemplate As Personify.WebControls.XslTemplate
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'MasterCustomerID = UserInfo.Profile.ProfileProperties("MasterCustomerId").ToString
            'SubCustomerId = CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
           
            order = Nothing
            Dim orderitem As WebOrderMaster
            Dim oMyOrders As WebOrderMasters

            oMyOrders = GetMyOrders(MasterCustomerId, SubCustomerId, CustomerMode.BOTH)

            For Each orderitem In oMyOrders
                If orderitem.OrderNumber = orderID Then
                    order = orderitem
                End If
            Next
            Dim myXSLorder As XSLorder = New XSLorder
            Dim LocalResourceFile As String = ""
            LocalResourceFile = ModulePath + "App_LocalResources\OrderItem.ascx.resx"
            myXSLorder.order = order
            myXSLorder.orderSummary = Localization.GetString("orderSummary", LocalResourceFile)
            myXSLorder.orderNumber = Localization.GetString("orderNumber", LocalResourceFile)
            myXSLorder.orderDate = Localization.GetString("orderDate", LocalResourceFile)
            myXSLorder.billTo = Localization.GetString("billTo", LocalResourceFile)
            myXSLorder.shipTo = Localization.GetString("shipTo", LocalResourceFile)
            myXSLorder.product = Localization.GetString("product", LocalResourceFile)
            myXSLorder.description = Localization.GetString("description", LocalResourceFile)
            myXSLorder.itemStatus = Localization.GetString("itemStatus", LocalResourceFile)
            myXSLorder.fulfillStatus = Localization.GetString("fulfillStatus", LocalResourceFile)
            myXSLorder.unitAmount = Localization.GetString("unitAmount", LocalResourceFile)
            myXSLorder.unitDiscount = Localization.GetString("unitDiscount", LocalResourceFile)
            myXSLorder.qty = Localization.GetString("qty", LocalResourceFile)
            myXSLorder.subtotal = Localization.GetString("subtotal", LocalResourceFile)
            myXSLorder.shipping = Localization.GetString("shipping", LocalResourceFile)
            myXSLorder.tax = Localization.GetString("tax", LocalResourceFile)
            myXSLorder.total = Localization.GetString("total", LocalResourceFile)
            Dim templatefile As String = ""
            templatefile = ModulePath + "Templates\template.xsl"
            detailTemplate.XSLfile = Server.MapPath(templatefile)
            ' tableTCMSXslTemplate.AddObject("", oMyOrdersFiltered)
            detailTemplate.AddObject("", myXSLorder)
            detailTemplate.Display()
        End Sub
#End Region


#Region " Web Form Designer Generated Code "

                'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Function GetMyOrders(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal mode As CustomerMode _
   ) As WebOrderMasters

            'Dim ProductId As Integer = 4

            Dim oWebOrderMasters As New WebOrderMasters
            Dim oWebOrderMaster As WebOrderMaster = Nothing
            Dim oWebOrderDetail As WebOrderDetail = Nothing
            Dim oWebOrderDetails As WebOrderDetails
            Dim ids As New List(Of String)
            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters

            Dim appendToKey As String = MasterCustomerId + SubCustomerId.ToString + mode.ToString

            If Not GetSessionObject(SessionKeys.PersonifyWebOrderMaster, appendToKey) Is Nothing Then
                oWebOrderMasters = GetSessionObject(SessionKeys.PersonifyWebOrderMaster, appendToKey)
            Else


                oOrderMasters = GetMyOrderMasters(MasterCustomerId, SubCustomerId, mode)

                For Each oOM As TIMSS.API.OrderInfo.IOrderMaster In oOrderMasters
                    ids.Add(oOM.OrderNumber)
                    oWebOrderMaster = oWebOrderMasters.AddNewOrderMaster
                    oWebOrderMaster.OrderNumber = oOM.OrderNumber
                    oWebOrderMaster.OrderDate = oOM.OrderDate
                    If oOM.Details.Count = 1 Then
                        oWebOrderMaster.Description = oOM.Details(0).Description
                    Else
                        oWebOrderMaster.Description = "Please expand for details"
                    End If


                    oWebOrderMaster.OrderStatusCode = oOM.OrderStatusCode.Code
                    oWebOrderMaster.OrderStatusCodeDescr = oOM.OrderStatusCode.Description
                    oWebOrderMaster.OrderTotal = oOM.TotalOrderAmount
                    oWebOrderMaster.OrderBalance = oOM.OrderBalance
                    'TODO - HACK
                    oWebOrderMaster.TotalPayments = oOM.OrderFinancialAnalysis.InvClearedReceipts
                    'Add additional Order Master Properties
                    oWebOrderMaster.BillTo = oOM.BillAddressDetailInfo.FormattedDetail
                    oWebOrderMaster.ShipTo = oOM.ShipAddressDetailInfo.FormattedDetail
                    oWebOrderMaster.TotalShipping = oOM.TotalShippingAmount
                    oWebOrderMaster.TotalTax = oOM.TotalTaxAmount

                    oWebOrderMaster.ShipMasterCustomerID = oOM.ShipMasterCustomerId
                    oWebOrderMaster.ShipSubCustomerID = oOM.ShipSubCustomerId
                    oWebOrderMaster.BillMasterCustomerID = oOM.BillMasterCustomerId
                    oWebOrderMaster.BillSubCustomerID = oOM.BillSubCustomerId

                    oWebOrderDetails = New WebOrderDetails

                    For Each oOd As TIMSS.API.OrderInfo.IOrderDetail In oOM.Details
                        oWebOrderDetail = oWebOrderDetails.AddNewOrderDetail()
                        oWebOrderDetail.SubSystem = oOd.Subsystem
                        oWebOrderDetail.OrderNumber = oOd.OrderNumber
                        oWebOrderDetail.OrderLineNumber = oOd.OrderLineNumber
                        oWebOrderDetail.OrderLineStatusCode = oOd.LineStatusCode.Code
                        oWebOrderDetail.OrderLineStatusCodeDescr = oOd.LineStatusCode.Description
                        oWebOrderDetail.OrderLineTotal = oOd.BaseTotalAmount
                        oWebOrderDetail.OrderLineBalance = oOd.LineBalanceAmount
                        oWebOrderDetail.TotalLinePayments = oOd.LinePaymentsAmount
                        oWebOrderDetail.Description = oOd.Description
                        'Add additional Order Detail Properties
                        oWebOrderDetail.TrackingNumber = oOd.TrackingNumber
                        oWebOrderDetail.OrderDate = oOd.OrderDate
                        oWebOrderDetail.OrderQuantity = oOd.OrderQuantity
                        oWebOrderDetail.LineDescription = oOd.LineStatusCode.Description
                        oWebOrderDetail.CycleEndDate = oOd.CycleEndDate
                        oWebOrderDetail.CycleBeginDate = oOd.CycleBeginDate
                        oWebOrderDetail.ShipCustomer = oOd.ShipCustomer.LabelName
                        oWebOrderDetail.ShipAddress = oOd.ShipAddress.FormattedAddress
                        oWebOrderDetail.ShippingStatus = oOd.FulfillStatusCode.Description
                        oWebOrderDetail.Amount = oOd.BaseUnitPrice
                        oWebOrderDetail.Discount = oOd.BaseUnitDiscount
                        oWebOrderDetail.Tax = oOd.BaseTaxAmount
                        oWebOrderDetail.Shipping = oOd.BaseShipAmount
                        oWebOrderDetail.Paid = oOd.PaidAmount
                        oWebOrderDetail.Total = oOd.BaseTotalAmount
                        oWebOrderDetail.Product = oOd.ProductCode
                        oWebOrderDetail.ProductId = oOd.ProductId
                        If oOd.Product IsNot Nothing AndAlso oOd.Product.RateCodes IsNot Nothing AndAlso oOd.Product.RateCodes.Count > 0 Then
                            For j As Integer = 0 To oOd.Product.RateCodes.Count - 1
                                Dim currentRateCode As String = oOd.Product.RateCodes(j).RateCodeString
                                Dim currentRateStructureString As String = oOd.Product.RateCodes(j).RateStructureString
                                If currentRateCode.ToString = oOd.RateCodeString.ToString And currentRateStructureString = oOd.RateStructureString Then
                                    oWebOrderDetail.MaxBadges = oOd.Product.RateCodes(j).MaxBadges
                                    oWebOrderMaster.OrderMaxBadges += oWebOrderDetail.MaxBadges
                                End If
                            Next
                        End If

                        Try
                            oWebOrderDetail.MeetingLocation = oOd.Product.MeetingProduct.PrimaryLocation.Customer.PrimaryAddress.AddressLabel
                        Catch de As NullReferenceException
                            oWebOrderDetail.MeetingLocation = ""
                        End Try

                    Next
                    oWebOrderMaster.Details = oWebOrderDetails

                Next



                AddSessionObject(SessionKeys.PersonifyWebOrderMaster, oWebOrderMasters, appendToKey)
            End If


            Return oWebOrderMasters

        End Function

        Private Function GetMyOrderMasters(ByVal MasterCustomerId As String, ByVal SubcustomerId As Integer, ByVal mode As CustomerMode) As TIMSS.API.OrderInfo.IOrderMasters

            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters

            oOrderMasters = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderMasters")

            'added mode selection, filter accordingly
            Select Case mode
                Case CustomerMode.SHIP
                    oOrderMasters.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
                    oOrderMasters.Filter.Add("ShipSubCustomerId", SubcustomerId)
                Case CustomerMode.BILL
                    oOrderMasters.Filter.Add("BillMasterCustomerId", MasterCustomerId)
                    oOrderMasters.Filter.Add("BillSubCustomerId", SubcustomerId)
                Case CustomerMode.BOTH
                    'if both, first of all we get the shipto orders
                    'oOrderMasters.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
                    'oOrderMasters.Filter.Add("ShipSubCustomerId", SubCustomerId)
                    oOrderMasters.Filter.Add(New TIMSS.API.Core.FilterItem("((Ship_Master_Customer_Id =  '" + MasterCustomerId.ToString + "' ) and (Ship_Sub_Customer_Id = " + SubcustomerId.ToString + " )) or ((Bill_Master_Customer_Id =  '" + MasterCustomerId.ToString + "' ) and (Bill_Sub_Customer_Id = " + SubcustomerId.ToString + " ))"))
            End Select

            oOrderMasters.Fill()
            Return oOrderMasters

        End Function

    End Class
    Public Class XSLorder
        Public order As WebOrderMaster
        Public orderSummary As String
        Public orderNumber As String
        Public orderDate As String
        Public billTo As String
        Public shipTo As String
        Public product As String
        Public description As String
        Public itemStatus As String
        Public fulfillStatus As String
        Public unitAmount As String
        Public unitDiscount As String
        Public qty As String
        Public subtotal As String
        Public tax As String
        Public shipping As String
        Public total As String
    End Class
End Namespace