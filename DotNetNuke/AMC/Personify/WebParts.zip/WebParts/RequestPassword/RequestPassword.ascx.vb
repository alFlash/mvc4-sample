Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.RequestPassword.Business
Imports TIMSS.Server.BusinessMessages.EmailAndFax
Imports System.Threading
Imports System.Web.Mail
Imports System.Xml
Imports System.Xml.XPath
Imports System.Xml.Xsl
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data


Namespace Personify.DNN.Modules.RequestPassword

    Public MustInherit Class RequestPassword
		Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable

#Region "Controls"
        Protected WithEvents lblUserName As System.Web.UI.WebControls.Label
        Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblEmailAddress As System.Web.UI.WebControls.Label
        Protected WithEvents txtEmailAddress As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnContinueMain As System.Web.UI.WebControls.Button
        Protected WithEvents pnlMain As System.Web.UI.WebControls.Panel

        Protected WithEvents lblHintQuestion As System.Web.UI.WebControls.Label
        Protected WithEvents lblHintQuestionCaption As System.Web.UI.WebControls.Label
        Protected WithEvents lblHintAnswer As System.Web.UI.WebControls.Label
        Protected WithEvents txtHintAnswer As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnContinueSecurityQuestion As System.Web.UI.WebControls.Button
        Protected WithEvents pnlSecurityQuestion As System.Web.UI.WebControls.Panel

#End Region
#Region "Constants"
        Public Const C_AUTHENTICATION_METHOD As String = "AuthenticationMethod"
        Public Const C_SECURITY_QUESTION As String = "SecurityQuestion"
        'Public Const C_CREATE_NEW_PASSWORD_USING_URL As String = "CreateNewPasswordUsingURL"
        Public Const C_CREATE_NEW_PASSWORD_ACTION_URL As String = "CreateNewPasswordActionURL"
#End Region
#Region "Properties"
        Public Property UserName() As String
            Get
                Return CStr(ViewState("UserName"))
            End Get
            Set(ByVal Value As String)
                ViewState("UserName") = Value
            End Set
        End Property

        Public Property AdminEmailAddress() As String
            Get
                Return CStr(ViewState("AdminEmailAddress"))
            End Get
            Set(ByVal Value As String)
                ViewState("AdminEmailAddress") = Value
            End Set
        End Property

#End Region
#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Settings(C_AUTHENTICATION_METHOD) Is Nothing Then                    
                    If Not Page.IsPostBack Then
                        If GetPersonifySiteSettings(PortalId) Then
                            ReadSettings()
                        Else
                            pnlMain.Visible = False
                            pnlSecurityQuestion.Visible = False
                        End If

                    End If
                Else
                    pnlMain.Visible = False
                    pnlSecurityQuestion.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & siteimagesFolder & "/administrator_info_48.gif"))
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub btnContinueMain_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnContinueMain.Click
            If FormValidation() Then
                If (Not CType(Settings(C_SECURITY_QUESTION), String) = "Y") Or (Not CheckHintQuestionExist()) Then

                    'If CType(Settings(C_CREATE_NEW_PASSWORD_USING_URL), String) = "Y" Then
                    Dim Guid As String = System.Guid.NewGuid.ToString()
                    AddPersonifyPasswordAssistanceRecord(Guid)
                    SendEmail(Guid)
                    'Else
                    '    Dim Guid As String = System.Guid.NewGuid.ToString()
                    '    AddPersonifyPasswordAssistanceRecord(Guid)
                    '    Redirect(Guid)
                    'End If
                Else
                    pnlMain.Visible = False
                    pnlSecurityQuestion.Visible = True
                    ReadSecurityQuestion()
                End If
            End If
        End Sub
        Private Sub btnContinueSecurityQuestion_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnContinueSecurityQuestion.Click
            Try
                If SecurityQuestionValidated() Then
                    ' If CType(Settings(C_CREATE_NEW_PASSWORD_USING_URL), String) = "Y" Then
                    Dim Guid As String = System.Guid.NewGuid.ToString()
                    AddPersonifyPasswordAssistanceRecord(Guid)
                    SendEmail(Guid)
                    'Else
                    '    Dim Guid As String = System.Guid.NewGuid.ToString()
                    '    AddPersonifyPasswordAssistanceRecord(Guid)
                    '    Redirect(Guid)
                    'End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "Helper Functions"

        Private Function CheckHintQuestionExist() As Boolean
            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
            oWebUsers = GetWebUser(UserName)

            If oWebUsers.Count > 0 Then
                If oWebUsers(0).HintQuestionCodeString = "" Then
                    Return False
                Else
                    Return True
                End If
            Else
                Return False
            End If
        End Function

        Private Sub ReadSettings()
            Select Case CType(Settings(C_AUTHENTICATION_METHOD), String)
                Case "User"
                    lblUserName.Visible = True
                    txtUserName.Visible = True
                    lblEmailAddress.Visible = False
                    txtEmailAddress.Visible = False
                Case "Email"
                    lblUserName.Visible = False
                    txtUserName.Visible = False
                    lblEmailAddress.Visible = True
                    txtEmailAddress.Visible = True
                Case "UserEmail"
                    lblUserName.Visible = True
                    txtUserName.Visible = True
                    lblEmailAddress.Visible = True
                    txtEmailAddress.Visible = True
            End Select
            pnlSecurityQuestion.Visible = False
        End Sub

        Private Function FormValidation() As Boolean

            Select Case CType(Settings(C_AUTHENTICATION_METHOD), String)
                Case "User"
                    If txtUserName.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingUserID", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
                    oWebUsers = GetWebUser(txtUserName.Text)
                    If oWebUsers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If oWebUsers(0).DisableLoginFlag = True Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDisabled", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    UserName = txtUserName.Text
                Case "Email"
                    If txtEmailAddress.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    Dim oRegex As New System.Text.RegularExpressions.Regex("^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$")
                    If Not oRegex.IsMatch(txtEmailAddress.Text) Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                    oCustomers = GetCustomer(txtEmailAddress.Text)
                    If oCustomers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("EmailAddressDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    ElseIf oCustomers.Count > 1 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("DuplicateEmailRecord", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
                    oWebUsers = GetWebUser(oCustomers(0).MasterCustomerId, CStr(oCustomers(0).SubCustomerId))

                    If oWebUsers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If oWebUsers.Count > 1 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If oWebUsers(0).DisableLoginFlag = True Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDisabled", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    UserName = oWebUsers(0).UserId
                Case "UserEmail"
                    If txtUserName.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingUserID", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If txtEmailAddress.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    Dim oRegex As New System.Text.RegularExpressions.Regex("^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$")
                    If Not oRegex.IsMatch(txtEmailAddress.Text) Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If


                    'If oCustomers.Count <= 0 Then
                    '    Skins.Skin.AddModuleMessage(Me, Localization.GetString("EmailAddressDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    '    Return False
                    'ElseIf oCustomers.Count > 1 Then
                    '    Skins.Skin.AddModuleMessage(Me, Localization.GetString("DuplicateEmailRecord", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    '    Return False
                    'End If

                    Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
                    oWebUsers = GetWebUser(txtUserName.Text)
                    If oWebUsers.Count > 1 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If oWebUsers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                    oCustomers = GetCustomer(oWebUsers(0).MasterCustomerId, oWebUsers(0).SubCustomerId.ToString)

                    If oCustomers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    If txtEmailAddress.Text <> oCustomers(0).PrimaryEmailAddress Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDoesNotMatch", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    If oWebUsers(0).DisableLoginFlag = True Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIDDisabled", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    UserName = txtUserName.Text
            End Select
            Return True
        End Function

        Private Sub SendEmail(ByVal guid As String)
            Try
                If Page.IsValid Then
                    pnlMain.Visible = False
                    Dim oEmail As New TIMSS.EmailManager

                    If CType(Settings(C_AUTHENTICATION_METHOD), String) = "Email" Or CType(Settings(C_AUTHENTICATION_METHOD), String) = "UserEmail" Then
                        oEmail.To = txtEmailAddress.Text
                    Else

                        Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
                        oWebUsers = GetWebUser(txtUserName.Text)

                        Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                        oCustomers = GetCustomer(oWebUsers(0).MasterCustomerId, CStr(oWebUsers(0).SubCustomerId))
                        oEmail.To = oCustomers(0).PrimaryEmailAddress

                    End If


                    Dim Subject As String = Services.Localization.Localization.GetString("EmailSubject", Me.LocalResourceFile)
                    oEmail.Subject = Subject

                    oEmail.FromEmail = AdminEmailAddress
                    oEmail.FromName = Services.Localization.Localization.GetString("EmailFromName", Me.LocalResourceFile)

                    Dim emailTemplateFile As String = Server.MapPath(ModulePath + "Templates\EmailTemplate.xsl")
                    Dim ApplicationId As String = String.Empty
                    Dim strTabId As String = Settings(C_CREATE_NEW_PASSWORD_ACTION_URL).ToString
                    Dim LinkToFollow As String = NavigateURL(Integer.Parse(strTabId), "", "&a=" & guid)

                    Dim xml As System.Xml.XmlReader = New System.Xml.XmlTextReader(New System.IO.StringReader("<?xml version='1.0'?><LinkToFollow>" & LinkToFollow & "</LinkToFollow>"))
                    Dim document As XmlDocument = New XmlDocument()
                    document.Load(xml)
                    Dim transformer As XslCompiledTransform = New XslCompiledTransform()
                    transformer.Load(emailTemplateFile)
                    Dim output As StringWriter = New StringWriter()
                    transformer.Transform(document, Nothing, output)
                    oEmail.Body = output.ToString
                    output.Close()

                    oEmail.IsBodyHtml = False
                    If (oEmail.Send()) Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("SuccessMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("FailureMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If

                    pnlMain.Visible = False
                    pnlSecurityQuestion.Visible = False

                End If
            Catch exc As System.Net.Mail.SmtpFailedRecipientException
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("InvalidEmailAddress", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                pnlMain.Visible = True
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub

        Private Sub Redirect(ByVal applicationId As String)
            Dim strTabId As String = Settings(C_CREATE_NEW_PASSWORD_ACTION_URL).ToString
            Dim LinkToFollow As String = NavigateURL(Integer.Parse(strTabId), "", "&a=" & applicationId)

            Response.Redirect(LinkToFollow)
        End Sub

        Private Sub AddPersonifyPasswordAssistanceRecord(ByVal guid As String)
            Dim sqlParamArr(2) As SqlParameter
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
            sqlParamArr(0).Value = PortalId.ToString
            sqlParamArr(1) = New SqlParameter("@UserId", SqlDbType.NVarChar, 100)
            sqlParamArr(1).Value = UserName
            sqlParamArr(2) = New SqlParameter("@ApplicationId", SqlDbType.NVarChar, 100)
            sqlParamArr(2).Value = guid

            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(ConnectionString, "dbo." & "" & "AddPersonifyPasswordAssistance", sqlParamArr(0), sqlParamArr(1), sqlParamArr(2))

        End Sub
        Private Sub ReadSecurityQuestion()

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
            oWebUsers = GetWebUser(UserName)

            lblHintQuestionCaption.Text = oWebUsers(0).HintQuestionCode.Description
            'lblHintQuestionCaption.Text = "your prefered name?"
        End Sub

        Private Function SecurityQuestionValidated() As Boolean
            'TODO: check if SecurityQuestion Answer is correct
            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
            oWebUsers = GetWebUser(UserName)

            If (oWebUsers(0).HintAnswer = txtHintAnswer.Text) Then
                Return True
            Else
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("HintQuestionInvalidAnswer", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
        End Function


        Private Function GetPersonifySiteSettings(ByVal CurrPortalID As Integer) As Boolean
            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(ConnectionString, "dbo." & "" & "GetPersonifySiteSettings", CurrPortalID), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    If (Not oSiteData.Item("AdminEmailAddress") Is Nothing) AndAlso (Not oSiteData.Item("AdminEmailAddress").ToString = "") Then
                        AdminEmailAddress = CType(oSiteData.Item("AdminEmailAddress"), String)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                End While
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            oSiteData.Close()
            oSiteData = Nothing

            Return True
        End Function
#End Region

        Private Function GetWebUser(ByVal UserId As String) As TIMSS.API.WebInfo.IWebUsers

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers



            oWebUsers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

            oWebUsers.Filter.Add("UserId", TIMSS.Enumerations.QueryOperatorEnum.Equals, UserId)
            oWebUsers.Fill()

            Return oWebUsers

        End Function

        Private Function GetWebUser(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.WebInfo.IWebUsers

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers


            oWebUsers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")
            oWebUsers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MCID)
            oWebUsers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SCID)
            oWebUsers.Fill()
            Return oWebUsers


        End Function
        Private Function GetCustomer(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers


            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
                .Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
                .Fill()
            End With

            Return oCustomers

        End Function

        Private Function GetCustomer(ByVal PrimaryEmailAddress As String) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers


            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")

            With oCustomers
                .Filter.Add("PrimaryEmailAddress", TIMSS.Enumerations.QueryOperatorEnum.Equals, PrimaryEmailAddress)
                .Fill()
            End With

            Return oCustomers

        End Function

    End Class

End Namespace
