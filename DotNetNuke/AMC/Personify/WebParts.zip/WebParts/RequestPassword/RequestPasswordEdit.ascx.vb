Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.RequestPassword.Business

Namespace Personify.DNN.Modules.RequestPassword

	Public MustInherit Class RequestPasswordEdit
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"
        Protected WithEvents rdAuthenticationMethod As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents chkSecurityQuestion As System.Web.UI.WebControls.CheckBox
        'Protected WithEvents chkCreatePasswordUsingURL As System.Web.UI.WebControls.CheckBox
        Protected WithEvents drpCreateNewPasswordActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
#End Region
#Region "Constants"
        Public Const C_AUTHENTICATION_METHOD As String = "AuthenticationMethod"
        Public Const C_SECURITY_QUESTION As String = "SecurityQuestion"
        Public Const C_CREATE_NEW_PASSWORD_USING_URL As String = "CreateNewPasswordUsingURL"
        Public Const C_CREATE_NEW_PASSWORD_ACTION_URL As String = "CreateNewPasswordActionURL"
#End Region
#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    LoadSettings()                    
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                UpdateSettings()
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        
#End Region
#Region "Helper Functions"
        Private Sub LoadSettings()
            If Not Settings(C_AUTHENTICATION_METHOD) Is Nothing Then
                Select Case CType(Settings(C_AUTHENTICATION_METHOD), String)
                    Case "User"
                        rdAuthenticationMethod.SelectedValue = "User"
                    Case "Email"
                        rdAuthenticationMethod.SelectedValue = "Email"
                    Case "UserEmail"
                        rdAuthenticationMethod.SelectedValue = "UserEmail"
                End Select
            Else
                rdAuthenticationMethod.SelectedValue = "User"
            End If

            If Not Settings(C_SECURITY_QUESTION) Is Nothing Then
                If CType(Settings(C_SECURITY_QUESTION), String) = "Y" Then
                    chkSecurityQuestion.Checked = True
                Else
                    chkSecurityQuestion.Checked = False
                End If
            End If

            'If Not Settings(C_CREATE_NEW_PASSWORD_USING_URL) Is Nothing Then
            '    If CType(Settings(C_CREATE_NEW_PASSWORD_USING_URL), String) = "Y" Then
            '        chkCreatePasswordUsingURL.Checked = True
            '    Else
            '        chkCreatePasswordUsingURL.Checked = False
            '    End If
            'End If

            If Not Settings(C_CREATE_NEW_PASSWORD_ACTION_URL) Is Nothing Then
                drpCreateNewPasswordActionURL.Url = CType(Settings(C_CREATE_NEW_PASSWORD_ACTION_URL), String)
            End If
        End Sub
        Private Sub UpdateSettings()
            Dim objModules As New Entities.Modules.ModuleController

            objModules.UpdateModuleSetting(Me.ModuleId, C_AUTHENTICATION_METHOD, rdAuthenticationMethod.SelectedValue)

            If chkSecurityQuestion.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_SECURITY_QUESTION, "Y")
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, C_SECURITY_QUESTION, "N")
            End If

            'If Me.chkCreatePasswordUsingURL.Checked Then
            '    objModules.UpdateModuleSetting(Me.ModuleId, C_CREATE_NEW_PASSWORD_USING_URL, "Y")
            'Else
            '    objModules.UpdateModuleSetting(Me.ModuleId, C_CREATE_NEW_PASSWORD_USING_URL, "N")
            'End If

            objModules.UpdateModuleSetting(Me.ModuleId, C_CREATE_NEW_PASSWORD_ACTION_URL, drpCreateNewPasswordActionURL.Url)

        End Sub

#End Region
#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
