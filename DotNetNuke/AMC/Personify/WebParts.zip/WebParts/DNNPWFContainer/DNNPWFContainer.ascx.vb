Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports Personify
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.UI
Imports PWFContainerConstants


Namespace Personify.DNN.Modules.DNNPWFContainer


    Public MustInherit Class DNNPWFContainer
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected WithEvents lblErrMsg As New Label
        Protected WithEvents plhPWFWebPart As New PlaceHolder
        Protected WithEvents pnlTasksbar As New Panel
        Protected WithEvents plhPWFTaskbarWebPart As New PlaceHolder
#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        End Sub
#End Region

#Region "Optional Interfaces"

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region "Variables"
        Dim _IsLoginRequired As Boolean
        Dim _FormName As String = String.Empty
#End Region

#Region "Properties"
        Public ReadOnly Property IsLoginRequired() As Boolean
            Get
                Return _IsLoginRequired
            End Get
        End Property

        Public ReadOnly Property FormName() As String
            Get
                Return _FormName
            End Get
        End Property
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            HideMessage()
            If IsValidSettings() Then
                Try

                    If Utils.ConvertToBoolean(Settings(C_ShowTaskbar)) Then
                        Dim ctlTaskBar As New Personify.Web.PersonifyTaskbarWebPart
                        Me.plhPWFTaskbarWebPart.Controls.Add(ctlTaskBar)
                        ctlTaskBar.ID = "pTb"
                        ctlTaskBar.FormName = FormName
                        Me.pnlTasksbar.Visible = True
                    Else
                        Me.pnlTasksbar.Visible = False
                    End If

                    Dim ctl As New Personify.Web.PersonifyWebPart
                    Me.plhPWFWebPart.Controls.Add(ctl)
                    AddHandler ctl.FormError, AddressOf PWF_FormError
                    ctl.ID = "pf"
                    ctl.OrgId = Me.OrganizationId
                    ctl.OrgUnitId = Me.OrganizationUnitId
                    ctl.FormName = FormName
                    'if this is turned on "FormError" event would not be raised
                    ctl.ThrowExceptionsDirectlyToHost = False

                    If IsLoginRequired Then BindFormToLoggedInCustomer(ctl)
                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If

        End Sub


#End Region

#Region "Helpers"

        Private Sub PWF_FormError(ByVal e As Exception)
            If e.Message.StartsWith("Form") And e.Message.Contains("is not found or invalid xml") Then
                ShowMessage(String.Format("<strong>Error: </strong> {0}", e.Message))
            Else
                ProcessModuleLoadException(Me, e)
            End If
        End Sub

        Private Sub HideMessage()
            Me.lblErrMsg.Text = String.Empty
            Me.lblErrMsg.Visible = False
        End Sub

        Private Sub ShowMessage(ByVal sMsg As String)
            Me.lblErrMsg.Text = sMsg
            Me.lblErrMsg.Visible = True
        End Sub

        Private Function IsValidSettings() As Boolean
            _FormName = Settings(C_FormName)
            If String.IsNullOrEmpty(FormName) Then
                ShowMessage("Form Name not provided")
                Return False
            End If

            _IsLoginRequired = Utils.ConvertToBoolean(Settings(C_LoginRequired))
            If IsLoginRequired AndAlso _
                (Not Me.IsPersonifyWebUserLoggedIn) Then
                ShowMessage("You must login to access this module")
                Return False
            End If

            Return True
        End Function


        Private Sub BindFormToLoggedInCustomer(ByVal ctl As Personify.Web.PersonifyWebPart)
            If (Not String.IsNullOrEmpty(MasterCustomerId)) AndAlso (Not String.IsNullOrEmpty(SubCustomerId)) Then
                'Dim sCmd As String = String.Format("cmd://Form/SelectItem?Key={0}|{1}", MasterCustomerId, SubCustomerId)
                'ctl.Cmd = sCmd
                ctl.PersonifyUser = String.Format("{0}|{1}", MasterCustomerId, SubCustomerId)
                ctl.PrePopulateCustomer = True
            End If
        End Sub

#End Region

    End Class



End Namespace
