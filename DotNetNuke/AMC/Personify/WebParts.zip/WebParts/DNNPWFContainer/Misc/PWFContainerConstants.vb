Public Class PWFContainerConstants
    Public Const C_FormName As String = "FormName"
    Public Const C_LoginRequired As String = "LoginRequired"
    Public Const C_ShowTaskbar As String = "ShowTaskbar"
End Class
