Public Class Utils
    <System.Diagnostics.DebuggerStepThroughAttribute()> Public Shared Function ConvertToBoolean(ByVal Value As String, Optional ByVal DefaultValue As Boolean = False) As Boolean
        If String.IsNullOrEmpty(Value) Then
            Return DefaultValue
        Else
            Select Case Value.ToLower
                Case "true", "t", "yes", "y", "1"
                    Return True
                Case Else
                    Return False
            End Select
        End If
    End Function
End Class
