Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Text
Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PersonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports Personify.ShoppingCartManager.Business

Namespace Personify.DNN.Modules.Badges

	Public MustInherit Class Badges
		Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
		'Implements Entities.Modules.IPortable
		'Implements Entities.Modules.ISearchable

		Private Const C_BADGEURL As String = "Badge_Url"
		Private Const C_BADGETEMPLATE As String = "Badge_Template"

		Protected BadgesXslTemplate As Personify.WebControls.XslTemplate
		Protected MainCancelButton As LinkButton
		Protected MainContinue As LinkButton
		Protected WarningLabel As Label

		'Protected WithEvents BadgeMessageControl As WebControls.MessageControl



#Region "Controls"
#End Region

		Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
			Dim ScriptPath As String = ResolveUrl(path)
			If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
				Dim script As StringBuilder = New StringBuilder
				script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
				Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
				script = Nothing
			End If
		End Sub

#Region "Event Handlers"

		Private OrderNumber As String
		Private ProductID As Integer
        'Dim MasterCustomerId As String = String.Empty				'"000000003133"
        'Dim SubCustomerId As Integer = 0

		Dim CartMasterCustomerId As String = String.Empty				'"000000003133"
		Dim CartSubCustomerId As Integer = 0

		Private WebpartMode As Integer = 3 ' show everything from cart

		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    RegisterJSScripts("js\badge.js", "Badge")

                    'BadgeMessageControl.Clear()

                    If Settings(C_BADGEURL) Is Nothing Then
                        'BadgeMessageControl.ShowMessage(Localization.GetString("NoLayoutSelected.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.RedError)
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        MainCancelButton.Visible = False
                        MainContinue.Visible = False
                    Else

                        If Not IsPostBack Then
                            Session("Back" + ModuleId.ToString) = Request.UrlReferrer
                        End If

                        If Session("Back" + ModuleId.ToString) IsNot Nothing Then
                            MainCancelButton.PostBackUrl = Convert.ToString(Session("Back" + ModuleId.ToString))
                        Else
                            MainCancelButton.Visible = False
                        End If

                        Dim WebBadges() As WebBadge
                        OrderNumber = Request("ordernumber") '"1000006617"

                        Try
                            ProductID = Convert.ToInt32(Request("productid"))
                        Catch ex As Exception

                        End Try

                        If OrderNumber IsNot Nothing Then
                            If OrderNumber.Length > 0 Then
                                WebpartMode = 1 ' with order
                            End If
                        End If

                        If ProductID > 0 Then
                            WebpartMode = 2 'with productid
                        End If


                        'If UserInfo.Profile.ProfileProperties("MasterCustomerId") IsNot Nothing AndAlso UserInfo.Profile.GetPropertyValue("MasterCustomerId") IsNot Nothing Then
                        '    MasterCustomerId = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
                        '    CartMasterCustomerId = MasterCustomerId
                        'Else
                        '    CartMasterCustomerId = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                        'End If

                        'If UserInfo.Profile.ProfileProperties("SubCustomerId") IsNot Nothing AndAlso UserInfo.Profile.GetPropertyValue("SubCustomerId") IsNot Nothing Then
                        '    SubCustomerId = CType(UserInfo.Profile.GetPropertyValue("SubCustomerId"), Integer)
                        '    CartSubCustomerId = SubCustomerId
                        'Else
                        '    CartSubCustomerId = 0
                        'End If

                        '    If WebpartMode = 1 Then
                        'if staff

                        CartMasterCustomerId = MasterCustomerId
                        CartSubCustomerId = SubCustomerId

                        'End If


                        Dim BadgeURL As String = String.Empty

                        'Dim objMS As Hashtable
                        'Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
                        'objMS = objMC.GetModuleSettings(ModuleId)
                        'If objMS(C_BADGEURL) IsNot Nothing Then
                        '	BadgeURL = CType(objMS(C_BADGEURL), String)
                        'End If

                        MainContinue.PostBackUrl = NavigateURL(Convert.ToInt32(Settings(C_BADGEURL)))


                        If WebpartMode = 0 Or WebpartMode > 3 Then
                            MainContinue.Visible = False
                            WarningLabel.Visible = True
                        ElseIf WebpartMode = 1 Then 'with order


                            WebBadges = GetBadgesInfo(MasterCustomerId, SubCustomerId, OrderNumber)

                            If WebBadges IsNot Nothing Then
                                BuildBadges(WebBadges)
                            Else
                                MainContinue.Visible = False
                                WarningLabel.Visible = True
                            End If

                        ElseIf WebpartMode = 2 Or WebpartMode = 3 Then  'show from cart with/without productid

                            BuildBadges(Nothing)

                        End If

                    End If

                    If MasterCustomerId Is Nothing OrElse MasterCustomerId.Length < 1 Then
                        MainContinue.Visible = False
                        WarningLabel.Visible = True
                    End If
                Else
                    MainCancelButton.Visible = False
                    MainContinue.Visible = False
                    WarningLabel.Visible = False
                    DisplayUserAccessMessage(role)
                End If
                

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

		Public Class ProductLine
			Public OrderLineNumber As Integer
			Public ProductName As String
			Public BeginDate As String
			Public EndDate As String
			Public BadgeCount As Integer
			Public MaxBadges As Integer
			Public Badges() As BadgeItem

            'AN Cuna Fix
            Public ProductType As String
            Public MasterProductFlag As Boolean
            Public TotalBadgesForMeeting As Integer
            Public TotalPaidBadgesForMeeting As Integer
            Public MeetingLineNumber As Integer

		End Class

		Public Class BadgeItem
			Public FirstName As String
			Public FullName As String
			Public CompanyName As String
			Public City As String
			Public State As String
			Public PostalCode As String
			Public BadgeSeq As String
            Public BadgeTypeCode As String

            'AN Cuna Fix
            Public ProductTypeCode As String
            Public MasterProductFlag As Boolean
            Public IsPaidBadge As Boolean
		End Class

		Public Class SavedUser
			Public FullName As String
			Public AllInfo As String
		End Class

        Private Sub BuildBadges(ByRef WebBadges() As WebBadge)
            If WebBadges IsNot Nothing Then
                If WebBadges.Length > 0 Then

                    Dim AllProducts(WebBadges.Length - 1) As ProductLine
                    ' --------AN Cuna Fix
                    Dim intPaidBadgesUsedCount As Integer = 0

                    Dim aSavedUser As New ArrayList

                    For i As Integer = 0 To WebBadges.Length - 1
                        ' --------AN Cuna Fix  
                        'set the paid padge used count to 0
                        intPaidBadgesUsedCount = 0

                        AllProducts(i) = New ProductLine
                        AllProducts(i).OrderLineNumber = WebBadges(i).OrderLineNumber
                        AllProducts(i).ProductName = WebBadges(i).ProductName
                        AllProducts(i).BeginDate = WebBadges(i).CycleBeginDate.ToString("MMMM d, yyyy")
                        AllProducts(i).EndDate = WebBadges(i).CycleEndDate.ToString("MMMM d, yyyy")
                        AllProducts(i).MaxBadges = WebBadges(i).MaxBadges
                        ' --------AN FIX CQ - 3246-7931501
                        AllProducts(i).ProductType = WebBadges(i).ProductType
                        AllProducts(i).MeetingLineNumber = WebBadges(i).MeetingLineNumber
                        AllProducts(i).MasterProductFlag = WebBadges(i).MasterProductFlag
                        If WebBadges(i).MasterProductFlag = True Then
                            AllProducts(i).TotalBadgesForMeeting = WebBadges(i).TotalBadgesForMeeting
                            AllProducts(i).TotalPaidBadgesForMeeting = WebBadges(i).TotalPaidBadgesForMeeting
                        End If


                        If WebBadges(i).Badges IsNot Nothing AndAlso WebBadges(i).Badges.Count > 0 Then
                            AllProducts(i).BadgeCount = WebBadges(i).Badges.Count
' --------AN Cuna Fix
                            'Dim AllBadges(AllProducts(i).MaxBadges - 1) As BadgeItem
                            Dim AllBadges(AllProducts(i).TotalBadgesForMeeting - 1) As BadgeItem

' --------AN Cuna Fix
                            'For j As Integer = 0 To AllProducts(i).MaxBadges - 1
                            For j As Integer = 0 To AllProducts(i).TotalBadgesForMeeting - 1
                                AllBadges(j) = New BadgeItem
                                If j < AllProducts(i).BadgeCount Then

                                    AllBadges(j).FirstName = WebBadges(i).Badges(j).FirstName
                                    AllBadges(j).FullName = WebBadges(i).Badges(j).FullName
                                    AllBadges(j).CompanyName = WebBadges(i).Badges(j).CompanyName
                                    AllBadges(j).City = WebBadges(i).Badges(j).City
                                    AllBadges(j).State = WebBadges(i).Badges(j).State
                                    AllBadges(j).PostalCode = WebBadges(i).Badges(j).PostalCode
                                    AllBadges(j).BadgeSeq = WebBadges(i).Badges(j).BadgeSeq.ToString

                                    ' --------AN Cuna Fix
                                    AllBadges(j).IsPaidBadge = (WebBadges(i).Badges(j).PaidFlag = True)
                                    If AllBadges(j).IsPaidBadge Then
                                        intPaidBadgesUsedCount = intPaidBadgesUsedCount + 1
                                    End If

                                    AllBadges(j).BadgeTypeCode = WebBadges(i).Badges(j).BadgeTypeCodeString


                                    Dim oSavedUser As New SavedUser
                                    oSavedUser.FullName = WebBadges(i).Badges(j).FullName
                                    oSavedUser.AllInfo = _
                                     WebBadges(i).Badges(j).FirstName + "|" + _
                                     WebBadges(i).Badges(j).FullName + "|" + _
                                     WebBadges(i).Badges(j).CompanyName + "|" + _
                                     WebBadges(i).Badges(j).City + "|" + _
                                     WebBadges(i).Badges(j).State + "|" + _
                                     WebBadges(i).Badges(j).PostalCode

                                    Dim already As Boolean = False
                                    If aSavedUser IsNot Nothing Then
                                        If aSavedUser.Count > 0 Then
                                            For k As Integer = 0 To aSavedUser.Count - 1
                                                Dim tempSavedUser As SavedUser = CType(aSavedUser(k), SavedUser)
                                                If tempSavedUser IsNot Nothing Then
                                                    If tempSavedUser.FullName = oSavedUser.FullName Then
                                                        If tempSavedUser.AllInfo = oSavedUser.AllInfo Then
                                                            already = True
                                                            Exit For
                                                        End If
                                                    End If
                                                End If
                                            Next
                                        End If
                                    End If
                                    If already = False Then
                                        aSavedUser.Add(oSavedUser)
                                    End If

                                Else
                                    AllBadges(j).BadgeSeq = "0" + (j + 1).ToString
                                    ' --------AN Cuna Fix
                                    If intPaidBadgesUsedCount < AllProducts(i).TotalPaidBadgesForMeeting Then
                                        AllBadges(j).IsPaidBadge = True
                                        intPaidBadgesUsedCount = intPaidBadgesUsedCount + 1
                                    End If
                                End If


                            Next

                            AllProducts(i).Badges = AllBadges
                        Else
                            'no badge available yet
                            Dim AllBadges(AllProducts(i).MaxBadges - 1) As BadgeItem
                            For j As Integer = 0 To AllProducts(i).MaxBadges - 1
                                AllBadges(j) = New BadgeItem


                                AllBadges(j).BadgeSeq = "0" + (j + 1).ToString
                            Next
                            AllProducts(i).Badges = AllBadges

                        End If
                    Next
                    Dim SavedUserList() As SavedUser = Nothing
                    If aSavedUser IsNot Nothing Then
                        If aSavedUser.Count > 0 Then
                            Dim tempSavedUserList(aSavedUser.Count - 1) As SavedUser
                            aSavedUser.CopyTo(tempSavedUserList)
                            SavedUserList = tempSavedUserList
                        End If
                    End If
                    ShowBadges(AllProducts, SavedUserList)
                End If

            Else '
                If WebpartMode = 2 Or WebpartMode = 3 Then

                    Dim oCartController As New ShoppingCartController()
                    ' --------AN Cuna Fix
                    Dim TempBadgeSeq As Integer = 0
                    ' -------------------------

                    Dim AList As ArrayList = oCartController.GetCustomerCart(MasterCustomerId, CartSubCustomerId, False, True)
                    If AList IsNot Nothing AndAlso AList.Count > 0 Then

                        Dim aSavedUser As New ArrayList
                        Dim aAllProducts As New ArrayList

                        For i As Integer = 0 To AList.Count - 1
                            Dim aShoppingCartInfo As ShoppingCartInfo
                            aShoppingCartInfo = CType(AList(i), ShoppingCartInfo)

                            Dim BadgeCount As Integer = aShoppingCartInfo.MaxBadges
                            If aShoppingCartInfo.ProductType = "BADGE" Then
                                BadgeCount = aShoppingCartInfo.Quantity
                            End If

                            If BadgeCount > 0 Then

                                Dim aBadges(BadgeCount - 1) As BadgeItem

                                If aShoppingCartInfo.ProductId = ProductID Or WebpartMode = 3 Then

                                    ' we have something to show



                                    Dim oProductLine As New ProductLine

                                    oProductLine.ProductName = aShoppingCartInfo.ShortName
                                    oProductLine.BeginDate = ""
                                    oProductLine.EndDate = ""
                                    oProductLine.MaxBadges = BadgeCount
                                    oProductLine.OrderLineNumber = aShoppingCartInfo.CartItemId

                                    'AN CUNA Fix
                                    'For Shopping Cart, put product type
                                    oProductLine.ProductType = aShoppingCartInfo.ProductType
                                    oProductLine.MeetingLineNumber = aShoppingCartInfo.RelatedCartItemId
                                    If aShoppingCartInfo.RelatedCartItemId = 0 Then
                                        oProductLine.MasterProductFlag = True
                                    Else
                                        oProductLine.MasterProductFlag = False
                                    End If

                                    Dim bi As ArrayList = oCartController.GetBadges(aShoppingCartInfo.CartItemId)

                                    For j As Integer = 0 To oProductLine.MaxBadges - 1

                                        aBadges(j) = New BadgeItem

                                        ' --------AN Cuna Fix
                                        TempBadgeSeq = TempBadgeSeq + 1
                                        aBadges(j).BadgeSeq = TempBadgeSeq
                                        If oProductLine.ProductType = "BADGE" Then
                                            aBadges(j).IsPaidBadge = True
                                        Else
                                            aBadges(j).IsPaidBadge = False
                                        End If
                                        'aBadges(j).BadgeSeq = "0" + (j + 1).ToString


                                        If bi IsNot Nothing AndAlso bi.Count > 0 Then
                                            oProductLine.BadgeCount = bi.Count

                                            For Each SavedBadge As ShoppingCartManager.Business.BadgeInfo In bi
                                                ' --------AN Cuna Fix

                                                'If j + 1 = SavedBadge.BadgeNumber Then

                                                'Start: 3246-8313615: PD: badges info is cleared if you delete a meeting from the cart(Clone 7.2.3)  
                                                If bi.Count > 0 Then
                                                    TempBadgeSeq = SavedBadge.BadgeNumber
                                                    aBadges(j).BadgeSeq = TempBadgeSeq
                                                End If
                                                'End: 3246-8313615: PD: badges info is cleared if you delete a meeting from the cart(Clone 7.2.3)   

                                                If TempBadgeSeq = SavedBadge.BadgeNumber Then
                                                    'aBadges(j).BadgeSeq = "0" + (j + 1).ToString
                                                    aBadges(j).FirstName = SavedBadge.FirstName
                                                    aBadges(j).FullName = SavedBadge.FullName
                                                    aBadges(j).City = SavedBadge.City
                                                    aBadges(j).CompanyName = SavedBadge.Company
                                                    aBadges(j).State = SavedBadge.State
                                                    aBadges(j).PostalCode = SavedBadge.PostalCode
                                                    aBadges(j).BadgeTypeCode = SavedBadge.BadgeTypeCode ' missing

                                                    Dim oSavedUser As New SavedUser
                                                    oSavedUser.FullName = aBadges(j).FullName
                                                    oSavedUser.AllInfo = _
                                                    aBadges(j).FirstName + "|" + _
                                                    aBadges(j).FullName + "|" + _
                                                     aBadges(j).CompanyName + "|" + _
                                                     aBadges(j).City + "|" + _
                                                     aBadges(j).State + "|" + _
                                                    aBadges(j).PostalCode

                                                    Dim already As Boolean = False
                                                    If aSavedUser IsNot Nothing Then
                                                        If aSavedUser.Count > 0 Then
                                                            For k As Integer = 0 To aSavedUser.Count - 1
                                                                Dim tempSavedUser As SavedUser = CType(aSavedUser(k), SavedUser)
                                                                If tempSavedUser IsNot Nothing Then
                                                                    If tempSavedUser.FullName = oSavedUser.FullName Then
                                                                        If tempSavedUser.AllInfo = oSavedUser.AllInfo Then
                                                                            already = True
                                                                            Exit For
                                                                        End If
                                                                    End If
                                                                End If
                                                            Next
                                                        End If
                                                    End If
                                                    If already = False Then
                                                        aSavedUser.Add(oSavedUser)
                                                    End If
                                                    Exit For
                                                End If
                                            Next

                                        Else
                                            oProductLine.BadgeCount = 0
                                        End If

                                    Next

                                    oProductLine.Badges = aBadges

                                    aAllProducts.Add(oProductLine)

                                End If
                            End If
                        Next

                        Dim SavedUserList() As SavedUser = Nothing
                        If aSavedUser IsNot Nothing Then
                            If aSavedUser.Count > 0 Then
                                Dim tempSavedUserList(aSavedUser.Count - 1) As SavedUser
                                aSavedUser.CopyTo(tempSavedUserList)
                                SavedUserList = tempSavedUserList
                            End If
                        End If

                        Dim AllProducts() As ProductLine = Nothing
                        If aAllProducts IsNot Nothing Then
                            If aAllProducts.Count > 0 Then
                                Dim tempAllProducts(aAllProducts.Count - 1) As ProductLine
                                aAllProducts.CopyTo(tempAllProducts)
                                AllProducts = tempAllProducts
                            End If
                        End If

                        ' --------AN Cuna Fix
                        If AllProducts IsNot Nothing Then


                            For i As Integer = 0 To AllProducts.Length - 1
                                If AllProducts(i).MasterProductFlag Then
                                    AllProducts(i).TotalBadgesForMeeting = GetTotalBageCountForMeeting(AllProducts(i).OrderLineNumber, AList)
                                End If
                            Next
                        End If
                        ShowBadges(AllProducts, SavedUserList)


                    End If
                End If
            End If
        End Sub
        Private Function GetTotalBageCountForMeeting(ByVal MeetingCartItemId As Integer, ByVal AShoppingList As ArrayList) As Integer

            Dim intCount As Integer = 0
            Dim aShoppingCartInfo As ShoppingCartInfo

            For i As Integer = 0 To AShoppingList.Count - 1
                aShoppingCartInfo = CType(AShoppingList(i), ShoppingCartInfo)

                'If aShoppingCartInfo.CartItemId = MeetingCartItemId OrElse aShoppingCartInfo.RelatedCartItemId = MeetingCartItemId Then
                '    intCount = intCount + (aShoppingCartInfo.MaxBadges * aShoppingCartInfo.Quantity)
                'End If

                If aShoppingCartInfo.CartItemId = MeetingCartItemId OrElse aShoppingCartInfo.RelatedCartItemId = MeetingCartItemId Then
                    'For Meetings and Sessions if master products

                    If aShoppingCartInfo.ProductType = "BADGE" Then
                        intCount = intCount + aShoppingCartInfo.Quantity
                    Else
                        intCount = intCount + (aShoppingCartInfo.MaxBadges * aShoppingCartInfo.Quantity)
                    End If



                End If

            Next
            Return intCount

        End Function

		Private Sub ShowBadges(ByRef AllProducts() As ProductLine, ByVal SavedUserList() As SavedUser)

			If AllProducts IsNot Nothing AndAlso AllProducts.Length > 0 Then

				Dim templatefile As String = ""
				Try
					templatefile = ModulePath + "Templates\" + Settings(C_BADGETEMPLATE).ToString()
					'templatefile = ModulePath + "Templates/BadgeTemplate.xsl"
				Catch ex As Exception
					DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
					'MessageControl.ShowMessage(Localization.GetString("WrongTemplate.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.YellowWarning)
				End Try

				BadgesXslTemplate.Visible = True
				BadgesXslTemplate.XSLfile = Server.MapPath(templatefile)
				'Session("UpSellItems") = us
				BadgesXslTemplate.AddObject("", AllProducts)
				BadgesXslTemplate.AddObject("", SavedUserList)
				BadgesXslTemplate.AddObject("ModuleId", ModuleId)
				BadgesXslTemplate.AddObject("Namenotset", Localization.GetString("Namenotset.Text", LocalResourceFile))
				BadgesXslTemplate.Display()

				Session("AllProducts" + ModuleId.ToString) = AllProducts

				Dim tempControl As Control
				For i As Integer = 0 To AllProducts.Length - 1

					Dim tempString As String

					tempString = ModuleId.ToString + "_" + AllProducts(i).OrderLineNumber.ToString
					tempControl = Me.FindControl("IndexLabel" + tempString)
					If (tempControl IsNot Nothing) Then
						Dim tempADDButton As Label = CType(tempControl, Label)
						tempADDButton.Text = Convert.ToString(AllProducts(i).BadgeCount + 1)
					End If

                    ' --------AN Cuna Fix
                    Dim TotalBadgesAvailable As Integer = 0
                    If WebpartMode = 1 Then
                        TotalBadgesAvailable = AllProducts(i).TotalBadgesForMeeting
                    Else
                        TotalBadgesAvailable = AllProducts(i).MaxBadges
                    End If
                    For j As Integer = 0 To TotalBadgesAvailable - 1


                        'For j As Integer = 0 To AllProducts(i).MaxBadges - 1

                        tempString = ModuleId.ToString + "_" + AllProducts(i).OrderLineNumber.ToString + "_" + AllProducts(i).Badges(j).BadgeSeq.ToString

                        tempControl = Me.FindControl("SaveButton" + tempString)

                        If (tempControl IsNot Nothing) Then
                            Dim tempSaveButton As LinkButton = CType(tempControl, LinkButton)
                            tempSaveButton.Attributes.Add("onClick", "javascript: SaveOpenBadge('OpenBadge" + ModuleId.ToString + "', 'cell" + tempString + "', 'SelectedOrderLineNumber" + ModuleId.ToString + "', 'cell" + ModuleId.ToString + "_" + AllProducts(i).OrderLineNumber.ToString + "');")
                            AddHandler tempSaveButton.Click, AddressOf SaveButton_Click
                        End If

                        tempControl = Me.FindControl("EditHyperLink" + tempString)
                        If (tempControl IsNot Nothing) Then
                            ' --------AN Cuna Fix
                            Dim tempEditHyperLink As HyperLink = CType(tempControl, HyperLink)

                            Dim strText As String = ""

                            If AllProducts(i).Badges(j).BadgeTypeCode IsNot Nothing Then
                                strText = Localization.GetString("EditLink.Text", LocalResourceFile)
                                If AllProducts(i).Badges(j).IsPaidBadge = True Then
                                    strText = String.Concat(strText, " Paid Badge")
                                Else
                                    strText = String.Concat(strText, " Free Badge")
                                End If

                                tempEditHyperLink.Text = strText
                            Else
                                strText = Localization.GetString("CreateLink.Text", LocalResourceFile)
                                If AllProducts(i).Badges(j).IsPaidBadge = True Then
                                    strText = String.Concat(strText, " Paid Badge")
                                Else
                                    strText = String.Concat(strText, " Free Badge")
                                End If

                                tempEditHyperLink.Text = strText
                            End If


                        End If

                        tempControl = Me.FindControl("BadgeTypePlaceHolder" + tempString)
                        If (tempControl IsNot Nothing) Then
                            Dim tempPlaceHolder As PlaceHolder = CType(tempControl, PlaceHolder)
                            Dim tempApplicationCodeDropDownList As New Personify.WebControls.ApplicationCodeDropDownList
                            tempApplicationCodeDropDownList.ID = "BadgeType" + tempString
                            tempApplicationCodeDropDownList.ApplicationType = "BADGE_TYPE"
                            tempApplicationCodeDropDownList.Subsystem = "MTG"
                            tempPlaceHolder.Controls.Add(tempApplicationCodeDropDownList)
                        End If

                    Next

                Next
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "No badges available for this meeting", Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If

		End Sub

		Private Function GetValueOfApplicationCodeDropDownList(ByVal id As String) As String
			Dim tempControl As Control
			tempControl = Me.FindControl(id)
			If (tempControl IsNot Nothing) Then
				Dim tempApplicationCodeDropDownList As Personify.WebControls.ApplicationCodeDropDownList = CType(tempControl, Personify.WebControls.ApplicationCodeDropDownList)
				Return tempApplicationCodeDropDownList.SelectedValue
			End If
			Return Nothing
		End Function

		Private Function GetValueOfTextBox(ByVal id As String) As String
			Dim tempControl As Control
			tempControl = Me.FindControl(id)
			If (tempControl IsNot Nothing) Then
				Dim tempTextBox As TextBox = CType(tempControl, TextBox)
				Return tempTextBox.Text
			End If
			Return Nothing
		End Function

		Private Sub SetValueOfTextBox(ByVal id As String)
			Dim tempControl As Control
			tempControl = Me.FindControl(id)
			If (tempControl IsNot Nothing) Then
				Dim tempTextBox As TextBox = CType(tempControl, TextBox)
				tempTextBox.Text = ""
			End If

		End Sub
		Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)

			Dim badge As String = CType(sender, LinkButton).ID
			badge = badge.Replace("SaveButton", "")

			Dim BadgeType As String = GetValueOfApplicationCodeDropDownList("BadgeType" + badge)
			Dim FirstName As String = GetValueOfTextBox("FirstName" + badge)
			Dim FullName As String = GetValueOfTextBox("FullName" + badge)
			Dim CompanyName As String = GetValueOfTextBox("CompanyName" + badge)
			Dim City As String = GetValueOfTextBox("City" + badge)
			Dim State As String = GetValueOfTextBox("State" + badge)
			Dim PostalCode As String = GetValueOfTextBox("PostalCode" + badge)

			Dim tBadge As String() = badge.Split(CType("_", Char))

			Dim OrderLineNumber As Integer = Convert.ToInt32(tBadge(1))

			Dim OldBadgeSeq As String = Convert.ToString(tBadge(2))

			Dim BadgeSeq As String = "0"
			Dim tempString As String = ModuleId.ToString + "_" + OrderLineNumber.ToString + "_" + OldBadgeSeq.ToString
			Dim tempControl As Control
			tempControl = Me.FindControl("BadgeSeqLabel" + tempString)
			If (tempControl IsNot Nothing) Then
				Dim tempBadgeSeqLabel As Label = CType(tempControl, Label)
				BadgeSeq = tempBadgeSeqLabel.Text
            End If

            ' --------AN Cuna Fix
            Dim IsPaidBadge As Boolean = False

            tempControl = Me.FindControl("IsPaidBadge" + tempString)
            If (tempControl IsNot Nothing) Then
                If String.Compare(CType(tempControl, Label).Text, "TRUE", True) = 0 Then
                    IsPaidBadge = True
                End If
            End If


            Dim mode As TransactionMode = TransactionMode.EDIT
			If BadgeSeq(0) = "0" Then
                mode = TransactionMode.ADD
				If WebpartMode = 1 Then
					BadgeSeq = "0"
				Else
					BadgeSeq = BadgeSeq.Substring(1)
				End If
			End If

			Dim isError As Boolean = False ' is error saving the badge

			If WebpartMode = 1 Then

                Dim oOrderDetailBadges As TIMSS.API.OrderInfo.IOrderDetailBadges = _
                AddBadge(mode, OrderNumber, OrderLineNumber, Convert.ToInt32(BadgeSeq), BadgeType, _
                FirstName, FullName, CompanyName, "", City, State, PostalCode, IsPaidBadge)


				If oOrderDetailBadges.ValidationIssues IsNot Nothing Then
					If oOrderDetailBadges.ValidationIssues.Count > 0 Then
						isError = True
					End If
				End If


				If isError = True Then

					Dim OpenBadge As String = Convert.ToString(Request("OpenBadge" + ModuleId.ToString))
					Dim SelectedOrderLineNumber As String = Convert.ToString(Request("SelectedOrderLineNumber" + ModuleId.ToString))

					If OpenBadge IsNot Nothing Then
						If OpenBadge.Length > 0 Then
							Dim SCRIPT As String = "<script language=""javascript"" type=""text/javascript""> EditBadge('" + SelectedOrderLineNumber + "','" + OpenBadge + "_0');" + _
							" Preview('" + OpenBadge + "'); </script>"
							Page.ClientScript.RegisterStartupScript(GetType(String), "scpShowBadgeAgain", SCRIPT)

						End If
					End If

					tempString = ModuleId.ToString + "_" + OrderLineNumber.ToString + "_" + OldBadgeSeq.ToString

					tempControl = Me.FindControl("ErrorLabel" + tempString)

					If (tempControl IsNot Nothing) Then
						Dim tempErrorLabel As Label = CType(tempControl, Label)
						tempErrorLabel.Text = oOrderDetailBadges.ValidationIssues(0).Message
					End If

				Else
                    If mode = TransactionMode.ADD Then

                        tempControl = Me.FindControl("BadgeSeqLabel" + tempString)
                        If (tempControl IsNot Nothing) Then
                            Dim tempFullNameLabel As Label = CType(tempControl, Label)
                            tempFullNameLabel.Text = oOrderDetailBadges(0).BadgeSeq.ToString
                        End If
                    End If
				End If

			ElseIf WebpartMode = 2 Or WebpartMode = 3 Then
				Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
				oCartController.AddUpdateBadge(OrderLineNumber, Convert.ToInt32(BadgeSeq), BadgeType, FirstName, FullName, CompanyName, City, State, PostalCode)
			End If

			If isError = False Then

				tempString = ModuleId.ToString + "_" + OrderLineNumber.ToString + "_" + OldBadgeSeq.ToString

				tempControl = Me.FindControl("FullNameLabel" + tempString)
				If (tempControl IsNot Nothing) Then
					Dim tempFullNameLabel As Label = CType(tempControl, Label)
					tempFullNameLabel.Text = FullName
				End If

                If mode = TransactionMode.ADD Or WebpartMode = 2 Then
                    tempControl = Me.FindControl("EditHyperLink" + tempString)
                    If (tempControl IsNot Nothing) Then
                        Dim tempEditHyperLink As HyperLink = CType(tempControl, HyperLink)
                        tempEditHyperLink.Text = Localization.GetString("EditLink.Text", LocalResourceFile)
                    End If
                End If

			End If
            Page.Response.Redirect(Page.Request.Url.ToString(), True)

		End Sub

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

#Region "Personidfy Data"
        Private Function GetTotalBageCountForOrderMeeting(ByVal MeetingLineNumber As Integer, ByVal AWebBadge() As WebBadge) As Integer

            Dim intCount As Integer = 0

            For i As Integer = 0 To AWebBadge.Length - 1
                If AWebBadge(i).MeetingLineNumber = MeetingLineNumber Then
                    intCount = intCount + (AWebBadge(i).MaxBadges)
                End If
            Next
            Return intCount

        End Function
        Private Function GetTotalPaidBageCountForOrderMeeting(ByVal MeetingLineNumber As Integer, ByVal AWebBadge() As WebBadge) As Integer

            Dim intCount As Integer = 0

            For i As Integer = 0 To AWebBadge.Length - 1
                If AWebBadge(i).MeetingLineNumber = MeetingLineNumber AndAlso AWebBadge(i).ProductType = "BADGE" Then
                    intCount = intCount + (AWebBadge(i).MaxBadges)
                End If
            Next
            Return intCount

        End Function

        Private Function GetBadgesInfo(ByVal MCID As String, ByVal SCID As Integer, ByVal OrderNumber As String) As WebBadge()

            Dim aWebBadge As New ArrayList

            Dim oOrderDetails As TIMSS.API.OrderInfo.IOrderDetails



            oOrderDetails = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetails")
            oOrderDetails.Filter.Add("ShipMasterCustomerId", MCID)
            oOrderDetails.Filter.Add("ShipSubCustomerId", SCID)
            'oOrderDetails.Filter.Add("Subsystem", "MTG")
            oOrderDetails.Filter.Add("OrderNumber", OrderNumber)
            'an cuna fix ..
            oOrderDetails.Filter.Add("Subsystem", "MTG")

            oOrderDetails.Fill()

            'AN Cuna Fix Clean up a bit of code here .. many of the if statements are not needed
            'If oOrderDetails IsNot Nothing Then
            For i As Integer = 0 To oOrderDetails.Count - 1
                'If oOrderDetails(i) IsNot Nothing Then

                Dim RateCode As String = oOrderDetails(i).RateCodeString
                Dim RateStructureString As String = oOrderDetails(i).RateStructureString

                'If oOrderDetails(i).Product IsNot Nothing Then
                '    If oOrderDetails(i).Product.RateCodes IsNot Nothing Then
                '        If oOrderDetails(i).Product.RateCodes.Count > 0 Then
                If oOrderDetails(i).OrderLineNumber = oOrderDetails(i).RelatedLineNumber OrElse oOrderDetails(i).ProductTypeCodeString = "BADGE" Then
                    For j As Integer = 0 To oOrderDetails(i).Product.RateCodes.Count - 1
                        Dim currentRateCode As String = oOrderDetails(i).Product.RateCodes(j).RateCodeString
                        Dim currentRateStructureString As String = oOrderDetails(i).Product.RateCodes(j).RateStructureString

                        If currentRateCode.ToString = RateCode.ToString And currentRateStructureString = RateStructureString Then
                            Dim oWebBadge As New WebBadge
                            oWebBadge.ProductName = oOrderDetails(i).Product.ShortName
                            oWebBadge.OrderLineNumber = oOrderDetails(i).OrderLineNumber
                            oWebBadge.CycleBeginDate = oOrderDetails(i).CycleBeginDate
                            oWebBadge.CycleEndDate = oOrderDetails(i).CycleEndDate
                            oWebBadge.MaxBadges = oOrderDetails(i).Product.RateCodes(j).MaxBadges
                            ' --------AN Cuna Fix
                            oWebBadge.ProductType = oOrderDetails(i).ProductTypeCode.Code
                            oWebBadge.MeetingLineNumber = oOrderDetails(i).RelatedLineNumber

                            If oOrderDetails(i).OrderLineNumber = oOrderDetails(i).RelatedLineNumber Then
                                oWebBadge.MasterProductFlag = True
                            Else
                                oWebBadge.MasterProductFlag = False
                            End If
                            'Public ProductType As String
                            'Public TotalBadgesForMeeting As Integer
                            'Public TotalPaidBadgesForMeeting As Integer
                            'Public MeetingLineNumber As Integer
                            'Public MasterProductFlag As Boolean


                            If oOrderDetails(i).ProductTypeCodeString = "BADGE" Then
                                oWebBadge.MaxBadges = oOrderDetails(i).OrderQuantity
                            End If
                            oWebBadge.Badges = oOrderDetails(i).Badges
                            aWebBadge.Add(oWebBadge)
                            Exit For

                        End If
                    Next
                End If
                '        End If
                '    End If
                'End If
                ' End If
            Next
            ' End If
            ' --------AN Cuna Fix
            'If aWebBadge IsNot Nothing Then
            '    If aWebBadge.Count > 0 Then
            '        Dim WebBadges(aWebBadge.Count - 1) As WebBadge
            '        aWebBadge.CopyTo(WebBadges)
            '        Return WebBadges
            '    End If
            'End If

            If aWebBadge IsNot Nothing Then
                If aWebBadge.Count > 0 Then
                    Dim WebBadges(aWebBadge.Count - 1) As WebBadge
                    aWebBadge.CopyTo(WebBadges)
                    ' --------AN FIX CQ - 3246-7931501
                    For j As Integer = 0 To WebBadges.Length - 1
                        If WebBadges(j).ProductType = "M" OrElse WebBadges(j).MasterProductFlag = True Then
                            WebBadges(j).TotalBadgesForMeeting = GetTotalBageCountForOrderMeeting(WebBadges(j).MeetingLineNumber, WebBadges)
                            WebBadges(j).TotalPaidBadgesForMeeting = GetTotalPaidBageCountForOrderMeeting(WebBadges(j).MeetingLineNumber, WebBadges)

                        Else

                        End If
                    Next

                    Dim intMEeting As Integer = 0
                    Dim oReturnWebBadges(intMEeting) As Personify.ApplicationManager.PersonifyDataObjects.WebBadge


                    For j As Integer = 0 To WebBadges.Length - 1
                        If WebBadges(j).ProductType = "M" OrElse WebBadges(j).MasterProductFlag = True Then

                            If intMEeting > 0 Then
                                ReDim Preserve oReturnWebBadges(intMEeting)
                            End If

                            oReturnWebBadges(intMEeting) = New WebBadge

                            oReturnWebBadges(intMEeting).ProductName = WebBadges(j).ProductName
                            oReturnWebBadges(intMEeting).Badges = WebBadges(j).Badges
                            oReturnWebBadges(intMEeting).MaxBadges = WebBadges(j).MaxBadges
                            oReturnWebBadges(intMEeting).OrderLineNumber = WebBadges(j).OrderLineNumber

                            oReturnWebBadges(intMEeting).CycleBeginDate = WebBadges(j).CycleBeginDate
                            oReturnWebBadges(intMEeting).CycleEndDate = WebBadges(j).CycleEndDate

                            oReturnWebBadges(intMEeting).ProductType = WebBadges(j).ProductType
                            oReturnWebBadges(intMEeting).MasterProductFlag = WebBadges(j).MasterProductFlag

                            oReturnWebBadges(intMEeting).TotalBadgesForMeeting = WebBadges(j).TotalBadgesForMeeting
                            oReturnWebBadges(intMEeting).TotalPaidBadgesForMeeting = WebBadges(j).TotalPaidBadgesForMeeting
                            oReturnWebBadges(intMEeting).MeetingLineNumber = WebBadges(j).MeetingLineNumber

                            intMEeting = intMEeting + 1
                        End If
                    Next


                    Return oReturnWebBadges
                End If
            End If


            Return Nothing
        End Function

        Private Function AddBadge( _
           ByVal mode As TransactionMode, _
                     ByVal OrderNumber As String, _
           ByVal OrderLineNumber As Integer, _
         ByVal BadgeSeq As Integer, _
           ByVal BadgeTypeCode As String, _
           ByVal FirstName As String, _
           ByVal FullName As String, _
           ByVal CompanyName As String, _
           ByVal BoothNumber As String, _
           ByVal City As String, _
           ByVal State As String, _
           ByVal PostalCode As String, _
          ByVal IsPaidBadge As Boolean) As TIMSS.API.OrderInfo.IOrderDetailBadges

            Dim oOrderDetailBadges As TIMSS.API.OrderInfo.IOrderDetailBadges
            Dim oSelectedBadge As TIMSS.API.OrderInfo.IOrderDetailBadge
            Dim oIsPaidBadge As Boolean = False


            Dim oOrderDetails As TIMSS.API.OrderInfo.IOrderDetails

            oOrderDetails = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetails")

            oOrderDetails.Fill(OrderNumber, OrderLineNumber)

            If oOrderDetails.Count > 0 Then
                If oOrderDetails(0).Subsystem = "MTG" AndAlso oOrderDetails(0).ProductTypeCodeString = "BADGE" Then
                    oIsPaidBadge = True
                End If

            End If


            oOrderDetailBadges = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetailBadges")

            If mode = TransactionMode.EDIT Then
                oOrderDetailBadges.Filter.Add("OrderNumber", OrderNumber)
                oOrderDetailBadges.Filter.Add("OrderLineNumber", OrderLineNumber)
                oOrderDetailBadges.Filter.Add("BadgeSeq", BadgeSeq)
                oOrderDetailBadges.Fill()
                oSelectedBadge = oOrderDetailBadges(0)
            Else
                'oSelectedBadge = oOrderDetailBadges.AddNew

                'oSelectedBadge = oOrderDetails(0).Badges.AddNew
                'oOrderDetailBadges = oOrderDetails(0).Badges
               ' --------AN Cuna Fix
                oOrderDetailBadges = oOrderDetails(0).ParentDetail.Badges
                oSelectedBadge = oOrderDetails(0).ParentDetail.Badges.AddNew
            End If

            With oSelectedBadge
                If mode = TransactionMode.ADD Then
                    .OrderNumber = OrderNumber

                    ' --------AN Cuna Fix
                    '.OrderLineNumber = OrderLineNumber
                    .OrderLineNumber = oOrderDetails(0).ParentDetail.OrderLineNumber
                    '.BadgeSeq = .BadgeSeq
                End If
                .BadgeTypeCode = .BadgeTypeCode.List(BadgeTypeCode).ToCodeObject
                .FirstName = FirstName
                .FullName = FullName
                .CompanyName = CompanyName
                .BoothNumber = BoothNumber
' --------AN Cuna Fix
                '.PaidFlag = oIsPaidBadge
                .PaidFlag = IsPaidBadge

                .City = City
                .State = State
                .PostalCode = PostalCode
            End With

            oOrderDetailBadges.Save()

            Return oOrderDetailBadges

        End Function


#End Region
    End Class

End Namespace
