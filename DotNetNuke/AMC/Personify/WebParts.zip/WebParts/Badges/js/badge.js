function hideID(id) {
	//safe function to hide an element with a specified id
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = 'none';
	}
	else {
		if (document.layers) { // Netscape 4
			document.id.display = 'none';
		}
		else { // IE 4
			document.all.id.style.display = 'none';
		}
	}
}

function showID(id) {
	//safe function to show an element with a specified id
		  
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = 'inline';
	}
	else {
		if (document.layers) { // Netscape 4
			document.id.display = 'inline';
		}
		else { // IE 4
			document.all.id.style.display = 'inline';
		}
	}
}

function EditBadge(hide,show) {
//	alert(hide + ">>>"+show);
	//hideID(hide);
	showID(show);
}

function setline(id, value) {

	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).innerHTML = value
	}
	else {
		if (document.layers) { // Netscape 4
			eval("document."+id).innerHTML = value
		}
		else { // IE 4
			eval("document.all."+id).innerHTML = value
		}
	}
}

function setfiled(id, val) {

	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).value =val
	}
	else {
		if (document.layers) { // Netscape 4
			eval("document."+id).value = val
		}
		else { // IE 4
			eval("document.all."+id).value = val
		}
	}
}


function getElementByPartialId(id) {
	if (document.forms[0].elements != null)
		for (i=0; i<document.forms[0].elements.length-1;i++ )
			if (document.forms[0].elements[i].name.indexOf(id)>0) {
				return document.forms[0].elements[i];
			}
}

function FillBadge(badge, info)
{
	inf = info.split('|');
	if (info.length>=5) {
		getElementByPartialId("FirstName"+badge).value = inf[0];
		getElementByPartialId("FullName"+badge).value = inf[1];
		getElementByPartialId("CompanyName"+badge).value = inf[2];
		getElementByPartialId("City"+badge).value = inf[3];
		getElementByPartialId("State"+badge).value = inf[4];
		
		getElementByPartialId("PostalCode"+badge).value = inf[5];

		setline('Line'+badge+'_1',inf[0]);
		setline('Line'+badge+'_2',inf[1]);
		setline('Line'+badge+'_3',inf[2]);
		setline('Line'+badge+'_4',inf[3]);
		setline('Line'+badge+'_5',inf[4]);
		//no PostalCode
}
}


function SaveOpenBadge(hiddenID, badge, hiddenID2, OrderLineNumber)
{

//alert(hiddenID+">>>"+ badge+">>>"+ hiddenID2+">>>"+  OrderLineNumber);
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(hiddenID).value = badge;
	}
	else {
		if (document.layers) { // Netscape 4
			document.hiddenID.value = badge;
		}
		else { // IE 4
			document.all.hiddenID.value = badge;
		}
	}

	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(hiddenID2).value = OrderLineNumber;
	}
	else {
		if (document.layers) { // Netscape 4
			document.hiddenID2.value = OrderLineNumber;
		}
		else { // IE 4
			document.all.hiddenID2.value = OrderLineNumber;
		}
	}
}

function GetValueById(id)
{
	if (document.getElementById) { // DOM3 = IE5, NS6
		return document.getElementById(id).value
	}
	else {
		if (document.layers) { // Netscape 4
			return document.id.value;
		}
		else { // IE 4
			return document.all.id.value;
		}
	}
}

function GetValueByPartialId(id)
{

	return getElementByPartialId(id).value;
}

function Preview(BadgeSeq)
{
	temp = BadgeSeq.replace("cell","").replace("add","");
	setline('Line'+temp+'_1',GetValueByPartialId('FirstName'+temp));
	setline('Line'+temp+'_2',GetValueByPartialId('FullName'+temp));
	setline('Line'+temp+'_3',GetValueByPartialId('CompanyName'+temp));
	setline('Line'+temp+'_4',GetValueByPartialId('City'+temp));
	setline('Line'+temp+'_5',GetValueByPartialId('State'+temp));

}