Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO


Namespace Personify.DNN.Modules.MyMeetingAgenda

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public MustInherit Class MyMeetingAgenda
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        

#Region " Private Variables "
      
        Private _ProductId As Integer
        Private _OrderNumber As String

#End Region

#Region "Controls"
        Protected WithEvents dlMeetings As DataList
        Protected WithEvents rpSessions As Repeater
        Protected WithEvents lblMeetingCount As Label
#End Region

#Region "Event Handlers"

       
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
           

            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
               

                If Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin" Then

                    If Request.QueryString("ProductId") IsNot Nothing AndAlso IsNumeric(Request.QueryString("ProductId")) Then
                        _ProductId = CInt(Request.QueryString("ProductId"))
                    End If

                    If Request.QueryString("OrderNumber") IsNot Nothing AndAlso IsNumeric(Request.QueryString("OrderNumber")) Then
                        _OrderNumber = Request.QueryString("OrderNumber")
                    End If

                    'End If
                    LoadMyCurrentMeetings()

                Else
                    DisplayUserAccessMessage(role)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' <summary>
        ''' Loads meeting and session data and bind to datalist
        ''' the its nested repeater
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub LoadMyCurrentMeetings()
            Dim oMeetingInfo As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
            Dim oSessionsInfo As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
            Dim intMeetingCount As Integer

            oMeetingInfo = DF_GetCustomerMeetings(MasterCustomerId, SubCustomerId, _OrderNumber)
            intMeetingCount = oMeetingInfo.FindAll("ProductTypeCode", "M").Length

            If intMeetingCount > 0 Then
                ' Display the total available meetings
                lblMeetingCount.Visible = True
                lblMeetingCount.Text = String.Format(Localization.GetString("lblMeetingCount", LocalResourceFile), intMeetingCount)

                ' Bind the datalist with the meetings registered for

                dlMeetings.DataSource = oMeetingInfo.FindAll("ProductTypeCode", "M")
                dlMeetings.DataBind()

                For i As Integer = 0 To intMeetingCount - 1
                    Dim rp As Repeater
                    rp = CType(dlMeetings.Items(i).FindControl("rpSessions"), Repeater)

                    oSessionsInfo = oMeetingInfo.GetSubProductsForAMeeting(MasterCustomerId, SubCustomerId, oMeetingInfo(i).ProductCode, oMeetingInfo(i).ProductCode, oMeetingInfo(i).OrderNumber, CInt(oMeetingInfo(i).OrderLineNumber))

                    rp.DataSource = oSessionsInfo
                    rp.DataBind()
                Next
            Else
                'No meetings found
                lblMeetingCount.Visible = True
                lblMeetingCount.Text = Localization.GetString("NoMeetings", LocalResourceFile)
            End If

        End Sub

        ''' <summary>
        ''' Build the event's vCalendar format and enables download
        ''' </summary>
        ''' <param name="BeginDate"></param>
        ''' <param name="EndDate"></param>
        ''' <param name="Location"></param>
        ''' <param name="Subject"></param>
        ''' <param name="Description"></param>
        ''' <remarks></remarks>
        Private Sub ExportEvent(ByVal BeginDate As Date, ByVal EndDate As Date, ByVal Location As String, ByVal Subject As String, ByVal Description As String)

            'Initialize the stream
            Dim _Stream As New MemoryStream()
            Dim _StreamWriter As New StreamWriter(_Stream)
            _StreamWriter.AutoFlush = True

            'Header
            _StreamWriter.WriteLine("BEGIN:VCALENDAR")
            _StreamWriter.WriteLine("PRODID:-//TMA Resources, Inc.//Personify//EN")
            _StreamWriter.WriteLine("BEGIN:VEVENT")

            'Body
            _StreamWriter.WriteLine("DTSTART:" & BeginDate.ToUniversalTime.ToString("yyyyMMdd\THHmmss\Z"))
            _StreamWriter.WriteLine("DTEND:" & EndDate.ToUniversalTime.ToString("yyyyMMdd\THHmmss\Z"))
            _StreamWriter.WriteLine("LOCATION:" & Location)
            _StreamWriter.WriteLine("DESCRIPTION;ENCODING=QUOTED-PRINTABLE:" & Description)
            _StreamWriter.WriteLine("SUMMARY:" & Subject)

            'Footer
            _StreamWriter.WriteLine("PRIORITY:3")
            _StreamWriter.WriteLine("END:VEVENT")
            _StreamWriter.WriteLine("END:VCALENDAR")

            'Download it to the client
            Response.Clear() 'clears the current output content from the buffer
            Response.AppendHeader("Content-Disposition", _
                     "attachment; filename=" & Subject & ".vcs")
            Response.AppendHeader("Content-Length", _Stream.Length.ToString())
            Response.ContentType = "application/download"
            Response.BinaryWrite(_Stream.ToArray())
            Response.End()
        End Sub

#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region " Commands "

        ''' <summary>
        ''' Commands received from the repeater
        ''' </summary>
        ''' <param name="source"></param>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Protected Sub rpSessions_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)

            Dim Subject As Literal = CType(e.Item.FindControl("litSessionTitle"), Literal)
            Dim StartDate As Literal = CType(e.Item.FindControl("litSessionStartDate"), Literal)
            Dim EndDate As Literal = CType(e.Item.FindControl("litSessionEndDate"), Literal)
            Dim Location As Label = CType(e.Item.FindControl("lblLocation"), Label)
            Dim Description As Label = CType(e.Item.FindControl("lblDescription"), Label)

            If e.CommandName = "ExportEvent" Then
                Try
                    ExportEvent(CDate(StartDate.Text), CDate(EndDate.Text), Location.Text, Subject.Text, Description.Text)
                Catch ex As Exception

                End Try
            End If
        End Sub

        Protected Sub rpSessions_ItemDataBound(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rpSessions.ItemDataBound
            '3246-5774803
            If e.Item.FindControl("imgCalendarDown") IsNot Nothing Then
                Dim imgCalendarDown As Image = CType(e.Item.FindControl("imgCalendarDown"), Image)

                With imgCalendarDown

                    .ImageUrl = "~/" & SiteImagesFolder & "/calendar_down.gif"
                    .AlternateText = Localization.GetString("ExportToMyCalendar")
                End With
            End If
            'end 3246-5774803
        End Sub

        ''' <summary>
        ''' Commands received from the datalist
        ''' </summary>
        ''' <param name="source"></param>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub dlMeetings_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles dlMeetings.ItemCommand
            If e.CommandName.ToLower = "gotodetail" Then
                'If the product is web enabled then redirect
                If CInt(e.CommandArgument) > 0 AndAlso Settings("MeetingDetailUrl") IsNot Nothing Then
                    Response.Redirect(NavigateURL(CType(Settings("MeetingDetailUrl"), Integer), "", "ProductId=" & e.CommandArgument.ToString))
                Else
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NotWebEnabled", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If
            End If

        End Sub
        '3246-5774803
        Private Sub dlMeetings_ItemDataBound(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles dlMeetings.ItemDataBound
            If e.Item.FindControl("imgCalendar") IsNot Nothing Then
                Dim imgCalendar As Image = CType(e.Item.FindControl("imgCalendar"), Image)

                With imgCalendar

                    .ImageUrl = "~/" & SiteImagesFolder & "/calendar.gif"
                    Dim hlMeetingTitle As LinkButton = CType(e.Item.FindControl("hlMeetingTitle"), LinkButton)
                    .AlternateText = hlMeetingTitle.Text
                End With
            End If
        End Sub
        'end 3246-5774803

#End Region

        Private Function DF_GetCustomerMeetings(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal OrderNumber As String) As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList


            Dim oMeetings As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
            oMeetings = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebCurrMeetingRegistrationsViewList")

            With oMeetings
                .Filter.Add("ShipMasterCustomerId", MasterCustomerId)
                .Filter.Add("ShipSubCustomerId", SubCustomerId.ToString)

                If OrderNumber IsNot Nothing Then
                    .Filter.Add("OrderNumber", OrderNumber)
                End If
                .Fill()
            End With

            
            Return oMeetings
        End Function

    End Class


End Namespace
