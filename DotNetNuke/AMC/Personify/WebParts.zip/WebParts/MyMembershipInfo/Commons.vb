Namespace Personify.DNN.Modules.MyMembershipInfo

    Public Class ModuleSettingsNames
        Public Const MyMembershipRenewUrl As String = "MyMembershipRenewUrl"
        Public Const MyMembershipRenewUrlType As String = "MyMembershipRenewUrlType"
        Public Const MyMembershipViewAllUrl As String = "MyMembershipViewAllUrl"
        Public Const MyMembershipViewAllUrlType As String = "MyMembershipViewAllUrlType"
        Public Const MyMembershipDisplayAll As String = "MyMembershipDisplayAll"
        Public Const MyMembershipRenewalWindow As String = "MyMembershipRenewalWindow"

        Public Const MyMembershipJoinNowUrl As String = "MyMembershipJoinNowUrl"
        Public Const MyMembershipJoinNowUrlType As String = "MyMembershipJoinNowUrlType"
        'Public Const MyMembershipViewAllUrl As String = "MyMembershipViewAllUrl"
        'Public Const MyMembershipViewAllUrlType As String = "MyMembershipViewAllUrlType"
    End Class

End Namespace
