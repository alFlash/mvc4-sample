Option Strict Off
Imports System
Imports System.Web
Imports personify
Imports System.IO



Namespace Personify.DNN.Modules.MyMembershipInfo

    Public MustInherit Class MyMembershipInfo
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"

        'Protected WithEvents dlstMembershipInfo As System.Web.UI.WebControls.DataList
        'Protected WithEvents pnlMembershipInfo As System.Web.UI.WebControls.Panel
        'Protected WithEvents lblMemberSince As System.Web.UI.WebControls.Label
        'Protected WithEvents lblMemberSinceValue As System.Web.UI.WebControls.Label
        'Protected WithEvents lblMembershipStatus As System.Web.UI.WebControls.Label
        'Protected WithEvents lblMembershipStatusValue As System.Web.UI.WebControls.Label
        'Protected WithEvents lblNextRenewalDate As System.Web.UI.WebControls.Label
        'Protected WithEvents lblNextRenewalDateValue As System.Web.UI.WebControls.Label
        'Protected WithEvents hlnkRenewMembership As System.Web.UI.WebControls.HyperLink
        'Protected WithEvents lblMembershipTitle As System.Web.UI.WebControls.Label
        'Protected WithEvents hlnkJoinNow As System.Web.UI.WebControls.HyperLink
        'Protected WithEvents hlnkViewAll As System.Web.UI.WebControls.HyperLink
        'Protected WithEvents pnlMembershipDetail As System.Web.UI.WebControls.Panel
        'Protected WithEvents dlstAllMemberships As System.Web.UI.WebControls.DataList
        'Protected WithEvents dlstPrimaryMemberships As System.Web.UI.HtmlControls.HtmlTable
        'Protected WithEvents hypDtlMbrRenew As System.Web.UI.WebControls.HyperLink
        'Protected WithEvents lblDtlMbrExpiration As System.Web.UI.WebControls.Label
        'Protected WithEvents NoMembershipMessage As System.Web.UI.WebControls.Label
        Protected MembershipTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents pnlShowMembershipInfo As System.Web.UI.WebControls.Panel
        Protected WithEvents lblNoMembershipMessage As System.Web.UI.WebControls.Label
#End Region

        Private ReadOnly Property RenewalWindowInDays() As Integer
            Get
                Return CInt(Settings(ModuleSettingsNames.MyMembershipRenewalWindow))
            End Get
        End Property

        Private ReadOnly Property DisplayAllMemberships() As Boolean
            Get
                Try
                    If DirectCast(Settings(ModuleSettingsNames.MyMembershipDisplayAll), String).ToLower = "true" Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    Return False
                End Try
            End Get
        End Property

        Private ReadOnly Property RenewActionURL() As String
            Get
                Dim intTab As Integer
                intTab = CInt(Settings(ModuleSettingsNames.MyMembershipRenewUrl))

                Return NavigateURL(intTab)
            End Get
        End Property

        Private ReadOnly Property ViewAllURL() As String
            Get

                Dim intTab As Integer
                intTab = CInt(Settings(ModuleSettingsNames.MyMembershipViewAllUrl))
                Return NavigateURL(intTab)
            End Get
        End Property

        Private ReadOnly Property JoinNowURL() As String
            Get

                Dim intTab As Integer
                intTab = CInt(Settings(ModuleSettingsNames.MyMembershipJoinNowUrl))
                Return NavigateURL(intTab)
            End Get
        End Property

        Private ReadOnly Property MaxRenewalDate() As Date
            Get
                Return Now.Date.AddDays(RenewalWindowInDays)
            End Get
        End Property

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim role As String
            role = Me.GetUserRole(UserInfo)
            Try

                If Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin" Then

                    Dim oMembershipList As TIMSS.API.MembershipInfo.IMembershipInfoViewList
                    Dim oPrimaryMembership As TIMSS.API.MembershipInfo.IMembershipInfoView

                    oMembershipList = DF_GetMyCurrentMemberships(MasterCustomerId, SubCustomerId)

                    Dim MembershipList(oMembershipList.Count - 1) As MembershipObject

                    If oMembershipList.Count > 0 Then
                        Dim counter As Integer = 0
                        For Each item As TIMSS.API.MembershipInfo.IMembershipInfoView In oMembershipList
                            Dim myMembershipObject As New MembershipObject
                            myMembershipObject.CycleEndDate = FormatDateTime(item.CycleEndDate)
                            myMembershipObject.GraceDate = FormatDateTime(item.GraceDate)
                            myMembershipObject.ProductShortName = item.ProductShortName
                            myMembershipObject.Counter = counter
                            myMembershipObject.User1ImageURL = ResolveUrl(GetUser1ImageURL())
                            myMembershipObject.CurrencyCode = item.CurrencyCode
                            MembershipList(counter) = myMembershipObject
                            counter = counter + 1
                        Next
                        Dim templatefile As String = ""
                        If Settings("Layout") Is Nothing Then
                            templatefile = ModulePath + "Templates\MyMembershipTemplate.xsl"
                        Else
                            templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
                        End If
                        If File.Exists(Server.MapPath(templatefile)) = False Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        Else

                            MembershipTemplate.XSLfile = Server.MapPath(templatefile)
                            MembershipTemplate.AddObject("", MembershipList)
                            MembershipTemplate.Display()
                            Dim pnlMembershipInfo As System.Web.UI.WebControls.Panel
                            pnlMembershipInfo = CType(Me.FindControl("pnlMembershipInfo".ToString), System.Web.UI.WebControls.Panel)
                            Dim pnlMembershipDetail As System.Web.UI.WebControls.Panel
                            pnlMembershipDetail = CType(Me.FindControl("pnlMembershipDetail".ToString), System.Web.UI.WebControls.Panel)
                            Try
                                pnlMembershipInfo.Visible = False
                            Catch ex As Exception
                            End Try

                            '3246-5774803
                            LoadImages()
                            'END 3246-5774803

                            Dim hlnkViewAll As System.Web.UI.WebControls.HyperLink
                            hlnkViewAll = CType(Me.FindControl("hlnkViewAll".ToString), System.Web.UI.WebControls.HyperLink)

                            If Not Page.IsPostBack Then


                                pnlMembershipInfo.Visible = True

                                Try
                                   
                                    hlnkViewAll.NavigateUrl = ViewAllURL

                                    oPrimaryMembership = Nothing
                                    For i As Integer = 0 To oMembershipList.Count - 1
                                        With oMembershipList(i)
                                            'TODO - Change the flags to Boolean Instead of Strings
                                            If .PrimaryLevel1Flag = "Y" And .PrimaryMemberGroupFlag = "Y" Then
                                                oPrimaryMembership = oMembershipList(i)
                                                Exit For
                                            End If
                                        End With
                                    Next

                                    pnlMembershipInfo.Visible = False
                                    pnlMembershipDetail.Visible = False
                                    Dim hlnkJoinNow As System.Web.UI.WebControls.HyperLink
                                    hlnkJoinNow = CType(Me.FindControl("hlnkJoinNow".ToString), System.Web.UI.WebControls.HyperLink)
                                    Dim NoMembershipMessage As System.Web.UI.WebControls.Label
                                    NoMembershipMessage = CType(Me.FindControl("NoMembershipMessage".ToString), System.Web.UI.WebControls.Label)
                                    'Display all memberships
                                    If DisplayAllMemberships = True Then
                                        'Disable Join Now Link
                                        hlnkJoinNow.Visible = False
                                        NoMembershipMessage.Visible = False
                                        'Disable Primary
                                        pnlMembershipDetail.Visible = True
                                        hlnkViewAll.Visible = False

                                        For Each item As MembershipObject In MembershipList
                                            Dim hypRenew As HyperLink
                                            Dim divButton As Panel
                                            Dim lblExp As Label
                                            hypRenew = DirectCast(Me.FindControl("hypDtlMbrRenew" & item.Counter.ToString), System.Web.UI.WebControls.HyperLink)
                                            lblExp = DirectCast(Me.FindControl("lblDtlMbrExpiration" & item.Counter.ToString), System.Web.UI.WebControls.Label)
                                            divButton = DirectCast(Me.FindControl("divButton" & item.Counter.ToString), System.Web.UI.WebControls.Panel)

                                            If Not lblExp Is Nothing Then
                                                If DisplayRenewMembershipLink(item.GraceDate) AndAlso item.CurrencyCode = PortalCurrency.Code Then
                                                    hypRenew.Visible = True
                                                    divButton.Visible = True
                                                    hypRenew.NavigateUrl = RenewActionURL
                                                Else
                                                    hypRenew.Visible = False
                                                    divButton.Visible = False
                                                End If
                                            End If

                                        Next


                                    Else
                                        'Display only the Primary Membership
                                        Dim hlnkRenewMembership As System.Web.UI.WebControls.HyperLink
                                        hlnkRenewMembership = CType(Me.FindControl("hlnkRenewMembership".ToString), System.Web.UI.WebControls.HyperLink)
                                        hlnkRenewMembership.Visible = False
                                        pnlMembershipInfo.Visible = True
                                        hlnkViewAll.Visible = True
                                        If Not oPrimaryMembership Is Nothing Then
                                            hlnkJoinNow.Visible = False
                                            With oPrimaryMembership
                                                Dim lblMembershipStatusValue As System.Web.UI.WebControls.Label
                                                lblMembershipStatusValue = CType(Me.FindControl("lblMembershipStatusValue".ToString), System.Web.UI.WebControls.Label)
                                                lblMembershipStatusValue.Text = .LineStatusCode.Description
                                                Dim lblMembershipTitle As System.Web.UI.WebControls.Label
                                                lblMembershipTitle = CType(Me.FindControl("lblMembershipTitle".ToString), System.Web.UI.WebControls.Label)
                                                lblMembershipTitle.Text = .ProductShortName
                                                Dim lblNextRenewalDateValue As System.Web.UI.WebControls.Label
                                                lblNextRenewalDateValue = CType(Me.FindControl("lblNextRenewalDateValue".ToString), System.Web.UI.WebControls.Label)
                                                lblNextRenewalDateValue.Text = .CycleEndDate.AddDays(1).ToShortDateString
                                                Dim lblMemberSinceValue As System.Web.UI.WebControls.Label
                                                lblMemberSinceValue = CType(Me.FindControl("lblMemberSinceValue".ToString), System.Web.UI.WebControls.Label)

                                                'lblMemberSinceValue.Text = ApplicationManager.Customer.GEtCustomerMembersinceDate(PortalId, MasterCustomerId, SubCustomerId).ToShortDateString
                                                lblMemberSinceValue.Text = .InitialBeginDate.ToShortDateString
                                            End With

                                            'Display renew membership only if falls withing the renewal window days

                                            If DisplayRenewMembershipLink(oPrimaryMembership.GraceDate) AndAlso oPrimaryMembership.CurrencyCode = PortalCurrency.Code Then
                                                hlnkRenewMembership.NavigateUrl = RenewActionURL
                                                hlnkRenewMembership.Visible = True
                                            End If
                                        Else
                                          
                                            NoMembershipMessage.Visible = True
                                            Dim dlstPrimaryMemberships As System.Web.UI.HtmlControls.HtmlTable
                                            dlstPrimaryMemberships = CType(Me.FindControl("dlstPrimaryMemberships".ToString), System.Web.UI.HtmlControls.HtmlTable)
                                            dlstPrimaryMemberships.Visible = False
                                            hlnkViewAll.Visible = False
                                            hlnkJoinNow.Visible = True
                                            hlnkJoinNow.NavigateUrl = JoinNowURL
                                        End If
                                    End If
                                Catch ex As Exception
                                    ProcessModuleLoadException(Me, ex)
                                End Try


                            End If


                        End If

                        lblNoMembershipMessage.Visible = False
                    Else
                        lblNoMembershipMessage.Visible = True
                    End If
                Else
                    DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End Try
        End Sub
 
        Private Function DisplayRenewMembershipLink(ByVal GraceDate As Date) As Boolean

            If MaxRenewalDate >= GraceDate Then
                Return True
            Else
                Return False
            End If

        End Function

        '3246-5774803
        Private Sub LoadImages()
          
            If FindControl("imgUser1") IsNot Nothing Then
                Dim imgUser1 As System.Web.UI.WebControls.Image = CType(FindControl("imgUser1"), System.Web.UI.WebControls.Image)
                imgUser1.ImageUrl = "~/" & SiteImagesFolder & "/user1.gif"
            End If

            If FindControl("imgIconBlank") IsNot Nothing Then
                Dim imgIconBlank As System.Web.UI.WebControls.Image = CType(FindControl("imgIconBlank"), System.Web.UI.WebControls.Image)
                imgIconBlank.ImageUrl = "~/" & SiteImagesFolder & "/icon_blank.gif"
            End If
        End Sub
        Private Function GetUser1ImageURL() As String
            Return "~/" & SiteImagesFolder & "/user1.gif"
        End Function
        'end 3246-5774803

#End Region

#Region "Optional Interfaces"
        'Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        '    'Get
        '    '    Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
        '    '    Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
        '    '    Return Actions
        '    'End Get
        'End Property

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
        ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
        ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        'End Sub

        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
        ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        'End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


        Private Function DF_GetMyCurrentMemberships(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.MembershipInfo.IMembershipInfoViewList
            Dim oMvw As TIMSS.API.MembershipInfo.IMembershipInfoViewList
            Dim strFilter As New Text.StringBuilder

            oMvw = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.MembershipInfo, "MembershipInfoViewList")

            oMvw.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            oMvw.Filter.Add("ShipSubCustomerId", SubCustomerId)
            With strFilter
                .Append("  (( (CYCLE_BEGIN_DATE <= GETDATE()) AND (FULFILL_STATUS_CODE = 'A')  AND (GRACE_DATE >= GETDATE()) AND (LINE_STATUS_CODE = 'A') ) ")
                .Append("	OR ")
                .Append(" ( (CYCLE_BEGIN_DATE <= GETDATE()) AND (FULFILL_STATUS_CODE = 'T')   AND (GRACE_DATE >= GETDATE()) AND (LINE_STATUS_CODE = 'A') ) ")
                .Append(" 	OR ")
                .Append(" (  (CYCLE_BEGIN_DATE <= GETDATE()) AND (FULFILL_STATUS_CODE = 'X')  AND (GRACE_DATE >= GETDATE()) AND (LINE_STATUS_CODE = 'A'))) ")
            End With
            oMvw.Filter.Add(New TIMSS.API.Core.FilterItem(strFilter.ToString))

            oMvw.Fill()

            Return oMvw
        End Function
     
    End Class
    Public Class MembershipObject
        Public ProductShortName As String
        Public CycleEndDate As String
        Public GraceDate As String
        Public Counter As Integer
        Public User1ImageURL As String
        Public CurrencyCode As String
    End Class

End Namespace
