Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: CLSCompliant(True)> 
<Assembly: AssemblyVersion("7.0.0.9")> 
