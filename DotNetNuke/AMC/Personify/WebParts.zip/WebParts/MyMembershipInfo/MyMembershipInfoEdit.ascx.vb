Imports System
Imports System.Web
Imports System.Web.UI
Imports System.IO
Imports System.Web.UI.WebControls

Namespace Personify.DNN.Modules.MyMembershipInfo

    Public MustInherit Class MyMembershipInfoEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Protected WithEvents chkExpandedView As System.Web.UI.WebControls.CheckBox

        Protected WithEvents rvExpirationDays As System.Web.UI.WebControls.RangeValidator
        Protected WithEvents rfExpirationInDays As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents rvRenewalWindowInDays As System.Web.UI.WebControls.RangeValidator
        Protected WithEvents rfRenewalWindowInDays As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtRenewalWindowInDays As System.Web.UI.WebControls.TextBox

        Protected WithEvents ctlViewAllURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlRenewURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlJoinNowURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
#End Region

#Region "Event Handlers"
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    If Not select_Template.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            If li.Text = "MyMembershipTemplate.xsl" Then
                                li.Selected = True
                            End If
                            select_Template.Items.Add(li)
                        Next
                        select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                    End If
                    If CType(Settings(ModuleSettingsNames.MyMembershipRenewalWindow), String) <> "" Then
                        txtRenewalWindowInDays.Text = CType(Settings(ModuleSettingsNames.MyMembershipRenewalWindow), String)
                    Else
                        txtRenewalWindowInDays.Text = "30"
                    End If

                    ctlViewAllURL.UrlType = CType(Settings(ModuleSettingsNames.MyMembershipViewAllUrlType), String)
                    ctlViewAllURL.Url = CType(Settings(ModuleSettingsNames.MyMembershipViewAllUrl), String)

                    ctlRenewURL.UrlType = CType(Settings(ModuleSettingsNames.MyMembershipRenewUrlType), String)
                    ctlRenewURL.Url = CType(Settings(ModuleSettingsNames.MyMembershipRenewUrl), String)

                    'Display all
                    If CType(Settings(ModuleSettingsNames.MyMembershipDisplayAll), String) <> "" Then
                        If CType(Settings(ModuleSettingsNames.MyMembershipDisplayAll), String).ToLower = "true" Then
                            chkExpandedView.Checked = True
                        Else
                            chkExpandedView.Checked = False
                        End If

                    End If

                    ctlJoinNowURL.UrlType = CType(Settings(ModuleSettingsNames.MyMembershipJoinNowUrlType), String)
                    ctlJoinNowURL.Url = CType(Settings(ModuleSettingsNames.MyMembershipJoinNowUrl), String)

                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try

                If Page.IsValid Then
                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting("Layout", select_Template.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.MyMembershipRenewalWindow, txtRenewalWindowInDays.Text)
                    UpdateModuleSetting(ModuleSettingsNames.MyMembershipDisplayAll, chkExpandedView.Checked.ToString)
                    UpdateModuleSetting(ModuleSettingsNames.MyMembershipRenewUrl, ctlRenewURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.MyMembershipViewAllUrl, ctlViewAllURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.MyMembershipJoinNowUrl, ctlJoinNowURL.Url)

                End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
