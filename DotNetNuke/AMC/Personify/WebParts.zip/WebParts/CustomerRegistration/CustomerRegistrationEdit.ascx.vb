Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Namespace Personify.DNN.Modules.CustomerRegistration

    Public MustInherit Class CustomerRegistrationEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region " Controls"
        Protected WithEvents lblAuthenticatedUserNavigateTo As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents ctlPostRegistrationNavigateToURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlAuthenticatedUserNavigateToURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents txtRegisterButtonCaption As System.Web.UI.WebControls.TextBox
        Protected WithEvents drpCustomerRecordType As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkCreateSegmentRecord As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkRequiresLogin As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAddressDetailFlagsDefaultChecked As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowAddressDetailFlags As System.Web.UI.WebControls.CheckBox
        Protected WithEvents pnlShowAddressDetailFlags As System.Web.UI.WebControls.Panel
        Protected WithEvents chkUseCompanyLookup As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents cboTemplate As WebControls.WebPartTemplateDropDownList
        Protected WithEvents chkSSO As New CheckBox

#End Region

#Region " Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then
                    LoadSettings()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            If Page.IsValid Then
                Try
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region " Helper functions"

        Private Sub LoadSettings()
            Try
                cboTemplate.WebPartTemplateFolder = ModulePath
                If (Not (CType(Settings(ModuleSettingsNames.C_TEMPLATE_FILE), String)) Is Nothing) Then
                    cboTemplate.DefaultValue = CType(Settings(ModuleSettingsNames.C_TEMPLATE_FILE), String)
                Else
                    cboTemplate.SelectedIndex = 0
                End If
                If Not Page.IsPostBack Then
                    With drpCustomerRecordType.Items
                        .Clear()
                        .Add(New ListItem("Individual", "I"))
                        .Add(New ListItem("Company", "C"))
                        .Add(New ListItem("Committee", "T"))
                    End With

                    ctlPostRegistrationNavigateToURL.UrlType = CType(Settings(ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL_TYPE), String)
                    ctlPostRegistrationNavigateToURL.Url = CType(Settings(ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL), String)

                    If Not Settings(ModuleSettingsNames.C_REQUIRES_LOGIN) Is Nothing Then
                        chkRequiresLogin.Checked = CBool(IIf(CType(Settings(ModuleSettingsNames.C_REQUIRES_LOGIN), String) = "Y", True, False))
                    End If

                    ctlAuthenticatedUserNavigateToURL.UrlType = CType(Settings(ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL_TYPE), String)
                    ctlAuthenticatedUserNavigateToURL.Url = CType(Settings(ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL), String)

                    txtRegisterButtonCaption.Text = CType(Settings(ModuleSettingsNames.C_REGISTER_BUTTON_CAPTION), String)

                    If Not Settings(CType(ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS, String)) Is Nothing Then
                        chkShowAddressDetailFlags.Checked = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS, String)), String) = "Y", True, False))
                    End If

                    If Not Settings(CType(ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED, String)) Is Nothing Then
                        chkAddressDetailFlagsDefaultChecked.Checked = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED, String)), String) = "Y", True, False))
                    End If

                    If Not Settings(CType(ModuleSettingsNames.C_USE_COMPANY_LOOKUP, String)) Is Nothing Then
                        chkUseCompanyLookup.Checked = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.C_USE_COMPANY_LOOKUP, String)), String) = "Y", True, False))
                    End If

                    If Not Settings(ModuleSettingsNames.C_CUSTOMER_RECORD_TYPE) Is Nothing Then
                        drpCustomerRecordType.SelectedValue = CType(Settings(ModuleSettingsNames.C_CUSTOMER_RECORD_TYPE), String)
                    End If

                    If drpCustomerRecordType.SelectedValue = "I" Then
                        chkCreateSegmentRecord.Enabled = False
                        chkCreateSegmentRecord.Checked = False
                    Else
                        chkCreateSegmentRecord.Enabled = True
                        If Not Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD) Is Nothing Then
                            chkCreateSegmentRecord.Checked = CBool(IIf(CType(Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD), String) = "Y", True, False))
                        End If
                    End If

                    If Not Settings("chkSSO") Is Nothing Then
                        If CType(Settings("chkSSO"), String) = "Y" Then
                            chkSSO.Checked = True
                        Else
                            chkSSO.Checked = False
                        End If
                    Else
                        chkSSO.Checked = False
                    End If

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub UpdateSettings()
            Dim objModules As New Entities.Modules.ModuleController


            objModules.UpdateModuleSetting(ModuleId, ModuleSettingsNames.C_TEMPLATE_FILE, cboTemplate.SelectedValue)
            
            'URL Type
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL_TYPE, ctlPostRegistrationNavigateToURL.UrlType)
            If Not chkRequiresLogin.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL_TYPE, ctlAuthenticatedUserNavigateToURL.UrlType)
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL_TYPE, "")
            End If
            'Tab Id
            If chkSSO.Checked Then
                objModules.UpdateModuleSetting(ModuleId, "chkSSO", "Y")
            Else
                objModules.UpdateModuleSetting(ModuleId, "chkSSO", "N")
            End If
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL, ctlPostRegistrationNavigateToURL.Url)
            If Not chkRequiresLogin.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL, ctlAuthenticatedUserNavigateToURL.Url)
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL, "0")
            End If
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_REQUIRES_LOGIN, CStr(IIf(chkRequiresLogin.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_REGISTER_BUTTON_CAPTION, txtRegisterButtonCaption.Text)
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS, CStr(IIf(chkShowAddressDetailFlags.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED, CStr(IIf(Me.chkAddressDetailFlagsDefaultChecked.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_USE_COMPANY_LOOKUP, CStr(IIf(Me.chkUseCompanyLookup.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_CUSTOMER_RECORD_TYPE, drpCustomerRecordType.SelectedValue)
            If drpCustomerRecordType.SelectedValue = "I" Then
                objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_CREATE_SEGMENT_RECORD, "N")
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, ModuleSettingsNames.C_CREATE_SEGMENT_RECORD, CStr(IIf(chkCreateSegmentRecord.Checked, "Y", "N")))
            End If



            'clean up
            objModules = Nothing

        End Sub

#End Region

#Region " Controls Events"
        Protected Sub drpCustomerRecordType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles drpCustomerRecordType.SelectedIndexChanged
            If drpCustomerRecordType.SelectedValue = "I" Then
                chkCreateSegmentRecord.Enabled = False
                chkCreateSegmentRecord.Checked = False
            Else
                chkCreateSegmentRecord.Enabled = True
                chkCreateSegmentRecord.Checked = False
            End If
        End Sub

        Private Sub chkRequiresLogin_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkRequiresLogin.CheckedChanged
            If chkRequiresLogin.Checked Then
                lblAuthenticatedUserNavigateTo.Visible = False
                ctlAuthenticatedUserNavigateToURL.Visible = False
            Else
                lblAuthenticatedUserNavigateTo.Visible = True
                ctlAuthenticatedUserNavigateToURL.Visible = True
            End If
        End Sub

#End Region

        
    End Class

End Namespace
