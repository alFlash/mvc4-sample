Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports TIMSS.API.Core
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Services.Localization
Imports TIMSS.SqlObjects
Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports Personify.ApplicationManager.PersonifyEnumerations



Namespace Personify.DNN.Modules.CustomerRegistration

    Public MustInherit Class CustomerRegistration
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


#Region " Constants "
        Private Const C_DATATEXTFIELD As String = "Description"
        Private Const C_DATAVALUEFIELD As String = "Code"

#End Region

#Region " Variables "
        'Private m_AffiliateMode As Boolean
        Private m_DisplayMode As enmDisplayMode
        Private m_EnableCreateWebUser As Boolean
        Private m_enmCreateWebUserMode As enmCreateWebUserMode
        Private m_EnableCreateSegmentRecord As Boolean
        Private m_EnableShipToBillTo As Boolean
        Private m_IsLoginRequired As Boolean
        Private m_RegisterButtonCaption As String
        Private m_CustomerRecordType As String
        Private m_UseCompanyLookup As Boolean
        Private m_PostRegisterNavigateURL As String
        Private m_RegisteredUserNavigateURL As String

 
#End Region

#Region " Enums "

        Private Enum enmDisplayMode
            Register = 0
            Profile = 1
        End Enum

        Private Enum enmCreateWebUserMode
            Workflow = 0
            [Auto] = 1
        End Enum
#End Region

#Region " Properties "
        'Used to control the display of the webpart - Registration /Profile Management
        Private Property DisplayMode() As enmDisplayMode
            Get
                Return m_DisplayMode
            End Get
            Set(ByVal Value As enmDisplayMode)
                m_DisplayMode = Value
            End Set
        End Property

        'Control  display of Password fields on the UI; used for creation of web user
        Private Property IsCreateWebUserEnabled() As Boolean
            Get
                Return m_EnableCreateWebUser
            End Get
            Set(ByVal Value As Boolean)
                m_EnableCreateWebUser = Value
            End Set
        End Property

        'Gets/Sets the Create web User mode (Workflow / Auto mode)
        Private Property CreateWebUserMode() As enmCreateWebUserMode
            Get
                Return m_enmCreateWebUserMode
            End Get
            Set(ByVal Value As enmCreateWebUserMode)
                m_enmCreateWebUserMode = Value
            End Set
        End Property

        'End E00019892

        'Controls creation of a segment record when a customer record is created
        Private Property IsCreateSegmentRecordEnabled() As Boolean
            Get
                Return m_EnableCreateSegmentRecord
            End Get
            Set(ByVal Value As Boolean)
                m_EnableCreateSegmentRecord = Value
            End Set
        End Property

        'Control  display of Bill-To & Ship-To flags on UI
        Private Property IsShipToBillToEnabled() As Boolean
            Get
                Return m_EnableShipToBillTo
            End Get
            Set(ByVal Value As Boolean)
                m_EnableShipToBillTo = Value
            End Set
        End Property

        'Redirects to Login if Login is required to display this web part
        Private Property IsLoginRequired() As Boolean
            Get
                Return m_IsLoginRequired
            End Get
            Set(ByVal Value As Boolean)
                m_IsLoginRequired = Value
            End Set
        End Property

        'check if this call come from Affiliate Management
        Private Property IsWorkFlowForSegment() As Boolean
            Get
                Dim o As Object = Me.ViewState("IsWorkFlowForSegment")
                If (o Is Nothing) Then
                    Return False
                Else
                    Return CType(o, Boolean)
                End If                
            End Get
            Set(ByVal Value As Boolean)
                ViewState("IsWorkFlowForSegment") = Value
            End Set
        End Property

        'Set the caption of the Register button on Registration web part
        Private Property RegisterButtonCaption() As String
            Get
                Return m_RegisterButtonCaption
            End Get
            Set(ByVal Value As String)
                m_RegisterButtonCaption = Value
            End Set
        End Property

        'Set the Customer Record type based on which the Customer record is created
        Private Property CustomerRecordType() As String
            Get
                Return m_CustomerRecordType
            End Get
            Set(ByVal Value As String)
                m_CustomerRecordType = Value
            End Set
        End Property

        'Set the UseCompanyLookup based on which the Ajax Company Lookup will be used or not
        Private Property UseCompanyLookup() As Boolean
            Get
                Return m_UseCompanyLookup
            End Get
            Set(ByVal Value As Boolean)
                m_UseCompanyLookup = Value
            End Set
        End Property

        'Set the URL to navigate to after the Registration is complete
        Private Property PostRegisterNavigateURL() As String
            Get
                Return m_PostRegisterNavigateURL
            End Get
            Set(ByVal Value As String)
                m_PostRegisterNavigateURL = Value
            End Set
        End Property

        'Set the URL for navigating to the tab in case user is already registered.
        ' Please note that this web part checks if the user clicked on Register link or
        ' the label namelink of Registered User
        Private Property RegisteredUserNavigateURL() As String
            Get
                Return m_RegisteredUserNavigateURL
            End Get
            Set(ByVal Value As String)
                m_RegisteredUserNavigateURL = Value
            End Set
        End Property

        Private Property objMasterCustomerId() As String
            Get
                Return CStr(ViewState("MasterCustomerId"))
            End Get
            Set(ByVal Value As String)
                ViewState("MasterCustomerId") = Value
            End Set
        End Property

        Private Property objSubCustomerId() As Integer
            Get
                Return CInt(ViewState("SubCustomerId"))
            End Get
            Set(ByVal Value As Integer)
                ViewState("SubCustomerId") = Value
            End Set
        End Property

        'Set the URL coming from (used for Cancel action)
        Private Property RefTabId() As String
            Get
                Return CStr(ViewState("RefTabId"))
            End Get
            Set(ByVal Value As String)
                ViewState("RefTabId") = Value
            End Set
        End Property
#End Region

#Region " Controls "

        'Protected WithEvents txtFirstName As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtMiddleName As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtLastName As System.Web.UI.WebControls.TextBox

        Protected WithEvents hdnMasterCustomerID As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected WithEvents hdnSubCustomerID As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected WithEvents lblHeading As System.Web.UI.WebControls.Label
        Protected WithEvents ddlPrefix As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents ddlSuffix As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents divProfilePersonal As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents lblAltLastNameCaption As System.Web.UI.WebControls.Label
        Protected WithEvents txtAltLastName As System.Web.UI.WebControls.TextBox
        Protected WithEvents divAltProfile As System.Web.UI.HtmlControls.HtmlGenericControl

        'Protected WithEvents ddlPhoneCountry As Personify.WebControls.CountryDropDownList
        'Protected WithEvents lblPhoneCountry As DotNetNuke.UI.WebControls.PropertyLabelControl
        'Protected WithEvents lblPhoneCountryCode As System.Web.UI.WebControls.Label
        'Protected WithEvents txtPhoneAreaCode As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtPhoneNumber As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtPhoneExt As System.Web.UI.WebControls.TextBox
        'Protected WithEvents lblPhoneExt As System.Web.UI.WebControls.Label
        'Protected WithEvents lblPhoneArea As System.Web.UI.WebControls.Label
        'Protected WithEvents lblPhoneNumber As System.Web.UI.WebControls.Label

        'Protected WithEvents ddlFaxCountry As Personify.WebControls.CountryDropDownList
        'Protected WithEvents lblFaxCountry As DotNetNuke.UI.WebControls.PropertyLabelControl
        'Protected WithEvents lblFaxCountryCode As System.Web.UI.WebControls.Label
        'Protected WithEvents txtFaxAreaCode As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtFaxNumber As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtFaxExt As System.Web.UI.WebControls.TextBox
        'Protected WithEvents lblFaxExt As System.Web.UI.WebControls.Label
        'Protected WithEvents lblFaxArea As System.Web.UI.WebControls.Label
        'Protected WithEvents lblFaxNumber As System.Web.UI.WebControls.Label

        'Protected WithEvents txtWebSiteAddress As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox

        Protected WithEvents lblCredentials As DotNetNuke.UI.WebControls.PropertyLabelControl
        Protected WithEvents lstCredentialsAvailable As System.Web.UI.WebControls.ListBox
        Protected WithEvents lstCredentialsAssigned As System.Web.UI.WebControls.ListBox
        Protected WithEvents lnkMoveRight As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkMoveLeft As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkAllRight As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkAllLeft As System.Web.UI.WebControls.LinkButton

        Protected WithEvents btnVerifyUserId As New System.Web.UI.WebControls.Button

        Protected WithEvents ctladdress As Personify.WebControls.AddressControl
        Protected WithEvents btnRegister As New System.Web.UI.WebControls.Button
        Protected WithEvents btnCancel As New System.Web.UI.WebControls.Button

        'Protected WithEvents txtUserId As System.Web.UI.WebControls.TextBox
        'Protected WithEvents lblUserId As DotNetNuke.UI.WebControls.PropertyLabelControl
        'Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        'Protected WithEvents lblPassword As DotNetNuke.UI.WebControls.PropertyLabelControl
        'Protected WithEvents txtVerifyPassword As System.Web.UI.WebControls.TextBox
        'Protected WithEvents lblVerifyPassword As DotNetNuke.UI.WebControls.PropertyLabelControl
        Protected WithEvents lblPasswordMin As System.Web.UI.WebControls.Label

        Protected WithEvents oMessageControl As WebControls.MessageControl
        Protected WithEvents pnlCustomerRegistration As System.Web.UI.WebControls.Panel

        Protected WithEvents xslCustomerRegistration As WebControls.XslTemplate


#End Region


#Region " Page Events "

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                ' Read Admin settings for this web part
                If Not ReadSettings() Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    Me.Visible = False
                    Exit Sub
                End If
                '' If the call is from Aff. management workflow
                If Not IsPostBack AndAlso Request.QueryString("ref") <> "" AndAlso String.Compare(Request.QueryString("ref"), "segment", True) = 0 Then
                    IsWorkFlowForSegment = True
                    'set the segment workflow flag ON                
                End If
                role = Me.GetUserRole(UserInfo)
                'role = "personifyuser"
                If role = "none" Or (Me.IsPersonifyWebUserLoggedIn And IsWorkFlowForSegment) Or (role = "personifyuser" And (CustomerRecordType = "C" Or CustomerRecordType = "T")) Then
                    If (Not UserInfo.IsSuperUser) Or (Not UserInfo.Profile.ProfileProperties("MasterCustomerId") Is Nothing AndAlso Not UserInfo.Profile.ProfileProperties("SubCustomerId") Is Nothing) Then


                        SSORegistrationValidationCheck()

                        pnlCustomerRegistration.Visible = True
                        AddTemplate()




                        If Not IsPostBack AndAlso Request.QueryString("reftabid") <> "" Then
                            RefTabId = Request.QueryString("reftabid")
                            'this property will be used if Cancel is pressed               
                        End If

                        If Not IsPostBack Then
                            If Not oMessageControl.ValidationIssues Is Nothing Then
                                oMessageControl.Clear()
                            End If
                        End If

                        If Not IsPostBack Then
                            HandleSSORegistrationSetup()
                        End If

                        'Check if the user is already logged in. If so then this web part should be hidden
                        ' and user should be redirected to a tab set by the admin for registered users
                        If HandleRedirectionForRegisteredUsers() = False Then
                            Skins.Skin.AddModuleMessage(Me, Localization.GetString("RegisteredUserRedirectionError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Me.Visible = False
                            Exit Sub
                        End If


                        InitializeControl()

                    Else 'The current user does not have these attributes
                        pnlCustomerRegistration.Visible = False
                        If UserInfo.UserID <> -1 Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AdminModeMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            'Else
                            '    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    End If
                Else
                    pnlCustomerRegistration.Visible = False
                    Select Case (role)
                        Case "personifyuser"
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("UserLoggedIn.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Case "host"
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("PersonifyHostLoggedIn.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Case "admin"
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("PersonifyAdminLoggedIn.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End Select

                End If

            Catch exc As Threading.ThreadAbortException
                'Ignore this exception as this occurs due to Redirection

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
            If ctladdress IsNot Nothing Then
                ctladdress.Mode = "ADD"
                'ctladdress.AddressStructureCountryCode = "USA"
                ctladdress.AddressStructureCountryCode = Me.GetDefaultCountryCodeForOrganization

                If Settings(ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS) Is Nothing OrElse CType(Settings(ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS), String) = "N" Then
                    HideAddressDetailFlags()
                Else
                    If Settings(ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED) Is Nothing OrElse CType(Settings(ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED), String) = "N" Then
                        ctladdress.ForDirectoryUseFlag = False
                        ctladdress.BillAddressFlag = False
                        ctladdress.ShipAddressFlag = False
                        ctladdress.PrimaryFlag = False
                    Else
                        ctladdress.ForDirectoryUseFlag = True
                        ctladdress.BillAddressFlag = True
                        ctladdress.ShipAddressFlag = True
                        ctladdress.PrimaryFlag = True
                    End If
                End If
                'BIO issue fix - added following line
                ctladdress.SetAddressVisible()
            End If

            'SetCommunicationMaskForPhone(ddlPhoneCountry.SelectedValue)
            'SetCommunicationMaskForFax(ddlFaxCountry.SelectedValue)
            If Not Page.Request.Params("__EVENTTARGET") Is Nothing AndAlso Page.Request.Params("__EVENTTARGET").IndexOf("txtCompanyName") > 0 Then
                Dim MCID As String = ""
                Dim SCID As String = ""
                Dim Comp As String = ""

                Comp = Page.Request.Params(Page.Request.Params("__EVENTTARGET"))
                If Comp.IndexOf(TIMSS.Constants.Application.C_KEY_DELIMITER) > 0 Then
                    ParseCustomerId(Comp, MCID, SCID)
                    GetPrimaryAddressForCustomer(MCID, SCID)
                End If
            End If

        End Sub

#End Region

#Region " Controls Events "

#Region " Action button events "
        Protected Sub btnVerifyUserId_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnVerifyUserId.Click
            Try
                Dim txtUserId As TextBox = CType(FindControl("ctl_" & ModuleId & "_" & "WebUser" & "_UserId"), TextBox)
                Dim username As String = txtUserId.Text

               
                Dim lblVerifyUserId As System.Web.UI.WebControls.Label
                lblVerifyUserId = CType(FindControl("lblVerifyUserId"), Label)
                If lblVerifyUserId IsNot Nothing Then
                    If df_DoesWebUserIDExists(username) Then
                        lblVerifyUserId.Text = Localization.GetString("UserIdExistsError", LocalResourceFile)
                        lblVerifyUserId.Text = lblVerifyUserId.Text & _
                        df_GetAlternativeWebUserIDs(username).Substring(2)
                    Else
                        lblVerifyUserId.Text = Localization.GetString("UserIdDoesNotExists", LocalResourceFile)
                    End If
                End If
            Catch ex As Exception
                Exit Sub
            End Try

        End Sub

        Protected Sub btnRegister_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegister.Click
            Try
                'validate form Password controls
                'If Not ValidateForm() Then
                'Dim _goScroll As String = "<script language='javascript'>setTimeout('window.scrollTo(0, 0)',1);</script>"
                'If Not Page.ClientScript.IsStartupScriptRegistered("goScroll") Then
                'Page.ClientScript.RegisterStartupScript(Me.GetType(), "goScroll", _goScroll)

                'End If
                'Exit Sub
                'End If

                'set the global variables 
                Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
                globalVariables.ModuleId = ModuleId
                globalVariables.Customer = "Customer"
                globalVariables.CustomerCommunication = "CustomerCommunication"
                globalVariables.WebUser = "WebUser"

                Dim txtUserId As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_UserId"), TextBox)
                Dim txtPassword As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Password"), TextBox)

                'start D00031381
                If txtUserId IsNot Nothing Then
                    If df_DoesWebUserIDExists(txtUserId.Text) Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIdExistsError", LocalResourceFile) + df_GetAlternativeWebUserIDs(txtUserId.Text).Substring(2), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Exit Sub
                    End If
                End If
                'end D00031381


                ctladdress = CType(FindControl("ctlAddress"), Personify.WebControls.AddressControl)

                Dim oCs As TIMSS.API.CustomerInfo.ICustomers

                'get an empty ICustomer collection
                oCs = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
                oCs.AddNew()

                'obtain the properties of type ICustomer
                Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oCs(0))

                'cycle thourgh the properties of ICustomer
                For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                    Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.Customer & "_" & pd.Name)
                    'if a control for the current property is found
                    If ctl IsNot Nothing Then

                        If oCs(0).Schema(pd.Name).Type.Name = "Boolean" Then
                            'if property is type of boolean then the control is assumed to be a checkbox
                            CType(oCs(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(CType(oCs(0).Schema(pd.Name), PropertyInfo), Me.ConvertBooleanType(CType(ctl, CheckBox).Checked))
                        ElseIf oCs(0).Schema(pd.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                            'if property is of type Lookup then the control is assumed to be dropdownlist and the value for that property will be read accordingly  -SelectedValue
                            CType(oCs(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(CType(oCs(0).Schema(pd.Name), PropertyInfo), CType(ctl, DropDownList).SelectedValue)
                        Else
                            'if property is not of type Lookup then the control is assumed to be dropdownlist and the value for that property will be read accordingly  - Text
                            CType(oCs(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(CType(oCs(0).Schema(pd.Name), PropertyInfo), CType(ctl, TextBox).Text)
                        End If

                    End If
                Next

                If FindControl("lstCredentialsAssigned") IsNot Nothing Then
                    'this control is not dynamic
                    lstCredentialsAssigned = CType(FindControl("lstCredentialsAssigned"), System.Web.UI.WebControls.ListBox)
                End If
                If FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.Customer & "_AltLastName") IsNot Nothing Then
                    'this control is not dynamic
                    txtAltLastName = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.Customer & "_AltLastName"), TextBox)
                End If



                Select Case CustomerRecordType
                    Case "I"
                        'customer record type is "INDIVID"
                        oCs(0).RecordType = "I"
                        If lstCredentialsAssigned IsNot Nothing Then
                            oCs(0).NameCredentials = lstCredentialsAssigned.Text
                        End If
                        oCs(0).CustomerClassCode = oCs(0).CustomerClassCode.List("INDIV").ToCodeObject
                    Case "C"
                        'customer record type is "COMPANY"
                        oCs(0).RecordType = "C"
                        oCs(0).CustomerClassCode = oCs(0).CustomerClassCode.List("COMPANY").ToCodeObject()
                        oCs(0).LastName = txtAltLastName.Text
                        If Me.IsWorkFlowForSegment AndAlso Not Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD) Is Nothing Then
                            oCs(0).WebSegmentCreationFlag = CBool(IIf(CType(Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD), String) = "Y", True, False))
                        End If
                    Case "T"
                        'customer record type is "COMMITTEE"
                        oCs(0).RecordType = "T"
                        oCs(0).CustomerClassCode = oCs(0).CustomerClassCode.List("COMMITTEE").ToCodeObject()
                        oCs(0).LastName = txtAltLastName.Text
                        If Me.IsWorkFlowForSegment AndAlso Not Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD) Is Nothing Then
                            oCs(0).WebSegmentCreationFlag = CBool(IIf(CType(Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD), String) = "Y", True, False))
                        End If
                End Select
                oCs(0).CustomerStatusCode = oCs(0).CustomerStatusCode.List("ACTIVE").ToCodeObject
                Dim oAddressDetail As TIMSS.API.CustomerInfo.ICustomerAddressDetail
                Dim oAddress As TIMSS.API.CustomerInfo.ICustomerAddress

                Dim CompanyMasterCustomer As String = String.Empty
                Dim CompanySubCustomer As Integer
                Dim CompanyName As String = String.Empty
                Dim CompanyAddressId As Long = 0
                If CustomerRecordType = "I" Then
                    'if customer record type is "INDIV" and the address selected is a company address
                    If UseCompanyLookup Then
                        If ctladdress.IsCompanyAddress Then
                            CompanyMasterCustomer = ctladdress.CompanyMasterCustomerId
                            CompanySubCustomer = ctladdress.CompanySubCustomerId
                            CompanyName = ctladdress.CompanyName
                            CompanyAddressId = df_GetPrimaryAddressIdForCompany(CompanyMasterCustomer, CompanySubCustomer.ToString())
                        End If
                    Else
                        CompanyName = ctladdress.CompanyName
                        If CompanyName.Length > 0 Then
                            Dim oCustomers As System.Data.DataSet
                            oCustomers = df_GetCompanyLookup(CompanyName)
                            If oCustomers.Tables(0) IsNot Nothing AndAlso oCustomers.Tables(0).Rows.Count > 0 Then
                                CompanyMasterCustomer = CType(oCustomers.Tables(0).Rows(0).Item("master_customer_id"), String)
                                CompanyMasterCustomer = CompanyMasterCustomer.Substring(1, CompanyMasterCustomer.Length - 1).Split(CChar("-"))(0)
                                CompanySubCustomer = CType(oCustomers.Tables(0).Rows(0).Item("sub_customer_id"), Integer)

                                CompanyAddressId = df_GetPrimaryAddressIdForCompany(CompanyMasterCustomer, CompanySubCustomer)
                            End If
                        End If
                    End If
                End If


                oAddressDetail = oCs(0).CreateDefaultAddress
                'set the properties for the customer address
                With oAddressDetail
                    .AddressTypeCode = .AddressTypeCode.List(ctladdress.AddressType).ToCodeObject
                    If CustomerRecordType = "I" Then
                        If ctladdress.LabelName <> "" Then
                            .LabelName = ctladdress.LabelName
                        Else
                            .LabelName = oCs(0).LabelName
                        End If
                    End If
                    .JobTitle = ctladdress.JobTitle
                    .MailStop = ctladdress.MailStop
                    .AttentionLine = ctladdress.Attention
                    If CompanyMasterCustomer.Length = 0 Then
                        .CompanyName = ctladdress.CompanyName
                    End If
                    If Settings(ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS) IsNot Nothing AndAlso CType(Settings(ModuleSettingsNames.C_SHOW_ADDRESS_DETAIL_FLAGS), String) = "Y" Then
                        .ShipToFlag = ctladdress.ShipAddressFlag
                        .BillToFlag = ctladdress.BillAddressFlag
                        .DirectoryFlag = ctladdress.ForDirectoryUseFlag
                        '.PrioritySeq = 0 '= ctladdress.PrimaryFlag
                    Else
                        If Settings(ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED) IsNot Nothing AndAlso CType(Settings(ModuleSettingsNames.C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED), String) = "Y" Then
                            .ShipToFlag = True
                            .BillToFlag = True
                            .DirectoryFlag = True
                            '.PrioritySeq = 0 'True
                        Else
                            .ShipToFlag = False
                            .BillToFlag = False
                            .DirectoryFlag = False
                            '.PrioritySeq = 1 'False
                        End If
                    End If

                    .AddressStatusCode = .AddressStatusCode.List("GOOD").ToCodeObject
                    If CompanyMasterCustomer.Length > 0 Then
                        .CompanyMasterCustomer = CompanyMasterCustomer
                        .CompanySubCustomer = CInt(CompanySubCustomer)
                        .CompanyName = CompanyName
                    End If
                End With

                If CompanyMasterCustomer.Length > 0 And UseCompanyLookup Then
                    'if a company address was selected then link customer address to the given company address
                    oAddressDetail.LinkAddress(CompanyMasterCustomer, CInt(CompanySubCustomer), "C", CompanyName, oAddressDetail.AddressStatusCodeString, CompanyAddressId)
                Else
                    oAddress = oAddressDetail.Address
                    With oAddress
                        'Part of CQ30948, move code for setting countrycode to first.
                        .CountryCode = .CountryCode.List(ctladdress.CountryCode).ToCodeObject
                        .Address1 = ctladdress.Address1
                        .Address2 = ctladdress.Address2
                        .Address3 = ctladdress.Address3
                        .Address4 = ctladdress.Address4
                        .AddressStatusCode = .AddressStatusCode.List("GOOD").ToCodeObject
                        .City = ctladdress.City
                        If Not String.Compare(ctladdress.State, "[ALL]") = 0 Then
                            '5926080
                            If ctladdress.State = "-1" Then
                                .State = ""
                            Else
                                .State = ctladdress.State
                            End If
                            'End of 5926080
                        End If
                        .PostalCode = ctladdress.PostalCode
                        .County = ctladdress.County
                    End With

                End If

                'add customer communication methods specified
                Dim index As Integer = 0
                Dim commExists As Boolean = False
                oCs(0).Communications.AddNew()

                'get the CommType codes
                Dim oCommTypeCodes As TIMSS.API.Core.ICode = CType(oCs(0).Communications(index), TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oCs(0).Communications(index).Schema("CommTypeCode"), ICodePropertyInfo))
                'get CommLocation codes
                Dim oCommLocationCodes As TIMSS.API.Core.ICode = CType(oCs(0).Communications(index), TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oCs(0).Communications(index).Schema("CommLocationCode"), ICodePropertyInfo))

                'cycle through each of the CommType codes and CommLocation codes
                For i As Integer = 0 To oCommTypeCodes.List.Count - 1
                    For j As Integer = 0 To oCommLocationCodes.List.Count - 1
                        'search if a control for PhoneNumber exists or a control for Formatted phone address exists
                        Dim controlPhoneNumber As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & oCommTypeCodes.List(i).Code & "_" & oCommLocationCodes.List(j).Code & "_PhoneNumber")
                        Dim controlFormattedPhoneAddress As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & oCommTypeCodes.List(i).Code & "_" & oCommLocationCodes.List(j).Code & "_FormattedPhoneAddress")
                        'if the control for PhoneNumber has a value different of empty
                        'if the  control for Formatted phone address has a value different of Empty
                        'in one of these cases means the current  communication type was set and will be added to customer
                        If (controlPhoneNumber IsNot Nothing AndAlso CType(controlPhoneNumber, TextBox).Text <> String.Empty) Or (controlFormattedPhoneAddress IsNot Nothing AndAlso CType(controlFormattedPhoneAddress, TextBox).Text <> String.Empty) Then
                            commExists = True
                            If index <> 0 Then
                                'for the first communication method the record is already added
                                oCs(0).Communications.AddNew()
                            End If

                            'set CountryCode, CommLocationCode, CommTypeCode for the current Communication method
                            'these properties need to be the first to set and in this order because of the API design
                            With oCs(0).Communications(index)
                                Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & oCommTypeCodes.List(i).Code & "_" & oCommLocationCodes.List(j).Code & "_" & "CountryCode")
                                If ctl IsNot Nothing Then
                                    .CountryCode = ""
                                    .CountryCode = CType(ctl, DropDownList).SelectedValue
                                Else
                                    .CountryCode = ""
                                    .CountryCode = Me.GetDefaultCountryCodeForOrganization
                                End If
                                .CommLocationCode = .CommLocationCode.List(j).ToCodeObject
                                .CommTypeCode = .CommTypeCode.List((i)).ToCodeObject
                            End With
                            'get the properties of ICustomerCommunication type
                            cPropDesc = ComponentModel.TypeDescriptor.GetProperties(oCs(0).Communications(index))
                            'cycle through the properties of ICustomerCommunication
                            For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                                Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & oCommTypeCodes.List(i).Code & "_" & oCommLocationCodes.List(j).Code & "_" & pd.Name)
                                'if a control for the current property was found
                                If ctl IsNot Nothing Then
                                    If oCs(0).Communications(index).Schema(pd.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                        'if the property is of type Lookup the value for this property is assumed to be obtain from a control of type dropdownlist
                                        CType(oCs(0).Communications(index), TIMSS.API.Core.BusinessObject).SetPropertyValue(CType(oCs(0).Communications(index).Schema(pd.Name), PropertyInfo), CType(ctl, DropDownList).SelectedValue)
                                    Else
                                        'if the property is not of type Lookup the value for this property is assumed to be obtain from a control of type textbox
                                        If pd.Name.IndexOf("CountryCode") < 0 And pd.Name.IndexOf("PhoneCountryCode") < 0 Then
                                            'the property is set only if it is different from ContryCode(already setted) and PhoneCountryCode(will be setted bellow)
                                            CType(oCs(0).Communications(index), TIMSS.API.Core.BusinessObject).SetPropertyValue(CType(oCs(0).Communications(index).Schema(pd.Name), PropertyInfo), CType(ctl, TextBox).Text)
                                        End If

                                    End If
                                End If

                            Next


                            'other properties to set not from controls
                            With oCs(0).Communications(index)
                                .MasterCustomerId = oCs(0).MasterCustomerId
                                .SubCustomerId = oCs(0).SubCustomerId
                                .PrimaryFlag = True
                                'PhoneCountryCode property is set based on a different control type - Label 
                                Dim countryCodeLabel As Control = FindControl("lbl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & oCommTypeCodes.List(i).Code & "_" & oCommLocationCodes.List(j).Code & "_PhoneCountryCode")
                                If countryCodeLabel IsNot Nothing Then
                                    oCs(0).Communications(index).PhoneCountryCode = CType(countryCodeLabel, Label).Text.Replace("(", "").Replace(")", "")
                                End If
                            End With
                            index = index + 1

                        End If
                    Next
                Next
                If Not commExists And index = 0 Then
                    'the CustomerCommunication was added to obtain the Codes for CommType and CommLocation
                    'but no CustomerCommunication method was added
                    'so it must be removed
                    oCs(0).Communications.RemoveAt(0)
                End If


                Dim MCid As String = oCs(0).MasterCustomerId
                Dim SCid As Integer = oCs(0).SubCustomerId

                'set the properties needed if Customer is of type Segment
                If Me.IsWorkFlowForSegment Then
                    objMasterCustomerId = MCid
                    objSubCustomerId = SCid
                    Select Case CustomerRecordType
                        Case "T"
                            oCs(0).SegmentRuleCode = oCs(0).SegmentRuleCode.List("COMMITTEE").ToCodeObject 'oCustomer.SegmentRuleCode
                        Case "C"
                            oCs(0).SegmentRuleCode = oCs(0).SegmentRuleCode.List("EMPLOYEE").ToCodeObject 'oCustomer.SegmentRuleCode
                    End Select
                    oCs(0).SegmentQualifier1 = MCid
                    oCs(0).SegmentQualifier2 = CStr(SCid)
                End If

                'add the customer 
                Dim oCustomer As TIMSS.API.CustomerInfo.ICustomer = df_ValidateCustomer(oCs, oMessageControl.ValidationIssues)

                Dim userid As String = String.Empty
                Dim password As String = String.Empty
                Dim HintQuestion As String = String.Empty
                Dim HintAnswer As String = String.Empty
                Dim tmpUserId As String = MCid & "|" & SCid


                'concatenate the Form validation messages with API validation messages
                Dim oValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = BuildErrorMessage(CType(oCustomer.ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                    'The save was not successfull
                    'oMessageControl.Show(CType(oCustomer.ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                    If Not oMessageControl.ValidationIssues Is Nothing Then
                        oMessageControl.Clear()
                    End If

                    If oValidationIssues.ErrorCount > 0 Then
                        For i As Integer = 0 To oValidationIssues.Count - 1
                            If oValidationIssues(i) IsNot Nothing AndAlso oValidationIssues(i).Key.IndexOf("DuplicateCustomerMatchesFoundIssue") > 1 AndAlso oValidationIssues(i).Responded = True AndAlso oValidationIssues(i).Response IsNot Nothing AndAlso oValidationIssues(i).Response.Value = "No" Then

                                Dim strTabId As String = CStr(RefTabId)
                                If strTabId Is Nothing Then
                                    Response.Redirect(NavigateURL(PortalSettings.LoginTabId))
                                Else
                                    Response.Redirect(NavigateURL(Integer.Parse(strTabId), True))
                                End If

                            End If
                        Next
                    End If

                    oMessageControl.Show(oValidationIssues)
                    Dim _goScroll As String = "<script language='javascript'>setTimeout('window.scrollTo(0, 0)',1);</script>"
                    If Not Page.ClientScript.IsStartupScriptRegistered("goScroll") Then
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "goScroll", _goScroll)
                    End If
                Else
                    If Not oMessageControl.ValidationIssues Is Nothing Then
                        oMessageControl.Clear()
                    End If

                    oCustomer = df_AddCustomer(oCs, oMessageControl.ValidationIssues)

                    Dim ddlHintQuestion As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Question"), DropDownList)
                    Dim txtHintAnswer As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Answer"), TextBox)

                    If ddlHintQuestion IsNot Nothing Then
                        HintQuestion = ddlHintQuestion.SelectedValue
                        HintAnswer = txtHintAnswer.Text
                    End If


                    If Not Me.IsSSOEnabled Then
                        'Regular registration flow

                        userid = txtUserId.Text
                        password = txtPassword.Text

                        'add the web user for the already added customer
                        df_CreateWebUserAccount(MCid, SCid, txtUserId.Text, txtPassword.Text, HintQuestion, HintAnswer)
                    Else
                        'SSO registration flow - does not require userid/password. Will be using master&sub customer id as userid                    
                        df_CreateWebUserAccount(MCid, SCid, tmpUserId, tmpUserId, HintQuestion, HintAnswer)

                        'Dim SSOUserId As String = SSOLoginManager.GetSSOUserId(GetCustomerToken()) 'Removed
                        For i As Integer = 0 To 3
                            If SSOLoginManager.UpdateVendorCustomerIdIntoSSO(GetCustomerToken(), tmpUserId) Then
                                Exit For
                            End If
                        Next
                    End If

                    If IsWorkFlowForSegment Then
                        'Adding a record to Cus_Segment_Control table if current Customer is Company or Committee
                        If CustomerRecordType = "C" Or CustomerRecordType = "T" Then
                            Dim ValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = AddSegment(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), CInt(UserInfo.Profile.GetPropertyValue("SubCustomerId")), oCustomer.SegmentRuleCode, oCustomer.SegmentQualifier1, oCustomer.SegmentQualifier2, CustomerRecordType)

                            If Not oMessageControl.ValidationIssues Is Nothing Then
                                oMessageControl.Clear()
                            End If

                            If ValidationIssues.Count > 0 Then
                                'The save was not successfull
                                oMessageControl.Show(CType(ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                            End If

                        End If

                    End If

                    If IsSSOEnabled() Then
                        'the user will be redirected
                        HandleRedirectionForNewUsers(tmpUserId, tmpUserId)
                    Else
                        'the user will be redirected
                        HandleRedirectionForNewUsers(userid, password)
                    End If

                End If

            Catch ex As Threading.ThreadAbortException
                'TIMSS.Messaging.Dispatching.ConsumerNotFoundException
            Catch TimssEx As TIMSS.Messaging.Dispatching.ConsumerNotFoundException
                ProcessModuleLoadException(Me, TimssEx)
            Catch ex2 As Exception
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("RegistrationError", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError) '3246-6116989
            End Try
        End Sub


        ''' <summary>
        ''' ConvertBoolean value to Personify boolean value 
        ''' </summary>
        Private Function ConvertBooleanType(ByVal status As Boolean) As String
            If status Then
                Return "Y"
            End If
            Return "N"
        End Function
        Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            Try
                If Not oMessageControl.ValidationIssues Is Nothing Then

                    oMessageControl.Clear()
                End If

                'Dim strTabId As String = "0"
                'Dim strCreateSegmentRecord As String = CType(Settings(ModuleSettingsNames.C_CREATE_SEGMENT_RECORD), String)
                'If Not strCreateSegmentRecord Is String.Empty AndAlso _
                '        String.Compare(strCreateSegmentRecord, "Y", True) = 0 Then

                'If Settings(ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL) IsNot Nothing Then
                '  strTabId = Settings(ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL).ToString
                'End If

                'End If
                Dim strTabId As String = CStr(RefTabId)
                If strTabId Is Nothing Then
                    'START 3246-8198868
                    If Not String.IsNullOrEmpty(RedirectURL) Then
                        Response.Redirect(RedirectURL, True)
                    Else
                        Response.Redirect(NavigateURL(PortalSettings.LoginTabId))
                    End If
                    'END 3246-8198868
                Else
                    Response.Redirect(NavigateURL(Integer.Parse(strTabId), True))
                End If

            Catch ex As Threading.ThreadAbortException
                'Ignore this exception

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

#End Region

#Region " Credentials related action buttons "
        Protected Sub lnkMoveRight_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkMoveRight.Click
            Try
                Dim selectedValue As String = lstCredentialsAvailable.SelectedValue
                Dim selectedText As String = ""

                If Not String.Compare(selectedValue, String.Empty) = 0 Then
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("CUS", "CREDENTIALS", True)

                    ' ApplicationManager.Codes.GetApplicationCodes(PortalId, "CUS", "CREDENTIALS")
                    Dim appcode As TIMSS.API.ApplicationInfo.IApplicationCode
                    For Each appcode In appCodes
                        If selectedValue = appcode.Code Then
                            selectedText = appcode.Description
                        End If
                    Next

                    lstCredentialsAssigned.Items.Add(New ListItem(selectedText, selectedValue))
                    lstCredentialsAvailable.Items.Remove(New ListItem(selectedText, selectedValue))
                End If

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub lnkMoveLeft_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkMoveLeft.Click
            Try
                Dim selectedValue As String = lstCredentialsAssigned.SelectedValue
                Dim selectedText As String = ""

                If Not String.Compare(selectedValue, String.Empty) = 0 Then

                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("CUS", "CREDENTIALS", True)
                    Dim appcode As TIMSS.API.ApplicationInfo.IApplicationCode
                    For Each appcode In appCodes
                        If selectedValue = appcode.Code Then
                            selectedText = appcode.Description
                        End If
                    Next

                    lstCredentialsAvailable.Items.Add(New ListItem(selectedText, selectedValue))
                    lstCredentialsAssigned.Items.Remove(New ListItem(selectedText, selectedValue))
                End If

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub lnkAllRight_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkAllRight.Click
            Try

                Dim selectedItem As ListItem
                For Each selectedItem In lstCredentialsAvailable.Items
                    lstCredentialsAssigned.Items.Add(selectedItem)
                Next
                lstCredentialsAvailable.Items.Clear()

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub lnkAllLeft_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkAllLeft.Click
            Try

                Dim selectedItem As ListItem
                For Each selectedItem In lstCredentialsAssigned.Items
                    lstCredentialsAvailable.Items.Add(selectedItem)
                Next
                lstCredentialsAssigned.Items.Clear()

            Catch ex As Threading.ThreadAbortException

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub
#End Region

#Region " Communication - Country Dropdown events"
        Private Sub CountrySelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

            If Page.IsPostBack Then
                SetCommunicationMask(sender, String.Empty)
            End If

        End Sub

#End Region

#Region " Personal Details Dropdownlists "

        Private Sub ddlPrefix_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlPrefix.PreRender
            Dim oListItem As New ListItem
            Dim strlocalizedPrefixLabel As String
            Dim strPrefixLabelFormat As String
            strPrefixLabelFormat = Localization.GetString("DefaultListItem", LocalResourceFile)
            If strPrefixLabelFormat = String.Empty Then
                strPrefixLabelFormat = "-- Select {0} --"
            End If
            strlocalizedPrefixLabel = Localization.GetString("lblPrefix", LocalResourceFile)
            If strlocalizedPrefixLabel = String.Empty Then
                strlocalizedPrefixLabel = "Prefix"
            End If


            oListItem.Text = String.Format(strPrefixLabelFormat, strlocalizedPrefixLabel)
            oListItem.Value = "-1"

            ddlPrefix.Items.Insert(0, oListItem)
            oListItem = Nothing

        End Sub

        Private Sub ddlSuffix_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSuffix.PreRender
            Dim oListItem As New ListItem
            Dim strlocalizedSuffixLabel As String
            Dim strSuffixLabelFormat As String
            strSuffixLabelFormat = Localization.GetString("DefaultListItem", LocalResourceFile)
            If strSuffixLabelFormat = String.Empty Then
                strSuffixLabelFormat = "-- Select {0} --"
            End If

            strlocalizedSuffixLabel = Localization.GetString("lblSuffix", LocalResourceFile)
            If strlocalizedSuffixLabel = String.Empty Then
                strlocalizedSuffixLabel = "Suffix"
            End If


            oListItem.Text = String.Format(strSuffixLabelFormat, strlocalizedSuffixLabel)
            oListItem.Value = "-1"

            ddlSuffix.Items.Insert(0, oListItem)
            oListItem = Nothing

        End Sub

#End Region
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub




        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

#Region " Helper Functions "

        Private Sub InitializeControl()
            Try
                If lblPasswordMin IsNot Nothing Then
                    lblPasswordMin.Text = String.Format(Localization.GetString("PasswordError", LocalResourceFile), GetMinPasswordLength.ToString)
                End If

                Select Case CustomerRecordType
                    Case "I"
                        'customer record type "INDIVID" 
                        divProfilePersonal.Visible = True
                        divAltProfile.Visible = False
                    Case "C"
                        'customer record type "COMPANY"
                        divProfilePersonal.Visible = False
                        divAltProfile.Visible = True
                        'show "Company" text 
                        lblAltLastNameCaption.Attributes.Add("resourcekey", "lblCompanyName")
                        'hide Company name control
                        ctladdress.HideCompanyName = True
                        ctladdress.HideLabelName = True
                    Case "T"
                        'customer record type "COMMITTEE"
                        divProfilePersonal.Visible = False
                        divAltProfile.Visible = True
                        'show "Committee" text
                        lblAltLastNameCaption.Attributes.Add("resourcekey", "lblCommitteeName")
                        'hide Company name control
                        ctladdress.HideCompanyName = True
                        ctladdress.HideLabelName = True
                End Select
                'sets Register button caption
                If Not String.Compare(RegisterButtonCaption, String.Empty) = 0 Then
                    btnRegister.Text = RegisterButtonCaption
                Else
                    btnRegister.Attributes.Add("resourcekey", "btnRegister")
                End If
                If Not Page.IsPostBack Then
                    With lstCredentialsAvailable
                        'sets the Available Credentials  listbox
                        .DataSource = GetApplicationCodes("CUS", "CREDENTIALS", True)
                        .DataTextField = "DESCRIPTION"
                        .DataValueField = "CODE"
                        .DataBind()
                    End With
                End If

            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        Private Sub AddTemplate()

            'sets the template file 
            If (Not (CType(Settings(ModuleSettingsNames.C_TEMPLATE_FILE), String)) Is Nothing) Then
                xslCustomerRegistration.XSLfile = Server.MapPath(ModulePath + "Templates\" + Settings(ModuleSettingsNames.C_TEMPLATE_FILE).ToString)
            Else
                pnlCustomerRegistration.Visible = False
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingTemplate", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If

            'sets the global variables used in template file for controls ID's
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            globalVariables.ModuleId = ModuleId
            globalVariables.Customer = "Customer"
            globalVariables.CustomerCommunication = "CustomerCommunication"
            globalVariables.WebUser = "WebUser"
            xslCustomerRegistration.AddObject("", globalVariables)
            xslCustomerRegistration.Display()

            'add the AddressControl ctlAddress if PlaceHolder Address found in template
            Dim ph As PlaceHolder = New PlaceHolder
            ph = CType(FindControl("phAddress"), PlaceHolder)
            If (ph IsNot Nothing) Then
                ctladdress = New Personify.WebControls.AddressControl
                ctladdress.ID = "ctladdress"
                ph.Controls.Add(ctladdress)
            End If
            ctladdress = CType(FindControl("ctlAddress"), Personify.WebControls.AddressControl)
            ctladdress.UseCompanyLookup = UseCompanyLookup
            ctladdress.ServicePath = ApplicationPath & "/PersonifyAjax.asmx"
            ctladdress.ServiceMethod = "SearchCompanies"


            'used to obtain properties of TIMSS.API.CustomerInfo.ICustomer type
            Dim oCs As TIMSS.API.CustomerInfo.ICustomers

            oCs = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            Dim oC As TIMSS.API.CustomerInfo.ICustomer
            oC = oCs.AddNew()

            'get the properties of TIMSS.API.CustomerInfo.ICustomer type
            Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oC)

            For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.Customer & "_" & pd.Name)
                'if a control for current property was found
                If ctl IsNot Nothing Then
                    'Dim oCodes As TIMSS.API.Core.ICode
                    'if property is of type Lookup - control will be a DropDownList
                    If oC.Schema(pd.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                        'control is filled with the codes available for the current property
                        'oCodes = CType(oC, TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oC.Schema(pd.Name), ICodePropertyInfo))
                        CType(ctl, DropDownList).DataTextField = C_DATATEXTFIELD
                        CType(ctl, DropDownList).DataValueField = C_DATAVALUEFIELD
                        '3246-7171001 fix
                        Dim codeType As String
                        Select Case pd.Name
                            Case "NamePrefix"
                                codeType = "NAME_PREFIX"
                            Case "NameSuffix"
                                codeType = "NAME_SUFFIX"
                            Case Else
                                codeType = pd.Name
                        End Select
                        CType(ctl, DropDownList).DataSource = GetApplicationCodes("CUS", codeType, True)
                        'End 3246-7171001 fix
                        CType(ctl, DropDownList).DataBind()

                        'add the first item in dropdownlist control - "-- Select {0} --"
                        Dim oListItem As New ListItem
                        Dim strlocalizedControlLabel As String
                        Dim strControlLabelFormat As String
                        strControlLabelFormat = Localization.GetString("DefaultListItem", LocalResourceFile)
                        If strControlLabelFormat = String.Empty Then
                            strControlLabelFormat = "-- Select {0} --"
                        End If
                        strlocalizedControlLabel = Localization.GetString(ctl.ID, LocalResourceFile)


                        oListItem.Text = String.Format(strControlLabelFormat, strlocalizedControlLabel)
                        oListItem.Value = "-1"

                        CType(ctl, DropDownList).Items.Insert(0, oListItem)
                        oListItem = Nothing

                    End If
                End If
            Next


            'used to obtain properties of TIMSS.API.CustomerInfo.ICustomerCommunication type
            Dim oCommunication As TIMSS.API.CustomerInfo.ICustomerCommunication
            oCommunication = oC.Communications.AddNew()

            'obtain CommunicationType codes: Phone, Fax, Email, Web
            Dim oCommTypeCodes As TIMSS.API.Core.ICode = CType(oCommunication, TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oCommunication.Schema("CommTypeCode"), ICodePropertyInfo))
            'obtain CommunicationLocation codes: Home, Work, Business
            Dim oCommLocationCodes As TIMSS.API.Core.ICode = CType(oCommunication, TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oCommunication.Schema("CommLocationCode"), ICodePropertyInfo))
            For i As Integer = 0 To oCommTypeCodes.List.Count - 1
                For j As Integer = 0 To oCommLocationCodes.List.Count - 1
                    Dim control As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & oCommTypeCodes.List(i).Code & "_" & oCommLocationCodes.List(j).Code & "_CountryCode")
                    'if the control CountryCode for the current CommType and commLocation was found was found
                    'then the control is filled with the countries codes
                    If control IsNot Nothing Then
                        CType(control, DropDownList).DataTextField = "CountryDescription"
                        CType(control, DropDownList).DataValueField = "CountryCode"
                        CType(control, DropDownList).DataSource = TIMSS.API.CachedApplicationData.ApplicationDataCache.Countries

                        CType(control, DropDownList).DataBind()
                        CType(control, DropDownList).AutoPostBack = True
                        'set the default country
                        CType(control, DropDownList).SelectedValue = Me.GetDefaultCountryCodeForOrganization

                        'add handler to handle the dropdownlist index change 
                        'adjust the communication mask accordingly to the country selected
                        AddHandler CType(control, DropDownList).SelectedIndexChanged, AddressOf CountrySelectedIndexChanged
                        SetCommunicationMask(control, String.Empty)
                    End If
                Next
            Next


            'the controls that are predefined
            lstCredentialsAssigned = CType(FindControl("lstCredentialsAssigned"), System.Web.UI.WebControls.ListBox)
            lstCredentialsAvailable = CType(FindControl("lstCredentialsAvailable"), System.Web.UI.WebControls.ListBox)
            divProfilePersonal = CType(FindControl("divProfilePersonal"), System.Web.UI.HtmlControls.HtmlGenericControl)
            lnkMoveRight = CType(FindControl("lnkMoveRight"), System.Web.UI.WebControls.LinkButton)
            lnkMoveLeft = CType(FindControl("lnkMoveLeft"), System.Web.UI.WebControls.LinkButton)
            lnkAllRight = CType(FindControl("lnkAllRight"), System.Web.UI.WebControls.LinkButton)
            lnkAllLeft = CType(FindControl("lnkAllLeft"), System.Web.UI.WebControls.LinkButton)
            divAltProfile = CType(FindControl("divAltProfile"), System.Web.UI.HtmlControls.HtmlGenericControl)
            lblAltLastNameCaption = CType(FindControl("lblAltLastNameCaption"), System.Web.UI.WebControls.Label)
            lblPasswordMin = CType(FindControl("lblPasswordMin"), Label)
            btnVerifyUserId = CType(FindControl("btnVerifyUserId"), Button)
            Dim lblVerifyUserId As System.Web.UI.WebControls.Label
            lblVerifyUserId = CType(FindControl("lblVerifyUserId"), Label)
            If lblVerifyUserId IsNot Nothing Then
                lblVerifyUserId.Text = String.Empty
            End If

            'Populate Hint Question field
            Dim HintQuestion As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Question"), DropDownList)
            If HintQuestion IsNot Nothing Then
                HintQuestion.DataTextField = "Description"
                HintQuestion.DataValueField = "Code"
                HintQuestion.DataSource = GetApplicationCodes("CUS", "HINT_QUESTION", False)

                HintQuestion.DataBind()

                Dim oLI As New System.Web.UI.WebControls.ListItem
                oLI.Text = Localization.GetString("HintQuestionInitLine", LocalResourceFile)
                oLI.Value = "-1"
                oLI.Selected = True
                HintQuestion.Items.Insert(0, oLI)
            End If



        End Sub
        Private Sub HideAddressDetailFlags()
            Dim lblAddressDetailFlags As Label = CType(ctladdress.FindControl("lblAddressDetailFlags"), Label)
            If Not lblAddressDetailFlags Is Nothing Then
                lblAddressDetailFlags.Visible = False
            End If
            Dim lblPrimaryFlagCaption As Label = CType(ctladdress.FindControl("lblPrimaryFlagCaption"), Label)
            If Not lblPrimaryFlagCaption Is Nothing Then
                lblPrimaryFlagCaption.Visible = False
            End If
            Dim chkPrimaryAddress As CheckBox = CType(ctladdress.FindControl("chkPrimaryAddress"), CheckBox)
            If Not chkPrimaryAddress Is Nothing Then
                chkPrimaryAddress.Visible = False
            End If
            Dim imgPrimary As Image = CType(ctladdress.FindControl("imgPrimary"), Image)
            If Not imgPrimary Is Nothing Then
                imgPrimary.Visible = False
            End If
            Dim lblShipToCaption As Label = CType(ctladdress.FindControl("lblShipToCaption"), Label)
            If Not lblShipToCaption Is Nothing Then
                lblShipToCaption.Visible = False
            End If
            Dim chkShipAddress As CheckBox = CType(ctladdress.FindControl("chkShipAddress"), CheckBox)
            If Not chkShipAddress Is Nothing Then
                chkShipAddress.Visible = False
            End If
            Dim imgShipTo As Image = CType(ctladdress.FindControl("imgShipTo"), Image)
            If Not imgShipTo Is Nothing Then
                imgShipTo.Visible = False
            End If
            Dim lblBillToCaption As Label = CType(ctladdress.FindControl("lblBillToCaption"), Label)
            If Not lblBillToCaption Is Nothing Then
                lblBillToCaption.Visible = False
            End If
            Dim chkBillAddress As CheckBox = CType(ctladdress.FindControl("chkBillAddress"), CheckBox)
            If Not chkBillAddress Is Nothing Then
                chkBillAddress.Visible = False
            End If
            Dim imgBillTo As Image = CType(ctladdress.FindControl("imgBillTo"), Image)
            If Not imgBillTo Is Nothing Then
                imgBillTo.Visible = False
            End If
            Dim lblForDirectoryUseCaption As Label = CType(ctladdress.FindControl("lblForDirectoryUseCaption"), Label)
            If Not lblForDirectoryUseCaption Is Nothing Then
                lblForDirectoryUseCaption.Visible = False
            End If
            Dim chkForDirectoryUse As CheckBox = CType(ctladdress.FindControl("chkForDirectoryUse"), CheckBox)
            If Not chkForDirectoryUse Is Nothing Then
                chkForDirectoryUse.Visible = False
            End If
            Dim imgForDirectoryUse As Image = CType(ctladdress.FindControl("imgForDirectoryUse"), Image)
            If Not imgForDirectoryUse Is Nothing Then
                imgForDirectoryUse.Visible = False
            End If
        End Sub

        Private Sub GetCustomerIdFromCompanyString(ByVal Company As String, ByRef MCID As String, ByRef SCID As String)

            Dim strTemp() As String
            Dim strID As String
            MCID = ""
            SCID = ""
            strTemp = Company.Split(CChar("-"))

            If strTemp.Length > 2 Then

                strID = strTemp(strTemp.GetUpperBound(0))
                strID = strID.Remove(strID.Length - 1, 1)

                If IsNumeric(strID) Then
                    SCID = CStr(CInt(strID))
                End If

                strID = strTemp(strTemp.GetUpperBound(0) - 1)

                MCID = strID.Trim.Remove(0, 1)
            End If
        End Sub

        Private Sub GetPrimaryAddressForCustomer(ByVal strMCID As String, ByVal strSCID As String)
            If ctladdress IsNot Nothing Then
                Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
                oAddresses = df_GetCustomerAddress(strMCID, strSCID)

                If oAddresses.Count > 0 Then
                    With oAddresses(0)
                        ctladdress.AddressStructureCountryCode = .CountryCode

                        ctladdress.CompanyName = .CompanyName
                        ctladdress.CompanyMasterCustomerId = .OwnerMasterCustomer
                        ctladdress.CompanySubCustomerId = CInt(.OwnerSubCustomer)
                        ctladdress.CompanyAddressId = CStr(.CustomerAddressId)
                        ctladdress.CompanyName = .LabelName
                        ctladdress.CompanyAddressLabelValue = .LabelName & "<br>" & .FormattedAddress.Replace(vbCrLf, "<br>")


                        ctladdress.CountryCode = .CountryCode
                        ctladdress.State = .State
                        ctladdress.Address1 = .Address1
                        ctladdress.Address2 = .Address2
                        ctladdress.Address3 = .Address3
                        ctladdress.Address4 = .Address4
                        ctladdress.City = .City
                        ctladdress.County = .County
                        ctladdress.PostalCode = .PostalCode
                        ctladdress.IsCompanyAddress = True
                    End With
                End If
            End If
        End Sub

        Private Function ReadSettings() As Boolean
            'If Not Settings(C_DISPLAY_AS) Is Nothing Then
            '    If String.Compare(CType(Settings(C_DISPLAY_AS), String), "Register", True) = 0 Then
            '        DisplayMode = enmDisplayMode.Register
            '    Else
            '        DisplayMode = enmDisplayMode.Profile
            '    End If
            'End If

            'If Not Settings(C_REGISTER_CREATE_WEB_USER) Is Nothing Then
            '    If CType(Settings(C_REGISTER_CREATE_WEB_USER), String) = "Y" Then
            '        IsCreateWebUserEnabled = True
            '    Else
            '        IsCreateWebUserEnabled = False
            '    End If
            'End If


            '' If the CreateWebUser setting is enabled, check how the webuser needs to be created (mode??)
            'If IsCreateWebUserEnabled Then
            '    If Not Settings(C_REGISTER_CREATE_WEB_USER_MODE) Is Nothing Then
            '        ' Check the Mode of web user creation and assign property value
            '        If String.Compare(CType(Settings(C_REGISTER_CREATE_WEB_USER_MODE), String), "WorkFlow", True) = 0 Then
            '            CreateWebUserMode = enmCreateWebUserMode.Workflow
            '        Else
            '            CreateWebUserMode = enmCreateWebUserMode.Auto
            '        End If
            '    Else
            '        ' Backward compatibility. In the older version whenever "CreateWebUser" was enabled, though "CreatewebUserMode" did not exists, was assumed to be "Auto"
            '        CreateWebUserMode = enmCreateWebUserMode.Auto
            '    End If

            'End If


            'If Not Settings(C_REGISTER_ENABLE_CREATE_SEGMENT_RECORD) Is Nothing Then
            '    If CType(Settings(C_REGISTER_ENABLE_CREATE_SEGMENT_RECORD), String) = "Y" Then
            '        IsCreateSegmentRecordEnabled = True
            '    Else
            '        IsCreateSegmentRecordEnabled = False
            '    End If
            'End If

            'If Not Settings(C_REGISTER_SHIPTO_BILLTO) Is Nothing Then
            '    If CType(Settings(C_REGISTER_SHIPTO_BILLTO), String) = "Y" Then
            '        IsShipToBillToEnabled = True
            '    Else
            '        IsShipToBillToEnabled = False
            '    End If
            'End If

            If Settings(ModuleSettingsNames.C_TEMPLATE_FILE) Is Nothing Then
                Return False
            End If

            If Not Settings(ModuleSettingsNames.C_REQUIRES_LOGIN) Is Nothing Then
                If CType(Settings(ModuleSettingsNames.C_REQUIRES_LOGIN), String) = "Y" Then
                    IsLoginRequired = True
                Else
                    IsLoginRequired = False
                End If
            Else
                Return False
            End If

            If Not Settings(ModuleSettingsNames.C_REGISTER_BUTTON_CAPTION) Is Nothing Then
                RegisterButtonCaption = CType(Settings(ModuleSettingsNames.C_REGISTER_BUTTON_CAPTION), String)
            Else
                RegisterButtonCaption = String.Empty
                Return False
            End If

            If Not Settings(ModuleSettingsNames.C_CUSTOMER_RECORD_TYPE) Is Nothing Then
                CustomerRecordType = CType(Settings(ModuleSettingsNames.C_CUSTOMER_RECORD_TYPE), String)
            Else
                Return False
            End If

            If Not Settings(ModuleSettingsNames.C_USE_COMPANY_LOOKUP) Is Nothing Then
                UseCompanyLookup = CBool(IIf(CType(Settings(ModuleSettingsNames.C_USE_COMPANY_LOOKUP), String) = "Y", True, False))
            Else
                UseCompanyLookup = False
            End If
            Return True
        End Function

        Private Sub SetCommunicationMask(ByVal sender As Object, ByVal code As String)
            'set the communication mask for the country selected
            Dim control As DropDownList = CType(sender, DropDownList)
            Dim oPhoneStructures As TIMSS.API.CustomerInfo.ICustomerPhoneStructures
            Dim oPhoneStructure As TIMSS.API.CustomerInfo.ICustomerPhoneStructure
            Dim strCountryCode As String = ""
            Dim CountryCode As String
            If code = String.Empty Then
                CountryCode = control.SelectedValue
            Else
                CountryCode = code
            End If

            If CountryCode.Length = 0 Then
                Exit Sub
            End If

            strCountryCode = TIMSS.API.CachedApplicationData.ApplicationDataCache.Country(CountryCode).PhoneCountryCode
            If strCountryCode <> String.Empty Then

                Dim idLabelCountryCode As String = "lbl" & control.ID.Substring(3, control.ID.LastIndexOf("_") - 2) & "PhoneCountryCode"
                If FindControl(idLabelCountryCode) IsNot Nothing Then
                    Dim lblCountryCode As Label = CType(FindControl(idLabelCountryCode), Label)
                    lblCountryCode.Text = String.Concat("( ", strCountryCode, " )")
                End If
            End If
            oPhoneStructures = DF_GetCustomerPhoneStructures(CountryCode)

            ' Reset the forms
            Dim idTextPhoneExtension As String = control.ID.Substring(0, control.ID.LastIndexOf("_") + 1) & "PhoneExtension"
            If Not FindControl(idTextPhoneExtension) Is Nothing Then
                CType(FindControl(idTextPhoneExtension), TextBox).Visible = False
            End If
            Dim idLabelPhoneExtension As String = "lbl" & control.ID.Substring(3, control.ID.LastIndexOf("_") - 2) & "PhoneExtension"
            If Not FindControl(idLabelPhoneExtension) Is Nothing Then
                CType(FindControl(idLabelPhoneExtension), Label).Visible = False
            End If

            If oPhoneStructures.Count > 0 Then
                For Each oPhoneStructure In oPhoneStructures
                    With oPhoneStructure
                        Select Case oPhoneStructure.FieldName
                            Case "PHONE_COUNTRY_CODE"

                            Case "PHONE_AREA_CODE"
                                Dim idTextPhoneAreaCode As String = control.ID.Substring(0, control.ID.LastIndexOf("_") + 1) & "PhoneAreaCode"
                                If Not FindControl(idTextPhoneAreaCode) Is Nothing Then
                                    CType(FindControl(idTextPhoneAreaCode), TextBox).Visible = True
                                    CType(FindControl(idTextPhoneAreaCode), TextBox).MaxLength = .MaxLength
                                End If

                                Dim idLabelPhoneAreaCode As String = "lbl" & control.ID.Substring(3, control.ID.LastIndexOf("_") - 2) & "PhoneAreaCode"
                                If Not FindControl(idLabelPhoneAreaCode) Is Nothing Then
                                    CType(FindControl(idLabelPhoneAreaCode), Label).Visible = True
                                End If

                                Dim idLabelPhoneNumber As String = "lbl" & control.ID.Substring(3, control.ID.LastIndexOf("_") - 2) & "PhoneNumber"
                                If Not FindControl(idLabelPhoneNumber) Is Nothing Then
                                    CType(FindControl(idLabelPhoneNumber), Label).Visible = True
                                End If


                            Case "PHONE_NUMBER"
                                Dim idTextPhoneNumber As String = control.ID.Substring(0, control.ID.LastIndexOf("_") + 1) & "PhoneNumber"
                                If Not FindControl(idTextPhoneNumber) Is Nothing Then
                                    CType(FindControl(idTextPhoneNumber), TextBox).Visible = True
                                    CType(FindControl(idTextPhoneNumber), TextBox).MaxLength = .MaxLength
                                End If


                            Case "PHONE_EXTENSION"
                                If Not FindControl(idTextPhoneExtension) Is Nothing Then
                                    CType(FindControl(idTextPhoneExtension), TextBox).Visible = True
                                    CType(FindControl(idTextPhoneExtension), TextBox).MaxLength = .MaxLength
                                End If

                                If Not FindControl(idLabelPhoneExtension) Is Nothing Then
                                    CType(FindControl(idLabelPhoneExtension), Label).Visible = True
                                    CType(FindControl(idLabelPhoneExtension), Label).Text = "(" & StrConv(.Prefix, VbStrConv.ProperCase) & ")"
                                End If

                        End Select
                    End With
                Next
            Else
                SetCommunicationMask(sender, "[ALL]")
            End If

        End Sub


        Private Function BuildErrorMessage(ByVal issues As TIMSS.API.Core.Validation.IssuesCollection) As TIMSS.API.Core.Validation.IssuesCollection

            Dim oIssuesList As New TIMSS.API.Core.Validation.IssuesCollection

            Dim intMinPasswordlength As Integer
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            globalVariables.ModuleId = ModuleId
            globalVariables.Customer = "Customer"
            globalVariables.CustomerCommunication = "CustomerCommunication"
            globalVariables.WebUser = "WebUser"
            Dim txtUserId As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_UserId"), TextBox)
            Dim txtPassword As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Password"), TextBox)
            Dim txtVerifyPassword As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Password_Confirm"), TextBox)
            Dim ddlHintQuestion As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Question"), DropDownList)
            Dim txtHintAnswer As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Answer"), TextBox)
            Dim txtEmail As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_Email_Home_FormattedPhoneAddress"), TextBox)

            If txtUserId IsNot Nothing AndAlso String.Compare(txtUserId.Text, String.Empty) = 0 Then
                Dim message As String = Localization.GetString("UserIdError", LocalResourceFile)
                Dim obj As New BusinessObject()
                Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                With oIssue
                    .Message = message
                    .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                    .ResponseRequired = False
                End With
                oIssuesList.Add(oIssue)
            End If
            If txtPassword IsNot Nothing And txtVerifyPassword IsNot Nothing Then
                intMinPasswordlength = GetMinPasswordLength()
                If txtPassword.Text.Length < intMinPasswordlength Then
                    Dim message As String = String.Format(Localization.GetString("PasswordError", LocalResourceFile), intMinPasswordlength.ToString)
                    Dim obj As New BusinessObject()
                    Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                    With oIssue
                        .Message = message
                        .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                        .ResponseRequired = False
                    End With
                    oIssuesList.Add(oIssue)
                End If
                If Not String.Compare(txtPassword.Text, txtVerifyPassword.Text) = 0 Then
                    Dim message As String = Localization.GetString("PasswordsMatchError", LocalResourceFile)
                    Dim obj As New BusinessObject()
                    Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                    With oIssue
                        .Message = message
                        .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                        .ResponseRequired = False
                    End With
                    oIssuesList.Add(oIssue)
                End If
            End If

            If ddlHintQuestion IsNot Nothing AndAlso ddlHintQuestion.SelectedValue = "-1" Then
                Dim message As String = Localization.GetString("HintQuestionError", LocalResourceFile)
                Dim obj As New BusinessObject()
                Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                With oIssue
                    .Message = message
                    .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                    .ResponseRequired = False
                End With
                oIssuesList.Add(oIssue)
            End If
            If txtHintAnswer IsNot Nothing AndAlso String.Compare(txtHintAnswer.Text, String.Empty) = 0 Then
                Dim message As String = Localization.GetString("HintAnswerError", LocalResourceFile)
                Dim obj As New BusinessObject()
                Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                With oIssue
                    .Message = message
                    .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                    .ResponseRequired = False
                End With
                oIssuesList.Add(oIssue)
            End If


            If txtEmail IsNot Nothing AndAlso String.Compare(txtEmail.Text, String.Empty) = 0 Then
                Dim message As String = Localization.GetString("EmailError", LocalResourceFile)
                Dim obj As New BusinessObject()
                Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                With oIssue
                    .Message = message
                    .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                    .ResponseRequired = False
                End With
                oIssuesList.Add(oIssue)
            End If

            For Each issue As TIMSS.API.Core.Validation.IssueBase In issues
                oIssuesList.Add(issue)
            Next

            Return oIssuesList
        End Function

        ''' <summary>
        ''' This needs to be replace with validationIssues control
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function ValidateForm() As Boolean
            Dim intMinPasswordlength As Integer
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            globalVariables.ModuleId = ModuleId
            globalVariables.Customer = "Customer"
            globalVariables.CustomerCommunication = "CustomerCommunication"
            globalVariables.WebUser = "WebUser"
            Dim txtUserId As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_UserId"), TextBox)
            Dim txtPassword As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Password"), TextBox)
            Dim txtVerifyPassword As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Password_Confirm"), TextBox)
            Dim ddlHintQuestion As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Question"), DropDownList)
            Dim txtHintAnswer As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.WebUser & "_Hint_Answer"), TextBox)

            'Select Case CustomerRecordType
            'Case "I"
            'If String.Compare(txtFirstName.Text, String.Empty) = 0 Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("FirstNameError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            ' Return False
            'End If

            'If String.Compare(txtLastName.Text, String.Empty) = 0 Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("LastNameError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            ' Case "C"
            'If String.Compare(txtAltLastName.Text, String.Empty) = 0 Then
            '            lblError.Text = Localization.GetString("CompanyNameError", LocalResourceFile)
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("CompanyNameError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'Case "T"
            'If String.Compare(txtAltLastName.Text, String.Empty) = 0 Then
            '            lblError.Text = Localization.GetString("CommitteeNameError", LocalResourceFile)
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("CommitteeNameError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'End Select
            'If String.Compare(ctladdress.AddressType, String.Empty) = 0 Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("AddressTypeError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'If String.Compare(ctladdress.CompanyName, String.Empty) = 0 Then
            'if there is an CompanyName selected the form address fields are not considered
            'If String.Compare(ctladdress.Address1, String.Empty) = 0 Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("Address1Error", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'If String.Compare(ctladdress.City, String.Empty) = 0 Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("CityError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'If String.Compare(ctladdress.PostalCode, String.Empty) = 0 Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("PostalCodeError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'If String.Compare(ctladdress.State, "[ALL]") = 0 AndAlso ctladdress.CountryCode = "USA" Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("StateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            'End If

            'Dim oRegex As New System.Text.RegularExpressions.Regex("^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$")
            'If Not oRegex.IsMatch(txtEmail.Text) Then
            'Skins.Skin.AddModuleMessage(Me, Localization.GetString("EmailError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'Return False
            'End If
            If txtUserId IsNot Nothing AndAlso String.Compare(txtUserId.Text, String.Empty) = 0 Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserIdError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            If txtPassword IsNot Nothing And txtVerifyPassword IsNot Nothing Then
                intMinPasswordlength = GetMinPasswordLength()
                If txtPassword.Text.Length < intMinPasswordlength Then
                    Skins.Skin.AddModuleMessage(Me, String.Format(Localization.GetString("PasswordError", LocalResourceFile), intMinPasswordlength.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If
                If Not String.Compare(txtPassword.Text, txtVerifyPassword.Text) = 0 Then
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("PasswordsMatchError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If
            End If

            If ddlHintQuestion IsNot Nothing AndAlso ddlHintQuestion.SelectedValue = "-1" Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("HintQuestionError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            If txtHintAnswer IsNot Nothing AndAlso String.Compare(txtHintAnswer.Text, String.Empty) = 0 Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("HintAnswerError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            Return True
        End Function

        ''' <summary>
        ''' Return the length of the password set in the Web.Config
        ''' TODO: Personify Enterprise should validate passwords
        ''' based on thi value otherwise users with passwords that do not
        ''' match this length will not be allowed to login
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetMinPasswordLength() As Integer
            Try
                Dim oMembProv As DotNetNuke.Security.Membership.MembershipProvider = DotNetNuke.Security.Membership.MembershipProvider.Instance()
                Dim minPasswordLength As Integer = oMembProv.MinPasswordLength
                If minPasswordLength = 0 Then
                    Return 7 'default is set to 7
                End If
                Return minPasswordLength
            Catch ex As Exception
                Return 7
            End Try
        End Function

        ''' <summary>
        ''' Redirects users to a Admin specified tab after registration process is successful
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub HandleRedirectionForNewUsers(ByVal userid As String, ByVal password As String)
            Dim strTabId As String
            'if a post register url is specified
            If Settings(ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL) IsNot Nothing Then
                strTabId = Settings(ModuleSettingsNames.C_POST_REGISTER_NAVIGATE_URL).ToString
                If IsWorkFlowForSegment Then
                    'if the current process is part of worflow for segment
                    'the user will be redirected to the specified tab 
                    'sending in queryString the mcid and scid of the newly added customer
                    'encrypt the ids
                    Dim encryptedMCID As String = TIMSS.Common.Encryption.Encrypt(objMasterCustomerId)
                    encryptedMCID = Replace(Server.UrlEncode(encryptedMCID), "", "+")
                    Dim encryptedSCID As String = TIMSS.Common.Encryption.Encrypt(CStr(objSubCustomerId))
                    encryptedSCID = Replace(Server.UrlEncode(encryptedSCID), "", "+")
                    Response.Redirect(NavigateURL(Integer.Parse(strTabId), "", "&referrer=NEW&mcid=" & encryptedMCID & "&scid=" & encryptedSCID))
                Else
                    'if not segment workflow
                    'Auto Login
                    Dim loginStatus As Personify.LoginStatus
                    Dim oLoginManager As New Personify.LoginManager(userid, password)
                    Dim objUser As UserInfo = Nothing

                    loginStatus = oLoginManager.Login()
                    If loginStatus.loginStatus = UserLoginStatus.LOGIN_SUCCESS Then

                        If RedirectURL = "" Then
                            Response.Redirect(NavigateURL(Integer.Parse(strTabId)))
                        Else
                            Response.Redirect(RedirectURL, True)
                        End If

                    End If
                End If
            Else
                'if a post register url is not specified
                'Auto Login
                Dim loginStatus As Personify.LoginStatus
                Dim oLoginManager As New Personify.LoginManager(userid, password)
                Dim objUser As UserInfo = Nothing

                loginStatus = oLoginManager.Login()
                If loginStatus.loginStatus = DotNetNuke.Security.Membership.UserLoginStatus.LOGIN_SUCCESS Then
                    If RedirectURL = "" Then
                        Response.Redirect(NavigateURL(), True)
                    Else
                        Response.Redirect(RedirectURL, True)
                    End If
                End If
            End If
        End Sub

        ''' <summary>
        ''' Redirects users to a Admin specified tab if registered users come to this web part
        ''' Except for IsWorkFlowForSegment
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function HandleRedirectionForRegisteredUsers() As Boolean
            Try
                ' Check if Login is required to access this web part.
                'For e.g. this web part can be used to register a new customer using Affiliate Management
                ' All the other times when a registered user tries accessing this web part, it should redirect them 
                'to the tabId set by the admin in the C_REGISTERED_USER_NAVIGATE_URL setting
                If Not IsWorkFlowForSegment Then
                    If Not IsLoginRequired Then
                        If IsUserLoggedIn() Then
                            Dim strTabId As String
                            Me.Visible = False
                            If Settings(ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL) IsNot Nothing Then
                                strTabId = Settings(ModuleSettingsNames.C_REGISTERED_USER_NAVIGATE_URL).ToString
                                Response.Redirect(NavigateURL(Integer.Parse(strTabId)))
                            Else
                                ' The web part was not properly set-up
                                Return False
                            End If
                        Else
                            Return True
                        End If
                    Else
                        Return True
                    End If
                Else
                    Return True
                End If

            Catch ex As Threading.ThreadAbortException
                'ignore
            End Try

        End Function

        ''' <summary>
        ''' Checks if a Personify User is logged in
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' 
        Private Function IsUserLoggedIn() As Boolean
            Try
                If Not UserInfo.IsSuperUser AndAlso _
                        (UserInfo.Profile.GetPropertyValue("MasterCustomerId") <> String.Empty) AndAlso _
                        (UserInfo.Profile.GetPropertyValue("SubCustomerId") <> String.Empty) AndAlso _
                        (UserInfo.Profile.GetPropertyValue("MasterCustomerId") IsNot Nothing) AndAlso _
                        (UserInfo.Profile.GetPropertyValue("SubCustomerId") IsNot Nothing) Then
                    Return True
                Else 'User is not logged in
                    Return False
                End If
            Catch exc As Exception
                Throw exc
            End Try
            'Return False
        End Function

#End Region
        Public Class XSLFileGlobalVariables
            Public ModuleId As Integer
            Public Customer As String
            Public WebUser As String
            Public CustomerCommunication As String
        End Class

#Region "SSO functions"

        Protected ReadOnly Property RedirectURL() As String
            Get
                Dim _RedirectURL As String = ""

                If Not Request.QueryString("returnurl") Is Nothing Then
                    ' return to the url passed to signin
                    _RedirectURL = HttpUtility.UrlDecode(Request.QueryString("returnurl"))
                End If

                Return _RedirectURL
            End Get

        End Property

        Private Sub SSORegistrationValidationCheck()

            If IsSSOEnabled() AndAlso GetCustomerToken() Is Nothing Then

                'redirect to login page which should redirect to SSO login page
                Dim strURL As New System.Text.StringBuilder
                strURL.Append(NavigateURL(PortalSettings.LoginTabId))
                If RedirectURL <> "" Then
                    strURL.Append("?returnurl=")
                    strURL.Append(RedirectURL)
                End If
                Response.Redirect(strURL.ToString, True)
            End If

        End Sub

        Private Function GetCustomerToken() As String
            If Not Session("customerToken") Is Nothing AndAlso CStr(Session("customerToken")) <> "" Then
                Return CStr(Session("customerToken"))
            ElseIf Not Session("CT") Is Nothing AndAlso CStr(Session("CT")) <> "" Then
                Dim decrypted As String = SSOLoginManager.DecryptCustomerToken(CStr(Session("CT")))

                Return decrypted.Substring(decrypted.IndexOf("|") + 1, decrypted.Length - decrypted.IndexOf("|") - 1)
            End If
            Return Nothing
        End Function

        Private Function IsSSOEnabled() As Boolean

            Dim EnableSSO As String = System.Configuration.ConfigurationManager.AppSettings("EnableSSO")
            If EnableSSO IsNot Nothing AndAlso EnableSSO.ToUpper = "Y" Then
                Dim oModules As New Entities.Modules.ModuleController
                If oModules.GetModuleSettings(ModuleId).ContainsKey("chkSSO") Then
                    If CType(Settings("chkSSO"), String) = "Y" Then
                        Return True
                    End If
                End If
            End If


            Return False
        End Function

        Private Sub HandleSSORegistrationSetup()


            If IsSSOEnabled() Then

                Dim strEmailid As String = Request.QueryString("EMAIL")
                If strEmailid IsNot Nothing AndAlso strEmailid <> "" Then

                    Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
                    globalVariables.ModuleId = ModuleId
                    globalVariables.Customer = "Customer"
                    globalVariables.CustomerCommunication = "CustomerCommunication"
                    globalVariables.WebUser = "WebUser"

                    Dim txtEmailId As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_Email_Home_FormattedPhoneAddress"), TextBox)

                    If Not txtEmailId Is Nothing Then
                        txtEmailId.Text = strEmailid
                    End If
                End If
            End If

        End Sub

#End Region


#Region "Personify Data"

        Private Function df_DoesWebUserIDExists(ByVal UserId As String) As Boolean
            'Check if the user exists
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers

            oWebList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

            oWebList.Filter.Add("UserId", TIMSS.Enumerations.QueryOperatorEnum.Equals, UserId)
            oWebList.Fill()
            If oWebList.Count > 0 Then
                Return True
            End If

            Return False

        End Function
        Private Function df_GetAlternativeWebUserIDs(ByVal UserId As String) As String
            'Check if the user exists


            Dim users As String = String.Empty
            Dim nullString As String = Nothing
            Dim RenewalStoredProcedureRequest As IStoredProcedureRequest = New StoredProcedureRequest("WEB_Generate_User_Id")

            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("pstrUserId", UserId, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("newUserIds", users, ParameterDirection.Output))
            Dim request As IQueryRequest = New QueryRequest(RenewalStoredProcedureRequest)

            Dim oQueryResult As IQueryResult
            oQueryResult = Me.PersonifyExecuteQueryRequest(request)

            If oQueryResult.Success Then
                Return oQueryResult.DataSet.Tables(0).Rows(0).Item(1)
            End If

            Return Nothing


        End Function


        Private Function df_GetCustomerAddress(ByVal MasterCustomerId As String, _
                    ByVal SubCustomerId As String, Optional ByVal CustomerAddressId As Integer = -1) As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            oAddresses = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")

            With oAddresses.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)

                If CustomerAddressId <> -1 Then
                    .Add("CustomerAddressId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CustomerAddressId)
                End If

            End With

            oAddresses.Fill()

            Return oAddresses

        End Function

        Private Function df_GetPrimaryAddressIdForCompany(ByVal pCompanyMasterCustomerId As String, ByVal pCompanySubCustomerId As Integer) As Integer

            'Use this to get customer for login. The API's do not have segmentation, hence use search object.

            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressDetails")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty
            'Customer - MCId, SCID, FirstName, LastNAme
            oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = pCompanyMasterCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = pCompanySubCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("PrioritySeq")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = 0
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("CustomerAddressId")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)


            searchObj.Search()

            If searchObj.Results.Table.Rows.Count > 0 Then
                Return DirectCast(searchObj.Results.Table.Rows(0).Item("CustomerAddressId"), Decimal)
            Else
                Return -1
            End If

        End Function

        Private Function df_GetCompanyLookup(ByVal CompanyName As String) As DataSet

            Dim strCacheKey As String = ""



            Dim oQueryResult As IQueryResult
            'Dim oParameters As New Hashtable
            Dim oParameters As New TIMSS.SqlObjects.RequestParameters

            oParameters.Add(New RequestParameter("P_RECORDTYPE", "C"))
            oParameters.Add(New RequestParameter("P_LABELNAME", CompanyName))


            Dim param1 As RequestParameter
            param1 = New RequestParameter("P_RECORDTYPE", "C")
            param1.Name = "P_RECORDTYPE"


            Dim param2 As RequestParameter
            param2 = New RequestParameter("P_LABELNAME", CompanyName)
            param2.Name = "P_LABELNAME"



            oQueryResult = Me.PersonifyExecuteQueryRequest(df_GetSelectRequest_GetCompanies, "@P_LABELNAME", CompanyName, "@P_RECORDTYPE", "C")

            'Massage the dataset
            With oQueryResult
                If .Success Then
                    For Each oRow As DataRow In .DataSet.Tables(0).Rows
                        'oRow.Item("master_customer_id") = "(" & oRow.Item("master_customer_id") & "-" & oRow.Item("sub_customer_id") & ")"
                        oRow.Item("master_customer_id") = TIMSS.Constants.Application.C_KEY_DELIMITER & oRow.Item("master_customer_id") & TIMSS.Constants.Application.C_KEY_DELIMITER & oRow.Item("sub_customer_id")
                    Next

                End If

            End With


            Return oQueryResult.DataSet

        End Function


        Private Function df_GetSelectRequest_GetCompanies() As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("GetCompanies")

            Dim tblCustomer As SelectTable = New SelectTable("cus_primary_info_vw", "c")

            tblCustomer.ResultColumns.Add("master_customer_id")
            tblCustomer.ResultColumns.Add("sub_customer_id")
            tblCustomer.ResultColumns.Add("customer_label_name")
            tblCustomer.ResultColumns.Add("formatted_address")

            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblCustomer)
            request.Parameters.Add("c", "record_type", "P_RECORDTYPE", String.Empty)
            request.Parameters.Add("c", "customer_label_name", "P_LABELNAME", "a", ParameterDirection.Input, QueryOperatorType.StartsWith)

            Return request
        End Function

        Private Function DF_GetCustomerPhoneStructures(ByVal Country As String) As TIMSS.API.CustomerInfo.ICustomerPhoneStructures

            Dim oPhoneStructures As TIMSS.API.CustomerInfo.ICustomerPhoneStructures

            oPhoneStructures = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerPhoneStructures")
            oPhoneStructures.Filter.Add("CountryCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, Country)
            oPhoneStructures.Filter.Add("AvailableFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
            oPhoneStructures.Fill()


            Return oPhoneStructures

        End Function

        Private Function df_ValidateCustomer(ByVal oCustomers As TIMSS.API.CustomerInfo.ICustomers, _
            Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.CustomerInfo.ICustomer


            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False


            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys)
                End If
            End If
            If GetSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "Customer"
                    '.GUID = oCustomers(0).Guid
                End With
            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys), BusinessObjectGUIDStorage())
            End If

            With oCustomers(0)
                If bGUIDExists Then
                    .Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = .Guid
                End If

            End With
            AddSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys, oclsGUID)



            If oCustomers(0).Addresses(0) IsNot Nothing Then
                oCustomers(0).Addresses(0).Guid = oCustomers(0).Guid
            End If
            If oCustomers(0).AddressDetails(0) IsNot Nothing Then
                oCustomers(0).AddressDetails(0).Address.IsAddressValidationAutoRespond = True
                oCustomers(0).AddressDetails(0).Guid = oCustomers(0).Guid
            End If
            If oCustomers(0).Communications(0) IsNot Nothing Then
                oCustomers(0).Communications(0).Guid = oCustomers(0).Guid
            End If
            oCustomers.Validate()

            If oCustomers.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then
                RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)
                'D00031386, D00031387 start

                'oCustomers.Validate()

                'D00031386, D00031387 end
            End If

            If oCustomers.ValidationIssues.ErrorCount = 0 Then
                'Remove the guids
                ClearSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys)
            End If
            Return oCustomers(0)

        End Function


        Private Function df_AddCustomer(ByVal oCustomers As TIMSS.API.CustomerInfo.ICustomers, _
                    Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.CustomerInfo.ICustomer

            'Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False



            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "Customer"
                    '.GUID = oCustomers(0).Guid
                End With
            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys), BusinessObjectGUIDStorage())
            End If

            ''oCustomers = CType(TIMSS.Global.App.GetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers"), TIMSS.API.CustomerInfo.ICustomers)
            'Dim oCustomer As TIMSS.API.CustomerInfo.ICustomer
            'oCustomer = oCustomers.AddNew()
            'oCustomer = Customer
            With oCustomers(0)
                If bGUIDExists Then
                    .Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = .Guid
                End If

            End With
            AddSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys, oclsGUID)


            If oCustomers(0).Addresses(0) IsNot Nothing Then
                oCustomers(0).Addresses(0).Guid = oCustomers(0).Guid
            End If
            If oCustomers(0).AddressDetails(0) IsNot Nothing Then
                oCustomers(0).AddressDetails(0).Guid = oCustomers(0).Guid
                oCustomers(0).AddressDetails(0).Address.IsAddressValidationAutoRespond = True
            End If
            If oCustomers(0).Communications(0) IsNot Nothing Then
                oCustomers(0).Communications(0).Guid = oCustomers(0).Guid
            End If

            'Set the Original Source Code to the Application Parameter Value
            Dim oAppParams As TIMSS.API.ApplicationInfo.IApplicationParameters
            oAppParams = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ApplicationInfo, "ApplicationParameters")
            oAppParams.Filter.Add("ParameterName", "WEB_NEW_CUSTOMER_SOURCE_CODE")
            oAppParams.Fill()

            If oAppParams.Count > 0 Then
                oCustomers(0).OriginalSourceCode.Code = oAppParams(0).ParameterValue
                'oCustomers(0).OriginalSourceCode = oCustomers(0).OriginalSourceCode.List(oAppParams(0).ParameterValue).ToCodeObject
            End If
            'Set the Original Source Code to the Application Parameter Value

            oCustomers.Save()


            If oCustomers.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)

                oCustomers.Save()
            End If

            If oCustomers.ValidationIssues.ErrorCount = 0 Then
                'Remove the guids
                ClearSessionObject(SessionKeys.PersonifyAddCustomerGUIDKeys)
            End If
            Return oCustomers(0)

        End Function

        Private Function df_CreateWebUserAccount(ByVal MasterCustomerID As String, _
                                                        ByVal SubCustomerID As Integer, _
                                                        ByVal UserId As String, _
                                                        ByVal Password As String, _
                                                        ByVal HintQuestion As String, _
                                                        ByVal HintAnswer As String) As Boolean

            '**Check if the user exists
            Dim oWebUser As TIMSS.API.WebInfo.IWebUser
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers

            Dim isWebUserAccountCreated As Boolean = False

            oWebList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

            oWebList.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerID)
            oWebList.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CStr(SubCustomerID))

            oWebList.Fill()

            If oWebList.Count > 0 Then

                ' save schema
                Dim bOrigUserIdReadOnlyUpdate As Boolean
                bOrigUserIdReadOnlyUpdate = oWebList.Schema.Item("UserId").IsReadOnly.OnUpdate
                oWebList.Schema.Item("UserId").IsReadOnly.OnUpdate = False

                oWebList(0).UserId = UserId
                oWebList(0).Password = Password
                oWebList(0).DisableLoginFlag = False
                oWebList(0).IsPasswordChangeRequired = False
                If HintQuestion.Trim <> "" Then
                    oWebList(0).HintQuestionCode = oWebList(0).HintQuestionCode.List(HintQuestion).ToCodeObject
                    oWebList(0).HintAnswer = HintAnswer
                End If

                oWebList.Save()
                'CreateWebUserAccount = True
                isWebUserAccountCreated = True

                ' reset schema to original value
                oWebList.Schema.Item("UserId").IsReadOnly.OnUpdate = bOrigUserIdReadOnlyUpdate
            Else
                oWebUser = oWebList.AddNew()
                With oWebUser
                    .MasterCustomerId = MasterCustomerID
                    .SubCustomerId = SubCustomerID
                    .UserId = UserId
                    .Password = Password
                    If HintQuestion.Trim <> "" Then
                        .HintQuestionCode = .HintQuestionCode.List(HintQuestion).ToCodeObject
                        .HintAnswer = HintAnswer
                    End If
                    .DisableLoginFlag = False
                    .IsPasswordChangeRequired = False
                End With
                oWebList.Save()
                'CreateWebUserAccount = True
                isWebUserAccountCreated = True
            End If

            Return isWebUserAccountCreated
        End Function
        Private Sub ParseCustomerId(ByVal customerId As String, ByRef MasterCustomerId As String, ByRef SubCustomerId As String)

            Dim aryCustomerId() As String = customerId.Split(TIMSS.Constants.Application.C_KEY_DELIMITER)

            If (aryCustomerId.Length > 1) Then
                MasterCustomerId = aryCustomerId(aryCustomerId.GetUpperBound(0) - 1)
                SubCustomerId = aryCustomerId(aryCustomerId.GetUpperBound(0))
            End If


        End Sub


        Private Function AddSegment(ByVal MasterCustomerId As String, _
            ByVal SubCustomerId As Integer, _
            ByVal SegmentRuleCode As ICode, _
            ByVal SegmentQualifier1 As String, ByVal SegmentQualifier2 As String, _
            ByVal CustomerRecordType As String, _
      Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection

            Dim oSegments As TIMSS.API.CustomerInfo.ICustomerSegmentControls

            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False

            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifyAddSegmentGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifyAddSegmentGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(SessionKeys.PersonifyAddSegmentGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "CustomerSegmentControl"
                    '.GUID = oCustomers(0).Guid
                End With

            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifyAddSegmentGUIDKeys), BusinessObjectGUIDStorage())
            End If

            oSegments = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerSegmentControls")
            Dim oSegment As TIMSS.API.CustomerInfo.ICustomerSegmentControl
            oSegment = oSegments.AddNew()
            With oSegment
                .MasterCustomerId = MasterCustomerId
                .SubCustomerId = SubCustomerId
                .SegmentRuleCode = SegmentRuleCode
                .SegmentQualifier1 = SegmentQualifier1
                .SegmentQualifier2 = SegmentQualifier2
                .SegmentControlFlag = True
                .WebSegmentControlFlag = True
                .ReadOnlyFlag = False
                .CanAddMemberFlag = True
                .CanRemoveMemberFlag = True
                .CanPlaceOrderFlag = True
                Select Case CustomerRecordType
                    Case "C"
                        .OrganizationId = "[ALL]"
                        .OrganizationUnitId = "[ALL]"
                    Case "T"
                        .OrganizationId = OrganizationId
                        .OrganizationUnitId = OrganizationUnitId
                End Select

                If bGUIDExists Then
                    .Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = .Guid
                End If

            End With


            AddSessionObject(SessionKeys.PersonifyAddSegmentGUIDKeys, oclsGUID)

            oSegments.Save()

            If oSegments.ValidationIssues.Count > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oSegments.ValidationIssues, RespondedValidationIssues)

                oSegments.Save()
            End If

            If oSegments.ValidationIssues.Count = 0 Then
                'Remove the guids
                ClearSessionObject(SessionKeys.PersonifyAddSegmentGUIDKeys)
                'amr - check if Reset the cache
                Dim strCacheKey As String = String.Concat("GetSegmentList", PortalId, MasterCustomerId, SubCustomerId)
                If Not PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then
                    PersonifyDataCache.Remove(strCacheKey)
                End If
            End If
            Return oSegments.ValidationIssues


        End Function



#End Region
    End Class


End Namespace
