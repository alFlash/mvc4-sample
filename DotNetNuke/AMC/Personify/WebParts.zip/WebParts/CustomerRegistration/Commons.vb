
Namespace Personify.DNN.Modules.CustomerRegistration

    Public Class ModuleSettingsNames
        Public Const C_POST_REGISTER_NAVIGATE_URL As String = "PostRegisterURL"
        Public Const C_POST_REGISTER_NAVIGATE_URL_TYPE As String = "PostRegisterURLType"
        Public Const C_REGISTERED_USER_NAVIGATE_URL As String = "RegisteredUserURL"
        Public Const C_REGISTERED_USER_NAVIGATE_URL_TYPE As String = "RegisteredUserURLType"
        Public Const C_REGISTER_BUTTON_CAPTION As String = "RegisterButtonCaption"
        Public Const C_CUSTOMER_RECORD_TYPE As String = "CustomerRecordType"
        Public Const C_CREATE_SEGMENT_RECORD As String = "CreateSegmentRecord"
        Public Const C_REQUIRES_LOGIN As String = "RequiresLogin"
        Public Const C_SHOW_ADDRESS_DETAIL_FLAGS As String = "ShowAddressDetailFlags"
        Public Const C_ADDRESS_DETAIL_FLAGS_DEFAULT_CHECKED As String = "AddressDetailFlagsDefaultChecked"
        Public Const C_USE_COMPANY_LOOKUP As String = "UseCompanyLookup"
        Public Const C_TEMPLATE_FILE As String = "TemplateFile"
    End Class

End Namespace

