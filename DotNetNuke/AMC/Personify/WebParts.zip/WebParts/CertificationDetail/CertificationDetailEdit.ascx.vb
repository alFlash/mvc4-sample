Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO

Namespace Personify.DNN.Modules.CertificationDetailEdit

    Public MustInherit Class CertificationDetailEdit
        Inherits ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl
        Const C_TEMPLATES As String = "Templates"
        Const C_DETAILSTEMPLATES As String = "DetailsTemplates"
        Const C_REVIEWTEMPLATES As String = "ReviewTemplates"
        'Const C_EDITADDRESS_ACTION As String = "EditAdressURL"
        Const C_Apply_ACTION As String = "ApplyURL"
        Const C_PrintTranscript_ACTION As String = "PrintTranscriptURL"
        Const C_AddTranscript_ACTION As String = "AddTranscriptURL"
        Const C_Login_ACTION As String = "LoginURL"


        Protected WithEvents select_DetailsTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents select_ReviewTemplate As System.Web.UI.WebControls.DropDownList
        'Protected WithEvents drpEditAddress As System.Web.UI.WebControls.DropDownList
        Protected WithEvents drpApply As System.Web.UI.WebControls.DropDownList

        Protected WithEvents drpPrintTranscript As System.Web.UI.WebControls.DropDownList
        Protected WithEvents drpAddTranscript As System.Web.UI.WebControls.DropDownList
        Protected WithEvents drpLogin As System.Web.UI.WebControls.DropDownList

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"

        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim _portalSettings As Entities.Portals.PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), Entities.Portals.PortalSettings)

                If Not select_DetailsTemplate.Items.Count > 0 Then
                    Dim li As ListItem
                    For Each li In GetTemplates()
                        If li.Text = "CertificationDetail.xsl" Then
                            li.Selected = True
                        End If
                        select_DetailsTemplate.Items.Add(li)
                    Next
                    select_DetailsTemplate.SelectedIndex = select_DetailsTemplate.Items.IndexOf(select_DetailsTemplate.Items.FindByValue(Convert.ToString(Settings(C_DETAILSTEMPLATES))))
                End If


                If Not select_ReviewTemplate.Items.Count > 0 Then
                    Dim li As ListItem
                    For Each li In GetTemplates()
                        If li.Text = "CertificationReview.xsl" Then
                            li.Selected = True
                        End If
                        select_ReviewTemplate.Items.Add(li)
                    Next
                    select_ReviewTemplate.SelectedIndex = select_ReviewTemplate.Items.IndexOf(select_ReviewTemplate.Items.FindByValue(Convert.ToString(Settings(C_REVIEWTEMPLATES))))
                End If

                Dim arrTabs As ArrayList = GetPortalTabs(_portalSettings.DesktopTabs, True, True)

                If Not Page.IsPostBack Then
                    'With drpEditAddress
                    '    .DataSource = arrTabs
                    '    .DataValueField = "TabId"
                    '    .DataTextField = "TabName"
                    '    .DataBind()
                    'End With
                    With drpApply
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    With drpPrintTranscript
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    With drpAddTranscript
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    With drpLogin
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    'If Not Settings(C_EDITADDRESS_ACTION) Is Nothing Then
                    '    If Not drpEditAddress.Items.FindByValue(Settings(C_EDITADDRESS_ACTION).ToString) Is Nothing Then
                    '        drpEditAddress.Items.FindByValue(Settings(C_EDITADDRESS_ACTION).ToString).Selected = True
                    '    Else
                    '        drpEditAddress.Items(0).Selected = True
                    '    End If
                    'End If

                    If Not Settings(C_Apply_ACTION) Is Nothing Then
                        If Not drpApply.Items.FindByValue(Settings(C_Apply_ACTION).ToString) Is Nothing Then
                            drpApply.Items.FindByValue(Settings(C_Apply_ACTION).ToString).Selected = True
                        Else
                            drpApply.Items(0).Selected = True
                        End If
                    End If

                    If Not Settings(C_PrintTranscript_ACTION) Is Nothing Then
                        If Not drpPrintTranscript.Items.FindByValue(Settings(C_PrintTranscript_ACTION).ToString) Is Nothing Then
                            drpPrintTranscript.Items.FindByValue(Settings(C_PrintTranscript_ACTION).ToString).Selected = True
                        Else
                            drpPrintTranscript.Items(0).Selected = True
                        End If
                    End If

                    If Not Settings(C_AddTranscript_ACTION) Is Nothing Then
                        If Not drpAddTranscript.Items.FindByValue(Settings(C_AddTranscript_ACTION).ToString) Is Nothing Then
                            drpAddTranscript.Items.FindByValue(Settings(C_AddTranscript_ACTION).ToString).Selected = True
                        Else
                            drpAddTranscript.Items(0).Selected = True
                        End If
                    End If


                    If Not Settings(C_Login_ACTION) Is Nothing Then
                        If Not drpLogin.Items.FindByValue(Settings(C_Login_ACTION).ToString) Is Nothing Then
                            drpLogin.Items.FindByValue(Settings(C_Login_ACTION).ToString).Selected = True
                        Else
                            drpLogin.Items(0).Selected = True
                        End If
                    End If

                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid

                If Page.IsValid = True Then

                    Dim objModules As New Entities.Modules.ModuleController

                    With objModules
                        .UpdateModuleSetting(ModuleId, C_DETAILSTEMPLATES, select_DetailsTemplate.SelectedValue)
                        .UpdateModuleSetting(ModuleId, C_REVIEWTEMPLATES, select_ReviewTemplate.SelectedValue)
                        '.UpdateModuleSetting(ModuleId, C_EDITADDRESS_ACTION, drpEditAddress.SelectedValue)
                        .UpdateModuleSetting(ModuleId, C_Apply_ACTION, drpApply.SelectedValue)
                        .UpdateModuleSetting(ModuleId, C_PrintTranscript_ACTION, drpPrintTranscript.SelectedValue)
                        .UpdateModuleSetting(ModuleId, C_AddTranscript_ACTION, drpAddTranscript.SelectedValue)
                        .UpdateModuleSetting(ModuleId, C_Login_ACTION, drpLogin.SelectedValue)
                    End With

                    'clean up
                    objModules = Nothing

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
