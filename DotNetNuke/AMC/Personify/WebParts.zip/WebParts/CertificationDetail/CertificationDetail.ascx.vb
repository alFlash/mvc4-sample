Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls




Namespace Personify.DNN.Modules.CertificationDetail

    Public Class CertificationDetail
        Inherits ApplicationManager.PersonifyDNNBaseForm



#Region "Controls"
        Protected CertificateXslTemplate As WebControls.XslTemplate
        Protected lblNothing As Label

        Const C_DETAILSTEMPLATES As String = "DetailsTemplates"
        Const C_REVIEWTEMPLATES As String = "ReviewTemplates"
        'Const C_EDITADDRESS_ACTION As String = "EditAdressURL"
        Const C_Apply_ACTION As String = "ApplyURL"

        Const C_PrintTranscript_ACTION As String = "PrintTranscriptURL"
        Const C_AddTranscript_ACTION As String = "AddTranscriptURL"
        Const C_Login_ACTION As String = "LoginURL"

#End Region

        Public Class Detail
            Public Description As String
            Public RequirementTypeCode As String
            Public RequirementMetCode As String
            Public Completed As String
        End Class

        Public Class Prerequisite
            Public Code As String
            Public Description As String
        End Class
        Public Class Requirement
            Public RequirementId As String
            Public Description As String
            Public minComplete As Integer
            Public Details() As Detail
            Public Prerequisites() As Prerequisite
            Public Completed As String
        End Class

        Public Class Certificate
            Public WebText As String
            Public Description As String
            Public Img As String
            Public Requirements() As Requirement
        End Class

#Region "Event Handlers"

        Public certcode As String = ""
        Public ProductId As Integer
        Public AddressId As Long


        Private Function LoginUrl() As String
            Dim aNavigateURL As String = ""
            Try
                Dim logintabid As Integer = Convert.ToInt32(Settings(C_Login_ACTION))
                If logintabid > 0 Then

                    aNavigateURL = NavigateURL(CType(Settings(C_Login_ACTION), Integer))
                    If aNavigateURL.IndexOf("?") > 0 Then
                        aNavigateURL += "&"
                    Else
                        aNavigateURL += "?"
                    End If
                    aNavigateURL = aNavigateURL + "returnurl=" + HttpUtility.UrlEncode(Request.Url.AbsoluteUri)
                End If

            Catch ex As Exception

            End Try

            Return aNavigateURL
        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If Not Settings(C_DETAILSTEMPLATES) Is Nothing Then




                        Dim mycertificate As Boolean = False

                        Dim ProductRequiredFlag As Boolean = False



                        Try
                            certcode = Convert.ToString(Request("C"))
                        Catch ex As Exception
                            'test only
                            certcode = "CERT_I"
                        End Try



                        If certcode Is Nothing Then
                            lblNothing.Visible = True
                            'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCertificate.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Else

                            Dim certdate As DateTime = DateTime.Now
                            Try
                                'Dim sd As String = Convert.ToString(Request("RD"))
                                'sd = sd.Insert(4, "/").Insert(2, "/")
                                'certdate = Convert.ToDateTime(sd)
                                certdate = Convert.ToDateTime(Request("RD"))

                                If certdate.ToString("MM/dd/yyyy") = Convert.ToString(Request("RD")) Then
                                    If Me.IsPersonifyWebUserLoggedIn Then mycertificate = True
                                End If
                            Catch ex As Exception
                                'test only
                                certdate = DateTime.Now
                            End Try



                            Dim templatefile As String = ""

                            If mycertificate = False Then
                                'templatefile = "Templates\CertificationDetails.xsl"
                                templatefile = ModulePath + "Templates\" + Settings(C_DETAILSTEMPLATES).ToString
                            Else
                                'templatefile = "Templates\CertificationReview.xsl"
                                templatefile = ModulePath + "Templates\" + Settings(C_REVIEWTEMPLATES).ToString
                            End If



                            'templatefile = ModulePath + templatefile

                            CertificateXslTemplate.XSLfile = Server.MapPath(templatefile)

                            CertificateXslTemplate.AddObject("ModuleId", ModuleId)
                            CertificateXslTemplate.AddObject("Loggedin", Me.IsPersonifyWebUserLoggedIn)

                            If Me.IsPersonifyWebUserLoggedIn Then
                                Dim oAddress As TIMSS.API.CustomerInfo.ICustomerAddressViewList
                                oAddress = GetPrimaryAddress(MasterCustomerId, SubCustomerId)

                                If oAddress IsNot Nothing AndAlso oAddress.Count > 0 AndAlso oAddress(0) IsNot Nothing Then
                                    CertificateXslTemplate.AddObject("LabelName", oAddress(0).LabelName.Replace(vbCrLf, "<br>"))
                                    CertificateXslTemplate.AddObject("FormattedAddress", oAddress(0).FormattedAddress.Replace(vbCrLf, "<br>"))
                                    AddressId = oAddress(0).CustomerAddressId
                                End If
                            End If

                            If mycertificate = False Then

                                Dim Certification As TIMSS.API.CertificationInfo.ICertification
                                Certification = GetCertificationByCode(certcode)

                                ProductRequiredFlag = Certification.ProductRequiredFlag

                                If ProductRequiredFlag = True Then
                                    ProductId = GetCertificationProductId(certcode)
                                    CertificateXslTemplate.AddObject("ProductId", ProductId)
                                End If

                                Dim aCertificate As New Certificate
                                aCertificate.WebText = Certification.WebText
                                aCertificate.Description = Certification.Description
                                aCertificate.Img = Certification.SmallImageFile

                                If Certification.Requirements IsNot Nothing AndAlso Certification.Requirements.Count > 0 Then

                                    Dim Requirements(Certification.Requirements.Count) As Requirement
                                    For i As Integer = 0 To Certification.Requirements.Count - 1
                                        Requirements(i) = New Requirement
                                        Requirements(i).minComplete = Certification.Requirements(i).NthWithinOption
                                        Requirements(i).Description = Certification.Requirements(i).Description
                                        Requirements(i).RequirementId = Certification.Requirements(i).RequirementId

                                        If Certification.Requirements(i).Details IsNot Nothing AndAlso Certification.Requirements(i).Details.Count > 0 Then
                                            Dim Details(Certification.Requirements(i).Details.Count - 1) As Detail
                                            For j As Integer = 0 To Certification.Requirements(i).Details.Count - 1
                                                Details(j) = New Detail
                                                Details(j).Description = Certification.Requirements(i).Details(j).Description
                                                Details(j).RequirementTypeCode = Certification.Requirements(i).Details(j).RequirementTypeCodeString
                                                Details(j).RequirementMetCode = Certification.Requirements(i).Details(j).RequirementMetCodeString
                                            Next
                                            Requirements(i).Details = Details
                                        End If

                                        If Certification.Requirements(i).Prerequisites IsNot Nothing AndAlso Certification.Requirements(i).Prerequisites.Count > 0 Then
                                            Dim aPrerequisites As New ArrayList
                                            For kk As Integer = 0 To Certification.Requirements(i).Prerequisites.Count - 1
                                                Dim oPrerequisites As New Prerequisite
                                                oPrerequisites.Code = Certification.Requirements(i).Prerequisites(kk).PrerequisiteRequirementId
                                                If Certification.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList IsNot Nothing AndAlso Certification.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList.Count > 0 Then
                                                    For nn As Integer = 0 To Certification.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList.Count - 1
                                                        If oPrerequisites.Code = Certification.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList(nn).Code Then
                                                            oPrerequisites.Description = Certification.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList(nn).Description
                                                        End If
                                                    Next
                                                End If
                                                aPrerequisites.Add(oPrerequisites)
                                            Next
                                            If aPrerequisites IsNot Nothing AndAlso aPrerequisites.Count > 0 Then
                                                Dim Prerequisites(aPrerequisites.Count - 1) As Prerequisite
                                                aPrerequisites.CopyTo(Prerequisites)
                                                Requirements(i).Prerequisites = Prerequisites

                                            End If
                                        End If
                                    Next
                                    aCertificate.Requirements = Requirements
                                End If

                                CertificateXslTemplate.AddObject("", aCertificate)

                            Else

                                Dim Certification As TIMSS.API.CertificationInfo.ICertificationCustomerCertification

                                Certification = GetCustomerCertificationByCode(MasterCustomerId, SubCustomerId, certcode, certdate)
                                'CertificateXslTemplate.AddObject("", Certification)
                                Dim aCertificate As New Certificate


                                If Certification IsNot Nothing Then
                                    aCertificate.WebText = Certification.CertificationInfo.WebText
                                    aCertificate.Description = Certification.CertificationInfo.Description
                                    aCertificate.Img = Certification.CertificationInfo.SmallImageFile

                                    If Certification.Requirements IsNot Nothing AndAlso Certification.Requirements.Count > 0 Then

                                        Dim Requirements(Certification.Requirements.Count) As Requirement
                                        For i As Integer = 0 To Certification.Requirements.Count - 1
                                            Requirements(i) = New Requirement
                                            Requirements(i).minComplete = Certification.Requirements(i).NthWithinOption
                                            Requirements(i).Description = Certification.Requirements(i).RequirementDescription
                                            Requirements(i).RequirementId = Certification.Requirements(i).RequirementIdString
                                            Requirements(i).Completed = Certification.Requirements(i).RequirementStatusCodeString

                                            If Certification.Requirements(i).Details IsNot Nothing AndAlso Certification.Requirements(i).Details.Count > 0 Then
                                                Dim Details(Certification.Requirements(i).Details.Count - 1) As Detail
                                                For j As Integer = 0 To Certification.Requirements(i).Details.Count - 1
                                                    Details(j) = New Detail
                                                    Details(j).Description = Certification.Requirements(i).Details(j).Description
                                                    Details(j).RequirementTypeCode = Certification.Requirements(i).Details(j).RequirementTypeCodeString
                                                    Details(j).RequirementMetCode = Certification.Requirements(i).Details(j).CRTRequirementDetailInfo.RequirementMetCodeString
                                                    Details(j).Completed = Certification.Requirements(i).Details(j).CompletedFlag.ToString
                                                Next
                                                Requirements(i).Details = Details
                                            End If

                                            If Certification.CertificationInfo.Requirements(i) IsNot Nothing AndAlso Certification.CertificationInfo.Requirements(i).Prerequisites IsNot Nothing AndAlso Certification.CertificationInfo.Requirements(i).Prerequisites.Count > 0 Then
                                                Dim aPrerequisites As New ArrayList
                                                For kk As Integer = 0 To Certification.CertificationInfo.Requirements(i).Prerequisites.Count - 1
                                                    Dim oPrerequisites As New Prerequisite
                                                    oPrerequisites.Code = Certification.CertificationInfo.Requirements(i).Prerequisites(kk).PrerequisiteRequirementId
                                                    If Certification.CertificationInfo.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList IsNot Nothing AndAlso Certification.CertificationInfo.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList.Count > 0 Then
                                                        For nn As Integer = 0 To Certification.CertificationInfo.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList.Count - 1
                                                            If oPrerequisites.Code = Certification.CertificationInfo.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList(nn).Code Then
                                                                oPrerequisites.Description = Certification.CertificationInfo.Requirements(i).Prerequisites(kk).PrerequisiteRequirementList(nn).Description
                                                            End If
                                                        Next
                                                    End If
                                                    aPrerequisites.Add(oPrerequisites)
                                                Next
                                                If aPrerequisites IsNot Nothing AndAlso aPrerequisites.Count > 0 Then
                                                    Dim Prerequisites(aPrerequisites.Count - 1) As Prerequisite
                                                    aPrerequisites.CopyTo(Prerequisites)
                                                    Requirements(i).Prerequisites = Prerequisites

                                                End If
                                            End If

                                        Next
                                        aCertificate.Requirements = Requirements
                                    End If

                                End If


                                CertificateXslTemplate.AddObject("", aCertificate)

                            End If
                            CertificateXslTemplate.Display()

                            If Me.IsPersonifyWebUserLoggedIn Then

                                'just create the certification
                                Dim tempControl As Control
                                tempControl = Me.FindControl("EditButton" + ModuleId.ToString)
                                If (tempControl IsNot Nothing) Then
                                    Dim tempEditButton As LinkButton = CType(tempControl, LinkButton)
                                    tempEditButton.Visible = True
                                    'tempEditButton.PostBackUrl = NavigateURL(CType(Settings(C_EDITADDRESS_ACTION), Integer)) & "?CHANGEADDRESSTYPE=BILL"
                                    'tempEditButton.PostBackUrl = EditSetting_ChangeBillShipAddressURL + "&CHANGEADDRESSTYPE=BILL"
                                    ' update moduleControls set moduledefid=null where contrlKey = 'ADDADDRESS'
                                    tempEditButton.PostBackUrl = NavigateURL(TabId, "ADDADDRESS", "MODE=EDIT", "CustomerAddressId=" & AddressId)
                                End If
                            End If

                            If ProductRequiredFlag = True Then
                                If ProductId > 0 Then
                                    'add to shopping cart
                                    Dim aProductDetails As ProductDetails
                                    aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(ProductId, False, False, True, True, , , Me.IsPersonifyWebUserLoggedIn, MasterCustomerId, SubCustomerId, True, True)

                                    Dim aPricingControl As New WebControls.PricingControl

                                    aPricingControl.ID = "PricingControl" + ModuleId.ToString
                                    aPricingControl.PortalID = PortalId

                                    Dim CanPurchaseMemberOnlyProducts As Boolean = False

                                    'add to cart button for member only products ?
                                    If UserInfo.Profile.ProfileProperties("CanPurchaseMemberOnlyProducts") IsNot Nothing AndAlso Not String.IsNullOrEmpty(UserInfo.Profile.ProfileProperties("CanPurchaseMemberOnlyProducts").ToString) Then
                                        If Convert.ToBoolean(UserInfo.Profile.GetPropertyValue("CanPurchaseMemberOnlyProducts")) = True Then
                                            CanPurchaseMemberOnlyProducts = True
                                        End If
                                    End If

                                    aPricingControl.IsMember = CanPurchaseMemberOnlyProducts
                                    aPricingControl.AllPrices = aProductDetails.AllPrices
                                    'ANMC 
                                    aPricingControl.PortalCurrency = PortalCurrency
                                    aPricingControl.ListPrices = aProductDetails.ListPrices
                                    aPricingControl.MemberPrices = aProductDetails.MemberPrices
                                    aPricingControl.YourPrices = aProductDetails.CustomerPrice

                                    aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)

                                    If Settings("DisplayRateCodeSettingsKey_" + aProductDetails.ProductInfo.Item(0).Subsystem.ToUpper) IsNot Nothing Then
                                        aPricingControl.ShowRateCode = True
                                    End If

                                    If Me.IsPersonifyWebUserLoggedIn Then
                                        aPricingControl.IsMember = True
                                    Else
                                        aPricingControl.IsMember = False
                                    End If

                                    Dim tempPlaceHolder As New PlaceHolder

                                    tempPlaceHolder = CType(Me.FindControl("PricingPlaceHolder" + ModuleId.ToString), PlaceHolder)
                                    If (tempPlaceHolder IsNot Nothing) Then
                                        tempPlaceHolder.Controls.Add(aPricingControl)
                                    End If


                                    Dim aAddToCartControl As New WebControls.AddToCartControl

                                    aAddToCartControl.ID = "AddToCartControl" + ModuleId.ToString

                                    aAddToCartControl.Visible = False 'from settings


                                    'If _
                                    'Convert.ToInt32(Settings("AddToCart")) = 1 _
                                    'Or Convert.ToInt32(Settings("AddToWishList")) = 1 _
                                    'Or Convert.ToInt32(Settings("BuyForGroup")) = 1 _
                                    'Then

                                    aAddToCartControl.Visible = True

                                    'If Convert.ToInt32(Settings("AddToCart")) = 1 Then
                                    aAddToCartControl.VisibleAddToCart = True
                                    'Else
                                    '    aAddToCartControl.VisibleAddToCart = False
                                    'End If

                                    'If Convert.ToInt32(Settings("AddToWishList")) = 1 Then
                                    '    aAddToCartControl.VisibleWishList = True
                                    'Else
                                    aAddToCartControl.VisibleWishList = False
                                    'End If

                                    aAddToCartControl.VisibleBuyForGroup = False


                                    'If Convert.ToInt32(Settings("BuyForGroup")) = 1 Then

                                    '    Dim lg As New Personify.WebUtility.LoginCustomer
                                    '    lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

                                    '    Dim MasterCustomerId As String = lg.MasterCustomerId
                                    '    Dim SubCustomerId As Integer = lg.SubCustomerId

                                    '    'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                                    '    'Dim MasterCustomerId As String = ApplicationManager.Customer.GetAnonymousUserId(lg.MasterCustomerId)
                                    '    'Dim SubCustomerId As Integer = 0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)

                                    '    If (ApplicationManager.AffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                    '        aAddToCartControl.VisibleBuyForGroup = True
                                    '    End If
                                    'End If

                                    'If Settings("DefaultQuantity") IsNot Nothing Then
                                    '    aAddToCartControl.Quantity = CType(Settings("DefaultQuantity"), Integer)
                                    'Else
                                    aAddToCartControl.Quantity = 1
                                    'End If
                                    'Select Case Subsystem
                                    '    Case "INV", "MISC", "SUB"
                                    '        aAddToCartControl.VisibleQuantity = True
                                    '    Case "MTG"
                                    '        If AllProducts(x).MaxBadges >= 1 Then
                                    '            aAddToCartControl.VisibleQuantity = True
                                    '        Else
                                    '            aAddToCartControl.VisibleQuantity = False
                                    '        End If
                                    '    Case Else
                                    aAddToCartControl.VisibleQuantity = False
                                    'End Select


                                    aAddToCartControl.ProductId = ProductId
                                    aAddToCartControl.Text = Localization.GetString("AddToCart.Text", LocalResourceFile)
                                    aAddToCartControl.WishListText = Localization.GetString("AddToWishList.Text", LocalResourceFile)
                                    aAddToCartControl.BuyForGroupText = Localization.GetString("BuyForGroup.Text", LocalResourceFile)
                                    aAddToCartControl.ButtonCss = "btna"

                                    aAddToCartControl.ButtonMode = WebControls.AddToCartControl.EnumButtonMode.Image

                                    '3246-5774803
                                    aAddToCartControl.ImageURL = GetAddToCartImageURL() 'ModulePath & "images/btn_addtocart.gif"
                                    aAddToCartControl.WishListImageURL = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                                    aAddToCartControl.BuyForGroupImageURL = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                                    'end 3246-5774803

                                    AddHandler aAddToCartControl.ButtonClick, AddressOf AddToCartButton_Click
                                    'AddHandler aAddToCartControl.WishListButtonClick, AddressOf AddToWishListControl_ButtonClick

                                    tempPlaceHolder = CType(Me.FindControl("AddToCartPlaceHolder" + ModuleId.ToString), PlaceHolder)
                                    If (tempPlaceHolder IsNot Nothing) Then
                                        tempPlaceHolder.Controls.Add(aAddToCartControl)
                                    End If

                                End If

                                'End If

                            Else


                                'just create the certification
                                Dim tempControl As Control
                                tempControl = Me.FindControl("SubmitButton" + ModuleId.ToString)
                                If (tempControl IsNot Nothing) Then
                                    Dim tempSaveButton As LinkButton = CType(tempControl, LinkButton)
                                    If Me.IsPersonifyWebUserLoggedIn = True Then
                                        tempSaveButton.Visible = True
                                        AddHandler tempSaveButton.Click, AddressOf CreateButton_Click
                                    Else
                                        Dim url As String = LoginUrl()
                                        If url.Length > 0 Then
                                            Response.Redirect(url)
                                        Else
                                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoLogin.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                                        End If
                                    End If
                                End If
                            End If
                        End If

                        Dim hypRegister As HyperLink
                        hypRegister = CType(Me.FindControl("hypRegister" + ModuleId.ToString), HyperLink)
                        If hypRegister IsNot Nothing Then
                            Dim aNavigateURL As String = NavigateURL(CType(Settings(C_Apply_ACTION), Integer))
                            If aNavigateURL.IndexOf("?") > 0 Then
                                aNavigateURL += "&"
                            Else
                                aNavigateURL += "?"
                            End If
                            hypRegister.NavigateUrl = aNavigateURL + "C=" + certcode
                        End If

                        Dim hypPrintTranscript As HyperLink
                        hypPrintTranscript = CType(Me.FindControl("hypPrintTranscript" + ModuleId.ToString), HyperLink)
                        If hypPrintTranscript IsNot Nothing Then
                            Dim aNavigateURL As String = NavigateURL(CType(Settings(C_PrintTranscript_ACTION), Integer))
                            If aNavigateURL.IndexOf("?") > 0 Then
                                aNavigateURL += "&"
                            Else
                                aNavigateURL += "?"
                            End If
                            hypPrintTranscript.NavigateUrl = aNavigateURL + "C=" + certcode
                        End If


                        Dim hypAddTranscript As HyperLink
                        hypAddTranscript = CType(Me.FindControl("hypAddTranscript" + ModuleId.ToString), HyperLink)
                        If hypAddTranscript IsNot Nothing Then
                            Dim aNavigateURL As String = NavigateURL(CType(Settings(C_AddTranscript_ACTION), Integer))
                            If aNavigateURL.IndexOf("?") > 0 Then
                                aNavigateURL += "&"
                            Else
                                aNavigateURL += "?"
                            End If
                            hypAddTranscript.NavigateUrl = aNavigateURL + "C=" + certcode
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    End If
                Else
                    DisplayUserAccessMessage(role)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub CreateButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)
            If certcode IsNot Nothing Then

                Dim Certifications As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications
                Certifications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CertificationInfo, "CertificationCustomerCertifications")

                With Certifications.AddNew
                    .MasterCustomerId = MasterCustomerId
                    .SubCustomerId = SubCustomerId
                    .CertificationCode.Code = certcode
                    .RegistrationDate = DateTime.Now
                    .ApplicationDate = DateTime.Now ' what's the difference ?
                End With

                Certifications = AddUpdateCertification(Certifications(0))

                If Certifications.ValidationIssues IsNot Nothing AndAlso Certifications.ValidationIssues.Count > 0 Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Certifications.ValidationIssues(0).Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Thankyou.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Error.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If

        End Sub

        Private Sub AddToCartButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)

            If certcode IsNot Nothing Then
                'Dim ProductId As Integer


                Dim tempPricingControl As WebControls.PricingControl

                tempPricingControl = CType(Me.FindControl("PricingControl" + ModuleId.ToString), WebControls.PricingControl)

                Dim aProductDetails As ProductDetails
                aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(ProductId, False, False, True, True, , , Me.IsPersonifyWebUserLoggedIn, MasterCustomerId, SubCustomerId, True, True)

                Dim aPrice As Decimal = Convert.ToDecimal(Request("PricingControl" + ModuleId.ToString + "_price"))
                Dim aRateCode As String = Convert.ToString(Request("PricingControl" + ModuleId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("PricingControl" + ModuleId.ToString + "_rs"))

                ' add upsell product
                AddToCart(MasterCustomerId, SubCustomerId, ProductId, 0, aProductDetails, 1, aRateCode, aRateStructure, aPrice, False) ' isWishList

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AddedToCard.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Error.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If

        End Sub

        Private Sub AddToCart( _
 ByVal MasterCustomerId As String, _
 ByVal SubCustomerId As Integer, _
  ByVal ProductID As Integer, _
  ByVal SubProductId As Integer, _
  ByVal ProductDetails As ProductDetails, _
  ByVal Quantity As Integer, _
  ByVal RateCode As String, _
  ByVal RateStructure As String, _
  ByVal Price As Decimal, _
 ByVal isWishList As Boolean _
 )
            'ByVal RateStructure As String, _			'ByVal RateCode As String _
            Try

                Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                Dim oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
                With oCartInfo
                    .Subsystem = ProductDetails.ProductInfo(0).Subsystem
                    .ProductType = ProductDetails.ProductInfo(0).ProductTypeCodeString
                    .RateStructure = RateStructure
                    .RateCode = RateCode

                    .MasterCustomerId = MasterCustomerId 'ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                    .SubCustomerId = SubCustomerId '0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)

                    .LongName = ProductDetails.ProductInfo(0).LongName
                    .ShortName = ProductDetails.ProductInfo(0).ShortName
                    .Price = Price
                    .Quantity = Quantity
                    .ProductId = ProductID
                    .SubProductId = SubProductId 'not 0
                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .MaxBadges = 0
                    .IsWishList = isWishList
                    .ShipMasterCustomerId = Nothing
                    .ShipSubCustomerId = 0

                    If ProductDetails.ListPrices IsNot Nothing Then
                        If ProductDetails.ListPrices.Count > 0 Then
                            For i As Integer = 0 To ProductDetails.ListPrices.Count - 1
                                If ProductDetails.ListPrices(i).RateStructure = .RateStructure And ProductDetails.ListPrices(i).RateCode = .RateCode Then
                                    .MaxBadges = ProductDetails.ListPrices(i).MaxBadges
                                End If
                            Next
                        End If
                    End If

                    If ProductDetails.MemberPrices IsNot Nothing Then
                        If ProductDetails.MemberPrices.Count > 0 Then
                            For i As Integer = 0 To ProductDetails.MemberPrices.Count - 1
                                If ProductDetails.MemberPrices(i).RateStructure = .RateStructure And ProductDetails.MemberPrices(i).RateCode = .RateCode Then
                                    .MaxBadges = ProductDetails.ListPrices(i).MaxBadges
                                End If
                            Next
                        End If
                    End If

                End With
                oCartController.AddToCart(oCartInfo)
                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region
#Region "Images Functions"

        '3246-5774803
        Private Function GetAddToCartImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_addtocart.gif")
        End Function
        Private Function GetWishListImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_wishlist.gif")
        End Function
        Private Function GetBuyForGroupImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_buyforgroup.gif")
        End Function
        'END 3246-5774803
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Personify Get DAta:"
        Private Function GetPrimaryAddress(ByVal MCID As String, ByVal SCID As Integer) As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            Dim oAddress As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            oAddress = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")

            oAddress.Filter.Add("MasterCustomerId", MCID)
            oAddress.Filter.Add("SubCustomerId", SCID)
            oAddress.Filter.Add("PrioritySeq", 0)
            oAddress.Fill()

            Return oAddress

        End Function

        Private Function GetCertificationByCode(ByVal CertificationCode As String) As TIMSS.API.CertificationInfo.ICertification

            Dim oCertifications As TIMSS.API.CertificationInfo.ICertifications

            oCertifications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CertificationInfo, "Certifications")
            oCertifications.Filter.Add("Certification_Code", TIMSS.Enumerations.QueryOperatorEnum.Equals, CertificationCode)

            oCertifications.Fill()
            Return oCertifications(0)

        End Function

        Private Function GetCertificationProductId(ByVal certification_code As String) As Integer

            Dim oProducts As TIMSS.API.ProductInfo.IProducts



            oProducts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")
            oProducts.Filter.Add("Product_code", certification_code)
            oProducts.Fill()
            If oProducts(0) IsNot Nothing Then
                Return oProducts(0).ProductId
            End If

            Return Nothing
        End Function

        Private Function GetCustomerCertificationByCode(ByVal MCID As String, ByVal SCID As Integer, ByVal CertificationCode As String, ByVal RegistrationDate As DateTime) As TIMSS.API.CertificationInfo.ICertificationCustomerCertification

            Dim oCertifications As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications


            oCertifications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CertificationInfo, "CertificationCustomerCertifications")
            oCertifications.Filter.Add("MasterCustomerID", MCID)
            oCertifications.Filter.Add("SubCustomerID", SCID)
            oCertifications.Filter.Add("Certification_Code", TIMSS.Enumerations.QueryOperatorEnum.Equals, CertificationCode)
            oCertifications.Filter.Add("Registration_Date", TIMSS.Enumerations.QueryOperatorEnum.Equals, RegistrationDate)
            oCertifications.Fill()
            Return oCertifications(0)

        End Function

        Private Function AddUpdateCertification(ByVal CertificationCustomerCertification As TIMSS.API.CertificationInfo.ICertificationCustomerCertification) As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications

            Dim oCertifications As TIMSS.API.CertificationInfo.ICertificationCustomerCertifications

         
            oCertifications = Me.PErsonifyGetCollection( TIMSS.Enumerations.NamespaceEnum.CertificationInfo, "CertificationCustomerCertifications")

            oCertifications.Add(CertificationCustomerCertification)

            oCertifications.Save()

            Return oCertifications

        End Function


#End Region
    End Class

End Namespace
