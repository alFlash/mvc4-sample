Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.OrderCreate.Business

Namespace Personify.DNN.Modules.OrderCreate

    Public MustInherit Class OrderCreateEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings
#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents cboSelectTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ctlNextPageURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlGoToShoppingCartURL As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents chkAutoSkipToNextPage As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkSamePageCheckOut As System.Web.UI.WebControls.CheckBox
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then
                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")

                    'Load Templates
                    If Not cboSelectTemplate.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            cboSelectTemplate.Items.Add(li)
                        Next
                        cboSelectTemplate.SelectedIndex = cboSelectTemplate.Items.IndexOf(cboSelectTemplate.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.TemplateName))))
                    End If

                    'NextPageURL

                    ctlNextPageURL.UrlType = "T"
                    If Not Settings(ModuleSettingsNames.NextPageURL) Is Nothing Then
                        ctlNextPageURL.Url = CType(Settings(ModuleSettingsNames.NextPageURL), String)
                    End If


                    'GoTo Shopping Cart URL

                    ctlGoToShoppingCartURL.UrlType = "T"
                    If Not Settings(ModuleSettingsNames.GoToShoppingCartURL) Is Nothing Then
                        ctlGoToShoppingCartURL.Url = CType(Settings(ModuleSettingsNames.GoToShoppingCartURL), String)
                    End If


                    'Auto Skip To Next Page
                    If CStr(Settings(ModuleSettingsNames.AutoSkipToNextPage)) = "Y" Then
                        chkAutoSkipToNextPage.Checked = True
                    Else
                        chkAutoSkipToNextPage.Checked = False
                    End If

                    'Same Page Cgecjout
                    If CStr(Settings(ModuleSettingsNames.SamePageCheckoutEnabled)) = "Y" Then
                        chkSamePageCheckOut.Checked = True
                    Else
                        chkSamePageCheckOut.Checked = False
                    End If


                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem

                ' Create a reference to the current directory.
                Dim dInfo As New System.IO.DirectoryInfo(Me.MapPathSecure((ModulePath & ModuleSettingsNames.C_TEMPLATEFOLDERNAME)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As System.IO.FileInfo() = dInfo.GetFiles(ModuleSettingsNames.C_FILEPATTERN)
                Dim fiTemp As System.IO.FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                '' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    Dim objPersonify As New OrderCreateinfo
                    Dim objModules As New Entities.Modules.ModuleController
                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

                    'Update Select Template
                    UpdateModuleSetting(ModuleSettingsNames.TemplateName, cboSelectTemplate.SelectedValue)

                    'Update Next Page URL
                    UpdateModuleSetting( ModuleSettingsNames.NextPageURLType, ctlNextPageURL.UrlType)
                    UpdateModuleSetting( ModuleSettingsNames.NextPageURL, ctlNextPageURL.Url)

                    'Update Go To Shopping Cart URL
                    UpdateModuleSetting(ModuleSettingsNames.GoToShoppingCartURLType, ctlGoToShoppingCartURL.UrlType)
                    UpdateModuleSetting(ModuleSettingsNames.GoToShoppingCartURL, ctlGoToShoppingCartURL.Url)
                   

                    'Update Auto Skip
                   UpdateModuleSetting( ModuleSettingsNames.AutoSkipToNextPage, CStr(IIf(chkAutoSkipToNextPage.Checked, "Y", "N")))

                    'Update Same Page Checkout
                   UpdateModuleSetting( ModuleSettingsNames.SamePageCheckoutEnabled, CStr(IIf(chkSamePageCheckOut.Checked, "Y", "N")))
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                'If Not Null.IsNull(itemId) Then
                '    Dim objCtlPersonify.OrderCreate As New Personify.OrderCreateController
                '    objCtlPersonify.OrderCreate.Delete(itemId)
                'End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
