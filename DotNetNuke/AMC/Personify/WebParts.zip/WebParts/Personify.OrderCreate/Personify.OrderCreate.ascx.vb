Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Collections.Generic

Imports Personify.DNN.Modules.OrderCreate
Imports Personify.ShoppingCartManager.Business
Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PersonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports TIMSS.API.Core

Namespace Personify.DNN.Modules.OrderCreate

    Public MustInherit Class OrderCreate
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable
        Implements Entities.Modules.Communications.IModuleCommunicator
        Implements Entities.Modules.Communications.IModuleListener


#Region "Controls"

        Protected OrderCreateTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents btnContinue As System.Web.UI.WebControls.Button
        Protected WithEvents lblErrorMessage As Label
#End Region


#Region "Private Variables"
        Private _IssueParentGuidHash As Hashtable 'Indicate which questions/answers are missing
        Private UpdateOrder As Boolean
        '3246-7346214 
        Private _ShoppingCartList As ArrayList

#End Region

#Region "Event Handlers"
        Private Sub SetCustomerId()



            If Me.IsPersonifyWebUserLoggedIn = False Then
                'The current user does not have these attributes
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                btnContinue.Visible = False
                Exit Sub
            End If


        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)

                If role = "personifyuser" Or role = "personifyadmin" Then
                    'Sample code to get data
                    'Dim objPersonify.OrderCreate As New Personify.OrderCreateController
                    'Dim list As ArrayList

                    'If Not Page.IsPostBack Then
                    '    list = objPersonify.OrderCreate.GetByModules(ModuleId)
                    'End If

                    SetCustomerId()


                    'AN TODO - Remove the test code from here
                    'add seesions
                    If String.Compare(Request.QueryString("MODE"), "EDITORDER", True) = 0 Then
                        UpdateOrder = True
                    Else
                        UpdateOrder = False
                    End If
                    'END add seesions

                    If IsPostBack Then

                        If CheckIfPostbackByButton("btnContinue") Then
                            MYRespondToValidationIssues()
                        End If


                    End If
                    LoadOrderCreateTemplate()
                    CodeForGoToCart()
                    'Add handler for radio buttons
                Else
                    btnContinue.Visible = False

                    DisplayUserAccessMessage(role)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try


        End Sub


        Private Sub CodeForGoToCart()
            Dim oControl As System.Web.UI.WebControls.HyperLink

            Dim strcontrolName As String = "btnGoToCart"
            If Not Me.FindControl(strcontrolName) Is Nothing Then

                oControl = CType(Me.FindControl(strcontrolName), System.Web.UI.WebControls.HyperLink)
                oControl.NavigateUrl = EditSetting_GoToShoppingCartURLURL
                'oControl.NavigateUrl = EditSetting_AdvanceShippingURL
            End If

        End Sub
        Private Function CheckIfPostbackByButton(ByVal ButtonName As String) As Boolean

            'Dim strControlName As String = "btnUpdateCart_" + ModuleId.ToString

            'strControlName = ButtonName + "_" + ModuleId.ToString
            Dim bReturn As Boolean = False

            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(ButtonName) > 0 Then
                    bReturn = True
                    Exit For
                End If

            Next

            Return bReturn

        End Function
        Private Function GetOrderFromSessionObject() As TIMSS.API.OrderInfo.IOrderMasters

            'TODO -- Comment the following

            If Not GetSessionObject(SessionKeys.PersonifyOrder) Is Nothing Then
                Return CType(GetSessionObject(SessionKeys.PersonifyOrder), TIMSS.API.OrderInfo.IOrderMasters)
            Else
                Return CType(GetSessionObject(SessionKeys.PersonifyOrder), TIMSS.API.OrderInfo.IOrderMasters)

                Return Nothing
            End If

        End Function

        '3246-7346214
        Private Function GetCartItemMapFromSessionObject() As Hashtable
            If SessionManager.GetSessionObject(PortalId, SessionKeys.PersonifyCartItemMap) IsNot Nothing Then
                Return CType(SessionManager.GetSessionObject(PortalId, SessionKeys.PersonifyCartItemMap), Hashtable)
            End If
            Return Nothing
        End Function

        Private Sub LoadOrderCreateTemplate()
            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters
            Dim strCurrency As String
            Dim bRenewalError As Boolean

            Try



                OrderCreateTemplate.Visible = True
                OrderCreateTemplate.XSLfile = Server.MapPath(EditSetting_TemplateFile)

                '3246-5774803
                Dim SubordinateArrowImageURL As String = GetSubordinateArrowImageURL()
                OrderCreateTemplate.AddObject("SubordinateArrowImageURL", SubordinateArrowImageURL)

                Dim QuestionImageURL As String = GetQuestionImageURL()
                OrderCreateTemplate.AddObject("QuestionImageURL", QuestionImageURL)

                Dim InfoImageURL As String = GetInfoImageURL()
                OrderCreateTemplate.AddObject("InfoImageURL", InfoImageURL)

                Dim ErrorImageURL As String = GetErrorImageURL()
                OrderCreateTemplate.AddObject("ErrorImageURL", ErrorImageURL)

                Dim WarningImageURL As String = GetWarningImageURL()
                OrderCreateTemplate.AddObject("WarningImageURL", WarningImageURL)

                'end 3246-5774803


                'If Not IsPostBack Then
                '    CreateOrder()
                'End If

                ' oOM = GetOrderFromSessionObject()
                If Not IsPostBack Then

                    If String.Compare(Request.QueryString("MODE"), "EDITORDER", True) = 0 Then
                        Dim strOrderNumber As String = Request("ORDERNUMBER")
                        Dim strOrderLineNumber As String = Request("ORDERLINENUMBER")
                        Dim strProductID As String = Request("PRODUCTID")
                        If strOrderNumber.Length > 0 AndAlso strOrderLineNumber.Length > 0 AndAlso strProductID.Length > 0 Then
                            AddToExistingOrder(strOrderNumber, strOrderLineNumber, strProductID)
                        End If

                    ElseIf EditSetting_SamePageCheckoutEnabled = False Then
                        If Request("AGENDAMEETINGID") IsNot Nothing Then
                            CreateOrderFromMyAgenda()
                        Else
                            'AN - MBR Renewal Process - if the order is created from membership renewal then get items from sc with order number

                            If String.Compare(Request.QueryString("MODE"), "MBRRENEWAL", True) = 0 Then
                                bRenewalError = CreateMBRRenewalOrderFromShoppingCart()
                            Else
                                CreateOrderFromShoppingCart()
                            End If


                        End If
                    End If
                End If


                oOM = GetOrderFromSessionObject()

                Dim args As New DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs


                If oOM Is Nothing Then

                    If bRenewalError = True Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("CannotCreateRenewal", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                    ElseIf EditSetting_SamePageCheckoutEnabled = False Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderForCheckOut", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                    End If
                    btnContinue.Visible = False
                    Exit Sub
                Else
                    'If the order does not have any validation issues, and the AutoSkip to next page setting is true then do not load the template. Just skip to the next page
                    If EditSetting_SamePageCheckoutEnabled = False Then
                        btnContinue.Visible = True
                    Else
                        btnContinue.Visible = False
                    End If


                    'RaiseEvent ModuleCommunication("", Nothing)
                    If oOM(0).Details.Count = 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderForCheckOut", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        btnContinue.Visible = False
                        Exit Sub
                    End If

                    If oOM.ValidationIssues.ErrorCount = 0 AndAlso EditSetting_AutoSkipToNextPage = True Then '3246-5727428
                        'add seesions
                        If UpdateOrder Then
                            Dim ids As New ArrayList()
                            ids.Add(oOM(0).OrderNumber)
                            SessionManager.ClearSessionObject(PortalId, SessionKeys.PersonifyPayOrderIds)
                            SessionManager.AddSessionObject(PortalId, SessionKeys.PersonifyPayOrderIds, ids)
                        End If
                        'END add seesions
                        GoToNextPage()
                        Exit Sub
                    End If


                    'Modified the message in order to provide a better view where user can clearly see missing anwsers
                    'Start
                    Dim frontStyleMessage As String = "<font color='red'><b>"
                    Dim endStyleMessage As String = "</b></font>"
                    If IsPostBack AndAlso CheckIfPostbackByButton("btnContinue") Then
                        For Each oIssue As TIMSS.API.Core.Validation.IIssue In oOM(0).ValidationIssues
                            If Me._IssueParentGuidHash.Contains(oIssue.ParentGuid) Then
                                oIssue.Message = frontStyleMessage & oIssue.Message & endStyleMessage
                            End If
                        Next
                    End If
                    'End

                    Dim oOD As TIMSS.API.OrderInfo.IOrderDetails
                    oOD = oOM(0).Details
                    OrderCreateTemplate.AddObject("", oOM)
                    OrderCreateTemplate.AddObject("", oOD)

                    strCurrency = Me.PortalCurrency.Symbol
                    OrderCreateTemplate.AddObject("CurrencySymbol", strCurrency)
                    OrderCreateTemplate.Display()
                End If





            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Edit Setting Properties"

        Private ReadOnly Property EditSetting_TemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.TemplateName), String)

                If strFileName Is Nothing OrElse strFileName.Length = 0 Then
                    strFileName = "OrderCreate.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property

        Private ReadOnly Property EditSetting_NextPageURL() As String
            Get
                Dim strNextPAgeURL As String = ""
                If CType(Settings(ModuleSettingsNames.NextPageURL), String).Length > 0 Then
                    strNextPAgeURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.NextPageURL), String)


                End If
                Return strNextPAgeURL
            End Get
        End Property
        Private ReadOnly Property EditSetting_GoToShoppingCartURLURL() As String
            Get
                Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.GoToShoppingCartURL), String)

            End Get
        End Property
        Private ReadOnly Property EditSetting_AutoSkipToNextPage() As Boolean
            Get
                Try
                    If CType(Settings(ModuleSettingsNames.AutoSkipToNextPage), String) = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    Return False
                End Try
            End Get
        End Property

        Private ReadOnly Property EditSetting_SamePageCheckoutEnabled() As Boolean
            Get
                Try
                    If CType(Settings(ModuleSettingsNames.SamePageCheckoutEnabled), String) = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    Return False
                End Try
            End Get
        End Property

#End Region


#Region "Corder Creation"

        Public Function GetMyAgendaItems(ByVal ProductId As Integer, ByVal MCID As String, ByVal SCID As Integer) As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

            Dim oAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
            oAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")

            With oAgendas
                .Filter.Add("MasterCustomerId", MCID)
                .Filter.Add("SubCustomerId'", SCID)
                .Filter.Add("MeetingProductId", ProductId)
                .Fill()
            End With

            Return oAgendas

        End Function

        Private Function CreateOrderParameterLine(ByVal CartId As Integer, ByVal ProductId As Long, ByVal RelatedCartId As Integer, Optional ByVal SubProductId As Integer = -1) As OrderEntryParameters
            Dim oParam As New OrderEntryParameters

            With oParam
                .CartItemId = CartId
                .RelatedCartItemId = RelatedCartId
                .ProductId = ProductId
                .MasterCustomerId = MasterCustomerId
                .SubCustomerId = SubCustomerId
                .ShipMasterCustomerId = MasterCustomerId
                .ShipSubCustomerId = SubCustomerId
                If SubProductId > 0 Then
                    oParam.SubProductId = SubProductId
                End If
            End With

            Return oParam
        End Function

        Private Sub CreateOrderFromMyAgenda()

            Dim oMyAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
            Dim PID As Integer
            Dim oParams As System.Collections.Generic.List(Of OrderEntryParameters)
            Dim oParam As OrderEntryParameters


            PID = Request("AGENDAMEETINGID")
            oParams = New System.Collections.Generic.List(Of OrderEntryParameters)
            oMyAgendas = GetMyAgendaItems(PID, MasterCustomerId, SubCustomerId)

            oParam = CreateOrderParameterLine(999, PID, 0) 'hack use 999 as the cart item 
            oParams.Add(oParam)

            For agendaCounter As Integer = 0 To oMyAgendas.Count - 1
                Dim oMyAgenda As TIMSS.API.CustomerInfo.ICustomerMeetingAgenda
                oMyAgenda = oMyAgendas(agendaCounter)

                If oMyAgenda.AvailableToOrders AndAlso oMyAgenda.AppointmentTypeCodeString = "MEETING" Then
                    'Add sessions / subproducts
                    oParam = CreateOrderParameterLine(oMyAgenda.AppointmentId, oMyAgenda.MeetingProductId, 999, oMyAgenda.SessionProductId)
                    oParams.Add(oParam)
                End If
            Next


            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters = Nothing
            oOrderMasters = get_clsOrderCheckOutProcessHelper.CreateOrders(MasterCustomerId, SubCustomerId, oParams.ToArray)

            AddSessionObject(SessionKeys.PersonifyOrder, oOrderMasters)

        End Sub

        Private Function ReturnSelectedProductClass(ByVal strOrderNo As String) As TIMSS.API.Base.WebInfo.SelectedProduct()
            Dim oManager As New ShoppingCartController

            Dim AList As ArrayList
            AList = oManager.GetShoppingCartForMembershipRenewalOrder(MasterCustomerId, SubCustomerId, strOrderNo, Me.PortalId)

            Dim intIndex As Integer = 0
            Dim oSelectedProducts(intIndex) As TIMSS.API.Base.WebInfo.SelectedProduct

            'Form the helper class .. master products first
            For i As Integer = 0 To AList.Count - 1
                If CType(AList(i), ShoppingCartInfo).RelatedCartItemId = 0 Then
                    If intIndex > 0 Then
                        ReDim Preserve oSelectedProducts(intIndex)
                    End If
                    oSelectedProducts(intIndex) = New TIMSS.API.Base.WebInfo.SelectedProduct

                    oSelectedProducts(intIndex).MainProduct = ReturnclsProdDetail(CType(AList(i), ShoppingCartInfo).OrderNo, CType(AList(i), ShoppingCartInfo).OrderLineNo, CType(AList(i), ShoppingCartInfo).ProductId, CType(AList(i), ShoppingCartInfo).RateStructure, CType(AList(i), ShoppingCartInfo).RateCode)

                    oSelectedProducts(intIndex).SubProducts = ReturnclsSubProducts(CType(AList(i), ShoppingCartInfo).CartItemId, AList)

                    intIndex = intIndex + 1
                End If
            Next

            Return oSelectedProducts
        End Function

        Private Function CreateMBRRenewalOrderFromShoppingCart() As Boolean
            'Dim oSelectedProducts() As TIMSS.API.Base.WebInfo.SelectedProduct
            Dim oSelectedProducts() As TIMSS.API.Base.WebInfo.SelectedProduct
            Dim strOrderNo As String = String.Empty
            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters = Nothing
            Dim oMBROrderViewList As TIMSS.API.WebInfo.IWebMembershipRenewalOrderViewList
            strOrderNo = Request.QueryString("ORDERNO")

            If Not String.IsNullOrEmpty(strOrderNo) Then
                If String.Compare(Request.QueryString("CHANGED"), "Y", True) = 0 Then
                    oSelectedProducts = ReturnSelectedProductClass(strOrderNo)
                    oMBROrderViewList = TIMSS.Global.GetCollection(Me.OrganizationId, Me.OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebMembershipRenewalOrderViewList")
                    oMBROrderViewList.Filter.Add("OrderNumber", strOrderNo)
                    oMBROrderViewList.Fill()
                    If oMBROrderViewList.Count > 0 Then
                        oOrderMasters = oMBROrderViewList(0).ChangeOrder(oSelectedProducts)
                    End If
                Else
                    oOrderMasters = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderMasters")
                    oOrderMasters.Fill(strOrderNo)
                End If
            End If

            'TODO - Remove this code
            'test code - create order and make payment with no changes
            Dim bError As Boolean

            If oOrderMasters.ValidationIssues.Count > 0 Then
                For i As Integer = 0 To oOrderMasters.ValidationIssues.Count - 1
                    If oOrderMasters.ValidationIssues(i).Severity = Validation.IssueSeverityEnum.Error Then

                        bError = True
                        Exit For
                    End If
                Next
            End If

            If bError = False Then
                AddSessionObject(SessionKeys.PersonifyOrder, oOrderMasters)
            End If

            Return bError
        End Function

        Private Function ReturnclsSubProducts(ByVal CartItemId As Integer, ByVal pList As ArrayList) As List(Of TIMSS.API.Base.WebInfo.ProductDetails)
            Dim oRet As New List(Of TIMSS.API.Base.WebInfo.ProductDetails)
            For j As Integer = 0 To pList.Count - 1
                If CType(pList(j), ShoppingCartInfo).RelatedCartItemId = CartItemId Then
                    Dim oPD As New TIMSS.API.Base.WebInfo.ProductDetails
                    oPD = ReturnclsProdDetail(CType(pList(j), ShoppingCartInfo).OrderNo, CType(pList(j), ShoppingCartInfo).OrderLineNo, CType(pList(j), ShoppingCartInfo).SubProductId, CType(pList(j), ShoppingCartInfo).RateStructure, CType(pList(j), ShoppingCartInfo).RateCode)
                    oRet.Add(oPD)
                End If
            Next
            Return oRet
        End Function

        Private Function ReturnclsProdDetail(ByVal OrderNo As String, ByVal OrderLineNo As Integer, ByVal PID As Long, ByVal RS As String, ByVal RC As String) As TIMSS.API.Base.WebInfo.ProductDetails

            Dim oPD As New TIMSS.API.Base.WebInfo.ProductDetails
            oPD.OrderNo = OrderNo
            oPD.OrderLineNo = OrderLineNo
            oPD.ProductID = PID
            oPD.RateStructure = RS
            oPD.RateCode = RC

            Return oPD
        End Function

        Private Sub CreateOrderFromShoppingCart()

            'Get hte shopping cart
            ' Dim ShopcartItem As ShoppingCartInfo
            Dim oManager As New ShoppingCartController

            '3246-7346214  
            Dim AList As ArrayList = _ShoppingCartList
            If AList Is Nothing OrElse AList.Count = 0 Then
                AList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False, True)

            End If
            'Dim AList As ArrayList = oManager.GetCustomerCart(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, False, True)

            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters = Nothing

            If AList.Count = 0 Then
                'TODO : Give a localized message
                Exit Sub
            End If
            Dim oParams(AList.Count - 1) As OrderEntryParameters


            Try

                'Form the parameter list
                For i As Integer = 0 To AList.Count - 1
                    oParams(i) = New OrderEntryParameters
                    oParams(i).CartItemId = CType(AList(i), ShoppingCartInfo).CartItemId
                    oParams(i).RelatedCartItemId = CType(AList(i), ShoppingCartInfo).RelatedCartItemId
                    oParams(i).MasterCustomerId = CType(AList(i), ShoppingCartInfo).MasterCustomerId
                    oParams(i).SubCustomerId = CType(AList(i), ShoppingCartInfo).SubCustomerId

                    oParams(i).ShipMasterCustomerId = CType(AList(i), ShoppingCartInfo).ShipMasterCustomerId
                    oParams(i).ShipSubCustomerId = CType(AList(i), ShoppingCartInfo).ShipSubCustomerId
                    oParams(i).ProductId = CType(AList(i), ShoppingCartInfo).ProductId
                    oParams(i).SubProductId = CType(AList(i), ShoppingCartInfo).SubProductId
                    oParams(i).Quantity = CType(AList(i), ShoppingCartInfo).Quantity
                    oParams(i).RateStructure = CType(AList(i), ShoppingCartInfo).RateStructure
                    oParams(i).RateCode = CType(AList(i), ShoppingCartInfo).RateCode
                    oParams(i).Subsystem = CType(AList(i), ShoppingCartInfo).Subsystem
                    oParams(i).ProductTypeCode = CType(AList(i), ShoppingCartInfo).ProductType

                    oParams(i).IsDirectPriceUpdate = CType(AList(i), ShoppingCartInfo).IsDirectPriceUpdate
                    oParams(i).UnitPrice = CType(AList(i), ShoppingCartInfo).Price
                    oParams(i).IsDirectPriceUpdate = CType(AList(i), ShoppingCartInfo).IsDirectPriceUpdate

                    'Add Market code to the shopping cart parameters

                    oParams(i).MarketCode = CType(AList(i), ShoppingCartInfo).MarketCode


                    'DCD Files
                    Dim DCDFileList As ArrayList
                    If oParams(i).Subsystem = "ECD" Then
                        DCDFileList = oManager.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, CType(AList(i), ShoppingCartInfo).CartItemId, False, PortalId)
                        If DCDFileList.Count > 0 Then
                            Dim oDCDFiles(DCDFileList.Count - 1) As OrderEntryParametersForDCDFiles

                            For j As Integer = 0 To DCDFileList.Count - 1
                                oDCDFiles(j) = New OrderEntryParametersForDCDFiles
                                oDCDFiles(j).CartItemId = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).CartItemId
                                oDCDFiles(j).CartItemFileId = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).CartItemFileId
                                oDCDFiles(j).FileId = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).FileId
                            Next
                            oParams(i).DCDFiles = oDCDFiles
                        End If
                    End If

                    'if the meeting has badges then add the badge order parameters
                    'AN Cuna Fix
                    If CType(AList(i), ShoppingCartInfo).MaxBadges > 0 Or CType(AList(i), ShoppingCartInfo).ProductType = "BADGE" Then
                        Dim ABadgeList As ArrayList = oManager.GetBadges(oParams(i).CartItemId)
                        If ABadgeList.Count > 0 Then
                            Dim oBadgeParams(ABadgeList.Count - 1) As OrderEntryParametersForBadges
                            For x As Integer = 0 To ABadgeList.Count - 1
                                oBadgeParams(x) = New OrderEntryParametersForBadges
                                oBadgeParams(x).BadgeNumber = CType(ABadgeList(x), BadgeInfo).BadgeNumber
                                oBadgeParams(x).BadgeTypeCode = CType(ABadgeList(x), BadgeInfo).BadgeTypeCode
                                oBadgeParams(x).FirstName = CType(ABadgeList(x), BadgeInfo).FirstName
                                oBadgeParams(x).FullName = CType(ABadgeList(x), BadgeInfo).FullName
                                oBadgeParams(x).Company = CType(ABadgeList(x), BadgeInfo).Company

                                oBadgeParams(x).City = CType(ABadgeList(x), BadgeInfo).City
                                oBadgeParams(x).State = CType(ABadgeList(x), BadgeInfo).State
                                oBadgeParams(x).PostalCode = CType(ABadgeList(x), BadgeInfo).PostalCode
                            Next
                            oParams(i).Badges = oBadgeParams

                        End If
                    End If
                Next

                'Create Order
                'N
                '3246-7346214
                Dim CartItemMap As New Hashtable
                oOrderMasters = get_clsOrderCheckOutProcessHelper.CreateOrders(MasterCustomerId, SubCustomerId, oParams, CartItemMap)
                SessionManager.ClearSessionObject(PortalId, SessionKeys.PersonifyCartItemMap)
                SessionManager.AddSessionObject(PortalId, SessionKeys.PersonifyCartItemMap, CartItemMap)


                'START 3246-7707353 AAO auto respond package to backorder if product is out of stock
                Dim oDetails As TIMSS.API.OrderInfo.IOrderDetails = oOrderMasters(0).Details
                Dim oDetail As TIMSS.API.OrderInfo.IOrderDetail
                Dim outOfStockProductsHash As New Hashtable
                Dim oIssue As TIMSS.API.Core.Validation.IIssue
                If oOrderMasters.ValidationIssues.ErrorCount > 0 Then
                    'can not use errorcount since we are looping through entire validation issues
                    For i As Integer = 0 To oOrderMasters.ValidationIssues.Count - 1
                        oIssue = oOrderMasters.ValidationIssues(i)

                        If oIssue.Key.Contains("OrderInfo.ProductOutOfStockIssue") Then
                            Dim strKey As String
                            strKey = oIssue.Key.Split(":")(0)
                            If Not outOfStockProductsHash.Contains(strKey) Then
                                outOfStockProductsHash.Add(strKey, oIssue.Key)
                            End If
                        End If
                    Next
                End If


                For i As Integer = 0 To oDetails.Count - 1
                    oDetail = oDetails(i)
                    If outOfStockProductsHash.Contains(oDetail.Guid) Then
                        If oDetail.ParentDetail.Product.ProductTypeCode.Code = "P" Then
                            Dim oReply As New TIMSS.API.Core.Validation.IssueResponse(Validation.StandardResponseEnum.Yes)
                            Dim vKey As String
                            vKey = outOfStockProductsHash(oDetail.Guid)
                            oOrderMasters.ValidationIssues(vKey).Responses.Add(oReply)
                            oOrderMasters.ValidationIssues(vKey).Responses.SelectedResponse = oReply
                        End If
                    End If
                Next
                'END auto respond package to back order if product is out of stock


                'ClearValidationIssues()

                'Validation Issues
                'If oOrderMasters.ValidationIssues.Count > 0 Then
                '    oMessageControl.Show(CType(oOrderMasters.ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                'End If


                ''Session.Add(GetSessionKeyForOrders(PortalId), oOrderMasters)
                AddSessionObject(SessionKeys.PersonifyOrder, oOrderMasters)


            Catch ex As Exception

                Throw ex
            End Try
        End Sub

        Private Class ProductInfo
            Public PID As Long
            Public Qty As Integer
        End Class
        Private Function GetProdInfo(ByVal strProduct As String) As ProductInfo

            Dim oRet As New ProductInfo
            Dim i As Int32

            If Integer.TryParse(strProduct, i) > 0 Then
                oRet.PID = CType(strProduct, Long)
                oRet.Qty = 1
            Else
                oRet.PID = strProduct.Split("q")(0)
                oRet.Qty = strProduct.Split("q")(1)

            End If

            Return oRet

        End Function

        'RTW - roll back later
        Private Sub CreateOrderFromRequest(ByVal PIDS As String, Optional ByVal Prices As String = Nothing)
            'Private Sub CreateOrderFromRequest(ByVal PIDS As String)

            Try


                'Get hte shopping cart
                Dim strPIDs() As String
                Dim strPrices() As String   '3246-5875068
                Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters = Nothing
                Dim ProductId As String = ""
                Dim ProductPrice As String = ""  '3246-5875068

                strPIDs = PIDS.Split(",")
                '3246-5875068
                If Prices IsNot Nothing Then
                    strPrices = Prices.Split(",")
                Else
                    strPrices = Nothing
                End If


                Dim oParams(strPIDs.Length - 1) As OrderEntryParameters

                For i As Integer = 0 To strPIDs.Length - 1
                    oParams(i) = New OrderEntryParameters
                    oParams(i).CartItemId = i + 1

                    oParams(i).MasterCustomerId = MasterCustomerId
                    oParams(i).SubCustomerId = SubCustomerId

                    oParams(i).ShipMasterCustomerId = MasterCustomerId
                    oParams(i).ShipSubCustomerId = SubCustomerId

                    If i = 0 Then
                        oParams(i).RelatedCartItemId = 0
                        'an cuna fix
                        ' oParams(i).ProductId = strPIDs(i)
                        oParams(i).ProductId = GetProdInfo(strPIDs(i)).PID
                        oParams(i).SubProductId = 0
                        '3246-5875068
                        If strPrices IsNot Nothing AndAlso strPrices.Length > 0 Then
                            oParams(i).UnitPrice = strPrices(i)
                            oParams(i).IsDirectPriceUpdate = True
                        End If
                        oParams(i).Quantity = 1
                    Else
                        '
                        oParams(i).RelatedCartItemId = 1
                        'an cuna fix
                        '            oParams(i).ProductId = strPIDs(0)
                        'oParams(i).SubProductId = strPIDs(i)
                        'oParams(i).Quantity = 1

                        oParams(i).ProductId = GetProdInfo(strPIDs(0)).PID
                        oParams(i).SubProductId = GetProdInfo(strPIDs(i)).PID
                        oParams(i).Quantity = GetProdInfo(strPIDs(i)).Qty

                    End If

                Next

                'Create Order
                oOrderMasters = get_clsOrderCheckOutProcessHelper.CreateOrders(MasterCustomerId, SubCustomerId, oParams)


                AddSessionObject(SessionKeys.PersonifyOrder, oOrderMasters)

            Catch ex As Exception
                Throw ex
            End Try

        End Sub


        Private Sub AddToExistingOrder(ByVal OrderNumber As String, ByVal OrderLineNumber As String, ByVal ProductIds As String)
            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters = Nothing
            oOrderMasters = get_clsOrderCheckOutProcessHelper.AddSubProductToExistingOrder(OrderNumber, Convert.ToInt32(OrderLineNumber), ProductIds.Split(","))
            AddSessionObject(SessionKeys.PersonifyOrder, oOrderMasters)
        End Sub


        Private Sub MYRespondToValidationIssues()

            Try
                'Get Order Master Object
                Dim oOM As TIMSS.API.OrderInfo.IOrderMasters
                Dim oResponseSelected As TIMSS.API.Core.Validation.IssueResponse = Nothing
                Dim IssuesResponded As Boolean = True
                '3246-7346214
                Dim OrderLineNoOfResponse As Integer = -1
                Dim Count As Integer = 0

                oOM = GetOrderFromSessionObject()
                Dim ctlMEssageControl As New Personify.WebControls.MessageControl
                _IssueParentGuidHash = New Hashtable
                'Dim strKeyId As String
                'Dim strREsponse As String

                'For each detail, respond to the validaiton issue
                'For Each oOrderDetail As TIMSS.API.OrderInfo.IOrderDetail In oOM(0).Details
                '    'TODO - Poll only those lines which have validation issues
                '    strKeyId = "rb" + "_" + oOrderDetail.OrderNumber.ToString + "_" + oOrderDetail.OrderLineNumber.ToString + "_" + "aRadioButtonList"

                '    strREsponse = GetValueOfRespondedVI(strKeyId)
                'Next

                For Each oOrderDetail As TIMSS.API.OrderInfo.IOrderDetail In oOM(0).Details
                    For Each oIssue As TIMSS.API.Core.Validation.IIssue In oOM(0).ValidationIssues
                        If oOrderDetail.Guid = oIssue.ParentGuid Then
                            oResponseSelected = GetResponseOfTheValidationIssue(oOrderDetail.Guid, oIssue)
                            'If there is no response on any of the issue - do not go to the next page
                            If oResponseSelected Is Nothing Then
                                If Not _IssueParentGuidHash.Contains(oIssue.ParentGuid) Then
                                    _IssueParentGuidHash.Add(oIssue.ParentGuid, "")
                                End If
                                IssuesResponded = False
                            Else
                                'Change the text color back if it has been answered
                                oIssue.Message = oIssue.Message.Replace("<font color='red'><b>", "")
                                oIssue.Message = oIssue.Message.Replace("</b></font>", "")
                                'End Change
                                oIssue.Responses.SelectedResponse = oResponseSelected
                                '3246-7346214
                                OrderLineNoOfResponse = oOrderDetail.OrderLineNumber
                            End If

                        End If
                    Next

                Next
                '3246-7346214
                Count = oOM(0).Details.Count
                oOM(0).RemoveDirtyOrderLines()
                oOM.Validate()

                '3246-7346214
                If Count > oOM(0).Details.Count Then
                    'remove item from shopping cart.
                    RemoveProductFromShoppingCart(OrderLineNoOfResponse)
                    If oOM(0).Details.Count = 0 Then
                        Response.Redirect(EditSetting_GoToShoppingCartURLURL)
                    End If
                End If

                If IssuesResponded = True AndAlso oOM.ValidationIssues.ErrorCount = 0 Then '3246-5727428
                    'In case the user chooses to removes the line or if there is a hard stop ... do not navigate to the next page.
                    If oOM(0).Details.Count = 0 Then

                    Else
                        'add seesions
                        If UpdateOrder Then
                            Dim ids As New ArrayList()
                            ids.Add(oOM(0).OrderNumber)
                            SessionManager.ClearSessionObject(PortalId, SessionKeys.PersonifyPayOrderIds)
                            SessionManager.AddSessionObject(PortalId, SessionKeys.PersonifyPayOrderIds, ids)
                        End If
                        'END add seesions
                        GoToNextPage()
                    End If

                Else
                    'Missing responde
                    lblErrorMessage.Visible = True
                End If

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try
        End Sub

        '3246-7346214
        Private Sub RemoveProductFromShoppingCart(ByVal CartItemToRemove As Integer)
            Dim CartItemMap As Hashtable = GetCartItemMapFromSessionObject()
            If CartItemMap IsNot Nothing Then
                For Each entry As DictionaryEntry In CartItemMap
                    If entry.Value.ToString = CartItemToRemove.ToString Then
                        Dim oController As New ShoppingCartController
                        oController.DeleteCartItemByCartItemId(MasterCustomerId, SubCustomerId, CType(entry.Key, Integer), False)
                        oController = Nothing
                        Exit Sub
                    End If
                Next
            End If
        End Sub

        Private Sub GoToNextPage()
            If EditSetting_NextPageURL.Length > 0 Then
                Response.Redirect(EditSetting_NextPageURL)
            End If

        End Sub

        Private Function GetResponseOfTheValidationIssue(ByVal VIGuid As String, ByVal Issue As TIMSS.API.Core.Validation.IIssue) As TIMSS.API.Core.Validation.IssueResponse

            Dim strcontrolKey As String
            Dim strResponseValue As String = ""
            Dim oReturnResponse As TIMSS.API.Core.Validation.IssueResponse = Nothing
            strcontrolKey = "a" + Issue.Key

            For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                If Page.Request.Form.Keys(i).Contains(strcontrolKey) Then
                    strResponseValue = Page.Request.Form(Page.Request.Form.Keys(i))
                    Exit For
                End If
            Next

            If strResponseValue.Length > 0 Then
                For Each oResponse As TIMSS.API.Core.Validation.IssueResponse In Issue.Responses
                    If oResponse.Value = strResponseValue Then
                        oReturnResponse = oResponse
                        Exit For
                    End If
                Next
            End If





            'For Each oResponse As TIMSS.API.Core.Validation.IssueResponse In Issue.Responses
            '    strcontrolKey = "rb" + "_" + VIGuid + "_" + oResponse.Value
            '    If Not Me.FindControl(strcontrolKey) Is Nothing Then
            '        If CType(Me.FindControl(strcontrolKey), RadioButton).Checked = True Then
            '            oReturnResponse = oResponse
            '            Exit For
            '        End If
            '    End If
            'Next

            Return oReturnResponse

        End Function

        Private Function GetValueOfRespondedVI(ByVal KeyId As String) As String

            Dim strReturn As String = ""

            For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                If Page.Request.Form.Keys(i).Contains(KeyId) Then
                    strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                    Exit For
                End If
            Next

            Return strReturn
        End Function

        'Private Sub btnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click
        '    RespondToValidationIssues()
        'End Sub
#End Region


        Public Sub OnModuleCommunication(ByVal s As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleListener.OnModuleCommunication

            Select Case DirectCast(s, PersonifyCheckOut_ModuleCommunicationKeys)

                Case PersonifyCheckOut_ModuleCommunicationKeys.CreateOrderFromProductIds
                    SetCustomerId()
                    RaiseEvent ModuleCommunication(PersonifyCheckOut_ModuleCommunicationKeys.RequestProductIdsFromProductDetailWebPart, e)

                Case PersonifyCheckOut_ModuleCommunicationKeys.SelectedProductIds

                    Dim strPIDs As String = e.Text
                    '3246-5875068
                    Dim strPrices As String = e.Value
                    CreateOrderFromRequest(strPIDs, strPrices)
                    'CreateOrderFromRequest(strPIDs)
                    LoadOrderCreateTemplate()
                    CodeForGoToCart()
                    'End If

                Case PersonifyCheckOut_ModuleCommunicationKeys.RespondToValidationIssues
                    MYRespondToValidationIssues()

                Case PersonifyCheckOut_ModuleCommunicationKeys.SamePageCheckOutEnabled

            End Select

            'If s.ToString = "CREATEORDERFROMREQUEST" Then
            '    SetCustomerId()
            '    RaiseEvent ModuleCommunication("REQUESTPRODUCTIDS", e)

            'End If
            'If s.ToString = "PRODUCTIDS" Then
            '    Dim strPIDs As String = e.Text
            '    CreateOrderFromRequest(strPIDs)
            '    LoadOrderCreateTemplate()
            '    CodeForGoToCart()
            'End If

            'If s.ToString = "RESPONDTOVALIDATIONISSUES" Then
            '    RespondToValidationIssues()
            'End If

        End Sub

        Public Event ModuleCommunication(ByVal sender As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleCommunicator.ModuleCommunication


#Region "Get images functions"
        Private Function GetSubordinateArrowImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/timss-arrow-subordinate.gif")
        End Function
        Private Function GetQuestionImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/timss-question-blue.gif")
        End Function
        Private Function GetInfoImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/timss-info-green.gif")
        End Function
        Private Function GetWarningImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/timss-warning-yellow.gif")
        End Function
        Private Function GetErrorImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/timss-error-red.gif")
        End Function
#End Region

#Region "Personify DAta"

#End Region
    End Class

End Namespace
