
Namespace Personify.DNN.Modules.OrderCreate
    Public Class ModuleSettingsNames
        Public Const TemplateName As String = "TemplateName"
        Public Const NextPageURL As String = "NextPageURL"
        Public Const NextPageURLType As String = "NextPageURLType"
        Public Const SamePageCheckoutEnabled As String = "SamePageCheckoutEnabled"
        Public Const GoToShoppingCartURL As String = "GoToShoppingCartURL"
        Public Const GoToShoppingCartURLType As String = "GoToShoppingCartURLType"


        Public Const AutoSkipToNextPage As String = "AutoSkipToNextPage"

        Public Const C_TEMPLATEFOLDERNAME As String = "Templates"
        Public Const C_FILEPATTERN As String = "*.?s*" '*.xsl
    End Class
End Namespace

