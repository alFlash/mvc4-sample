

Namespace Personify.DNN.Modules.PayOrders

    Public Class ModuleSettingsNames
        Public Const C_PayOrdersURL As String = "PayOrders_Url"
        Public Const C_PayOrdersTEMPLATE As String = "PayOrdersTemplate"
        Public Const C_PayOrdersMode As String = "PayOrdersMode"
        Public Const C_CCTEMPLATE As String = "CC_Template"
        Public Const C_TEMPLATES As String = "Templates"
        Public Const C_FILEPATTERN As String = "*.?s*" '*.xsl
        Public Const C_ENABLEECHECK As String = "EnableECheck"
        Public Const C_ECHECKTEMPLATE As String = "ECheckTemplate"
    End Class

    Public Class ReceiptTypeCodes
        Public ReceiptCodeValue As String
        Public ReceiptCodeDescrip As String
    End Class

    Public Class CheckType
        Public CheckTypeValue As String
        Public CheckTypeDescrip As String
    End Class
End Namespace
