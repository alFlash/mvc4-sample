Option Strict Off
Option Explicit On


Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects



Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Configuration

Imports System.Web.UI.WebControls
Imports System.Collections.Generic

Imports Telerik.Web.UI

Namespace Personify.DNN.Modules.PayOrders

    Public MustInherit Class PayOrders
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"
        Protected PayOrdersXslTemplate As Personify.WebControls.XslTemplate
        Protected CreditCardTemplate As Personify.WebControls.XslTemplate
        Protected CreditCardForTabTemplate As Personify.WebControls.XslTemplate
        Protected ECheckTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents RadTabStrip1 As Telerik.Web.UI.RadTabStrip
        Protected WithEvents RadMultiPage1 As Telerik.Web.UI.RadMultiPage
        Protected WithEvents cmdContinue As LinkButton
        Protected WithEvents cmdAuthorizeContinue As LinkButton
        Protected WithEvents oMessageControl As WebControls.MessageControl
#End Region

#Region "Private Variables"
        Private ECheckCodes As List(Of String)

        Private _ShowInvalidCardMsg As Boolean = False
#End Region

#Region "Constants"
        Public Const ccTypeId As String = "ddlCCType"
        Public Const ccNumberId As String = "txtCCNumber"
        Public Const ccCVV2Id As String = "txtCVV2"
        Public Const ccMonthId As String = "txtccMonth"
        Public Const ccYearId As String = "txtccYear"
        Public Const ccNameonCardId As String = "txtccNameOnCard"
        Public Const ccUseCCOnFileId As String = "chkUseCreditCardOnFile"
        Public Const ccRememberMyInfoId As String = "chkRememberMyCreditCard"

        Public Const eckTypeId As String = "ddlEckType"
        Public Const eckRoutingNumberId As String = "txtRoutingNumber"
        Public Const eckAccountNumberId As String = "txtAccountNumber"
        Public Const eckCheckNumberId As String = "txtCheckNumber"
        Public Const eckAccountNameId As String = "txtAccountName"
        Public Const eckDriversLicenseId As String = "txtDriversLicense"
        Public Const eckDriversLicenseState As String = "txtDriversLicenseState"
        Public Const eckCheckTypeId As String = "ddlEckCheckType"

#End Region

#Region "Properties"
        Private ReadOnly Property EditSetting_ECheckEnabled() As Boolean
            Get
                Try
                    If CType(Settings(ModuleSettingsNames.C_ENABLEECHECK), String) = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    Return False
                End Try
            End Get
        End Property

        Private ReadOnly Property EditSetting_ECheckTemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.C_ECHECKTEMPLATE), String)

                If strFileName Is Nothing OrElse strFileName.Length = 0 Then
                    strFileName = "ECheck.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property
#End Region

#Region "Event Handlers"

        Private Function GetRenewalsObject() As TIMSS.API.WebInfo.IWebRenewalListingViewList
            If GetSessionObject(SessionKeys.PersonifyMembershipRenewalsViewList) Is Nothing Then

                Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo

                'If debug Then
                '	arrGroupActionInfo = GetGroupActionInfo()
                'Else
                arrGroupActionInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
                'End If
                Dim oWebRenewalListing As TIMSS.API.WebInfo.IWebRenewalListingViewList
                If arrGroupActionInfo IsNot Nothing Then
                    If arrGroupActionInfo.Length > 0 Then
                        Dim CustomerID(arrGroupActionInfo.Length - 1) As CustomerID
                        For i As Integer = 0 To arrGroupActionInfo.Length - 1

                            CustomerID(i) = New CustomerID
                            CustomerID(i).MasterCustomerId = arrGroupActionInfo(i).AffiliateCustomerId.MasterCustomerId
                            CustomerID(i).SubCustomerId = arrGroupActionInfo(i).AffiliateCustomerId.SubCustomerId
                        Next

                        oWebRenewalListing = GetRenewals(CustomerID)



                    End If
                Else
                    Dim CustomerID(0) As CustomerID
                    CustomerID(0) = New CustomerID
                    CustomerID(0).MasterCustomerId = MasterCustomerId
                    CustomerID(0).SubCustomerId = SubCustomerId

                    oWebRenewalListing = GetRenewals(CustomerID)
                End If
                AddSessionObject(SessionKeys.PersonifyMembershipRenewalsViewList, oWebRenewalListing)
                Return oWebRenewalListing

            Else
                Return CType(GetSessionObject(SessionKeys.PersonifyMembershipRenewalsViewList), TIMSS.API.WebInfo.IWebRenewalListingViewList)
            End If

            Return Nothing
        End Function


        Private Function GetOrdersObject() As TIMSS.API.WebInfo.IWebOrderBalanceViewList
            Dim oWebOrderListing As TIMSS.API.WebInfo.IWebOrderBalanceViewList
            Dim oWebOrderListingTemp As New ArrayList
            Dim ids As New ArrayList
            oWebOrderListing = GetOrders(MasterCustomerId, SubCustomerId)
            ids = CType(GetSessionObject(SessionKeys.PersonifyPayOrderIds), ArrayList)

            'Dim oWebOrderListing As TIMSS.API.WebInfo.IWebOrderBalanceViewList
            'oWebOrderListing = Personify.ApplicationManager.WebProduct.GetOrders(PortalId, MasterCustomerID, SubCustomerId)
            'If oWebOrderListing IsNot Nothing AndAlso oWebOrderListing.Count > 0 Then
            '	For i As Integer = 0 To oWebOrderListing.Count - 1
            '		oWebOrderListing.Item(i).DueDate = 
            '	Next
            'End If
            'AddSessionObject( WebUtility.SessionManager.SessionKeys.PersonifyOrdersViewList, oWebOrderListing)

            If ids IsNot Nothing AndAlso ids.Count > 0 Then

                For Each order As TIMSS.API.WebInfo.IWebOrderBalanceView In oWebOrderListing
                    If ids.Contains(order.OrderNumber) Then
                        order.BaseBalanceAmount = Me.ConvertPriceFromBaseToPortalCurrency(order.BaseBalanceAmount)
                        oWebOrderListingTemp.Add(order)
                    End If
                Next
                oWebOrderListing.Clear()
                For Each order As TIMSS.API.WebInfo.IWebOrderBalanceView In oWebOrderListingTemp
                    oWebOrderListing.Add(order)
                Next
                Return oWebOrderListing

            Else
                For Each order As TIMSS.API.WebInfo.IWebOrderBalanceView In oWebOrderListing
                    If order.BaseBalanceAmount > 0 Then
                        oWebOrderListingTemp.Add(order)
                    End If
                Next
                oWebOrderListing.Clear()

                For Each order As TIMSS.API.WebInfo.IWebOrderBalanceView In oWebOrderListingTemp
                    order.BaseBalanceAmount = Me.ConvertPriceFromBaseToPortalCurrency(order.BaseBalanceAmount)

                    oWebOrderListing.Add(order)
                Next

                Return oWebOrderListing
            End If
        End Function

        Public PayOrdersMode As Integer = 0 ' 0 payOrders 1 payRenewals

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Settings("PayOrdersMode") IsNot Nothing AndAlso Settings("PayOrdersMode") = "1" Then
                    PayOrdersMode = 1
                End If


                RegisterJSScripts("js\CreditCard.js", "CreditCard")
                RegisterJSScripts("js\Echeck.js", "Echeck")


                If Me.IsPersonifyWebUserLoggedIn Then
                    'If Not UserInfo.Profile.GetPropertyValue("MasterCustomerId") Is Nothing _
                    ' AndAlso _
                    ' Not UserInfo.Profile.GetPropertyValue("SubCustomerId") Is Nothing _
                    ' AndAlso _
                    ' UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString.Length > 0 _
                    ' Then
                    '	If PayOrdersMode = 0 Or (PayOrdersMode = 1 And AffiliateManagementSessionHelper.IsManagingSegment(PortalId) = True) Then
                    '		Try
                    '			MasterCustomerID = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
                    '			SubCustomerId = CType(UserInfo.Profile.GetPropertyValue("SubCustomerId"), Integer)
                    '		Catch ex As Exception

                    '		End Try

                    '	End If

                    ' If Personify.WebUtility.User.IsPersonifyUserLoggedIn(UserInfo.Profile.ProfileProperties, MasterCustomerID, SubCustomerId) = True Then
                    If EditSetting_ECheckEnabled Then
                        RadMultiPage1.Visible = True
                        RadTabStrip1.Visible = True
                        CreditCardTemplate.Visible = False
                    Else
                        RadMultiPage1.Visible = False
                        RadTabStrip1.Visible = False
                        CreditCardTemplate.Visible = True
                    End If

                    ECheckCodes = get_clsOrderCheckOutProcessHelper.GetECheckCodeList()

                    Dim templatefile As String = ""
                    If Settings("PayOrdersTemplate") Is Nothing Then
                        If PayOrdersMode = 0 Then
                            templatefile = ModulePath + "Templates\PayOrders.xsl"
                        Else
                            templatefile = ModulePath + "Templates\PayRenewals.xsl"
                        End If
                    Else
                        templatefile = ModulePath + "Templates\" + Settings("PayOrdersTemplate").ToString
                    End If

                    PayOrdersXslTemplate.XSLfile = Server.MapPath(templatefile)
                    PayOrdersXslTemplate.AddObject("ModuleId", ModuleId)

                    If PayOrdersMode = 1 Then
                        Dim oWebRenewalListing As TIMSS.API.WebInfo.IWebRenewalListingViewList
                        oWebRenewalListing = GetRenewalsObject()
                        If oWebRenewalListing IsNot Nothing AndAlso oWebRenewalListing.Count > 0 Then
                            Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                            arrGroupActionInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
                            PayOrdersXslTemplate.AddObject("CurrencySymbol", PortalCurrency.Symbol)
                            PayOrdersXslTemplate.AddObject("", oWebRenewalListing)
                            PayOrdersXslTemplate.AddObject("", arrGroupActionInfo)
                            PayOrdersXslTemplate.Display()

                            If CheckIfPostbackByButton("btnProcessOrder") Or CheckIfPostbackByButton("btnAuthorize") Then
                                If ValidateTemplateFields() Then
                                    ProcessPayment()
                                End If
                            End If
                            LoadPaymentTemplate()
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RenewOrderNotCreated", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If

                    Else

                        Dim oWebOrderlListing As TIMSS.API.WebInfo.IWebOrderBalanceViewList
                        oWebOrderlListing = GetOrdersObject()
                        Dim TotalAmount As Double = 0
                        For Each oWebOrder As TIMSS.API.WebInfo.IWebOrderBalanceView In oWebOrderlListing
                            TotalAmount = Math.Round(TotalAmount + oWebOrder.BaseBalanceAmount, 2)
                        Next
                        PayOrdersXslTemplate.AddObject("CurrencySymbol", PortalCurrency.Symbol)
                        PayOrdersXslTemplate.AddObject("TotalAmount", TotalAmount)
                        PayOrdersXslTemplate.AddObject("", oWebOrderlListing)
                        PayOrdersXslTemplate.Display()

                        If CheckIfPostbackByButton("btnProcessOrder") Or CheckIfPostbackByButton("btnAuthorize") Then
                            If ValidateTemplateFields() Then
                                ProcessPayment()
                            End If
                        End If
                        LoadPaymentTemplate()

                    End If



                Else
                    RadTabStrip1.Visible = False
                    RadMultiPage1.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("LoginFirst.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Public Class Months
            Public MonthName As String
            Public MonthNumber As Integer
        End Class

        Public Class Years
            Public Year As Integer
        End Class

        Private Function LoadMonths() As Months()

            Dim oMonths(11) As Months
            Dim dtStartDate As Date = Date.Parse("01-01-2006")


            Dim i As Integer = 1

            For i = 1 To 12
                oMonths(i - 1) = New Months
                oMonths(i - 1).MonthName = Format(dtStartDate, "MMMM")
                oMonths(i - 1).MonthNumber = dtStartDate.Month

                dtStartDate = dtStartDate.AddMonths(1)
            Next

            Return oMonths

        End Function

        Private Function LoadYears() As Years()
            '3246-6880268
            Dim oYears(10) As Years

            Dim i As Integer = 1
            Dim StartDate As Date = Date.Now.AddYears(-1)
            '3246-6880268
            For i = 1 To 10
                oYears(i - 1) = New Years
                oYears(i - 1).Year = StartDate.AddYears(i).Year
            Next

            Return oYears

        End Function

        Private ReadOnly Property ccControlValue(ByVal ControlId As String) As String
            Get
                Dim ocontrolId As String = ""
                Dim strReturn As String = ""
                ocontrolId = ControlId + "_" + ModuleId.ToString

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ocontrolId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

        Private ReadOnly Property ControlValue(ByVal ControlId As String) As String
            Get
                Dim ocontrolId As String = ""
                Dim strReturn As String = ""
                ocontrolId = ControlId

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ocontrolId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property




        Private Sub LoadCreditCardTemplate(ByVal TempCreditCardTemplate As Personify.WebControls.XslTemplate)

            ' Valid Receipt Type Codes for Current E-Commerce Batch 
            Dim oVs() As ValidReceiptCodes
            Dim strError As String = ""
            oVs = get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError)
            If strError.Length > 0 OrElse oVs.Length = 0 Then
                Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile)
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile) + "</br>" + strError, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)

                '''''''''''''''''Personify.WebUtility.ClearSessionObject( SessionManager.SessionKeys.PersonifyOrder)
            Else
                Dim oCCInfo As TIMSS.API.CustomerInfo.ICustomerCreditCards
                Dim CCOnFileExists As Boolean
                'CCOnFileExists = get_clsOrderCheckOutProcessHelper.CheckIfThePayorHAsCreditCardOfRecord(MasterCustomerId, SubCustomerId)

                TempCreditCardTemplate.Visible = True

                Dim templatefile As String = ""
                If Settings("CC_Template") Is Nothing Then
                    templatefile = ModulePath + "Templates\CreditCardWithCVV2.xsl"
                Else
                    templatefile = ModulePath + "Templates\" + Settings("CC_Template").ToString
                End If

                TempCreditCardTemplate.XSLfile = Server.MapPath(templatefile)
                'Server.MapPath(ModulePath + "Templates\CreditCardWithCVV2.xsl")

                oCCInfo = get_clsOrderCheckOutProcessHelper.GetCustomerCreditCardOnRecord(MasterCustomerId, SubCustomerId, oVs)
                CCOnFileExists = oCCInfo.Count > 0 AndAlso oCCInfo(0).CCExpirationDate >= TIMSS.Global.App.ServerDateTime.Date

                'If cc on file exists, then store the credit card type. This is used for creating receipts before the order is saved

                'Constants to be loaded in CC Template

                TempCreditCardTemplate.AddObject("ModuleId", ModuleId)
                TempCreditCardTemplate.AddObject("CCOnFileExists", CCOnFileExists)


                TempCreditCardTemplate.AddObject("ccTypeId", ccTypeId)
                TempCreditCardTemplate.AddObject("ccNumberId", ccNumberId)
                TempCreditCardTemplate.AddObject("ccCVV2Id", ccCVV2Id)
                TempCreditCardTemplate.AddObject("ccMonthId", ccMonthId)
                TempCreditCardTemplate.AddObject("ccYearId", ccYearId)
                TempCreditCardTemplate.AddObject("ccNameonCardId", ccNameonCardId)
                TempCreditCardTemplate.AddObject("ccUseCCOnFileId", ccUseCCOnFileId)
                TempCreditCardTemplate.AddObject("ccRememberMyInfoId", ccRememberMyInfoId)
                TempCreditCardTemplate.AddObject("ccInvalidCard", _ShowInvalidCardMsg)

                If CCOnFileExists Then
                    TempCreditCardTemplate.AddObject("ccOnFileExpMonth", oCCInfo(0).CCExpirationDate.Month)
                    TempCreditCardTemplate.AddObject("ccOnFileExpYear", oCCInfo(0).CCExpirationDate.Year)
                    TempCreditCardTemplate.AddObject("ccOnFilePayorName", oCCInfo(0).CCName)

                End If

                '
                'Load Credit Card Template

                'Customers Preferred Credit Card
                TempCreditCardTemplate.AddObject("", oCCInfo)

                'Months of the year
                TempCreditCardTemplate.AddObject("", LoadMonths)

                'Years -- Current Year + 5
                TempCreditCardTemplate.AddObject("", LoadYears)


                TempCreditCardTemplate.AddObject("", oVs)
                TempCreditCardTemplate.Display()

                oCCInfo = Nothing
            End If

        End Sub

        Private Sub LoadECheckTemplate()

            ' Valid Receipt Type Codes for Current E-Commerce Batch 
            Dim oVs() As ValidReceiptCodes
            Dim strError As String = ""
            oVs = get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError)

            ECheckTemplate.Visible = True
            ECheckTemplate.XSLfile = Server.MapPath(EditSetting_ECheckTemplateFile)

            ECheckTemplate.AddObject("ModuleId", ModuleId)

            ECheckTemplate.AddObject("eckTypeId", eckTypeId)
            ECheckTemplate.AddObject("eckRoutingNumberId", eckRoutingNumberId)
            ECheckTemplate.AddObject("eckAccountNumberId", eckAccountNumberId)
            ECheckTemplate.AddObject("eckCheckNumberId", eckCheckNumberId)
            ECheckTemplate.AddObject("eckAccountNameId", eckAccountNameId)
            ECheckTemplate.AddObject("eckDriversLicenseId", eckDriversLicenseId)
            ECheckTemplate.AddObject("eckDriversLicenseState", eckDriversLicenseState)
            ECheckTemplate.AddObject("eckCheckTypeId", eckCheckTypeId)

            Dim oAppStates As TIMSS.API.ApplicationInfo.IApplicationStates
            oAppStates = get_clsOrderCheckOutProcessHelper.GetApplicationStates("USA")

            If Not oAppStates.Count = 0 Then
                ECheckTemplate.AddObject("", oAppStates)
            End If

            Dim ReceiptTypeCodeList(oVs.Length - ECheckCodes.Count) As ReceiptTypeCodes
            Dim i As Integer = 0

            For Each ReceiptCode As ValidReceiptCodes In oVs
                For Each ECheckCode As String In ECheckCodes
                    If ReceiptCode.ReceiptCode.ToString = ECheckCode Then
                        ReceiptTypeCodeList(i) = New ReceiptTypeCodes
                        ReceiptTypeCodeList(i).ReceiptCodeValue = ReceiptCode.ReceiptCode.ToString
                        ReceiptTypeCodeList(i).ReceiptCodeDescrip = ReceiptCode.ReceiptDescription.ToString

                        i = i + 1
                    End If
                Next
            Next

            ECheckTemplate.AddObject("ReceiptTypeCodeList", ReceiptTypeCodeList)

            Dim CheckTypeList As Personify.ApplicationManager.PersonifyDataObjects.CheckType() = get_clsOrderCheckOutProcessHelper.GetCheckType()

            If CheckTypeList.Length > 0 Then
                ECheckTemplate.AddObject("CheckTypeList", CheckTypeList)
            End If
            ECheckTemplate.Display()

            Dim ddl As DropDownList = CType(FindControl(String.Concat("IDType_", ModuleId)), DropDownList)
            Dim lblPersID As Label = FindControl("lblECDriversLicense")
            Dim lblAddtlInfo As Label = FindControl("lblECDriversLicenseState")
            If ddl IsNot Nothing AndAlso lblPersID IsNot Nothing AndAlso lblAddtlInfo IsNot Nothing Then
                ddl.Attributes.Add("onChange", String.Format("SetChangeLabel(this,'{0}','{1}')", lblPersID.ClientID, lblAddtlInfo.ClientID))
            End If

            Dim txtRequiredAuthorizationVerbiage As Label
            txtRequiredAuthorizationVerbiage = CType(FindControl("txtRequiredAuthorizationVerbiage"), Label)

            If txtRequiredAuthorizationVerbiage IsNot Nothing Then
                txtRequiredAuthorizationVerbiage.Text = Localization.GetString("txtRequiredAuthorizationVerbiage", Me.LocalResourceFile)
            End If

            Dim imgTeleCheckLogo As Image
            imgTeleCheckLogo = CType(FindControl("imgTeleCheckLogo"), Image)

            If imgTeleCheckLogo IsNot Nothing Then
                imgTeleCheckLogo.ImageUrl = String.Concat("~/", SiteImagesFolder, "/official_logo.gif")
            End If

            LoadToolTips(eckRoutingNumberId)
            LoadToolTips(eckAccountNumberId)
        End Sub

        Private Sub LoadToolTips(ByVal Name As String)
            Dim tempPlaceHolder As New PlaceHolder
            Dim tempTextboxPlaceHolder As New PlaceHolder
            Dim tempToolTip As New RadToolTip
            Dim tempTextbox As New TextBox

            tempTextbox.ID = String.Concat(Name, "_", ModuleId.ToString)
            tempTextbox.Width = "200"
            With tempToolTip
                .ID = String.Concat(Name, "ToolTip_", ModuleId.ToString)
                .Height = "200"
                .Width = "380"
                .TargetControlID = tempTextbox.ID
                .IsClientID = False
                .OffsetY = "4"
                .Sticky = True
                .Animation = ToolTipAnimation.Fade
                .Position = ToolTipPosition.MiddleRight
                .RelativeTo = ToolTipRelativeDisplay.Element
                .Skin = Localization.GetString("ECKToolTipSkin", Me.LocalResourceFile)
                .ShowEvent = ToolTipShowEvent.OnFocus
                .ManualClose = False
                .HideDelay = 500
                Dim tempImage As New Image
                tempImage.ID = String.Concat(Name, "Image_", ModuleId.ToString)
                tempImage.ImageUrl = ResolveUrl(String.Concat("~/", SiteImagesFolder, "/", Localization.GetString(String.Concat(Name, "Image"), Me.LocalResourceFile)))
                .Controls.Add(tempImage)
            End With

            For i As Integer = 0 To Me.Controls.Count - 1
                For j As Integer = 0 To Me.Controls(i).Controls.Count - 1
                    For k As Integer = 0 To Me.Controls(i).Controls(j).Controls.Count - 1
                        tempTextboxPlaceHolder = Me.Controls(i).Controls(j).Controls(k).FindControl(String.Concat(Name, "TextboxPlaceHolder_", ModuleId.ToString))
                        tempPlaceHolder = Me.Controls(i).Controls(j).Controls(k).FindControl(String.Concat(Name, "PlaceHolder_", ModuleId.ToString))
                        If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                            Exit For
                        End If
                    Next
                    If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                        Exit For
                    End If
                Next
                If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                    Exit For
                End If
            Next

            If tempTextboxPlaceHolder IsNot Nothing Then
                tempTextboxPlaceHolder.Controls.Add(tempTextbox)
            End If

            If (tempPlaceHolder IsNot Nothing) Then
                tempPlaceHolder.Controls.Add(tempToolTip)
            End If
        End Sub



        Private Sub ProcessPayment()

            Dim testlist As New ArrayList
            Dim ActualAmount As Decimal = 0
            Dim monal As New ArrayList 'ApplicationManager.Payments.OrderNumberAndLine

            If PayOrdersMode = 1 Then

                Dim oWebRenewalListing As TIMSS.API.WebInfo.IWebRenewalListingViewList
                oWebRenewalListing = GetRenewalsObject()

                If oWebRenewalListing IsNot Nothing Then
                    If oWebRenewalListing.Count > 0 Then
                        For i As Integer = 0 To oWebRenewalListing.Count - 1
                            Dim checkboxname As String = "OrderCheckBox_" + ModuleId.ToString + "_" + oWebRenewalListing(i).OrderNumber.ToString + "_" + oWebRenewalListing(i).OrderLineNumber.ToString

                            If ControlValue(checkboxname).ToLower = "on" Then
                                testlist.Add(checkboxname)
                            End If
                        Next
                        If testlist.Count > 0 Then
                            For j As Integer = 0 To testlist.Count - 1
                                Dim parts() As String = testlist(j).ToString.Split(CChar("_"))
                                If parts.Length = 4 Then

                                    Dim monalj As New OrderNumberAndLine
                                    monalj.OrderNumber = parts(2)
                                    monalj.OrderLineNumber = parts(3)
                                    monal.Add(monalj)

                                    For i As Integer = 0 To oWebRenewalListing.Count - 1
                                        Dim checkboxname As String = "OrderCheckBox_" + ModuleId.ToString + "_" + oWebRenewalListing(i).OrderNumber.ToString + "_" + oWebRenewalListing(i).OrderLineNumber.ToString
                                        If testlist(j).ToString = checkboxname Then
                                            ActualAmount += oWebRenewalListing(i).BaseAmount
                                        End If
                                    Next
                                End If
                            Next
                        End If
                    End If
                End If
            Else

                Dim oWebOrderListing As TIMSS.API.WebInfo.IWebOrderBalanceViewList
                oWebOrderListing = GetOrdersObject()

                If oWebOrderListing IsNot Nothing Then
                    If oWebOrderListing.Count > 0 Then
                        For i As Integer = 0 To oWebOrderListing.Count - 1
                            Dim checkboxname As String = "OrderCheckBox_" + ModuleId.ToString + "_" + oWebOrderListing(i).OrderNumber.ToString + "_" + oWebOrderListing(i).OrderLineNumber.ToString
                            If ControlValue(checkboxname).ToLower = "on" Then
                                testlist.Add(checkboxname)
                            End If
                        Next
                        If testlist.Count > 0 Then
                            For j As Integer = 0 To testlist.Count - 1
                                Dim parts() As String = testlist(j).ToString.Split(CChar("_"))
                                If parts.Length = 4 Then
                                    Dim monalj As New OrderNumberAndLine
                                    monalj.OrderNumber = parts(2)
                                    monalj.OrderLineNumber = parts(3)
                                    monal.Add(monalj)

                                    For i As Integer = 0 To oWebOrderListing.Count - 1
                                        Dim checkboxname As String = "OrderCheckBox_" + ModuleId.ToString + "_" + oWebOrderListing(i).OrderNumber.ToString + "_" + oWebOrderListing(i).OrderLineNumber.ToString
                                        If testlist(j).ToString = checkboxname Then
                                            ActualAmount += oWebOrderListing(i).BaseBalanceAmount
                                        End If
                                    Next
                                End If
                            Next
                        End If
                    End If


                End If
            End If

            If monal.Count > 0 AndAlso ActualAmount > 0 Then

                Dim strRememberMYCard As String
                Dim bRemembeMyCard As Boolean

                strRememberMYCard = ccControlValue(ccRememberMyInfoId)
                bRemembeMyCard = strRememberMYCard.Length > 0

                Dim strUsePreferredCard As String
                Dim bUsePreferredCard As Boolean = False
                strUsePreferredCard = ccControlValue(ccUseCCOnFileId)
                bUsePreferredCard = strUsePreferredCard.Length > 0

                Dim cc As New CreditCard

                cc.MasterCustomerId = MasterCustomerId
                cc.SubCustomerId = SubCustomerId
                cc.Cvv2 = ccControlValue(ccCVV2Id)
                cc.ActualAmount = ActualAmount

                Dim isEcheck As Boolean = False

                If Me.EditSetting_ECheckEnabled Then
                    For i As Integer = 0 To RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls.Count - 1
                        If RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "CreditCardForTabTemplate" Then
                            isEcheck = False
                        ElseIf RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "ECheckTemplate" Then
                            isEcheck = True
                        End If
                    Next
                Else
                    isEcheck = False
                End If

                If bUsePreferredCard = True Then

                    Dim oCCInfo As TIMSS.API.CustomerInfo.ICustomerCreditCards
                    oCCInfo = get_clsOrderCheckOutProcessHelper.GetCustomerCreditCardOnRecord(MasterCustomerId, SubCustomerId)

                    cc.Name = ccControlValue(ccNameonCardId)
                    cc.No = oCCInfo(0).CCReferenceDecrypted
                    cc.Type = oCCInfo(0).ReceiptTypeCodeString
                    cc.Year = Convert.ToInt32(ccControlValue(ccYearId))
                    cc.Month = Convert.ToInt32(ccControlValue(ccMonthId))
                    cc.rRememberMYCard = bRemembeMyCard
                    oCCInfo = Nothing
                Else
                    cc.Name = ccControlValue(ccNameonCardId) ' "Antonio"
                    cc.No = ccControlValue(ccNumberId) '"4111111111111111"
                    cc.Type = ccControlValue(ccTypeId) ' "VS"
                    If Not ccControlValue(ccYearId) = "" Then
                        cc.Year = Convert.ToInt32(ccControlValue(ccYearId)) '2007
                    End If

                    If Not ccControlValue(ccMonthId) = "" Then
                        cc.Month = Convert.ToInt32(ccControlValue(ccMonthId)) '12
                    End If
                    cc.rRememberMYCard = bRemembeMyCard
                End If

                Dim eck As New ECheck

                If isEcheck Then
                    cc.Name = ccControlValue(eckAccountNameId)
                    cc.Type = ccControlValue(eckTypeId)
                End If

                eck.AccountName = ccControlValue(eckAccountNameId)
                eck.ECheckType = ccControlValue(eckTypeId)
                eck.RoutingNumber = ccControlValue(eckRoutingNumberId)
                eck.AccountNumber = ccControlValue(eckAccountNumberId)
                eck.CheckNumber = ccControlValue(eckCheckNumberId)
                eck.IDType = ccControlValue("IDType")
                If ccControlValue("IDType") = "DL" Then
                    eck.DriversLicense = ccControlValue(eckDriversLicenseId)
                    eck.DriversLicenseState = ccControlValue(eckDriversLicenseState)
                Else
                    eck.FederalTaxId = ccControlValue(eckDriversLicenseId)
                    eck.DateOfBirth = ccControlValue(eckDriversLicenseState)
                End If

                eck.AccountType = ccControlValue(eckCheckTypeId)
                eck.ActualAmount = ActualAmount

                Dim Receipt As TIMSS.API.AccountingInfo.IARReceipts
                Dim Omonal(monal.Count - 1) As OrderNumberAndLine
                monal.CopyTo(Omonal)
                Dim Approved As Boolean = False

                Receipt = PayRenewals(Omonal, cc, eck, Approved)

                If Receipt(0).ValidationIssues.Count > 0 Then
                    oMessageControl.Clear()

                    oMessageControl.Show(Receipt.ValidationIssues)
                Else
                    'Skins.Skin.AddModuleMessage(Me, Localization.GetString("CannotSaveOrder", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    'ClearSessionObject( SessionManager.SessionKeys.PersonifyMembershipRenewalsViewList)
                    ClearSessionObject(SessionKeys.PersonifyOrdersViewList)

                    ' clear the cache

                    ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.BOTH.ToString)
                    ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.SHIP.ToString)
                    ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.BILL.ToString)

                    ClearSessionObject(SessionKeys.PersonifyMembershipRenewalsViewList)
                    ClearSessionObject(SessionKeys.PersonifyPayOrderIds)

                    Response.Redirect(NavigateURL(CType(Settings("PayOrders_Url"), Integer), "", "&RECEIPT=" & Receipt(0).ReceiptNumber.ToString))

                End If

                cc = Nothing
                eck = Nothing
            End If




        End Sub

        Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
            Dim ScriptPath As String = ResolveUrl(path)
            If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
                Dim script As System.Text.StringBuilder = New System.Text.StringBuilder
                script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
                script = Nothing
            End If
        End Sub

#End Region

#Region "Private Functions"
        Private Sub DisableValidateRequiredFields()
            Dim enable As Boolean = False
            For i As Integer = 0 To RadTabStrip1.Tabs.Count - 1
                If RadTabStrip1.Tabs(i).Selected Then
                    enable = True
                Else
                    enable = False
                End If
                For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                    If RadMultiPage1.PageViews(i).Controls(j).GetType.Name = "XslTemplate" Then
                        For k As Integer = 0 To RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls.Count - 1
                            If RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls(k).GetType.Name = "RequiredFieldValidator" Then
                                CType(RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls(k), System.Web.UI.WebControls.RequiredFieldValidator).Enabled = enable
                            End If
                        Next
                    End If
                Next
            Next
        End Sub

        Private Function ValidateTemplateFields() As Boolean

            If Me.EditSetting_ECheckEnabled Then

                Dim isECheck As Boolean = False
                For i As Integer = 0 To RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls.Count - 1
                    If RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "CreditCardForTabTemplate" Then
                        isECheck = False
                    ElseIf RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "ECheckTemplate" Then
                        isECheck = True
                    End If
                Next

                If Not isECheck Then
                    If Not ccControlValue(ccUseCCOnFileId).ToLower = "on" Then
                        If ccControlValue(ccTypeId) = "" Then
                            Return False
                        End If

                        Dim ccNumbervalue As String = ccControlValue(ccNumberId)
                        If ccNumbervalue = "" Then
                            Return False
                        ElseIf DoesContainCharacter(ccNumbervalue) Then
                            _ShowInvalidCardMsg = True
                            Return False
                        End If
                    End If

                    If ccControlValue(ccMonthId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccYearId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccNameonCardId) = "" Then
                        Return False
                    End If
                Else
                    If ccControlValue(eckTypeId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckCheckTypeId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckRoutingNumberId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckAccountNumberId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckCheckNumberId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckAccountNameId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckDriversLicenseId) = "" Then
                        Return False
                    End If

                    If Not ccControlValue("IDType") = "SSN" Then
                        If ccControlValue(eckDriversLicenseState) = "" Then
                            Return False
                        End If
                    Else
                        If ccControlValue(eckDriversLicenseState) = "" OrElse Not IsDate(ccControlValue(eckDriversLicenseState)) Then
                            Return False
                        End If
                    End If
                End If
                Return True
            Else
                If CreditCardTemplate IsNot Nothing Then
                    If ccControlValue(ccTypeId) = "" Then
                        Return False
                    End If

                    Dim ccNumbervalue As String = ccControlValue(ccNumberId)
                    If ccNumbervalue = "" Then
                        Return False
                    ElseIf DoesContainCharacter(ccNumbervalue) Then
                        _ShowInvalidCardMsg = True
                        Return False
                    End If

                    If ccControlValue(ccMonthId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccYearId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccNameonCardId) = "" Then
                        Return False
                    End If

                    Return True
                Else
                    Return False
                End If
            End If
        End Function

        Private Sub LoadPaymentTemplate()

            For i As Integer = 0 To RadMultiPage1.PageViews.Count - 1
                For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                    CreditCardTemplate = RadMultiPage1.PageViews(i).Controls(j).FindControl("CreditCardTemplate")
                    If CreditCardTemplate IsNot Nothing Then
                        Exit For
                    End If
                Next
                If CreditCardTemplate IsNot Nothing Then
                    Exit For
                End If
            Next



            If EditSetting_ECheckEnabled Then
                LoadCreditCardTemplate(CreditCardForTabTemplate)
                For i As Integer = 0 To RadMultiPage1.PageViews.Count - 1
                    For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                        ECheckTemplate = RadMultiPage1.PageViews(i).Controls(j).FindControl("ECheckTemplate")
                        If ECheckTemplate IsNot Nothing Then
                            Exit For
                        End If
                    Next
                    If ECheckTemplate IsNot Nothing Then
                        Exit For
                    End If
                Next

                LoadECheckTemplate()
            Else
                LoadCreditCardTemplate(CreditCardTemplate)
            End If

        End Sub

        Private Function CheckIfPostbackByButton(ByVal ButtonName As String) As Boolean

            'Dim strControlName As String = "btnUpdateCart_" + ModuleId.ToString

            'strControlName = ButtonName + "_" + ModuleId.ToString
            Dim bReturn As Boolean = False

            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(ButtonName) > 0 Then
                    bReturn = True
                    Exit For
                End If

            Next

            Return bReturn

        End Function
#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
            If Not oMessageControl Is Nothing Then
                oMessageControl.Clear()
            End If
        End Sub


#Region "PErsonify"
        Private Function GetRenewals(ByVal CustomerIDList() As CustomerID _
   ) As TIMSS.API.WebInfo.IWebRenewalListingViewList


            Dim oWebMembershipRenewals As TIMSS.API.WebInfo.IWebRenewalListingViewList

            oWebMembershipRenewals = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebRenewalListingViewList")

            With oWebMembershipRenewals.Filter

                Dim ShipCustomerFilter As String = String.Empty
                If CustomerIDList.Length > 0 Then
                    For i As Integer = 0 To CustomerIDList.Length - 1
                        If i > 0 Then
                            ShipCustomerFilter += " or "
                        End If
                        ShipCustomerFilter += "( Ship_Master_Customer_id = '" + CustomerIDList(i).MasterCustomerId.ToString + "' and Ship_Sub_Customer_Id = " + CustomerIDList(i).SubCustomerId.ToString + " )"
                    Next
                End If

                .Add(New TIMSS.API.Core.FilterItem(ShipCustomerFilter))
                .Add("CurrencyCode", PortalCurrency.Code)
                oWebMembershipRenewals.Sort("ORDER_NO", ComponentModel.ListSortDirection.Ascending)
                oWebMembershipRenewals.Sort("ORDER_LINE_NO", ComponentModel.ListSortDirection.Ascending)

                oWebMembershipRenewals.Fill()


            End With

            Return oWebMembershipRenewals



        End Function

        Private Function GetOrders(ByVal BillMasterCustomerID As String _
          , ByVal BillSubCustomerID As Integer _
         ) As TIMSS.API.WebInfo.IWebOrderBalanceViewList

            Dim oWebOrderBalance As TIMSS.API.WebInfo.IWebOrderBalanceViewList




            oWebOrderBalance = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebOrderBalanceViewList")

            With oWebOrderBalance.Filter

                Dim ShipCustomerFilter As String = String.Empty
                ShipCustomerFilter += "( Bill_Master_Customer_id = '" + BillMasterCustomerID.ToString + "' and Bill_Sub_Customer_Id = " + BillSubCustomerID.ToString + " )"

                .Add(New TIMSS.API.Core.FilterItem(ShipCustomerFilter))
                .Add("CurrencyCode", PortalCurrency.Code)
                oWebOrderBalance.Sort("ORDER_NO", ComponentModel.ListSortDirection.Ascending)
                oWebOrderBalance.Sort("ORDER_LINE_NO", ComponentModel.ListSortDirection.Ascending)

                oWebOrderBalance.Fill()

            End With

            Return oWebOrderBalance



        End Function


        Private Function PayRenewals(ByVal ManyOrderNumberAndLine() As OrderNumberAndLine _
, ByVal oneCC As CreditCard _
, ByVal oneECK As ECheck _
, ByRef Approved As Boolean _
  ) As TIMSS.API.AccountingInfo.IARReceipts




            Dim oAppOrgUnits As TIMSS.API.ApplicationInfo.IApplicationOrganizationUnits
            Dim oFarReceipts As TIMSS.API.AccountingInfo.IARReceipts
            Dim oFarReceipt As TIMSS.API.AccountingInfo.IARReceipt
            Dim bAuthorizationSuccess As Boolean = False

            oAppOrgUnits = TIMSS.API.CachedApplicationData.ApplicationDataCache.ApplicationOrganizationUnits(OrganizationId, OrganizationUnitId)

            oAppOrgUnits(0).SetCurrentECommerceBatch()

            oFarReceipts = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.AccountingInfo, "ARReceipts")
            oFarReceipt = oFarReceipts.AddNew

            With oFarReceipt

                .BillMasterCustomerId = oneCC.MasterCustomerId ' "000000003133"
                .BillSubCustomerId = oneCC.SubCustomerId ' 0
                .MasterCustomerId = oneCC.MasterCustomerId '"000000003133"
                .SubCustomerId = oneCC.SubCustomerId '0

                .ActualAmount = oneCC.ActualAmount '270
                '.ReceiptTypeCode = .ReceiptTypeCode.List("VS").ToCodeObject
                .ReceiptTypeCode = .ReceiptTypeCode.List(oneCC.Type).ToCodeObject
                .CCReferenceDecrypted = oneCC.No ' "4111111111111111"

                .CCExpirationDate = New Date(oneCC.Year, oneCC.Month, 1)
                'Date.Today

                .CCName = oneCC.Name '"Antonio"
                '.CCAddress1 = oneCC.Address1 ' "123 Main Street"
                .CCAddress1 = .BillToCustomer.PrimaryAddress.Address.Address1

                .CCCity = .BillToCustomer.PrimaryAddress.Address.City  ' "Vienna"
                .CCState = .BillToCustomer.PrimaryAddress.Address.State  ' "VA"
                .CCPostalCode = .BillToCustomer.PrimaryAddress.Address.PostalCode  ' "22182"
                .CCCountryCode = .BillToCustomer.PrimaryAddress.Address.CountryCode.Code    ' "USA"

                'for ECheck
                .BankRoutingNumber = oneECK.RoutingNumber
                .BankAccountNumber = oneECK.AccountNumber
                .PersonalIdentifier = oneECK.IDType
                .DriversLicenseStateCode = oneECK.DriversLicenseState '??
                .DriversLicenseNumber = oneECK.DriversLicense
                .FederalTaxId = oneECK.FederalTaxId
                If Not String.IsNullOrEmpty(oneECK.DateOfBirth) Then
                    .BirthDate = CType(oneECK.DateOfBirth, Date)
                End If
                .CheckReference = oneECK.CheckNumber
                If oneECK.AccountType IsNot "" Then
                    .CheckTypeCode = .CheckTypeCode.List(oneECK.AccountType).ToCodeObject
                End If
                'raps iSSUE - mOVE THIS TO AFTER APPLYCASH METHOD BECAUSE AUTHCARD NEEDS ORDER NUMBER
                'commentD00030855 

                'If ConfigurationManager.AppSettings("CreditCardAuthorization") IsNot Nothing AndAlso ConfigurationManager.AppSettings("CreditCardAuthorization").ToUpper = "OFF" Then
                '    .ReceiptStatusCode = .ReceiptStatusCode.List("A").ToCodeObject
                'Else
                '    .AuthorizeCreditCard()
                'End If

                ''The authorization fails here. There is a blank message in the Validation issues
                'If oFarReceipts.ValidationIssues.Count > 0 Then
                '    ''''
                'End If

                'If oFarReceipts(0).CCAuthorization.Length > 0 Then
                '    bAuthorizationSuccess = True
                'Else
                '    If ConfigurationManager.AppSettings("CreditCardAuthorization") IsNot Nothing AndAlso ConfigurationManager.AppSettings("CreditCardAuthorization").ToUpper = "OFF" Then

                '    Else

                '    End If
                'End If


                'If ConfigurationManager.AppSettings("CreditCardAuthorization") IsNot Nothing AndAlso ConfigurationManager.AppSettings("CreditCardAuthorization").ToUpper = "OFF" Then
                '    bAuthorizationSuccess = True
                'End If


                '.ReceiptStatusCode = .ReceiptStatusCode.List("A").ToCodeObject

                'If bAuthorizationSuccess Then
                If ManyOrderNumberAndLine IsNot Nothing AndAlso ManyOrderNumberAndLine.Length > 0 Then

                    For i As Integer = 0 To ManyOrderNumberAndLine.Length - 1
                        .AddOrderLineToPayWithReceipt(ManyOrderNumberAndLine(i).OrderNumber, ManyOrderNumberAndLine(i).OrderLineNumber)

                    Next

                End If


                oFarReceipt.ApplyCash(oneCC.ActualAmount)

                If ConfigurationManager.AppSettings("CreditCardAuthorization") IsNot Nothing AndAlso ConfigurationManager.AppSettings("CreditCardAuthorization").ToUpper = "OFF" Then
                    .ReceiptStatusCode = .ReceiptStatusCode.List("A").ToCodeObject
                Else
                    Approved = .AuthorizeCreditCard()
                End If

                'End If
            End With
            'AUTHORIZE CARD AND THEN SAVE



            oFarReceipts.Save()

            If oFarReceipts.ValidationIssues.Count = 0 Then

                'NOTE - this method does not save the record. It adds it to the collection.
                'You have to call the save method
                If oneCC.rRememberMYCard AndAlso oFarReceipts(0).PayorCanMakeThisCreditCardOfRecord Then
                    oFarReceipts(0).SaveCreditCardOfRecord()
                End If



            End If
            Return oFarReceipts


        End Function

#End Region

#Region "Helper function"

        Private Function DoesContainCharacter(ByVal value As String) As Boolean
            Try
                Dim compare As Long
                compare = CType(value, Long)
            Catch ex As Exception
                Return True
            End Try

            Return False
        End Function

#End Region

    End Class


End Namespace
