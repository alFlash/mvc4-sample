Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO

Namespace Personify.DNN.Modules.PayOrders

	Public MustInherit Class PayOrdersEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
		Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

		Protected WithEvents Urlcontrol_PayOrdersUrl As DotNetNuke.UI.UserControls.UrlControl
		Protected WithEvents DropDownListPayOrdersTemplate As DropDownList
		Protected WithEvents DropDownListCCTemplate As DropDownList
        Protected WithEvents DropDownListPayOrdersMode As DropDownList
        Protected WithEvents ddlECheckTemplate As DropDownList
        Protected WithEvents ddlEnableECheck As DropDownList

#End Region

#Region "Private Members"

#End Region

#Region "Event Handlers"
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
                If Not Page.IsPostBack Then

                    Dim PayOrdersURL As String = String.Empty
                    Dim PayOrdersTemplate As String = String.Empty
                    Dim CCTemplate As String = String.Empty
                    Dim ECheckTemplate As String = String.Empty
                    Dim PayOrdersMode As String = String.Empty
                    Dim EnableECheck As String = String.Empty


                    Dim objMS As Hashtable
                    Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
                    objMS = objMC.GetModuleSettings(ModuleId)
                    If objMS(ModuleSettingsNames.C_PayOrdersURL) IsNot Nothing Then
                        PayOrdersURL = CType(objMS(ModuleSettingsNames.C_PayOrdersURL), String)
                    End If
                    Urlcontrol_PayOrdersUrl.Url = PayOrdersURL

                    If objMS(ModuleSettingsNames.C_PayOrdersMode) IsNot Nothing Then
                        PayOrdersMode = CType(objMS(ModuleSettingsNames.C_PayOrdersMode), String)
                    End If

                    If objMS(ModuleSettingsNames.C_PayOrdersTEMPLATE) IsNot Nothing Then
                        PayOrdersTemplate = CType(objMS(ModuleSettingsNames.C_PayOrdersTEMPLATE), String)
                    End If

                    If objMS(ModuleSettingsNames.C_CCTEMPLATE) IsNot Nothing Then
                        CCTemplate = CType(objMS(ModuleSettingsNames.C_CCTEMPLATE), String)
                    End If

                    If objMS(ModuleSettingsNames.C_ECHECKTEMPLATE) IsNot Nothing Then
                        ECheckTemplate = CType(objMS(ModuleSettingsNames.C_ECHECKTEMPLATE), String)
                    End If

                    If objMS(ModuleSettingsNames.C_ENABLEECHECK) IsNot Nothing Then
                        EnableECheck = CType(objMS(ModuleSettingsNames.C_ENABLEECHECK), String)
                    End If

                    Dim li As ListItem
                    For Each li In GetTemplates()
                        DropDownListPayOrdersTemplate.Items.Add(li)
                    Next

                    For Each li In GetTemplates()
                        DropDownListCCTemplate.Items.Add(li)
                    Next

                    For Each li In GetTemplates()
                        ddlECheckTemplate.Items.Add(li)
                    Next

                    DropDownListPayOrdersMode.Items.Add(New ListItem("Pay Orders", "0"))
                    DropDownListPayOrdersMode.Items.Add(New ListItem("Pay Renewals", "1"))
                    DropDownListPayOrdersMode.SelectedIndex = DropDownListPayOrdersMode.Items.IndexOf(DropDownListPayOrdersMode.Items.FindByValue(PayOrdersMode))

                    ddlEnableECheck.Items.Add(New ListItem("True", "Y"))
                    ddlEnableECheck.Items.Add(New ListItem("False", "N"))
                    ddlEnableECheck.SelectedIndex = ddlEnableECheck.Items.IndexOf(ddlEnableECheck.Items.FindByValue(EnableECheck))

                    DropDownListPayOrdersTemplate.SelectedIndex = DropDownListPayOrdersTemplate.Items.IndexOf(DropDownListPayOrdersTemplate.Items.FindByValue(PayOrdersTemplate))
                    DropDownListCCTemplate.SelectedIndex = DropDownListCCTemplate.Items.IndexOf(DropDownListCCTemplate.Items.FindByValue(CCTemplate))
                    ddlECheckTemplate.SelectedIndex = ddlECheckTemplate.Items.IndexOf(ddlECheckTemplate.Items.FindByValue(ECheckTemplate))

                End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Function GetTemplates() As ListItemCollection
			Try
				Dim lic As New ListItemCollection
				Dim ListItem As ListItem
				' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & ModuleSettingsNames.C_TEMPLATES)))
				' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(ModuleSettingsNames.C_FILEPATTERN)
				Dim fiTemp As FileInfo
				For Each fiTemp In fInfo
					ListItem = New ListItem
					ListItem.Text = fiTemp.Name
					ListItem.Value = fiTemp.Name
					lic.Add(ListItem)
				Next fiTemp
				Return lic

			Catch ex As Exception
				Throw ex
			End Try
		End Function


		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try
				' Only Update if the Entered Data is Valid
				If Page.IsValid = True Then

                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

                    UpdateModuleSetting(ModuleSettingsNames.C_PayOrdersURL, CType(Urlcontrol_PayOrdersUrl.Url, String))
                    UpdateModuleSetting(ModuleSettingsNames.C_PayOrdersMode, CType(DropDownListPayOrdersMode.SelectedValue, String))
                    UpdateModuleSetting(ModuleSettingsNames.C_PayOrdersTEMPLATE, CType(DropDownListPayOrdersTemplate.SelectedValue, String))
                    UpdateModuleSetting(ModuleSettingsNames.C_CCTEMPLATE, CType(DropDownListCCTemplate.SelectedValue, String))
                    UpdateModuleSetting(ModuleSettingsNames.C_ECHECKTEMPLATE, CType(ddlECheckTemplate.SelectedValue, String))
                    UpdateModuleSetting(ModuleSettingsNames.C_ENABLEECHECK, CType(ddlEnableECheck.SelectedValue, String))

					' Redirect back to the portal home page
					Response.Redirect(NavigateURL(), True)
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try

				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
