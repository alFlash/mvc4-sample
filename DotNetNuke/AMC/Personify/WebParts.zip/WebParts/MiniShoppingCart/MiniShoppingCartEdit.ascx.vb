Imports System
Imports System.Web.UI.WebControls
Imports Personify
Imports Personify.ShoppingCartManager.Business

Namespace Personify.DNN.Modules.MiniShoppingCart

    Public MustInherit Class MiniShoppingCartEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents ctlURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlCheckoutUrl As DotNetNuke.UI.UserControls.UrlControl
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    ctlURL.UrlType = CType(Settings("ShoppingCartUrlType"), String)
                    ctlURL.Url = CType(Settings("ShoppingCartUrl"), String)
                    ctlCheckoutUrl.UrlType = CType(Settings("CheckoutUrlType"), String)
                    ctlCheckoutUrl.Url = CType(Settings("CheckoutUrl"), String)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                   UpdateModuleSetting( "ShoppingCartUrl", ctlURL.Url)
                   UpdateModuleSetting( "ShoppingCartUrlType", ctlURL.UrlType)
                   UpdateModuleSetting( "CheckoutUrl", ctlCheckoutUrl.Url)
                  UpdateModuleSetting( "CheckoutUrlType", ctlCheckoutUrl.UrlType)
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                If Not Null.IsNull(itemId) Then

                End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
