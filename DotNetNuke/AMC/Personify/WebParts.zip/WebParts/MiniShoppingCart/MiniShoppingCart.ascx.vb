Imports System
Imports System.Web.UI.WebControls
Imports Personify.ShoppingCartManager.Business
Imports Personify

Namespace Personify.DNN.Modules.MiniShoppingCart

    Public MustInherit Class MiniShoppingCart
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Implements Entities.Modules.Communications.IModuleListener

#Region "Controls"
        Protected WithEvents lblMiniCart As System.Web.UI.WebControls.Label
        Protected WithEvents hlViewCart As System.Web.UI.WebControls.HyperLink
        Protected WithEvents hlCheckout As System.Web.UI.WebControls.HyperLink
#End Region

#Region "Private Variables"
        Private SessionId As String
        'Private MasterCustomerId As String
        'Private SubCustomerId As Integer
#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'If Not Page.IsPostBack Then
                LoadMiniCart()

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub Pre_Render(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            Try
                'If Not Page.IsPostBack Then
                LoadMiniCart()

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadMiniCart()
            Dim oMiniShoppingCart As New ShoppingCartController
            Dim oCartInfo As New MiniShoppingCartInfo
            oCartInfo = oMiniShoppingCart.GetMiniShoppingCart(MasterCustomerId, SubCustomerId)
            lblMiniCart.Text = String.Format(Localization.GetString("lblMiniCart", LocalResourceFile), oCartInfo.ShoppingCartItems.ToString, Me.PortalCurrency.Symbol, oCartInfo.ShoppingCartTotal.ToString)
            oCartInfo = Nothing
            oMiniShoppingCart = Nothing

            hlViewCart.NavigateUrl = "~/default.aspx?tabid=" & CType(Settings("ShoppingCartUrl"), String)
            hlCheckout.NavigateUrl = "~/default.aspx?tabid=" & CType(Settings("CheckoutUrl"), String)
        End Sub

#End Region

#Region "Optional Interfaces"
       
        Public Sub OnModuleCommunication(ByVal s As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleListener.OnModuleCommunication
            Try
                If e.Text.ToLower = "updateminicart" Then
                    LoadMiniCart()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
