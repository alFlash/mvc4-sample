Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.PrintRoster.Business
Imports Personify.ApplicationManager.AffiliateManagementSessionHelper

Namespace Personify.DNN.Modules.PrintRoster

    Public MustInherit Class PrintRoster
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable

#Region "Controls"
        Protected WithEvents lnkAffiliateList As System.Web.UI.WebControls.HyperLink
        Protected WithEvents btnPrint As System.Web.UI.WebControls.Button
        Protected WithEvents pnlHeader As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMembers As System.Web.UI.WebControls.Panel
        Protected WithEvents xslMembersView As WebControls.XslTemplate

        Protected WithEvents lblSegmentDesc As System.Web.UI.WebControls.Label

        Dim segmentinfo As SegmentInfo
        Dim SegmentType As String = String.Empty
        Dim qualifier1 As String = String.Empty
        Dim qualifier2 As String = String.Empty
        Dim affiliateListTabId As Integer = 0
        Private m_EventTarget As String

#End Region

#Region "Constants"
        Private Const C_AFFILIATE_LIST_ACTION_URL As String = "AffiliateListActionURL"
        Private Const C_SEGMENT_EMPLOYEE As String = "EMPLOYEE"
        Private Const C_SEGMENT_MEMBERSHIP As String = "MEMBERSHIP"
        Private Const C_SEGMENT_GEOGRAPHIC As String = "GEOGRAPHY"
        Private Const C_SEGMENT_COMMITTEE As String = "COMMITTEE"
        Private Const C_SEGMENT_MISCELLANEOUS As String = "MISCELLANEOUS"
#End Region

#Region "Properties"
        Public Property EventTarget() As String
            Get
                If (m_EventTarget Is Nothing) Then
                    Return String.Empty
                Else
                    Return m_EventTarget
                End If
            End Get
            Set(ByVal Value As String)
                m_EventTarget = Value
            End Set
        End Property
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    'get current segment information
                    segmentinfo = GetCurrentSegmentInfo(PortalId)
                    qualifier1 = segmentinfo.SegmentQualifier1
                    qualifier2 = segmentinfo.SegmentQualifier2
                    SegmentType = segmentinfo.SegmentType
                    affiliateListTabId = segmentinfo.AffiliateListTabId

                    lblSegmentDesc.Text = segmentinfo.SegmentDescr

                    If Not Page.IsPostBack And (qualifier1 = String.Empty Or qualifier2 = String.Empty Or SegmentType = String.Empty) Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingSegmentInformation", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        Exit Sub
                    End If
                    InitializeControls()

                Else 'The current user does not have these attributes
                    pnlHeader.Visible = False
                    pnlMembers.Visible = False
                   DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
            'when Print button is pressed go back to AffiliateList tab
            Response.Redirect(NavigateURL(affiliateListTabId))

        End Sub

#End Region

#Region "Optional Interfaces"

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
        '    ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
        '    ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        'End Sub

        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
        ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        'End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
#Region "Helper Functions"
        Private Sub InitializeControls()
            EventTarget = Request.Params("__EVENTTARGET")
            If Not Page.IsPostBack Then
                'segment description in the Header panel
                pnlHeader.Visible = True
            End If

            Dim members() As GroupActionListInfo = Nothing
            'get the items for the current segment (based on segment type)
            Select Case SegmentType
                Case C_SEGMENT_EMPLOYEE
                    members = BuildGroupActionEmployeeSegmentAffiliateList()
                Case C_SEGMENT_MEMBERSHIP
                    members = BuildGroupActionMembershipProductSegmentAffiliateList()
                Case C_SEGMENT_GEOGRAPHIC
                    members = BuildGroupActionGeographySegmentAffiliateList()
                Case C_SEGMENT_COMMITTEE
                    members = BuildGroupActionCommitteeSegmentAffiliateList()
                Case C_SEGMENT_MISCELLANEOUS
                    members = BuildGroupActionMiscellaneousSegmentAffiliateList()
            End Select



            'set the template file
            xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/PrintRosterTemplate.xsl")
            xslMembersView.AddObject("", members)
            xslMembersView.Display()

            'set the onclick attribute for Print button to trigger the JavaScript function PrintWindow
            btnPrint.Attributes.Add("onclick", "PrintWindow(this)")

            lnkAffiliateList.NavigateUrl = NavigateURL(affiliateListTabId)

        End Sub

#End Region
#Region "Group Action Build List"
        Private Function BuildGroupActionCommitteeSegmentAffiliateList() As GroupActionListInfo()
            'get AffiliateGroupActionInfo - selected items
            Dim arrGroupActionInfo() As GroupActionAffiliateInfo = GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            'build a comma separated array of selected cucstomerIds
            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList

            'get the selected items(the comma separated array customerIDs) for current segment
            Dim _clsAffMgmt As New Personify.ApplicationManager.AffiliateManagement(OrganizationId, OrganizationUnitId)
            oMembers = _clsAffMgmt.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, customerIDs)
            _clsAffMgmt = Nothing
            Dim SortCriteria As String = String.Empty
            'find the sorting criteria
            If Not (EventTarget Is Nothing) Then
                If EventTarget.IndexOf("btnAddress") >= 0 Then
                    SortCriteria = "City"
                End If
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                End If

                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                End If

                If EventTarget.IndexOf("btnEmail") >= 0 Then
                    SortCriteria = "PrimaryEmailAddress"
                End If
            End If
            oMembers.Sort(SortCriteria)

            'build an array of GroupActionListInfo items based on selected items info
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function

        Private Function BuildGroupActionEmployeeSegmentAffiliateList() As GroupActionListInfo()
            'get AffiliateGroupActionInfo - selected items
            Dim arrGroupActionInfo() As GroupActionAffiliateInfo = GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            'build a comma separated array of selected cucstomerIds
            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList
            'get the selected items(the comma separated array customerIDs) for current segment
            Dim _clsAffMgmt As New Personify.ApplicationManager.AffiliateManagement(OrganizationId, OrganizationUnitId)
            oMembers = _clsAffMgmt.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, customerIDs)
            _clsAffMgmt = Nothing

            Dim SortCriteria As String = String.Empty
            'find the sorting criterias
            If Not (EventTarget Is Nothing) Then
                If EventTarget.IndexOf("btnLocation") >= 0 Then
                    SortCriteria = "City"
                End If
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                End If

                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                End If
            End If
            oMembers.Sort(SortCriteria)

            'build an array of GroupActionListInfo items based on selected items info
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function

        Private Function BuildGroupActionGeographySegmentAffiliateList() As GroupActionListInfo()
            'get AffiliateGroupActionInfo - selected items
            Dim arrGroupActionInfo() As GroupActionAffiliateInfo = GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            'build a comma separated array of selected cucstomerIds
            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
            'get the selected items(the comma separated array customerIDs) for current segment
            Dim _clsAffMgmt As New Personify.ApplicationManager.AffiliateManagement(OrganizationId, OrganizationUnitId)



            oMembers = _clsAffMgmt.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, customerIDs)
            _clsAffMgmt = Nothing
            'find the sorting criterias
            Dim SortCriteria As String = String.Empty
            If Not (EventTarget Is Nothing) Then
                If EventTarget.IndexOf("btnLocation") >= 0 Then
                    SortCriteria = "City"
                End If
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                End If

                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                End If
            End If
            oMembers.Sort(SortCriteria)

            'build an array of GroupActionListInfo items based on selected items info
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function

        Private Function BuildGroupActionMembershipProductSegmentAffiliateList() As GroupActionListInfo()
            'get AffiliateGroupActionInfo - selected items
            Dim arrGroupActionInfo() As GroupActionAffiliateInfo = GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            'build a comma separated array of selected cucstomerIds
            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
            'get the selected items(the comma separated array customerIDs) for current segment
            Dim _clsAffMgmt As New Personify.ApplicationManager.AffiliateManagement(OrganizationId, OrganizationUnitId)
            oMembers = _clsAffMgmt.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, customerIDs)
            _clsAffMgmt = Nothing
            'find the sorting criteria
            Dim SortCriteria As String = String.Empty
            If Not (EventTarget Is Nothing) Then
                If EventTarget.IndexOf("btnLocation") >= 0 Then
                    SortCriteria = "City"
                End If
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                End If

                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                End If
            End If
            oMembers.Sort(SortCriteria)

            'build an array of GroupActionListInfo items based on selected items info
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function

        Private Function BuildGroupActionMiscellaneousSegmentAffiliateList() As GroupActionListInfo()
            'get AffiliateGroupActionInfo - selected items
            Dim arrGroupActionInfo() As GroupActionAffiliateInfo = GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            'build a comma separated array of selected cucstomerIds
            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList
            'get the selected items(the comma separated array customerIDs) for current segment
            Dim _clsAffMgmt As New Personify.ApplicationManager.AffiliateManagement(OrganizationId, OrganizationUnitId)

            oMembers = _clsAffMgmt.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, customerIDs)
            _clsAffMgmt = Nothing
            'find the sorting criteria
            Dim SortCriteria As String = String.Empty
            If Not (EventTarget Is Nothing) Then
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                End If
                If EventTarget.IndexOf("btnProduct") >= 0 Then
                    SortCriteria = "ShortName"
                End If
                If EventTarget.IndexOf("btnPurchaseDate") >= 0 Then
                    SortCriteria = "OrderDate"
                End If
            End If
            oMembers.Sort(SortCriteria)

            'build an array of GroupActionListInfo items based on selected items info
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                ' Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function
#End Region
#Region "GroupActionListInfo"
        ' This class will be used to store information about each GroupAction member
        Public Class GroupActionListInfo
            Public Name As String
            Public Address As String
            Public Phone As String
            Public Email As String
        End Class
#End Region
    End Class

End Namespace
