Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Web.UI.HtmlControls
Imports System.Text
Imports Personify.ApplicationManager

Namespace Personify.DNN.Modules.AffiliateSegmentList
    <Description(""), ToolboxData("<{0}:Segment runat=server></{0}:Segment>")> _
    Public Class Segment
        Inherits CompositeControl



#Region " Controls "

        Private lnkListAll As LinkButton
        Private lnkAddMember As LinkButton
        Private lnkRenewAll As LinkButton
        Private lnkBuyProduct As LinkButton

        'Add Member controls
        'Private txtAddMemberLastName As TextBox
        'Private lblAddMemberLastName As Label

        'Private txtAddMemberFirstName As TextBox
        'Private lblAddMemberFirstName As Label

        'Private txtAddMemberState As TextBox
        'Private lblAddMemberState As Label
        'Private WithEvents ddlAddMemberState As Personify.WebControls.StateDropDownList

        'Private txtAddMemberCity As TextBox
        'Private lblAddMemberCity As Label

        'Private WithEvents lstAddMemberCountry As Personify.WebControls.CountryDropDownList
        'Private lblAddMemberCountry As Label


        Private uniqId As HiddenField
        Private m_EventTarget As String
        Private m_AddMemberStateDefault As String
        Private m_AddMemberCountryDefault As String

#End Region

#Region "Controls Properties"


        <Bindable(False), Category("Appearance"), Description("List All")> _
        Public Property ListAllCaption() As String
            Get
                Return CStr(ViewState("ListAllCaption"))
            End Get

            Set(ByVal value As String)
                ViewState("ListAllCaption") = value
            End Set

        End Property
        Public Property ListAllNavigateUrl() As String
            Get
                Return CStr(ViewState("ListAllNavigateUrl"))
            End Get
            Set(ByVal value As String)
                ViewState("ListAllNavigateUrl") = value
            End Set

        End Property

        Public Property AddMemberCaption() As String
            Get
                Return CStr(ViewState("AddMemberCaption"))
            End Get

            Set(ByVal value As String)
                ViewState("AddMemberCaption") = value
            End Set

        End Property
        Public Property AddMemberNavigateUrl() As String
            Get
                Return CStr(ViewState("AddMemberNavigateUrl"))
            End Get
            Set(ByVal value As String)
                ViewState("AddMemberNavigateUrl") = value
            End Set

        End Property

        Public Property RenewAllCaption() As String
            Get
                Return CStr(ViewState("RenewAllCaption"))
            End Get

            Set(ByVal value As String)
                ViewState("RenewAllCaption") = value
            End Set

        End Property
        Public Property RenewAllNavigateUrl() As String
            Get
                Return CStr(ViewState("RenewAllNavigateUrl"))
            End Get
            Set(ByVal value As String)
                ViewState("RenewAllNavigateUrl") = value
            End Set

        End Property

        Public Property BuyProductCaption() As String
            Get
                Return CStr(ViewState("BuyProductCaption"))
            End Get

            Set(ByVal value As String)
                ViewState("BuyProductCaption") = value
            End Set

        End Property
        Public Property BuyProductNavigateUrl() As String
            Get
                Return CStr(ViewState("BuyProductNavigateUrl"))
            End Get
            Set(ByVal value As String)
                ViewState("BuyProductNavigateUrl") = value
            End Set

        End Property
        Public Property AffiliateListGroupPurchaseTabId() As Integer
            Get
                Return CInt(ViewState("AffiliateListGroupPurchaseTabId"))
            End Get
            Set(ByVal value As Integer)
                ViewState("AffiliateListGroupPurchaseTabId") = value
            End Set
        End Property

        'Public Property AddMemberFirstNameLabel() As String
        '    Get
        '        Return CStr(ViewState("AddMemberFirstNameLabel"))
        '    End Get

        'Set(ByVal value As String)
        '   ViewState("AddMemberFirstNameLabel") = value
        'End Set

        'End Property
        'Public Property AddMemberLastNameLabel() As String
        '    Get
        '        Return CStr(ViewState("AddMemberLastNameLabel"))
        '    End Get
        '    Set(ByVal value As String)
        '        ViewState("AddMemberLastNameLabel") = value
        '    End Set

        'End Property
        'Public Property AddMemberFirstNameValue() As String
        '    Get
        '        EnsureChildControls()
        '        Return txtAddMemberFirstName.Text
        '    End Get

        'Set(ByVal value As String)
        '   EnsureChildControls()
        '  txtAddMemberFirstName.Text = value
        'End Set

        'End Property
        'Public Property AddMemberLastNameValue() As String
        '    Get
        '        EnsureChildControls()
        '        Return txtAddMemberLastName.Text
        '    End Get
        '    Set(ByVal value As String)
        '        EnsureChildControls()
        '        txtAddMemberLastName.Text = value
        '    End Set

        'End Property


        'Public Property AddMemberStateLabel() As String
        '    Get
        '        Return CStr(ViewState("AddMemberStateLabel"))
        '    End Get

        'Set(ByVal value As String)
        'ViewState("AddMemberStateLabel") = value
        'End Set

        'End Property
        'Public Property AddMemberStateValue() As String
        'Get
        'If ddlAddMemberState Is Nothing Then
        'Return ""
        'Else
        ' ddlAddMemberState.SelectedValue
        ' End If
        'End Get
        'Set(ByVal value As String)
        'If ddlAddMemberState Is Nothing Then

        'Else
        'ddlAddMemberState.SelectedValue = value
        'End If

        'End Set
        'End Property

        'Public Property AddMemberCityLabel() As String
        '    Get
        '        Return CStr(ViewState("AddMemberCityLabel"))
        '    End Get
        '    Set(ByVal value As String)
        '        ViewState("AddMemberCityLabel") = value
        '    End Set

        'End Property

        'Public WriteOnly Property AddMemberStateDefault() As String
        '    Set(ByVal value As String)
        '        m_AddMemberStateDefault = value
        '    End Set

        'End Property
        'Public Property AddMemberCityValue() As String
        '    Get
        '        EnsureChildControls()
        '        Return txtAddMemberCity.Text
        '    End Get
        '    Set(ByVal value As String)
        '        EnsureChildControls()
        '       txtAddMemberCity.Text = value
        '   End Set

        'End Property
        'Public Property AddMemberCountryLabel() As String
        '    Get
        '        Return CStr(ViewState("AddMemberCountryLabel"))
        '    End Get
        '    Set(ByVal value As String)
        '        ViewState("AddMemberCountryLabel") = value
        '    End Set

        'End Property
        'Public WriteOnly Property AddMemberCountryDefault() As String
        '    Set(ByVal value As String)
        '        m_AddMemberCountryDefault = value
        '    End Set

        'End Property
        'Public Property AddMemberCountryValue() As String
        '    Get
        '        EnsureChildControls()

        '        If lstAddMemberCountry Is Nothing Then
        '            Return ""
        '        Else
        '            Return lstAddMemberCountry.SelectedValue
        '        End If
        '    End Get
        '    Set(ByVal value As String)
        '        EnsureChildControls()
        '        If lstAddMemberCountry Is Nothing Then

        '        Else
        '            lstAddMemberCountry.SelectedValue = value
        '        End If

        'End Set
        'End Property
        'Public Property AddMemberAddCaption() As String
        '    Get
        '        Return CStr(ViewState("AddMemberAddCaption"))
        '    End Get
        '    Set(ByVal value As String)
        '        ViewState("AddMemberAddCaption") = value
        '    End Set

        'End Property


        'Public Property IsAddMember() As Boolean
        '    Get
        '        If ViewState("IsAddMember") Is Nothing Then
        '            Return False
        '        Else
        '            Return CBool(ViewState("IsAddMember"))
        '        End If
        '    End Get
        '    Set(ByVal value As Boolean)
        '        ViewState("IsAddMember") = value

        '       HideShowAddMemberFields(value)

        'End Set


        'End Property

        Public Property SegmentQualifier1() As String
            Get
                Return CStr(ViewState("SegmentQualifier1"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentQualifier1") = value
            End Set

        End Property

        Public Property SegmentQualifier2() As String
            Get
                Return CStr(ViewState("SegmentQualifier2"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentQualifier2") = value
            End Set

        End Property
        Public Property SegmentType() As String
            Get
                Return CStr(ViewState("SegmentType"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentType") = value
            End Set

        End Property

        Public Property Subsystem() As String
            Get
                Return CStr(ViewState("Subsystem"))
            End Get
            Set(ByVal value As String)
                ViewState("Subsystem") = value
            End Set

        End Property
        Public Property SegmentOwnerMasterCustomerId() As String
            Get
                Return CStr(ViewState("SegmentOwnerMasterCustomerId"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentOwnerMasterCustomerId") = value
            End Set

        End Property

        Public Property SegmentOwnerSubCustomerId() As String
            Get
                Return CStr(ViewState("SegmentOwnerSubCustomerId"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentOwnerSubCustomerId") = value
            End Set

        End Property

        Public Property SegmentDescr() As String
            Get
                Return CStr(ViewState("SegmentDescr"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentDescr") = value
            End Set

        End Property

        Public Property ReadOnlyFlag() As Boolean
            Get
                Return CBool(ViewState("ReadOnlyFlag"))
            End Get
            Set(ByVal value As Boolean)
                ViewState("ReadOnlyFlag") = value
            End Set

        End Property

        Public Property CanAddMemberFlag() As Boolean
            Get
                Return CBool(ViewState("CanAddMemberFlag"))
            End Get
            Set(ByVal value As Boolean)
                ViewState("CanAddMemberFlag") = value
            End Set

        End Property

        Public Property CanRemoveMemberFlag() As Boolean
            Get
                Return CBool(ViewState("CanRemoveMemberFlag"))
            End Get
            Set(ByVal value As Boolean)
                ViewState("CanRemoveMemberFlag") = value
            End Set

        End Property

        Public Property CanPlaceOrderFlag() As Boolean
            Get
                Return CBool(ViewState("CanPlaceOrderFlag"))
            End Get
            Set(ByVal value As Boolean)
                ViewState("CanPlaceOrderFlag") = value
            End Set

        End Property

        Public Property CanEditSegmentOwnerFlag() As Boolean
            Get
                Return CBool(ViewState("CanEditSegmentOwnerFlag"))
            End Get
            Set(ByVal value As Boolean)
                ViewState("CanEditSegmentOwnerFlag") = value
            End Set

        End Property
        Public Property SegmentMembersCount() As String
            Get
                Return CStr(ViewState("SegmentMembersCount"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentMembersCount") = value
            End Set

        End Property

        Public Property SegmentMembersInt() As Integer
            Get
                Return CInt(ViewState("SegmentMembersInt"))
            End Get
            Set(ByVal value As Integer)
                ViewState("SegmentMembersInt") = value
            End Set

        End Property

        Public Property SegmentDescription() As String
            Get
                Return CStr(ViewState("SegmentDescription"))
            End Get
            Set(ByVal value As String)
                ViewState("SegmentDescription") = value
            End Set

        End Property


        Public Property EditSegmentNavigateUrl() As String
            Get
                Return CStr(ViewState("EditSegmentNavigateUrl"))
            End Get
            Set(ByVal value As String)
                ViewState("EditSegmentNavigateUrl") = value
            End Set

        End Property


        Public Property PortalId() As Integer
            Get
                Return CInt(ViewState("PortalId"))
            End Get
            Set(ByVal value As Integer)
                ViewState("PortalId") = value
            End Set

        End Property

        Public Property SegmentListTabId() As Integer
            Get
                Return CInt(ViewState("SegmentListTabId"))
            End Get
            Set(ByVal value As Integer)
                ViewState("SegmentListTabId") = value
            End Set

        End Property

        Public Property AffiliateListTabId() As Integer
            Get
                Return CInt(ViewState("AffiliateListTabId"))
            End Get
            Set(ByVal value As Integer)
                ViewState("AffiliateListTabId") = value
            End Set

        End Property

        Public Property EventTarget() As String
            Get
                If m_EventTarget Is Nothing Then
                    Return String.Empty
                Else
                    Return m_EventTarget
                End If
            End Get
            Set(ByVal value As String)
                m_EventTarget = value
            End Set


        End Property

        'Private Sub HideShowAddMemberFields(ByVal pIsAddMember As Boolean)
        'hide or show the fields of AddMember panel
        '    If Not lblAddMemberLastName Is Nothing Then lblAddMemberLastName.Visible = Not pIsAddMember
        '    If Not txtAddMemberLastName Is Nothing Then txtAddMemberLastName.Visible = Not pIsAddMember
        '    If Not lblAddMemberFirstName Is Nothing Then lblAddMemberFirstName.Visible = Not pIsAddMember
        '    If Not txtAddMemberFirstName Is Nothing Then txtAddMemberFirstName.Visible = Not pIsAddMember
        '    If Not lblAddMemberState Is Nothing Then lblAddMemberState.Visible = Not pIsAddMember
        '    If Not ddlAddMemberState Is Nothing Then ddlAddMemberState.Visible = Not pIsAddMember
        '    If Not lblAddMemberCity Is Nothing Then lblAddMemberCity.Visible = Not pIsAddMember
        '    If Not txtAddMemberCity Is Nothing Then txtAddMemberCity.Visible = Not pIsAddMember
        '    If Not lblAddMemberCountry Is Nothing Then lblAddMemberCountry.Visible = Not pIsAddMember
        '    If Not lstAddMemberCountry Is Nothing Then lstAddMemberCountry.Visible = Not pIsAddMember
        'End Sub


#End Region

#Region " Create Control Overrides "
        'Private Function GetCountryCodeFromPageRequest() As String
        'Dim strCountry As String = ""

        '    If Page.IsPostBack Then
        '        If EventTarget.Contains("lstAddMemberCountry") Then
        '            If Page.Request.Params(EventTarget) Is Nothing Then

        'Else
        '   If Page.Request.Params(EventTarget).ToString <> "" Then
        '      strCountry = Page.Request.Params(EventTarget)
        ' End If
        'End If
        'If strCountry = "" Then
        '   For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
        '      If Page.Request.Form.Keys(i).Contains("lstAddMemberCountry") Then
        '         strCountry = Page.Request.Form(Page.Request.Form.Keys(i))
        '        Exit For
        '   End If
        'Next
        'End If
        'End If

        'End If

        'Return strCountry

        ' End Function
        'return true if Add Member panel is expanded
        'Private Function GetExpandFromPageRequest() As Boolean
        '    If Page.IsPostBack Then

        'Dim ID As String = EventTarget.Replace("$", "_")

        'If ID.IndexOf(Me.ClientID, StringComparison.InvariantCultureIgnoreCase) >= 0 Then
        '   If EventTarget.Contains("lnkAddMember") Then
        'AddMember link was clicked
        '      Return True
        ' End If

        'If EventTarget.Contains("lstAddMemberCountry") Then
        'PostBack after selection of country DropDown changed
        '   Return True
        'End If
        'End If

        'End If

        'Return False

        'End Function



        Protected Overrides Sub CreateChildControls()
            EventTarget = Page.Request("__EVENTTARGET")
            ' Setup the controls on the page
            Dim table As New HtmlTable

            'save current segment information before going to some other tab
            SaveSegmentInfo()

            ' set table attributes
            With table
                .Border = 0
                .ApplyStyleSheetSkin(Page)
                .Width = Unit.Percentage(100).ToString
                .CellSpacing = 1
                .CellPadding = 3
                .Attributes.Add("class", "tmar_FormTable")
            End With

            ' Put the controls inside a table
            Dim lnkEditSegment As StringBuilder = New StringBuilder()

            If CanEditSegmentOwnerFlag Then
                lnkEditSegment.AppendFormat("<div class=""tmar_subhead1""><a id=""{0}"" href=""javascript:{1}"" >{2}</a>&nbsp;{3}</div>", Me.UniqueID, Page.ClientScript.GetPostBackEventReference(Me, "EDITSEGMENT"), SegmentDescription, SegmentMembersCount)
            Else
                lnkEditSegment.AppendFormat("<div class=""tmar_subhead1"">{0}&nbsp;{1}</div>", SegmentDescription, SegmentMembersCount)
            End If
            'Note:  If the Search box has more number of cells (>4) , increase the colspan here else it will wrap the segment name when the
            '       the search box gets displayed
            table.Rows.Add(CreateHtmlTableRow( _
                                                CreateLinkButtonInHtmlCell(lnkEditSegment.ToString, 4)))
            If SegmentMembersInt > 0 Then
                table.Rows.Add(CreateHtmlTableRow( _
                                    CreateControlInHtmlCell(lnkListAll, "lnkListAll", ListAllCaption, 4)))
            End If

            If Me.CanAddMemberFlag Then
                table.Rows.Add(CreateHtmlTableRow( _
                       CreateControlInHtmlCell(lnkAddMember, "lnkAddMember", AddMemberCaption, 4)))
            End If
            'If GetExpandFromPageRequest() Then
            'Add Member panel is expanded
            'Dim lnkAddMember As StringBuilder = New StringBuilder()
            'lnkAddMember.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""javascript:{1}"" >&nbsp; {2}<img src=""{3}"" />&nbsp;</a></div>", Me.UniqueID, Page.ClientScript.GetPostBackEventReference(Me, "ADDMEMBER"), AddMemberAddCaption, ResolveUrl("images/arrow_right_blue.gif"))

            'table.Rows.Add(CreateHtmlTableRow( _
            '        CreateControlInHtmlCell(lblAddMemberLastName, "lblAddMemberLastName", AddMemberLastNameLabel), _
            '        CreateControlInHtmlCell(txtAddMemberLastName, "txtAddMemberLastName", ""), _
            '        CreateControlInHtmlCell(lblAddMemberFirstName, "lblAddMemberFirstName", AddMemberFirstNameLabel), _
            '        CreateControlInHtmlCell(txtAddMemberFirstName, "txtAddMemberFirstName", "")))
            'table.Rows.Add(CreateHtmlTableRow( _
            '                        CreateControlInHtmlCell(lblAddMemberCity, "lblAddMemberCity", AddMemberCityLabel), _
            '        CreateControlInHtmlCell(txtAddMemberCity, "txtAddMemberCity", ""), _
            '        CreateControlInHtmlCell(lblAddMemberState, "lblAddMemberState", AddMemberStateLabel), _
            '        CreateControlInHtmlCell(ddlAddMemberState, "ddlAddMemberState", "")))
            'table.Rows.Add(CreateHtmlTableRow(CreateControlInHtmlCell(lblAddMemberCountry, "lblAddMemberCountry", AddMemberCountryLabel), _
            '        CreateControlInHtmlCell(lstAddMemberCountry, "lstAddMemberCountry", "")))
            'table.Rows.Add(CreateHtmlTableRow( _
            '        CreateBlankCell(), _
            '        CreateBlankCell(), _
            '        CreateBlankCell(), _
            '        CreateLinkButtonInHtmlCell(lnkAddMember.ToString)))


            'End If

            If SegmentMembersInt > 0 Then
                table.Rows.Add(CreateHtmlTableRow( _
                        CreateControlInHtmlCell(lnkRenewAll, "lnkRenewAll", RenewAllCaption, 4)))
                If CanPlaceOrderFlag Then
                    table.Rows.Add(CreateHtmlTableRow( _
                            CreateControlInHtmlCell(lnkBuyProduct, "lnkBuyProduct", BuyProductCaption, 4)))
                End If
            End If
            Controls.Add(table)



        End Sub


        Private Function GetAddressStructure(ByVal Country As String) As TIMSS.API.CustomerInfo.ICustomerAddressStructures
            Dim oAddressStructures As TIMSS.API.CustomerInfo.ICustomerAddressStructures


            Try
                'oAddressStructures = Customer.GetCustomerAddressStructures(0, Country)
                oAddressStructures = TIMSS.API.CachedApplicationData.ApplicationDataCache.CustomerAddressStructures(Country)

                If oAddressStructures.Count = 0 Then
                    oAddressStructures = GetAddressStructure("[ALL]")
                End If


                Return oAddressStructures

            Catch ex As Exception
                Throw ex
            End Try
        End Function

#End Region

#Region " Create HTML Table , Rows and Cells "

        Private Function CreateHtmlTableRow(ByVal ParamArray HtmlCells() As HtmlTableCell) As HtmlTableRow
            Dim tablerow As New HtmlTableRow
            Dim i As Integer = 0
            For Each Cell As HtmlTableCell In HtmlCells

                If Not Cell Is Nothing Then


                    If i = 2 Then ' this is the third column
                        Cell.NoWrap = True
                        Cell.Attributes.Add("style", "width: 150px")
                    End If


                    tablerow.Cells.Add(Cell)
                End If

                i += 1
            Next

            Return tablerow
        End Function

        Private Overloads Function CreateBlankCell() As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            Return tablecell

        End Function

        Private Overloads Function CreateLinkButtonInHtmlCell(ByVal innerHtml As String, Optional ByVal Colspan As Integer = 0) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell
            If Colspan > 0 Then tablecell.ColSpan = Colspan
            tablecell.InnerHtml = innerHtml
            tablecell.Attributes.Add("align", "right")

            Return tablecell

        End Function




        'Private Overloads Function CreateControlInHtmlCell(ByRef Control As Personify.WebControls.StateDropDownList, _
        '       ByVal ID As String, ByVal Text As String) As HtmlTableCell

        'Dim statecell As HtmlTableCell = New HtmlTableCell

        '   SetControlProperties(Control, ID, "")


        '  statecell.Controls.Add(Control)

        ' Return statecell

        'End Function

        Private Overloads Function CreateControlInHtmlCell(ByRef Control As Button, _
                                    ByVal ID As String, _
                                    ByVal Text As String, _
                                    ByVal NavigateURL As String, _
                                    Optional ByVal Colspan As Integer = 0) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function

        Private Overloads Function CreateControlInHtmlCell(ByRef Control As LinkButton, _
                                    ByVal ID As String, _
                                    ByVal Text As String, _
                                    Optional ByVal Colspan As Integer = 0) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            If Colspan > 0 Then tablecell.ColSpan = Colspan

            SetControlProperties(Control, ID, Text)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function

        Private Overloads Function CreateControlInHtmlCell(ByRef Control As HyperLink, _
                                ByVal ID As String, _
                                ByVal Text As String, _
                                ByVal ControlNavigateURL As String, _
                                Optional ByVal Colspan As Integer = 0) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            If Colspan > 0 Then tablecell.ColSpan = Colspan

            SetControlProperties(Control, ID, Text, ControlNavigateURL)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function

        Private Overloads Function CreateControlInHtmlCell(ByRef Control As Label, _
        ByVal ID As String, ByVal Text As String, _
                  Optional ByVal Width As Integer = -1, _
                  Optional ByVal Colspan As Integer = 0) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            tablecell.NoWrap = True
            If Colspan > 0 Then tablecell.ColSpan = Colspan

            SetControlProperties(Control, ID, Text, Width)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function

        'Private Overloads Function CreateControlInHtmlCell(ByRef Control As TextBox, ByVal ID As String, ByVal Text As String, _
        '              Optional ByVal Width As Integer = -1, _
        '              Optional ByVal EnableViewState As Boolean = False, _
        '              Optional ByVal MaxLength As Integer = -1, _
        '              Optional ByVal Colspan As Integer = 0) As HtmlTableCell


        'Dim tablecell As HtmlTableCell

        '   tablecell = New HtmlTableCell

        'If Colspan > 0 Then tablecell.ColSpan = Colspan

        'SetControlProperties(Control, ID, Text, Width, EnableViewState, MaxLength)

        'tablecell.Controls.Add(Control)

        'Return tablecell

        'End Function

        'Private Overloads Function CreateControlInHtmlCell(ByRef Control As Personify.WebControls.CountryDropDownList, _
        '                    ByVal ID As String, ByVal Text As String, _
        '                    Optional ByVal Width As Integer = -1, _
        '                    Optional ByVal EnableViewState As Boolean = False, _
        '                    Optional ByVal Colspan As Integer = 0) As HtmlTableCell

        'Dim tablecell As HtmlTableCell

        '    tablecell = New HtmlTableCell

        '    If Colspan > 0 Then tablecell.ColSpan = Colspan

        '    SetControlProperties(Control, ID, Text, Width, EnableViewState)

        '    tablecell.Controls.Add(Control)

        '    Return tablecell

        'End Function

        'Private Overloads Sub SetControlProperties(ByRef Control As DropDownList, ByVal ID As String, ByVal Text As String)
        '    Control = New DropDownList
        '    With Control
        '        .ID = ID
        '        .Text = Text
        '    End With
        'End Sub

        'Private Overloads Sub SetControlProperties(ByRef Control As Personify.WebControls.StateDropDownList, ByVal ID As String, ByVal Text As String)
        '    Control = New Personify.WebControls.StateDropDownList
        '    With Control
        '        .ID = ID
        '        .Text = Text
        '        .EnableViewState = EnableViewState

        '    End With
        'End Sub

        Private Overloads Sub SetControlProperties(ByRef Control As HyperLink, ByVal ID As String, ByVal Text As String, ByVal ControlNavigateURL As String)
            Control = New HyperLink
            With Control
                .ID = ID
                .Text = Text
                .NavigateUrl = ControlNavigateURL
            End With
        End Sub
        Private Overloads Sub SetControlProperties(ByRef Control As LinkButton, ByVal ID As String, ByVal Text As String)
            Control = New LinkButton
            With Control
                .ID = ID
                .Text = Text
            End With
        End Sub

        Private Overloads Sub SetControlProperties(ByRef Control As Button, ByVal ID As String, ByVal Text As String)
            Control = New Button
            With Control
                .ID = ID
                .Text = Text
            End With
        End Sub


        Private Overloads Sub SetControlProperties(ByRef Control As Label, ByVal ID As String, ByVal Text As String, _
                Optional ByVal Width As Integer = -1)
            Control = New Label
            With Control
                .ID = ID
                .Text = Text
                If Width <> -1 Then
                    .Width = Unit.Percentage(Width)
                End If

            End With
        End Sub



        'Private Overloads Sub SetControlProperties(ByRef Control As TextBox, ByVal ID As String, ByVal Text As String, _
        '           Optional ByVal Width As Integer = -1, Optional ByVal EnableViewState As Boolean = False, Optional ByVal MaxLength As Integer = -1)
        '    Control = New TextBox
        '    With Control
        '        .ID = ID
        '        .Text = Text
        '        If Width <> -1 Then
        '            .Width = Unit.Percentage(Width)
        '        End If
        '        .EnableViewState = EnableViewState
        '        If MaxLength <> -1 Then
        '            .MaxLength = MaxLength
        '        End If
        '    End With
        'End Sub

        'Private Overloads Sub SetControlProperties(ByRef Control As Personify.WebControls.CountryDropDownList, ByVal ID As String, ByVal Text As String, _
        '            Optional ByVal Width As Integer = -1, Optional ByVal EnableViewState As Boolean = False)
        '    Control = New Personify.WebControls.CountryDropDownList
        '    With Control
        '        .ID = ID
        '        .Text = Text
        '  .AutoPostBack = True
        '        If Width <> -1 Then
        '            .Width = Unit.Percentage(Width)
        '        End If
        '        .EnableViewState = EnableViewState
        '        If Page.IsPostBack Then

        'Dim strC As String = GetCountryCodeFromPageRequest()
        '            If strC.Length > 0 Then
        '                .SelectedValue = strC
        '            End If

        'End If

        'End With
        'End Sub



#End Region

#Region "Save Segment Info"
        Private Sub SaveSegmentInfo()
            'save current segment information before navigating to some other tab

            If Page.IsPostBack() Then

                Dim strucSegmentOwner As AffiliateManagementSessionHelper.CustomerId
                strucSegmentOwner.MasterCustomerId = SegmentOwnerMasterCustomerId
                strucSegmentOwner.SubCustomerId = CInt(SegmentOwnerSubCustomerId)

                Dim ID As String = EventTarget.Replace("$", "_")
                If ID.IndexOf(Me.ClientID, StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                    If EventTarget.Contains("lnkListAll") Then
                        'ListAll was clicked
                        '** Set information about the current segment before navigating to another tab
                        AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, SegmentType, SegmentQualifier1, SegmentQualifier2, Subsystem, strucSegmentOwner, SegmentDescr, ReadOnlyFlag, CanAddMemberFlag, CanRemoveMemberFlag, CanPlaceOrderFlag, CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId)
                        Page.Response.Redirect(ListAllNavigateUrl, True)
                    ElseIf EventTarget.Contains("lnkRenewAll") Then
                        'RenewAll was clicked
                        '** Set information about the current segment before navigating to another tab
                        AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, SegmentType, SegmentQualifier1, SegmentQualifier2, Subsystem, strucSegmentOwner, SegmentDescr, ReadOnlyFlag, CanAddMemberFlag, CanRemoveMemberFlag, CanPlaceOrderFlag, CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId)
                        Page.Response.Redirect(RenewAllNavigateUrl, True)
                    ElseIf EventTarget.Contains("lnkBuyProduct") Then
                        'BuyProduc was clicked
                        AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, SegmentType, SegmentQualifier1, SegmentQualifier2, Subsystem, strucSegmentOwner, SegmentDescr, ReadOnlyFlag, CanAddMemberFlag, CanRemoveMemberFlag, CanPlaceOrderFlag, CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId, AffiliateListGroupPurchaseTabId)
                        Page.Response.Redirect(BuyProductNavigateUrl, True)
                    ElseIf EventTarget.Contains("lnkAddMember") Then
                        'AddMember was clicked
                        AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, SegmentType, SegmentQualifier1, SegmentQualifier2, Subsystem, strucSegmentOwner, SegmentDescr, ReadOnlyFlag, CanAddMemberFlag, CanRemoveMemberFlag, CanPlaceOrderFlag, CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId, AffiliateListTabId)
                        Page.Response.Redirect(AddMemberNavigateUrl, True)
                    End If
                End If

                ID = EventTarget.Replace(":", "_")
                ID = ID.Replace("$", "_")
                If ID.IndexOf(Me.ClientID, StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                    If Not Page.Request("__EVENTARGUMENT") Is Nothing Then
                        'If Page.Request("__EVENTARGUMENT").IndexOf("ADDMEMBER", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                        'Add Members was clicked
                        'Dim divNo As String = String.Empty

                        'Dim firstName As String = String.Empty
                        'Dim lastName As String = String.Empty
                        'Dim city As String = String.Empty
                        'Dim country As String = String.Empty
                        'Dim state As String = String.Empty

                        'get the values for Searching Criterias
                        'For Each ctl As String In Page.Request.Params.AllKeys
                        'If ctl.IndexOf("txtAddMemberLastName", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                        'lastName = Page.Request.Params(ctl)
                        'End If
                        'If ctl.IndexOf("txtAddMemberFirstName", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                        'firstName = Page.Request.Params(ctl)
                        'End If
                        'If ctl.IndexOf("txtAddMemberCity", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                        'city = Page.Request.Params(ctl)
                        'End If
                        'If ctl.IndexOf("ddlAddMemberState", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                        'state = Page.Request.Params(ctl)
                        'End If
                        'If ctl.IndexOf("lstAddMemberCountry", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                        'country = Page.Request.Params(ctl)
                        'End If
                        'Next
                        'Dim url As String = Page.Request.Params("__EVENTARGUMENT").Replace("ADDMEMBER:", "")

                        'build the URL for CustomerSearch web part, containing the searching criterias
                        'Dim ref As String = String.Empty
                        'If lastName <> String.Empty Then
                        'ref = ref & "&lastname=" & lastName
                        'End If
                        'If firstName <> String.Empty Then
                        'ref = ref & "&firstname=" & firstName
                        'End If
                        'If country <> String.Empty Then
                        'ref = ref & "&country=" & country
                        'End If
                        'If state <> String.Empty Then
                        'ref = ref & "&state=" & state
                        'End If
                        'If city <> String.Empty Then
                        ' ref = ref & "&city=" & city
                        'End If
                        'ref = ref & "&Execute=yes"

                        'Dim url As String = NavigateURL(AddMemberNavigateUrl, "", ref)
                        'AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, SegmentType, SegmentQualifier1, SegmentQualifier2, Subsystem, strucSegmentOwner, SegmentDescr, ReadOnlyFlag, CanAddMemberFlag, CanRemoveMemberFlag, CanPlaceOrderFlag, CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId)
                        'Page.Response.Redirect(url)
                        If Page.Request("__EVENTARGUMENT").IndexOf("EDITSEGMENT", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                            'Edit Segment was clicked
                            AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, SegmentType, SegmentQualifier1, SegmentQualifier2, Subsystem, strucSegmentOwner, SegmentDescr, ReadOnlyFlag, CanAddMemberFlag, CanRemoveMemberFlag, CanPlaceOrderFlag, CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId, AffiliateListGroupPurchaseTabId)
                            '3246-5916927
                            AffiliateManagementSessionHelper.ManageAffiliate(PortalId, SegmentQualifier1, CInt(SegmentQualifier2), SegmentDescr, True)
                            'end 3246-5916927
                            Page.Response.Redirect(EditSegmentNavigateUrl)
                        End If
                    End If

                End If
            End If


        End Sub
#End Region
        'Private Sub ddlAddMemberState_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAddMemberState.PreRender
        'Dim oListItem As New ListItem
        '    oListItem.Text = m_AddMemberStateDefault
        '    oListItem.Value = "-1"
        '    ddlAddMemberState.Items.Insert(0, oListItem)
        '    ddlAddMemberState.SelectedValue = "-1"
        '     oListItem = Nothing
        'End Sub

        'Private Sub lstAddMemberCountry_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstAddMemberCountry.PreRender
        'Dim oListItem As New ListItem
        '    oListItem.Text = m_AddMemberCountryDefault
        '    oListItem.Value = "-1"
        '    lstAddMemberCountry.Items.Insert(0, oListItem)
        '    lstAddMemberCountry.SelectedValue = "-1"
        '    oListItem = Nothing
        'End Sub

    End Class

End Namespace
