Option Strict Off
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Text
Imports Personify.DNN.Modules.AffiliateSegmentList.Business
Imports Personify.DNN.Modules.AffiliateSegmentList.clsAffiliateManagementHelper
Imports Personify.ApplicationManager



Namespace Personify.DNN.Modules.AffiliateSegmentList

    Public MustInherit Class AffiliateSegmentList
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm



#Region "Controls"
        Protected WithEvents pnlSegments As System.Web.UI.WebControls.Panel
        Protected WithEvents xslSegmentsView As WebControls.XslTemplate
        Protected WithEvents divGroupPurchaseNoSegmentsMessage As HtmlControls.HtmlGenericControl
        Protected WithEvents divNoSegmentsMessage As HtmlControls.HtmlGenericControl
        Dim dsCusSegment As DataSet

        Protected WithEvents divAddSegment As HtmlControls.HtmlGenericControl
        'Private strMasterCustomerId As String
        'Private intSubCustomerId As Integer
#End Region


#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim boolIsNonPersonifyAccess As Boolean
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    Dim isPersUser As Boolean = IsPersonifyWebUserLoggedIn()
                    If Settings(C_SEGMENT_LISTING) Is Nothing Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    Else
                        pnlSegments.Visible = True
                        InitializeControl()
                    End If
                Else
                    boolIsNonPersonifyAccess = True
                End If

                If boolIsNonPersonifyAccess Then 'The current user does not have these attributes
                    pnlSegments.Visible = False
                    DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region



#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

       




        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init

            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

#Region " Helper Functions "
        Private Sub InitializeControl()
            Try

                ' if Display All has been selected..
                If CType(Settings(C_SEGMENT_LISTING), Integer) = 0 Then   ' DISPLAY ALL segments
                    'Segment Listing = "Display All"

                    Dim oSegments As TIMSS.API.WebInfo.IWebCustomerSegmentControlViewList
                    'get the segments list
                    oSegments = GetSegmentList(False)
                    If Not oSegments Is Nothing Then
                        Dim segments(oSegments.Count) As SegmentListInfo
                        Dim i As Integer
                        Dim segmentArray As ArrayList = New ArrayList

                        For i = 0 To oSegments.Count - 1
                            'D00031572 - DisplayOnPage functionality
                            If CheckSegmentDisplayOnPage(oSegments(i).SegmentRuleCodeString) Then
                                segments(i) = New SegmentListInfo
                                segments(i).SegmentType = oSegments(i).SegmentRuleCodeString
                                If oSegments(i).SegmentActualDescription.Length > 0 Then
                                    segments(i).SegmentDescription = oSegments(i).SegmentActualDescription
                                Else
                                    segments(i).SegmentDescription = oSegments(i).SegmentRuleCodeString & " - " & oSegments(i).SegmentQualifier1 & " -" & oSegments(i).SegmentQualifier2 & "<BR>"
                                End If
                                segments(i).SegmentQualifier1 = oSegments(i).SegmentQualifier1
                                segments(i).SegmentQualifier2 = oSegments(i).SegmentQualifier2

                                'calculate the number of members for the segment
                                Dim counter As String = String.Empty
                                Select Case segments(i).SegmentType
                                    Case "COMMITTEE"
                                        segments(i).SegmentMembersInt = GetCommitteeSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2)
                                        counter = " (" & segments(i).SegmentMembersInt.ToString & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case "EMPLOYEE"
                                        segments(i).SegmentMembersInt = GetEmployeeSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2)
                                        counter = " (" & segments(i).SegmentMembersInt.ToString & " " & Localization.GetString("Employees", LocalResourceFile) & ")"
                                    Case "MISCELLANEOUS"
                                        segments(i).SegmentMembersInt = GetMiscellaneousSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2)
                                        counter = " (" & segments(i).SegmentMembersInt.ToString & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case "GEOGRAPHY"
                                        segments(i).SegmentMembersInt = GetGeographySegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2)
                                        counter = " (" & segments(i).SegmentMembersInt.ToString & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case "PRODUCT"
                                        segments(i).SegmentMembersInt = GetMembershipProductSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2)
                                        counter = " (" & segments(i).SegmentMembersInt.ToString & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                End Select
                                segments(i).SegmentMembersCount = counter

                                Dim segmentItem As Segment = New Segment
                                'set the values for the properties of each Segment type object
                                With segmentItem
                                    .SegmentType = oSegments(i).SegmentRuleCodeString
                                    .SegmentQualifier1 = oSegments(i).SegmentQualifier1
                                    .SegmentQualifier2 = oSegments(i).SegmentQualifier2
                                    .PortalId = PortalId
                                    .SegmentOwnerMasterCustomerId = oSegments(i).SegmentOwnerMasterCustomerId
                                    .SegmentOwnerSubCustomerId = oSegments(i).SegmentOwnerSubCustomerId
                                    If oSegments(i).SegmentActualDescription.Length > 0 Then
                                        .SegmentDescr = oSegments(i).SegmentActualDescription
                                    Else
                                        .SegmentDescr = oSegments(i).SegmentRuleCodeString & " - " & oSegments(i).SegmentQualifier1 & " -" & oSegments(i).SegmentQualifier2 & "<BR>"
                                    End If
                                    .Subsystem = oSegments(i).Subsystem
                                    .ReadOnlyFlag = oSegments(i).ReadOnlyFlag
                                    .CanRemoveMemberFlag = oSegments(i).CanRemoveMemberFlag
                                    .CanPlaceOrderFlag = oSegments(i).CanPlaceOrderFlag And CBool(IIf(CType(Settings(C_ALLOW_SEGMENT_ORDER), String) = "Y", True, False))
                                    .CanAddMemberFlag = oSegments(i).CanAddMemberFlag
                                    .SegmentListTabId = Me.TabId   ' Current tab is the one used for segmentlisting
                                    .CanEditSegmentOwnerFlag = False
                                    If Not Settings(C_ALLOW_SEGMENT_EDITS) Is Nothing AndAlso CType(Settings(C_ALLOW_SEGMENT_EDITS), String) = "Y" Then
                                        .CanEditSegmentOwnerFlag = CBool(IIf(oSegments(i).CanEditSegmentOwnerFlag = "Y", True, False))
                                    End If

                                    If oSegments(i).SegmentActualDescription.Length > 0 Then
                                        .SegmentDescription = oSegments(i).SegmentActualDescription
                                    Else
                                        .SegmentDescription = oSegments(i).SegmentRuleCodeString & " - " & oSegments(i).SegmentQualifier1 & " -" & oSegments(i).SegmentQualifier2 & "<BR>"
                                    End If


                                    .SegmentMembersCount = counter
                                    .SegmentMembersInt = segments(i).SegmentMembersInt
                                    
                                    Select Case .SegmentType
                                        Case "COMMITTEE"
                                            .AddMemberCaption = Localization.GetString("AddMember", LocalResourceFile)
                                            .AddMemberNavigateUrl = NavigateURL(CType(Settings(C_COMMITTEE_ADD_MEMBER_ACTION_URL), Integer), "", "")

                                            '.AddMemberFirstNameLabel = Localization.GetString("FirstName", LocalResourceFile)
                                            '.AddMemberLastNameLabel = Localization.GetString("LastName", LocalResourceFile)
                                            '.AddMemberStateLabel = Localization.GetString("State", LocalResourceFile)
                                            '.AddMemberStateDefault = Localization.GetString("DefaultState", LocalResourceFile)
                                            '.AddMemberCityLabel = Localization.GetString("City", LocalResourceFile)
                                            '.AddMemberCountryDefault = Localization.GetString("DefaultCountry", LocalResourceFile)
                                            '.AddMemberCountryLabel = Localization.GetString("Country", LocalResourceFile)
                                            '.AddMemberAddCaption = Localization.GetString("Add", LocalResourceFile)

                                            .ListAllNavigateUrl = NavigateURL(CType(Settings(C_COMMITTEE_LISTING_ACTION_URL), Integer), "", "") '"mcid=" & seg1.SegmentQualifier1 & "&scid=" & seg1.SegmentQualifier2 & "&SegmentType=Committee")
                                            .RenewAllNavigateUrl = NavigateURL(CType(Settings(C_COMMITTEE_RENEW_ALL_ACTION_URL), Integer), "", "")
                                            .AffiliateListTabId = CType(Settings(C_COMMITTEE_LISTING_ACTION_URL), Integer)
                                            .BuyProductNavigateUrl = NavigateURL(CType(Settings(C_COMMITTEE_BUY_PRODUCT_ACTION_URL), Integer), "", "")

                                            '**Used for navigating to the assigned tab when user opts for
                                            ' "Buy product for same group". The "Buy for group" button on product listing uses this setting to redirect
                                            ' the user to this tab
                                            .AffiliateListGroupPurchaseTabId = CType(Settings(C_COMMITTEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                            .EditSegmentNavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_EDIT_ACTION_URL), Integer))
                                        Case "EMPLOYEE"
                                            .AddMemberCaption = Localization.GetString("AddEmployee", LocalResourceFile)
                                            .AddMemberNavigateUrl = NavigateURL(CType(Settings(C_EMPLOYEE_ADD_MEMBER_ACTION_URL), Integer), "", "")

                                            '.AddMemberFirstNameLabel = Localization.GetString("FirstName", LocalResourceFile)
                                            '.AddMemberLastNameLabel = Localization.GetString("LastName", LocalResourceFile)
                                            '.AddMemberStateLabel = Localization.GetString("State", LocalResourceFile)
                                            '.AddMemberStateDefault = Localization.GetString("DefaultState", LocalResourceFile)
                                            '.AddMemberCityLabel = Localization.GetString("City", LocalResourceFile)
                                            '.AddMemberCountryDefault = Localization.GetString("DefaultCountry", LocalResourceFile)
                                            '.AddMemberCountryLabel = Localization.GetString("Country", LocalResourceFile)
                                            '.AddMemberAddCaption = Localization.GetString("Add", LocalResourceFile)


                                            .ListAllNavigateUrl = NavigateURL(CType(Settings(C_EMPLOYEE_LISTING_ACTION_URL), Integer), "", "") '"mcid=" & seg1.SegmentQualifier1 & "&scid=" & seg1.SegmentQualifier2 & "&SegmentType=Employment")
                                            .RenewAllNavigateUrl = NavigateURL(CType(Settings(C_EMPLOYEE_RENEW_ALL_ACTION_URL), Integer), "", "")
                                            .AffiliateListTabId = CType(Settings(C_EMPLOYEE_LISTING_ACTION_URL), Integer)
                                            .BuyProductNavigateUrl = NavigateURL(CType(Settings(C_EMPLOYEE_BUY_PRODUCT_ACTION_URL), Integer), "", "")

                                            '**Used for navigating to the assigned tab when user opts for
                                            ' "Buy product for same group". The "Buy for group" button on product listing uses this setting to redirect
                                            ' the user to this tab
                                            .AffiliateListGroupPurchaseTabId = CType(Settings(C_EMPLOYEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                            .EditSegmentNavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_EDIT_ACTION_URL), Integer))

                                        Case "GEOGRAPHY"
                                            .ListAllNavigateUrl = NavigateURL(CType(Settings(C_GEOGRAPHIC_LISTING_ACTION_URL), Integer), "", "") '"mcid=" & seg1.SegmentQualifier1 & "&scid=" & seg1.SegmentQualifier2 & "&SegmentType=Geographic")
                                            .RenewAllNavigateUrl = NavigateURL(CType(Settings(C_GEOGRAPHIC_RENEW_ALL_ACTION_URL), Integer), "", "")
                                            .AffiliateListTabId = CType(Settings(C_GEOGRAPHIC_LISTING_ACTION_URL), Integer)
                                            .BuyProductNavigateUrl = NavigateURL(CType(Settings(C_GEOGRAPHIC_BUY_PRODUCT_ACTION_URL), Integer), "", "")

                                            '**Used for navigating to the assigned tab when user opts for
                                            ' "Buy product for same group". The "Buy for group" button on product listing uses this setting to redirect
                                            ' the user to this tab
                                            .AffiliateListGroupPurchaseTabId = CType(Settings(C_GEOGRAPHIC_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                            .CanEditSegmentOwnerFlag = False

                                        Case "PRODUCT"
                                            .ListAllNavigateUrl = NavigateURL(CType(Settings(C_MEMBERSHIP_LISTING_ACTION_URL), Integer), "", "") '"mcid=" & seg1.SegmentQualifier1 & "&scid=" & seg1.SegmentQualifier2 & "&SegmentType=Membership")
                                            .RenewAllNavigateUrl = NavigateURL(CType(Settings(C_MEMBERSHIP_RENEW_ALL_ACTION_URL), Integer), "", "")
                                            .AffiliateListTabId = CType(Settings(C_MEMBERSHIP_LISTING_ACTION_URL), Integer)
                                            .BuyProductNavigateUrl = NavigateURL(CType(Settings(C_MEMBERSHIP_BUY_PRODUCT_ACTION_URL), Integer), "", "")

                                            '**Used for navigating to the assigned tab when user opts for
                                            ' "Buy product for same group". The "Buy for group" button on product listing uses this setting to redirect
                                            ' the user to this tab
                                            .AffiliateListGroupPurchaseTabId = CType(Settings(C_MEMBERSHIP_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                            .CanEditSegmentOwnerFlag = False

                                        Case Else

                                            .ListAllNavigateUrl = NavigateURL(CType(Settings(C_MISC_LISTING_ACTION_URL), Integer), "", "") '"mcid=" & seg1.SegmentQualifier1 & "&scid=" & seg1.SegmentQualifier2 & "&SegmentType=Miscellaneous")
                                            .RenewAllNavigateUrl = NavigateURL(CType(Settings(C_MISCELLANEOUS_RENEW_ALL_ACTION_URL), Integer), "", "")
                                            .AffiliateListTabId = CType(Settings(C_MISC_LISTING_ACTION_URL), Integer)
                                            .BuyProductNavigateUrl = NavigateURL(CType(Settings(C_MISCELLANEOUS_BUY_PRODUCT_ACTION_URL), Integer), "", "")

                                            '**Used for navigating to the assigned tab when user opts for
                                            ' "Buy product for same group". The "Buy for group" button on product listing uses this setting to redirect
                                            ' the user to this tab
                                            .AffiliateListGroupPurchaseTabId = CType(Settings(C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                            .CanEditSegmentOwnerFlag = False

                                    End Select

                                    .ListAllCaption = Localization.GetString("ListAll", LocalResourceFile)
                                    .RenewAllCaption = Localization.GetString("RenewAll", LocalResourceFile)
                                    .BuyProductCaption = Localization.GetString("BuyProduct", LocalResourceFile)

                                End With
                                segmentArray.Add(segmentItem)
                            End If
                        Next

                        'set the template file to be used
                        xslSegmentsView.XSLfile = Server.MapPath(ModulePath + "/Templates/AffiliateSegmentListTemplate.xsl")
                        xslSegmentsView.AddObject("", segments)
                        xslSegmentsView.Display()


                        'add Segment to each of the PlaceHolders from template file
                        For i = 0 To segmentArray.Count - 1
                            Dim segment As Segment = New Segment
                            segment = CType(segmentArray.Item(i), Segment)
                            Dim ph As New PlaceHolder
                            ph = CType(Me.FindControl("ph" + (i + 1).ToString), PlaceHolder)
                            If (ph IsNot Nothing) Then
                                ph.Controls.Add(segment)
                            End If
                        Next

                        divNoSegmentsMessage.Visible = False
                    Else

                        divNoSegmentsMessage.Visible = True
                    End If
                Else
                    ' Display only segments that have Ordering privileges

                    Dim oSegments As TIMSS.API.WebInfo.IWebCustomerSegmentControlViewList
                    'get the list of segments to be displayed filtered by ordering privileges
                    oSegments = GetSegmentList(True)

                    If Not oSegments Is Nothing Then
                        Dim segments(oSegments.Count) As SegmentListInfo
                        Dim i As Integer
                        Dim oSegmentsCount As Integer = 0

                        For i = 0 To oSegments.Count - 1
                            'D00031572 - DisplayOnPage functionality
                            If CheckSegmentDisplayOnPage(oSegments(i).SegmentRuleCodeString) Then

                                segments(i) = New SegmentListInfo
                                Dim AffiliateListTabId As Integer = 0
                                With segments(i)
                                    .SegmentType = oSegments(i).SegmentRuleCodeString
                                    If oSegments(i).SegmentActualDescription.Length > 0 Then
                                        .SegmentDescription = oSegments(i).SegmentActualDescription
                                    Else
                                        .SegmentDescription = oSegments(i).SegmentRuleCodeString & " - " & oSegments(i).SegmentQualifier1 & " -" & oSegments(i).SegmentQualifier2 & "<BR>"
                                    End If
                                    .SegmentQualifier1 = oSegments(i).SegmentQualifier1
                                    .SegmentQualifier2 = oSegments(i).SegmentQualifier2
                                    .SegmentOwnerMasterCustomerId = oSegments(i).SegmentOwnerMasterCustomerId
                                    .SegmentOwnerSubCustomerId = oSegments(i).SegmentOwnerSubCustomerId
                                    .Subsystem = oSegments(i).Subsystem
                                    .ReadOnlyFlag = oSegments(i).ReadOnlyFlag
                                    .CanRemoveMemberFlag = oSegments(i).CanRemoveMemberFlag
                                    .CanPlaceOrderFlag = oSegments(i).CanPlaceOrderFlag 'oSegments(i).CanPlaceOrderFlag And CBool(IIf(CType(Settings(C_ALLOW_SEGMENT_ORDER), String) = "Y", True, False))
                                    .CanAddMemberFlag = oSegments(i).CanAddMemberFlag
                                    .SegmentListTabId = Me.TabId   ' Current tab is the one used for segmentlisting
                                    .CanEditSegmentOwnerFlag = False
                                    If Not Settings(C_ALLOW_SEGMENT_EDITS) Is Nothing AndAlso CType(Settings(C_ALLOW_SEGMENT_EDITS), String) = "Y" Then
                                        .CanEditSegmentOwnerFlag = CBool(IIf(oSegments(i).CanEditSegmentOwnerFlag = "Y", True, False))
                                    End If
                                End With

                                Dim counter As String = String.Empty
                                'set ActionURL for each of the segment to be displayed for each segment type
                                'set the number of items in each segment
                                'AffiliateListTabId (for returning path) for each segment type
                                Select Case segments(i).SegmentType
                                    Case "COMMITTEE"
                                        segments(i).NavigateURL = NavigateURL(CType(Settings(C_COMMITTEE_LISTING_ACTION_URL), Integer), "", "")
                                        AffiliateListTabId = CType(Settings(C_COMMITTEE_LISTING_ACTION_URL), Integer)
                                        counter = " (" & GetCommitteeSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case "EMPLOYEE"
                                        segments(i).NavigateURL = NavigateURL(CType(Settings(C_EMPLOYEE_LISTING_ACTION_URL), Integer), "", "")
                                        AffiliateListTabId = CType(Settings(C_EMPLOYEE_LISTING_ACTION_URL), Integer)
                                        counter = " (" & GetEmployeeSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2) & " " & Localization.GetString("Employees", LocalResourceFile) & ")"
                                    Case "MISCELLANEOUS"
                                        segments(i).NavigateURL = NavigateURL(CType(Settings(C_MISC_LISTING_ACTION_URL), Integer), "", "")
                                        AffiliateListTabId = CType(Settings(C_MISC_LISTING_ACTION_URL), Integer)
                                        counter = " (" & GetMiscellaneousSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case "GEOGRAPHY"
                                        segments(i).NavigateURL = NavigateURL(CType(Settings(C_GEOGRAPHIC_LISTING_ACTION_URL), Integer), "", "")
                                        AffiliateListTabId = CType(Settings(C_GEOGRAPHIC_LISTING_ACTION_URL), Integer)
                                        counter = " (" & GetGeographySegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case "PRODUCT"
                                        segments(i).NavigateURL = NavigateURL(CType(Settings(C_MEMBERSHIP_LISTING_ACTION_URL), Integer), "", "")
                                        AffiliateListTabId = CType(Settings(C_MEMBERSHIP_LISTING_ACTION_URL), Integer)
                                        counter = " (" & GetMembershipProductSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                    Case Else
                                        segments(i).NavigateURL = NavigateURL(CType(Settings(C_MISC_LISTING_ACTION_URL), Integer), "", "")
                                        AffiliateListTabId = CType(Settings(C_MISC_LISTING_ACTION_URL), Integer)
                                        counter = " (" & GetMiscellaneousSegmentAffiliateListCount(segments(i).SegmentQualifier1, segments(i).SegmentQualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                End Select


                                If Page.IsPostBack Then
                                    If Page.Request("__EVENTTARGET").IndexOf("lnkSegmentDescription", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                                        'code to be executed when Segment Description link is clicked
                                        Dim index1 As Integer = Page.Request("__EVENTTARGET").IndexOf("lnkSegmentDescription", StringComparison.InvariantCultureIgnoreCase)
                                        Dim length As Integer = "lnkSegmentDescription".Length
                                        If CType(Page.Request("__EVENTTARGET").Substring(index1 + length), Integer) - 1 = oSegmentsCount Then
                                            Dim url As String = segments(i).NavigateURL
                                            Dim strucSegmentOwner As AffiliateManagementSessionHelper.CustomerId = New AffiliateManagementSessionHelper.CustomerId
                                            strucSegmentOwner.MasterCustomerId = segments(i).SegmentOwnerMasterCustomerId
                                            strucSegmentOwner.SubCustomerId = CInt(segments(i).SegmentOwnerSubCustomerId)

                                            Dim AffiliateListGroupPurchaseTabId As Integer = 0
                                            'set AffiliateListGroupPurchaseTabId for each of the segments types
                                            Select Case segments(i).SegmentType
                                                Case "COMMITTEE"
                                                    AffiliateListGroupPurchaseTabId = CType(Settings(C_COMMITTEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                                Case "EMPLOYEE"
                                                    AffiliateListGroupPurchaseTabId = CType(Settings(C_EMPLOYEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                                Case "MISCELLANEOUS"
                                                    AffiliateListGroupPurchaseTabId = CType(Settings(C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                                Case "GEOGRAPHY"
                                                    AffiliateListGroupPurchaseTabId = CType(Settings(C_GEOGRAPHIC_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                                Case "PRODUCT"
                                                    AffiliateListGroupPurchaseTabId = CType(Settings(C_MEMBERSHIP_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                                Case Else
                                                    AffiliateListGroupPurchaseTabId = CType(Settings(C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), Integer)
                                            End Select
                                            Dim SegmentListTabId As Integer = TabId
                                            'current segment information is saved
                                            AffiliateManagementSessionHelper.SetCurrentSegmentInfo(PortalId, segments(i).SegmentType, segments(i).SegmentQualifier1, segments(i).SegmentQualifier2, segments(i).Subsystem, strucSegmentOwner, segments(i).SegmentDescription, segments(i).ReadOnlyFlag, segments(i).CanAddMemberFlag, segments(i).CanRemoveMemberFlag, segments(i).CanPlaceOrderFlag, segments(i).CanEditSegmentOwnerFlag, SegmentListTabId, AffiliateListTabId, AffiliateListGroupPurchaseTabId)
                                            Page.Response.Redirect(url)
                                        End If
                                    End If
                                End If
                                segments(i).SegmentDescription = segments(i).SegmentDescription + counter
                                oSegmentsCount = oSegmentsCount + 1
                            End If
                        Next

                        'set the template file for this view of the web part - OrderingPrivileges    
                        xslSegmentsView.XSLfile = Server.MapPath(ModulePath + "/Templates/CanPlaceOrderSegmentListTemplate.xsl")
                        xslSegmentsView.AddObject("", segments)
                        xslSegmentsView.Display()

                        divGroupPurchaseNoSegmentsMessage.Visible = False

                    Else

                        divGroupPurchaseNoSegmentsMessage.Visible = True
                    End If

                End If
                If GetCanCreateSegmentsFlag() Then
                    'if user has the permission to Add Segments the corresponding panel will be shown
                    divAddSegment.Visible = True

                    'build the ContextMenu for the 2 items: CreateEmploymentSegment and CreateCommitteeSegment
                    Dim ctxChangeTitle As MarkItUp.WebControls.ContextMenu
                    Dim lnkPageTitle As MarkItUp.WebControls.ContextMenuLink

                    ctxChangeTitle = New MarkItUp.WebControls.ContextMenu
                    ctxChangeTitle.ID = "ctxChangeTitle"

                    Dim omenuitem As MarkItUp.WebControls.ContextMenuItem

                    If Not Settings(C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL) Is String.Empty Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("CreateEmploymentSegment", LocalResourceFile)
                            .CommandArgument = NavigateURL(CType(Settings(C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL), Integer), "", "ref=segment&reftabid=" & TabId)
                            .ClientNotificationFunction = "NavigateUrl"
                        End With
                        ctxChangeTitle.Items.Add(omenuitem)
                    End If

                    If Not Settings(C_CREATE_COMMITTEE_SEGMENT_ACTION_URL) Is String.Empty Then

                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("CreateCommitteeSegment", LocalResourceFile)
                            .CommandArgument = NavigateURL(CType(Settings(C_CREATE_COMMITTEE_SEGMENT_ACTION_URL), Integer), "", "ref=segment&reftabid=" & TabId)
                            .ClientNotificationFunction = "NavigateUrl"
                        End With
                        ctxChangeTitle.Items.Add(omenuitem)
                    End If

                    lnkPageTitle = New MarkItUp.WebControls.ContextMenuLink
                    With lnkPageTitle
                        .ID = "lnkPageTitle"
                        .ContextMenuToOpen = "ctxChangeTitle"
                        .Text = "Add Segments"
                        .CssClass = "btna"
                    End With
                    With divAddSegment.Controls
                        .Add(ctxChangeTitle)
                        .Add(lnkPageTitle)
                    End With

                Else
                    divAddSegment.Visible = False
                End If

            Catch ex As Exception
                Throw ex

            End Try

        End Sub

        'D00031572 - DisplayOnPage functionality
        Private Function CheckSegmentDisplayOnPage(ByVal SegmentType As String) As Boolean
            Select Case SegmentType
                Case "COMMITTEE"
                    If Not Settings(C_COMMITTEE_DISPLAY_ON_PAGE) Is Nothing AndAlso CStr(Settings(C_COMMITTEE_DISPLAY_ON_PAGE)) = "Y" Then
                        Return True
                    End If
                Case "EMPLOYEE"
                    If Not Settings(C_EMPLOYEE_DISPLAY_ON_PAGE) Is Nothing AndAlso CStr(Settings(C_EMPLOYEE_DISPLAY_ON_PAGE)) = "Y" Then
                        Return True
                    End If
                Case "MISCELLANEOUS"
                    If Not Settings(C_MISC_DISPLAY_ON_PAGE) Is Nothing AndAlso CStr(Settings(C_MISC_DISPLAY_ON_PAGE)) = "Y" Then
                        Return True
                    End If
                Case "GEOGRAPHY"
                    If Not Settings(C_GEOGRAPHIC_DISPLAY_ON_PAGE) Is Nothing AndAlso CStr(Settings(C_GEOGRAPHIC_DISPLAY_ON_PAGE)) = "Y" Then
                        Return True
                    End If
                Case "PRODUCT"
                    If Not Settings(C_MEMBERSHIP_DISPLAY_ON_PAGE) Is Nothing AndAlso CStr(Settings(C_MEMBERSHIP_DISPLAY_ON_PAGE)) = "Y" Then
                        Return True
                    End If
            End Select
            Return False
        End Function
        'End D00031572

        'returns a boolean indicating if user has permissions to create new segments
        Private Function GetCanCreateSegmentsFlag() As Boolean
            Try

                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
                oCustomers.Filter.Add("MasterCustomerId", MasterCustomerId)
                oCustomers.Filter.Add("SubCustomerId", SubCustomerId)
                oCustomers.Fill()

                'get the current customer
                'oCustomers = Personify.ApplicationManager.Customer.GetCustomer(PortalId, strMasterCustomerId, intSubCustomerId.ToString)

                If oCustomers.Count > 0 Then
                    GetCanCreateSegmentsFlag = oCustomers(0).CanCreateSegmentsFlag And _
                                        CType(IIf(CType(Settings(C_ALLOW_SEGMENT_CREATE), String) = "Y", True, False), Boolean) And _
                                        (Not Settings(C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL) Is String.Empty OrElse _
                                        Not Settings(C_CREATE_COMMITTEE_SEGMENT_ACTION_URL) Is String.Empty)

                End If

            Catch ex As Exception
                Throw ex
            End Try
        End Function
        'returns the segments of a customer
        Private Function GetSegmentList(ByVal FilterByOrderingPrivileges As Boolean) As TIMSS.API.WebInfo.IWebCustomerSegmentControlViewList
            Try
                Dim oSegments As TIMSS.API.WebInfo.IWebCustomerSegmentControlViewList

                oSegments = get_clsAffiliateManagement.GetSegmentList(PortalId, MasterCustomerId, SubCustomerId, FilterByOrderingPrivileges)

                If oSegments.Count > 0 Then
                    GetSegmentList = oSegments
                Else
                    GetSegmentList = Nothing
                End If


            Catch ex As Exception
                Throw ex
            End Try
        End Function


        'returns the number of items for the specified Committee type segment
        Private Function GetCommitteeSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList
            'get the items for this segment 
            oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2)


            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If

        End Function

        'returns the number of items for the specified Employee type segment
        Private Function GetEmployeeSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList

            'get the items for this segment
            oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2)

            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function

        'get the number of items for the specified Membership type segment
        Private Function GetMembershipProductSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

            'get the items for this segment
            oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2)
            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function

        'get the number of items for the specified Geography segment type
        Private Function GetGeographySegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

            'get the items for this segment
            oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2)

            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function

        'get the number of items for the specified Miscellaneous segment type
        Private Function GetMiscellaneousSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList

            'get the items for this segment
            oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2)
            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If


        End Function
       
        ' This class will be used to store information about each of the segment listed
        Public Class SegmentListInfo
            Public SegmentType As String
            Public SegmentDescription As String
            Public SegmentQualifier1 As String
            Public SegmentQualifier2 As String
            Public NavigateURL As String
            Public SegmentMembersCount As String
            Public SegmentMembersInt As Integer
            Public SegmentOwnerMasterCustomerId As String
            Public SegmentOwnerSubCustomerId As String
            Public Subsystem As String
            Public ReadOnlyFlag As Boolean
            Public CanRemoveMemberFlag As Boolean
            Public CanPlaceOrderFlag As Boolean
            Public CanAddMemberFlag As Boolean
            Public SegmentListTabId As Integer
            Public CanEditSegmentOwnerFlag As Boolean
        End Class

#End Region

    End Class

End Namespace
