Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify
Imports Personify.DNN.Modules.AffiliateSegmentList.Business
Imports Personify.DNN.Modules.AffiliateSegmentList.clsAffiliateManagementHelper

Namespace Personify.DNN.Modules.AffiliateSegmentList

    Public MustInherit Class AffiliateSegmentListEdit
        Inherits Entities.Modules.PortalModuleBase

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region


#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objCtlAffiliateSegmentList As New AffiliateSegmentListController
                Dim objAffiliateSegmentList As New AffiliateSegmentListInfo

                ' Determine ItemId
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Null.NullInteger()
                End If

                If Not Page.IsPostBack Then
                    LoadSettings()
                    'Else
                    'UpdateSettings()

                    ' Redirect back to the portal home page
                    'Response.Redirect(NavigateURL(), True)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub lnkUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            If Page.IsValid Then
                Try
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub

        Private Sub lnkCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Protected Sub rdSegmentListing_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdSegmentListing.SelectedIndexChanged
            If rdSegmentListing.SelectedIndex = 1 Then
                pnlCommittee.Visible = False
                pnlEmployee.Visible = False
                pnlMembership.Visible = False
                pnlMiscellaneous.Visible = False
                pnlGeographic.Visible = False

            Else
                pnlCommittee.Visible = True
                pnlEmployee.Visible = True
                pnlMembership.Visible = True
                pnlMiscellaneous.Visible = True
                pnlGeographic.Visible = True
            End If
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Protected WithEvents rdSegmentListing As System.Web.UI.WebControls.RadioButtonList

        'Edit Segment Listing
        Protected WithEvents pnlCommittee As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlEmployee As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMembership As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMiscellaneous As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlGeographic As System.Web.UI.WebControls.Panel

        Protected WithEvents chkAllowSegmentCreate As System.Web.UI.WebControls.CheckBox
        Protected WithEvents drpCreateEmploymentSegmentActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpCreateCommitteeSegmentActionURL As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents chkAllowSegmentEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents drpSegmentEditActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents chkAllowSegmentOrder As System.Web.UI.WebControls.CheckBox
        Protected WithEvents drpSegmentOrderActionURL As DotNetNuke.UI.UserControls.UrlControl


        'Committee
        'Protected WithEvents drpCommitteeSearchActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpCommitteeAddMemberActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpCommitteeRenewAllActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpCommitteeBuyProductActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpCommitteeAffiliateListGroupPurchaseAction As DotNetNuke.UI.UserControls.UrlControl
        'Employee
        'Protected WithEvents drpEmployeeSearchActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpEmployeeAddMemberActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpEmployeeRenewAllActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpEmployeeBuyProductActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpEmployeeAffiliateListGroupPurchaseAction As DotNetNuke.UI.UserControls.UrlControl
        'Membership
        'Protected WithEvents drpMembershipSearchActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpMembershipRenewAllActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpMembershipBuyProductActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpMembershipAffiliateListGroupPurchaseAction As DotNetNuke.UI.UserControls.UrlControl
        'Miscellaneous
        'Protected WithEvents drpMiscellaneousSearchActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpMiscellaneousRenewAllActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpMiscellaneousBuyProductActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpMiscellaneousAffiliateListGroupPurchaseAction As DotNetNuke.UI.UserControls.UrlControl
        'Geographic
        'Protected WithEvents drpGeographicSearchActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpGeographicRenewAllActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpGeographicBuyProductActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpGeographicAffiliateListGroupPurchaseAction As DotNetNuke.UI.UserControls.UrlControl



        'Member Listing Action URL's
        Protected WithEvents lblMemberListingActionURL As System.Web.UI.WebControls.Label
        Protected WithEvents lblCommitteeListingActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpCommitteeListingActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblEmployeeListingActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpEmployeeListingActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblMembershipListingActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpMembershipListingActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblMiscListingActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpMiscListingActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblGeographicListingActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpGeographicListingActionURL As DotNetNuke.UI.UserControls.UrlControl

        'D00031572 - DisplayOnPage settings
        Protected WithEvents lblCommitteeDisplayOnPage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkCommitteeDisplayOnPage As CheckBox
        Protected WithEvents lblEmployeeDisplayOnPage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkEmployeeDisplayOnPage As CheckBox
        Protected WithEvents lblMembershipDisplayOnPage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkMembershipDisplayOnPage As CheckBox
        Protected WithEvents lblMiscDisplayOnPage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkMiscDisplayOnPage As CheckBox
        Protected WithEvents lblGeographicDisplayOnPage As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkGeographicDisplayOnPage As CheckBox
        'End D00031572

        Private Const c_DataValueField As String = "TabID"
        Private Const c_DataTextField As String = "TabName"




        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region " Helper functions"

        Private Sub LoadSettings()

            If Not Settings(C_ALLOW_SEGMENT_CREATE) Is Nothing Then
                If CType(Settings(C_ALLOW_SEGMENT_CREATE), String) = "Y" Then
                    chkAllowSegmentCreate.Checked = True
                    If Not Settings(C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL) Is Nothing Then
                        drpCreateEmploymentSegmentActionURL.Url = CType(Settings(C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL), String)
                    End If
                    If Not Settings(C_CREATE_COMMITTEE_SEGMENT_ACTION_URL) Is Nothing Then
                        drpCreateCommitteeSegmentActionURL.Url = CType(Settings(C_CREATE_COMMITTEE_SEGMENT_ACTION_URL), String)
                    End If
                Else
                    chkAllowSegmentCreate.Checked = False
                End If

            End If

            If Not Settings(C_ALLOW_SEGMENT_EDITS) Is Nothing Then
                If CType(Settings(C_ALLOW_SEGMENT_EDITS), String) = "Y" Then
                    chkAllowSegmentEdit.Checked = True
                    If Not Settings(C_SEGMENT_EDIT_ACTION_URL) Is Nothing Then
                        drpSegmentEditActionURL.Url = CType(Settings(C_SEGMENT_EDIT_ACTION_URL), String)
                    End If
                Else
                    chkAllowSegmentEdit.Checked = False
                End If

            End If

            If Not Settings(C_ALLOW_SEGMENT_ORDER) Is Nothing Then
                If CType(Settings(C_ALLOW_SEGMENT_ORDER), String) = "Y" Then
                    chkAllowSegmentOrder.Checked = True
                    'If Not Settings(C_SEGMENT_ORDER_ACTION_URL) Is Nothing Then
                    'drpSegmentOrderActionURL.Url = CType(Settings(C_SEGMENT_ORDER_ACTION_URL), String)
                    'End If
                Else
                    chkAllowSegmentOrder.Checked = False
                End If
            End If


            


            If Not Settings(C_SEGMENT_LISTING) Is Nothing Then
                If CType(Settings(C_SEGMENT_LISTING), Integer) = 0 Then
                    rdSegmentListing.SelectedIndex = 0
                    pnlCommittee.Visible = True
                    pnlEmployee.Visible = True
                    pnlMembership.Visible = True
                    pnlMiscellaneous.Visible = True
                    pnlGeographic.Visible = True


                    'committee
                    'If Not Settings(C_COMMITTEE_SEARCH_ACTION_URL) Is Nothing Then
                    'drpCommitteeSearchActionURL.Url = CType(Settings(C_COMMITTEE_SEARCH_ACTION_URL), String)
                    'End If
                    If Not Settings(C_COMMITTEE_ADD_MEMBER_ACTION_URL) Is Nothing Then
                        drpCommitteeAddMemberActionURL.Url = CType(Settings(C_COMMITTEE_ADD_MEMBER_ACTION_URL), String)
                    End If
                    If Not Settings(C_COMMITTEE_RENEW_ALL_ACTION_URL) Is Nothing Then
                        drpCommitteeRenewAllActionURL.Url = CType(Settings(C_COMMITTEE_RENEW_ALL_ACTION_URL), String)
                    End If
                    If Not Settings(C_COMMITTEE_BUY_PRODUCT_ACTION_URL) Is Nothing Then
                        drpCommitteeBuyProductActionURL.Url = CType(Settings(C_COMMITTEE_BUY_PRODUCT_ACTION_URL), String)
                    End If
                    If Not Settings(C_COMMITTEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL) Is Nothing Then
                        drpCommitteeAffiliateListGroupPurchaseAction.Url = CType(Settings(C_COMMITTEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), String)
                    End If
                    'employee
                    'If Not Settings(C_EMPLOYEE_SEARCH_ACTION_URL) Is Nothing Then
                    'drpEmployeeSearchActionURL.Url = CType(Settings(C_EMPLOYEE_SEARCH_ACTION_URL), String)
                    'End If
                    If Not Settings(C_EMPLOYEE_ADD_MEMBER_ACTION_URL) Is Nothing Then
                        drpEmployeeAddMemberActionURL.Url = CType(Settings(C_EMPLOYEE_ADD_MEMBER_ACTION_URL), String)
                    End If
                    If Not Settings(C_EMPLOYEE_RENEW_ALL_ACTION_URL) Is Nothing Then
                        drpEmployeeRenewAllActionURL.Url = CType(Settings(C_EMPLOYEE_RENEW_ALL_ACTION_URL), String)
                    End If
                    If Not Settings(C_EMPLOYEE_BUY_PRODUCT_ACTION_URL) Is Nothing Then
                        drpEmployeeBuyProductActionURL.Url = CType(Settings(C_EMPLOYEE_BUY_PRODUCT_ACTION_URL), String)
                    End If
                    If Not Settings(C_EMPLOYEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL) Is Nothing Then
                        drpEmployeeAffiliateListGroupPurchaseAction.Url = CType(Settings(C_EMPLOYEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), String)
                    End If
                    'membership
                    'If Not Settings(C_MEMBERSHIP_SEARCH_ACTION_URL) Is Nothing Then
                    'drpMembershipSearchActionURL.Url = CType(Settings(C_MEMBERSHIP_SEARCH_ACTION_URL), String)
                    'End If
                    If Not Settings(C_MEMBERSHIP_RENEW_ALL_ACTION_URL) Is Nothing Then
                        drpMembershipRenewAllActionURL.Url = CType(Settings(C_MEMBERSHIP_RENEW_ALL_ACTION_URL), String)
                    End If
                    If Not Settings(C_MEMBERSHIP_BUY_PRODUCT_ACTION_URL) Is Nothing Then
                        drpMembershipBuyProductActionURL.Url = CType(Settings(C_MEMBERSHIP_BUY_PRODUCT_ACTION_URL), String)
                    End If
                    If Not Settings(C_MEMBERSHIP_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL) Is Nothing Then
                        drpMembershipAffiliateListGroupPurchaseAction.Url = CType(Settings(C_MEMBERSHIP_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), String)
                    End If
                    'miscellaneous
                    'If Not Settings(C_MISCELLANEOUS_SEARCH_ACTION_URL) Is Nothing Then
                    'drpMiscellaneousSearchActionURL.Url = CType(Settings(C_MISCELLANEOUS_SEARCH_ACTION_URL), String)
                    'End If
                    If Not Settings(C_MISCELLANEOUS_RENEW_ALL_ACTION_URL) Is Nothing Then
                        drpMiscellaneousRenewAllActionURL.Url = CType(Settings(C_MISCELLANEOUS_RENEW_ALL_ACTION_URL), String)
                    End If
                    If Not Settings(C_MISCELLANEOUS_BUY_PRODUCT_ACTION_URL) Is Nothing Then
                        drpMiscellaneousBuyProductActionURL.Url = CType(Settings(C_MISCELLANEOUS_BUY_PRODUCT_ACTION_URL), String)
                    End If
                    If Not Settings(C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL) Is Nothing Then
                        drpMiscellaneousAffiliateListGroupPurchaseAction.Url = CType(Settings(C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), String)
                    End If
                    'geographic
                    'If Not Settings(C_GEOGRAPHIC_SEARCH_ACTION_URL) Is Nothing Then
                    'drpGeographicSearchActionURL.Url = CType(Settings(C_GEOGRAPHIC_SEARCH_ACTION_URL), String)
                    'End If
                    If Not Settings(C_GEOGRAPHIC_RENEW_ALL_ACTION_URL) Is Nothing Then
                        drpGeographicRenewAllActionURL.Url = CType(Settings(C_GEOGRAPHIC_RENEW_ALL_ACTION_URL), String)
                    End If
                    If Not Settings(C_GEOGRAPHIC_BUY_PRODUCT_ACTION_URL) Is Nothing Then
                        drpGeographicBuyProductActionURL.Url = CType(Settings(C_GEOGRAPHIC_BUY_PRODUCT_ACTION_URL), String)
                    End If
                    If Not Settings(C_GEOGRAPHIC_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL) Is Nothing Then
                        drpGeographicAffiliateListGroupPurchaseAction.Url = CType(Settings(C_GEOGRAPHIC_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL), String)
                    End If
                Else
                    rdSegmentListing.SelectedIndex = 1
                    pnlCommittee.Visible = False
                    pnlEmployee.Visible = False
                    pnlMembership.Visible = False
                    pnlMiscellaneous.Visible = False
                    pnlGeographic.Visible = False

                End If
            End If


            If Not Settings(C_COMMITTEE_LISTING_ACTION_URL) Is Nothing Then
                drpCommitteeListingActionURL.Url = CType(Settings(C_COMMITTEE_LISTING_ACTION_URL), String)
            End If
            If Not Settings(C_EMPLOYEE_LISTING_ACTION_URL) Is Nothing Then
                drpEmployeeListingActionURL.Url = CType(Settings(C_EMPLOYEE_LISTING_ACTION_URL), String)
            End If

            If Not Settings(C_MEMBERSHIP_LISTING_ACTION_URL) Is Nothing Then
                drpMembershipListingActionURL.Url = CType(Settings(C_MEMBERSHIP_LISTING_ACTION_URL), String)
            End If

            If Not Settings(C_MISC_LISTING_ACTION_URL) Is Nothing Then
                drpMiscListingActionURL.Url = CType(Settings(C_MISC_LISTING_ACTION_URL), String)
            End If
            If Not Settings(C_GEOGRAPHIC_LISTING_ACTION_URL) Is Nothing Then
                drpGeographicListingActionURL.Url = CType(Settings(C_GEOGRAPHIC_LISTING_ACTION_URL), String)
            End If

            'D00031572 - DisplayOnPage settings
            If Not Settings(C_COMMITTEE_DISPLAY_ON_PAGE) Is Nothing Then
                chkCommitteeDisplayOnPage.Checked = CBool(IIf(CType(Settings(C_COMMITTEE_DISPLAY_ON_PAGE), String) = "Y", True, False))
            End If
            If Not Settings(C_EMPLOYEE_DISPLAY_ON_PAGE) Is Nothing Then
                chkEmployeeDisplayOnPage.Checked = CBool(IIf(CType(Settings(C_EMPLOYEE_DISPLAY_ON_PAGE), String) = "Y", True, False))
            End If

            If Not Settings(C_MEMBERSHIP_DISPLAY_ON_PAGE) Is Nothing Then
                chkMembershipDisplayOnPage.Checked = CBool(IIf(CType(Settings(C_MEMBERSHIP_DISPLAY_ON_PAGE), String) = "Y", True, False))
            End If

            If Not Settings(C_MISC_DISPLAY_ON_PAGE) Is Nothing Then
                chkMiscDisplayOnPage.Checked = CBool(IIf(CType(Settings(C_MISC_DISPLAY_ON_PAGE), String) = "Y", True, False))
            End If
            If Not Settings(C_GEOGRAPHIC_DISPLAY_ON_PAGE) Is Nothing Then
                chkGeographicDisplayOnPage.Checked = CBool(IIf(CType(Settings(C_GEOGRAPHIC_DISPLAY_ON_PAGE), String) = "Y", True, False))
            End If
            'End D00031572
        End Sub

        Private Sub UpdateSettings()

            Dim objModules As New Entities.Modules.ModuleController

            'Edit Segment Listing
            If chkAllowSegmentCreate.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_ALLOW_SEGMENT_CREATE, "Y")
                objModules.UpdateModuleSetting(Me.ModuleId, C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL, drpCreateEmploymentSegmentActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_CREATE_COMMITTEE_SEGMENT_ACTION_URL, drpCreateCommitteeSegmentActionURL.Url)
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, C_ALLOW_SEGMENT_CREATE, "N")
            End If

            If chkAllowSegmentEdit.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_ALLOW_SEGMENT_EDITS, "Y")
                objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_EDIT_ACTION_URL, drpSegmentEditActionURL.Url)
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, C_ALLOW_SEGMENT_EDITS, "N")
            End If
            If chkAllowSegmentOrder.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_ALLOW_SEGMENT_ORDER, "Y")
                'objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ORDER_ACTION_URL, drpSegmentOrderActionURL.Url)
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, C_ALLOW_SEGMENT_ORDER, "N")
            End If



            If rdSegmentListing.SelectedIndex = 0 Then
                'display all
                objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_LISTING, "0")

               
                'committee
                'objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_SEARCH_ACTION_URL, drpCommitteeSearchActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_ADD_MEMBER_ACTION_URL, drpCommitteeAddMemberActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_RENEW_ALL_ACTION_URL, drpCommitteeRenewAllActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_BUY_PRODUCT_ACTION_URL, drpCommitteeBuyProductActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL, drpCommitteeAffiliateListGroupPurchaseAction.Url)
                'employee
                'objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_SEARCH_ACTION_URL, drpEmployeeSearchActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_ADD_MEMBER_ACTION_URL, drpEmployeeAddMemberActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_RENEW_ALL_ACTION_URL, drpEmployeeRenewAllActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_BUY_PRODUCT_ACTION_URL, drpEmployeeBuyProductActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL, drpEmployeeAffiliateListGroupPurchaseAction.Url)
                'membership
                'objModules.UpdateModuleSetting(Me.ModuleId, C_MEMBERSHIP_SEARCH_ACTION_URL, drpMembershipSearchActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_MEMBERSHIP_RENEW_ALL_ACTION_URL, drpMembershipRenewAllActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_MEMBERSHIP_BUY_PRODUCT_ACTION_URL, drpMembershipBuyProductActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_MEMBERSHIP_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL, drpMembershipAffiliateListGroupPurchaseAction.Url)
                'miscellaneous
                'objModules.UpdateModuleSetting(Me.ModuleId, C_MISCELLANEOUS_SEARCH_ACTION_URL, drpMiscellaneousSearchActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_MISCELLANEOUS_RENEW_ALL_ACTION_URL, drpMiscellaneousRenewAllActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_MISCELLANEOUS_BUY_PRODUCT_ACTION_URL, drpMiscellaneousBuyProductActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL, drpMiscellaneousAffiliateListGroupPurchaseAction.Url)
                'geographic
                'objModules.UpdateModuleSetting(Me.ModuleId, C_GEOGRAPHIC_SEARCH_ACTION_URL, drpGeographicSearchActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_GEOGRAPHIC_RENEW_ALL_ACTION_URL, drpGeographicRenewAllActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_GEOGRAPHIC_BUY_PRODUCT_ACTION_URL, drpGeographicBuyProductActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_GEOGRAPHIC_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL, drpGeographicAffiliateListGroupPurchaseAction.Url)

            Else
                'ordering segments only
                objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_LISTING, "1")
            End If
            
            'Member Listing ActionURL's
            objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_LISTING_ACTION_URL, drpCommitteeListingActionURL.Url)
            objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_LISTING_ACTION_URL, drpEmployeeListingActionURL.Url)
            objModules.UpdateModuleSetting(Me.ModuleId, C_MEMBERSHIP_LISTING_ACTION_URL, drpMembershipListingActionURL.Url)
            objModules.UpdateModuleSetting(Me.ModuleId, C_MISC_LISTING_ACTION_URL, drpMiscListingActionURL.Url)
            objModules.UpdateModuleSetting(Me.ModuleId, C_GEOGRAPHIC_LISTING_ACTION_URL, drpGeographicListingActionURL.Url)

            'D00031572 - DisplayOnPage settings
            objModules.UpdateModuleSetting(Me.ModuleId, C_COMMITTEE_DISPLAY_ON_PAGE, CStr(IIf(chkCommitteeDisplayOnPage.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, C_EMPLOYEE_DISPLAY_ON_PAGE, CStr(IIf(chkEmployeeDisplayOnPage.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, C_MEMBERSHIP_DISPLAY_ON_PAGE, CStr(IIf(chkMembershipDisplayOnPage.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, C_MISC_DISPLAY_ON_PAGE, CStr(IIf(chkMiscDisplayOnPage.Checked, "Y", "N")))
            objModules.UpdateModuleSetting(Me.ModuleId, C_GEOGRAPHIC_DISPLAY_ON_PAGE, CStr(IIf(chkGeographicDisplayOnPage.Checked, "Y", "N")))
            
            'End D00031572

            objModules = Nothing
        End Sub

#End Region



    End Class

End Namespace
