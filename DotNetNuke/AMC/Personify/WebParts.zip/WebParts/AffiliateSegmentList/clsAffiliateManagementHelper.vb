Namespace Personify.DNN.Modules.AffiliateSegmentList
    Public Class clsAffiliateManagementHelper
#Region "Constants"

        Public Const C_SEGMENT_LISTING As String = "DisplayAs" '"SegmentListing"
        'Edit segment listing
        Public Const C_ALLOW_SEGMENT_CREATE As String = "AllowSegmentCreate"
        Public Const C_CREATE_EMPLOYMENT_SEGMENT_ACTION_URL As String = "AddEmploymentSegmentActionURL" '"CreateSegmentActionURL"
        Public Const C_CREATE_COMMITTEE_SEGMENT_ACTION_URL As String = "AddCommitteeSegmentActionURL" '
        Public Const C_ALLOW_SEGMENT_EDITS As String = "AllowSegmentEdit"
        Public Const C_SEGMENT_EDIT_ACTION_URL As String = "SegmentEditActionURL"
        Public Const C_ALLOW_SEGMENT_ORDER As String = "AllowSegmentOrder"
        'Public Const C_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL As String = "AffiliateListGroupPurchaseActionURL"

        'Public Const C_SEGMENT_ORDER_ACTION_URL As String = "SegmentOrderActionURL"
        'Committee
        'Public Const C_COMMITTEE_SEARCH_ACTION_URL As String = "CommitteeSearchActionURL"
        Public Const C_COMMITTEE_ADD_MEMBER_ACTION_URL As String = "CommitteeAddMemberActionURL"
        Public Const C_COMMITTEE_RENEW_ALL_ACTION_URL As String = "CommitteeRenewAllActionURL"
        Public Const C_COMMITTEE_BUY_PRODUCT_ACTION_URL As String = "CommitteeBuyProductActionURL"
        Public Const C_COMMITTEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL As String = "CommitteeAffiliateListGroupPurchaseActionURL"

        'Employee
        'Public Const C_EMPLOYEE_SEARCH_ACTION_URL As String = "EmployeeSearchActionURL"
        Public Const C_EMPLOYEE_ADD_MEMBER_ACTION_URL As String = "EmployeeAddMemberActionURL"
        Public Const C_EMPLOYEE_RENEW_ALL_ACTION_URL As String = "EmployeeRenewAllActionURL"
        Public Const C_EMPLOYEE_BUY_PRODUCT_ACTION_URL As String = "EmployeeBuyProductActionURL"
        Public Const C_EMPLOYEE_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL As String = "EmployeeAffiliateListGroupPurchaseActionURL"

        'Membership
        'Public Const C_MEMBERSHIP_SEARCH_ACTION_URL As String = "MembershipSearchActionURL"
        Public Const C_MEMBERSHIP_RENEW_ALL_ACTION_URL As String = "MembershipRenewAllActionURL"
        Public Const C_MEMBERSHIP_BUY_PRODUCT_ACTION_URL As String = "MembershipBuyProductActionURL"
        Public Const C_MEMBERSHIP_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL As String = "MembershipAffiliateListGroupPurchaseActionURL"
        'Miscellaneous
        'Public Const C_MISCELLANEOUS_SEARCH_ACTION_URL As String = "MiscellaneousSearchActionURL"
        Public Const C_MISCELLANEOUS_RENEW_ALL_ACTION_URL As String = "MiscellaneousRenewAllActionURL"
        Public Const C_MISCELLANEOUS_BUY_PRODUCT_ACTION_URL As String = "MiscellaneousBuyProductActionURL"
        Public Const C_MISCELLANEOUS_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL As String = "MiscellaneousAffiliateListGroupPurchaseActionURL"
        'Geographic
        'Public Const C_GEOGRAPHIC_SEARCH_ACTION_URL As String = "GeographicSearchActionURL"
        Public Const C_GEOGRAPHIC_RENEW_ALL_ACTION_URL As String = "GeographicRenewAllActionURL"
        Public Const C_GEOGRAPHIC_BUY_PRODUCT_ACTION_URL As String = "GeographicBuyProductActionURL"
        Public Const C_GEOGRAPHIC_AFFILIATELIST_GROUP_PURCHASE_ACTION_URL As String = "GeographicAffiliateListGroupPurchaseActionURL"


        'D00031572 - DisplayOnPage settings
        Public Const C_COMMITTEE_DISPLAY_ON_PAGE As String = "CommitteeDisplayOnPage"
        Public Const C_EMPLOYEE_DISPLAY_ON_PAGE As String = "EmployeeDisplayOnPage"
        Public Const C_MEMBERSHIP_DISPLAY_ON_PAGE As String = "MembershipDisplayOnPage"
        Public Const C_MISC_DISPLAY_ON_PAGE As String = "MiscDisplayOnPage"
        Public Const C_GEOGRAPHIC_DISPLAY_ON_PAGE As String = "GeographicDisplayOnPage"
        'End D00031572

        'Member Action URL's
        Public Const C_COMMITTEE_LISTING_ACTION_URL As String = "CommitteeListingActionURL"
        Public Const C_EMPLOYEE_LISTING_ACTION_URL As String = "EmployeeListingActionURL"
        Public Const C_MEMBERSHIP_LISTING_ACTION_URL As String = "MembershipListingActionURL"
        Public Const C_MISC_LISTING_ACTION_URL As String = "MiscListingActionURL"
        Public Const C_GEOGRAPHIC_LISTING_ACTION_URL As String = "GeographicListingActionURL"
#End Region
    End Class
End Namespace
