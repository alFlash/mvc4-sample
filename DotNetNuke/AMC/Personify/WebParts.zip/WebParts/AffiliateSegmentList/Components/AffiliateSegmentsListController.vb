Imports System
Imports System.Data
Imports Personify.DNN.Modules.AffiliateSegmentList.Data

Namespace Personify.DNN.Modules.AffiliateSegmentList.Business

    Public Class AffiliateSegmentListController
        'Implements Entities.Modules.ISearchable
        'Implements Entities.Modules.IPortable

#Region "Pulic Methods"
        '---------------------------------------------------------------------
        ' TODO Implement BLL methods
        ' You can use CodeSmith templates to generate this code
        '---------------------------------------------------------------------
        Public Function List() As ArrayList
            Return Nothing 'CBO.FillCollection(DataProvider.Instance().ListAffiliateSegmentList(), GetType(AffiliateSegmentListInfo))
        End Function

        Public Function GetByModules(ByVal ModuleId As Integer) As ArrayList
            Return Nothing 'CBO.FillCollection(DataProvider.Instance().GetAffiliateSegmentListByModules(ModuleId), GetType(AffiliateSegmentListInfo))
        End Function

        Public Function [Get](ByVal ItemID As Integer, ByVal ModuleId As Integer) As AffiliateSegmentListInfo
            Return Nothing 'CType(CBO.FillObject(DataProvider.Instance().GetAffiliateSegmentList(ItemID, ModuleId), GetType(AffiliateSegmentListInfo)), AffiliateSegmentListInfo)
        End Function

        Public Function Add(ByVal objAffiliateSegmentList As AffiliateSegmentListInfo) As Integer
            Return Nothing 'CType(DataProvider.Instance().AddAffiliateSegmentList(objAffiliateSegmentList.ModuleId, objAffiliateSegmentList.Field1), Integer)
        End Function

        Public Sub Update(ByVal objAffiliateSegmentList As AffiliateSegmentListInfo)
            'DataProvider.Instance().UpdateAffiliateSegmentList(objAffiliateSegmentList.ItemId, objAffiliateSegmentList.Field1)
        End Sub

        Public Sub Delete(ByVal ItemID As Integer)
            'DataProvider.Instance().DeleteAffiliateSegmentList(ItemID)
        End Sub
#End Region

#Region "Optional Interfaces"
        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

        'End Function

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

        'End Sub
#End Region

    End Class

End Namespace
