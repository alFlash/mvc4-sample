Imports System
Imports Personify
Imports System.Web.UI.WebControls
Imports DotNetNuke


Namespace Personify.DNN.Modules.CustomerDemographics

    Public MustInherit Class CustomerDemographicsEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings
#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents gridTable As System.Web.UI.WebControls.DataGrid
        Protected WithEvents panelTable As System.Web.UI.WebControls.Panel
        Protected WithEvents rbtDemoSelection As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents rbtMode As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents plMode As DotNetNuke.UI.UserControls.LabelControl
#End Region

#Region "Private Members"
        Private Count As Integer
        Private xParser As New PropertyParser
        Private Const EnableColNo As Integer = 2
        Private Const EnableColName As String = "Enable"
        Private XmlLoad As Boolean = False
#End Region

#Region "Public Members"
        Public DeclareSortArray As String
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")
                    Localization.LocalizeDataGrid(gridTable, Me.LocalResourceFile)
                    panelTable.Visible = False
                    BindSelection()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                If Page.IsValid = True Then
                    'UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

                    If Not (rbtDemoSelection.SelectedIndex = -1) Then
                        xParser.LoadPropertyFile(MapPath("DemographicProperties.xml"))
                        xParser.FirstItem()
                        Do
                            xParser.SetValue()

                            If (xParser.ItemID = rbtDemoSelection.SelectedValue.ToString) Then
                                If (xParser.LocateModule(ModuleId.ToString())) Then
                                    UpdateProperties()
                                Else
                                    AddProperties()
                                End If
                            Else
                                If (xParser.LocateModule(ModuleId.ToString())) Then
                                    DeleteProperties()
                                End If
                            End If


                        Loop While (xParser.NextItem())
                        xParser.SavePropertyFile(MapPath("DemographicProperties.xml"))
                    End If

                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Protected Sub rbtDemoSelection_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rbtDemoSelection.SelectedIndexChanged
            XmlLoad = False
            ShowPanel()
        End Sub

#End Region

#Region " Private sub/function "

        Private Sub ShowPanel()
            panelTable.Visible = True
            If (XmlLoad = False) Then
                xParser.LoadPropertyFile(MapPath("DemographicProperties.xml"))
            End If
            xParser.FirstItem()
            Do
                xParser.SetValue()
                If (xParser.ItemID = rbtDemoSelection.SelectedValue) Then
                    Exit Do
                End If
            Loop While (xParser.NextItem)

            'Not going to show Mode option right now, comment out following lines for not show 
            'this option
            'If (xParser.Special = "Add") Then
            '    rbtMode.Visible = True
            '    plMode.Visible = True
            'Else
            '    rbtMode.Visible = False
            '    plMode.Visible = False
            'End If

            rbtMode.Visible = False
            plMode.Visible = False

            BindGrid()
            BindSetting()
        End Sub

        Private Sub ShowEnableCheckBox(ByVal row As Integer, ByVal column As Integer, ByVal show As Boolean)
            Dim cbxEnable As System.Web.UI.WebControls.CheckBox

            cbxEnable = CType(GetColumnControl(row, column, "cbxEnable"), System.Web.UI.WebControls.CheckBox)
            If Not (cbxEnable Is Nothing) Then
                cbxEnable.Visible = show
                cbxEnable.Enabled = show
            End If
        End Sub

        Private Sub ShowEnableRadioButtonList(ByVal row As Integer, ByVal column As Integer, ByVal show As Boolean)
            Dim rbtEnable As System.Web.UI.WebControls.RadioButtonList

            rbtEnable = CType(GetColumnControl(row, column, "rbtEnable"), System.Web.UI.WebControls.RadioButtonList)
            If Not (rbtEnable Is Nothing) Then
                rbtEnable.Visible = show
                rbtEnable.Enabled = show
            End If
        End Sub

        Private Sub DeleteProperties()
            xParser.DeleteProperties()
        End Sub

        Private Sub UpdateProperties()
            Dim i As Integer
            Dim sort As System.Web.UI.WebControls.DropDownList
            Dim display As System.Web.UI.WebControls.TextBox
            Dim enable As System.Web.UI.WebControls.CheckBox
            Dim cbxReadonly As System.Web.UI.WebControls.CheckBox

            Dim enableAdd As Boolean = False
            Dim enableEdit As Boolean = False

            For i = 0 To gridTable.Items.Count - 1
                If (xParser.LocateProperty(gridTable.Items.Item(i).Cells.Item(0).Text)) Then

                    display = CType(GetColumnControl(i, 1, "tbxDspTitle"), System.Web.UI.WebControls.TextBox)
                    If Not (display Is Nothing) Then
                        xParser.Caption = display.Text
                    End If

                    enable = CType(GetColumnControl(i, 2, "cbxDisplay"), System.Web.UI.WebControls.CheckBox)
                    If Not (enable Is Nothing) Then
                        If (enable.Checked) Then
                            xParser.Display = "True"
                        Else
                            xParser.Display = "False"
                        End If
                    End If

                    enable = CType(GetColumnControl(i, 3, "cbxEnableAdd"), System.Web.UI.WebControls.CheckBox)
                    cbxReadonly = CType(GetColumnControl(i, 3, "cbxAddReadOnly"), System.Web.UI.WebControls.CheckBox)
                    If Not (enable Is Nothing Or cbxReadonly Is Nothing) Then
                        If (enable.Checked And cbxReadonly.Checked) Then
                            xParser.EnableAdd = "ReadOnly"
                            enableAdd = True
                        ElseIf (enable.Checked) Then
                            xParser.EnableAdd = "True"
                            enableAdd = True
                        Else
                            xParser.EnableAdd = "False"
                        End If
                    End If

                    enable = CType(GetColumnControl(i, 4, "cbxEnableEdit"), System.Web.UI.WebControls.CheckBox)
                    cbxReadonly = CType(GetColumnControl(i, 4, "cbxEditReadOnly"), System.Web.UI.WebControls.CheckBox)
                    If Not (enable Is Nothing Or cbxReadonly Is Nothing) Then
                        If (enable.Checked And cbxReadonly.Checked) Then
                            xParser.EnableEdit = "ReadOnly"
                            enableEdit = True
                        ElseIf (enable.Checked) Then
                            xParser.EnableEdit = "True"
                            enableEdit = True
                        Else
                            xParser.EnableEdit = "False"
                        End If
                    End If

                    enable = CType(GetColumnControl(i, 5, "cbxRequired"), System.Web.UI.WebControls.CheckBox)
                    If Not (enable Is Nothing) Then
                        If (enable.Checked) Then
                            xParser.Required = "True"
                        Else
                            xParser.Required = "False"
                        End If
                    End If

                    sort = CType(GetColumnControl(i, 6, "ddlSort"), System.Web.UI.WebControls.DropDownList)
                    If Not (sort Is Nothing) Then
                        xParser.Sort = sort.SelectedValue
                    End If

                    xParser.UpdateProperties()
                End If
            Next

            If (xParser.LocateProperty("Institution")) Then
                xParser.SetValue()
                xParser.Generate = "False"
                xParser.EnableAdd = "False"
                xParser.EnableEdit = "False"
                xParser.Display = "False"
                xParser.Sort = "-1"
                xParser.UpdateProperties()
            End If

            If (rbtMode.Visible) Then
                If (rbtMode.SelectedIndex = 0) Then
                    xParser.Mode = "Add"
                Else
                    If (enableEdit) Then
                        xParser.Mode = "Edit"
                    Else
                        xParser.Mode = "Display"
                    End If
                End If
            Else
                If (enableAdd) Then
                    If (enableEdit) Then
                        xParser.Mode = "EditAndAdd"
                    Else
                        xParser.Mode = "Add"
                    End If
                Else
                    If (enableEdit) Then
                        xParser.Mode = "Edit"
                    Else
                        xParser.Mode = "Display"
                    End If
                End If
            End If

            xParser.ModuleID = ModuleId.ToString
            xParser.UpdateModule()
        End Sub

        'Private Sub UpdateEnable(ByVal row As Integer)
        '    If (rbtMode.SelectedValue = "Display") Then
        '        UpdateEnableCheckBox(row)
        '    Else
        '        UpdateEnableRadioButtonList(row)
        '    End If
        'End Sub

        'Private Sub UpdateEnableCheckBox(ByVal row As Integer)
        '    Dim enable As System.Web.UI.WebControls.CheckBox

        '    enable = CType(GetColumnControl(row, EnableColNo, "cbxEnable"), System.Web.UI.WebControls.CheckBox)
        '    If Not (enable Is Nothing) Then
        '        If (enable.Checked) Then
        '            xParser.Enable = "ReadOnly"
        '        Else
        '            xParser.Enable = "False"
        '        End If
        '    End If
        'End Sub

        'Private Sub UpdateEnableRadioButtonList(ByVal row As Integer)
        '    Dim enable As System.Web.UI.WebControls.RadioButtonList

        '    enable = CType(GetColumnControl(row, EnableColNo, "rbtEnable"), System.Web.UI.WebControls.RadioButtonList)
        '    If Not (enable Is Nothing) Then
        '        If (enable.SelectedValue = "Disable") Then
        '            xParser.Enable = "False"
        '        ElseIf (enable.SelectedValue = "ReadOnly") Then
        '            xParser.Enable = "ReadOnly"
        '        Else
        '            xParser.Enable = "Editable"
        '        End If
        '    End If
        'End Sub

        Private Sub AddProperties()
            xParser.AddModule()
            xParser.ModuleID = ModuleId.ToString()
            xParser.Mode = "Display"
            xParser.UpdateModule()

            If (xParser.LocateModule(ModuleId.ToString())) Then
                UpdateProperties()
            End If
        End Sub

        Private Sub BindSelection()
            xParser.LoadPropertyFile(MapPath("DemographicProperties.xml"))
            XmlLoad = True
            xParser.FirstItem()

            Do
                Dim listitem As New System.Web.UI.WebControls.ListItem

                xParser.SetValue()
                If Not xParser.ItemID = "CustomerInfo.Customers" Then
                    listitem.Text = xParser.ItemName
                    listitem.Value = xParser.ItemID
                    rbtDemoSelection.Items.Add(listitem)
                    If (xParser.LocateModule(ModuleId.ToString)) Then
                        listitem.Selected = True
                        ShowPanel()
                    End If
                End If
            Loop While (xParser.NextItem)
        End Sub

        Private Sub BindGrid()
            xParser.LoadPropertyFile(MapPath("DemographicProperties.xml"))
            gridTable.DataSource = CreateDataTable(GetFields())
            gridTable.DataBind()
        End Sub

        Private Function CreateDataTable(ByVal ht As Hashtable) As DataTable
            Dim list As New ArrayList
            list.Clear()

            Dim collection As ICollection
            collection = ht.Keys

            Dim enums As IEnumerator
            enums = collection.GetEnumerator()
            enums.Reset()

            Dim dc As New DataColumn
            dc.ColumnName = "Value"
            dc.DataType = System.Type.GetType("System.String")
            Dim dt As New DataTable
            dt.Columns.Add(dc)

            Dim dr As DataRow
            xParser.LocateItem(rbtDemoSelection.SelectedValue.ToString())
            If Not (xParser.LocateModule(ModuleId.ToString())) Then
                xParser.LocateModule("0")
            End If


            While (enums.MoveNext())
                If (xParser.LocateProperty(enums.Current.ToString())) Then
                    xParser.SetValue()
                    If (xParser.Generate = "True") Then
                        If Not (xParser.Prop = "Institution") Then
                            dr = dt.NewRow()
                            dr("Value") = enums.Current.ToString()
                            dt.Rows.Add(dr)
                        End If
                    End If
                End If
            End While

            Dim i As Integer
            Dim sortDC As New DataColumn
            sortDC.ColumnName = "Value"
            sortDC.DataType = System.Type.GetType("System.String")
            Dim sortDT As New DataTable
            sortDT.Columns.Add(sortDC)

            Dim count As Integer = dt.Rows.Count

            If xParser.ItemName = "Customer Education" Then
                count = count + 1
            End If

            For i = 1 To count
                xParser.LocateProperty(i)
                xParser.SetValue()
                If (Not (xParser.Prop = "Institution")) AndAlso (CType(xParser.Sort, Integer) = i) Then
                    For Each row As DataRow In dt.Rows
                        If (row("Value").ToString = xParser.Prop.ToString) Then
                            dr = sortDT.NewRow()
                            dr("Value") = row("Value").ToString
                            sortDT.Rows.Add(dr)
                            Exit For
                        End If
                    Next
                End If
            Next

            Return sortDT
        End Function

        Private Function GetFields() As Hashtable
            Return Me.PersonifyGetCollection(rbtDemoSelection.SelectedValue.ToString()).Schema.GetPropertyToColumnMap()
        End Function

        Private Sub BindSetting()
            Dim list As New ArrayList
            Dim i As Integer

            For i = 1 To gridTable.Items.Count
                list.Add(i)
            Next

            Dim sort As System.Web.UI.WebControls.DropDownList
            Dim display As System.Web.UI.WebControls.TextBox
            Dim enable As System.Web.UI.WebControls.CheckBox
            Dim cbxReadonly As System.Web.UI.WebControls.CheckBox
            Dim SortControlNames As New ArrayList

            Dim changeFlag As Boolean = False

            If rbtMode.Visible Then
                xParser.SetValue()
                If (xParser.Mode = "Add") Then
                    rbtMode.SelectedIndex = 0
                ElseIf (xParser.Mode = "EditAndAdd") Then
                    rbtMode.SelectedIndex = 0
                ElseIf (xParser.Mode = "Edit") Then
                    rbtMode.SelectedIndex = 1
                Else
                    rbtMode.SelectedIndex = 1
                End If
            End If

            If (xParser.LocateProperty("Institution")) Then
                xParser.SetValue()
                If (xParser.Prop = "Institution") Then
                    If (CType(xParser.Sort, Integer) = 3) Then
                        changeFlag = False
                    Else
                        changeFlag = True
                    End If
                End If
            End If

            For i = 0 To gridTable.Items.Count - 1
                If (xParser.LocateProperty(gridTable.Items.Item(i).Cells.Item(0).Text)) Then
                    xParser.SetValue()
                End If

                display = CType(GetColumnControl(i, 1, "tbxDspTitle"), System.Web.UI.WebControls.TextBox)
                If Not (display Is Nothing) Then
                    display.Text = xParser.Caption
                End If

                'SetEnableControl(i, EnableColNo)
                'BindEnableCheckBox(i)
                'BindEnableRadioButtonList(i)

                enable = CType(GetColumnControl(i, 2, "cbxDisplay"), System.Web.UI.WebControls.CheckBox)
                If Not (enable Is Nothing) Then
                    If (xParser.Display = "False") Then
                        enable.Checked = False
                    Else
                        enable.Checked = True
                    End If
                End If

                enable = CType(GetColumnControl(i, 3, "cbxEnableAdd"), System.Web.UI.WebControls.CheckBox)
                If Not (enable Is Nothing) Then

                    If (xParser.EnableAdd = "False") Then
                        enable.Checked = False
                    Else
                        enable.Checked = True
                    End If
                End If

                cbxReadonly = CType(GetColumnControl(i, 3, "cbxAddReadOnly"), System.Web.UI.WebControls.CheckBox)
                If Not (cbxReadonly Is Nothing) Then
                    If (xParser.EnableAdd = "ReadOnly") Then
                        cbxReadonly.Checked = True
                    Else
                        cbxReadonly.Checked = False
                    End If
                End If

                enable = CType(GetColumnControl(i, 4, "cbxEnableEdit"), System.Web.UI.WebControls.CheckBox)
                If Not (enable Is Nothing) Then
                    If (xParser.EnableEdit = "False") Then
                        enable.Checked = False
                    Else
                        enable.Checked = True
                    End If
                End If

                cbxReadonly = CType(GetColumnControl(i, 4, "cbxEditReadOnly"), System.Web.UI.WebControls.CheckBox)
                If Not (cbxReadonly Is Nothing) Then
                    If (xParser.EnableEdit = "ReadOnly") Then
                        cbxReadonly.Checked = True
                    Else
                        cbxReadonly.Checked = False
                    End If
                End If

                enable = CType(GetColumnControl(i, 5, "cbxRequired"), System.Web.UI.WebControls.CheckBox)
                If Not (enable Is Nothing) Then
                    If (xParser.Required = "False") Then
                        enable.Checked = False
                    Else
                        enable.Checked = True
                    End If
                End If

                sort = CType(GetColumnControl(i, 6, "ddlSort"), System.Web.UI.WebControls.DropDownList)
                If Not (sort Is Nothing) Then
                    SortControlNames.Add(sort.ClientID)
                    sort.DataSource = list
                    sort.DataBind()

                    If (xParser.ItemName = "Customer Education") AndAlso (CType(xParser.Sort, Integer) > 3) AndAlso (Not changeFlag) Then
                        sort.SelectedValue = (CType(xParser.Sort, Integer) - 1).ToString
                    Else
                        sort.SelectedValue = xParser.Sort
                    End If
                    sort.Attributes.Add("onChange", "javascript: change(" & (SortControlNames.Count - 1).ToString & ");")
                End If
            Next

            SetDeclareSortArray(SortControlNames)
        End Sub

        Private Sub SetDeclareSortArray(ByVal ControlNames As ArrayList)
            Dim i As Integer

            DeclareSortArray = "var ScontrolSID = new Array(" & ControlNames.Count.ToString & ");"
            DeclareSortArray += "var howmany;"
            DeclareSortArray += "var i;"

            DeclareSortArray += "howmany = " & ControlNames.Count.ToString & ";"
            For i = 0 To ControlNames.Count - 1
                DeclareSortArray += "ScontrolSID[" & i.ToString & "] = """ & ControlNames(i).ToString & """;"
            Next
        End Sub

        'Private Sub BindEnable(ByVal row As Integer)
        '    If Not (rbtMode.SelectedValue = "") Then
        '        If (rbtMode.SelectedValue = "Display") Then
        '            BindEnableCheckBox(row)
        '        Else
        '            BindEnableRadioButtonList(row)
        '        End If
        '    Else
        '        If (xParser.Mode = "Display") Then
        '            BindEnableCheckBox(row)
        '        Else
        '            BindEnableRadioButtonList(row)
        '        End If
        '    End If
        'End Sub

        'Private Sub BindEnableCheckBox(ByVal row As Integer)
        '    Dim enable As System.Web.UI.WebControls.CheckBox
        '    enable = CType(GetColumnControl(row, EnableColNo, "cbxEnable"), System.Web.UI.WebControls.CheckBox)

        '    If Not (enable Is Nothing) Then
        '        If (xParser.Enable = "False") Then
        '            enable.Checked = False
        '        Else
        '            enable.Checked = True
        '        End If
        '    End If
        'End Sub

        'Private Sub BindEnableRadioButtonList(ByVal row As Integer)
        '    Dim enable As System.Web.UI.WebControls.RadioButtonList
        '    enable = CType(GetColumnControl(row, EnableColNo, "rbtEnable"), System.Web.UI.WebControls.RadioButtonList)

        '    If Not (enable Is Nothing) Then
        '        If (xParser.Enable = "False") Then
        '            enable.SelectedValue = "Disable"
        '        ElseIf (xParser.Enable = "ReadOnly") Then
        '            enable.SelectedValue = "ReadOnly"
        '        Else
        '            enable.SelectedValue = "Editable"
        '        End If
        '    End If
        'End Sub

        Private Function GetColumnControl(ByVal Row As Integer, ByVal Column As Integer, ByVal ControlID As String) As System.Web.UI.Control
            Dim i As Integer
            If (gridTable.Items.Item(Row).Controls.Item(Column).HasControls) Then
                For i = 0 To gridTable.Items.Item(Row).Controls.Item(Column).Controls.Count - 1
                    If (gridTable.Items.Item(Row).Controls.Item(Column).Controls.Item(i).ID = ControlID) Then
                        Return gridTable.Items.Item(Row).Controls.Item(Column).Controls.Item(i)
                    End If
                Next
            End If
            Return Nothing
        End Function


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
