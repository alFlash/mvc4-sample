Imports system.Xml

'Imports TIMSSCMS.DNN.Modules.CustomerDemographics.Business

Namespace Personify.DNN.Modules.CustomerDemographics

    Public Class PropertyParser

#Region " Private Members "
        Private xDoc As XmlDocument
        Private xRoot As XmlElement
        Private xItem As XmlNode
        Private xModule As XmlNode
        Private xProperty As XmlNode
        Private xNode As XmlNode

        Private _ItemName As String
        Private _ItemID As String
        Private _ApiCollection As String
        Private _ParentCollection As String
        Private _Keys As String
        Private _Special As String

        Private _ModuleID As String
        Private _Mode As String

        Private _Caption As String
        Private _Generate As String
        Private _Property As String
        Private _Type As String
        Private _Required As String
        Private _EnableAdd As String
        Private _EnableEdit As String
        Private _Display As String
        Private _Sort As String
        Private _TypeName As String
        Private _SubSystem As String
        Private _Code As String
        Private _Source As String
        Private _Control As String
#End Region

#Region " Properties "
        Public Property ItemName() As String
            Get
                Return _ItemName
            End Get
            Set(ByVal value As String)
                _ItemName = value
            End Set
        End Property

        Public Property ApiCollection() As String
            Get
                Return _ApiCollection
            End Get
            Set(ByVal value As String)
                _ApiCollection = value
            End Set
        End Property

        Public Property ParentCollection() As String
            Get
                Return _ParentCollection
            End Get
            Set(ByVal value As String)
                _ParentCollection = value
            End Set
        End Property

        Public Property ItemID() As String
            Get
                Return _ItemID
            End Get
            Set(ByVal value As String)
                _ItemID = value
            End Set
        End Property

        Public Property Keys() As String
            Get
                Return _Keys
            End Get
            Set(ByVal value As String)
                _Keys = value
            End Set
        End Property

        Public Property Special() As String
            Get
                Return _Special
            End Get
            Set(ByVal value As String)
                _Special = value
            End Set
        End Property

        Public Property ModuleID() As String
            Get
                Return _ModuleID
            End Get
            Set(ByVal value As String)
                _ModuleID = value
            End Set
        End Property

        Public Property Caption() As String
            Get
                Return _Caption
            End Get
            Set(ByVal value As String)
                _Caption = value
            End Set
        End Property

        Public Property Mode() As String
            Get
                Return _Mode
            End Get
            Set(ByVal value As String)
                _Mode = value
            End Set
        End Property

        Public Property Generate() As String
            Get
                Return _Generate
            End Get
            Set(ByVal value As String)
                _Generate = value
            End Set
        End Property

        Public Property Prop() As String
            Get
                Return _Property
            End Get
            Set(ByVal value As String)
                _Property = value
            End Set
        End Property

        Public Property Type() As String
            Get
                Return _Type
            End Get
            Set(ByVal value As String)
                _Type = value
            End Set
        End Property

        Public Property Required() As String
            Get
                Return _Required
            End Get
            Set(ByVal value As String)
                _Required = value
            End Set
        End Property

        Public Property EnableAdd() As String
            Get
                Return _EnableAdd
            End Get
            Set(ByVal value As String)
                _EnableAdd = value
            End Set
        End Property

        Public Property EnableEdit() As String
            Get
                Return _EnableEdit
            End Get
            Set(ByVal value As String)
                _EnableEdit = value
            End Set
        End Property

        Public Property Display() As String
            Get
                Return _Display
            End Get
            Set(ByVal value As String)
                _Display = value
            End Set
        End Property

        Public Property Sort() As String
            Get
                Return _Sort
            End Get
            Set(ByVal value As String)
                _Sort = value
            End Set
        End Property

        Public Property TypeName() As String
            Get
                Return _TypeName
            End Get
            Set(ByVal value As String)
                _TypeName = value
            End Set
        End Property

        Public Property SubSystem() As String
            Get
                Return _SubSystem
            End Get
            Set(ByVal value As String)
                _SubSystem = value
            End Set
        End Property

        Public Property Code() As String
            Get
                Return _Code
            End Get
            Set(ByVal value As String)
                _Code = value
            End Set
        End Property

        Public Property Source() As String
            Get
                Return _Source
            End Get
            Set(ByVal value As String)
                _Source = value
            End Set
        End Property

        Public Property Control() As String
            Get
                Return _Control
            End Get
            Set(ByVal value As String)
                _Control = value
            End Set
        End Property

#End Region

#Region " Private Sub/Fuctions "

        Sub New()
            xDoc = New XmlDocument
        End Sub

        Private Sub SetProperties()
            _Caption = xProperty.Attributes("Caption").Value.ToString
            _Generate = xProperty.Attributes("Generate").Value.ToString
            _Property = xProperty.Attributes("Property").Value.ToString
            _Type = xProperty.Attributes("Type").Value.ToString
            _Required = xProperty.Attributes("Required").Value.ToString
            _EnableAdd = xProperty.Attributes("EnableAdd").Value.ToString
            _EnableEdit = xProperty.Attributes("EnableEdit").Value.ToString
            _Display = xProperty.Attributes("Display").Value.ToString
            _Sort = xProperty.Attributes("Sort").Value.ToString
            _TypeName = xProperty.Attributes("TypeName").Value.ToString
            _SubSystem = xProperty.Attributes("SubSystem").Value.ToString
            _Code = xProperty.Attributes("Code").Value.ToString
            _Source = xProperty.Attributes("Source").Value.ToString
            _Control = xProperty.Attributes("Control").Value.ToString
        End Sub

        Private Sub SetModule()
            _ModuleID = xModule.Attributes("Id").Value.ToString
            _Mode = xModule.Attributes("Mode").Value.ToString
        End Sub

        Private Sub SetItem()
            _ItemID = xItem.Attributes("Id").Value.ToString
            _ItemName = xItem.Attributes("Name").Value.ToString
            _ApiCollection = xItem.Attributes("ApiCollection").Value.ToString
            _Keys = xItem.Attributes("Keys").Value.ToString
            _ParentCollection = xItem.Attributes("ParentCollection").Value.ToString
            _Special = xItem.Attributes("Special").Value.ToString
        End Sub

        Private Function CreateAttribute(ByVal Name As String, ByVal Value As String) As XmlAttribute
            Dim attribute As XmlAttribute

            attribute = xDoc.CreateAttribute(Name)
            attribute.Value = Value

            Return attribute
        End Function


#End Region

#Region " Public Sub/Functions "

        Public Sub LoadPropertyFile(ByVal FileName As String)
            Dim xmlDoc As XmlDocument
            xmlDoc = New XmlDocument

            SyncLock xmlDoc
                xmlDoc.Load(FileName)
                xRoot = xmlDoc.DocumentElement
            End SyncLock
            xmlDoc = Nothing
        End Sub

        Public Function LocateItem(ByVal ItemID As String) As Boolean
            If ((xRoot.HasChildNodes) And (Not (xRoot Is Nothing))) Then
                xItem = xRoot.FirstChild
                While Not (xItem.Attributes("Id").Value = ItemID)
                    xItem = xItem.NextSibling

                    If (xItem Is Nothing) Then
                        Return False
                    End If
                End While
            End If

            Return True
        End Function

        Public Function LocateModule(ByVal ModuleID As String) As Boolean
            If ((xItem.HasChildNodes) And (Not (xItem Is Nothing))) Then
                xModule = xItem.FirstChild
                While Not (xModule.Attributes("Id").Value = ModuleID)
                    xModule = xModule.NextSibling

                    If (xModule Is Nothing) Then
                        Return False
                    End If
                End While
            End If

            Return True
        End Function

        Public Function LocateProperty(ByVal Ppt As String) As Boolean
            If ((xModule.HasChildNodes) And (Not (xModule Is Nothing))) Then
                xProperty = xModule.FirstChild
                While Not (xProperty.Attributes("Property").Value = Ppt)
                    xProperty = xProperty.NextSibling

                    If (xProperty Is Nothing) Then
                        Return False
                    End If
                End While
            End If

            Return True
        End Function

        Public Function LocateProperty(ByVal Sort As Integer) As Boolean
            If ((xModule.HasChildNodes) And (Not (xModule Is Nothing))) Then
                xProperty = xModule.FirstChild
                While Not (xProperty.Attributes("Sort").Value = Sort.ToString)
                    xProperty = xProperty.NextSibling

                    If (xProperty Is Nothing) Then
                        Return False
                    End If
                End While
            End If

            Return True
        End Function

        Public Function NextProperty() As Boolean
            If (xProperty.NextSibling Is Nothing) Then
                Return False
            End If

            xProperty = xProperty.NextSibling
            Return True
        End Function

        Public Function NextItem() As Boolean
            If (xItem.NextSibling Is Nothing) Then
                Return False
            End If

            xItem = xItem.NextSibling
            Return True
        End Function

        Public Sub FirstProperty(ByVal ModuleID As String)
            LocateModule(ModuleID)

            If (xModule.HasChildNodes) Then
                xProperty = xModule.FirstChild
            End If
        End Sub

        Public Sub FirstItem()
            If (xRoot.HasChildNodes) Then
                xItem = xRoot.FirstChild
            End If
        End Sub

        Public Sub SetValue()
            If Not (xItem Is Nothing) Then
                SetItem()
            End If

            If Not (xModule Is Nothing) Then
                SetModule()
            End If

            If Not (xProperty Is Nothing) Then
                SetProperties()
            End If
        End Sub

        Public Sub UpdateProperties()
            xProperty.Attributes("Caption").Value = _Caption
            xProperty.Attributes("EnableAdd").Value = _EnableAdd
            xProperty.Attributes("EnableEdit").Value = _EnableEdit
            xProperty.Attributes("Display").Value = _Display
            xProperty.Attributes("Sort").Value = _Sort
            xProperty.Attributes("Required").Value = _Required
        End Sub

        Public Sub UpdateModule()
            xModule.Attributes("Id").Value = _ModuleID
            xModule.Attributes("Mode").Value = _Mode
        End Sub

        Public Sub AddModule()
            LocateModule("0")

            xItem.AppendChild(xModule.Clone)
        End Sub

        Public Sub SavePropertyFile(ByVal filename As String)
            Dim xmlDoc As XmlDocument
            xmlDoc = New XmlDocument

            SyncLock xmlDoc
                xmlDoc.Load(filename)
                xmlDoc.DocumentElement.InnerXml = xRoot.InnerXml
                xmlDoc.Save(filename)
            End SyncLock
            xmlDoc = Nothing
        End Sub

        Public Sub DeleteProperties()
            xModule.RemoveAll()
            xItem.RemoveChild(xModule)
            xModule = Nothing
        End Sub

#End Region

    End Class
End Namespace