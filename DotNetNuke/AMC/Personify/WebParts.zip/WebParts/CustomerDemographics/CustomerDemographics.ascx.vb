Option Strict Off
Imports System
Imports System.Web.UI.WebControls
Imports Personify.ApplicationManager

Namespace Personify.DNN.Modules.CustomerDemographics
    <CLSCompliant(False)> _
    Public MustInherit Class CustomerDemographics
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable
        Implements Entities.Modules.Communications.IModuleListener
        Implements Entities.Modules.Communications.IModuleCommunicator



#Region "Controls"
        Private view As System.Web.UI.WebControls.View
        Private row As System.Web.UI.WebControls.TableRow
        Private cell As System.Web.UI.WebControls.TableCell
        Protected WithEvents tableDemoInfo As System.Web.UI.WebControls.Table
        Protected WithEvents BtnSave As New System.Web.UI.WebControls.Button
        Protected WithEvents BtnBack As New System.Web.UI.WebControls.Button
        Protected WithEvents pnlDetail As New System.Web.UI.WebControls.Panel
        Protected WithEvents pnlList As New System.Web.UI.WebControls.Panel
        Protected WithEvents dgDmgView As New System.Web.UI.WebControls.DataGrid
        Protected WithEvents btnAddRecord As New System.Web.UI.WebControls.Button
        Protected WithEvents oMessageControl As Personify.WebControls.MessageControl
        Protected WithEvents txtInstitutionName As New TextBox 'Personify.WebControls.AutoCompleteTextBox
        Protected WithEvents autoInstitutionName As New AjaxControlToolkit.AutoCompleteExtender


#End Region

#Region " Private Members "
        Private Const CONFIGFILE As String = "DemographicProperties.xml"
        Private ShowSave As Boolean = False
        Private ShowList As Boolean
        Private xParser As New PropertyParser
        Private oBusinessCollection As TIMSS.API.Core.IBusinessObjectCollection = Nothing
        Private oBusinessObject As TIMSS.API.Core.BusinessObject = Nothing
        Private CollType As CollectionType
        Private CollArgs As String()
        Private KeyCollection As String()
        Private CurrentItemID As String
        'Private strMCID As String
        'Private strSCID As String
        Private IfValidationIssues As Boolean

        Private CollAction As Action
        Private boolUnAuthorizedAccess As Boolean

        Private TimssSubCodeControls As New ArrayList
        Private TimssAppCodeControls As New ArrayList
        Private TimssSubsystemControls As New ArrayList
        Private TimssCountryControls As New ArrayList
        Private TimssControl As New Specialized.NameValueCollection
        Private TimssControlValues As New Specialized.NameValueCollection

        Private ReqValidators As New ArrayList

        Shared SortClickNumber As Integer = 0
        Private show As Boolean = True

#End Region

#Region " Enums "
        Private Enum Action
            ADD = 0
            EDIT = 1
            VIEW = 2
        End Enum
        Private Enum CollectionType
            CustomerDemographics = 0
            CustomerEducation = 1
            CustomerSpecialNeeds = 2
            CustomerSpecialty = 3
            'UserDefined = 4   'Refers to extended tables
        End Enum
#End Region

#Region "Event Handlers"

        Private Sub Pre_Render(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender

            If show Then
                If (pnlDetail.Visible) Then
                    If Not tableDemoInfo.FindControl("Comments") Is Nothing Then
                        CType(tableDemoInfo.FindControl("Comments"), TextBox).Width = 400
                        CType(tableDemoInfo.FindControl("Comments"), TextBox).Height = 50
                        CType(tableDemoInfo.FindControl("Comments"), TextBox).TextMode = TextBoxMode.MultiLine
                    End If


                    SetupPostbackControl()

                    For Each ControlID As String In ReqValidators
                        CType(tableDemoInfo.FindControl(ControlID), System.Web.UI.WebControls.RequiredFieldValidator).Visible = True
                    Next
                End If
            Else

            End If
            

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'Sample code to get data

                If show Then
                    If Page.IsPostBack Then

                        SetupPostbackControl()

                    End If
                    If CollAction = Action.VIEW Then
                        btnAddRecord.PostBackUrl = FormatControlURL(Page.Request.Url.AbsoluteUri, "ADD", ";", "mid=" & Me.ModuleId)
                    End If
                Else
                   
                End If
                
                '               DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Please configure this web part", Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Protected Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
            Try
                If (Page.IsValid) Then
                    Dim success As Boolean = SaveData()

                    If Not (IfValidationIssues) AndAlso success Then
                        Response.Redirect(NavigateURL(), True)
                    End If
                End If
            Catch ex As Threading.ThreadAbortException

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub BtnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnBack.Click
            Try
                If Not oMessageControl.ValidationIssues Is Nothing Then
                    oMessageControl.Clear()
                End If
                Response.Redirect(NavigateURL(), True)

            Catch ex As Threading.ThreadAbortException

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Private Sub dgDmgView_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgDmgView.ItemDataBound
            If e.Item.ItemType = ListItemType.AlternatingItem Then
                e.Item.Attributes.Add("OnMouseOver", "this.className=""tmar_demo_DataTable_Hover""")
                e.Item.Attributes.Add("OnMouseOut", "this.className=""" & dgDmgView.AlternatingItemStyle.CssClass & """")
            ElseIf e.Item.ItemType = ListItemType.Item Then
                e.Item.Attributes.Add("OnMouseOver", "this.className=""tmar_demo_DataTable_Hover""")
                e.Item.Attributes.Add("OnMouseOut", "this.className=""" & dgDmgView.ItemStyle.CssClass & """")
            End If
        End Sub


        Private Sub dgDmgView_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles dgDmgView.SortCommand
            Dim dt As DataTable = CType(CType(source, System.Web.UI.WebControls.DataGrid).DataSource, DataTable)
            Dim dv As New DataView(dt)

            If ((SortClickNumber Mod 2) = 0) Then
                dv.Sort = e.SortExpression + " " + "ASC"
            Else
                dv.Sort = e.SortExpression + " " + "DESC"
            End If

            SortClickNumber += 1
            dgDmgView.DataSource = dv
            dgDmgView.DataBind()
        End Sub

#End Region

#Region " Private Sub/Function "

        Private Function GetNavigationURL(Optional ByVal strAction As String = "") As String
            Dim strActionURL As String = ""

            If Not Page.Request.Url.AbsoluteUri Is Nothing Then

                If strAction.Length = 0 Then
                    strActionURL = FormatControlURL(Page.Request.Url.AbsoluteUri, strAction, "")
                Else
                    strActionURL = FormatControlURL(Page.Request.Url.AbsoluteUri, strAction, "", "mid=" & Me.ModuleId)
                End If
            End If

            Return strActionURL
        End Function

        Private Sub SetupPostbackControl()
            Dim i As Integer
            Dim j As Integer
            Dim ToSet As Boolean

            For i = 0 To TimssSubCodeControls.Count - 1
                Dim CtrlSubCode As Personify.WebControls.ApplicationSubCodeDropDownList
                CtrlSubCode = CType(tableDemoInfo.FindControl(TimssSubCodeControls(i).ToString), Personify.WebControls.ApplicationSubCodeDropDownList)

                Dim CtrlCode As Personify.WebControls.ApplicationCodeDropDownList
                CtrlCode = CType(tableDemoInfo.FindControl(TimssControl.Get(TimssSubCodeControls(i).ToString)), Personify.WebControls.ApplicationCodeDropDownList)

                CtrlSubCode.ApplicationCode = CtrlCode.SelectedValue
                CtrlSubCode.DefaultValue = CtrlSubCode.SelectedValue
                CtrlCode.DefaultValue = CtrlCode.SelectedValue
            Next

            For i = 0 To TimssAppCodeControls.Count - 1
                ToSet = True
                For j = 0 To TimssSubCodeControls.Count - 1
                    If (TimssAppCodeControls(i).ToString = TimssControl.Get(TimssSubCodeControls(j).ToString).ToString) Then
                        ToSet = False
                    End If
                Next
                If ToSet Then
                    Dim CtrlAppCode As Personify.WebControls.ApplicationCodeDropDownList
                    CtrlAppCode = CType(tableDemoInfo.FindControl(TimssAppCodeControls(i).ToString), Personify.WebControls.ApplicationCodeDropDownList)

                    CtrlAppCode.DefaultValue = CtrlAppCode.SelectedValue
                End If
            Next

            For i = 0 To TimssSubsystemControls.Count - 1
                Dim ctrlSubsystem As Personify.WebControls.SubsystemDropDownList
                ctrlSubsystem = CType(tableDemoInfo.FindControl(TimssSubsystemControls(i).ToString), Personify.WebControls.SubsystemDropDownList)

                ctrlSubsystem.DefaultValue = ctrlSubsystem.SelectedValue
            Next

            For i = 0 To TimssCountryControls.Count - 1
                Dim ctrlCountry As Personify.WebControls.CountryDropDownList
                ctrlCountry = CType(tableDemoInfo.FindControl(TimssCountryControls(i).ToString), Personify.WebControls.CountryDropDownList)

                ctrlCountry.DefaultValue = ctrlCountry.SelectedValue
            Next
        End Sub

        Public Function FormatControlURL(ByVal strActionUrl As String, _
                                 ByVal strActionName As String, _
                                 ByVal strArgs As String, _
                                 Optional ByVal strMiscArgs As String = "") As String
            Try
                If InStr(strActionUrl, "?") = 0 Then
                    strActionUrl = strActionUrl & "?action=" & strActionName & "&args=" & strArgs
                Else
                    strActionUrl = strActionUrl & "&action=" & strActionName & "&args=" & strArgs
                End If

                If strMiscArgs.Length > 0 Then
                    If Not strMiscArgs.StartsWith("&") Then
                        strMiscArgs = "&" & strMiscArgs
                    End If
                    strActionUrl = strActionUrl & strMiscArgs
                End If
                Return strActionUrl
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
                Return ""
            End Try
        End Function

        Private Sub BuildHTMLForGrid()
            Dim HasSetup As Boolean = False
            xParser.LoadPropertyFile(MapPath(CONFIGFILE))

            xParser.FirstItem()

            Do
                xParser.SetValue()
                If (xParser.LocateModule(ModuleId.ToString)) Then
                    xParser.SetValue()
                    CurrentItemID = xParser.ItemID
                    If (xParser.Special = "Add" And xParser.Mode = "Add") Then
                        CollAction = Action.ADD
                        pnlList.Visible = False
                        pnlDetail.Visible = True
                        BtnSave.Enabled = False
                        BtnSave.Visible = False
                        BtnBack.Enabled = False
                        BtnBack.Visible = False
                        BuildHTML()
                    Else
                        If (xParser.Special = "Add") Then
                            btnAddRecord.Visible = False
                        End If
                        LoadListView()
                    End If
                    HasSetup = True
                    Exit Do
                End If
            Loop While (xParser.NextItem())

            If Not (HasSetup) Then
                btnAddRecord.Visible = False

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
            End If
        End Sub

        Private Sub BuildHTML()
            xParser.LoadPropertyFile(MapPath(CONFIGFILE))

            xParser.FirstItem()

            Do
                xParser.SetValue()
                If (xParser.LocateModule(ModuleId.ToString)) Then
                    CurrentItemID = xParser.ItemID
                    LoadDetailView()
                    Exit Do
                End If
            Loop While (xParser.NextItem())
        End Sub

        Private Function SaveData() As Boolean
            xParser.LoadPropertyFile(MapPath(CONFIGFILE))

            xParser.FirstItem()

            Do
                xParser.SetValue()
                If (xParser.LocateModule(ModuleId.ToString)) Then
                    If (SaveCollection(False) Is Nothing) Then
                        Return False
                    End If
                    Return True
                    Exit Do
                End If
            Loop While (xParser.NextItem())
            Return False
        End Function

        Private Function SaveCollection(ByVal ToReturn As Boolean) As TIMSS.API.Core.IBusinessObjectCollection

            Dim obusinesscoll As TIMSS.API.Core.IBusinessObjectCollection = Nothing
            Dim obj As TIMSS.API.Core.IBusinessObject = Nothing
            IfValidationIssues = False

            Dim ValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection

            If (CollAction = Action.EDIT) Then
                SetKeyCollection()
                obusinesscoll = df_GetCollection(xParser.ItemID, KeyCollection, CollArgs)
                If Not (obusinesscoll.Count = 1) Then
                    Return Nothing
                End If
                obj = CType(obusinesscoll(0), TIMSS.API.Core.IBusinessObject)
            ElseIf (CollAction = Action.ADD) Then
                If xParser.ItemID = "CustomerInfo.Customers" Then
                    SetKeyCollection()

                    CollArgs = (UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString() & "," & UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString).Split(",")

                    obusinesscoll = df_GetCollection(xParser.ItemID, KeyCollection, CollArgs)
                    If Not (obusinesscoll.Count = 1) Then
                        Return Nothing
                    End If
                    obj = CType(obusinesscoll(0), TIMSS.API.Core.IBusinessObject)
                Else
                    obusinesscoll = df_GetCollection(xParser.ItemID)
                    obj = CType(obusinesscoll.AddNew, TIMSS.API.Core.IBusinessObject)
                End If
            End If

            xParser.FirstProperty(ModuleId.ToString)
            Do
                xParser.SetValue()

                If (xParser.Source = "API") Then
                    If ((xParser.EnableAdd = "True" AndAlso CollAction = Action.ADD) OrElse (xParser.EnableEdit = "True" AndAlso CollAction = Action.EDIT)) Then
                        If (xParser.Display = "True") Then

                            Dim temp As Object = GetValueFromControl()
                            If (temp.ToString = "-1" AndAlso (xParser.Control = "ApplicationCodeDropDownList" OrElse xParser.Control = "ApplicationSubCodeDropDownList" OrElse xParser.Control = "SubsystemDropDownList" OrElse xParser.Control = "CountryDropDownList")) Then
                                temp = ""
                            End If

                            If (xParser.Control = "CalendarCtrl" AndAlso temp.ToString = "") Then
                                temp = Date.MinValue

                            End If
                        
                            obj.SetPropertyValue(SetPropertyInfo(xParser.Prop), temp)
                          

                        End If
                    End If
                ElseIf (xParser.Source = "UserProfile") Then
                    obj.SetPropertyValue(SetPropertyInfo(xParser.Prop), CType(UserInfo.Profile.GetPropertyValue(xParser.Prop), String))
                Else
                    obj.SetPropertyValue(SetPropertyInfo(xParser.Prop), CType(xParser.SubSystem.ToString, String))
                End If

            Loop While (xParser.NextProperty())

            If (ToReturn) Then
                Return obusinesscoll
            End If

            ValidationIssues = df_SaveCollection(obusinesscoll, oMessageControl.ValidationIssues)

            If ValidationIssues.Count = 0 Then
                RemoveCache()
            End If

            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If

            If ValidationIssues.Count > 0 Then
                oMessageControl.Show(CType(ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                IfValidationIssues = True
            Else
                Return obusinesscoll
            End If
            Return obusinesscoll
        End Function

        Private Sub RemoveCache()

            If Not (xParser.ParentCollection = "") Then
                xParser.LocateItem(xParser.ParentCollection)
                xParser.SetValue()

                RemoveCache()
            Else
                Dim keyValues As String()
                Dim i As Integer

                keyValues = xParser.Keys.Split(Convert.ToChar(";"))

                For i = 0 To keyValues.Length - 1
                    If (xParser.LocateProperty(keyValues(i))) Then
                        xParser.SetValue()
                        If (xParser.Source = "UserProfile") Then
                            keyValues.SetValue(CType(UserInfo.Profile.GetPropertyValue(keyValues(i)), String), i)
                        Else
                            'Key value should be passed in by url
                        End If
                    End If
                Next
                'ApplicationManager.Customer.RemoveCollectionCache(keyValues)

            End If
        End Sub

        Private Function SetPropertyInfo(ByVal Name As String) As TIMSS.API.Core.PropertyInfo

            Dim APIPropertyInfo As TIMSS.API.Core.PropertyInfo = New TIMSS.API.Core.PropertyInfo

            APIPropertyInfo.Name = Name
            APIPropertyInfo.PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup

            Return APIPropertyInfo
        End Function

        Private Function GetValueFromControl() As String
            Select Case xParser.Control
                Case "ApplicationCodeDropDownList"
                    Return CType(tableDemoInfo.FindControl(xParser.Prop), DropDownList).SelectedValue

                Case "ApplicationSubCodeDropDownList"
                    Return CType(tableDemoInfo.FindControl(xParser.Prop), DropDownList).SelectedValue

                Case "TextBox"
                    If (xParser.Prop = "PreferredCommMethodCode") Then
                        Return (CType(tableDemoInfo.FindControl(xParser.Prop), DropDownList).SelectedValue).ToUpper
                    End If
                    If (xParser.Prop = "InstitutionName") Then
                        Dim strTemp() As String = CType(tableDemoInfo.FindControl(xParser.Prop), TextBox).Text.Split("-")
                        If strTemp(0) IsNot Nothing Then
                            Return strTemp(0)
                        End If
                    End If
                    Return CType(tableDemoInfo.FindControl(xParser.Prop), TextBox).Text

                Case "CalendarCtrl"
                    'Return CType(tableDemoInfo.FindControl(xParser.Prop), UserControls.CalendarCtrl).Datetextbox.Text
                    If Not CType(tableDemoInfo.FindControl(xParser.Prop), Telerik.Web.UI.RadDatePicker).IsEmpty Then
                        Return CType(tableDemoInfo.FindControl(xParser.Prop), Telerik.Web.UI.RadDatePicker).SelectedDate.ToString
                    Else
                        Return ""
                    End If

                Case "CheckBox"
                    If (CType(tableDemoInfo.FindControl(xParser.Prop), CheckBox).Checked) Then
                        Return "True"
                    Else
                        Return "False"
                    End If

                Case "SubsystemDropDownList"
                    Return CType(tableDemoInfo.FindControl(xParser.Prop), DropDownList).SelectedValue

                Case "CountryDropDownList"
                    Return CType(tableDemoInfo.FindControl(xParser.Prop), DropDownList).SelectedValue

                Case Else
                    Return CType(tableDemoInfo.FindControl(xParser.Prop), TextBox).Text

            End Select
        End Function

        Private Sub LoadDetailView()
            Dim i As Integer = 1

            oBusinessCollection = PopulateData(CurrentItemID)
            SetupDetailView()
        End Sub

        Private Sub LoadListView()
            Dim i As Integer = 1

            oBusinessCollection = PopulateData(CurrentItemID)
            If oBusinessCollection.Count = 0 Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecordMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                dgDmgView.Visible = False
            ElseIf (xParser.ParentCollection = "") Then
                If CheckRecordExistance() Then
                    dgDmgView.AllowPaging = False
                    SetupListView()
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecordMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    dgDmgView.Visible = False
                    btnAddRecord.Visible = True
                    btnAddRecord.Enabled = True
                End If
            Else
                dgDmgView.AllowPaging = False
                SetupListView()
            End If
        End Sub

        Private Function CheckRecordExistance() As Boolean
            Dim i As Integer
            Dim AppCode As TIMSS.API.Core.AppCode
            Dim AppSubCode As TIMSS.API.Core.AppSubcode
            Dim AppSubSystem As TIMSS.API.Core.AppSubsystem
            Dim AppCountry As TIMSS.API.Core.AppCountry
            Dim RecordExist As Boolean = False

            If Not (oBusinessCollection Is Nothing) Then
                For Each oObject As TIMSS.API.Core.BusinessObject In oBusinessCollection
                    i = 1
                    While (xParser.LocateProperty(i))
                        xParser.SetValue()
                        If Not (xParser.Display = "False") Then
                            If oObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                                If (xParser.Type = "CODE") Then
                                    AppCode = CType(oObject.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppCode)
                                    If Not (AppCode.Code = "") Then
                                        RecordExist = True
                                        Exit While
                                    End If
                                ElseIf (xParser.Type = "SUBCODE") Then
                                    AppSubCode = CType(oObject.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppSubcode)
                                    If Not (AppSubCode.Code = "") Then
                                        RecordExist = True
                                        Exit While
                                    End If
                                ElseIf (xParser.Type = "SUBSYSTEMCODE") Then
                                    AppSubSystem = CType(oObject.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppSubsystem)
                                    If Not (AppSubSystem.Code = "") Then
                                        RecordExist = True
                                        Exit While
                                    End If
                                ElseIf (xParser.Type = "COUNTRYCODE") Then
                                    AppCountry = CType(oObject.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppCountry)
                                    If Not (AppCountry.Code = "") Then
                                        RecordExist = True
                                        Exit While
                                    End If
                                ElseIf (xParser.Type = "DateTime") Then
                                    If CType(oObject.GetPropertyValue(xParser.Prop.ToString), Date) = Date.MinValue.Date Then

                                    Else
                                        RecordExist = True
                                        Exit While
                                    End If
                                Else
                                    If Not (CType(oObject.GetPropertyValue(xParser.Prop.ToString), String) = "") Then
                                        RecordExist = True
                                        Exit While
                                    End If
                                End If
                            End If
                        End If

                        i += 1
                    End While

                Next
                Return RecordExist
            End If
        End Function


        Private Sub SetupListView()
            Dim DataColumn As System.Web.UI.WebControls.BoundColumn
            Dim HyperColumn As System.Web.UI.WebControls.HyperLinkColumn

            Dim dc As DataColumn
            Dim dt As New DataTable
            Dim edit As Boolean = False
            Dim add As Boolean = False
            Dim i As Integer

            i = 1

            dgDmgView.HeaderStyle.CssClass = "tmar_demo_DataHeader"
            dgDmgView.ItemStyle.CssClass = "tmar_demo_DataTable"
            dgDmgView.AlternatingItemStyle.CssClass = "tmar_demo_DataTable_Grey"
            dgDmgView.GridLines = GridLines.None
            dgDmgView.AllowSorting = True

            While (xParser.LocateProperty(i))
                xParser.SetValue()
                If (xParser.EnableEdit = "True" Or xParser.EnableEdit = "ReadOnly") Then
                    edit = True
                End If
                If (xParser.EnableAdd = "True" Or xParser.EnableAdd = "ReadOnly") Then
                    add = True
                End If
                If Not (xParser.Display = "False") Then
                    DataColumn = New System.Web.UI.WebControls.BoundColumn
                    DataColumn.HeaderText = xParser.Caption
                    DataColumn.SortExpression = xParser.Prop
                    DataColumn.DataField = xParser.Prop
                    If (xParser.Type = "DateTime") Then
                        DataColumn.DataFormatString = "{0:" + Localization.GetString("DateFormat", LocalResourceFile) + "}"
                    End If
                    dgDmgView.Columns.Add(DataColumn)

                    dc = New DataColumn
                    dc.ColumnName = xParser.Prop
                    If (xParser.Type = "DateTime") Then
                        dc.DataType = System.Type.GetType("System.DateTime")
                    Else
                        dc.DataType = System.Type.GetType("System.String")
                    End If
                    dt.Columns.Add(dc)
                End If

                i += 1
            End While

            If edit Then
                '**Build the Edit column..shows the EDIT hyperlink
                HyperColumn = New System.Web.UI.WebControls.HyperLinkColumn
                HyperColumn.Text = "Edit"
                HyperColumn.DataNavigateUrlField = "Edit"
                dgDmgView.Columns.Add(HyperColumn)

                dc = New DataColumn
                dc.ColumnName = "Edit"
                dc.DataType = System.Type.GetType("System.String")

                dt.Columns.Add(dc)
            End If

            If Not (xParser.Special = "Add") Then

                If Not add Then
                    btnAddRecord.Visible = False
                Else
                    btnAddRecord.Visible = True
                End If
            End If

            If Not (oBusinessCollection Is Nothing) Then
                'START 3246-6210640: Demographics mistakenly showing on Web
                Dim codeHash As Hashtable = New Hashtable
                For Each oObject As TIMSS.API.Core.BusinessObject In oBusinessCollection

                    If IsCodeObjectValid(oObject, codeHash) Then
                        dt.Rows.Add(AddRow(oObject, dt.NewRow()))
                    End If
                Next
                'END 3246-6210640: Demographics mistakenly showing on Web
            End If

            dgDmgView.DataSource = dt
            dgDmgView.DataBind()

        End Sub

        'START 3246-6210640: Demographics mistakenly showing on Web
        Private Function IsCodeObjectValid(ByVal obj As TIMSS.API.Core.BusinessObject, ByVal codeHash As Hashtable) As Boolean

            Dim i As Integer
            Dim AppCode As TIMSS.API.Core.AppCode = Nothing
            Dim CompareCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = Nothing
            Dim AppSubSystem As TIMSS.API.Core.AppSubsystem = Nothing          

            i = 1
            While (xParser.LocateProperty(i))
                xParser.SetValue()
                If Not (xParser.Display = "False") AndAlso Not (xParser.Prop = "Institution") Then
                    If obj.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        If (xParser.Type = "CODE") Then
                            AppCode = CType(obj.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppCode)                     
                        End If
                    End If
                End If
                i += 1
            End While

            If CompareCodes Is Nothing AndAlso AppCode IsNot Nothing AndAlso codeHash.Count = 0 Then
                'Get all the code type and its subsystem
                'CompareCodes = ApplicationManager.Codes.GetApplicationCodes(Me.PortalId, AppCode.Subsystem, AppCode.Type)

                CompareCodes = GetApplicationCodes(AppCode.Subsystem, AppCode.Type, True)
                If CompareCodes IsNot Nothing AndAlso CompareCodes.Count > 0 Then
                    For Each oCompare As TIMSS.API.ApplicationInfo.IApplicationCode In CompareCodes
                        If Not codeHash.Contains(oCompare.Code) Then
                            codeHash.Add(oCompare.Code, oCompare.Code)
                        End If
                    Next
                Else
                    Return False
                End If
            End If

            If codeHash.Contains(AppCode.Code) Then
                Return True
            End If

            Return False

        End Function
        'END 3246-6210640: Demographics mistakenly showing on Web

        Private Function AddRow(ByVal obj As TIMSS.API.Core.BusinessObject, ByVal dr As DataRow) As DataRow
            Dim i As Integer
            Dim AppCode As TIMSS.API.Core.AppCode
            Dim AppSubCode As TIMSS.API.Core.AppSubcode
            Dim AppSubSystem As TIMSS.API.Core.AppSubsystem
            Dim AppCountry As TIMSS.API.Core.AppCountry
            Dim edit As Boolean = False
            Dim add As Boolean = False

            i = 1
            While (xParser.LocateProperty(i))
                xParser.SetValue()
                If (xParser.EnableEdit = "True" Or xParser.EnableEdit = "ReadOnly") Then
                    edit = True
                End If
                If (xParser.EnableAdd = "True" Or xParser.EnableAdd = "ReadOnly") Then
                    add = True
                End If
                If Not (xParser.Display = "False") AndAlso Not (xParser.Prop = "Institution") Then
                    If obj.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        If (xParser.Type = "CODE") Then
                            AppCode = CType(obj.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppCode)
                            'Dim t As TIMSS.API.ApplicationInfo.IApplicationCode
                            't.AvailableToWebFlag
                            dr(xParser.Prop) = AppCode.Description
                        ElseIf (xParser.Type = "SUBCODE") Then
                            AppSubCode = CType(obj.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppSubcode)
                            dr(xParser.Prop) = AppSubCode.Description
                        ElseIf (xParser.Type = "SUBSYSTEMCODE") Then
                            AppSubSystem = CType(obj.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppSubsystem)
                            dr(xParser.Prop) = AppSubSystem.Description
                        ElseIf (xParser.Type = "COUNTRYCODE") Then
                            AppCountry = CType(obj.GetPropertyValue(xParser.Prop.ToString), TIMSS.API.Core.AppCountry)
                            dr(xParser.Prop) = AppCountry.Description
                        ElseIf (xParser.Type = "DateTime") Then
                            If CType(obj.GetPropertyValue(xParser.Prop.ToString), Date) = Date.MinValue.Date Then

                            Else
                                dr(xParser.Prop) = FormatDate(CType(obj.GetPropertyValue(xParser.Prop.ToString), Date))
                            End If
                        Else
                            dr(xParser.Prop) = CType(obj.GetPropertyValue(xParser.Prop.ToString), String)
                        End If
                    End If
                End If

                i += 1
            End While

            Dim strArgs As String = ""
            Dim strActionURL As String

            If edit Then
                SetKeyCollection()
                If Not Page.Request.Url.AbsoluteUri Is Nothing Then
                    For Each key As String In KeyCollection
                        strArgs += CType(obj.GetOriginalPropertyValue(key).ToString, String) & ";"
                    Next
                    'strArgs = CType(obj.GetPropertyValue("CUS_DEMOGRAPHIC_ID"), String)
                    'strArgs = strArgs & CType(obj.GetPropertyValue("USER_N1"), String)
                    strActionURL = FormatControlURL(Page.Request.Url.AbsoluteUri, "EDIT", strArgs, "mid=" & Me.ModuleId)

                    dr("Edit") = strActionURL
                End If
            End If

            Return dr
        End Function

        Public Shared Function FormatDate(ByVal poDate As Object) As String
            Dim strFormattedDate As String
            If IsDBNull(poDate) Then
                strFormattedDate = ""
            Else
                strFormattedDate = Format(CType(poDate, Date), "MM/dd/yyyy")
            End If
            Return strFormattedDate
        End Function

        Private Sub SetKeyCollection()
            KeyCollection = Nothing
            KeyCollection = xParser.Keys.ToString.Split(Convert.ToChar(";"))
        End Sub

        Private Sub SetupDetailView()
            If (CollAction = Action.ADD) Then
                SetupAddDetailView()
            ElseIf (CollAction = Action.EDIT) Then
                SetupEditDetailView()
            End If
        End Sub

        Private Sub SetupAddDetailView()
            Dim i As Integer
            Dim j As Integer

            i = 1
            j = 1
            While (xParser.LocateProperty(i))
                xParser.SetValue()
                If Not (xParser.EnableAdd = "False") Then
                    AddRow(i, j, True)
                Else
                    AddRow(i, j, False)
                End If

                i += 1
            End While
        End Sub

        Private Sub SetupEditDetailView()
            Dim i As Integer
            Dim j As Integer

            i = 1
            j = 1
            GetArgs()
            SetBusinessObject()
            While (xParser.LocateProperty(i))
                xParser.SetValue()
                If Not (xParser.EnableEdit = "False") Then
                    AddRow(i, j, True)
                Else
                    AddRow(i, j, False)
                End If

                i += 1
            End While
        End Sub

        Private Sub SetBusinessObject()

            Dim i As Integer = 0
            Dim key As String = ""
            Dim match As Boolean = True

            SetKeyCollection()
            For Each oObject As TIMSS.API.Core.BusinessObject In oBusinessCollection
                match = True
                For i = 0 To KeyCollection.Length - 1
                    key = KeyCollection(i)
                    If oObject.GetPropertyValue(key) IsNot Nothing Then
                        If Not (CollArgs(i) = CType(oObject.GetOriginalPropertyValue(key).ToString, String)) Then
                            match = False
                            Exit For
                        End If
                    Else
                        match = False
                        Exit For
                    End If
                Next
                If match Then
                    oBusinessObject = oObject
                    Exit For
                End If
            Next
        End Sub

        Private Sub AddRow(ByVal position As Integer, ByVal offset As Integer, ByVal show As Boolean)
            row = New System.Web.UI.WebControls.TableRow

            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(SetupLabel())
            cell.Width = CType(Unit.Percentage(1), System.Web.UI.WebControls.Unit)
            cell.Wrap = False
            cell.HorizontalAlign = HorizontalAlign.Right
            row.Cells.Add(cell)

            cell = New System.Web.UI.WebControls.TableCell
            Dim ctrl As System.Web.UI.Control = SetupDataField()

            'If (xParser.Prop = "Institution") Then
            '    If CheckKeyStoreExists() Then
            '        CType(ctrl, TextBox).Text = "cucu"
            '    End If
            '    cell.Controls.Add(CType(ctrl, TextBox))
            'Else
            cell.Controls.Add(ctrl)
            If xParser.Prop = "InstitutionName" Then
                With autoInstitutionName
                    .TargetControlID = txtInstitutionName.ID
                    .MinimumPrefixLength = "1"
                    .EnableCaching = "true"
                    .ServiceMethod = "SearchInstitutions"
                    .ID = "autoInstitutionName"
                    .ServicePath = ApplicationPath & "/PersonifyAjax.asmx"
                End With
                cell.Controls.Add(autoInstitutionName)
            End If
            'End If

            'If (xParser.Prop = "Institution") Then

            '    If CheckKeyStoreExists() Then
            '        CType(ctrl, TextBox).Text = "cucu"
            '    End If
            '    cell.Controls.Add(CType(ctrl, TextBox))
            'Else
            'cell.Controls.Add(ctrl)
            'End If

            If (xParser.Required = "True" AndAlso (Not (xParser.Control = "CheckBox"))) Then

                If Not (xParser.Control = "CalendarCtrl") Then
                    Dim RequiredValidator As New System.Web.UI.WebControls.RequiredFieldValidator

                    RequiredValidator.ID = "RV_" + ctrl.ID
                    RequiredValidator.Visible = False
                    RequiredValidator.ControlToValidate = ctrl.ID
                    RequiredValidator.ErrorMessage = Localization.GetString("RequiredFieldErrorMessage", LocalResourceFile)
                    ReqValidators.Add(RequiredValidator.ID)

                    cell.Controls.Add(RequiredValidator)
                Else
                    'CType(ctrl, UserControls.CalendarCtrl).ValidateRequiredDate = True
                    'CType(ctrl, UserControls.CalendarCtrl).RequiredErrorMessage = Localization.GetString("RequiredFieldErrorMessage", LocalResourceFile)
                End If
            End If

            If (xParser.Control = "CalendarCtrl") Then
                'CType(ctrl, UserControls.CalendarCtrl).ErrorMessage = Localization.GetString("DateFormatErrorMessage", LocalResourceFile)
                'no need, automaticaly "Invalid Style" is applied (alterante solution .DateInput.ClientEvents.OnError = "OnError")
            End If

            If (xParser.Type = "Number") Then
                Dim RegExpValidator As New System.Web.UI.WebControls.RegularExpressionValidator

                RegExpValidator.ControlToValidate = ctrl.ID
                RegExpValidator.ErrorMessage = Localization.GetString("NumberFieldErrorMessage", LocalResourceFile)
                RegExpValidator.ValidationExpression = "^\d+$"

                cell.Controls.Add(RegExpValidator)
            End If


            cell.Width = CType(Unit.Percentage(100), System.Web.UI.WebControls.Unit)
            cell.Wrap = True
            cell.HorizontalAlign = HorizontalAlign.Left
            row.Cells.Add(cell)

            row.Visible = show

            tableDemoInfo.Rows.AddAt(position - offset, row)
        End Sub

        Private Function SetupCalendar() As System.Web.UI.Control
            'Dim calendar As UserControls.CalendarCtrl
            Dim calendar As New Telerik.Web.UI.RadDatePicker
            calendar.EnableViewState = True
            'calendar = CType(LoadControl("~\controls\CalendarCtrl.ascx"), UserControls.CalendarCtrl)

            Return calendar
        End Function

        Private Function SetupLabel() As System.Web.UI.Control
            Dim label As New System.Web.UI.WebControls.Label

            If Not xParser.Caption = "Institution ID" Then
                'hide Institution ID label
                If (xParser.Required = "True") Then
                    label.Text = xParser.Caption
                    label.ForeColor = Color.Red
                    'label.Style.Add("color", "red")
                Else
                    label.Text = xParser.Caption
                    label.ForeColor = Color.Black
                    'label.Style.Add("color", "black")
                End If

            End If

            Return label


        End Function
        'Private Function CheckKeyStoreExists() As Boolean

        'If Not Page.Request.Params("KeyStore") Is Nothing AndAlso Page.Request.Params("KeyStore").Length > 0 Then
        'Return True
        'Else
        'Return False
        'End If

        'End Function


        Private Function SetupDataField() As System.Web.UI.Control

            Select Case xParser.Control
                Case "ApplicationCodeDropDownList"
                    Dim ctrl As New Personify.WebControls.ApplicationCodeDropDownList

                    ctrl.ApplicationType = xParser.TypeName
                    ctrl.Subsystem = xParser.SubSystem
                    ctrl.EnableViewState = True
                    ctrl.ID = xParser.Prop

                    If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                        ctrl.Enabled = False
                    ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                        ctrl.Enabled = False
                    End If

                    If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                        BindCtrlData(ctrl)
                    Else
                        TimssAppCodeControls.Add(ctrl.ID)
                        ctrl.AddInitLine = True
                        ctrl.InitLine = Localization.GetString("AppCodeInitLine", LocalResourceFile)
                    End If

                    Return ctrl
                Case "SubsystemDropDownList"
                    Dim ctrl As New Personify.WebControls.SubsystemDropDownList

                    ctrl.EnableViewState = True
                    ctrl.ID = xParser.Prop

                    If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                        ctrl.Enabled = False
                    ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                        ctrl.Enabled = False
                    End If

                    If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                        BindCtrlData(ctrl)
                    Else
                        TimssSubsystemControls.Add(ctrl.ID)
                    End If

                    Return ctrl
                Case "CountryDropDownList"
                    Dim ctrl As New Personify.WebControls.CountryDropDownList

                    ctrl.EnableViewState = True
                    ctrl.ID = xParser.Prop

                    If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                        ctrl.Enabled = False
                    ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                        ctrl.Enabled = False
                    End If

                    If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                        BindCtrlData(ctrl)
                    Else
                        TimssCountryControls.Add(ctrl.ID)
                    End If

                    Return ctrl
                Case "ApplicationSubCodeDropDownList"
                    Dim ctrl As New Personify.WebControls.ApplicationSubCodeDropDownList

                    ctrl.ApplicationType = xParser.TypeName
                    ctrl.Subsystem = xParser.SubSystem
                    ctrl.ApplicationCode = TimssControlValues.Get(xParser.Code)
                    CType(tableDemoInfo.FindControl(xParser.Code), Personify.WebControls.ApplicationCodeDropDownList).AutoPostBack = True
                    ctrl.EnableViewState = True
                    ctrl.ID = xParser.Prop

                    If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                        ctrl.Enabled = False
                    ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                        ctrl.Enabled = False
                    End If

                    'BindCtrlData(ctrl)
                    If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                        BindCtrlData(ctrl)
                    Else
                        TimssSubCodeControls.Add(ctrl.ID)
                        TimssControl.Add(ctrl.ID, xParser.Code)
                        ctrl.AddInitLine = True
                        ctrl.InitLine = Localization.GetString("SubCodeInitLine", LocalResourceFile)
                    End If
                    Return ctrl
                Case "TextBox"

                    Dim ctrl As New System.Web.UI.WebControls.TextBox
                    ctrl.ID = xParser.Prop
                    ctrl.EnableViewState = True
                    If (xParser.Prop = "Institution") Then
                        ctrl.Visible = False
                    End If
                    If (xParser.Prop = "InstitutionName") Then
                        'Dim comp As String
                        'comp = Page.Request.Params("KeyStore")
                        txtInstitutionName.ID = xParser.Prop
                        txtInstitutionName.EnableViewState = True
                        txtInstitutionName.CssClass = "AutoComplete"
                        txtInstitutionName.Columns = 35
                        'AddHandler txtInstitutionName.TextChanged, AddressOf SearchInstitutions
                        If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                            txtInstitutionName.ReadOnly = True
                        ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                            txtInstitutionName.ReadOnly = True
                        End If
                        'If comp IsNot Nothing Then
                        'txtInstitutionName.Text = comp
                        'End If

                        If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                            BindCtrlData(txtInstitutionName)
                        End If
                        Return txtInstitutionName
                    ElseIf (xParser.Prop = "PreferredCommMethodCode") Then


                        Dim ctrlDrop As New Personify.WebControls.ApplicationCodeDropDownList

                        ctrlDrop.ApplicationType = "COMM_TYPE"
                        ctrlDrop.Subsystem = "CUS"
                        ctrlDrop.EnableViewState = True
                        ctrlDrop.ID = xParser.Prop

                        If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                            ctrlDrop.Enabled = False
                        ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                            ctrlDrop.Enabled = False
                        End If

                        If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                            BindCtrlData(ctrlDrop)
                        Else
                            TimssAppCodeControls.Add(ctrlDrop.ID)
                            ctrlDrop.AddInitLine = True
                            ctrlDrop.InitLine = Localization.GetString("AppCodeInitLine", LocalResourceFile)
                        End If

                        Return ctrlDrop
                    Else
                        If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                            ctrl.ReadOnly = True
                        ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                            ctrl.ReadOnly = True
                        End If
                        If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                            BindCtrlData(ctrl)
                        End If
                        Return ctrl
                    End If

                Case "CalendarCtrl"
                    'Dim ctrl As UserControls.CalendarCtrl
                    'ctrl = CType(LoadControl("~\controls\CalendarCtrl.ascx"), UserControls.CalendarCtrl)
                    Dim ctrl As New Telerik.Web.UI.RadDatePicker

                    ctrl.ID = xParser.Prop
                    ctrl.EnableViewState = True
                    ctrl.MinDate = "1/1/1900"
                    If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                        'ctrl.Datetextbox.ReadOnly = True
                        'ctrl.CalendarLink.Enabled = False
                        ctrl.EnableTyping = False
                        ctrl.DatePopupButton.Visible = False

                    ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                        'ctrl.Datetextbox.ReadOnly = True
                        'ctrl.CalendarLink.Enabled = False
                        ctrl.EnableTyping = False
                        ctrl.DatePopupButton.Visible = False
                    End If

                    'If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                    'telerik need to bind anyway?
                    If (Not (CollAction = Action.ADD)) Then
                        BindCtrlData(ctrl)
                    End If

                    Return ctrl
                Case "CheckBox"
                    Dim ctrl As New CheckBox

                    ctrl.ID = xParser.Prop
                    ctrl.EnableViewState = True

                    If (CollAction = Action.ADD And xParser.EnableAdd = "ReadOnly") Then
                        ctrl.Enabled = False
                    ElseIf (CollAction = Action.EDIT And xParser.EnableEdit = "ReadOnly") Then
                        ctrl.Enabled = False
                    End If

                    If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                        BindCtrlData(ctrl)
                    End If

                    Return ctrl
                Case Else
                    Dim ctrl As New System.Web.UI.WebControls.TextBox

                    ctrl.ID = xParser.Prop
                    ctrl.EnableViewState = True
                    If ((Not (CollAction = Action.ADD)) AndAlso (Not (Page.IsPostBack))) Then
                        BindCtrlData(ctrl)
                    End If

                    Return ctrl
            End Select
        End Function


        Private Sub BindCtrlData(ByRef ctrl As CheckBox)
            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        If (CType(oBusinessObject.GetPropertyValue(xParser.Prop), String) = "True") Then
                            ctrl.Checked = True
                            TimssControlValues.Add(xParser.Prop, "True")
                        Else
                            ctrl.Checked = False
                            TimssControlValues.Add(xParser.Prop, "False")
                        End If

                    End If

                End If
            End If
        End Sub

        'Private Sub BindCtrlData(ByRef ctrl As UserControls.CalendarCtrl)

        '    If (TimssControlValues.Get(xParser.Prop) = "") Then
        '        If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

        '        Else
        '            If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
        '                If CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), String) = "12:00:00 AM" Then
        '                    ctrl.Datetextbox.Text = ""
        '                Else
        '                    ctrl.Datetextbox.Text = CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), String)
        '                End If
        '                TimssControlValues.Add(xParser.Prop, ctrl.Datetextbox.Text)
        '            End If

        '        End If
        '    Else
        '        ctrl.Datetextbox.Text = TimssControlValues.Get(xParser.Prop)
        '    End If
        'End Sub

        Private Sub BindCtrlData(ByRef ctrl As Telerik.Web.UI.RadDatePicker)

            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        'If CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), String) = "12:00:00 AM" Then
                        '    ctrl.Datetextbox.Text = ""
                        'Else
                        '    ctrl.Datetextbox.Text = CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), String)
                        'End If
                        If Not (CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), String) = "12:00:00 AM" OrElse CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), String) = "1/1/0001 12:00:00 AM") Then
                            ctrl.SelectedDate = CType(oBusinessObject.GetPropertyValue(xParser.Prop.ToString), DateTime)
                        End If

                        'TimssControlValues.Add(xParser.Prop, ctrl.Datetextbox.Text)
                        If Not ctrl.IsEmpty Then
                            TimssControlValues.Add(xParser.Prop, ctrl.SelectedDate.ToString)
                        Else
                            TimssControlValues.Add(xParser.Prop, "")
                        End If
                    End If

                End If
            Else
                If Not String.IsNullOrEmpty(TimssControlValues.Get(xParser.Prop)) Then
                    ctrl.SelectedDate = TimssControlValues.Get(xParser.Prop)
                End If
            End If
        End Sub
        Private Sub BindCtrlData(ByRef ctrl As Personify.WebControls.ApplicationSubCodeDropDownList)
            Dim AppSubCode As TIMSS.API.Core.AppSubcode

            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        AppSubCode = CType(oBusinessObject.GetPropertyValue(xParser.Prop), TIMSS.API.Core.AppSubcode)
                        If Not (AppSubCode.Code = "") Then
                            ctrl.DefaultValue = AppSubCode.Code
                            TimssControlValues.Add(xParser.Prop, AppSubCode.Code)
                        Else
                            TimssSubCodeControls.Add(ctrl.ID)
                            TimssControl.Add(ctrl.ID, xParser.Code)
                            ctrl.AddInitLine = True
                            ctrl.InitLine = Localization.GetString("SubCodeInitLine", LocalResourceFile)
                        End If
                    End If

                End If
            Else
                ctrl.DefaultValue = TimssControlValues.Get(xParser.Prop)
            End If
        End Sub

        Private Sub BindCtrlData(ByRef ctrl As Personify.WebControls.ApplicationCodeDropDownList)

            Dim AppCode As TIMSS.API.Core.AppCode
            Dim CommCode As String
            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If xParser.Prop = "PreferredCommMethodCode" Then
                        If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                            CommCode = CType(oBusinessObject.GetPropertyValue(xParser.Prop), String)
                            If Not (CommCode = "") Then
                                ctrl.DefaultValue = CommCode
                                TimssControlValues.Add(xParser.Prop, CommCode)
                            Else
                                TimssAppCodeControls.Add(ctrl.ID)
                                ctrl.AddInitLine = True
                                ctrl.InitLine = Localization.GetString("AppCodeInitLine", LocalResourceFile)
                            End If
                        End If
                    Else
                        If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                            AppCode = CType(oBusinessObject.GetPropertyValue(xParser.Prop), TIMSS.API.Core.AppCode)
                            If Not (AppCode.Code = "") Then
                                ctrl.DefaultValue = AppCode.Code
                                TimssControlValues.Add(xParser.Prop, AppCode.Code)
                            Else
                                TimssAppCodeControls.Add(ctrl.ID)
                                ctrl.AddInitLine = True
                                ctrl.InitLine = Localization.GetString("AppCodeInitLine", LocalResourceFile)
                            End If
                        End If
                    End If
                End If
            End If
        End Sub


        Private Sub BindCtrlData(ByRef ctrl As Personify.WebControls.SubsystemDropDownList)

            Dim Subsystem As TIMSS.API.Core.AppSubsystem

            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        Subsystem = CType(oBusinessObject.GetPropertyValue(xParser.Prop), TIMSS.API.Core.AppSubsystem)
                        If Not (Subsystem.Code = "") Then
                            ctrl.DefaultValue = Subsystem.Code
                            TimssControlValues.Add(xParser.Prop, Subsystem.Code)
                        Else
                            TimssSubsystemControls.Add(ctrl.ID)
                        End If
                    End If

                End If
            End If
        End Sub

        Private Sub BindCtrlData(ByRef ctrl As Personify.WebControls.CountryDropDownList)

            Dim Country As TIMSS.API.Core.AppCountry

            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        Country = CType(oBusinessObject.GetPropertyValue(xParser.Prop), TIMSS.API.Core.AppCountry)
                        If Not (Country.Code = "") Then
                            ctrl.DefaultValue = Country.Code
                            TimssControlValues.Add(xParser.Prop, Country.Code)
                        Else
                            TimssCountryControls.Add(ctrl.ID)
                        End If
                    End If

                End If
            End If
        End Sub

        Private Sub BindCtrlData(ByRef ctrl As System.Web.UI.WebControls.TextBox)
            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        ctrl.Text = CType(oBusinessObject.GetPropertyValue(xParser.Prop), String)
                        TimssControlValues.Add(xParser.Prop, ctrl.Text)
                    End If

                End If
            End If
        End Sub
        Private Sub BindCtrlData(ByRef ctrl As System.Web.UI.WebControls.DropDownList)
            If (TimssControlValues.Get(xParser.Prop) = "") Then
                If (oBusinessObject Is Nothing) OrElse (CollAction = Action.ADD) Then

                Else
                    If oBusinessObject.GetPropertyValue(xParser.Prop) IsNot Nothing Then
                        ctrl.Items.Add(New ListItem("choose one method", ""))
                        ctrl.Items.Add(New ListItem("phone", "PHONE"))
                        ctrl.Items.Add(New ListItem("fax", "FAX"))
                        ctrl.Items.Add(New ListItem("email", "EMAIL"))
                        ctrl.Items.Add(New ListItem("web", "WEB"))

                        ctrl.SelectedValue = CType(oBusinessObject.GetPropertyValue(xParser.Prop), String)
                        TimssControlValues.Add(xParser.Prop, ctrl.SelectedValue)
                    End If

                End If
            End If
        End Sub

        Private Sub GetArgs()
            CollArgs = Nothing
            Dim strArg As String

            strArg = Request.QueryString("args")
            If Not (strArg Is Nothing) Then
                CollArgs = strArg.Split(Convert.ToChar(";"))
            End If
        End Sub

        Private Function PopulateData(ByVal CollectionName As String) As TIMSS.API.Core.IBusinessObjectCollection
            Dim oBusinessObj As TIMSS.API.Core.IBusinessObjectCollection
            Dim Keys As String()
            Dim KeyValues As String()
            Dim i As Integer
            If (xParser.LocateItem(CollectionName)) Then
                xParser.SetValue()
                If Not (xParser.ParentCollection = "") Then
                    oBusinessObj = PopulateData(xParser.ParentCollection)
                    If (oBusinessObj IsNot Nothing) Then
                        For Each oObject As TIMSS.API.Core.IBusinessObject In oBusinessObj
                            If (xParser.LocateItem(CollectionName)) Then
                                xParser.SetValue()
                                Return CType(oObject.GetPropertyValue(xParser.ApiCollection), TIMSS.API.Core.IBusinessObjectCollection)
                            End If
                        Next

                        Return Nothing
                    Else
                        Return Nothing
                    End If
                Else
                    Keys = xParser.Keys.Split(Convert.ToChar(";"))
                    KeyValues = xParser.Keys.Split(Convert.ToChar(";"))

                    For i = 0 To KeyValues.Length - 1
                        If (xParser.LocateProperty(KeyValues(i))) Then
                            xParser.SetValue()
                            If (xParser.Source = "UserProfile") Then
                                KeyValues.SetValue(CType(UserInfo.Profile.GetPropertyValue(Keys(i)), String), i)
                            Else
                                'Key value should be passed in by url
                            End If
                        End If
                    Next
                    oBusinessObj = df_GetCollection(xParser.ItemID, Keys, KeyValues)
                    Return oBusinessObj
                End If
            Else
                Return Nothing
                'Throw exception for wrong info in xml
            End If
        End Function

        Private Function DetermineCollectionAction() As Boolean
            Dim strAction As String
            Dim intModuleId As Integer

            strAction = Request.QueryString("action")
            intModuleId = Convert.ToInt16(Request.QueryString("mid"))


            If strAction Is Nothing OrElse strAction Is String.Empty Then
                DetermineCollectionAction = True
                CollAction = Action.VIEW
                pnlList.Visible = True
                pnlDetail.Visible = False
            Else
                If intModuleId > 0 Then
                    Select Case strAction.ToUpper
                        Case "ADD"
                            CollAction = Action.ADD
                            DetermineCollectionAction = True
                            pnlList.Visible = False
                            pnlDetail.Visible = True

                        Case "EDIT"
                            CollAction = Action.EDIT
                            DetermineCollectionAction = True
                            pnlList.Visible = False
                            pnlDetail.Visible = True

                        Case Else
                            DetermineCollectionAction = True
                            CollAction = Action.VIEW
                            pnlList.Visible = True
                            pnlDetail.Visible = False
                    End Select
                Else
                    DetermineCollectionAction = False
                End If
            End If
        End Function

        Private Sub LockUnAuthorizedAccess()
            boolUnAuthorizedAccess = True
            pnlDetail.Visible = False
            pnlList.Visible = False
        End Sub

#End Region

#Region "Optional Interfaces"


        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
            Return Nothing
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
            Return Nothing
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init


            If (DotNetNuke.Framework.AJAX.IsInstalled()) Then
                DotNetNuke.Framework.AJAX.RegisterScriptManager()
                'Dim SM As ScriptManager = ScriptManager.GetCurrent(Page)
                'SM.SupportsPartialRendering = True
            End If

            Dim role As String
            role = Me.GetUserRole(UserInfo)
            If role = "personifyuser" Or role = "personifyadmin" Then
                'strMCID = UserInfo.Profile.GetPropertyValue("MasterCustomerId")
                'strSCID = UserInfo.Profile.GetPropertyValue("SubCustomerId")


                BtnSave.Visible = True
                BtnBack.Visible = True
                BtnBack.Width = 70
                BtnSave.Width = 70
                btnAddRecord.Visible = True

                If Not DetermineCollectionAction() Then
                    LockUnAuthorizedAccess()
                    Exit Sub
                Else
                    boolUnAuthorizedAccess = False
                End If

                If CollAction = Action.ADD OrElse CollAction = Action.EDIT Then
                    BuildHTML()
                Else
                    BuildHTMLForGrid()
                End If
            Else
                show = False
                pnlDetail.Visible = False
                pnlList.Visible = False
                DisplayUserAccessMessage(role)
                Exit Sub
            End If





            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub


#End Region

#Region " IMC "
        Public Sub OnModuleCommunication(ByVal s As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleListener.OnModuleCommunication
            Select Case e.Type
                Case "Personify.DNN.Modules.IMCSaveSender"
                    Dim objAssembly As Reflection.Assembly = Reflection.Assembly.LoadFrom(MapPath("..\\..\\bin\\Personify.DNN.Modules.IMCSaveSender.dll"))

                    Dim evt As New DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs("Personify.DNN.Modules.CustomerDemographics", SaveCollection(True), GetType(CustomerDemographics).Name, objAssembly.GetName.Name)

                    RaiseEvent ModuleCommunication(Me, evt)
                    Return
            End Select
        End Sub

        Public Event ModuleCommunication(ByVal sender As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleCommunicator.ModuleCommunication

#End Region


#Region "Personify Data"


        Private Function df_GetCollection(ByVal TypeName As String, ByVal Keys As String(), ByVal KeyValues As String()) As TIMSS.API.Core.IBusinessObjectCollection

            Dim oObject As TIMSS.API.Core.IBusinessObjectCollection

            Dim i As Integer
            Dim keyString As String = ""

            For Each key As String In KeyValues
                keyString += key
            Next

            oObject = Me.PersonifyGetCollection(TypeName)

            With oObject
                For i = 0 To Keys.Length - 1
                    .Filter.Add(Keys(i), TIMSS.Enumerations.QueryOperatorEnum.Equals, KeyValues(i))
                Next
                .Fill()
            End With
           
            Return oObject

        End Function

        Private Function df_GetCollection(ByVal TypeName As String) As TIMSS.API.Core.IBusinessObjectCollection

            Dim oObject As TIMSS.API.Core.IBusinessObjectCollection

            oObject = Me.PersonifyGetCollection(TypeName)

            Return oObject

        End Function

        Private Function df_SaveCollection(ByVal oBusinessObjectColl As TIMSS.API.Core.IBusinessObjectCollection, _
            Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection

            oBusinessObjectColl.Save()

            If oBusinessObjectColl.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then
                RespondToValidationIssues(oBusinessObjectColl.ValidationIssues, RespondedValidationIssues)

                oBusinessObjectColl.Save()
            End If

            Return oBusinessObjectColl.ValidationIssues


        End Function


#End Region


    End Class

End Namespace
