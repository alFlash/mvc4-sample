Imports System
Imports System.Web.Caching
Imports System.Reflection

Namespace Personify.DNN.Modules.ActivateAccount.Data

    Public MustInherit Class DataProvider

#Region "Shared/Static Methods"
        ' singleton reference to the instantiated object 
        Private Shared objProvider As DataProvider = Nothing

        ' constructor
        Shared Sub New()
            CreateProvider()
        End Sub

        ' dynamically create provider
        Private Shared Sub CreateProvider()
            objProvider = CType(Framework.Reflection.CreateObject("data", "Personify.DNN.Modules.ActivateAccount.Data", "Personify.DNN.Modules.ActivateAccount"), DataProvider)
        End Sub

        ' return the provider
        Public Shared Shadows Function Instance() As DataProvider
            Return objProvider
        End Function
#End Region

#Region "Abstract Methods"
        '---------------------------------------------------------------------
        ' TODO Declare DAL methods. Should be implemented in each DAL DataProvider
        ' Use CodeSmith templates to generate this code
        '---------------------------------------------------------------------

        Public MustOverride Function ListActivateAccount() As IDataReader
        Public MustOverride Function GetActivateAccountByModules(ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function GetActivateAccount(ByVal ItemID As Integer, ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function AddActivateAccount(ByVal ModuleId As Integer, ByVal Field1 As String) As Integer
        Public MustOverride Sub UpdateActivateAccount(ByVal ItemId As Integer, ByVal Field1 As String)
        Public MustOverride Sub DeleteActivateAccount(ByVal ItemID As Integer)
#End Region

    End Class

End Namespace
