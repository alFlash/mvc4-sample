Imports System
Imports System.Data
Imports Personify.DNN.Modules.ActivateAccount.Data

Namespace Personify.DNN.Modules.ActivateAccount.Business

    Public Class ActivateAccountController
        'Implements Entities.Modules.ISearchable
        'Implements Entities.Modules.IPortable

#Region "Pulic Methods"
        '---------------------------------------------------------------------
        ' TODO Implement BLL methods
        ' You can use CodeSmith templates to generate this code
        '---------------------------------------------------------------------
        Public Function List() As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().ListActivateAccount(), GetType(ActivateAccountInfo))
        End Function

        Public Function GetByModules(ByVal ModuleId As Integer) As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().GetActivateAccountByModules(ModuleId), GetType(ActivateAccountInfo))
        End Function

        Public Function [Get](ByVal ItemID As Integer, ByVal ModuleId As Integer) As ActivateAccountInfo
            Return CType(CBO.FillObject(DataProvider.Instance().GetActivateAccount(ItemId, ModuleId), GetType(ActivateAccountInfo)), ActivateAccountInfo)
        End Function

        Public Function Add(ByVal objActivateAccount As ActivateAccountInfo) As Integer
            Return CType(DataProvider.Instance().AddActivateAccount(objActivateAccount.ModuleId, objActivateAccount.Field1), Integer)
        End Function

        Public Sub Update(ByVal objActivateAccount As ActivateAccountInfo)
            DataProvider.Instance().UpdateActivateAccount(objActivateAccount.ItemId, objActivateAccount.Field1)
        End Sub

        Public Sub Delete(ByVal ItemID As Integer)
            DataProvider.Instance().DeleteActivateAccount(ItemId)
        End Sub
#End Region

#Region "Optional Interfaces"
        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

        'End Function

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

        'End Sub
#End Region

    End Class

End Namespace
