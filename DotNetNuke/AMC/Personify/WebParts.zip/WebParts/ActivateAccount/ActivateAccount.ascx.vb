Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.ActivateAccount.Business
Imports TIMSS.Server.BusinessMessages.EmailAndFax
Imports System.Threading
Imports System.Web.Mail
Imports System.Xml
Imports System.Xml.XPath
Imports System.Xml.Xsl
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data
Imports Personify.ApplicationManager
Imports System.Text.RegularExpressions

Namespace Personify.DNN.Modules.ActivateAccount

    Public MustInherit Class ActivateAccount
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        'Implements Entities.Modules.IPortable


#Region "Controls"
        Protected WithEvents txtMasterCustomerId As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtSubCustomerId As System.Web.UI.WebControls.TextBox
        Protected WithEvents ctlCaptchaCustomerId As DotNetNuke.UI.WebControls.CaptchaControl
        Protected WithEvents btnContinueCustomerId As System.Web.UI.WebControls.Button
        Protected WithEvents pnlCustomerId As System.Web.UI.WebControls.Panel

        Protected WithEvents txtFirstName As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtLastName As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEmailAddress As System.Web.UI.WebControls.TextBox
        Protected WithEvents ctlCaptchaFirstName As DotNetNuke.UI.WebControls.CaptchaControl
        Protected WithEvents btnContinueFirstName As System.Web.UI.WebControls.Button
        Protected WithEvents pnlFirstName As System.Web.UI.WebControls.Panel

        Private frmMasterCustomerId As String = String.Empty
        Private frmSubCustomerId As String = String.Empty

#End Region
#Region "Constants"
        Public Const C_AUTHENTICATION_METHOD As String = "AuthenticationMethod"
        Public Const C_USE_CAPTCHA As String = "UseCaptcha"
        Public Const C_CREATE_USER_ACTION_URL As String = "CreateNewPasswordActionURL"
#End Region
#Region "Properties"
        Public Property InterfaceType() As String
            Get
                Return CStr(ViewState("InterfaceType"))
            End Get
            Set(ByVal Value As String)
                ViewState("InterfaceType") = Value
            End Set
        End Property

        Public Property AdminEmailAddress() As String
            Get
                Return CStr(ViewState("AdminEmailAddress"))
            End Get
            Set(ByVal Value As String)
                ViewState("AdminEmailAddress") = Value
            End Set
        End Property

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Settings(C_AUTHENTICATION_METHOD) Is Nothing Then
                    If Not Page.IsPostBack Then
                        If GetPersonifySiteSettings(PortalId) Then
                            ReadSettings()
                        Else
                            pnlCustomerId.Visible = False
                            pnlFirstName.Visible = False
                        End If

                    End If
                Else
                    pnlCustomerId.Visible = False
                    pnlFirstName.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub btnContinue_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnContinueCustomerId.Click, btnContinueFirstName.Click
            If FormValidation() Then
                Dim Guid As String = System.Guid.NewGuid.ToString()
                AddPersonifyActivateAccountRecord(Guid)
                SendEmail(Guid)
            End If
        End Sub

#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
#Region "Helper Functions"
        Private Sub ReadSettings()
            If CType(Settings(C_AUTHENTICATION_METHOD), String) = "CustomerId" Then
                pnlCustomerId.Visible = True
                pnlFirstName.Visible = False
                If CType(Settings(C_USE_CAPTCHA), String) = "Y" Then
                    ctlCaptchaCustomerId.Visible = True
                Else
                    ctlCaptchaCustomerId.Visible = False
                End If
            ElseIf CType(Settings(C_AUTHENTICATION_METHOD), String) = "FirstName" Then
                pnlCustomerId.Visible = False
                pnlFirstName.Visible = True
                If CType(Settings(C_USE_CAPTCHA), String) = "Y" Then
                    ctlCaptchaFirstName.Visible = True
                Else
                    ctlCaptchaFirstName.Visible = False
                End If
            Else
                pnlCustomerId.Visible = False
                pnlFirstName.Visible = False
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
            End If
        End Sub
        Private Function GetPersonifySiteSettings(ByVal CurrPortalID As Integer) As Boolean

            AdminEmailAddress = PersonifySiteSettings.GetSiteSettings(CurrPortalID).AdminEmailAddress

            If AdminEmailAddress.Length = 0 OrElse (AdminEmailAddress.Length > 0 AndAlso Not Regex.IsMatch((AdminEmailAddress), C_EMAIL_REGULAR_EXPRESSION)) Then
                If String.Equals(Me.GetUserRole(UserInfo), "host", StringComparison.OrdinalIgnoreCase) Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ActivateAccountNotAvailable", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

                Return False
            End If

            Return True

            'Dim oSiteData As System.Data.SqlClient.SqlDataReader
            'Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString



            'oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(ConnectionString, "dbo." & "" & "GetPersonifySiteSettings", CurrPortalID), System.Data.SqlClient.SqlDataReader)
            'If oSiteData.HasRows Then
            '    While oSiteData.Read
            '        If (Not oSiteData.Item("AdminEmailAddress") Is Nothing) AndAlso (Not oSiteData.Item("AdminEmailAddress").ToString = "") Then
            '            AdminEmailAddress = CType(oSiteData.Item("AdminEmailAddress"), String)
            '        Else
            '            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            '            Return False
            '        End If
            '    End While
            'Else
            '    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            '    Return False
            'End If
            'oSiteData.Close()
            'oSiteData = Nothing

            'Return True
        End Function
        Private Function FormValidation() As Boolean

            Select Case CType(Settings(C_AUTHENTICATION_METHOD), String)
                Case "CustomerId"
                    If CType(Settings(C_USE_CAPTCHA), String) = "Y" AndAlso Not ctlCaptchaCustomerId.IsValid Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidCaptcha", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If txtMasterCustomerId.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingMasterCustomerId", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If txtSubCustomerId.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingSubCustomerId", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                    oCustomers = GetCustomer(txtMasterCustomerId.Text, txtSubCustomerId.Text)
                    If oCustomers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("CustomerDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If oCustomers(0).PrimaryEmailAddress Is Nothing Or oCustomers(0).PrimaryEmailAddress = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("CustomerDoesNotHavePrimaryEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
                    oWebUsers = GetWebUser(txtMasterCustomerId.Text, txtSubCustomerId.Text)
                    If oWebUsers.Count = 1 AndAlso oWebUsers(0).UserId <> txtMasterCustomerId.Text Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("AccountAlreadyExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    frmMasterCustomerId = txtMasterCustomerId.Text
                    frmSubCustomerId = txtSubCustomerId.Text
                Case "FirstName"
                    If CType(Settings(C_USE_CAPTCHA), String) = "Y" AndAlso Not ctlCaptchaFirstName.IsValid Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidCaptcha", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If txtFirstName.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingFirstName", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If txtLastName.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingLastName", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If txtEmailAddress.Text = String.Empty Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    Dim oRegex As New System.Text.RegularExpressions.Regex("^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$")
                    If Not oRegex.IsMatch(txtEmailAddress.Text) Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEmailAddress", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                    oCustomers = GetCustomer(txtFirstName.Text, txtLastName.Text, txtEmailAddress.Text)

                    If oCustomers.Count <= 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("CustomerDoesNotExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    ElseIf oCustomers.Count > 1 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If


                    Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers
                    oWebUsers = GetWebUser(oCustomers(0).MasterCustomerId, oCustomers(0).SubCustomerId)
                    If (oWebUsers.Count = 1 AndAlso oWebUsers(0).UserId <> oWebUsers(0).MasterCustomerId) Or (oWebUsers.Count > 1) Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("AccountAlreadyExists", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    frmMasterCustomerId = oCustomers(0).MasterCustomerId
                    frmSubCustomerId = CType(oCustomers(0).SubCustomerId, String)
            End Select
            Return True
        End Function

        Private Sub SendEmail(ByVal guid As String)
            Try
                If Page.IsValid Then
                    pnlCustomerId.Visible = False
                    pnlFirstName.Visible = False

                    Dim oEmail As New TIMSS.EmailManager
                    '
                    If CType(Settings(C_AUTHENTICATION_METHOD), String) = "FirstName" Then
                        oEmail.To = txtEmailAddress.Text
                    Else
                        Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                        oCustomers = GetCustomer(frmMasterCustomerId, frmSubCustomerId)
                        oEmail.To = oCustomers(0).PrimaryEmailAddress
                    End If

                    oEmail.Subject = Services.Localization.Localization.GetString("EmailSubject", Me.LocalResourceFile)

                    oEmail.FromEmail = AdminEmailAddress
                    oEmail.FromName = Services.Localization.Localization.GetString("EmailFromName", Me.LocalResourceFile)

                    Dim emailTemplateFile As String = Server.MapPath(ModulePath + "Templates\EmailTemplate.xsl")
                    Dim ApplicationId As String = String.Empty
                    Dim strTabId As String = Settings(C_CREATE_USER_ACTION_URL).ToString
                    Dim LinkToFollow As String = NavigateURL(Integer.Parse(strTabId), "", "&a=" & guid)

                    Dim xml As System.Xml.XmlReader = New System.Xml.XmlTextReader(New System.IO.StringReader("<?xml version='1.0'?><LinkToFollow>" & LinkToFollow & "</LinkToFollow>"))
                    Dim document As XmlDocument = New XmlDocument()
                    document.Load(xml)
                    Dim transformer As XslCompiledTransform = New XslCompiledTransform()
                    transformer.Load(emailTemplateFile)
                    Dim output As StringWriter = New StringWriter()
                    transformer.Transform(document, Nothing, output)
                    oEmail.Body = output.ToString
                    output.Close()

                    oEmail.IsBodyHtml = False
                    If (oEmail.Send()) Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("SuccessMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("FailureMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                    pnlCustomerId.Visible = False
                    pnlFirstName.Visible = False
                End If
            Catch exc As System.Net.Mail.SmtpFailedRecipientException
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("InvalidEmailAddress", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                pnlCustomerId.Visible = False
                pnlFirstName.Visible = False
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub

        Private Sub Redirect(ByVal applicationId As String)
            Dim strTabId As String = Settings(C_CREATE_USER_ACTION_URL).ToString
            Dim LinkToFollow As String = NavigateURL(Integer.Parse(strTabId), "", "&a=" & applicationId)

            Response.Redirect(LinkToFollow)
        End Sub

        Private Sub AddPersonifyActivateAccountRecord(ByVal guid As String)
            Dim sqlParamArr(2) As SqlParameter
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            Dim CustomerId As String = frmMasterCustomerId & TIMSS.Constants.Application.C_KEY_DELIMITER & frmSubCustomerId
            sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
            sqlParamArr(0).Value = PortalId.ToString
            sqlParamArr(1) = New SqlParameter("@CustomerId", SqlDbType.NVarChar, 100)
            sqlParamArr(1).Value = CustomerId
            sqlParamArr(2) = New SqlParameter("@ApplicationId", SqlDbType.NVarChar, 100)
            sqlParamArr(2).Value = guid

            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(ConnectionString, "dbo." & "" & "AddPersonifyActivateAccount", sqlParamArr(0), sqlParamArr(1), sqlParamArr(2))

        End Sub
#End Region

#Region "Personify Data"
        Private Function GetCustomer(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", MCID)
                .Filter.Add("SubCustomerId", SCID)
                .Fill()
            End With

            Return oCustomers

        End Function

        Private Function GetWebUser(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.WebInfo.IWebUsers

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers

            oWebUsers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")
            oWebUsers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MCID)
            oWebUsers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SCID)
            oWebUsers.Fill()
            Return oWebUsers

        End Function

        Private Function GetCustomer(ByVal FirstName As String, ByVal LastName As String, ByVal PrimaryEmailAddress As String) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers



            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                With oCustomers
                    .Filter.Add("FirstName", TIMSS.Enumerations.QueryOperatorEnum.Equals, FirstName)
                    .Filter.Add("LastName", TIMSS.Enumerations.QueryOperatorEnum.Equals, LastName)
                    .Filter.Add("PrimaryEmailAddress", TIMSS.Enumerations.QueryOperatorEnum.Equals, PrimaryEmailAddress)
                    .Fill()
                End With
            End With

            Return oCustomers

        End Function
#End Region
    End Class

End Namespace
