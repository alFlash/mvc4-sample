Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.ActivateAccount.Business

Namespace Personify.DNN.Modules.ActivateAccount

    Public MustInherit Class ActivateAccountEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents rdAuthenticationMethod As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents drpCreateUserActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents chkUseCaptcha As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
#End Region
#Region "Constants"
        Public Const C_AUTHENTICATION_METHOD As String = "AuthenticationMethod"
        Public Const C_USE_CAPTCHA As String = "UseCaptcha"
        Public Const C_CREATE_USER_ACTION_URL As String = "CreateNewPasswordActionURL"
#End Region


#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    LoadSettings()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                UpdateSettings()
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        
#End Region
#Region "Helper Functions"
        Private Sub LoadSettings()
            If Not Settings(C_AUTHENTICATION_METHOD) Is Nothing Then
                Select Case CType(Settings(C_AUTHENTICATION_METHOD), String)
                    Case "CustomerId"
                        rdAuthenticationMethod.SelectedValue = "CustomerId"
                    Case "FirstName"
                        rdAuthenticationMethod.SelectedValue = "FirstName"
                End Select
            Else
                rdAuthenticationMethod.SelectedValue = "CustomerId"
            End If

            If Not Settings(C_USE_CAPTCHA) Is Nothing Then
                If CType(Settings(C_USE_CAPTCHA), String) = "Y" Then
                    chkUseCaptcha.Checked = True
                Else
                    chkUseCaptcha.Checked = False
                End If
            End If


            If Not Settings(C_CREATE_USER_ACTION_URL) Is Nothing Then
                drpCreateUserActionURL.Url = CType(Settings(C_CREATE_USER_ACTION_URL), String)
            End If
        End Sub
        Private Sub UpdateSettings()
            Dim objModules As New Entities.Modules.ModuleController
            objModules.UpdateModuleSetting(Me.ModuleId, Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

            objModules.UpdateModuleSetting(Me.ModuleId, C_AUTHENTICATION_METHOD, rdAuthenticationMethod.SelectedValue)

            If chkUseCaptcha.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_USE_CAPTCHA, "Y")
            Else
                objModules.UpdateModuleSetting(Me.ModuleId, C_USE_CAPTCHA, "N")
            End If

            objModules.UpdateModuleSetting(Me.ModuleId, C_CREATE_USER_ACTION_URL, drpCreateUserActionURL.Url)

        End Sub

#End Region
#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
