SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ABS_CustomerSearch]
@first_name AS VARCHAR(40),
@last_name AS VARCHAR(40)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
select c.master_customer_id, c.sub_customer_id, c.last_first_name,
c2.label_name as institution
from customer c
left outer join cus_relationship cr on 
c.master_customer_id=cr.master_customer_id
and c.sub_customer_id=cr.sub_customer_id 
and cr.primary_employer_flag='Y'
and cr.relationship_type = 'Employment'
and cr.reciprocal_code = 'Employer'
left join customer c2
on
c2.master_customer_id=cr.related_master_customer_id
and c2.sub_customer_id=cr.related_sub_customer_id  
where 
c.record_type = 'I'
and c.customer_status_code = 'ACTIVE'
and c.first_name like @first_name + '%'
and c.last_name like @last_name + '%'
and (c.master_customer_id+'|'+cast(c.sub_customer_id as varchar(5))) not in (select (master_customer_id+'|'+ cast(sub_customer_id as varchar(5))) from abs_reviewer)
order by c.last_first_name

END


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ABS_ReviewerSearch]
@first_name AS VARCHAR(40)
,@last_name AS VARCHAR(40)
,@reviewer_approved_for_code AS VARCHAR(40)
,@expertise_code AS VARCHAR(40)
,@expertise_level_code AS VARCHAR(40)
,@end_date AS DateTime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

select r.master_customer_id, r.sub_customer_id, c2.last_first_name 
,cr.master_customer_id, cr.sub_customer_id
,c1.label_name as institution
,rt.reviewer_approved_for_code, rt.end_date
,re.expertise_code, re.expertise_subcode, re.expertise_level_code
from abs_reviewer r
left join customer c2
on
c2.master_customer_id=r.master_customer_id
and c2.sub_customer_id=r.sub_customer_id 
left  join cus_relationship cr on 
r.master_customer_id=cr.related_master_customer_id
and r.sub_customer_id=cr.related_sub_customer_id 
--and r.reviewer_status_code = 'ACTIVE'
and cr.primary_employer_flag='Y'
and cr.relationship_type = 'Employment'
and cr.reciprocal_code = 'Employer'
left join customer c1
on
c1.master_customer_id=cr.master_customer_id
and c1.sub_customer_id=cr.sub_customer_id 
left join abs_reviewer_term rt
on 
c2.master_customer_id=rt.master_customer_id
and c2.sub_customer_id=rt.sub_customer_id 
join abs_reviewer_expertise re
on
c2.master_customer_id=re.master_customer_id
and c2.sub_customer_id=re.sub_customer_id 
where
c2.first_name like @first_name + '%'
and 
c2.last_name like @last_name + '%'
and
rt.reviewer_approved_for_code like @reviewer_approved_for_code + '%'
and
re.expertise_code like @expertise_code + '%'
and
re.expertise_level_code like @expertise_level_code + '%'
and
((rt.end_date is NULL) or (rt.end_date >= getdate() ) )
order by c2.last_first_name


END


/****** Object:  StoredProcedure [dbo].[ABS_SubmissionReviewerSearch]    Script Date: 12/29/2008 12:09:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ABS_SubmissionReviewerSearch]
@abs_call_code as VARCHAR(40)
,@submission_type_code as VARCHAR(40)
,@first_name AS VARCHAR(40)
,@last_name AS VARCHAR(40)
,@reviewer_approved_for_code AS VARCHAR(40)
,@expertise_code AS VARCHAR(40)
,@expertise_level_code AS VARCHAR(40)
,@end_date AS DateTime
,@MaxNumberOfAssignments as int
,@MaxNumberOfOpenAssignments as int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

select r.master_customer_id, r.sub_customer_id, c2.last_first_name 
,cr.master_customer_id, cr.sub_customer_id
,c1.label_name as institution
,rt.reviewer_approved_for_code, rt.end_date
,re.expertise_code, re.expertise_subcode, re.expertise_level_code
,cstr.abs_call_submission_type_reviewer_id
,cstr.number_of_assignments
,cstr.number_of_open_assignments
from abs_reviewer r
left join customer c2
on
c2.master_customer_id=r.master_customer_id
and c2.sub_customer_id=r.sub_customer_id 
left  join cus_relationship cr on 
r.master_customer_id=cr.related_master_customer_id
and r.sub_customer_id=cr.related_sub_customer_id 
--and r.reviewer_status_code = 'ACTIVE'
and cr.primary_employer_flag='Y'
and cr.relationship_type = 'Employment'
and cr.reciprocal_code = 'Employer'
left join customer c1
on
c1.master_customer_id=cr.master_customer_id
and c1.sub_customer_id=cr.sub_customer_id 
left join abs_reviewer_term rt
on 
c2.master_customer_id=rt.master_customer_id
and c2.sub_customer_id=rt.sub_customer_id 
join abs_reviewer_expertise re
on
c2.master_customer_id=re.master_customer_id
and c2.sub_customer_id=re.sub_customer_id 

join abs_call_submission_type_reviewer cstr
on 
c2.master_customer_id=cstr.master_customer_id
and c2.sub_customer_id=cstr.sub_customer_id 
and
abs_call_code = @abs_call_code
and 
submission_type_code = @submission_type_code

where

c2.first_name like @first_name + '%'
and 
c2.last_name like @last_name + '%'
and
rt.reviewer_approved_for_code like @reviewer_approved_for_code + '%'
and
re.expertise_code like @expertise_code + '%'
and
re.expertise_level_code like @expertise_level_code + '%'
and
((rt.end_date is NULL) or (rt.end_date >= getdate() ) )

and ((@MaxNumberOfAssignments is NULL) OR (@MaxNumberOfAssignments=0) OR (cstr.number_of_assignments < @MaxNumberOfAssignments))
and ((@MaxNumberOfOpenAssignments is NULL) OR (@MaxNumberOfOpenAssignments=0) OR (cstr.number_of_open_assignments < @MaxNumberOfOpenAssignments))


order by c2.last_first_name


END
