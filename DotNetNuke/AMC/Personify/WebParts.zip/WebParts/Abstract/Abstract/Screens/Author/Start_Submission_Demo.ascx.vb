Imports TIMSS.SQLObjects
Imports ScreenController.AbstractScreen

Public Class Start_Submission_Demo
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents TextBoxFirstName As TextBox
    Protected WithEvents TextBoxLastName As TextBox
    Protected WithEvents TextBoxEmail As TextBox
    Protected WithEvents TextBoxPhone As TextBox
    Protected WithEvents TextBoxCity As TextBox
    Protected WithEvents RadComboBoxInstitution As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxCredentials As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxState As Telerik.Web.UI.RadComboBox

    Protected WithEvents LinkButtonClearSearch As LinkButton
    Protected WithEvents LinkButtonSearch As LinkButton
    Protected WithEvents LinkButtonEmail As LinkButton

    Protected WithEvents RadGrid1 As Telerik.Web.UI.RadGrid

#End Region


#Region "Events"


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

    End Sub

#End Region



    'Private Sub RadGrid1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGrid1.NeedDataSource
    '    If Page.IsPostBack Then RadGrid1.DataSource = GetAuthorsData()
    'End Sub




    Public Function GetData() As DataTable


        Dim oData As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

        oData = CallManager.ABSSubmissionType_Get(PortalId, Nothing, Nothing)


        Dim oDataDT As DataTable = New DataTable()

        If oData IsNot Nothing AndAlso oData.Count > 0 Then


            oDataDT.Columns.Add("AbstractCall", Type.GetType("System.String"))
            oDataDT.Columns.Add("SubmissionType", Type.GetType("System.String"))
            oDataDT.Columns.Add("Link", Type.GetType("System.String"))

            Dim row As DataRow
            For Each o As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType In oData
                If o.IsWebSubmissionAllowed Then
                    row = oDataDT.NewRow()
                    row("AbstractCall") = o.AbstractCallInfo.Title
                    row("SubmissionType") = o.Description

                    row("Link") = NavigateURL("", "s=" & ScreenController.AbstractScreen.Author_SubmissionEntryGeneralInformation & "&args=" & o.AbstractCallCode & "&type=" & o.SubmissionTypeCodeString)
                    oDataDT.Rows.Add(row)
                End If
            Next

            Return oDataDT

        End If

        Return oDataDT

    End Function




    Private Sub RadGrid1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGrid1.NeedDataSource
        RadGrid1.DataSource = GetData()
    End Sub
End Class
