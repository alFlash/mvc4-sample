Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI
Imports PersonifyWebCommon

Public Class SubmissionEntryConfirmation
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


#Region "Controls"
    Protected WithEvents pnlMain As Panel
    Protected WithEvents lblMessage As Label

    Protected WithEvents RadGridAuthors As RadGrid
    Protected WithEvents ctlSubmissionTextBlocks As SubmissionTextBlocks
    Protected WithEvents ctlSubmissionAttachments As SubmissionAttachments

    Protected WithEvents RadGridDisclosureQuestions As RadGrid

    Protected WithEvents btnSubmitContent As Button
    Protected WithEvents btnPrevious As Button
    Protected WithEvents btnSaveForLater As Button

    Protected WithEvents pnlButtons As Panel

    Protected WithEvents RadComboBoxRecordPresentation As RadComboBox
    Protected WithEvents RadComboBoxTakePhotographs As RadComboBox
    Protected WithEvents RadComboBoxPublish As RadComboBox
    Protected WithEvents RadComboBoxOtherPresentations As RadComboBox

    Protected HyperLinkAddAuthor As HyperLink
    Protected HyperLinkEditContext As HyperLink
    Protected HyperLinkEditAttachments As HyperLink
    Protected HyperLinkEditSubmissionInfo As HyperLink
    Protected WithEvents lblAbstractTitle As Label
    Protected WithEvents lblCategory As Label
    Protected WithEvents lblLengthInMinutes As Label
    Protected WithEvents lblTopics As Label
    Protected WithEvents lblKeywords As Label

    Protected WithEvents butAuthorReport As Button
 
    Protected WithEvents lblSubmissionId As Label
    Protected WithEvents RadAjaxPanelAttachments As RadAjaxPanel

#End Region
#Region "Properties"
    Public ReadOnly Property AbstractSubmissionId() As Integer
        Get
            If Request("sid") IsNot Nothing Then
                Return CInt(Request("sid"))
            Else
                Return 0
            End If
        End Get
    End Property

    Private _mode As String = String.Empty
    Public ReadOnly Property Mode() As String
        Get
            'If Request("mode") IsNot Nothing Then
            '    Return CStr(Request("mode"))
            'Else
            '    Return String.Empty
            'End If


            If String.IsNullOrEmpty(_mode) Then
                If ABS_AcessControl_IsAuthorBelongToSubmission(Me.MasterCustomerId, Me.SubCustomerId, Request("sid")) Then
                    _mode = "Edit"
                Else
                    _mode = "View"
                End If
            End If
            Return _mode
        End Get
    End Property

#End Region
#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If ValidateQS() Then

            If Mode = "View" Then
                pnlButtons.Visible = False
            Else
                pnlMain.Visible = True
                lblMessage.Visible = False
            End If

            If Not Page.IsPostBack Then
                SetupControls()
            End If

            With ctlSubmissionAttachments
                .AbstractSubmissionId = AbstractSubmissionId
                Dim AdditionalPathExtension As String = String.Concat(GetArgs(), "\", GetSubType(), "\", AbstractSubmissionId)
                .AdditionalPathExtension = AdditionalPathExtension
                'If Mode = "View" Then .IsEdit = False Else .IsEdit = True
                .IsEdit = False  'is the confirmation page
                .PortalId = PortalId
            End With
        Else
            pnlMain.Visible = False
            lblMessage.Visible = True
            lblMessage.Text = "Query String arguments expected"
        End If
    End Sub


    Protected Sub RadGridAuthors_NeedDataSource(ByVal [source] As Object, _
         ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()

        RadGridAuthors.DataSource = LoadAuthors()

    End Sub
    Protected Sub btnPrevious_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        GoToNextPage(Author_SubmissionEntryContent, GetArgs, AbstractSubmissionId, 0, GetSubType)
    End Sub

    Protected Sub btnSubmitContent_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmitContent.Click
        Dim oSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
        Dim tmpString As String = String.Empty
        oSubmissions = CallManager.GetAbstractSubmission(PortalId, AbstractSubmissionId)

        If oSubmissions IsNot Nothing AndAlso oSubmissions.Count > 0 Then
            If oSubmissions(0).IsSubmissionAllowed Then
                oSubmissions(0).EventStatusCode = Constants.Const_EventCode_SUBMISSION_SUBMITTED
                oSubmissions(0).Validate()
                oSubmissions(0).SubmissionDate = DateTime.Now
                oSubmissions.Save()
                If oSubmissions.ValidationIssues.ErrorCount = 0 Then
                    Response.Redirect(NavigateURL("", "s=0"))
                End If
            Else
                Me.ShowPopupMessage(oSubmissions.ValidationIssues(0).Message)
            End If
        End If
    End Sub

    Protected Sub btnSaveForLater_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSaveForLater.Click
        
        Response.Redirect(NavigateURL("", "s=0"))

    End Sub
#End Region


#Region "Helper functions"

    Private Sub SetupControls()

        Dim strTopics As New System.Text.StringBuilder
        Dim strKeywords As New System.Text.StringBuilder
        Dim oSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission
        oSubmission = CallManager.GetSubmission(PortalId, AbstractSubmissionId)

        If oSubmission.ExternalStatusCodeString <> "DRAFT" Then
            _mode = "View"
            pnlButtons.Visible = False
        End If


        'Build the Topics String
        For Each oTopic As TIMSS.API.AbstractInfo.IAbstractSubmissionTopic In oSubmission.AbstractSubmissionTopics
          
            If Not String.IsNullOrEmpty(oTopic.TopicCode.Code) Then
                If strTopics.Length <> 0 Then
                    strTopics.Append(",<br />")
                End If                
                strTopics.Append(oTopic.TopicCode.Description)
                If oTopic.PrimaryTopicFlag Then
                    strTopics.Append("(Primary)")
                End If
            Else
                If strTopics.Length <> 0 Then
                    strTopics.Append(",<br />")
                End If
                strTopics.Append(oTopic.Topic)
                If oTopic.PrimaryTopicFlag Then
                    strTopics.Append(" (Primary)")
                End If
            End If
            
        Next

        'Build the Keywords String
        For Each oKeyword As TIMSS.API.AbstractInfo.IAbstractSubmissionKeyword In oSubmission.AbstractSubmissionKeywords            
            If Not String.IsNullOrEmpty(oKeyword.KeywordCode.Code) Then
                If strKeywords.Length <> 0 Then
                    strKeywords.Append(",<br />")
                End If
                strKeywords.Append(oKeyword.KeywordCode.Description)
            Else
                If strKeywords.Length <> 0 Then
                    strKeywords.Append(",<br />")
                End If
                strKeywords.Append(oKeyword.Keyword)
            End If
            
        Next

        'Set the Submission Information
        lblAbstractTitle.Text = oSubmission.Title
        lblCategory.Text = oSubmission.CategoryCode.Description
        lblLengthInMinutes.Text = oSubmission.LengthInMinutes.ToString
        lblTopics.Text = strTopics.ToString
        lblKeywords.Text = strKeywords.ToString

        If Mode = "View" Then
            HyperLinkEditContext.Visible = False
            HyperLinkEditAttachments.Visible = False
            HyperLinkEditSubmissionInfo.Visible = False
        Else
            Dim url As String = AppendReturnURL(GetNextPageURL(Author_SubmissionEntryContent, GetArgs, AbstractSubmissionId.ToString(), 0, GetSubType, Nothing))
            HyperLinkEditContext.NavigateUrl = url
            HyperLinkEditAttachments.NavigateUrl = url
            HyperLinkEditSubmissionInfo.NavigateUrl = AppendReturnURL(GetNextPageURL(Author_SubmissionEntryGeneralInformation, GetArgs, AbstractSubmissionId.ToString(), 0, GetSubType, Nothing))
        End If

        If lblSubmissionId IsNot Nothing Then lblSubmissionId.Text = AbstractSubmissionId

        With ctlSubmissionTextBlocks
            .AbstractSubmissionId = AbstractSubmissionId
            '.EditNavigateURL = GetNextPageURL(Author_SubmissionEntryContent, GetArgs, AbstractSubmissionId.ToString(), 0, GetSubType, Nothing)
            'If Mode = "View" Then .IsEdit = False Else .IsEdit = True
            .IsEdit = False
            .PortalId = PortalId
        End With


        With oSubmission

            Dim item As RadComboBoxItem
            If .PermissionToRecordFlag Then
                item = RadComboBoxRecordPresentation.FindItemByValue("Y")
            Else
                item = RadComboBoxRecordPresentation.FindItemByValue("N")
            End If
            If item IsNot Nothing Then
                item.Selected = True
            End If

            If .PermissionToPhotographFlag Then
                item = RadComboBoxTakePhotographs.FindItemByValue("Y")
            Else
                item = RadComboBoxTakePhotographs.FindItemByValue("N")
            End If
            If item IsNot Nothing Then
                item.Selected = True
            End If

            If .PermissionToPublishFlag Then
                item = RadComboBoxPublish.FindItemByValue("Y")
            Else
                item = RadComboBoxPublish.FindItemByValue("N")
            End If
            If item IsNot Nothing Then
                item.Selected = True
            End If


            If .ConsiderForOtherTypeFlag Then
                item = RadComboBoxOtherPresentations.FindItemByValue("Y")
            Else
                item = RadComboBoxOtherPresentations.FindItemByValue("N")
            End If
            If item IsNot Nothing Then
                item.Selected = True
            End If
        End With


    End Sub


    Private Function ValidateQS() As Boolean
        If String.IsNullOrEmpty(Request("sid")) Then
            Return False
        Else
            Return True
        End If

    End Function

    Private Function LoadAuthors() As ArrayList
        If Mode = "View" Then
            HyperLinkAddAuthor.Visible = False
        Else
            HyperLinkAddAuthor.NavigateUrl = GetAuthorPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryAuthorInformation, GetArgs, AbstractSubmissionId, 0, GetSubType, True)
        End If
        Dim oAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        oAuthors = CallManager.GetSubmissionAuthors(PortalId, AbstractSubmissionId)

        Dim list As ArrayList = New ArrayList()
        If oAuthors IsNot Nothing AndAlso oAuthors.Count > 0 Then

            For i As Integer = 0 To oAuthors.Count - 1
                Dim row As AuthorItem = New AuthorItem
                row.AbstractSubmissionAuthorId = oAuthors(i).AbstractSubmissionAuthorId
                row.CompanyInstitutionName = oAuthors(i).CompanyInstitutionName
                row.Name = String.Format("{0} {1}", oAuthors(i).FirstName, oAuthors(i).LastName)

                If Not String.IsNullOrEmpty(oAuthors(i).NameSuffixString) Then
                    row.Name = String.Format("{0}, {1}", row.Name, oAuthors(i).NameSuffixString)
                End If

                row.Roles = oAuthors(i).AuthorRoleCodeString
                If Mode = "View" Then
                    row.EditText = ""
                Else
                    row.EditText = "Edit"
                    row.EditURL = GetAuthorPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryAuthorInformation, GetArgs, AbstractSubmissionId, oAuthors(i).AbstractSubmissionAuthorId, GetSubType)
                End If
                list.Add(row)
            Next
        End If

        Return list

    End Function

    Protected Sub RadGridDisclosureQuestions_NeedDataSource(ByVal [source] As Object, _
           ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()

        RadGridDisclosureQuestions.DataSource = LoadAuthorDisclosureQuestions()
    End Sub

    Private Function LoadAuthorDisclosureQuestions() As ArrayList

        Dim call_code As String = String.Empty
        Dim submission_type As String = String.Empty
        Dim oAbstractSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission
        oAbstractSubmission = CallManager.GetSubmission(PortalId, AbstractSubmissionId)
        If oAbstractSubmission IsNot Nothing Then
            call_code = oAbstractSubmission.AbstractCallCode
            submission_type = oAbstractSubmission.SubmissionTypeCode
        End If

        Dim oAbstractCallSubmissionTypeAuthorDisclosureControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
        oAbstractCallSubmissionTypeAuthorDisclosureControls = CallManager.ABSSubmissionType_GetAuthorDisclosureQuestions(PortalId, call_code, submission_type)

        Dim list As ArrayList = New ArrayList()

        For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAbstractSubmission.AbstractSubmissionAuthors
            For Each oAnswer As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosure In oAuthor.AbstractSubmissionAuthorDisclosures
                'find the related question
                Dim question As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl
                question = oAbstractCallSubmissionTypeAuthorDisclosureControls.FindObject("AbstractCallSubmissionTypeAuthorDisclosureControlId", oAnswer.AbstractCallSubmissionTypeAuthorDisclosureControlId)

                If question IsNot Nothing Then
                    Dim row As AuthorDisclosureQuestionsData = New AuthorDisclosureQuestionsData()
                    row.AuthorDisclosureControlId = oAnswer.AbstractSubmissionAuthorDisclosureId
                    row.QuestionText = question.QuestionText
                    row.QuestionSeq = question.QuestionSequence
                    row.RelatedCustomerName = oAnswer.RelatedCustomerName
                    row.DisclosureProductDescription = oAnswer.DisclosureProductDescription
                    list.Add(row)
                End If

            Next
        Next


        Return list

    End Function
#End Region

    Private Sub butAuthorReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butAuthorReport.Click
        'Report_GetAbstractSubmission
        Dim strReleaseURL As String
        Dim strReportURL As String
        strReportURL = Report_GetAbstractSubmission(PortalId, Me.OrganizationId, Me.OrganizationUnitId, "ABS1008_Authors", Me.AbstractSubmissionId, strReleaseURL)
        If Not String.IsNullOrEmpty(strReportURL) AndAlso Not String.IsNullOrEmpty(strReleaseURL) Then
            'Register the Java script
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "winOpen", Report_BuildNewWindow_JavaScript(strReportURL, strReleaseURL), True)
            'Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "InitializeJS", sb.ToString)
        End If
    End Sub

  


    'Private Function GetAbstractSubmissionReport(ByVal OrgId As String, ByVal OrgUnitId As String, ByVal ReportName As String, ByVal SubmissionId As Integer) As String
    '    Dim strURL As String = String.Empty
    '    Dim strStatus As String = String.Empty
    '    Dim ReportParameters As New Specialized.NameValueCollection

    '    Dim oclsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)

    '    ReportParameters.Add("Org ID", OrgId)
    '    ReportParameters.Add("Org Unit ID", OrgUnitId)
    '    ReportParameters.Add("Submission ID", SubmissionId)

    '    strURL = String.Concat(oclsReporting.GetReportURL(PortalId, ReportName, ReportParameters, strStatus), "&cmd=EXPORT&EXPORT_FMT=U2FPDF:0&sOutputFormat=P")
    '    'Get the Release URL to relase the BO license
    '    If strURL.IndexOf("ProxySession") > 0 Then
    '        'Fire the URL to release the session
    '        strReleaseURL = oclsReporting.GetReleaseURL(True)
    '    Else
    '        'Fire the URL to release the session
    '        strReleaseURL = oclsReporting.GetReleaseURL(False)
    '    End If

    '    oclsReporting = Nothing

    '    Return strURL

    'End Function

    'Private Function GetReportURL(ByVal strReportName As String) As String
    '    Dim strReportURL As String = String.Empty
    '    strReportURL = GetAbstractSubmissionReport(Me.OrganizationId, Me.OrganizationUnitId, strReportName, Me.AbstractSubmissionId)
    '    Return strReportURL
    'End Function


End Class

Public Class AuthorItem
    Private _AbstractSubmissionAuthorId As Integer
    Private _CompanyInstitutionName As String
    Private _Name As String
    Private _Roles As String
    Private _EditURL As String
    Private _EditText As String

    Public Property AbstractSubmissionAuthorId() As Integer
        Get
            Return _AbstractSubmissionAuthorId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionAuthorId = value
        End Set
    End Property

    Public Property CompanyInstitutionName() As String
        Get
            Return _CompanyInstitutionName
        End Get
        Set(ByVal value As String)
            _CompanyInstitutionName = value
        End Set
    End Property
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property
    Public Property Roles() As String
        Get
            Return _Roles
        End Get
        Set(ByVal value As String)
            _Roles = value
        End Set
    End Property
    Public Property EditURL() As String
        Get
            Return _EditURL
        End Get
        Set(ByVal value As String)
            _EditURL = value
        End Set
    End Property

    Public Property EditText() As String
        Get
            Return _EditText
        End Get
        Set(ByVal value As String)
            _EditText = value
        End Set
    End Property
    'Public Sub New(ByVal AbstractSubmissionAuthorId As Integer, ByVal CompanyInstitutionName As String, ByVal Name As String, ByVal Roles As String)
    '   Me.AbstractSubmissionAuthorId = AbstractSubmissionAuthorId
    '    Me.CompanyInstitutionName = CompanyInstitutionName
    '    Me.Name = Name
    '    Me.Roles = Roles
    'End Sub
End Class
