Imports TIMSS.API.Core
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic
Imports Telerik.Web.UI

Public Class AuthorDetails
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private _oWebAuthors As List(Of WEB_SUBMISSIONAUTHOR)
#End Region

#Region "Controls"
    Protected WithEvents lblNumberOfAuthors As Label
    Protected WithEvents btnAddAuthor As Button
    Protected WithEvents RadGridAuthors As RadGrid
    Protected WithEvents lbtnSelectAll As LinkButton
    Protected WithEvents lbtnSelectNone As LinkButton
    Protected WithEvents ddlActions As RadComboBox
    Protected WithEvents pnlAuthorDetail As Panel
    Protected WithEvents pnlAddAuthor As Panel
    Protected WithEvents ddlCallCode As Telerik.Web.UI.RadComboBox

#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetupControls()

    End Sub

    Private Sub lbtnSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnSelectAll.Click
        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridAuthors.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                CType(oItem.FindControl("chkSelect"), CheckBox).Checked = True
            End If
        Next
    End Sub

    Private Sub lbtnSelectNone_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnSelectNone.Click
        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridAuthors.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                CType(oItem.FindControl("chkSelect"), CheckBox).Checked = False
            End If
        Next
    End Sub

    Private Sub ddlActions_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlActions.SelectedIndexChanged
        Dim Authors As New ArrayList

        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridAuthors.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                If CType(oItem.FindControl("chkSelect"), CheckBox).Checked Then
                    Authors.Add(GetAuthorEmailObject(Convert.ToInt32(oItem.Item("AbstractSubmissionAuthorId").Text)))
                End If
            End If
        Next

        If Authors.Count > 0 Then
            Session(Constants.Const_EmailListSessionName) = Authors

            Select Case ddlActions.SelectedValue
                Case "SendEmail"
                    Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Admin_Email, String))))
            End Select
        End If
    End Sub

    Private Sub RadGridAuthors_DeleteCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridAuthors.DeleteCommand
        Dim ID As String = RadGridAuthors.Items(e.Item.ItemIndex)("AbstractSubmissionAuthorId").Text
        Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = SubmissionManager.ABS_Submission_Author_Delete(PortalId, CType(GetAbsSubId(), Integer), ID)

        If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
            e.Canceled = True
        Else
            SetupControls()
        End If

    End Sub

    Private Sub btnAddAuthor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddAuthor.Click
        'pnlAuthorDetail.Visible = False
        pnlAddAuthor.Visible = True

        Dim ABSPage As AbstractScreenBase = LoadControl(ScreenController.Screen_GetName(Author_SubmissionEntryAuthorInformation))
        ABSPage.ID = String.Concat("AuthorDetail_AddAuthor_TabContent")
        pnlAddAuthor.Controls.Add(ABSPage)
    End Sub

#End Region

#Region "Helper functions"

    Private Function GetAuthorEmailObject(ByVal AuthorId As Integer) As AbstractEmail
        Dim oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor = CallManager.GetAuthor(PortalId, AuthorId)

        If oAuthor IsNot Nothing Then
            Dim oEmail As New AbstractEmail
            oEmail.EmailName = String.Concat(oAuthor.FirstName, " ", oAuthor.LastName)
            oEmail.EmailAddress = oAuthor.EmailAddress
            Return oEmail
        End If

        Return Nothing
    End Function

    Private Sub SetupControls()
        Dim oAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors = CallManager.GetSubmission(PortalId, CType(GetAbsSubId(), Integer)).AbstractSubmissionAuthors

        _oWebAuthors = New List(Of WEB_SUBMISSIONAUTHOR)
        Dim oWebAuthor As WEB_SUBMISSIONAUTHOR
        Dim AuthorCounter As Integer = 0
        For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAuthors
            oWebAuthor = New WEB_SUBMISSIONAUTHOR
            With oWebAuthor
                .AbstractSubmissionAuthorId = oAuthor.AbstractSubmissionAuthorId
                .AuthorRoleCodeString = oAuthor.AuthorRoleCodeString
                .CompanyInstitutionName = oAuthor.CompanyInstitutionName
                .IsCustomer = IIf(oAuthor.MasterCustomerId Is Nothing, False, True)
                .LastFirstName = String.Concat(oAuthor.LastName, ", ", oAuthor.FirstName)
            End With
            _oWebAuthors.Add(oWebAuthor)
            AuthorCounter = AuthorCounter + 1
        Next

        lblNumberOfAuthors.Text = AuthorCounter
    End Sub

#End Region

#Region "Public Function"

#End Region

    Private Sub RadGridAuthors_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGridAuthors.NeedDataSource
        RadGridAuthors.DataSource = _oWebAuthors
    End Sub
End Class
