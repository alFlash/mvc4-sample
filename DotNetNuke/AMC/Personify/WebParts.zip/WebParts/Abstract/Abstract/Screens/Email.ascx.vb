Imports TIMSS.API.Core
Imports Personify.ApplicationManager.Commons
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic
Imports Telerik.Web.UI
Imports TIMSS.Server.BusinessMessages.EmailAndFax

Public Class Email
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private _EmailList As ArrayList
    Private _SingleEmail As Boolean
    Private _FromEmail As New AbstractEmail
#End Region

#Region "Controls"

    Protected WithEvents txtEmailFrom As RadTextBox
    Protected WithEvents txtEmailTo As RadTextBox
    Protected WithEvents txtEmailCC As RadTextBox
    Protected WithEvents txtEmailBCC As RadTextBox
    Protected WithEvents txtEmailSubject As RadTextBox
    Protected WithEvents RadEditorEmailBody As RadEditor
    Protected WithEvents btnSendEmail As Button
    Protected WithEvents btnBack As Button

#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        _EmailList = Session(Constants.Const_EmailListSessionName)
        _FromEmail.EmailName = System.Configuration.ConfigurationManager.AppSettings("AbstractFromName")
        _FromEmail.EmailAddress = System.Configuration.ConfigurationManager.AppSettings("AbstractFromEmail")

        'request.UrlReferrer.AbsoluteUri
        If ViewState("PrevURL") Is Nothing AndAlso Request.UrlReferrer IsNot Nothing Then
            ViewState("PrevURL") = Request.UrlReferrer.AbsoluteUri
        End If

        If Not Page.IsPostBack Then
            SetupControls()
        Else

        End If
    End Sub

    Private Sub btnSendEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click
        If _EmailList Is Nothing Then
            Exit Sub
        End If
        Try
            If Page.IsValid Then
                Dim arrEmail As Array
                Dim oEmail As New SendEmailRequest

                oEmail.From.Address = _FromEmail.EmailAddress
                oEmail.From.DisplayName = _FromEmail.EmailName
                oEmail.Body = RadEditorEmailBody.Text
                oEmail.Subject = txtEmailSubject.Text

                If _SingleEmail Then
                    oEmail.To.Add(CreateEmailObject(_EmailList(0)))
                    If txtEmailBCC.Text <> String.Empty Then
                        arrEmail = Split(txtEmailBCC.Text, ";")
                        For Each strEmail As String In arrEmail
                            If strEmail <> "" Then
                                oEmail.Bcc.Add(CreateEmailObject(strEmail))
                            End If
                        Next
                    End If
                Else
                    oEmail.To.Add(CreateEmailObject(_FromEmail))
                    For Each oAbsEmail As AbstractEmail In _EmailList
                        oEmail.Bcc.Add(CreateEmailObject(oAbsEmail))
                    Next
                End If

                If txtEmailCC.Text <> String.Empty Then
                    arrEmail = Split(txtEmailCC.Text, ";")
                    For Each strEmail As String In arrEmail
                        If strEmail <> "" Then
                            oEmail.Cc.Add(CreateEmailObject(strEmail))
                        End If
                    Next
                End If

                TIMSS.Global.App.CurrentDeliveryStrategy.ProcessSync(oEmail)
                ' completed
                'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("MessageSent", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Me.ShowPopupMessage("Email has been sent")

            End If
        Catch exc As System.Net.Mail.SmtpFailedRecipientException
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("UserDoesNotExists", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
        End Try
    End Sub

    Private Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        If ViewState("PrevURL") IsNot Nothing Then
            Response.Redirect(ViewState("PrevURL"), True)
        End If
    End Sub

#End Region

#Region "Helper functions"
    Private Sub SetupControls()
        If Session(Constants.Const_EmailListSessionName) Is Nothing Then
            Exit Sub
        End If               
        txtEmailFrom.Text = ConcatEmailDisplay(_FromEmail)
        If _EmailList.Count = 1 Then
            txtEmailTo.Text = ConcatEmailDisplay(_EmailList(0))
            _SingleEmail = True
        Else
            txtEmailTo.Text = ConcatEmailDisplay(_FromEmail)
            txtEmailBCC.Text = ConcatEmailAddress()
            txtEmailBCC.Enabled = False
            _SingleEmail = False
        End If
    End Sub

    Private Function ConcatEmailAddress() As String
        Dim EmailNameStr As String = Nothing
        For Each Email As AbstractEmail In _EmailList
            EmailNameStr = String.Concat(EmailNameStr, ConcatEmailDisplay(Email))
        Next
        Return EmailNameStr
    End Function

    Private Function ConcatEmailDisplay(ByVal AbsEmailAddress As AbstractEmail) As String
        If AbsEmailAddress.EmailAddress IsNot Nothing Then
            Return String.Concat(AbsEmailAddress.EmailName, " (", AbsEmailAddress.EmailAddress, ")", "; ")
        End If
        Return String.Empty

        End Function

    Private Function CreateEmailObject(ByVal AbsEmailAddress As AbstractEmail) As EmailAddress

        Dim oEmail As EmailAddress
        If AbsEmailAddress.EmailAddress IsNot Nothing Then
            oEmail = New EmailAddress(AbsEmailAddress.EmailAddress, AbsEmailAddress.EmailName)
        Else
            oEmail = New EmailAddress(String.Empty, AbsEmailAddress.EmailName)
        End If

        Return oEmail
    End Function

    Private Function CreateEmailObject(ByVal EmailStr As String) As EmailAddress
        Dim oEmail As New EmailAddress(EmailStr, EmailStr)
        Return oEmail
    End Function

#End Region

#Region "Public Function"

#End Region

End Class

