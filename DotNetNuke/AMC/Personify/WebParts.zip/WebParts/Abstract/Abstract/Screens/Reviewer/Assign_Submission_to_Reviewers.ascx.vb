Imports TIMSS.SQLObjects
Imports ScreenController.AbstractScreen

Public Class Assign_Submission_to_Reviewers
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected SubmissionTypeLabel As Label
    Protected SubmissionTitleLabel As Label
    Protected AbstractCallTitleLabel As Label
    Protected ExpertiseLevelLabel As Label
    Protected ReviewBlindRuleLabel As Label
    Protected SubmissionCategoryLabel As Label
    Protected SubmissionDateLabel As Label
    Protected SubmissionTopicLabel As Label

    Protected WithEvents TextBoxFirstName As TextBox
    Protected WithEvents TextBoxLastName As TextBox
    Protected WithEvents RadComboBoxAprovedFor As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxAreaOfExpertise As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxLevelOfExpertise As Telerik.Web.UI.RadComboBox
    Protected WithEvents LinkButtonClearSearch As LinkButton
    Protected WithEvents LinkButtonSearch As LinkButton
    Protected WithEvents RadGrid1 As Telerik.Web.UI.RadGrid
    Protected WithEvents LinkButtonAssignReviewers As LinkButton
    Protected WithEvents RadDatePickerSearch As Telerik.Web.UI.RadDatePicker
    Protected WithEvents SubmissionDetailsPanel As Panel

    Protected AbstractCallCode As HiddenField
    Protected SubmissionTypeCode As HiddenField

    Protected DefaultMaxReviewerAssignments As HiddenField
    Protected DefaultMaxReviewerOpenAssignments As HiddenField

    Private _SubmissionId As String = String.Empty
    Private _SubmissionIds() As Integer

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Request("sid") IsNot Nothing Then _SubmissionId = Request("sid")
        If Request("sids") IsNot Nothing Then _SubmissionIds = Session(Convert.ToString(Request("sids")))

        If String.IsNullOrEmpty(_SubmissionId) AndAlso (_SubmissionIds Is Nothing OrElse _SubmissionIds.Length = 0) Then
            ShowPopupMessage("Nothing selected")
            Exit Sub
        End If

        If Not Page.IsPostBack Then

            Dim sid As String = Nothing
            If Not String.IsNullOrEmpty(_SubmissionId) Then
                sid = _SubmissionId
            ElseIf _SubmissionIds IsNot Nothing AndAlso _SubmissionIds.Length = 1 Then
                sid = _SubmissionIds(0)
            End If

            If Not String.IsNullOrEmpty(sid) Then

                Dim Submissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
                Submissions = CallManager.GetAbstractSubmission(PortalId, sid)

                If Submissions IsNot Nothing AndAlso Submissions.Count Then

                    AbstractCallTitleLabel.Text = Submissions(0).AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title
                    ExpertiseLevelLabel.Text = Submissions(0).ExpertiseLevelCode.Description
                    ReviewBlindRuleLabel.Text = Submissions(0).AbstractCallSubmissionTypeInfo.ReviewBlindRuleCode.Description
                    SubmissionCategoryLabel.Text = Submissions(0).CategoryCode.Description
                    SubmissionDateLabel.Text = Submissions(0).SubmissionDate
                    SubmissionTitleLabel.Text = Submissions(0).Title

                    Dim SubmissionTopic As String = ""
                    If Submissions(0).AbstractSubmissionTopics IsNot Nothing AndAlso Submissions(0).AbstractSubmissionTopics.Count > 0 Then
                        For i As Integer = 0 To Submissions(0).AbstractSubmissionTopics.Count - 1
                            If i <> 0 Then SubmissionTopic += "; "
                            SubmissionTopic += Submissions(0).AbstractSubmissionTopics(i).TopicCode.Description
                        Next
                    End If
                    SubmissionTopicLabel.Text = SubmissionTopic
                    SubmissionTypeLabel.Text = Submissions(0).SubmissionTypeCode

                    AbstractCallCode.Value = Submissions(0).AbstractCallCode
                    SubmissionTypeCode.Value = Submissions(0).SubmissionTypeCode

                    DefaultMaxReviewerAssignments.Value = Submissions(0).AbstractCallSubmissionTypeInfo.DefaultMaxReviewerAssignments
                    DefaultMaxReviewerOpenAssignments.Value = Submissions(0).AbstractCallSubmissionTypeInfo.DefaultMaxReviewerOpenAssignments

                End If
            Else
                'hide info because is not only one
                SubmissionDetailsPanel.Visible = False
                AbstractCallCode.Value = Request("args")
                SubmissionTypeCode.Value = Request("type")

                Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes = _
                CallManager.ABSSubmissionType_Get(PortalId, AbstractCallCode.Value, SubmissionTypeCode.Value)
                If (oAbstractCallSubmissionTypes IsNot Nothing AndAlso oAbstractCallSubmissionTypes.Count = 1) Then
                    DefaultMaxReviewerAssignments.Value = oAbstractCallSubmissionTypes(0).DefaultMaxReviewerAssignments
                    DefaultMaxReviewerOpenAssignments.Value = oAbstractCallSubmissionTypes(0).DefaultMaxReviewerOpenAssignments
                Else
                    ShowPopupMessage("Parameters Missing")
                End If

            End If

            LoadControls()
        End If
    End Sub

    Protected Sub LinkButtonAssignReviewers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonAssignReviewers.Click

        Dim success As Boolean = True

        Dim ReviewersArray As New ArrayList
        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGrid1.SelectedItems
            Dim AbstractCallSubmissionTypeReviewerId As Integer = dataitem("AbstractCallSubmissionTypeReviewerId").Text
            ReviewersArray.Add(AbstractCallSubmissionTypeReviewerId)
        Next

        Dim Reviewers(ReviewersArray.Count - 1) As Integer
        ReviewersArray.CopyTo(Reviewers)

        If Reviewers IsNot Nothing AndAlso Reviewers.Length > 0 Then

            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = Nothing

            If Not String.IsNullOrEmpty(_SubmissionId) Then
                oIssues = CallManager.CreateSubmissionReviewers(PortalId, CInt(_SubmissionId), Reviewers)
                If oIssues IsNot Nothing Then success = False
            End If

            'change this to one call
            If _SubmissionIds IsNot Nothing AndAlso _SubmissionIds.Length > 0 Then
                'For Each aSubmissionId As Integer In _SubmissionIds
                '    oIssues = CallManager.CreateSubmissionReviewers(PortalId, aSubmissionId, Reviewers)
                '    If oIssues IsNot Nothing Then
                '        success = False
                '        Exit For
                '    End If
                'Next

                oIssues = CallManager.CreateSubmissionsReviewers(PortalId, _SubmissionIds, Reviewers)
                If oIssues IsNot Nothing Then success = False

            End If


            If oIssues Is Nothing AndAlso success = True Then
                Dim sid As String = Nothing
                If Not String.IsNullOrEmpty(_SubmissionId) Then
                    sid = _SubmissionId
                ElseIf _SubmissionIds IsNot Nothing AndAlso _SubmissionIds.Length = 1 Then
                    sid = _SubmissionIds(0)
                End If

                If sid IsNot Nothing Then
                    Response.Redirect(NavigateURL("", "s=" & ScreenController.AbstractScreen.Assign_Submission_to_Reviewers & "&sid=" & sid))
                Else
                    Me.GoToNextPage(Admin_SubmissionSearchList, "", "")
                End If
            Else
                ShowPopupMessage(oIssues)
            End If
        End If
    End Sub


    Protected Sub LinkButtonSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSearch.Click

        RadGrid1.DataSource = GetReviewersData()
        RadGrid1.DataBind()

        If GetReviewersData.Count > 0 Then
            LinkButtonAssignReviewers.Visible = True
        Else
            LinkButtonAssignReviewers.Visible = False
        End If
    End Sub


    Protected Sub LinkButtonClearSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonClearSearch.Click
        TextBoxFirstName.Text = ""
        TextBoxLastName.Text = ""
        RadDatePickerSearch.SelectedDate = DateTime.Now.AddMonths(12)
        RadComboBoxAprovedFor.SelectedIndex = 0
        RadComboBoxAreaOfExpertise.SelectedIndex = 0
        RadComboBoxLevelOfExpertise.SelectedIndex = 0
    End Sub


#End Region


#Region "Helper functions"

    Public Sub LoadControls()

        RadDatePickerSearch.SelectedDate = DateTime.Now.AddMonths(12)

        Dim Expertises As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                     GetApplicationCodes("ABS", "EXPERTISE", True)
        If Expertises IsNot Nothing AndAlso Expertises.Count > 0 Then

            RadComboBoxAreaOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
            For Each Expertise As TIMSS.API.ApplicationInfo.IApplicationCode In Expertises
                RadComboBoxAreaOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem(Expertise.Description.ToString, Expertise.Code))
            Next
        End If

        Dim ExpertiseLevels As TIMSS.API.ApplicationInfo.IApplicationCodes = _
            GetApplicationCodes("ABS", "EXPERTISE_LEVEL", True)
        If ExpertiseLevels IsNot Nothing AndAlso ExpertiseLevels.Count > 0 Then

            RadComboBoxLevelOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
            For Each ExpertiseLevel As TIMSS.API.ApplicationInfo.IApplicationCode In ExpertiseLevels
                RadComboBoxLevelOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem(ExpertiseLevel.Description.ToString, ExpertiseLevel.Code))
            Next
        End If

        Dim AprovedFors As TIMSS.API.ApplicationInfo.IApplicationCodes = _
            GetApplicationCodes("ABS", "REVIEWER_APPROVED_FOR", True)
        If AprovedFors IsNot Nothing AndAlso AprovedFors.Count > 0 Then
            RadComboBoxAprovedFor.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
            For Each AprovedFor As TIMSS.API.ApplicationInfo.IApplicationCode In AprovedFors
                RadComboBoxAprovedFor.Items.Add(New Telerik.Web.UI.RadComboBoxItem(AprovedFor.Description.ToString, AprovedFor.Code))
            Next
        End If
    End Sub

    Public Function GetReviewersData() As ICollection
        Dim list As ArrayList = New ArrayList()

        Dim oAbstractReviewers As IQueryResult
        If RadDatePickerSearch.SelectedDate.HasValue Then
            oAbstractReviewers = CallManager.GetSubmissionReviewersSearch(PortalId, AbstractCallCode.Value, SubmissionTypeCode.Value, TextBoxFirstName.Text, TextBoxLastName.Text, RadComboBoxAprovedFor.SelectedValue, RadComboBoxAreaOfExpertise.SelectedValue, RadComboBoxLevelOfExpertise.SelectedValue, RadDatePickerSearch.SelectedDate, Convert.ToInt32(DefaultMaxReviewerAssignments.Value), Convert.ToInt32(DefaultMaxReviewerOpenAssignments.Value))
        Else
            oAbstractReviewers = CallManager.GetSubmissionReviewersSearch(PortalId, AbstractCallCode.Value, SubmissionTypeCode.Value, TextBoxFirstName.Text, TextBoxLastName.Text, RadComboBoxAprovedFor.SelectedValue, RadComboBoxAreaOfExpertise.SelectedValue, RadComboBoxLevelOfExpertise.SelectedValue, Nothing, Convert.ToInt32(DefaultMaxReviewerAssignments.Value), Convert.ToInt32(DefaultMaxReviewerOpenAssignments.Value))
        End If
        
        If oAbstractReviewers.Success = False OrElse Not oAbstractReviewers.ValidationMessages.Count > 0 Then

            If oAbstractReviewers IsNot Nothing AndAlso oAbstractReviewers.DataSet IsNot Nothing AndAlso oAbstractReviewers.DataSet.Tables IsNot Nothing AndAlso oAbstractReviewers.DataSet.Tables.Count > 0 AndAlso oAbstractReviewers.DataSet.Tables(0).Rows IsNot Nothing AndAlso oAbstractReviewers.DataSet.Tables(0).Rows.Count > 0 Then

                Dim Expertise As String = ""
                Dim LevelOfExpertise As String = ""
                For i As Integer = 0 To oAbstractReviewers.DataSet.Tables(0).Rows.Count - 1

                    Dim includeRow As Boolean = True
                    If i < oAbstractReviewers.DataSet.Tables(0).Rows.Count - 1 Then

                        Dim currentMasterCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i)("master_customer_id")
                        Dim currentSubCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i)("sub_customer_id")

                        Dim nextMasterCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i + 1)("master_customer_id")
                        Dim nextSubCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i + 1)("sub_customer_id")

                        If currentMasterCustomerId = nextMasterCustomerId AndAlso currentSubCustomerId = nextSubCustomerId Then
                            includeRow = False
                            Expertise += oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_code") + " - " + oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_subcode") + "<BR>"
                            LevelOfExpertise += Convert.ToString(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_level_code")) + "<BR>"
                        End If

                    End If
                    If includeRow = True Then

                        Dim row As ReviewerSearchData = New ReviewerSearchData()

                        row.MasterCustomerId = oAbstractReviewers.DataSet.Tables(0).Rows(i)("master_customer_id")
                        row.SubCustomerId = oAbstractReviewers.DataSet.Tables(0).Rows(i)("sub_customer_id")
                        row.AbstractCallSubmissionTypeReviewerId = oAbstractReviewers.DataSet.Tables(0).Rows(i)("abs_call_submission_type_reviewer_id")
                        row.Name = oAbstractReviewers.DataSet.Tables(0).Rows(i)("last_first_name")
                        row.Link = NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_Work_with_Reviewer & "&mcid=" & row.MasterCustomerId.ToString & "&scid=" & row.SubCustomerId.ToString)

                        'If oCustomers.DataSet.Tables(0).Columns.IndexOf("Institution") >= 0 Then
                        If Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("Institution")) Then
                            row.Institution = Convert.ToString(oAbstractReviewers.DataSet.Tables(0).Rows(i)("Institution"))
                        End If

                        'row.AverageScore = "no idea" ' not anymore
                        'row.Completed = "no idea"
                        If Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_code")) AndAlso Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_subcode")) Then
                            row.Expertise = Expertise + oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_code") + " - " + _
                            oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_subcode")
                        End If

                        If Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_level_code")) Then
                            row.LevelOfExpertise = LevelOfExpertise + Convert.ToString(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_level_code"))
                        End If

                        'row.OpenReviews = "no idea"

                        row.NumberOfAssignments = Convert.ToInt32(oAbstractReviewers.DataSet.Tables(0).Rows(i)("number_of_assignments"))
                        row.NumberOfOpenAssignments = Convert.ToInt32(oAbstractReviewers.DataSet.Tables(0).Rows(i)("number_of_open_assignments"))

                        list.Add(row)
                        Expertise = ""
                        LevelOfExpertise = ""
                    End If
                Next
            End If
        End If
        Return list

    End Function
#End Region

   

   


End Class
