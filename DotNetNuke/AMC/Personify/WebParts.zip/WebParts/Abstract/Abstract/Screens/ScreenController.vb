Public Class ScreenController
    'Todo: Create a link list for page workflow ?


#Region "Screen Name"

    Public Shared Function Screen_GetName(ByVal ScreenId As String) As String

        Dim controlName As String = Nothing
        Dim NameId As Integer

        NameId = CInt(ScreenId) 'todo: need to catch this exception and either ignore or present error page
        
        Select Case NameId
            'Administrator
            Case AbstractScreen.HomePage
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Homepage.ascx"
            Case AbstractScreen.Admin_DefineCallParticipation
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/DefineCallParticipation.ascx"
            Case AbstractScreen.Admin_SubmissionTypeSetup
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/SubmissionTypeSetup.ascx"
            Case AbstractScreen.Admin_AuthorRequirements
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/AuthorRequirements.ascx"
            Case AbstractScreen.Reviewer_Inbox
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Reviewer_Inbox.ascx"
            Case AbstractScreen.Reviewer_Inbox
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Reviewer_Inbox.ascx"
            Case AbstractScreen.Reviewer_Invitation
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Reviewer_Invitation.ascx"
            Case AbstractScreen.Reviewer_ReviewSubmission
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Review_Submission.ascx"
            Case AbstractScreen.Reviewer_Search
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Reviewer_Search.ascx"
            Case AbstractScreen.Reviewer_Work_with_Reviewer
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Work_with_Reviewer.ascx"
            Case AbstractScreen.Assign_Submission_to_Reviewers
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Assign_Submission_to_Reviewers.ascx"
            Case AbstractScreen.Assign_Reviewer_to_Submission
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Assign_Reviewer_to_Submission.ascx"
            Case AbstractScreen.Assign_Submission_to_Product
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Reviewer/Assign_Submission_to_Product.ascx"
            Case AbstractScreen.Start_Submission_Demo
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/Start_Submission_Demo.ascx"
            Case AbstractScreen.Author_MySubmissions
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/MySubmissions.ascx"
            Case AbstractScreen.Author_SubmissionEntryGeneralInformation
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/SubmissionEntryGeneralInformation.ascx"
            Case AbstractScreen.Author_SubmissionEntryAuthorInformation
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/SubmissionEntryAuthorInformation.ascx"
            Case AbstractScreen.Author_SubmissionEntryContent
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/SubmissionEntryContent.ascx"
            Case AbstractScreen.Author_SubmissionEntryConfirmation
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/SubmissionEntryConfirmation.ascx"
            Case AbstractScreen.Author_Search
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/Author_Search.ascx"
            Case AbstractScreen.Author_Work_with_Author
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Author/Author_Work_with_Author.ascx"
            Case AbstractScreen.Admin_MaterialsRequirements
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/MaterialRequirements.ascx"
            Case AbstractScreen.Admin_ReviewProcess
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/ReviewProcess.ascx"
            Case AbstractScreen.Admin_SubmissionTypeUpdate
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmissionType/SubmissionTypeMain.ascx"
            Case AbstractScreen.Admin_SubmissionSearchList
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmission/SubmissionSearchList.ascx"
            Case AbstractScreen.Admin_SubmissionDetails
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmission/SubmissionDetails.ascx"
            Case AbstractScreen.Admin_DisclosureDetails
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmission/DisclosureDetails.ascx"
            Case AbstractScreen.Admin_AuthorDetails
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmission/AuthorDetails.ascx"
            Case AbstractScreen.Admin_SubmissionHistory
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmission/SubmissionHistory.ascx"
            Case AbstractScreen.Admin_SubmissionReviews
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmission/SubmissionReviews.ascx"
            Case AbstractScreen.Admin_SubmissionTextBlock
                controlName = "~/DesktopModules/Personify - Abstract/Controls/Author/SubmissionTextBlocks.ascx"
            Case AbstractScreen.Admin_SubmissionAttachment
                controlName = "~/DesktopModules/Personify - Abstract/Controls/Author/SubmissionAttachments.ascx"
            Case AbstractScreen.Admin_Email
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Email.ascx"
            Case AbstractScreen.Admin_SubmissionTypeReviewers
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageSubmissionType/SubmissionTypeReviewer.ascx"
            Case AbstractScreen.TestPage
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/t1.ascx"
            Case AbstractScreen.BlankPage
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Administrator/ManageCall/BlankPage.ascx"
            Case Nothing
                'Default to homepage
                controlName = "~/DesktopModules/Personify - Abstract/Screens/Homepage.ascx"
            Case Else
                'Todo: mabye we'll load an error page here
        End Select

        Return controlName

    End Function

    Public Shared Function Screen_GetName(ByVal ScreenId As AbstractScreen) As String

        Dim controlName As String = Nothing
        Dim NameId As Integer = CInt(ScreenId) 'todo: need to catch this exception and either ignore or present error page

        Return Screen_GetName(NameId.ToString)

    End Function


    Public Shared Function Screen_RequiredAccessCheck(ByVal ScreenId As AbstractScreen) As ABS_Security_Role

        Select Case ScreenId
            Case AbstractScreen.Admin_DefineCallParticipation
                Return ABS_Security_Role.Admin

            Case AbstractScreen.Admin_AuthorRequirements
                Return ABS_Security_Role.SubTypeStaff_Specific
            Case AbstractScreen.Admin_MaterialsRequirements
                Return ABS_Security_Role.SubTypeStaff_Specific
            Case AbstractScreen.Admin_ReviewProcess
                Return ABS_Security_Role.SubTypeStaff_Specific
            Case AbstractScreen.Admin_SubmissionTypeSetup
                Return ABS_Security_Role.SubTypeStaff_Specific
            Case AbstractScreen.Admin_SubmissionTypeUpdate
                Return ABS_Security_Role.SubTypeStaff_Specific

            Case AbstractScreen.Admin_SubmissionSearchList
                Return ABS_Security_Role.SubTypeStaff_General
                'To do: need to include other sub type pages (staff)
            Case Else
                Return ABS_Security_Role.ALL
        End Select

    End Function

    Public Enum AbstractScreen
        'Admin
        Admin_DefineCallParticipation = 300
        Admin_SubmissionTypeSetup = 1
        Admin_AuthorRequirements = 2
        Admin_MaterialsRequirements = 99
        Admin_ReviewProcess = 98
        Admin_SubmissionTypeUpdate = 97
        Admin_SubmissionSearchList = 200
        Admin_SubmissionDetails = 201
        Admin_SubmissionTextBlock = 202
        Admin_SubmissionAttachment = 203
        Admin_DisclosureDetails = 204
        Admin_AuthorDetails = 205
        Admin_SubmissionHistory = 206
        Admin_SubmissionReviews = 207
        Admin_Email = 400
        Admin_SubmissionTypeReviewers = 208
        TestPage = 999

        'Reviewer
        Reviewer_Inbox = 3
        Reviewer_Invitation = 5
        Reviewer_ReviewSubmission = 7
        Reviewer_Search = 9
        Reviewer_Work_with_Reviewer = 11
        Assign_Submission_to_Reviewers = 13
        Assign_Submission_to_Product = 15
        Assign_Reviewer_to_Submission = 17
        'Author
        Author_MySubmissions = 20
        Author_SubmissionEntryGeneralInformation = 21
        Author_SubmissionEntryAuthorInformation = 22
        Author_SubmissionEntryContent = 23
        Author_SubmissionEntryConfirmation = 24
        Author_Search = 25
        Author_Work_with_Author = 26

        Start_Submission_Demo = 33

        HomePage = 0
        BlankPage = 888

    End Enum


    Public Enum ABS_Security_Role
        Admin
        SubTypeStaff_General
        SubTypeStaff_Specific
        ALL
    End Enum
#End Region

End Class


#Region "removed code"
'Public Shared Function GetAbstractScreenName(ByVal screenName As AbstractScreen, ByVal args As String, ByVal action As String) As String
'    'ToDo: display list of screen and return the control back

'    Dim controlName As String = GetScreenName(screenName)

'    Return AbstractScreen.Admin_DefineCallParticipation
'    Else
'    Return AbstractScreen.Admin_SubmissionTypeSetup
'    End If
'End Function

'Public Shared Function ConstructAbstractParameter(ByVal name As String, ByVal args As String, Optional ByVal action As String = "", Optional ByVal type As String = "") As AbstactParameters
'    Dim abstractPara As New AbstactParameters(name, action, args)
'    Return abstractPara
'End Function

'Public Shared Function ConstructAbstractQueryStringParameter(ByVal name As String, ByVal args As String, Optional ByVal action As String = "", Optional ByVal type As String = "") As String

'    Dim t As String = NavigateURL()
'    Dim ta(3) As String

'    ta(0) = "test"

'    t = NavigateURL("test", ta)
'    t = NavigateURL(1, ta)
'    t = NavigateURL(1, "test", ta)

'    Return ""
'End Function

''Public Class AbstractScreen

''    Public Const Admin_DefineCallParticipation As String = "~/DesktopModules/Abstract/Screens/Administrator/ManageCall/DefineCallParticipation.ascx"
''    Public Const Admin_SubmissionTypeSetup As String = "~/DesktopModules/Abstract/Screens/Administrator/ManageCall/SubmissionTypeSetup.ascx"


''End Class



''Public Class AbstactParameters
''    Private _Action As String 'screentype
''    Private _Arguments As String
''    Private _Name As String
''    'Public CustomParameters() As String

''#Region "Properties"

''    Public ReadOnly Property ScreenType() As String
''        Get
''            Return _Action
''        End Get
''    End Property

''    Public ReadOnly Property Arguments() As String
''        Get
''            Return _Arguments
''        End Get
''    End Property

''    Public ReadOnly Property Name() As String
''        Get
''            Return _Name
''        End Get
''    End Property


''#End Region

''    Public Sub New(ByVal Name As String, ByVal screenAction As String, ByVal args As String)
''        _Name = Name
''        _Action = screenAction
''        _Arguments = args
''    End Sub

''End Class


#End Region
