Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI
Imports TIMSS.API.Core
Imports System.Data
Imports System.Collections.Generic
Imports Personify.ApplicationManager.PErsonifyEnumerations


Namespace Personify.DNN.Modules.Homepage

    Public Class Homepage
        Inherits AbstractScreenBase

#Region "Controls"
        Protected WithEvents RadGridCalls As RadGrid
        Protected WithEvents btnNewSubmission As Button
        Protected WithEvents lblSubmissionDate As Label
        Protected WithEvents lblReviewProcessEnds As Label

        Protected WithEvents lblReviewProcessEnds1 As DataGrid
        Protected WithEvents btnGo As Button
        Protected WithEvents btnExpand As Button
        Protected WithEvents ctlReviewerInbox As ReviewerInboxControl
        Protected WithEvents ctlAuthorSubmissions As AuthorSubmissions
        Protected WithEvents pnlCalls As Panel
        'Protected WithEvents lblLoginCustomer As Label
        Private dtblSubmissionTypeStaff As DataTable
        Protected WithEvents rdbOpen As RadioButton
        Protected WithEvents rdbClosed As RadioButton
        Protected WithEvents rdbAll As RadioButton

        Protected WithEvents tblReviewer As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents RadGridAuthorSubmissions As RadGrid
#End Region

#Region "Private"

        Public ReadOnly Property TestPerf() As Boolean
            Get
                If Request("TestPerf") IsNot Nothing Then
                    Return True
                End If
            End Get

        End Property

        Private _oAbstractCalls As TIMSS.API.AbstractInfo.IAbstractCalls
        Private _TableAbstractCalls As DataTable
        Private _DatasourceList As Generic.List(Of AuthorSubmission)

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If HasAdminAccess() Then
                    LoadABSCalls()
                Else
                    If GetSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer) IsNot Nothing Then
                        dtblSubmissionTypeStaff = GetSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer)
                    Else
                        dtblSubmissionTypeStaff = Me.ABS_AccessControl_IsSubmissionTypeStaff_GetTable(MasterCustomerId, SubCustomerId, Nothing, Nothing)
                        AddSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer, dtblSubmissionTypeStaff)
                    End If
                    If dtblSubmissionTypeStaff IsNot Nothing AndAlso dtblSubmissionTypeStaff.Rows.Count > 0 Then
                        LoadABSCalls()
                    End If
                End If


                If ABS_AcessControl_IsReviewer(MasterCustomerId, SubCustomerId) Then
                    With ctlReviewerInbox
                        .PortalId = PortalId
                        .MasterCustomerId = MasterCustomerId
                        .SubCustomerId = SubCustomerId
                        .isCOMPLETED = False
                    End With
                Else
                    tblReviewer.Visible = False
                End If

                'With ctlAuthorSubmissions
                '.PortalId = PortalId
                '.MasterCustomerId = MasterCustomerId
                '.SubCustomerId = SubCustomerId
                '.IsClosed = False
                'End With
                LoadAuthorSubmissions()

                If RadGridAuthorSubmissions IsNot Nothing Then
                    RadGridAuthorSubmissions.Rebind()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub RadGridAuthorSubmissions_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGridAuthorSubmissions.NeedDataSource
            RadGridAuthorSubmissions.DataSource = _DatasourceList
        End Sub

#End Region

#Region "Optional Interfaces"
        'Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        '    Get
        '        Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
        '        Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
        '        Return Actions
        '    End Get
        'End Property

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
        '    ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
        '    ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        'End Sub

        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
        '    ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        'End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Helper functions"

        Private Sub LoadAuthorSubmissions()

            _DatasourceList = New Generic.List(Of AuthorSubmission)

            Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
            Dim oAbstractAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
            oAbstractAuthors = CallManager.GetAuthorSubmissions(PortalId, MasterCustomerId, SubCustomerId)

            For Each oAbstractSubmissionAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAbstractAuthors
                Dim navigateURL As String = String.Empty

                With oAbstractSubmissionAuthor

                    'If .AbstractSubmissionInfo.ExternalStatusCodeString = "DRAFT" Or .AbstractSubmissionInfo.InternalStatusCodeString = "NEED_AUTHOR_CHANGES" Then
                    'navigateURL = GetNextPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryGeneralInformation, GetArgs, CInt(.AbstractSubmissionId), GetSubType)
                    'Else

                    navigateURL = GetAuthorNextPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryConfirmation, .AbstractSubmissionInfo.AbstractCallCode, CType(.AbstractSubmissionId, Long), .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCode.Code, "View")

                    Dim oAbstractSubmissionTemp As New AuthorSubmission(.AbstractSubmissionId, .AbstractSubmissionInfo.Title, .AuthorRoleCode.Description, .AbstractSubmissionInfo.ExternalStatusCode.Description, navigateURL, .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCode.Description, .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title)
                  
                    Dim submissionTypeEndDate As Date
                    submissionTypeEndDate = .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeEndDate

                    If PersonifyWebCommon.isNullDate(submissionTypeEndDate) OrElse submissionTypeEndDate >= Date.Now Then
                        _DatasourceList.Add(oAbstractSubmissionTemp)
                    End If

                End With

            Next

        End Sub

        Public Function GetAuthorNextPageURL(ByVal screenId As ScreenController.AbstractScreen, ByVal args As String, ByVal SubmissionId As Long, Optional ByVal type As String = Nothing, Optional ByVal mode As String = Nothing) As String

            Dim strURLBuilder As New System.Text.StringBuilder
            strURLBuilder.Append("s=")
            strURLBuilder.Append(screenId)
            If SubmissionId > 0 Then
                strURLBuilder.Append("&sid=")
                strURLBuilder.Append(SubmissionId)
            End If
            If Not String.IsNullOrEmpty(args) Then
                strURLBuilder.Append("&args=")
                strURLBuilder.Append(args)
            End If
            If type IsNot Nothing AndAlso Not String.IsNullOrEmpty(type) Then
                strURLBuilder.Append("&type=")
                strURLBuilder.Append(type)
            End If
            If mode IsNot Nothing AndAlso Not String.IsNullOrEmpty(mode) Then
                strURLBuilder.Append("&mode=")
                strURLBuilder.Append(mode)
            End If

            Return NavigateURL("", strURLBuilder.ToString)
        End Function
#End Region

        Private Sub rdbOpen_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbOpen.CheckedChanged
            'LoadABSCalls()
            Me.RadGridCalls.Rebind()
            btnExpand.Text = "Expand All"
        End Sub

        Private Sub rdbClosed_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbClosed.CheckedChanged
            'LoadABSCalls()
            Me.RadGridCalls.Rebind()
            btnExpand.Text = "Expand All"
        End Sub

        Private Sub rdbAll_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbAll.CheckedChanged
            'LoadABSCalls()
            Me.RadGridCalls.Rebind()
            btnExpand.Text = "Expand All"
        End Sub
        Private Sub btnExpand_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExpand.Click
            If btnExpand.Text = "Expand All" Then
                CollapseExpandAll("EXPAND")
                btnExpand.Text = "Collapse All"
            Else
                CollapseExpandAll("COLLAPSE")
                btnExpand.Text = "Expand All"
            End If
        End Sub

        Private Function HasAccess(ByVal strCallCode As String, ByVal strSubmissionType As String) As Boolean
            Dim dvSubmissionTypeStaff As DataView = Nothing
            Dim blnHasAccess As Boolean

            If HasAdminAccess() Then
                Return True
            End If

            If GetSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer) IsNot Nothing Then
                dtblSubmissionTypeStaff = GetSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer)
            End If

           If dtblSubmissionTypeStaff IsNot Nothing Then
                dvSubmissionTypeStaff = dtblSubmissionTypeStaff.DefaultView
                If Not String.IsNullOrEmpty(strCallCode) AndAlso Not String.IsNullOrEmpty(strSubmissionType) Then
                    dvSubmissionTypeStaff.RowFilter = String.Concat("AbstractCallCode = '", strCallCode, "' and SubmissionTypeCode = '", strSubmissionType, "'")
                ElseIf Not String.IsNullOrEmpty(strCallCode) Then
                    dvSubmissionTypeStaff.RowFilter = String.Concat("AbstractCallCode = '", strCallCode, "'")
                End If
                blnHasAccess = dvSubmissionTypeStaff.Count > 0
            End If
            Return blnHasAccess
        End Function

        Private Sub LoadABSCalls()


            Dim strCallToExpand As String = Nothing
            Dim strCallStatus As String = String.Empty
            _TableAbstractCalls = CreateCallTable()
            Dim rowCall As System.Data.DataRow
            If rdbOpen.Checked Then
                strCallStatus = "Y"
            ElseIf rdbClosed.Checked Then
                strCallStatus = "N"
            End If
            _oAbstractCalls = CallManager.ABSALLCALLS_GET(PortalId, strCallStatus)
            For Each oCall As TIMSS.API.AbstractInfo.IAbstractCall In _oAbstractCalls
                'Check if the logged in user has access to view the page
                If HasAccess(oCall.AbstractCallCode, String.Empty) Then
                    pnlCalls.Visible = True
                    'Set the last call added as the Call to Expand (1st One, as the list is Sorted)
                    If String.IsNullOrEmpty(strCallToExpand) Then
                        strCallToExpand = oCall.Title
                    End If
                    rowCall = _TableAbstractCalls.NewRow
                    rowCall.Item("CallCode") = oCall.AbstractCallCode
                    rowCall.Item("CallType") = oCall.CallTypeCodeString
                    rowCall.Item("CallDescription") = oCall.Description
                    rowCall.Item("CallTitle") = oCall.Title
                    If oCall.ProductInfo Is Nothing Then
                        rowCall.Item("ProductLink") = ""
                    Else
                        rowCall.Item("ProductLink") = oCall.ProductInfo.ShortName
                    End If
                    _TableAbstractCalls.Rows.Add(rowCall)
                End If
            Next
            ' RadGridCalls.DataSource = tblCalls
            'RadGridCalls.DataBind()
            'If Request.QueryString("Expand") = "TRUE" Then
            '    CollapseExpandAll("EXPAND")
            'ElseIf Request.QueryString("Expand") = "FALSE" Then
            '    CollapseExpandAll("COLLAPSE")
            'Else
            '    CollapseExpandAll(String.Empty, strCallToExpand)
            'End If
        End Sub

        Private Function LoadABSCallSubtypes(ByVal strCallCode As String) As DataTable

            Dim oCall As TIMSS.API.AbstractInfo.IAbstractCall
            Dim strStaff As System.Text.StringBuilder
            Dim tblCallSubTypes As DataTable = New DataTable()
            tblCallSubTypes = CreateCallSubtypeTable()
            Dim rowCallSubType As System.Data.DataRow

            oCall = _oAbstractCalls.FindObject("AbstractCallCode", strCallCode)
            strStaff = New System.Text.StringBuilder

            If oCall.AbstractCallSubmissionTypes.Count > 0 Then
                For Each oCallSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType In oCall.AbstractCallSubmissionTypes
                    If HasAccess(oCall.AbstractCallCode, oCallSubType.SubmissionTypeCode.Code) Then
                        strStaff.Remove(0, strStaff.Length)
                        rowCallSubType = tblCallSubTypes.NewRow
                        rowCallSubType.Item("AbstractCallCode") = oCallSubType.AbstractCallCode
                        rowCallSubType.Item("CallSubTypeCode") = oCallSubType.SubmissionTypeCode.Code
                        rowCallSubType.Item("CallSubTypeDescr") = oCallSubType.Description
                        If oCallSubType.SubmissionTypeEndDate <> DateTime.MinValue Then
                            rowCallSubType.Item("SubmissionDue") = oCallSubType.SubmissionTypeEndDate.ToShortDateString
                        Else
                            rowCallSubType.Item("SubmissionDue") = Constants.Const_Not_Applicable
                        End If
                        If oCallSubType.FinalReviewDate <> DateTime.MinValue Then
                            rowCallSubType.Item("ReviewProcessEnds") = oCallSubType.FinalReviewDate.ToShortDateString
                        Else
                            rowCallSubType.Item("ReviewProcessEnds") = Constants.Const_Not_Applicable
                        End If
                        rowCallSubType.Item("NumberofSubmissions") = oCallSubType.TotalSubmissions
                        rowCallSubType.Item("SubmissionsNeedingAction") = oCallSubType.TotalSubmissionsNeedStaffAction
                        rowCallSubType.Item("AvailableReviewers") = 0
                        rowCallSubType.Item("ReviewsCompleted") = oCallSubType.TotalSubmissionsAwaitingFinalDecision
                        rowCallSubType.Item("UnAssignedSubmissions") = oCallSubType.TotalSubmissionsUnassigned
                        'To do: RTW need to do finalist check

                        rowCallSubType.Item("Staff") = oCallSubType.StaffNamesAndRoles()
                        tblCallSubTypes.Rows.Add(rowCallSubType)
                    End If
                Next
            End If

            Return tblCallSubTypes
        End Function

        Private Sub CollapseExpandAll(ByVal strExpand As String, Optional ByVal strCallToExpand As String = Nothing)
            Dim item As GridItem
            Dim blnFirstOne As Boolean = True
            For Each item In RadGridCalls.MasterTableView.Controls(0).Controls
                If TypeOf item Is GridGroupHeaderItem Then
                    If strExpand = "EXPAND" Then
                        item.Expanded = True
                    ElseIf strExpand = "COLLAPSE" Then
                        item.Expanded = False
                    ElseIf String.IsNullOrEmpty(strExpand) AndAlso item.Cells(1).Text = strCallToExpand Then
                        item.Expanded = True
                        blnFirstOne = False
                    Else
                        item.Expanded = False
                    End If
                End If
            Next item
        End Sub

        Protected Sub RadGridCalls_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridCalls.ItemDataBound
            Dim strHeaderText As String
            If TypeOf e.Item Is GridDataItem Then
                Dim item As GridDataItem = CType(e.Item, GridDataItem)
                Dim lblCallCode As Label = CType(item.FindControl("lblCallCode"), Label)
                Dim btnNewSubmission As Button = CType(item.FindControl("btnNewSubmission"), Button)
                Dim hlEditCallDetails As HyperLink = CType(item.FindControl("hlEditCallDetails"), HyperLink)
                Dim RadGridCallSubTypes As RadGrid = CType(item.FindControl("RadGridCallSubTypes"), RadGrid)
                If lblCallCode IsNot Nothing Then
                    If HasAdminAccess() Then
                        hlEditCallDetails.NavigateUrl = GetNextPageURL(Admin_DefineCallParticipation, lblCallCode.ToolTip.Trim, "EDIT", "")
                        hlEditCallDetails.Visible = True
                        btnNewSubmission.Visible = True
                    Else
                        hlEditCallDetails.Visible = False
                        btnNewSubmission.Visible = False
                    End If
                    RadGridCallSubTypes.DataSource = Nothing
                    If Not Me.TestPerf Then
                        RadGridCallSubTypes.DataSource = LoadABSCallSubtypes(lblCallCode.ToolTip.Trim)
                        RadGridCallSubTypes.DataBind()
                        If RadGridCallSubTypes.Items.Count > 0 Then
                            RadGridCallSubTypes.Visible = True
                        Else
                            RadGridCallSubTypes.Visible = False
                        End If
                    Else
                        RadGridCallSubTypes.Visible = False
                    End If
                End If
            ElseIf TypeOf e.Item Is GridGroupHeaderItem Then
                Dim item As GridGroupHeaderItem = CType(e.Item, GridGroupHeaderItem)
                Dim groupDataRow As DataRowView = CType(e.Item.DataItem, DataRowView)
                strHeaderText = groupDataRow("CallTitle").ToString()
                item.DataCell.Text = strHeaderText
            End If
        End Sub
        Protected Sub NewSubmissionType(ByVal sender As Object, ByVal e As EventArgs)
            Dim lblCallCode As Label
            btnNewSubmission = DirectCast(sender, Button)
            Dim dataItem As GridDataItem = DirectCast(btnNewSubmission.NamingContainer, GridDataItem)
            lblCallCode = DirectCast(dataItem.FindControl("lblCallCode"), Label)
            If lblCallCode IsNot Nothing Then
                GoToNextPage(Admin_SubmissionTypeSetup, lblCallCode.ToolTip.Trim, "", "")
            End If
        End Sub

        'Set the URL to Edit Submission Type
        Protected Sub SubmissionTypeUpdate(ByVal sender As Object, ByVal e As EventArgs)
            Dim hlnkCallSubType As HyperLink
            Dim lblAbstractCallCode As Label
            hlnkCallSubType = DirectCast(sender, HyperLink)
            Dim dataItem As GridDataItem = DirectCast(hlnkCallSubType.NamingContainer, GridDataItem)
            lblAbstractCallCode = DirectCast(dataItem.FindControl("lblAbstractCallCode"), Label)
            If lblAbstractCallCode IsNot Nothing AndAlso hlnkCallSubType IsNot Nothing Then
                hlnkCallSubType.NavigateUrl = GetNextPageURL(Admin_SubmissionTypeUpdate, lblAbstractCallCode.Text, "", hlnkCallSubType.Text)
                hlnkCallSubType.Text = "Edit"
            End If
        End Sub


        Private Function CreateCallTable() As DataTable
            Dim oTable As New System.Data.DataTable
            oTable.Columns.Add(New System.Data.DataColumn("CallCode", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("CallType", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("CallDescription", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("CallTitle", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("ProductLink", GetType(String)))
            Return oTable
        End Function

        Private Function CreateCallSubtypeTable() As DataTable
            Dim oTable As New System.Data.DataTable
            oTable.Columns.Add(New System.Data.DataColumn("AbstractCallCode", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("CallSubTypeCode", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("CallSubTypeDescr", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("SubmissionDue", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("ReviewProcessEnds", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("NumberofSubmissions", GetType(Integer)))
            oTable.Columns.Add(New System.Data.DataColumn("SubmissionsNeedingAction", GetType(Integer)))
            oTable.Columns.Add(New System.Data.DataColumn("UnAssignedSubmissions", GetType(Integer)))
            oTable.Columns.Add(New System.Data.DataColumn("AvailableReviewers", GetType(String)))
            oTable.Columns.Add(New System.Data.DataColumn("ReviewsCompleted", GetType(Integer)))
            oTable.Columns.Add(New System.Data.DataColumn("Staff", GetType(String)))
            Return oTable
        End Function

        Private Sub RadGridCalls_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGridCalls.NeedDataSource
            btnExpand.Text = "Expand All"
            Me.RadGridCalls.DataSource = _TableAbstractCalls
        End Sub

       
    End Class
End Namespace
