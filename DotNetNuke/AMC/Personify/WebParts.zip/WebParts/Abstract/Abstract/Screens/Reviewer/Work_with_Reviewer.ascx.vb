
Imports ScreenController.AbstractScreen

Public Class Work_with_Reviewer
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected LabelFullName As Label
    Protected LabelInstitution As Label
    Protected WithEvents CheckBoxConfidential As CheckBox
    Protected WithEvents CheckBoxPublish As CheckBox
    Protected WithEvents RadComboBoxState As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxStatus As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadGridShowAreasOfExpertise As Telerik.Web.UI.RadGrid
    Protected WithEvents RadGridAreaOfExpertise As Telerik.Web.UI.RadGrid
    Protected WithEvents RadGridAssigments As Telerik.Web.UI.RadGrid
    Protected WithEvents TextBoxAddress1 As TextBox
    Protected WithEvents TextBoxAddress2 As TextBox
    Protected WithEvents TextBoxCity As TextBox
    Protected WithEvents TextBoxEmail As TextBox
    Protected WithEvents TextBoxFirstName As TextBox
    Protected WithEvents TextBoxLastName As TextBox
    Protected WithEvents TextBoxMiddleName As TextBox
    Protected WithEvents TextBoxPhone As TextBox
    Protected WithEvents TextBoxZip As TextBox
    Protected WithEvents TextBoxInstitution As TextBox
    Protected WithEvents LinkButtonInsertAreasOfExpertise As LinkButton
    'Protected WithEvents LinkButtonSave As LinkButton

    Protected WithEvents RadGridOpenReviews As ReviewerInboxControl
    Protected WithEvents RadGridPreviousReviews As ReviewerInboxControl
    Protected WithEvents butInsertAreasOfExpertise As Button
    Protected WithEvents RadToolTip2 As Telerik.Web.UI.RadToolTip


#End Region


#Region "Events"

    Private _SubmissionReviewerId As Integer = 0
    Private _rid As New ReviewSubmissionData()
    Private _MasterCustomerId As String = Nothing
    Private _SubCustomerId As Integer = 0


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        _MasterCustomerId = Request("mcid")
        _SubCustomerId = Integer.Parse(Request("scid"))

        If _MasterCustomerId Is Nothing OrElse _MasterCustomerId.Length < 1 Then
            ShowPopupMessage("Nothing selected")
        Else

            If Not Page.IsPostBack Then
                Dim Reviewers As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers
                Reviewers = CallManager.GetAbstractCallSubmissionTypeReviewers(PortalId, _MasterCustomerId, _SubCustomerId)

                Dim Reviewer As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewer
                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                Dim oCustomer As TIMSS.API.CustomerInfo.ICustomer
                If Reviewers IsNot Nothing AndAlso Reviewers.Count > 0 Then
                    Reviewer = Reviewers(0)
                    oCustomer = Reviewer.CustomerInfo
                Else
                    'If s/he is not a reviewer get the Customer Info
                    oCustomers = CallManager.GetCustoemrInfo(PortalId, _MasterCustomerId, _SubCustomerId)
                    If oCustomers IsNot Nothing AndAlso oCustomers.Count > 0 Then
                        oCustomer = oCustomers(0)
                    End If
                End If

                If oCustomer IsNot Nothing Then
                    LabelFullName.Text = oCustomer.LabelName
                    TextBoxFirstName.Text = oCustomer.FirstName

                    TextBoxMiddleName.Text = oCustomer.MiddleName
                    TextBoxLastName.Text = oCustomer.LastName
                    TextBoxEmail.Text = oCustomer.PrimaryEmailAddress
                    TextBoxPhone.Text = oCustomer.PrimaryPhone
                    CheckBoxPublish.Checked = oCustomer.IncludeInDirectoryFlag

                    Dim Statuses As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                        GetApplicationCodes("CUS", "CUSTOMER_STATUS", False)
                    If Statuses IsNot Nothing AndAlso Statuses.Count > 0 Then
                        For Each Status As TIMSS.API.ApplicationInfo.IApplicationCode In Statuses
                            RadComboBoxStatus.Items.Add(New Telerik.Web.UI.RadComboBoxItem(Status.Description.ToString, Status.Code))
                        Next
                        RadComboBoxStatus.SelectedValue = oCustomer.CustomerStatusCodeString
                    End If


                    If oCustomer.PrimaryEmployer IsNot Nothing Then
                        LabelInstitution.Visible = True
                        LabelInstitution.Text = ", " + oCustomer.PrimaryEmployer.LabelName
                        TextBoxInstitution.Text = oCustomer.PrimaryEmployer.LabelName
                    Else
                        LabelInstitution.Visible = False
                    End If

                    If oCustomer.PrimaryAddress IsNot Nothing AndAlso oCustomer.PrimaryAddress.Address IsNot Nothing Then
                        TextBoxAddress1.Text = oCustomer.PrimaryAddress.Address.Address1
                        TextBoxAddress2.Text = oCustomer.PrimaryAddress.Address.Address2
                        TextBoxCity.Text = oCustomer.PrimaryAddress.Address.City
                        TextBoxZip.Text = oCustomer.PrimaryAddress.Address.PostalCode
                        If oCustomer.PrimaryAddress.Address.Details IsNot Nothing AndAlso oCustomer.PrimaryAddress.Address.Details.Count > 0 Then
                            CheckBoxConfidential.Checked = oCustomer.PrimaryAddress.Address.Details(0).DirectoryFlag
                        End If

                        'RTW Todo:
                        Dim States As TIMSS.API.ApplicationInfo.IApplicationStates
                        States = get_clsOrderCheckOutProcessHelper.GetApplicationStates("USA")
                        'GetApplicationStates(PortalId, "USA")
                        If States IsNot Nothing AndAlso States.Count > 0 Then
                            For Each State As TIMSS.API.ApplicationInfo.IApplicationState In States
                                RadComboBoxState.Items.Add(New Telerik.Web.UI.RadComboBoxItem(State.StateDescription.ToString, State.StateCode))
                            Next
                            RadComboBoxState.SelectedValue = oCustomer.PrimaryAddress.Address.State
                        End If
                    End If

                End If

                If Reviewer IsNot Nothing Then

                    If Reviewer.AbstractReviewerInfo IsNot Nothing AndAlso Reviewer.AbstractReviewerInfo.AbstractReviewerExpertiseList IsNot Nothing AndAlso Reviewer.AbstractReviewerInfo.AbstractReviewerExpertiseList.Count > 0 Then

                        Dim ExpertisesDT As DataTable = New DataTable()
                        ExpertisesDT.Columns.Add("AbstractReviewerExpertiseId", Type.GetType("System.String"))
                        ExpertisesDT.Columns.Add("ExpertiseCode", Type.GetType("System.String"))
                        ExpertisesDT.Columns.Add("ExpertiseSubcode", Type.GetType("System.String"))
                        ExpertisesDT.Columns.Add("ExpertiseLevelCode", Type.GetType("System.String"))

                        Dim row As DataRow
                        For Each AbstractReviewerExpertise As TIMSS.API.AbstractInfo.IAbstractReviewerExpertise In Reviewer.AbstractReviewerInfo.AbstractReviewerExpertiseList
                            row = ExpertisesDT.NewRow()
                            row("AbstractReviewerExpertiseId") = AbstractReviewerExpertise.AbstractReviewerExpertiseId
                            row("ExpertiseCode") = AbstractReviewerExpertise.ExpertiseCodeString
                            row("ExpertiseSubcode") = AbstractReviewerExpertise.ExpertiseSubcodeString
                            row("ExpertiseLevelCode") = AbstractReviewerExpertise.ExpertiseLevelCodeString
                            ExpertisesDT.Rows.Add(row)
                        Next
                        RadGridShowAreasOfExpertise.DataSource = ExpertisesDT
                        RadGridShowAreasOfExpertise.DataBind()

                    End If


                    Dim AssignmentsDT As DataTable = New DataTable()
                    AssignmentsDT.Columns.Add("SubmissionType", Type.GetType("System.String"))
                    AssignmentsDT.Columns.Add("Call", Type.GetType("System.String"))
                    Dim arow As DataRow
                    For Each Assignment As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewer In Reviewers
                        arow = AssignmentsDT.NewRow()
                        arow("SubmissionType") = Assignment.AbstractCallSubmissionTypeInfo.Description
                        arow("Call") = Assignment.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Description
                        AssignmentsDT.Rows.Add(arow)
                    Next
                    RadGridAssigments.DataSource = AssignmentsDT
                    RadGridAssigments.DataBind()



                    Dim ExpertisesDTAll As DataTable = New DataTable()
                    ExpertisesDTAll.Columns.Add("Area", Type.GetType("System.String"))
                    ExpertisesDTAll.Columns.Add("AreaCode", Type.GetType("System.String"))
                    ExpertisesDTAll.Columns.Add("AreaSubcode", Type.GetType("System.String"))

                    Dim rowAll As DataRow

                    Dim Expertises As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                                 GetApplicationCodes("ABS", "EXPERTISE", True)
                    If Expertises IsNot Nothing AndAlso Expertises.Count > 0 Then
                        For Each Expertise As TIMSS.API.ApplicationInfo.IApplicationCode In Expertises

                            For Each ExpertiseSubcode As TIMSS.API.ApplicationInfo.IApplicationSubcode In Expertise.Subcodes

                                rowAll = ExpertisesDTAll.NewRow()
                                rowAll("Area") = Expertise.Description + " - " + ExpertiseSubcode.Description
                                rowAll("AreaCode") = Expertise.Code
                                rowAll("AreaSubcode") = ExpertiseSubcode.Description
                                ExpertisesDTAll.Rows.Add(rowAll)
                            Next
                        Next

                    End If

                    RadGridAreaOfExpertise.DataSource = ExpertisesDTAll
                    RadGridAreaOfExpertise.DataBind()

                    'RadGridAreaOfExpertise.Height = 200

                    Dim ExpertiseLevels As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                        GetApplicationCodes("ABS", "EXPERTISE_LEVEL", True)
                    If ExpertiseLevels IsNot Nothing AndAlso ExpertiseLevels.Count > 0 Then
                        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGridAreaOfExpertise.Items
                            Dim DropDownLevel As DropDownList = dataitem.FindControl("DropDownLevel")
                            For Each ExpertiseLevel As TIMSS.API.ApplicationInfo.IApplicationCode In ExpertiseLevels
                                DropDownLevel.Items.Add(New ListItem(ExpertiseLevel.Description.ToString, ExpertiseLevel.Code))
                            Next

                            'select previous values
                            If Reviewer.AbstractReviewerInfo IsNot Nothing AndAlso Reviewer.AbstractReviewerInfo.AbstractReviewerExpertiseList IsNot Nothing Then
                                For Each AbstractReviewerExpertise As TIMSS.API.AbstractInfo.IAbstractReviewerExpertise In Reviewer.AbstractReviewerInfo.AbstractReviewerExpertiseList
                                    If String.Compare(AbstractReviewerExpertise.ExpertiseCodeString, dataitem.Item("AreaCode").Text, True) = 0 Then
                                        If String.Compare(AbstractReviewerExpertise.ExpertiseSubcodeString, dataitem.Item("AreaSubcode").Text, True) = 0 Then
                                            dataitem.Selected = True
                                            DropDownLevel.SelectedValue = AbstractReviewerExpertise.ExpertiseLevelCodeString
                                        End If
                                    End If
                                Next
                            End If
                        Next
                    End If

                    With RadGridOpenReviews
                        .PortalId = PortalId
                        .MasterCustomerId = _MasterCustomerId
                        .SubCustomerId = _SubCustomerId
                        .isCOMPLETED = False
                        .isReadOnly = True
                    End With
                    With RadGridPreviousReviews
                        .PortalId = PortalId
                        .MasterCustomerId = _MasterCustomerId
                        .SubCustomerId = _SubCustomerId
                        .isCOMPLETED = True
                        .isReadOnly = True
                    End With

                End If

            End If
        End If


    End Sub

    Protected Sub LinkButtonInsertAreasOfExpertise_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonInsertAreasOfExpertise.Click
        Dim AreaOfExpertises() As CallManagerHelper.AreaOfExpertise = Nothing
        Dim aoes As New ArrayList
        For Each aoedataitem As Telerik.Web.UI.GridDataItem In RadGridAreaOfExpertise.SelectedItems
            Dim aoe As New CallManagerHelper.AreaOfExpertise
            aoe.ExpertiseCode = aoedataitem.Item("AreaCode").Text
            aoe.ExpertiseSubcode = aoedataitem.Item("AreaSubcode").Text

            Dim DropDownLevel As DropDownList = aoedataitem.FindControl("DropDownLevel")
            aoe.ExpertiseLevelCode = DropDownLevel.SelectedValue
            aoes.Add(aoe)
        Next
        Dim AreaOfExpertisesTemp(aoes.Count - 1) As CallManagerHelper.AreaOfExpertise
        aoes.CopyTo(AreaOfExpertisesTemp)
        AreaOfExpertises = AreaOfExpertisesTemp

        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection

        oIssues = CallManager.UpdateAreasOfExpertise(PortalId, _MasterCustomerId, Convert.ToInt32(_SubCustomerId), AreaOfExpertises)
        If oIssues Is Nothing Then
            Response.Redirect(Request.Url.ToString)
        Else
            ShowPopupMessage(oIssues)
        End If

    End Sub

    Private Sub butInsertAreasOfExpertise_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butInsertAreasOfExpertise.Click
        'RadToolTip2.HideEvent = Telerik.Web.UI.ToolTipHideEvent.ManualClose
        RadToolTip2.Show()
    End Sub
#End Region


#Region "Helper functions"


#End Region





End Class

