
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports ScreenController
Imports ScreenController.AbstractScreen

Public Class SubmissionTypeMain
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This Call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method Call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()


        

    End Sub

#End Region

#Region "Variables & Properties"

    Protected WithEvents radTabMenu As RadTabStrip
    Protected WithEvents radMultiTabContent As RadMultiPage

    Protected WithEvents lblSubmissionDue As Label
    Protected WithEvents lblNumberSubmissions As Label
    Protected WithEvents lblUnAssignedSubmission As Label
    Protected WithEvents lblReviewProcessDate As Label
    Protected WithEvents lblSubmissionsNeedAction As Label
    Protected WithEvents lblReviewsCompleted As Label
    Protected WithEvents lblStaffList As Label
    Protected WithEvents lblTitlePage As Label
    Protected WithEvents lblSubmissionType As Label
    Protected WithEvents lblSetupCompleted As Label

    Private _newPageFlag As Boolean = False
#End Region


#Region "Helper functions"

    Private Sub SetupControls()
        'Default to Detail page tab



        If GetArgs() IsNot Nothing Then
            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            Dim absSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType

            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType) 'All submission types

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                absSubType = absSubTypes(0)

                lblSetupCompleted.Visible = Not absSubType.SetupCompletedFlag

                If Not PersonifyWebCommon.isNullDate(absSubType.WebSubmittalEndDate) Then
                    lblSubmissionDue.Text = absSubType.WebSubmittalEndDate.ToLongDateString
                Else
                    lblSubmissionDue.Text = Constants.Const_Not_Applicable
                End If

                If Not PersonifyWebCommon.isNullDate(absSubType.FinalReviewDate) Then
                    lblReviewProcessDate.Text = absSubType.FinalReviewDate.ToLongDateString
                Else
                    lblReviewProcessDate.Text = Constants.Const_Not_Applicable
                End If

                lblNumberSubmissions.Text = absSubType.TotalSubmissions
                lblUnAssignedSubmission.Text = absSubType.TotalSubmissionsUnassigned
                lblSubmissionsNeedAction.Text = absSubType.TotalSubmissionsNeedStaffAction
                lblReviewsCompleted.Text = absSubType.TotalSubmissionsAwaitingFinalDecision

                Dim strStaff As New System.Text.StringBuilder

                For Each oStaff As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaff In absSubType.AbstractCallSubmissionTypeStaffs
                    If strStaff.Length = 0 Then
                        strStaff.Append(oStaff.CustomerInfo.LabelName)
                        strStaff.Append(" - ")
                        strStaff.Append(oStaff.StaffRoleCode.Description)
                    Else
                        strStaff.Append(", ")
                        strStaff.Append(oStaff.CustomerInfo.LabelName)
                        strStaff.Append(" - ")
                        strStaff.Append(oStaff.StaffRoleCode.Description)
                    End If
                Next

                lblSubmissionType.Text = absSubType.SubmissionTypeCode.Description
                lblStaffList.Text = strStaff.ToString
                lblTitlePage.Text = lblTitlePage.Text.Replace("{0}", absSubType.AbstractCallInfo.Title)
            End If

        End If


        AddPageView("PVDetail")
    End Sub

    Private Function AddPageView(ByVal pageViewID As String) As String
        Dim pageView As New RadPageView()
        pageView.ID = pageViewID
        _newPageFlag = True
        Me.radMultiTabContent.PageViews.Add(pageView)
        radMultiTabContent.SelectedIndex = radMultiTabContent.PageViews.Count - 1
        Return pageViewID
    End Function

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            'Todo: should we check if querystring is valid(?) If not valid - hide the page
            SetupControls()

        End If
    End Sub

    Protected Sub radTabMenu_TabClick(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadTabStripEventArgs) Handles radTabMenu.TabClick

        e.Tab.PageViewID = AddPageView(e.Tab.PageViewID)
        e.Tab.PageView.Selected = True
    End Sub



#End Region


    Private Sub radMultiTabContent_PageViewCreated(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadMultiPageEventArgs) Handles radMultiTabContent.PageViewCreated
        Dim seq As Integer = 0
        If _newPageFlag Then
            seq = CInt(ViewState("sequence")) + 1
            ViewState("sequence") = seq.ToString
        Else
            seq = e.PageView.MultiPage.PageViews.Count
        End If

        Dim ControlName As String = ""
        Select Case e.PageView.ID
            Case "PVDetail"
                ControlName = ScreenController.Screen_GetName(Admin_SubmissionTypeSetup)
            Case "PVReviewers"
                ControlName = ScreenController.Screen_GetName(AbstractScreen.Admin_SubmissionTypeReviewers)
            Case "PVSubmissions"                
                't.Relationships(0).re()
                ControlName = ScreenController.Screen_GetName(Admin_SubmissionSearchList)
            Case "PVAuthors"
                ControlName = ScreenController.Screen_GetName(Admin_AuthorRequirements)
                'ControlName = ScreenController.Screen_GetName(Admin_AuthorRequirements)
            Case "PVReviewProcess"
                ControlName = ScreenController.Screen_GetName(Admin_ReviewProcess)
            Case "PVMaterails"
                ControlName = ScreenController.Screen_GetName(Admin_MaterialsRequirements)
        End Select

        Dim ABSPage As AbstractScreenBase = LoadControl(ControlName)
        'Dim spacer As LiteralControl = New LiteralControl("<br />")
        'e.PageView.Controls.Add(spacer)

        ABSPage.ID = String.Concat(e.PageView.ID, "_TabContent")
        e.PageView.Controls.Add(ABSPage)

        If _newPageFlag Then
            Dim bEx As Boolean
            If Not String.IsNullOrEmpty(lblNumberSubmissions.Text) Then


                If Convert.ToInt16(lblNumberSubmissions.Text) > 0 Then
                    bEx = True
                End If
            End If
            ABSPage.SetupUpdateView(bEx)
        End If

    End Sub
End Class
