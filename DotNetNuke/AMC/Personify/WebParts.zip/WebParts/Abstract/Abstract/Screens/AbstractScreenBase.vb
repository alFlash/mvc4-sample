
Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports ScreenController.AbstractScreen
Imports ScreenController
Imports TIMSS.API.Core.Validation
Imports TIMSS.API.Core.ValidationIssues

Public MustInherit Class AbstractScreenBase
    Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Properties / Functions"

    Private _WebThemeName As String = "Office2007"
    Private _Language As String = "EN-US"

    'Public Event ShowMessageTextEvent(ByVal message As String)
    'Public Event ShowMessageAPIValidationEvent(ByVal validationIssues As TIMSS.API.Core.Validation.IIssuesCollection)

    Public Property Language() As String
        Get
            Return _Language
        End Get
        Set(ByVal value As String)
            _Language = value
        End Set
    End Property

    Public Property WebThemeName() As String
        Get
            Return _WebThemeName
        End Get
        Set(ByVal value As String)
            _WebThemeName = value
        End Set
    End Property

    Public Function GetTabId() As Integer
        If Request("tabid") IsNot Nothing Then
            Return CInt(Request("tabid"))
        End If
        Return 0
    End Function

    Public Function GetArgs() As String
        Return Request("args")
    End Function

    Public Function GetSubType() As String
        Return Request("type")
    End Function

    Public Function GetAction() As String
        Return Request("action")
    End Function

    Public Function GetAbsSubId() As String
        Return Request("AbsSubId")
    End Function


#End Region

#Region "Common functions"

    Public Sub GoToNextPage(ByVal screenId As AbstractScreen, ByVal args As String, ByVal action As String, Optional ByVal type As String = Nothing, Optional ByVal sids As String = Nothing)
        Me.Response.Redirect(GetNextPageURL(screenId, args, action, type, sids), True)
    End Sub

    Public Function GetNextPageURL(ByVal screenId As AbstractScreen, ByVal args As String, ByVal action As String, Optional ByVal type As String = Nothing, Optional ByVal sids As String = Nothing) As String

        Dim strURLBuilder As New System.Text.StringBuilder
        strURLBuilder.Append("s=")
        strURLBuilder.Append(screenId)
        If Not String.IsNullOrEmpty(action) Then
            strURLBuilder.Append("&action=")
            strURLBuilder.Append(action)
        End If
        If Not String.IsNullOrEmpty(args) Then
            strURLBuilder.Append("&args=")
            strURLBuilder.Append(args)
        End If
        If type IsNot Nothing AndAlso Not String.IsNullOrEmpty(type) Then
            strURLBuilder.Append("&type=")
            strURLBuilder.Append(type)
        End If
        If sids IsNot Nothing AndAlso Not String.IsNullOrEmpty(sids) Then
            strURLBuilder.Append("&sids=")
            strURLBuilder.Append(sids)
        End If

        Return NavigateURL("", strURLBuilder.ToString)
    End Function

    Public Function GetSubmissionDetailPageURL(ByVal screenId As AbstractScreen, ByVal sid As String) As String

        Dim strURLBuilder As New System.Text.StringBuilder
        strURLBuilder.Append("s=")
        strURLBuilder.Append(screenId)
     
        If sid IsNot Nothing AndAlso Not String.IsNullOrEmpty(sid) Then
            strURLBuilder.Append("&AbsSubId=")
            strURLBuilder.Append(sid)
        End If

        Return NavigateURL("", strURLBuilder.ToString)
    End Function

    Public Function GetAuthorPageURL(ByVal screenId As AbstractScreen, ByVal args As String, ByVal SubmissionId As Integer, ByVal AuthorId As Integer, Optional ByVal type As String = Nothing, Optional ByVal IsAdd As Boolean = False) As String

        Dim strURLBuilder As New System.Text.StringBuilder
        strURLBuilder.Append("s=")
        strURLBuilder.Append(screenId)
        If SubmissionId > 0 Then
            strURLBuilder.Append("&sid=")
            strURLBuilder.Append(SubmissionId)
        End If
        If AuthorId > 0 Then
            strURLBuilder.Append("&aid=")
            strURLBuilder.Append(AuthorId)
        End If
        If Not String.IsNullOrEmpty(args) Then
            strURLBuilder.Append("&args=")
            strURLBuilder.Append(args)
        End If
        If type IsNot Nothing AndAlso Not String.IsNullOrEmpty(type) Then
            strURLBuilder.Append("&type=")
            strURLBuilder.Append(type)
        End If
        If IsAdd = True Then
            strURLBuilder.Append("&mode=ADD")
        End If

        Return NavigateURL("", strURLBuilder.ToString)
    End Function

    Public Sub GoToNextPage(ByVal screenId As AbstractScreen, ByVal args As String, ByVal SubmissionId As Integer, ByVal AuthorId As Integer, Optional ByVal type As String = Nothing, Optional ByVal mode As String = Nothing)
        Me.Response.Redirect(GetNextPageURL(screenId, args, SubmissionId, AuthorId, type, mode), True)
    End Sub

    Public Function AppendReturnURL(ByVal url As String) As String
        If url.IndexOf("?") > 0 Then
            Return String.Format("{0}&returnurl={1}", url, Request.RawUrl)
        Else
            Return String.Format("{0}?returnurl={1}", url, Request.RawUrl)
        End If
    End Function

    Public Function GetNextPageURL(ByVal screenId As AbstractScreen, ByVal args As String, ByVal SubmissionId As Integer, ByVal AuthorId As Integer, Optional ByVal type As String = Nothing, Optional ByVal mode As String = Nothing) As String

        Dim strURLBuilder As New System.Text.StringBuilder
        strURLBuilder.Append("s=")
        strURLBuilder.Append(screenId)
        If SubmissionId > 0 Then
            strURLBuilder.Append("&sid=")
            strURLBuilder.Append(SubmissionId)
        End If
        If AuthorId > 0 Then
            strURLBuilder.Append("&aid=")
            strURLBuilder.Append(AuthorId)
        End If
        If Not String.IsNullOrEmpty(args) Then
            strURLBuilder.Append("&args=")
            strURLBuilder.Append(args)
        End If
        If type IsNot Nothing AndAlso Not String.IsNullOrEmpty(type) Then
            strURLBuilder.Append("&type=")
            strURLBuilder.Append(type)
        End If

        If mode IsNot Nothing AndAlso Not String.IsNullOrEmpty(mode) Then
            strURLBuilder.Append("&mode=")
            strURLBuilder.Append(mode)
        End If

        Return NavigateURL("", strURLBuilder.ToString)
    End Function

    

    Public Sub RedirectToLogin()
        Dim LoginURLBuilder As New System.Text.StringBuilder
        LoginURLBuilder.Append("~/Default.aspx?tabid=")
        LoginURLBuilder.Append(PortalSettings.LoginTabId)
        LoginURLBuilder.Append("&returnurl=")
        LoginURLBuilder.Append(HttpUtility.UrlEncode(Request.Url.AbsoluteUri))

        Me.Response.Redirect(LoginURLBuilder.ToString, True)

    End Sub
    'Public Sub ShowMessage(ByVal message As String, ByVal messageType As Skins.Controls.ModuleMessage.ModuleMessageType)
    '    RaiseEvent ShowMessageEvent(message, messageType)
    'End Sub

    Public Sub ShowPopupMessage(ByVal message As String)
        Dim popupMessage As New Telerik.Web.UI.RadToolTip
        Me.Controls.Add(popupMessage)
        With popupMessage
            .Position = Telerik.Web.UI.ToolTipPosition.Center
            .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
            .Animation = Telerik.Web.UI.ToolTipAnimation.Fade
            '.OffsetY = 60
            '.OffsetX = 115
            .HideDelay = 2500
            .Title = "Message"
            .Width = 170
            .Height = 60
            .Show()            
            .RenderInPageRoot = True            
        End With

        Dim lblmessageText As New Label
        lblmessageText.Text = message
        popupMessage.Controls.Add(lblmessageText)
    End Sub



    Public Sub ShowPopupMessageAndRedirect(ByVal message As String, ByVal URL As String)
        Dim popupMessage As New Telerik.Web.UI.RadToolTip
        Me.Controls.Add(popupMessage)
        With popupMessage
            .Position = Telerik.Web.UI.ToolTipPosition.Center
            .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
            .Animation = Telerik.Web.UI.ToolTipAnimation.Fade
            '.OffsetY = 60
            '.OffsetX = 115
            '.HideDelay = 6000
            '.HideDelay = "4000"
            .Title = "Message"
            .Width = 170
            .Height = 120
            '.ManualClose = True
            .HideEvent = Telerik.Web.UI.ToolTipHideEvent.ManualClose
            .Show()
            .RenderInPageRoot = True
        End With

        Dim lblmessageText As New Label
        lblmessageText.Text = message
        popupMessage.Controls.Add(lblmessageText)

        Dim oLiteral As New Literal
        oLiteral.Text = "<br/>"
        popupMessage.Controls.Add(oLiteral)

        Dim redirectButton As New Literal
        'redirectButton.Text = "OK"
        'redirectButton.Visible = True
        'redirectButton.PostBackUrl = URL
        'redirectButton.UseSubmitBehavior = False
        'redirectButton.Attributes.Add("onclick", "window.parent.location.href = '" + URL + "'")
        redirectButton.Text = "<br /><div align='center'><input type='button' onclick=""window.location.href = '" + URL + "';"" value='OK' /><div>"

        popupMessage.Controls.Add(redirectButton)
    End Sub

    Public Sub ShowPopupMessage(ByVal validationIssues As TIMSS.API.Core.Validation.IIssuesCollection)

        If validationIssues Is Nothing OrElse validationIssues.ErrorCount = 0 Then
            Exit Sub
        End If

        Dim popupMessage As New Telerik.Web.UI.RadToolTip
        Dim width As Integer = 75
        Me.Controls.Add(popupMessage)

        With popupMessage
            '.Position = Telerik.Web.UI.ToolTipPosition.BottomRight
            '.RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
            .Position = Telerik.Web.UI.ToolTipPosition.Center
            .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow            
            .Animation = Telerik.Web.UI.ToolTipAnimation.Fade
            '.Animation = Telerik.Web.UI.ToolTipAnimation.None
            .Title = "Message"
            .Width = 300          
            .Height = width * validationIssues.ErrorCount                        
            .Show()
            .RenderInPageRoot = True
            '.VisibleOnPageLoad = True
            .HideEvent = Telerik.Web.UI.ToolTipHideEvent.ManualClose
        End With


        popupMessage.Controls.Add(CreateValidationContent(validationIssues))

    End Sub

    Private Function CreateValidationContent(ByVal validationIssues As TIMSS.API.Core.Validation.IIssuesCollection) As Table
        Dim aTable As New Table
        aTable.CellSpacing = 0
        aTable.CellPadding = 3
        aTable.Height = New System.Web.UI.WebControls.Unit(100, UnitType.Percentage)
        aTable.Width = New System.Web.UI.WebControls.Unit(100, UnitType.Percentage)
        For i As Integer = 0 To validationIssues.Count - 1
            If validationIssues(i).Severity = IssueSeverityEnum.Error Then
                Dim tablecellA As New TableCell
                tablecellA.HorizontalAlign = HorizontalAlign.Center
                tablecellA.VerticalAlign = VerticalAlign.Middle
                Dim aImage As New System.Web.UI.WebControls.Image
                aImage.ImageUrl = GetMessageIcon(validationIssues(i).Severity)
                tablecellA.Controls.Add(aImage)

                Dim tablecellB As New TableCell
                tablecellB.HorizontalAlign = HorizontalAlign.Left
                tablecellB.VerticalAlign = VerticalAlign.Middle
                Dim aLabel As New Label
                aLabel.Text = validationIssues(i).Message
                tablecellB.Controls.Add(aLabel)

                Dim aRow As New TableRow
                aRow.Cells.Add(tablecellA)
                aRow.Cells.Add(tablecellB)
                aTable.Rows.Add(aRow)
            End If         
        Next
        Dim btnOk As New Button
        Dim aEndRow As New TableRow
        Dim aEndCell As New TableCell
        Dim lbl As New Label
        lbl.Text = "<br/><br/>"
        btnOk.Text = "Ok"
        btnOk.Width = "50"
        aEndCell.HorizontalAlign = HorizontalAlign.Right
        aEndCell.ColumnSpan = 2
        aEndCell.Controls.Add(lbl)
        aEndCell.Controls.Add(btnOk)
        aEndRow.Cells.Add(aEndCell)
        aTable.Rows.Add(aEndRow)

        Return aTable
    End Function


    'Private Sub SetPopupControlProperties(ByRef control As Telerik.Web.UI.RadToolTip, Optional ByVal isModal As Boolean = False)

    '    With Control
    '        .Position = Telerik.Web.UI.ToolTipPosition.BottomRight
    '        .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
    '        ' .Position = Telerik.Web.UI.ToolTipPosition.Center
    '        ' .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
    '        .OffsetY = 20

    '        .HideDelay = 6000
    '        .Title = "Message"
    '        .Width = "350"
    '        .ManualClose = False
    '        .Modal = isModal
    '        .Show()
    '        .VisibleOnPageLoad = True

    '        If isModal Then
    '            .ManualClose = True
    '        Else
    '            .ManualClose = False
    '        End If

    '    End With


    'End Sub

#End Region

#Region "Get Instance of Manager class"

    Public Function CallManager() As CallManagerHelper
        Dim oCallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
        Return oCallManager
    End Function

    Public Function ReviewManager() As ReviewManagerHelper
        Dim oReviewManager As New ReviewManagerHelper(OrganizationId, OrganizationUnitId)
        Return oReviewManager
    End Function

    Public Function SubmissionManager() As SubmissionManagerHelper
        Dim oSubmissionManager As New SubmissionManagerHelper(OrganizationId, OrganizationUnitId)
        Return oSubmissionManager
    End Function

#End Region

#Region "Access Control"

    Public Function HasAdminAccess() As Boolean

        If GetSessionObject(SessionKeys.PersonifyAbstractCallAdmin) Is Nothing Then
            AddSessionObject(SessionKeys.PersonifyAbstractCallAdmin, Me.ABS_AcessControl_IsStaff(MasterCustomerId, SubCustomerId))
        End If

        Return GetSessionObject(SessionKeys.PersonifyAbstractCallAdmin)
    End Function

    Public Function HasSubmissionTypeAccess(ByVal controlAccessType As ScreenController.ABS_Security_Role) As Boolean

        If HasAdminAccess() Then
            Return True
        End If

        If Not controlAccessType = ScreenController.ABS_Security_Role.SubTypeStaff_Specific AndAlso Not controlAccessType = ScreenController.ABS_Security_Role.SubTypeStaff_General Then
            Return False
        End If

        Dim tblSubTypeList As DataTable
        If GetSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer) IsNot Nothing Then
            tblSubTypeList = GetSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer)
        Else
            tblSubTypeList = Me.ABS_AccessControl_IsSubmissionTypeStaff_GetTable(MasterCustomerId, SubCustomerId, Nothing, Nothing)
            AddSessionObject(SessionKeys.PersonifyAbstractCallSubTypeStaffPerCustomer, tblSubTypeList)
        End If

        If tblSubTypeList Is Nothing Then
            Return False
        End If

        Select Case controlAccessType
            Case ScreenController.ABS_Security_Role.SubTypeStaff_General
                If tblSubTypeList.Rows.Count > 0 Then
                    Return True
                End If
            Case ScreenController.ABS_Security_Role.SubTypeStaff_Specific
                If GetArgs() Is Nothing OrElse Me.GetSubType Is Nothing Then
                    Return False
                End If
                Dim oExpression As String
                oExpression = String.Concat("SubmissionTypeCode='", GetSubType, "' and AbstractCallCode='", GetArgs, "'")
                If tblSubTypeList.Select(oExpression).Length > 0 Then
                    Return True
                End If
        End Select




        Return False

    End Function

    Public Function ABS_AcessControl_IsStaff(ByVal MasterCustomerId As String, ByVal SubCustomerId As String) As Boolean

        Dim t As TIMSS.API.CustomerInfo.ICustomerAbstractStaffRoles

        Dim oParm As TIMSS.API.Core.SearchProperty
        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAbstractStaffRoles")
        searchObj.EnforceLimits = False

        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("ActiveFlag")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = "Y"
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AdministratorFlag")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = "Y"
        searchObj.Parameters.Add(oParm)


        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            Return True
        End If

        Return False
       
    End Function


    Public Function ABS_AcessControl_IsSubmissionTypeStaff(ByVal MasterCustomerId As String, ByVal SubCustomerId As String, ByVal CallCode As String, ByVal SubmissionTypeCode As String) As Boolean
        'Check if user is part of submission type / Call code as STAFF

        Dim isSubmissionTypeStaffFlag As Boolean
        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeStaffs")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeStaffId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)


        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubCustomerId
        searchObj.Parameters.Add(oParm)


        If Not String.IsNullOrEmpty(CallCode) Then
            oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = CallCode
            searchObj.Parameters.Add(oParm)
        End If

        If Not String.IsNullOrEmpty(SubmissionTypeCode) Then
            oParm = New TIMSS.API.Core.SearchProperty("SubmissionTypeCode")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = SubmissionTypeCode
            searchObj.Parameters.Add(oParm)
        End If


        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            isSubmissionTypeStaffFlag = True
        End If

        Return isSubmissionTypeStaffFlag

    End Function

    Public Function ABS_AccessControl_IsSubmissionTypeStaff_GetTable(ByVal MasterCustomerId As String, ByVal SubCustomerId As String, ByVal CallCode As String, ByVal SubmissionTypeCode As String) As DataTable


        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeStaffs")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeStaffId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)


        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubCustomerId
        searchObj.Parameters.Add(oParm)



        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
        If Not String.IsNullOrEmpty(CallCode) Then
            oParm.UseInQuery = True
            oParm.Value = CallCode
        Else
            oParm.UseInQuery = False
        End If
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)



        oParm = New TIMSS.API.Core.SearchProperty("SubmissionTypeCode")
        If Not String.IsNullOrEmpty(SubmissionTypeCode) Then
            oParm.UseInQuery = True
            oParm.Value = SubmissionTypeCode
        Else
            oParm.UseInQuery = False
        End If
        oParm.ShowInResults = True

        searchObj.Parameters.Add(oParm)


        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            Return searchObj.Results.Table
        End If

        Return Nothing

    End Function

    Public Function ABS_AcessControl_IsAuthorAllowToSubmitForSubmission(ByVal MasterCustomerId As String, ByVal SubCustomerId As String, ByVal CallCode As String, ByVal SubmissionTypeCode As String) As Boolean
        'Check if author allow to submit for this Call / submission type
        Return True
    End Function

    Public Function ABS_AcessControl_IsAuthorBelongToSubmission(ByVal MasterCustomerId As String, ByVal SubCustomerId As String, ByVal SubmissionId As String) As Boolean
        'Check if author submitted the submission
        Dim AuthorBelongToSubmission As Boolean
        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty
        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubmissionId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubCustomerId
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            AuthorBelongToSubmission = True
        End If

        Return AuthorBelongToSubmission
    End Function

    Public Function ABS_AcessControl_IsReviewer(ByVal MasterCustomerId As String, ByVal SubCustomerId As String) As Boolean
        'Check if user is part of ABS_Reviewer
        Dim isReviewerFlag As Boolean
        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractReviewers")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty
        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubCustomerId
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            isReviewerFlag = True
        End If

        Return isReviewerFlag
    End Function

    Public Function ABS_AcessControl_IsSubmissionReviewer(ByVal MasterCustomerId As String, ByVal SubCustomerId As String, ByVal SubmissionId As String) As Boolean
        'Check if user is a reviewer of particular submission id
        Dim isSubmissionReviewerFlag As Boolean
        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionReviewers")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty
        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubmissionId
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            isSubmissionReviewerFlag = True
        End If

        Return isSubmissionReviewerFlag
    End Function

    Public Function ABS_AcessControl_IsAuthor(ByVal MasterCustomerId As String, ByVal SubCustomerId As String) As Boolean

        Return True
        ' ''Check if user is part of ABS_Reviewer
        ''Dim isReviewerFlag As Boolean
        ''Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        ''searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractReviewers")
        ''searchObj.EnforceLimits = False

        ' ''Set up the search fields
        ''Dim oParm As TIMSS.API.Core.SearchProperty
        ''oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        ''oParm.UseInQuery = True
        ''oParm.ShowInResults = False
        ''oParm.Value = MasterCustomerId
        ''searchObj.Parameters.Add(oParm)

        ''oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        ''oParm.UseInQuery = True
        ''oParm.ShowInResults = False
        ''oParm.Value = SubCustomerId
        ''searchObj.Parameters.Add(oParm)

        ''searchObj.Search()

        ''If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
        ''    isReviewerFlag = True
        ''End If

        ''Return isReviewerFlag
    End Function
#End Region

#Region "Helper functions"

    Private Function GetMessageIcon(ByVal iconType As IssueSeverityEnum) As String

        Select Case iconType
            Case IssueSeverityEnum.Information
                Return "~/DefaultPersonifyImages/timss-info-green.gif"
            Case IssueSeverityEnum.Question
                Return "~/DefaultPersonifyImages/timss-question-blue.gif"
            Case IssueSeverityEnum.Warning
                Return "~/DefaultPersonifyImages/timss-warning-yellow.gif"
            Case IssueSeverityEnum.Error
                Return "~/DefaultPersonifyImages/timss-error-red.gif"
        End Select

        Return ""
    End Function



#End Region

#Region "Virtual Methods"

    Public Overridable Sub SetupUpdateView(Optional ByVal SubmissionsExists As Boolean = False)

    End Sub

#End Region



End Class
