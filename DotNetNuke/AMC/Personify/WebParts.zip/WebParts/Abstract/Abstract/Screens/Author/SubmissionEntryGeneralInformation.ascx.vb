Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI

Public Class SubmissionEntryGeneralInformation
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private SubmissionId As Integer
    Private oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
    Private _AbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

    Dim listTopics As ArrayList
    Dim listKeywords As ArrayList

    Dim topics As Hashtable
    Dim keywords As Hashtable
    Dim sidFound As Boolean

    Public Property KeywordNONE() As Boolean
        Get
            Return ViewState("KeywordNONE")
        End Get
        Set(ByVal value As Boolean)
            ViewState("KeywordNONE") = value
        End Set
    End Property

    Public Property TopicNONE() As Boolean
        Get
            Return ViewState("TopicNONE")
        End Get
        Set(ByVal value As Boolean)
            ViewState("TopicNONE") = value
        End Set
    End Property


    Public ReadOnly Property AbstractSubmissionId() As Integer
        Get
            If Request("sid") IsNot Nothing Then
                Return CInt(Request("sid"))
            Else
                Return 0
            End If
        End Get
    End Property

#End Region

#Region "Controls"
    Protected WithEvents pnlMain As Panel
    Protected WithEvents lblMessage As Label

    Protected WithEvents lblInstruction As Label
    Protected WithEvents RadEditorTitle As TextBox

    Protected WithEvents RadGridTopicOptions As RadGrid
    Protected WithEvents RadTextBoxTopic As RadTextBox
    Protected WithEvents RadGridKeywords As RadGrid
    Protected WithEvents RadTextBoxKeyword As RadTextBox

    Protected WithEvents butEnterAuthorInformation As Button

    Protected WithEvents CustomValidator1 As CustomValidator
    Protected WithEvents CustomValidator2 As CustomValidator
    Protected WithEvents CustomValidator3 As CustomValidator

    Protected WithEvents RequiredFieldValidatorTopic As RequiredFieldValidator
    Protected WithEvents RequiredFieldValidatorKeyword As RequiredFieldValidator
    Protected WithEvents pnlTopics As Panel
    Protected WithEvents pnlKeywords As Panel
    Protected WithEvents lblKeywords As Label
    Protected WithEvents ddlCategory As RadComboBox
    Protected WithEvents txtLengthInMinutes As RadNumericTextBox

    Protected WithEvents butGoBackSubmissionDetail As Button

#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        sidFound = False
        If AbstractSubmissionId > 0 Then
            oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)
            oAbstractSubmissions.Filter.Add("AbstractSubmissionId", AbstractSubmissionId)
            oAbstractSubmissions.Fill()
            If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then
                sidFound = True
            End If
        End If

        If ValidateQS() Then
            pnlMain.Visible = True
            lblMessage.Visible = False
            If Not Page.IsPostBack Then
                'lblInstruction.Text = CallManager.GetInstruction(PortalId, Constants.Const_InstructionType_Author, GetArgs, GetSubType)
                SetupControls()
            End If
        Else
            pnlMain.Visible = False
            lblMessage.Visible = True
            If Me._AbstractCallSubmissionTypes IsNot Nothing AndAlso Me._AbstractCallSubmissionTypes.ValidationIssues.ErrorCount > 0 Then
                lblMessage.Text = Me._AbstractCallSubmissionTypes.ValidationIssues(0).Message
            Else
                lblMessage.Text = "You may not submit at this time."
            End If
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        If Not TopicNONE Then
            args.IsValid = (RadGridTopicOptions.SelectedItems.Count > 0)
        Else
            args.IsValid = True
        End If

    End Sub

    Protected Sub CustomValidator2_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator2.ServerValidate
        If Not KeywordNONE Then
            args.IsValid = (RadGridKeywords.SelectedItems.Count > 0)
        Else
            args.IsValid = True
        End If
    End Sub


    Protected Sub CustomValidator3_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        If Not TopicNONE Then
            Dim primaryTopicExists As Boolean = False
            For Each dataitem As Telerik.Web.UI.GridDataItem In RadGridTopicOptions.SelectedItems
                Dim rdPrimaryTopic As RadioButton = dataitem.FindControl("rdPrimaryTopic")
                If rdPrimaryTopic.Checked Then
                    primaryTopicExists = True
                    Exit For
                End If
            Next
            args.IsValid = primaryTopicExists
        Else
            args.IsValid = True
        End If
    End Sub
#End Region


#Region "Public functions"

    Private Sub SetupControls()

        If Request("mode") IsNot Nothing AndAlso Request("mode") = "Y" Then
            Me.butEnterAuthorInformation.Visible = False
            Me.butGoBackSubmissionDetail.Visible = True
        End If


        KeywordNONE = False
        TopicNONE = False
        listTopics = New ArrayList()

        RadGridTopicOptions.Visible = True
        RadTextBoxTopic.Visible = False
        RequiredFieldValidatorTopic.Enabled = False

        RadGridKeywords.Visible = True
        RadTextBoxKeyword.Visible = False
        RequiredFieldValidatorKeyword.Enabled = False

        'Set up the Category Combobox          
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        appCodes = GetApplicationCodes("ABS", "CATEGORY", True)
        ddlCategory.DataSource = appCodes
        ddlCategory.DataTextField = "Description"
        ddlCategory.DataValueField = "Code"
        ddlCategory.DataBind()
        ddlCategory.Items.Insert(0, New RadComboBoxItem(""))


        If _AbstractCallSubmissionTypes(0).ValidateTopicControlCodeString = "NONE" Then
            TopicNONE = True
        End If
        If _AbstractCallSubmissionTypes(0).ValidateKeywordControlCodeString = "NONE" Then
            KeywordNONE = True
        End If

        'Edit mode
        topics = New Hashtable
        keywords = New Hashtable
        If AbstractSubmissionId > 0 Then
            If Not sidFound Then
                Exit Sub
            End If
            RadEditorTitle.Text = oAbstractSubmissions(0).Title
            If Not TopicNONE Then
                Dim oAbstractTopic As TIMSS.API.AbstractInfo.IAbstractSubmissionTopic
                For Each oAbstractTopic In oAbstractSubmissions(0).AbstractSubmissionTopics
                    If oAbstractTopic.TopicCode.Code <> "" Then
                        topics.Add(oAbstractTopic.TopicCode.Code, New TopicItem(oAbstractTopic.TopicCode.Code, oAbstractTopic.TopicCode.Code, oAbstractTopic.PrimaryTopicFlag, True))
                    End If
                Next
            Else
                RadTextBoxTopic.Text = oAbstractSubmissions(0).PrimaryTopicCode
            End If

            Dim oAbstractKeyword As TIMSS.API.AbstractInfo.IAbstractSubmissionKeyword
            If Not KeywordNONE Then
                For Each oAbstractKeyword In oAbstractSubmissions(0).AbstractSubmissionKeywords
                    If oAbstractKeyword.KeywordCode.Code <> "" Then
                        keywords.Add(oAbstractKeyword.KeywordCode.Code, New KeywordItem(oAbstractKeyword.KeywordCode.Code, oAbstractKeyword.KeywordCode.Code, True))
                    End If
                Next
            Else
                RadTextBoxKeyword.Text = oAbstractSubmissions(0).AbstractSubmissionKeywords(0).Keyword
            End If

            If ddlCategory.FindItemByValue(oAbstractSubmissions(0).CategoryCode.Code) IsNot Nothing Then
                ddlCategory.FindItemByValue(oAbstractSubmissions(0).CategoryCode.Code).Selected = True
            End If

            txtLengthInMinutes.Text = oAbstractSubmissions(0).LengthInMinutes
        End If

        If _AbstractCallSubmissionTypes(0).ValidateTopicControlCodeString = "SUBMISSION_TYPE_LIST" Then
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationSubcodes = GetApplicationSubCodes("ABS", "SUBMISSION_TOPIC", "", True)
            For Each oAbstractSubmissionTypeTopics As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopic In _AbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics
                Dim topicDescription As String = oAbstractSubmissionTypeTopics.TopicCode
                For Each code As TIMSS.API.ApplicationInfo.IApplicationSubcode In oAppCodes
                    If oAbstractSubmissionTypeTopics.TopicCode = code.Subcode Then
                        topicDescription = code.Description

                        Dim primaryFlag As Boolean = False
                        Dim checkedFlag As Boolean = False
                        If topics IsNot Nothing AndAlso topics(oAbstractSubmissionTypeTopics.TopicCode) IsNot Nothing Then
                            primaryFlag = CType(topics(oAbstractSubmissionTypeTopics.TopicCode), TopicItem).Primary
                            checkedFlag = True
                        End If

                        Dim oAbstractSubmissionTypeTopicsTemp As New TopicItem(oAbstractSubmissionTypeTopics.TopicCode, topicDescription, primaryFlag, checkedFlag)
                        listTopics.Add(oAbstractSubmissionTypeTopicsTemp)
                    End If
                Next
            Next
        ElseIf _AbstractCallSubmissionTypes(0).ValidateTopicControlCodeString = "SYSTEM_LIST" Then
            Dim codes As TIMSS.API.ApplicationInfo.IApplicationSubcodes = _
             GetApplicationSubCodes("ABS", Constants.Const_Submission_Topic_Type, _AbstractCallSubmissionTypes(0).ValidationTopicCodeString, True)
            For Each code As TIMSS.API.ApplicationInfo.IApplicationSubcode In codes
                Dim primaryFlag As Boolean = False
                Dim checkedFlag As Boolean = False
                If topics IsNot Nothing AndAlso topics(code.Subcode) IsNot Nothing Then
                    primaryFlag = CType(topics(code.Subcode), TopicItem).Primary
                    checkedFlag = True

                End If
                Dim oAbstractSubmissionTypeTopicsTemp As New TopicItem(code.Subcode, code.Description, primaryFlag, checkedFlag)
                listTopics.Add(oAbstractSubmissionTypeTopicsTemp)
            Next
        ElseIf _AbstractCallSubmissionTypes(0).ValidateTopicControlCodeString = "NONE" Then
            RadGridTopicOptions.Visible = False

            RadTextBoxTopic.Visible = True
            RequiredFieldValidatorTopic.Enabled = True
            pnlTopics.ScrollBars = ScrollBars.None
            TopicNONE = True
        End If


        listKeywords = New ArrayList()

        If _AbstractCallSubmissionTypes(0).ValidateKeywordControlCodeString = "SUBMISSION_TYPE_LIST" Then
            Dim oAppCodes As TIMSS.API.ApplicationInfo.IApplicationSubcodes = GetApplicationSubCodes("ABS", "SUBMISSION_KEYWORD", "", True)
            For Each oAbstractSubmissionTypeKeywords As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeKeyword In _AbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords
                Dim keywordDescription As String = oAbstractSubmissionTypeKeywords.KeywordCode
                For Each code As TIMSS.API.ApplicationInfo.IApplicationSubcode In oAppCodes
                    If oAbstractSubmissionTypeKeywords.KeywordCode = code.Subcode Then
                        keywordDescription = code.Description

                        Dim checkedFlag As Boolean = False
                        If keywords IsNot Nothing AndAlso keywords(oAbstractSubmissionTypeKeywords.KeywordCode) IsNot Nothing Then
                            checkedFlag = True
                        End If
                        Dim oAbstractSubmissionTypeKeywordsTemp As New KeywordItem(oAbstractSubmissionTypeKeywords.KeywordCode, keywordDescription, checkedFlag)
                        listKeywords.Add(oAbstractSubmissionTypeKeywordsTemp)
                    End If
                Next
            Next
        ElseIf _AbstractCallSubmissionTypes(0).ValidateKeywordControlCodeString = "SYSTEM_LIST" Then
            Dim codes As TIMSS.API.ApplicationInfo.IApplicationSubcodes = _
             GetApplicationSubCodes("ABS", Constants.Const_Submission_Keyword_Type, _AbstractCallSubmissionTypes(0).ValidationKeywordCodeString, True)
            For Each code As TIMSS.API.ApplicationInfo.IApplicationSubcode In codes
                Dim checkedFlag As Boolean = False
                If keywords IsNot Nothing AndAlso keywords(code.Subcode) IsNot Nothing Then
                    checkedFlag = True
                End If

                Dim oAbstractSubmissionTypeKeywordsTemp As New KeywordItem(code.Subcode, code.Description, checkedFlag)
                listKeywords.Add(oAbstractSubmissionTypeKeywordsTemp)
            Next
        ElseIf _AbstractCallSubmissionTypes(0).ValidateKeywordControlCodeString = "NONE" Then
            KeywordNONE = True
            RadGridKeywords.Visible = False
            RadTextBoxKeyword.Visible = True
            RequiredFieldValidatorKeyword.Enabled = True
            pnlKeywords.ScrollBars = ScrollBars.None
        End If


    End Sub


    Private Function ValidateQS() As Boolean

        Dim result As Boolean

        If AbstractSubmissionId = 0 And (GetArgs() Is Nothing Or GetSubType() Is Nothing) Then
            result = False
        Else
            result = True
        End If

        If result Then
            _AbstractCallSubmissionTypes = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypes"), TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes) 'oAbstractCall.AbstractCallSubmissionTypes
            If sidFound Then
                _AbstractCallSubmissionTypes.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, oAbstractSubmissions(0).AbstractCallCode)
                _AbstractCallSubmissionTypes.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, oAbstractSubmissions(0).SubmissionTypeCode)
            Else
                _AbstractCallSubmissionTypes.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, GetArgs)
                _AbstractCallSubmissionTypes.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, GetSubType)
            End If
            _AbstractCallSubmissionTypes.Fill()
            If _AbstractCallSubmissionTypes Is Nothing Or _AbstractCallSubmissionTypes.Count = 0 Then
                result = False
            Else
                result = _AbstractCallSubmissionTypes(0).IsWebSubmissionAllowed
            End If
        End If

        Return result

    End Function
    Protected Sub RadGridTopicOptions_NeedDataSource(ByVal [source] As Object, _
   ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        RadGridTopicOptions.DataSource = listTopics
    End Sub
    Protected Sub RadGridTopicOptions_ItemDataBound(ByVal [source] As Object, _
       ByVal e As Telerik.Web.UI.GridItemEventArgs)

        If topics IsNot Nothing Then
            If (TypeOf e.Item Is GridDataItem) Then
                If topics(CStr(CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("TopicCode"))) IsNot Nothing Then
                    CType(e.Item, GridDataItem).Selected = True                    
                    'CType(CType(e.Item, GridDataItem).FindControl("columnSelectCheckBox"), CheckBox).Checked = True
                End If
                Dim rdPrimaryTopic As RadioButton = CType(CType(e.Item, GridDataItem).FindControl("rdPrimaryTopic"), RadioButton)
                rdPrimaryTopic.Attributes.Add("Onclick", "SelectMeOnly('" & rdPrimaryTopic.ClientID & "', 'rdPrimaryTopic')")
            End If


        End If
    End Sub

    Protected Sub RadGridKeywords_NeedDataSource(ByVal [source] As Object, _
      ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)

        RadGridKeywords.DataSource = listKeywords
    End Sub
    Protected Sub RadGridKeywords_ItemDataBound(ByVal [source] As Object, _
           ByVal e As Telerik.Web.UI.GridItemEventArgs)

        If keywords IsNot Nothing Then
            If (TypeOf e.Item Is GridDataItem) Then
                If keywords(CStr(CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("KeywordCode"))) IsNot Nothing Then
                    CType(e.Item, GridDataItem).Selected = True
                    'CType(CType(e.Item, GridDataItem).FindControl("columnSelectCheckBox"), CheckBox).Checked = True
                End If
            End If
        End If
    End Sub

    Protected Sub butEnterAuthorInformation_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butEnterAuthorInformation.Click

        CustomValidator1.Validate()
        CustomValidator2.Validate()
        CustomValidator3.Validate()

        If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oValidationIssues = SaveCustomer()

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                ShowPopupMessage(oValidationIssues)
            ElseIf SubmissionId = 0 Then
                ShowPopupMessage("Abstract Call Code and Submission Type Code not found")
            Else
                'ShowPopupMessage(Constants.Const_Save_Message)
                If Not String.IsNullOrEmpty(Request("returnurl")) Then
                    Response.Redirect(Request("returnurl"))
                End If

                Dim mode As String = String.Empty
                If AbstractSubmissionId > 0 Then
                    mode = "Edit"
                End If
                If sidFound Then
                    GoToNextPage(Author_SubmissionEntryAuthorInformation, oAbstractSubmissions(0).AbstractCallCode, SubmissionId, 0, oAbstractSubmissions(0).SubmissionTypeCode, mode)
                Else
                    GoToNextPage(Author_SubmissionEntryAuthorInformation, GetArgs, SubmissionId, 0, GetSubType, mode)
                End If
            End If
        Else
                ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If

    End Sub
    Private Function ValidateSubmissionTypeDates() As Boolean

        Return True
    End Function
    Private Function SaveCustomer() As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
        Dim oAbstractCall As TIMSS.API.AbstractInfo.IAbstractCall = Nothing
        Dim oAbstractCallSubmissionType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType = Nothing
        Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes = Nothing
        Dim oAbstractSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission = Nothing

        Dim submissionIndex As Integer = 0

        If AbstractSubmissionId > 0 Then
            sidFound = False
            oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)
            oAbstractSubmissions.Filter.Add("AbstractSubmissionId", AbstractSubmissionId)
            oAbstractSubmissions.Fill()
            If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then
                sidFound = True
            End If

            If sidFound Then
                oAbstractSubmission = oAbstractSubmissions(0)
                oAbstractSubmission.AbstractSubmissionTopics.RemoveAll()
                oAbstractSubmission.AbstractSubmissionKeywords.RemoveAll()
            End If
        Else
            oAbstractCallSubmissionTypes = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypes"), TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes) 'oAbstractCall.AbstractCallSubmissionTypes
            oAbstractCallSubmissionTypes.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, GetArgs)
            oAbstractCallSubmissionTypes.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, GetSubType)
            oAbstractCallSubmissionTypes.Fill()
            If oAbstractCallSubmissionTypes Is Nothing Or oAbstractCallSubmissionTypes.Count = 0 Then
                SubmissionId = 0
                Return Nothing
            End If
            oAbstractCallSubmissionType = oAbstractCallSubmissionTypes(0)

            oAbstractSubmissions = oAbstractCallSubmissionType.AbstractSubmissions
            submissionIndex = oAbstractSubmissions.Count
            oAbstractSubmission = oAbstractSubmissions.AddNew
            oAbstractSubmission.EventStatusCode = Constants.Const_EventCode_DRAFT_SAVED
            oAbstractSubmission.ReadOnly("ExternalStatusCode") = False
            oAbstractSubmission.ExternalStatusCode = oAbstractSubmission.ExternalStatusCode.List("DRAFT").ToCodeObject
        End If



        With oAbstractSubmission
            .Title = RadEditorTitle.Text
            If ddlCategory.Text <> "" Then
                .CategoryCode.Code = ddlCategory.SelectedValue
            End If
            If txtLengthInMinutes.Text <> "" Then
                .LengthInMinutes = txtLengthInMinutes.Text
            End If
        End With

        If Not KeywordNONE Then
            For Each dataitemK As Telerik.Web.UI.GridDataItem In RadGridKeywords.SelectedItems
                Dim oAbstractKeyword As TIMSS.API.AbstractInfo.IAbstractSubmissionKeyword
                oAbstractKeyword = oAbstractSubmission.AbstractSubmissionKeywords.AddNew
                oAbstractKeyword.AbstractSubmissionId = oAbstractSubmission.AbstractSubmissionId
                'oAbstractKeyword.KeywordCode = oAbstractKeyword.KeywordCode.List(dataitem.OwnerTableView.DataKeyValues(index)("KeywordCode")).ToCodeObject
                'oAbstractKeyword.KeywordCode = oAbstractKeyword.KeywordCode.List(CType(dataitemK.FindControl("hdnKeywordCode"), HiddenField).Value).ToCodeObject
                oAbstractKeyword.KeywordCode.Code = CType(dataitemK.FindControl("hdnKeywordCode"), HiddenField).Value
            Next
        Else
            Dim oAbstractkeyword As TIMSS.API.AbstractInfo.IAbstractSubmissionKeyword
            oAbstractkeyword = oAbstractSubmission.AbstractSubmissionKeywords.AddNew
            oAbstractkeyword.AbstractSubmissionId = oAbstractSubmission.AbstractSubmissionId
            oAbstractkeyword.Keyword = RadTextBoxKeyword.Text
        End If
        If Not TopicNONE Then
            For Each dataitemT As Telerik.Web.UI.GridDataItem In RadGridTopicOptions.SelectedItems
                Dim rdPrimaryTopic As RadioButton = dataitemT.FindControl("rdPrimaryTopic")

                Dim oAbstractTopic As TIMSS.API.AbstractInfo.IAbstractSubmissionTopic
                oAbstractTopic = oAbstractSubmission.AbstractSubmissionTopics.AddNew
                oAbstractTopic.AbstractSubmissionId = oAbstractSubmission.AbstractSubmissionId
                'oAbstractTopic.TopicCode = oAbstractTopic.TopicCode.List(dataitem.OwnerTableView.DataKeyValues(index)("TopicCode")).ToCodeObject
                'oAbstractTopic.TopicCode = oAbstractTopic.TopicCode.List(CType(dataitemT.FindControl("hdnTopicCode"), HiddenField).Value).ToCodeObject
                oAbstractTopic.TopicCode.Code = CType(dataitemT.FindControl("hdnTopicCode"), HiddenField).Value
                oAbstractTopic.PrimaryTopicFlag = rdPrimaryTopic.Checked
            Next
        Else
            Dim oAbstractTopic As TIMSS.API.AbstractInfo.IAbstractSubmissionTopic
            oAbstractTopic = oAbstractSubmission.AbstractSubmissionTopics.AddNew
            oAbstractTopic.AbstractSubmissionId = oAbstractSubmission.AbstractSubmissionId
            oAbstractTopic.Topic = RadTextBoxTopic.Text
            'oAbstractTopic.PrimaryTopicFlag = True
        End If


        oAbstractSubmissions.Save()
        If oAbstractSubmissions.ValidationIssues.ErrorCount > 0 Then
            SubmissionId = 0
        Else
            SubmissionId = oAbstractSubmissions(submissionIndex).AbstractSubmissionId
        End If
        Return oAbstractSubmissions.ValidationIssues
    End Function
#End Region


    
    Private Sub RadGridTopicOptions_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadGridTopicOptions.SelectedIndexChanged
        For Each dataItem As GridDataItem In RadGridTopicOptions.Items
            Dim rdPrimaryTopic As RadioButton = CType(dataItem.FindControl("rdPrimaryTopic"), RadioButton)
            If RadGridTopicOptions.SelectedItems.Count = 1 Then
                rdPrimaryTopic.Checked = dataItem.Selected
            End If
        Next
    End Sub

    Private Sub butGoBackSubmissionDetail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butGoBackSubmissionDetail.Click

        CustomValidator1.Validate()
        CustomValidator2.Validate()
        CustomValidator3.Validate()

        If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oValidationIssues = SaveCustomer()

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                ShowPopupMessage(oValidationIssues)        
            Else
                Me.Response.Redirect(GetSubmissionDetailPageURL(Admin_SubmissionDetails, AbstractSubmissionId), True)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If


    End Sub
End Class

Public Class TopicItem
    Private _TopicDescription As String
    Private _TopicCode As String
    Private _Primary As Boolean
    Private _Checked As Boolean

    Public Property TopicDescription() As String
        Get
            Return _TopicDescription
        End Get
        Set(ByVal value As String)
            _TopicDescription = value
        End Set
    End Property

    Public Property TopicCode() As String
        Get
            Return _TopicCode
        End Get
        Set(ByVal value As String)
            _TopicCode = value
        End Set
    End Property

    Public Property Primary() As Boolean
        Get
            Return _Primary
        End Get
        Set(ByVal value As Boolean)
            _Primary = value
        End Set
    End Property

    Public Property Checked() As Boolean
        Get
            Return _Checked
        End Get
        Set(ByVal value As Boolean)
            _Checked = value
        End Set
    End Property

    Public Sub New(ByVal TopicCode As String, ByVal TopicDescription As String, ByVal Primary As Boolean, ByVal Checked As Boolean)
        Me.TopicDescription = TopicDescription
        Me.TopicCode = TopicCode
        Me.Primary = Primary
        Me.Checked = Checked
    End Sub
End Class


Public Class KeywordItem
    Private _KeywordDescription As String
    Private _KeywordCode As String
    Private _Checked As Boolean


    Public Property KeywordDescription() As String
        Get
            Return _KeywordDescription
        End Get
        Set(ByVal value As String)
            _KeywordDescription = value
        End Set
    End Property

    Public Property KeywordCode() As String
        Get
            Return _KeywordCode
        End Get
        Set(ByVal value As String)
            _KeywordCode = value
        End Set
    End Property

    Public Property Checked() As Boolean
        Get
            Return _Checked
        End Get
        Set(ByVal value As Boolean)
            _Checked = value
        End Set
    End Property
    Public Sub New(ByVal keywordCode As String, ByVal keywordDescription As String, ByVal Checked As Boolean)
        Me.KeywordDescription = keywordDescription
        Me.KeywordCode = keywordCode
        Me.Checked = Checked
    End Sub
End Class