Imports TIMSS.API.Core
Imports Personify.ApplicationManager.Commons
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic
Imports Telerik.Web.UI

Public Class SubmissionHistory
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

#End Region

#Region "Controls"
    Protected WithEvents RadGridActivities As RadGrid
#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetupControls()
    End Sub

#End Region

#Region "Helper functions"

    Private Sub SetupControls()
        Dim oActivities As TIMSS.API.AbstractInfo.IAbstractSubmissionActivities = CallManager.GetSubmission(PortalId, CType(GetAbsSubId(), Integer)).AbstractSubmissionActivities

        Dim oWebActivities As New List(Of WEB_ACTIVITY)
        Dim oWebActivity As WEB_ACTIVITY
        For Each oActivity As TIMSS.API.AbstractInfo.IAbstractSubmissionActivity In oActivities
            oWebActivity = New WEB_ACTIVITY
            With oWebActivity
                .AbstractSubmissionActivityId = oActivity.AbstractSubmissionActivityId
                .NewAssignmentStatusCodeString = oActivity.NewAssignmentStatusCodeString
                .NewExternalStatusCodeString = oActivity.NewExternalStatusCodeString
                .NewInternalStatusCodeString = oActivity.NewInternalStatusCodeString
                .PreviousExternalStatusCodeString = oActivity.PreviousExternalStatusCodeString
                .PreviousInternalStatusCodeString = oActivity.PreviousInternalStatusCodeString
                If Not oActivity.ReviewerMasterCustomerId = "" Then
                    Dim Customer As TIMSS.API.CustomerInfo.ICustomer = SubmissionManager.GetCustomer(PortalId, oActivity.ReviewerMasterCustomerId, oActivity.ReviewerSubCustomerId)
                    .ReviewerName = Customer.LastFirstName
                Else
                    .ReviewerName = ""
                End If
                .ReviewProcessEventCodeString = oActivity.ReviewProcessEventCodeString
                .ReviewProcessEventDate = oActivity.ReviewProcessEventDate
            End With
            oWebActivities.Add(oWebActivity)
        Next

        RadGridActivities.DataSource = oWebActivities
        RadGridActivities.DataBind()
    End Sub

#End Region

#Region "Public Function"

#End Region



End Class
