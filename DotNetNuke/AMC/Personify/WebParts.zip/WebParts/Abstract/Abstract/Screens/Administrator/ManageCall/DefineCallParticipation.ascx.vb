
Imports ScreenController.AbstractScreen
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports PersonifyWebCommon

Public Class DefineCallParticipation
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Controls & Variables"

    Protected WithEvents butContinue As Button
    Protected WithEvents txtCallTitle As RadTextBox
    Protected WithEvents txtCallDescription As RadTextBox
    Protected WithEvents radCallComment As RadTextBox
    Protected WithEvents txtCallStartDate As RadDatePicker
    Protected WithEvents txtCallEndDate As RadDatePicker

    Protected WithEvents txtCallCode As RadTextBox
    Protected WithEvents ddlCallType As RadComboBox
    Protected WithEvents ddlExistingCalls As RadComboBox
    Protected WithEvents ddlMeetings As RadComboBox

    Protected WithEvents butContinueExistCall As Button    
    Protected WithEvents rfMeeting As RequiredFieldValidator    
    Protected WithEvents butUpdate As Button

    Protected WithEvents tblMain As System.Web.UI.HtmlControls.HtmlTable



#End Region

#Region "Properties"

    Public ReadOnly Property IsEditMode() As Boolean

        Get
            If GetAction() IsNot Nothing AndAlso GetAction.ToUpper = "EDIT" Then
                Return True
            End If
            Return False
        End Get
        
    End Property
#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            SetupControls()
        End If
    End Sub

    Private Sub butContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butContinue.Click

        
        If Not Page.IsValid Then
            ShowPopupMessage(Constants.Const_PageError_Meesage)
            Exit Sub
        End If

        Dim oWebCall As New CallManagerHelper.WEB_ABSCALL
        oWebCall.Title = txtCallTitle.Text
        oWebCall.Description = txtCallDescription.Text
        oWebCall.CallStartDate = txtCallStartDate.SelectedDate
        If Not txtCallEndDate.IsEmpty Then
            oWebCall.CallEndDate = txtCallEndDate.SelectedDate
        End If
        oWebCall.CallType = ddlCallType.SelectedValue
        oWebCall.CallCode = txtCallCode.Text.Trim
        oWebCall.Comments = Me.radCallComment.Text.Trim

        oWebCall.MeetingValue = Me.ddlMeetings.SelectedValue

        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection

        If GetArgs() Is Nothing Then
            oIssues = CallManager.ABSCALL_Create(PortalId, oWebCall)
        Else
            oIssues = CallManager.ABSCALL_Update(PortalId, oWebCall)
        End If

        If oIssues IsNot Nothing AndAlso oIssues.ErrorCount > 0 Then
            ShowPopupMessage(oIssues)
        Else
            GoToNextPage(Admin_SubmissionTypeSetup, oWebCall.CallCode, "", GetSubType)
        End If

    End Sub

    Private Sub butUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdate.Click
        If Not Page.IsValid Then
            ShowPopupMessage(Constants.Const_PageError_Meesage)
            Exit Sub
        End If

        Dim oWebCall As New CallManagerHelper.WEB_ABSCALL
        oWebCall.Title = txtCallTitle.Text
        oWebCall.Description = txtCallDescription.Text
        oWebCall.CallStartDate = txtCallStartDate.SelectedDate
        If Not txtCallEndDate.IsEmpty Then
            oWebCall.CallEndDate = txtCallEndDate.SelectedDate
        End If
        oWebCall.CallType = ddlCallType.SelectedValue
        oWebCall.CallCode = txtCallCode.Text 'need to let system generate this
        oWebCall.Comments = Me.radCallComment.Text

        oWebCall.MeetingValue = Me.ddlMeetings.SelectedValue

        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
        oIssues = CallManager.ABSCALL_Update(PortalId, oWebCall)

        If oIssues.ErrorCount > 0 Then
            ShowPopupMessage(oIssues)
        Else
            Me.GoToNextPage(HomePage, String.Empty, String.Empty)
            'ShowPopupMessage(Constants.Const_Save_Message)
        End If
    End Sub

    Private Sub butContinueExistCall_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butContinueExistCall.Click
        If ddlExistingCalls.SelectedIndex <> 0 Then
            GoToNextPage(Admin_SubmissionTypeSetup, Me.ddlExistingCalls.SelectedItem.Value, "")
        End If
    End Sub

    Private Sub ddlExistingCalls_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxItemEventArgs) Handles ddlExistingCalls.ItemDataBound

        e.Item.Text = (DirectCast(e.Item.DataItem, DataRowView))("AbstractCallCode").ToString()
        e.Item.Value = (DirectCast(e.Item.DataItem, DataRowView))("AbstractCallCode").ToString()

    End Sub

    Private Sub ddlMeetings_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxItemEventArgs) Handles ddlMeetings.ItemDataBound
        Dim oProduct As TIMSS.API.ProductInfo.IProduct

        oProduct = CType(e.Item.DataItem, TIMSS.API.ProductInfo.IProduct)

        Dim subsystem As String = oProduct.Subsystem.Code
        Dim productCode As String = oProduct.ProductCode
        Dim parentCode As String = oProduct.ParentProduct
        Dim productId As String = oProduct.ProductId

        e.Item.Value = FormatMeetingDropdownValue(productId, productCode, parentCode, subsystem)
    End Sub

    'Private Sub chkMeetingAssign_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkMeetingAssign.CheckedChanged

    '    If chkMeetingAssign.Checked Then
    '        Me.ddlMeetings.Visible = True
    '        rfMeeting.Enabled = True
    '    Else
    '        Me.ddlMeetings.Visible = False
    '        rfMeeting.Enabled = False
    '    End If
    'End Sub

#End Region

#Region "Helper functions"

    Private Sub SetupControls()

        'Bind Default controls
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        appCodes = GetApplicationCodes("ABS", "CALL_TYPE", True)
        ddlCallType.DataSource = appCodes
        ddlCallType.DataTextField = "Description"
        ddlCallType.DataValueField = "Code"
        ddlCallType.DataBind()
        ddlCallType.Items.Insert(0, New RadComboBoxItem(""))
        ddlCallType.SelectedValue = "MEETING"
        'End Binding Default Controls

        ''Dim callSource As DataTable
        ''callSource = CallManager.ABSCALLS_TABLE_GET(PortalId, True)
        ''ddlExistingCalls.DataSource = callSource
        ' ''ddlExistingCsalls.DataTextField = "AbstractCallCode"
        ' ''ddlExistingCalls.DataValueField = "AbstractCallCode"
        ''ddlExistingCalls.DataBind()   
        ''ddlExistingCalls.Items.Insert(0, New RadComboBoxItem(""))

        Dim meetingSource As TIMSS.API.ProductInfo.IProducts = CallManager.CallMeetingProducts_Get(PortalId)
        ddlMeetings.DataSource = meetingSource
        ddlMeetings.DataTextField = "ShortName"
        ddlMeetings.DataValueField = "ProductCode"
        ddlMeetings.DataBind()
        ddlMeetings.Items.Insert(0, New RadComboBoxItem(""))

        If GetArgs() IsNot Nothing Then
            Dim absCalls As TIMSS.API.AbstractInfo.IAbstractCalls
            Dim absCall As TIMSS.API.AbstractInfo.IAbstractCall

            absCalls = CallManager.ABSCALLS_GET(PortalId, GetArgs)
            If absCalls IsNot Nothing AndAlso absCalls.Count > 0 Then
                absCall = absCalls(0)

                With absCall
                    txtCallCode.Enabled = False
                    txtCallTitle.Text = .Title
                    txtCallCode.Text = .AbstractCallCode
                    txtCallDescription.Text = .Description
                    txtCallStartDate.SelectedDate = .CallStartDate
                    If Not isNullDate(.CallEndDate) Then
                        txtCallEndDate.SelectedDate = .CallEndDate
                    End If                    
                    Dim item As RadComboBoxItem = ddlCallType.FindItemByValue(.CallTypeCode.Code)
                    If item IsNot Nothing Then
                        item.Selected = True
                    End If

                    Dim meetingValue As String
                    meetingValue = FormatMeetingDropdownValue(.PrimaryProductId, .PrimaryProductCode, .PrimaryParentProduct, .PrimaryProductSubsystem)
                    item = Me.ddlMeetings.FindItemByValue(meetingValue)
                    If item IsNot Nothing Then
                        item.Selected = True
                    End If

                    radCallComment.Text = .Comments
                End With
              


                'If Not txtCallEndDate.IsEmpty Then
                '    oWebCall.CallEndDate = txtCallEndDate.SelectedDate
                'End If
                'oWebCall.CallType = "MEETING" 'need to pick
                'oWebCall.CallCode = Date.Now.Ticks
            End If
        End If


        If IsEditMode Then
            butContinue.Visible = False
            butUpdate.Visible = True
            txtCallCode.Enabled = False
        End If

    End Sub

    Private Function FormatMeetingDropdownValue(ByVal productId As String, ByVal productCode As String, ByVal parentCode As String, ByVal subsystem As String) As String

        Dim strValue As New System.Text.StringBuilder
        strValue.Append(productId)
        strValue.Append("|")
        strValue.Append(productCode)
        strValue.Append("|")
        strValue.Append(parentCode)
        strValue.Append("|")
        strValue.Append(subsystem)

        Return strValue.ToString
    End Function

#End Region







End Class
