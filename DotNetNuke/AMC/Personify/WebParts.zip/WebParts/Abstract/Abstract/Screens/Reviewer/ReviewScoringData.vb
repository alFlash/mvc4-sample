Public Class ReviewScoringData

    Private _AbstractCallSubmissionTypeScoringControlId As Integer = 0
    Public Property AbstractCallSubmissionTypeScoringControlId() As Integer
        Get
            Return _AbstractCallSubmissionTypeScoringControlId
        End Get
        Set(ByVal value As Integer)
            _AbstractCallSubmissionTypeScoringControlId = value
        End Set
    End Property

    Private _AnswerTypeCodeString As String
    Public Property AnswerTypeCodeString() As String
        Get
            Return _AnswerTypeCodeString
        End Get
        Set(ByVal value As String)
            _AnswerTypeCodeString = value
        End Set
    End Property

    Private _ScoringAnswerCodeString As String
    Public Property ScoringAnswerCodeString() As String
        Get
            Return _ScoringAnswerCodeString
        End Get
        Set(ByVal value As String)
            _ScoringAnswerCodeString = value
        End Set
    End Property


    Private _SubmissionScoringCriterionDescription As String
    Public Property SubmissionScoringCriterionDescription() As String
        Get
            Return _SubmissionScoringCriterionDescription
        End Get
        Set(ByVal value As String)
            _SubmissionScoringCriterionDescription = value
        End Set
    End Property



    Private _ScoringCriterionCodeString As String
    Public Property ScoringCriterionCodeString() As String
        Get
            Return _ScoringCriterionCodeString
        End Get
        Set(ByVal value As String)
            _ScoringCriterionCodeString = value
        End Set
    End Property

    Private _AllowCommentsFlag As Boolean
    Public Property AllowCommentsFlag() As Boolean
        Get
            Return _AllowCommentsFlag
        End Get
        Set(ByVal value As Boolean)
            _AllowCommentsFlag = value
        End Set
    End Property


    Private _ScoringAnswerSubcode As String
    Public Property ScoringAnswerSubcode() As String
        Get
            Return _ScoringAnswerSubcode
        End Get
        Set(ByVal value As String)
            _ScoringAnswerSubcode = value
        End Set
    End Property


    Private _ScoringAnswerText As String
    Public Property ScoringAnswerText() As String
        Get
            Return _ScoringAnswerText
        End Get
        Set(ByVal value As String)
            _ScoringAnswerText = value
        End Set
    End Property



    Private _Comments As String
    Public Property Comments() As String
        Get
            Return _Comments
        End Get
        Set(ByVal value As String)
            _Comments = value
        End Set
    End Property
   

End Class
