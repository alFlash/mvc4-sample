Imports TIMSS.SQLObjects
Imports ScreenController.AbstractScreen

Public Class Reviewer_Search
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents TextBoxFirstName As TextBox
    Protected WithEvents TextBoxFirstName2 As TextBox
    Protected WithEvents TextBoxLastName As TextBox
    Protected WithEvents TextBoxLastName2 As TextBox

    Protected WithEvents RadComboBoxAprovedFor As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxAreaOfExpertise As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxLevelOfExpertise As Telerik.Web.UI.RadComboBox

    Protected WithEvents LinkButtonClearSearch As LinkButton
    Protected WithEvents LinkButtonClearSearch2 As LinkButton

    Protected WithEvents LinkButtonSearch As LinkButton
    Protected WithEvents LinkButtonSearch2 As LinkButton

    Protected WithEvents RadGrid1 As Telerik.Web.UI.RadGrid
    Protected WithEvents RadGrid2 As Telerik.Web.UI.RadGrid

    Protected WithEvents RadGridAreaOfExpertise As Telerik.Web.UI.RadGrid

    Protected WithEvents RadGridCallSubmissionType As Telerik.Web.UI.RadGrid

    Protected WithEvents LinkButtonCreateReviewers As LinkButton
    Protected WithEvents LinkButtonAssignReviewers As LinkButton
    Protected WithEvents LinkButtonAssignReviewersDirectly As LinkButton

    Protected WithEvents DropDownListApprovedFor As Telerik.Web.UI.RadComboBox
    Protected WithEvents DropDownListRoleCode As Telerik.Web.UI.RadComboBox

    Protected WithEvents RadDatePickerTermBegin As Telerik.Web.UI.RadDatePicker
    Protected WithEvents RadDatePickerTermEnd As Telerik.Web.UI.RadDatePicker
    Protected WithEvents RadDatePickerSearch As Telerik.Web.UI.RadDatePicker

    Protected WithEvents AssignReviewersPanel As Panel
    Protected WithEvents CreateReviewersPanel As Panel

    Protected WithEvents RadTabStrip1 As Telerik.Web.UI.RadTabStrip
    Protected WithEvents RadToolTip1 As Telerik.Web.UI.RadToolTip

    Protected WithEvents lblReviewerAdded As Label

    Protected WithEvents CustomValidatorCustomerSearch As CustomValidator

    Protected WithEvents RadDatePickerTermBeginValidator As RequiredFieldValidator
    Protected WithEvents RadDatePickerTermEndValidator As RequiredFieldValidator
    Protected WithEvents but2 As Button
    Protected WithEvents but3 As Button
    Protected WithEvents t2 As Telerik.Web.UI.RadToolTip
    Protected WithEvents t3 As Telerik.Web.UI.RadToolTip
    Protected WithEvents RadToolTip12 As Telerik.Web.UI.RadToolTip

#End Region


#Region "Events"

    Private AbstractCallCode As String
    Private SubmissionTypeCode As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        AbstractCallCode = Request("args")
        SubmissionTypeCode = Request("type")

        If Not Page.IsPostBack Then    
            RadDatePickerSearch.SelectedDate = DateTime.Now.AddMonths(12)

            Dim ExpertisesDT As DataTable = New DataTable()
            ExpertisesDT.Columns.Add("Area", Type.GetType("System.String"))
            ExpertisesDT.Columns.Add("AreaCode", Type.GetType("System.String"))
            ExpertisesDT.Columns.Add("AreaSubcode", Type.GetType("System.String"))

            Dim row As DataRow

            Dim Expertises As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                         GetApplicationCodes("ABS", "EXPERTISE", True)
            If Expertises IsNot Nothing AndAlso Expertises.Count > 0 Then
                For Each Expertise As TIMSS.API.ApplicationInfo.IApplicationCode In Expertises

                    If Expertise.Subcodes IsNot Nothing AndAlso Expertise.Subcodes.Count > 0 Then

                        For Each ExpertiseSubcode As TIMSS.API.ApplicationInfo.IApplicationSubcode In Expertise.Subcodes
                            row = ExpertisesDT.NewRow()
                            row("Area") = Expertise.Description + " - " + ExpertiseSubcode.Description
                            row("AreaCode") = Expertise.Code
                            row("AreaSubcode") = ExpertiseSubcode.Description
                            ExpertisesDT.Rows.Add(row)
                        Next

                    Else

                        row = ExpertisesDT.NewRow()
                        row("Area") = Expertise.Description + " - ExpertiseSubcode missing ???"
                        row("AreaCode") = Expertise.Code
                        row("AreaSubcode") = "ExpertiseSubcode missing"
                        ExpertisesDT.Rows.Add(row)

                        RadGridAreaOfExpertise.Enabled = False

                    End If
                Next

                RadComboBoxAreaOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
                For Each Expertise As TIMSS.API.ApplicationInfo.IApplicationCode In Expertises
                    RadComboBoxAreaOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem(Expertise.Description.ToString, Expertise.Code))
                Next
            End If

            RadGridAreaOfExpertise.DataSource = ExpertisesDT
            RadGridAreaOfExpertise.DataBind()

            Dim ExpertiseLevels As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                GetApplicationCodes("ABS", "EXPERTISE_LEVEL", True)
            If ExpertiseLevels IsNot Nothing AndAlso ExpertiseLevels.Count > 0 Then
                For Each dataitem As Telerik.Web.UI.GridDataItem In RadGridAreaOfExpertise.Items
                    Dim DropDownLevel As DropDownList = dataitem.FindControl("DropDownLevel")
                    For Each ExpertiseLevel As TIMSS.API.ApplicationInfo.IApplicationCode In ExpertiseLevels
                        DropDownLevel.Items.Add(New ListItem(ExpertiseLevel.Description.ToString, ExpertiseLevel.Code))
                    Next
                Next

                RadComboBoxLevelOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
                For Each ExpertiseLevel As TIMSS.API.ApplicationInfo.IApplicationCode In ExpertiseLevels
                    RadComboBoxLevelOfExpertise.Items.Add(New Telerik.Web.UI.RadComboBoxItem(ExpertiseLevel.Description.ToString, ExpertiseLevel.Code))
                Next
            End If


            RadDatePickerTermBegin.SelectedDate = DateTime.Now
            RadDatePickerTermEnd.SelectedDate = DateTime.Now.AddMonths(12)

            ' SetupCustomerCreateReviewerContent()
            ' SetupReviewerAssignedContent()



        End If
    End Sub

#End Region


#Region "Helper functions"

    Private Sub SetupCustomerCreateReviewerContent()

        If RadComboBoxAprovedFor.Items.Count = 0 Then
            Dim AprovedFors As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                    GetApplicationCodes("ABS", "REVIEWER_APPROVED_FOR", True)
            If AprovedFors IsNot Nothing AndAlso AprovedFors.Count > 0 Then
                RadComboBoxAprovedFor.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
                For Each AprovedFor As TIMSS.API.ApplicationInfo.IApplicationCode In AprovedFors
                    DropDownListApprovedFor.Items.Add(New Telerik.Web.UI.RadComboBoxItem(AprovedFor.Description.ToString, AprovedFor.Code))
                    RadComboBoxAprovedFor.Items.Add(New Telerik.Web.UI.RadComboBoxItem(AprovedFor.Description.ToString, AprovedFor.Code))
                Next
            End If
        End If
        
        If DropDownListRoleCode.Items.Count = 0 Then
            Dim RoleCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = _
            GetApplicationCodes("ABS", "REVIEWER_ROLE", True)
            If RoleCodes IsNot Nothing Then
                For Each RoleCode As TIMSS.API.ApplicationInfo.IApplicationCode In RoleCodes
                    DropDownListRoleCode.Items.Add(New Telerik.Web.UI.RadComboBoxItem(RoleCode.Description.ToString, RoleCode.Code))
                Next
            End If
        End If
        
        RadDatePickerTermEnd.Attributes.Add("Style", "Z-Index:42222")
    End Sub

    Private Sub SetupReviewerAssignedContent()

        Dim CallDT As DataTable = New DataTable()
        CallDT.Columns.Add("CallSubmissionType", Type.GetType("System.String"))
        CallDT.Columns.Add("Call", Type.GetType("System.String"))
        CallDT.Columns.Add("CallTitle", Type.GetType("System.String"))
        CallDT.Columns.Add("SubmissionType", Type.GetType("System.String"))
        CallDT.Columns.Add("SubmissionTypeDescription", Type.GetType("System.String"))

        Dim callrow As DataRow
        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls
        oABSCalls = CallManager.GetCallAndSubmissionType(PortalId)
        If oABSCalls IsNot Nothing AndAlso oABSCalls.Count > 0 Then
            For Each oABSCall As TIMSS.API.AbstractInfo.IAbstractCall In oABSCalls
                If (oABSCall.CallEndDate = Date.MinValue OrElse oABSCall.CallEndDate >= TIMSS.Global.App.ServerDateTime.Date) Then
                    If oABSCall IsNot Nothing AndAlso oABSCall.AbstractCallSubmissionTypes IsNot Nothing AndAlso oABSCall.AbstractCallSubmissionTypes.Count > 0 Then
                        For Each oAbstractCallSubmissionType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType In oABSCall.AbstractCallSubmissionTypes

                            If String.IsNullOrEmpty(AbstractCallCode) OrElse String.IsNullOrEmpty(SubmissionTypeCode) OrElse _
(String.Compare(AbstractCallCode, oABSCall.AbstractCallCode, True) = 0 AndAlso String.Compare(SubmissionTypeCode, oAbstractCallSubmissionType.SubmissionTypeCodeString, True) = 0) Then

                                callrow = CallDT.NewRow()
                                callrow("Call") = oABSCall.AbstractCallCode
                                callrow("SubmissionType") = oAbstractCallSubmissionType.SubmissionTypeCode

                                callrow("CallTitle") = oABSCall.Title
                                callrow("SubmissionTypeDescription") = oAbstractCallSubmissionType.Description

                                callrow("CallSubmissionType") = oABSCall.Title + " - " + oAbstractCallSubmissionType.Description
                                CallDT.Rows.Add(callrow)

                            End If

                        Next
                    End If
                End If
            Next
        End If

        RadGridCallSubmissionType.DataSource = CallDT
        RadGridCallSubmissionType.DataBind()
        If Not String.IsNullOrEmpty(AbstractCallCode) AndAlso Not String.IsNullOrEmpty(SubmissionTypeCode) Then
            RadGridCallSubmissionType.Items(0).Selected = True
        End If
    End Sub

#End Region

    Protected Sub LinkButtonAssignReviewers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonAssignReviewers.Click



        Dim success As Boolean = True

        Dim ReviewersArray As New ArrayList
        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGrid1.SelectedItems
            Dim MasterCustomerId As String = dataitem("MasterCustomerId").Text
            Dim SubCustomerId As Integer = dataitem("SubCustomerId").Text
            Dim r As New CallManagerHelper.Reviewer
            r.MasterCustomerId = MasterCustomerId
            r.SubCustomerId = SubCustomerId
            ReviewersArray.Add(r)
        Next

        Dim Reviewers(ReviewersArray.Count - 1) As CallManagerHelper.Reviewer
        ReviewersArray.CopyTo(Reviewers)


        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
        oIssues = Nothing

        'change this to one call
        'now it stops after first error

        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGridCallSubmissionType.SelectedItems

            Dim AbstractCallCode As String = dataitem("Call").Text
            Dim ReviewTypeCode As String = dataitem("SubmissionType").Text

            oIssues = CallManager.CreateSubmissionTypeReviewer(PortalId, AbstractCallCode, ReviewTypeCode, Reviewers)
            If oIssues IsNot Nothing Then
                success = False
                Exit For
            End If
        Next


        If success = True AndAlso oIssues Is Nothing Then
            'lblReviewerAdded.Text = Constants.Const_SubmissionTypeReviewer_Added
            ShowPopupMessage(Constants.Const_SubmissionTypeReviewer_Added)
        Else
            'lblReviewerAdded.Text = Constants.Const_SubmissionTypeReviewerError_Added
            ShowPopupMessage(oIssues)
        End If
        Exit Sub




    End Sub

    Protected Sub LinkButtonCreateReviewers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonCreateReviewers.Click

        RadDatePickerTermBeginValidator.Validate()
        RadDatePickerTermEndValidator.Validate()
        If Page.IsValid Then
            Dim Reviewers() As CallManagerHelper.Reviewer = Nothing
            Dim aor As New ArrayList
            For Each dataitem As Telerik.Web.UI.GridDataItem In RadGrid2.SelectedItems
                Dim oReviewer As New CallManagerHelper.Reviewer
                oReviewer.MasterCustomerId = dataitem("MasterCustomerId").Text
                oReviewer.SubCustomerId = Convert.ToInt32(dataitem("SubCustomerId").Text)
                aor.Add(oReviewer)
            Next

            Dim ReviewersTemp(aor.Count - 1) As CallManagerHelper.Reviewer
            aor.CopyTo(ReviewersTemp)
            Reviewers = ReviewersTemp

            Dim AreaOfExpertises() As CallManagerHelper.AreaOfExpertise = Nothing
            Dim aoes As New ArrayList
            For Each aoedataitem As Telerik.Web.UI.GridDataItem In RadGridAreaOfExpertise.SelectedItems
                Dim aoe As New CallManagerHelper.AreaOfExpertise
                aoe.ExpertiseCode = aoedataitem.Item("AreaCode").Text
                aoe.ExpertiseSubcode = aoedataitem.Item("AreaSubcode").Text

                Dim DropDownLevel As DropDownList = aoedataitem.FindControl("DropDownLevel")
                aoe.ExpertiseLevelCode = DropDownLevel.SelectedValue
                aoes.Add(aoe)
            Next
            Dim AreaOfExpertisesTemp(aoes.Count - 1) As CallManagerHelper.AreaOfExpertise
            aoes.CopyTo(AreaOfExpertisesTemp)
            AreaOfExpertises = AreaOfExpertisesTemp

            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.CreateReviewer(PortalId, Reviewers, DropDownListApprovedFor.SelectedValue, DropDownListRoleCode.SelectedValue, RadDatePickerTermBegin.SelectedDate, RadDatePickerTermEnd.SelectedDate, AreaOfExpertises)
            If oIssues Is Nothing Then
                GoToNextPage(ScreenController.AbstractScreen.Reviewer_Search, "", "")
            Else
                ShowPopupMessage(oIssues)
            End If

        End If
    End Sub

    Private Sub FillGrid1()
        If RadTabStrip1.SelectedIndex = 0 Then
            If IsPostBack Then
                Dim oGetReviewersData As ICollection = GetReviewersData()



                'filter users if we know the call
                'If Not String.IsNullOrEmpty(AbstractCallCode) AndAlso Not String.IsNullOrEmpty(SubmissionTypeCode) Then

                '    Dim tempGetReviewersData As New ArrayList

                '    Dim sourceTable As DataTable = ReviewManager.ABS_SubmissionTypeReviewers_Get(PortalId, GetArgs, GetSubType)

                '    For Each datarow As ReviewerSearchData In oGetReviewersData

                '        If sourceTable IsNot Nothing AndAlso sourceTable.Rows IsNot Nothing AndAlso sourceTable.Rows.Count > 0 Then
                '            Dim include As Boolean = True
                '            For Each reviewerrow As System.Data.DataRow In sourceTable.Rows
                '                If Convert.ToInt32(reviewerrow("AbstractCallSubmissionTypeReviewerId")) = datarow.MasterCustomerId Then
                '                    include = False
                '                End If
                '            Next
                '            If include Then
                '                tempGetReviewersData.Add(datarow)
                '            End If
                '        End If
                '    Next
                '    oGetReviewersData = CType(tempGetReviewersData, ICollection)

                'End If

                RadGrid1.DataSource = oGetReviewersData

                If GetReviewersData.Count > 0 Then
                    If Not String.IsNullOrEmpty(AbstractCallCode) AndAlso Not String.IsNullOrEmpty(SubmissionTypeCode) Then
                        LinkButtonAssignReviewersDirectly.Visible = True
                        AssignReviewersPanel.Visible = False
                    Else
                        LinkButtonAssignReviewersDirectly.Visible = False
                        AssignReviewersPanel.Visible = True
                    End If
                Else
                    AssignReviewersPanel.Visible = False
                    LinkButtonAssignReviewersDirectly.Visible = True
                End If
            End If

        End If
    End Sub

    Protected Sub LinkButtonSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSearch.Click
        FillGrid1()
        RadGrid1.DataBind()
        RadGrid2.DataSource = Nothing
        CreateReviewersPanel.Visible = False
        RadGrid2.DataBind()
        SetupReviewerAssignedContent()
    End Sub

    Private Sub RadGrid1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGrid1.NeedDataSource
        FillGrid1()
    End Sub

    Private Sub FillGrid2()
        If RadTabStrip1.SelectedIndex = 1 Then
            If IsPostBack Then
                Dim oGetCustomerData As ICollection = GetCustomerData()
                RadGrid2.DataSource = oGetCustomerData

                If oGetCustomerData.Count > 0 Then
                    CreateReviewersPanel.Visible = True
                Else
                    CreateReviewersPanel.Visible = False
                End If

            End If
        End If
    End Sub

    Protected Sub LinkButtonSearch2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSearch2.Click

        'CustomValidatorCustomerSearch.Validate()

        If Page.IsValid Then

            SetupCustomerCreateReviewerContent()
            FillGrid2()
            RadGrid2.DataBind()
            RadGrid1.DataSource = Nothing
            AssignReviewersPanel.Visible = False
            RadGrid1.DataBind()
        Else
            RadGrid2.DataSource = Nothing
            RadGrid2.DataBind()
            CreateReviewersPanel.Visible = False
        End If

    End Sub

    Private Sub RadGrid2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGrid2.NeedDataSource

        If Not (String.IsNullOrEmpty(TextBoxFirstName2.Text) AndAlso String.IsNullOrEmpty(TextBoxLastName2.Text)) Then
            FillGrid2()
        End If

    End Sub

    Protected Sub LinkButtonClearSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonClearSearch.Click
        TextBoxFirstName.Text = ""
        TextBoxLastName.Text = ""
        RadDatePickerSearch.SelectedDate = DateTime.Now.AddMonths(12)
        RadComboBoxAprovedFor.SelectedIndex = 0
        RadComboBoxAreaOfExpertise.SelectedIndex = 0
        RadComboBoxLevelOfExpertise.SelectedIndex = 0
        RadGrid1.DataSource = Nothing
        RadGrid1.DataBind()
        AssignReviewersPanel.Visible = False
        RadGrid2.DataSource = Nothing
        RadGrid2.DataBind()
        CreateReviewersPanel.Visible = False
    End Sub

    Protected Sub LinkButtonClearSearch2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonClearSearch2.Click

        'CustomValidatorCustomerSearch.Validate()
        'If Page.IsValid Then

        TextBoxFirstName2.Text = ""
        TextBoxLastName2.Text = ""

        RadGrid1.DataSource = Nothing
        RadGrid1.DataBind()
        AssignReviewersPanel.Visible = False

        RadGrid2.DataSource = Nothing
        RadGrid2.DataBind()
        CreateReviewersPanel.Visible = False
        'End If

    End Sub

    Public Function GetReviewersData() As ICollection
        Dim list As ArrayList = New ArrayList()

        Dim oAbstractReviewers As IQueryResult
        If RadDatePickerSearch.SelectedDate.HasValue Then
            oAbstractReviewers = CallManager.GetReviewersSearch(PortalId, TextBoxFirstName.Text, TextBoxLastName.Text, RadComboBoxAprovedFor.SelectedValue, RadComboBoxAreaOfExpertise.SelectedValue, RadComboBoxLevelOfExpertise.SelectedValue, RadDatePickerSearch.SelectedDate)
        Else
            oAbstractReviewers = CallManager.GetReviewersSearch(PortalId, TextBoxFirstName.Text, TextBoxLastName.Text, RadComboBoxAprovedFor.SelectedValue, RadComboBoxAreaOfExpertise.SelectedValue, RadComboBoxLevelOfExpertise.SelectedValue, Nothing)
        End If

        If oAbstractReviewers.Success = False OrElse Not oAbstractReviewers.ValidationMessages.Count > 0 Then

            If oAbstractReviewers IsNot Nothing AndAlso oAbstractReviewers.DataSet IsNot Nothing AndAlso oAbstractReviewers.DataSet.Tables IsNot Nothing AndAlso oAbstractReviewers.DataSet.Tables.Count > 0 AndAlso oAbstractReviewers.DataSet.Tables(0).Rows IsNot Nothing AndAlso oAbstractReviewers.DataSet.Tables(0).Rows.Count > 0 Then

                Dim Expertise As String = ""
                Dim LevelOfExpertise As String = ""
                For i As Integer = 0 To oAbstractReviewers.DataSet.Tables(0).Rows.Count - 1

                    Dim includeRow As Boolean = True
                    If i < oAbstractReviewers.DataSet.Tables(0).Rows.Count - 1 Then

                        Dim currentMasterCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i)("master_customer_id")
                        Dim currentSubCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i)("sub_customer_id")

                        Dim nextMasterCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i + 1)("master_customer_id")
                        Dim nextSubCustomerId As String = oAbstractReviewers.DataSet.Tables(0).Rows(i + 1)("sub_customer_id")

                        If currentMasterCustomerId = nextMasterCustomerId AndAlso currentSubCustomerId = nextSubCustomerId Then
                            includeRow = False
                            Expertise += oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_code") + " - " + oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_subcode") + "<BR>"
                            LevelOfExpertise += Convert.ToString(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_level_code")) + "<BR>"
                        End If

                    End If

                    If includeRow = True Then

                        Dim row As ReviewerSearchData = New ReviewerSearchData()
                        row.MasterCustomerId = oAbstractReviewers.DataSet.Tables(0).Rows(i)("master_customer_id")
                        row.SubCustomerId = oAbstractReviewers.DataSet.Tables(0).Rows(i)("sub_customer_id")
                        row.Name = oAbstractReviewers.DataSet.Tables(0).Rows(i)("last_first_name")
                        row.Link = NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_Work_with_Reviewer & "&mcid=" & row.MasterCustomerId.ToString & "&scid=" & row.SubCustomerId.ToString)

                        'If oCustomers.DataSet.Tables(0).Columns.IndexOf("Institution") >= 0 Then
                        If Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("Institution")) Then
                            row.Institution = Convert.ToString(oAbstractReviewers.DataSet.Tables(0).Rows(i)("Institution"))
                        End If

                        'row.AverageScore = "no idea" ' not anymore
                        'row.Completed = "no idea"
                        If Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_code")) AndAlso Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_subcode")) Then
                            row.Expertise = Expertise + oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_code") + " - " + _
                            oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_subcode")
                        End If

                        If Not IsDBNull(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_level_code")) Then
                            row.LevelOfExpertise = LevelOfExpertise + Convert.ToString(oAbstractReviewers.DataSet.Tables(0).Rows(i)("expertise_level_code"))
                        End If

                        'row.OpenReviews = "no idea"

                        list.Add(row)

                        Expertise = ""
                        LevelOfExpertise = ""
                    End If
                Next
            End If
        End If
        Return list

    End Function


    Public Function GetCustomerData() As ICollection

        Dim list As ArrayList = New ArrayList()

        Dim oCustomers As IQueryResult

        oCustomers = CallManager.GetCustomerSearch(PortalId, TextBoxFirstName2.Text, TextBoxLastName2.Text)

        If oCustomers.Success = False OrElse Not oCustomers.ValidationMessages.Count > 0 Then

            If oCustomers IsNot Nothing AndAlso oCustomers.DataSet IsNot Nothing AndAlso oCustomers.DataSet.Tables IsNot Nothing AndAlso oCustomers.DataSet.Tables.Count > 0 AndAlso oCustomers.DataSet.Tables(0).Rows IsNot Nothing AndAlso oCustomers.DataSet.Tables(0).Rows.Count > 0 Then
                For i As Integer = 0 To oCustomers.DataSet.Tables(0).Rows.Count - 1
                    Dim row As ReviewerSearchData = New ReviewerSearchData()

                    row.MasterCustomerId = oCustomers.DataSet.Tables(0).Rows(i)("master_customer_id")
                    row.SubCustomerId = oCustomers.DataSet.Tables(0).Rows(i)("sub_customer_id")
                    row.Name = oCustomers.DataSet.Tables(0).Rows(i)("last_first_name")

                    'If oCustomers.DataSet.Tables(0).Columns.IndexOf("Institution") >= 0 Then
                    If Not IsDBNull(oCustomers.DataSet.Tables(0).Rows(i)("Institution")) Then
                        row.Institution = Convert.ToString(oCustomers.DataSet.Tables(0).Rows(i)("Institution"))
                    End If
                    'End If
                    list.Add(row)
                Next
            End If
        Else
            'error
        End If
        Return list
    End Function


    Protected Sub CustomValidatorCustomerSearch_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidatorCustomerSearch.ServerValidate
        args.IsValid = Not (String.IsNullOrEmpty(TextBoxFirstName2.Text) AndAlso String.IsNullOrEmpty(TextBoxLastName2.Text))
    End Sub

   
End Class
