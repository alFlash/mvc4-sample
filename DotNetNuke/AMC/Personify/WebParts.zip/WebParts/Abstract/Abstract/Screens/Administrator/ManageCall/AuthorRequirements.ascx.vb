
Imports ScreenController.AbstractScreen
Imports Constants
Imports Telerik.Web.UI

Public Class AuthorRequirements
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables # Properties"
    Private _LargestSeq As Integer
    Private _SubmissionsExist As Boolean


    Public ReadOnly Property SubmissionAuthorDisclosureExist() As Boolean
        Get
            If _LargestSeq > 0 Then
                Return True
            End If
            Return False
        End Get
    End Property

#End Region

#Region "Controls"

    Protected WithEvents btnContinue As Button
    Protected WithEvents btnPrevious As Button
    Protected WithEvents RadEditorInstructions As Telerik.Web.UI.RadEditor
    Protected WithEvents RadGridAuthorDisclosureQuestions As Telerik.Web.UI.RadGrid
    Protected WithEvents odsDisclosureRelationshipCode As ObjectDataSource
    Protected WithEvents lblAuthorRole As Label
    Protected WithEvents rbtnValidatePrimaryAuthorYes As RadioButton
    Protected WithEvents rbtnValidatePrimaryAuthorNo As RadioButton
    Protected WithEvents ddlDefinitionStoredProcedure As DropDownList
    Protected WithEvents ReorderChanges As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents rbtnAllowPrimaryViewAbsYes As RadioButton
    Protected WithEvents rbtnAllowPrimaryViewAbsNo As RadioButton
    Protected WithEvents rbtnPrimaryAuthorMustBeMemberYes As RadioButton
    Protected WithEvents rbtnPrimaryAuthorMustBeMemberNo As RadioButton
    Protected WithEvents butUpdate As Button
    Protected WithEvents lblCallCode As Label
    Protected WithEvents lblTitlePage As Label
    Protected WithEvents ddlRelationship As RadComboBox
    Protected WithEvents textQuestion As TextBox
    Private shouldDisableCommandItem As Boolean
    Private shouldDisableEditItems As Boolean
#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            SetupControls()
        Else
            InitializeControls()
        End If
    End Sub

    Private Sub btnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click

        If Page.IsValid AndAlso SubmissionAuthorDisclosureExist Then
            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()

            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)
            If oIssues.ErrorCount > 0 Then
                ShowPopupMessage(oIssues)
            Else
                GoToNextPage(Admin_MaterialsRequirements, GetArgs, "", GetSubType)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_AuthorRequirement)
        End If
    End Sub

    Private Sub butUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdate.Click

        If Page.IsValid AndAlso SubmissionAuthorDisclosureExist Then
            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)
            If oIssues.ErrorCount > 0 Then
                ShowPopupMessage(oIssues)
            Else
                Me.RadGridAuthorDisclosureQuestions.Rebind()
                ShowPopupMessage(Const_Save_Message)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_AuthorRequirement)
        End If
    End Sub

    Private Sub btnPrevious_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        GoToNextPage(Admin_SubmissionTypeSetup, GetArgs, "", GetSubType)
    End Sub

    Private Sub RadGridAuthorDisclosureQuestions_DeleteCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridAuthorDisclosureQuestions.DeleteCommand
        Dim ID As String = RadGridAuthorDisclosureQuestions.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeAuthorDisclosureControlId").Text
        Dim QuestionSeq As String = RadGridAuthorDisclosureQuestions.Items(e.Item.ItemIndex)("QuestionSequence").Text

        If CallManager.ABSSubmissionType_DeleteAuthorDisclosureQuestion(PortalId, ID, QuestionSeq, GetArgs, GetSubType).ErrorCount > 0 Then
            e.Canceled = True
        Else
            InitializeControls()
        End If
    End Sub

    Private Sub RadGridAuthorDisclosureQuestions_InsertCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridAuthorDisclosureQuestions.InsertCommand
        Dim editedItem As Telerik.Web.UI.GridEditableItem = CType(e.Item, Telerik.Web.UI.GridEditableItem)

        Dim newValues As Hashtable = New Hashtable
        'The GridTableView will fill the values from all editable columns in the hash
        e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editedItem)
        Dim DisclosureQuestion As New AuthorDisclosureQuestionsData

        Try
            'For Each entry As DictionaryEntry In newValues
            '    Select Case entry.Key.ToString
            '        Case "QuestionText"
            '            DisclosureQuestions.QuestionText = entry.Value.ToString
            '        Case "DisclosureRelationshipCodeString"
            '            DisclosureQuestions.DisclosureRelationshipCode = entry.Value.ToString
            '    End Select
            'Next

            Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
            Dim ddlRelationship As RadComboBox = DirectCast(editItem.FindControl("ddlRelationship"), RadComboBox)
            Dim textQuestion As TextBox = DirectCast(editItem.FindControl("textQuestion"), TextBox)

            DisclosureQuestion.QuestionText = textQuestion.Text
            If ddlRelationship.Text <> "" Then
                DisclosureQuestion.DisclosureRelationshipCode = ddlRelationship.SelectedItem.Value
            End If

            If CreateAuthorDisclosureQuestions(DisclosureQuestion).ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try

    End Sub

    Private Sub RadGridAuthorDisclosureQuestions_UpdateCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridAuthorDisclosureQuestions.UpdateCommand
        Dim editedItem As Telerik.Web.UI.GridEditableItem = TryCast(e.Item, Telerik.Web.UI.GridEditableItem)

        Dim newValues As Hashtable = New Hashtable
        'The GridTableView will fill the values from all editable columns in the hash
        e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editedItem)
        Dim DisclosureQuestion As New AuthorDisclosureQuestionsData

        Try
            'For Each entry As DictionaryEntry In newValues
            '    Select Case entry.Key.ToString
            '        Case "QuestionText"
            '            DisclosureQuestion.QuestionText = entry.Value.ToString
            '        Case "DisclosureRelationshipCodeString"
            '            DisclosureQuestion.DisclosureRelationshipCode = entry.Value.ToString
            '    End Select
            'Next

            Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
            Dim ddlRelationship As RadComboBox = DirectCast(editItem.FindControl("ddlRelationship"), RadComboBox)
            Dim textQuestion As TextBox = DirectCast(editItem.FindControl("textQuestion"), TextBox)

            DisclosureQuestion.QuestionText = textQuestion.Text
            If ddlRelationship.Text <> "" Then
                DisclosureQuestion.DisclosureRelationshipCode = ddlRelationship.SelectedItem.Value
            End If

            DisclosureQuestion.AbstractCallCode = GetArgs()
            DisclosureQuestion.SubmissionTypeCode = GetSubType()
            DisclosureQuestion.AuthorDisclosureControlId = RadGridAuthorDisclosureQuestions.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeAuthorDisclosureControlId").Text
            If CallManager.ABSSubmissionType_UpdateAuthorDisclosureQuestion(PortalId, DisclosureQuestion).ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Private Sub rbtnValidatePrimaryAuthorYes_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnValidatePrimaryAuthorYes.CheckedChanged
        If Not ddlDefinitionStoredProcedure.Enabled = rbtnValidatePrimaryAuthorYes.Checked Then
            ddlDefinitionStoredProcedure.Enabled = rbtnValidatePrimaryAuthorYes.Checked
        End If
    End Sub

    Private Sub rbtnValidatePrimaryAuthorNo_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnValidatePrimaryAuthorNo.CheckedChanged
        If ddlDefinitionStoredProcedure.Enabled = rbtnValidatePrimaryAuthorNo.Checked Then
            ddlDefinitionStoredProcedure.Enabled = Not rbtnValidatePrimaryAuthorNo.Checked
        End If
    End Sub

    Protected Sub RadGridAuthorDisclosureQuestions_ItemCreated(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridAuthorDisclosureQuestions.ItemCreated
        If TypeOf e.Item Is GridCommandItem Then
            Dim commandItem As GridCommandItem = CType(e.Item, GridCommandItem)
            Dim RebindButton As LinkButton
            Dim RefreshButton As Button
            Dim NewButton As Button
            NewButton = CType(commandItem.FindControl("AddNewRecordButton"), Button)
            NewButton.Visible = False
            RebindButton = CType(commandItem.FindControl("RebindGridButton"), LinkButton)
            RebindButton.Visible = False
            RefreshButton = CType(commandItem.FindControl("RefreshButton"), Button)
            RefreshButton.Visible = False
        End If
    End Sub

    Protected Sub RadGridAuthorDisclosureQuestions_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridAuthorDisclosureQuestions.ItemDataBound
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then
            Dim Item As GridEditableItem = DirectCast(e.Item, GridEditableItem)
            ddlRelationship = DirectCast(Item.FindControl("ddlRelationship"), RadComboBox)
            textQuestion = DirectCast(Item.FindControl("textQuestion"), TextBox)
            GetRelationships(ddlRelationship)
            If Not e.Item.OwnerTableView.IsItemInserted Then
                ddlRelationship.Items.FindItemByText(Item("DisclosureRelationshipCodeString").Text).Selected = True
                If Not Item("QuestionText").Text = "&nbsp;" Then
                    textQuestion.Text = Item("QuestionText").Text
                Else
                    textQuestion.Text = String.Empty
                End If
            End If
        End If

    End Sub

    Protected Sub GridTextBlock_ItemCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridAuthorDisclosureQuestions.ItemCommand
        If e.CommandName = RadGrid.EditCommandName Then
            shouldDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.InitInsertCommandName Then
            shouldDisableEditItems = True

            shouldDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.CancelCommandName Then
            shouldDisableCommandItem = False
            shouldDisableEditItems = False
        End If
    End Sub

    Protected Sub RadGridAuthorDisclosureQuestions_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles RadGridAuthorDisclosureQuestions.PreRender
        If shouldDisableEditItems Then
            For Each dataItem As GridDataItem In RadGridAuthorDisclosureQuestions.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = False
            Next
        ElseIf shouldDisableCommandItem Then
            Dim commandItem As GridCommandItem = DirectCast(RadGridAuthorDisclosureQuestions.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = False
        Else
            For Each dataItem As GridDataItem In RadGridAuthorDisclosureQuestions.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = True
            Next
            Dim commandItem As GridCommandItem = DirectCast(RadGridAuthorDisclosureQuestions.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = True
        End If
    End Sub

    Private Sub GetRelationships(ByRef ddlRoles As RadComboBox)
        ddlRoles.DataSource = GetApplicationCodes("ABS", "DISCLOSURE_RELATIONSHIP", True)
        ddlRoles.DataTextField = "Description"
        ddlRoles.DataValueField = "Code"
        ddlRoles.DataBind()
    End Sub
#End Region


#Region "Helper functions"
    Private Sub SetupControls()

        If GetArgs() IsNot Nothing AndAlso GetSubType() IsNot Nothing Then
            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            Dim absSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType

            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                absSubType = absSubTypes(0)
                lblCallCode.Text = absSubType.AbstractCallCode + " - "
                lblTitlePage.Text = absSubType.Description
                Dim absInstruction As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeInstruction
                For Each absInstruction In absSubType.AbstractCallSubmissionTypeInstructions
                    If absInstruction.InstructionTypeCodeString.ToUpper = Const_InstructionType_Author Then
                        Me.RadEditorInstructions.Content = absInstruction.InstructionText
                        Exit For
                    End If
                Next

                rbtnAllowPrimaryViewAbsYes.Checked = absSubType.AllowViewingByAllAuthorsFlag
                rbtnAllowPrimaryViewAbsNo.Checked = Not absSubType.AllowViewingByAllAuthorsFlag

                rbtnPrimaryAuthorMustBeMemberYes.Checked = absSubType.PrimaryAuthorMustBeMemberFlag
                rbtnPrimaryAuthorMustBeMemberNo.Checked = Not absSubType.PrimaryAuthorMustBeMemberFlag

                rbtnValidatePrimaryAuthorYes.Checked = absSubType.AuthorValidationStoredProcedure <> ""
                rbtnValidatePrimaryAuthorNo.Checked = Not (absSubType.AuthorValidationStoredProcedure <> "")

                'Dim expression As New Telerik.Web.UI.GridSortExpression
                'expression.FieldName = "QuestionSequence"
                'expression.SortOrder = Telerik.Web.UI.GridSortOrder.Ascending
                'RadGridAuthorDisclosureQuestions.MasterTableView.SortExpressions.AddSortExpression(expression)
                RadGridAuthorDisclosureQuestions.SortingSettings.EnableSkinSortStyles = False
                RadGridAuthorDisclosureQuestions.DataSource = absSubType.AbstractCallSubmissionTypeAuthorDisclosureControls
                _LargestSeq = absSubType.AbstractCallSubmissionTypeAuthorDisclosureControls.Count
                'LoadAuthorRole()

                'Get the Author Requirement Stored Procedure List
                ddlDefinitionStoredProcedure.DataTextField = "Name"
                ddlDefinitionStoredProcedure.DataValueField = "Name"
                ddlDefinitionStoredProcedure.DataSource = absSubType.GetAuthorValidationStoredProcedureList
                ddlDefinitionStoredProcedure.DataBind()
                If rbtnValidatePrimaryAuthorYes.Checked Then
                    ddlDefinitionStoredProcedure.Enabled = True
                Else
                    ddlDefinitionStoredProcedure.Enabled = False
                End If
            End If
        End If
    End Sub

    Private Sub InitializeControls()

        If GetArgs() IsNot Nothing AndAlso GetSubType() IsNot Nothing Then
            UpdateQuestionOrder()

            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                RadGridAuthorDisclosureQuestions.DataSource = absSubTypes(0).AbstractCallSubmissionTypeAuthorDisclosureControls
                _LargestSeq = absSubTypes(0).AbstractCallSubmissionTypeAuthorDisclosureControls.Count
            End If
        End If
    End Sub

    Private Sub UpdateQuestionOrder()
        If ReorderChanges.Value = "" Then
            Exit Sub
        End If

        CallManager.ABSSubmissionType_AuthorDisclosure_Reorder(PortalId, GetArgs, GetSubType, ReorderChanges.Value)
        ReorderChanges.Value = ""
    End Sub

    Private Sub LoadAuthorRole()
        If lblAuthorRole.Text.Length = 0 Then
            Dim AuthorRoleCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("ABS", "AUTHOR_ROLE", True)

            For Each AuthorRoleCode As TIMSS.API.ApplicationInfo.IApplicationCode In AuthorRoleCodes
                lblAuthorRole.Text = String.Concat(lblAuthorRole.Text, "<br>", AuthorRoleCode.Description, "<br>")
            Next
        End If
    End Sub

    Private Function GetRecord(ByVal AuthorDisclosureQuestions As ArrayList, ByVal AuthorDisclosureControlId As Integer) As AuthorDisclosureQuestionsData
        For Each AuthorDisclosureQuestion As AuthorDisclosureQuestionsData In AuthorDisclosureQuestions
            If AuthorDisclosureQuestion.AuthorDisclosureControlId = AuthorDisclosureControlId Then
                Return AuthorDisclosureQuestion
            End If
        Next
        Return Nothing
    End Function


    Public Function GetDisclosureRelationshipCode() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "DISCLOSURE_RELATIONSHIP", True)
    End Function

    Private Function CreateAuthorDisclosureQuestions(ByVal DisclosureQuestion As AuthorDisclosureQuestionsData) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim AuthorDisclosureQuestion As AuthorDisclosureQuestionsData = New AuthorDisclosureQuestionsData()
        With AuthorDisclosureQuestion
            .AbstractCallCode = GetArgs()
            .SubmissionTypeCode = GetSubType()
            .DisclosureRelationshipCode = DisclosureQuestion.DisclosureRelationshipCode
            .QuestionSeq = _LargestSeq + 1
            .QuestionText = DisclosureQuestion.QuestionText
        End With

        Return CallManager.ABSSubmissionType_AddAuthorDisclosureQuestion(PortalId, AuthorDisclosureQuestion)
    End Function

    Private Function GetWebSubmissionTypeUponSave() As WEB_SUBMISSIONTYPE

        Dim absSubType As New WEB_SUBMISSIONTYPE

        absSubType.Call_Code = GetArgs()
        absSubType.SubmissionTypeCode = GetSubType()

        absSubType.AllowViewingByAllAuthorsFlag = rbtnAllowPrimaryViewAbsYes.Checked
        absSubType.PrimaryAuthorMustBeMemberFlag = rbtnPrimaryAuthorMustBeMemberYes.Checked
        If rbtnValidatePrimaryAuthorYes.Checked Then
            absSubType.AuthorValidationStoredProcedure = ddlDefinitionStoredProcedure.SelectedValue.ToString
        Else
            absSubType.AuthorValidationStoredProcedure = ""
        End If

        absSubType.ABSInstruction_Get(Const_InstructionType_Author, Language, Me.RadEditorInstructions.Content)

        Return absSubType

    End Function
#End Region


#Region "Public methods'"


    Private Sub DisableGrid(ByVal objGrid As Telerik.Web.UI.RadGrid, ByVal MoveUpButtonName As String, ByVal MoveDownButtonName As String)

        Me.FindControl(MoveUpButtonName).Visible = False

        Me.FindControl(MoveDownButtonName).Visible = False

        objGrid.Columns(0).Display = False
        objGrid.Columns(objGrid.Columns.Count - 1).Display = False

        For Each grdCmdItem As GridCommandItem In objGrid.MasterTableView.GetItems(GridItemType.CommandItem)

            If objGrid.Items.Count > 0 Then
                Dim btn As Button = DirectCast(grdCmdItem.FindControl("AddNewRecordButton"), Button)
                btn.Visible = False

                Dim lnkbtn1 As LinkButton = DirectCast(grdCmdItem.FindControl("InitInsertButton"), LinkButton)
                lnkbtn1.Visible = False

            End If
        Next
    End Sub

    Public Overrides Sub SetupUpdateView(Optional ByVal SubmissionsExist As Boolean = False)
        Me.btnContinue.Visible = False
        Me.btnPrevious.Visible = False
        Me.butUpdate.Visible = True
        _SubmissionsExist = SubmissionsExist

        SetupControls()

        If SubmissionsExist Then
            rbtnAllowPrimaryViewAbsYes.Enabled = False
            rbtnAllowPrimaryViewAbsNo.Enabled = False

            rbtnPrimaryAuthorMustBeMemberNo.Enabled = False
            rbtnPrimaryAuthorMustBeMemberYes.Enabled = False

            rbtnValidatePrimaryAuthorNo.Enabled = False
            rbtnValidatePrimaryAuthorYes.Enabled = False

            'Hode the Edit and Delete columns
            DisableGrid(RadGridAuthorDisclosureQuestions, "btnMoveUp", "btnMoveDown")



        End If
    End Sub

#End Region

End Class
