Imports TIMSS.SQLObjects
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic

Public Class Assign_Reviewer_to_Submission
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents pnlReviewerList As Panel
    Protected WithEvents LinkButtonAssignReviewers As LinkButton
    Protected WithEvents RadGridSubmissions As Telerik.Web.UI.RadGrid
    Protected WithEvents ddlInternalStatus As Telerik.Web.UI.RadComboBox
    Protected WithEvents txtTitle As Telerik.Web.UI.RadTextBox
    Protected WithEvents btnSearch As Button

    Private _ReviewerIds() As Integer

    Private _DoSearch As Boolean = False

#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Request("rids") IsNot Nothing Then _ReviewerIds = Session(Convert.ToString(Request("rids")))

        If _ReviewerIds Is Nothing OrElse _ReviewerIds.Length = 0 Then
            ShowPopupMessage("Nothing selected")
            Exit Sub
        End If

        For Each rid As Integer In _ReviewerIds
            Dim Reviewers As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers
            Reviewers = CallManager.GetAbstractCallSubmissionTypeReviewers(PortalId, rid)

            If Reviewers IsNot Nothing AndAlso Reviewers.Count Then
                AddReviewerInfoToPage(Reviewers)
            End If
        Next

        If Not Page.IsPostBack Then
            LoadControls()
        End If

    End Sub

    Protected Sub LinkButtonAssignReviewers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonAssignReviewers.Click

        Dim success As Boolean = True

        Dim SubmissionArray As New ArrayList

        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridSubmissions.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                If CType(oItem.FindControl("chkSelect"), CheckBox).Checked Then
                    Dim AbstractSubmissionId As Integer = oItem("AbstractSubmissionId").Text
                    SubmissionArray.Add(AbstractSubmissionId)
                End If
            End If
        Next

        Dim Submissions(SubmissionArray.Count - 1) As Integer
        SubmissionArray.CopyTo(Submissions)

        If Submissions IsNot Nothing AndAlso Submissions.Length > 0 AndAlso _ReviewerIds IsNot Nothing AndAlso _ReviewerIds.Length > 0 Then

            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = Nothing

            oIssues = CallManager.CreateSubmissionsReviewers(PortalId, Submissions, _ReviewerIds)

            If oIssues Is Nothing Then
            Else
                ShowPopupMessage(oIssues)
            End If
        End If

    End Sub
    Private Sub RadGridSubmissions_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGridSubmissions.NeedDataSource
        If _DoSearch = False Then
            Exit Sub
        End If

        Dim oParameters As New List(Of TIMSS.API.Core.SearchProperty)
        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionId")
        oParm.ShowInResults = True
        oParm.UseInQuery = False
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("Title")
        oParm.ShowInResults = True
        If txtTitle.Text.Length > 0 Then
            oParm.UseInQuery = True
            oParm.Value = txtTitle.Text
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Contains
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
        oParm.ShowInResults = False
        oParm.UseInQuery = True
        oParm.Value = GetArgs()
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeInfo.SubmissionTypeCode")
        oParm.ShowInResults = False
        oParm.UseInQuery = True
        oParm.Value = GetSubType()
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("InternalStatusCode")
        oParm.ShowInResults = True
        If Not (ddlInternalStatus.SelectedValue = "-1") Then
            oParm.UseInQuery = True
            oParm.Value = ddlInternalStatus.SelectedValue
        Else
            oParm.UseInQuery = True
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.NotEqualTo
            oParm.Value = "PENDING_SUBMISSION"
        End If
        oParameters.Add(oParm)


        RadGridSubmissions.DataSource = SubmissionManager.ABS_Submission_Get(PortalId, oParameters)

    End Sub

    Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        _DoSearch = True
        RadGridSubmissions.Rebind()
    End Sub

#End Region

#Region "Helper functions"

    Public Sub LoadControls()
        ddlInternalStatus.DataTextField = "Description"
        ddlInternalStatus.DataValueField = "Code"
        ddlInternalStatus.DataSource = GetApplicationCodes("ABS", "INTERNAL_STATUS", True)
        ddlInternalStatus.DataBind()
        ddlInternalStatus.Items.Insert(0, GetInitItem())
        Dim item As Telerik.Web.UI.RadComboBoxItem
        item = ddlInternalStatus.Items.FindItemByValue("PENDING_SUBMISSION")
        If item IsNot Nothing Then
            ddlInternalStatus.Items.Remove(item)
        End If


        RadGridSubmissions.DataSource = Nothing
        RadGridSubmissions.DataBind()
    End Sub

    Private Function GetInitItem() As Telerik.Web.UI.RadComboBoxItem
        Dim oItem As New Telerik.Web.UI.RadComboBoxItem
        oItem.Text = ""
        oItem.Value = "-1"

        Return oItem
    End Function

    Private Sub AddReviewerInfoToPage(ByVal Reviewers As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers)
        If Reviewers.Count = 1 Then
            Dim tbl As New System.Web.UI.WebControls.Table
            Dim row As System.Web.UI.WebControls.TableRow
            Dim cell As System.Web.UI.WebControls.TableCell

            Dim ReviewerName As New Label
            ReviewerName.ID = String.Concat("lblReviewerName_", Reviewers(0).AbstractCallSubmissionTypeReviewerId)
            ReviewerName.Text = Reviewers(0).CustomerInfo.LastFirstName
            ReviewerName.Font.Bold = True
            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(ReviewerName)
            row = New System.Web.UI.WebControls.TableRow
            row.Cells.Add(cell)
            tbl.Rows.Add(row)

            If Reviewers(0).AbstractSubmissionReviewers.Count > 0 Then
                For Each Reviewer As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer In Reviewers(0).AbstractSubmissionReviewers
                    Dim SubmissionTitle As New Label
                    SubmissionTitle.ID = String.Concat("lblSubmissionTitle_", Reviewer.AbstractSubmissionReviewerId)
                    SubmissionTitle.Text = Reviewer.AbstractSubmissionInfo.Title
                    cell = New System.Web.UI.WebControls.TableCell
                    cell.Controls.Add(SubmissionTitle)
                    row = New System.Web.UI.WebControls.TableRow
                    row.Cells.Add(cell)
                    tbl.Rows.Add(row)
                Next
            End If
            pnlReviewerList.Controls.Add(tbl)
        End If

    End Sub
#End Region

End Class
