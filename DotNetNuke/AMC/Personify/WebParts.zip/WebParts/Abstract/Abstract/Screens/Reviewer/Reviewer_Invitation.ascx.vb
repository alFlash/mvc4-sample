
Imports ScreenController.AbstractScreen

Public Class Reviewer_Invitation
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

    End Sub

#End Region

#Region "Variables"



#End Region

    Protected WithEvents DropDownListReason As DropDownList
    Protected LabelTitle As Label
    Protected LabelCall As Label
    Protected LabelSubmissionType As Label
    Protected LabelReviewBlindRule As Label
    Protected LabelDueDate As Label
    Protected WithEvents butAccept As Button
    Protected WithEvents butShowDecline As Button
    Protected WithEvents LinkButtonAccept2 As LinkButton
    Protected WithEvents LinkButtonRealDecline As LinkButton
    Protected radDeclineWindow As Telerik.Web.UI.RadToolTip
    Protected WithEvents ctlSubmissionTextBlocks As SubmissionTextBlocks
    Protected MessageLabel As Label
    Protected Panel1 As Panel

#Region "Events"

    Private _SubmissionReviewerId As Integer = 0


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        _SubmissionReviewerId = Integer.Parse(Request("srid"))

        If Not IsPersonifyWebUserLoggedIn Then
            'Error
            MessageLabel.Text = "Please login first"
        End If


        If Not _SubmissionReviewerId > 0 Then
            MessageLabel.Text = "Nothing selected"
        Else

            If Not Page.IsPostBack Then

                Dim Reasons As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                 GetApplicationCodes("ABS", "ASSIGNMENT_STATUS_REASON", True)
                If Reasons IsNot Nothing AndAlso Reasons.Count > 0 Then
                    For Each Reason As TIMSS.API.ApplicationInfo.IApplicationCode In Reasons
                        DropDownListReason.Items.Add(New ListItem(Reason.Description, Reason.Code))
                    Next
                End If
                DropDownListReason.SelectedItem.Value = ""

                Dim rid As New ReviewerInvitationData()
                If rid.GetData(PortalId, MasterCustomerId, SubCustomerId, _SubmissionReviewerId) Then


                    LabelTitle.Text = rid.SubmissionTitle
                    LabelCall.Text = rid.AbstractCallTitle
                    LabelSubmissionType.Text = rid.SubmissionTypeCode
                    LabelReviewBlindRule.Text = rid.ReviewBlindRule
                    LabelDueDate.Text = CDate(rid.DueDate).ToString("M/d/yyyy")

                    With ctlSubmissionTextBlocks
                        .AbstractSubmissionId = rid.AbstractSubmissionId
                        .EditNavigateURL = ""
                        .IsEdit = False
                        .PortalId = PortalId
                        .ShowInstruction = False
                    End With
                Else
                    MessageLabel.Text = "Access denied"
                    Panel1.Visible = False
                End If
            End If
        End If
    End Sub


    Private Sub Accept()

        If Not _SubmissionReviewerId > 0 Then
            ShowPopupMessage("Nothing selected")
        Else
            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection

            oIssues = CallManager.SetSubmissionReviewerStatus(PortalId, MasterCustomerId, SubCustomerId, _SubmissionReviewerId, Constants.Const_AssignmentStatus_UnderReview, Nothing)
            If oIssues IsNot Nothing Then
                'error
                ShowPopupMessage(oIssues)
            Else
                Response.Redirect(NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_ReviewSubmission & "&srid=" & _SubmissionReviewerId.ToString))
            End If

        End If
    End Sub


    Protected Sub butAccept_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butAccept.Click
        Accept()
    End Sub

    Protected Sub LinkButtonAccept2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonAccept2.Click
        Accept()

    End Sub

    Protected Sub LinkButtonRealDecline_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonRealDecline.Click

        If _SubmissionReviewerId > 0 Then
            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.SetSubmissionReviewerStatus(PortalId, MasterCustomerId, SubCustomerId, _SubmissionReviewerId, Constants.Const_AssignmentStatus_Declined, DropDownListReason.SelectedValue)
            If oIssues IsNot Nothing Then
                ShowPopupMessage(oIssues)
            Else
                Response.Redirect(NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_Inbox))
            End If
        End If

    End Sub

    Private Sub butShowDecline_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butShowDecline.Click
        Me.radDeclineWindow.Show()        
    End Sub

#End Region


 
End Class
