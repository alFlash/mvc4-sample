
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic
Imports Telerik.Web.UI

Public Class DisclosureDetails
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private _oSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission
#End Region

#Region "Controls"
    Protected WithEvents GridSubmissionDisclosure As RadGrid
    Protected WithEvents rptSubmissionAuthors As Repeater
#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Not Page.IsPostBack Then
            SetupControls()
        Else

        End If
    End Sub

    Protected Sub GridSubmissionDisclosure_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GridSubmissionDisclosure.NeedDataSource
        GridSubmissionDisclosure.DataSource = _oSubmission.AbstractSubmissionDisclosures

    End Sub

#End Region


#Region "Helper functions"

    Private Sub SetupControls()
        _oSubmission = CallManager.GetSubmission(PortalId, CType(GetAbsSubId(), Integer))
        rptSubmissionAuthors.DataSource = _oSubmission.AbstractSubmissionAuthors
        rptSubmissionAuthors.DataBind()

    End Sub

    Private Sub rptSubmissionAuthors_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptSubmissionAuthors.ItemDataBound
        Dim rptAuthorDisclosureQuestions As Repeater = e.Item.FindControl("rptAuthorDisclosureQuestions")
        If rptAuthorDisclosureQuestions IsNot Nothing Then
            Dim AuthorDisclosureQuestions As New List(Of WEB_AUTHORDISCLOSUREQUESTION)

            Dim oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor = CType(e.Item.DataItem, TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor)
            If oAuthor.AbstractSubmissionAuthorDisclosures IsNot Nothing AndAlso oAuthor.AbstractSubmissionAuthorDisclosures.Count > 0 Then
                For Each oAuthorDisclosure As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosure In oAuthor.AbstractSubmissionAuthorDisclosures
                    Dim oAuthorDisclosureQuestion As New WEB_AUTHORDISCLOSUREQUESTION
                    Dim oAuthorDisclosureQuestionControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl = SubmissionManager.ABS_Submission_AuthorDisclosureControl_Get(PortalId, oAuthorDisclosure.AbstractCallSubmissionTypeAuthorDisclosureControlId)
                    oAuthorDisclosureQuestion.AuthorDisclosureQuestionText = IIf(oAuthorDisclosureQuestionControl Is Nothing, "", oAuthorDisclosureQuestionControl.QuestionText)
                    oAuthorDisclosureQuestion.DisclosureRelationshipCodeString = oAuthorDisclosure.DisclosureRelationshipCode.Description
                    oAuthorDisclosureQuestion.RelatedCustomerName = oAuthorDisclosure.RelatedCustomerName
                    AuthorDisclosureQuestions.Add(oAuthorDisclosureQuestion)
                Next
            End If
            If AuthorDisclosureQuestions.Count > 0 Then
                rptAuthorDisclosureQuestions.DataSource = AuthorDisclosureQuestions
                rptAuthorDisclosureQuestions.DataBind()
            Else
                CType(e.Item.FindControl("lblAuthorName"), Label).Visible = False
            End If
        End If
    End Sub

#End Region

#Region "Public Function"

#End Region



End Class

