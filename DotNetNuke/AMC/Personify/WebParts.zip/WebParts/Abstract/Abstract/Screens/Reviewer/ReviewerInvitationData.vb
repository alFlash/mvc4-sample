Public Class ReviewerInvitationData

    Private _AbstractCallTitle As String = Nothing
    Public Property AbstractCallTitle() As String
        Get
            Return _AbstractCallTitle
        End Get
        Set(ByVal value As String)
            _AbstractCallTitle = value
        End Set
    End Property

    Private _SubmissionTypeCode As String = Nothing
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property

    Private _SubmissionTitle As String = Nothing
    Public Property SubmissionTitle() As String
        Get
            Return _SubmissionTitle
        End Get
        Set(ByVal value As String)
            _SubmissionTitle = value
        End Set
    End Property

    Private _AbstractSubmissionReviewerId As Integer = 0
    Public Property AbstractSubmissionReviewerId() As Integer
        Get
            Return _AbstractSubmissionReviewerId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionReviewerId = value
        End Set
    End Property

    Private _AbstractSubmissionId As Integer = 0
    Public Property AbstractSubmissionId() As Integer
        Get
            Return _AbstractSubmissionId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionId = value
        End Set
    End Property

    'Private _AssignmentStatusCode As String
    'Public Property AssignmentStatusCode() As String
    '    Get
    '        Return _AssignmentStatusCode
    '    End Get
    '    Set(ByVal value As String)
    '        _AssignmentStatusCode = value
    '    End Set
    'End Property

    Private _ReviewBlindRule As String
    Public Property ReviewBlindRule() As String
        Get
            Return _ReviewBlindRule
        End Get
        Set(ByVal value As String)
            _ReviewBlindRule = value
        End Set
    End Property

    Private _DueDate As String
    Public Property DueDate() As String
        Get
            Return _DueDate
        End Get
        Set(ByVal value As String)
            _DueDate = value
        End Set
    End Property

    Private _MasterCustomerId As String
    Public Property MasterCustomerId() As String
        Get
            Return _MasterCustomerId
        End Get
        Set(ByVal value As String)
            _MasterCustomerId = value
        End Set
    End Property

    Private _SubCustomerId As Integer
    Public Property SubCustomerId() As Integer
        Get
            Return _SubCustomerId
        End Get
        Set(ByVal value As Integer)
            _SubCustomerId = value
        End Set
    End Property

    Public ReadOnly Property OrganizationId(ByVal PortalId As Integer) As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId(ByVal PortalId As Integer) As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

    Public Sub New()

    End Sub

    Public Function GetData(ByVal PortalId As String, ByVal currentMasterCustomerId As String, ByVal currentSubCustomerId As Integer, ByVal AbstractSubmissionReviewerId As Integer) As Boolean

        Dim result As Boolean = False

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers

        'oAbstractSubmissions(0).AssignmentStatusCodeString
        Dim CallManager As New CallManagerHelper(OrganizationId(PortalId), OrganizationUnitId(PortalId))

        oAbstractSubmissionReviewers = CallManager.GetSubmissionReviewerData(PortalId, AbstractSubmissionReviewerId)

        ' read only 
        If oAbstractSubmissionReviewers IsNot Nothing AndAlso oAbstractSubmissionReviewers.Count > 0 Then
            If currentMasterCustomerId.ToUpper = oAbstractSubmissionReviewers(0).MasterCustomerId.ToUpper AndAlso currentSubCustomerId = oAbstractSubmissionReviewers(0).SubCustomerId Then

                MasterCustomerId = oAbstractSubmissionReviewers(0).MasterCustomerId
                SubCustomerId = oAbstractSubmissionReviewers(0).SubCustomerId

                AbstractSubmissionReviewerId = oAbstractSubmissionReviewers(0).AbstractSubmissionReviewerId
                'AssignmentStatusCode = oAbstractSubmissionReviewers(0).AssignmentStatusCodeString
                AbstractCallTitle = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title
                SubmissionTitle = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.Title
                SubmissionTypeCode = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCodeString

                DueDate = oAbstractSubmissionReviewers(0).ReviewDueDate

                ReviewBlindRule = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.ReviewBlindRuleCode.Description

                AbstractSubmissionId = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionId
                result = True
            End If

        End If
        Return result
    End Function


End Class
