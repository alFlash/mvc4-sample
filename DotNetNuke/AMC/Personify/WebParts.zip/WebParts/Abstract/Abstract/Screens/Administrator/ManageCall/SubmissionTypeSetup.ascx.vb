Imports ScreenController.AbstractScreen
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports System.Collections.Generic

Public Class SubmissionTypeSetup
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents butContinue As Button
    Protected WithEvents butPrev As Button
    Protected WithEvents ddlSubmissionType As RadComboBox
    Protected WithEvents txtSubmissionDesc As RadTextBox
    Protected WithEvents butUpdate As Button

    Protected WithEvents rdSubmissionStart As RadDatePicker
    Protected WithEvents rdSubmissionEnd As RadDatePicker
    Protected WithEvents rdSubmissionWebStart As RadDatePicker
    Protected WithEvents rdSubmissionWebEnd As RadDatePicker

    Protected WithEvents txtMaxNumber As RadNumericTextBox
    Protected WithEvents txtMaxFinalist As RadNumericTextBox
    Protected WithEvents txtMaxAccepted As RadNumericTextBox
    Protected WithEvents txtMaxSubmissionPerAuthor As RadNumericTextBox
    Protected WithEvents txtMaxAcceptedPerAuthor As RadNumericTextBox

    Protected WithEvents rdReviewEnd As RadDatePicker
    Protected WithEvents rdAnnouncement As RadDatePicker

    Protected WithEvents RadGridStaff As RadGrid
    Protected WithEvents RadGridCusSearch As RadGrid
    Protected WithEvents odsStaffRoleCode As ObjectDataSource
    Protected WithEvents txtFirstName As TextBox
    Protected WithEvents txtLastName As TextBox
    'Protected WithEvents txtCity As TextBox
    Protected WithEvents btnSearch As Button
    Protected WithEvents pnlSearch As Panel
    Protected WithEvents pnlEdit As Panel
    Protected WithEvents lblCallCode As Label
    'Protected WithEvents txtState As TextBox
    Protected WithEvents ddlStaffRoles As RadComboBox
    'Protected WithEvents ddlStaffRolesSearch As DropDownList
    Protected WithEvents txtEmailAddress As TextBox
    Protected WithEvents txtEmail As TextBox
    Private _UpdateMode As Boolean = False
    Private SelectedRoleCode As String = ""
    Private shouldDisableCommandItem As Boolean
    Private shouldDisableEditItems As Boolean

    Protected WithEvents odsStaffRoles As ObjectDataSource

    Protected WithEvents PnlAjaxUpdate As RadAjaxPanel

#End Region

#Region "Helper functions"

    Private Sub SetupControls()

        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        appCodes = GetApplicationCodes("ABS", "SUBMISSION_TYPE", True)

        ddlSubmissionType.DataSource = appCodes
        ddlSubmissionType.DataTextField = "Description"
        ddlSubmissionType.DataValueField = "Code"
        ddlSubmissionType.DataBind()
        ddlSubmissionType.Items.Insert(0, New RadComboBoxItem(""))

        'Load data if exists
        If GetArgs() IsNot Nothing Then


            Dim absSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType
            Dim absSelectedType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType
            Dim absCalls As TIMSS.API.AbstractInfo.IAbstractCalls

            absCalls = CallManager.ABSCALLS_GET(PortalId, GetArgs)
            If absCalls Is Nothing OrElse absCalls.Count = 0 Then
                Exit Sub
            End If

            lblCallCode.Text = absCalls(0).AbstractCallCode

            'Remove existing submission type from dropdown list
            For Each absSubType In absCalls(0).AbstractCallSubmissionTypes
                If GetSubType() IsNot Nothing AndAlso absSubType.SubmissionTypeCodeString = GetSubType() Then
                    absSelectedType = absSubType
                Else
                    Dim item As RadComboBoxItem = ddlSubmissionType.FindItemByValue(absSubType.SubmissionTypeCodeString)
                    If item IsNot Nothing Then
                        ddlSubmissionType.Items.Remove(item)
                    End If
                End If
            Next
            'GetSubType
            If absSelectedType IsNot Nothing Then
                LoadControls(absSelectedType)
            Else
                With absCalls(0)
                    If Not Me.isNullDate(.CallStartDate) Then
                        rdSubmissionStart.SelectedDate = .CallStartDate
                        rdSubmissionWebStart.SelectedDate = .CallStartDate
                    End If
                    If Not Me.isNullDate(.CallEndDate) Then
                        rdSubmissionEnd.SelectedDate = .CallEndDate
                        rdSubmissionWebEnd.SelectedDate = .CallEndDate
                    End If
                End With
            End If
        End If
    End Sub


    Private Function GetWebSubmissionTypeUponSave() As WEB_SUBMISSIONTYPE
        Dim absSubType As New WEB_SUBMISSIONTYPE

        absSubType.Call_Code = GetArgs()
        absSubType.SubmissionTypeCode = ddlSubmissionType.SelectedValue
        absSubType.Description = txtSubmissionDesc.Text


        If rdSubmissionStart.SelectedDate.HasValue Then
            absSubType.SubmissionStartDate = rdSubmissionStart.SelectedDate        
        End If

        If rdSubmissionEnd.SelectedDate.HasValue Then
            absSubType.SubmissionEndDate = rdSubmissionEnd.SelectedDate
        End If
        If rdSubmissionWebStart.SelectedDate.HasValue Then
            absSubType.SubmissionWebStartDate = rdSubmissionWebStart.SelectedDate
        End If
        If rdSubmissionWebEnd.SelectedDate.HasValue Then
            absSubType.SubmissionWebEndDate = rdSubmissionWebEnd.SelectedDate
        End If
        If rdReviewEnd.SelectedDate.HasValue Then
            absSubType.ReviewEndDate = rdReviewEnd.SelectedDate
        End If
        If rdAnnouncement.SelectedDate.HasValue Then
            absSubType.AnnouncementDate = rdAnnouncement.SelectedDate
        End If

        If txtMaxNumber.Value.HasValue Then
            absSubType.MaxSubmissions = txtMaxNumber.Text
        Else
            absSubType.MaxSubmissions = 0
        End If
        If txtMaxFinalist.Value.HasValue Then
            absSubType.MaxFinalistSubmissions = txtMaxFinalist.Text
        Else
            absSubType.MaxFinalistSubmissions = 0
        End If
        If txtMaxAccepted.Value.HasValue Then
            absSubType.MaxAcceptedSubmissions = txtMaxAccepted.Text
        Else
            absSubType.MaxAcceptedSubmissions = 0
        End If
        If txtMaxSubmissionPerAuthor.Value.HasValue Then
            absSubType.DefaultMaxSubmissionsPerAuthor = txtMaxSubmissionPerAuthor.Text
        Else
            absSubType.DefaultMaxSubmissionsPerAuthor = 0
        End If
        If txtMaxAcceptedPerAuthor.Value.HasValue Then
            absSubType.DefaultMaxAcceptedSubmissionsPerAuthor = txtMaxAcceptedPerAuthor.Text
        Else
            absSubType.DefaultMaxAcceptedSubmissionsPerAuthor = 0
        End If


        Return absSubType
    End Function

  
    Private Sub LoadControls(ByVal absSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType)

        Dim item As RadComboBoxItem = ddlSubmissionType.FindItemByValue(absSubType.SubmissionTypeCodeString)
        If item IsNot Nothing Then
            item.Selected = True
        End If
        ddlSubmissionType.Enabled = False

        txtSubmissionDesc.Text = absSubType.Description

        If Not isNullDate(absSubType.FinalReviewDate) Then
            rdReviewEnd.SelectedDate = absSubType.FinalReviewDate
        End If
        If Not isNullDate(absSubType.AnnouncementDate) Then
            rdAnnouncement.SelectedDate = absSubType.AnnouncementDate
        End If
        If Not isNullDate(absSubType.SubmissionTypeStartDate) Then
            rdSubmissionStart.SelectedDate = absSubType.SubmissionTypeStartDate
        End If
        If Not isNullDate(absSubType.SubmissionTypeEndDate) Then
            rdSubmissionEnd.SelectedDate = absSubType.SubmissionTypeEndDate
        End If
        If Not isNullDate(absSubType.WebSubmittalStartDate) Then
            rdSubmissionWebStart.SelectedDate = absSubType.WebSubmittalStartDate
        End If
        If Not isNullDate(absSubType.WebSubmittalEndDate) Then
            rdSubmissionWebEnd.SelectedDate = absSubType.WebSubmittalEndDate
        End If

        txtMaxNumber.Text = absSubType.MaxSubmissions
        txtMaxFinalist.Text = absSubType.MaxFinalistSubmissions
        txtMaxAccepted.Text = absSubType.MaxAcceptedSubmissions
        txtMaxSubmissionPerAuthor.Text = absSubType.DefaultMaxSubmissionsPerAuthor
        txtMaxAcceptedPerAuthor.Text = absSubType.DefaultMaxAcceptedSubmissionsPerAuthor

    End Sub

    Private Sub RemoveExistingSubmissionType(ByVal absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes)

    End Sub

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            SetupControls()
        End If

    End Sub

    Private Sub butUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdate.Click

        If Page.IsValid Then

            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection

            If GetSubType() IsNot Nothing Then
                oValidationIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)
            Else
                oValidationIssues = CallManager.ABSSubmissionType_Create(PortalId, absSubType)
            End If

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                ShowPopupMessage(oValidationIssues)
            Else
                ShowPopupMessage(Constants.Const_Save_Message)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If
    End Sub

    Private Sub butContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butContinue.Click

        'Todo: Get the submission object
        Dim arrStaffs As New ArrayList

        If Page.IsValid Then

            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection

            If GetSubType() IsNot Nothing Then
                oValidationIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)
            Else
                oValidationIssues = CallManager.ABSSubmissionType_Create(PortalId, absSubType)
                'If the Submission Type is new, get the Staff from Session and Save them
                If GetSubType() Is Nothing AndAlso oValidationIssues.ErrorCount = 0 Then
                    If Session("Staff") IsNot Nothing Then
                        arrStaffs = DirectCast(Session("Staff"), ArrayList)
                        'Assign the CallCode and SubmissionType
                        arrStaffs(0).AbstractCallCode = GetArgs()
                        arrStaffs(0).SubmissionTypeCode = ddlSubmissionType.SelectedValue
                    End If
                    'Call the Save method
                    If RadGridStaff.Items.Count > 0 AndAlso CallManager.ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Insert(PortalId, arrStaffs).ErrorCount > 0 Then
                        'Show any error messages and stay on the same page
                        Me.ShowPopupMessage(oValidationIssues)
                        Exit Sub
                    Else
                        'If Save is successful clear the Session
                        Session.Remove("Staff")
                    End If
                End If
            End If

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                Me.ShowPopupMessage(oValidationIssues)
            Else
                GoToNextPage(Admin_AuthorRequirements, GetArgs, "", ddlSubmissionType.SelectedValue)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If

    End Sub


    Private Sub butPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butPrev.Click
        GoToNextPage(Admin_DefineCallParticipation, GetArgs, "", GetSubType)
    End Sub

    Private Sub RadGridCusSearch_NeedDataSource(ByVal source As System.Object, ByVal e As GridNeedDataSourceEventArgs) Handles RadGridCusSearch.NeedDataSource
        RadGridCusSearch.DataSource = New String() {}
        RadGridCusSearch.DataSource = Nothing
        RadGridCusSearch.DataSource = CallManager.ABSSubmissionTypeStaff_Search(PortalId, txtFirstName.Text, txtLastName.Text)
    End Sub

    Private Sub RadGridStaff_NeedDataSource(ByVal source As System.Object, ByVal e As GridNeedDataSourceEventArgs) Handles RadGridStaff.NeedDataSource

        Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim aStaff As SubmissionTypeStaff
        Dim arrStaffs As New ArrayList

        If GetSubType() Is Nothing Then
            'New Submission Type get the Staff from the Session
            If Session("Staff") IsNot Nothing Then
                arrStaffs = DirectCast(Session("Staff"), ArrayList)
            End If
        Else
            'Submission Exists Get the Staff from the DB
            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)
            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                For Each oStaff As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaff In absSubTypes(0).AbstractCallSubmissionTypeStaffs
                    aStaff = New SubmissionTypeStaff
                    aStaff.SubmissionTypeStaffId = oStaff.AbstractCallSubmissionTypeStaffId
                    aStaff.StaffName = oStaff.CustomerInfo.LabelName
                    aStaff.MasterCustomerID = oStaff.MasterCustomerId
                    aStaff.SubCustomerID = oStaff.SubCustomerId
                    aStaff.StaffRoleDescription = oStaff.StaffRoleCode.Description
                    aStaff.EmailAddress = oStaff.EmailAddress
                    arrStaffs.Add(aStaff)
                Next
            End If
        End If

        RadGridStaff.DataSource = arrStaffs

    End Sub

    Protected Sub RadGridStaff_ItemCreated(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridStaff.ItemCreated
        Select Case True
            Case TypeOf e.Item Is GridCommandItem
                Dim commandItem As GridCommandItem = CType(e.Item, GridCommandItem)
                Dim AddButton As LinkButton
                Dim RebindButton As LinkButton
                Dim RefreshButton As Button
                Dim NewButton As Button
                NewButton = CType(commandItem.FindControl("AddNewRecordButton"), Button)
                NewButton.Visible = False
                AddButton = CType(commandItem.FindControl("InitInsertButton"), LinkButton)
                AddButton.Text = "Add new record"
                RebindButton = CType(commandItem.FindControl("RebindGridButton"), LinkButton)
                RebindButton.Visible = False
                RefreshButton = CType(commandItem.FindControl("RefreshButton"), Button)
                RefreshButton.Visible = False
            Case TypeOf e.Item Is GridEditFormItem And e.Item.IsInEditMode
                Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
                pnlSearch = CType(editItem.FindControl("pnlSearch"), Panel)
                pnlEdit = CType(editItem.FindControl("pnlEdit"), Panel)
                btnSearch = CType(editItem.FindControl("btnSearch"), Button)
                If e.Item.OwnerTableView.IsItemInserted Then
                    pnlSearch.Visible = True
                    pnlSearch.Height = 100
                    pnlEdit.Visible = False
                Else
                    'item is about to be edited
                    pnlSearch.Visible = False
                    pnlEdit.Visible = True
                    pnlEdit.Height = 50
                End If
        End Select
    End Sub
    Protected Sub RadGridStaff_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridStaff.ItemDataBound
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then
            Dim Item As GridEditableItem = DirectCast(e.Item, GridEditableItem)
            ddlStaffRoles = DirectCast(Item.FindControl("ddlStaffRoles"), RadComboBox)

            txtEmailAddress = DirectCast(Item.FindControl("txtEmailAddress"), TextBox)
            GetStaffRoleCodes(ddlStaffRoles)
            If Not e.Item.OwnerTableView.IsItemInserted Then
                ddlStaffRoles.Items.FindItemByText(Item("StaffRoleDescription").Text).Selected = True
                If Not Item("EmailAddress").Text = "&nbsp;" Then
                    txtEmailAddress.Text = Item("EmailAddress").Text
                Else
                    txtEmailAddress.Text = String.Empty
                End If
            End If
        End If
    End Sub
    Protected Sub RadGridCusSearch_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles RadGridCusSearch.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then
            Dim Item As GridDataItem = DirectCast(e.Item, GridDataItem)
            Dim ddlStaffRole As RadComboBox = DirectCast(Item.FindControl("cboStaffRole"), RadComboBox)
            ddlStaffRole.Items.FindItemByValue(Item("StaffRole").Text).Selected = True
        End If
    End Sub

    Protected Sub RadGridStaff_ItemCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridStaff.ItemCommand
        If e.CommandName = RadGrid.EditCommandName Then
            shouldDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.InitInsertCommandName Then
            shouldDisableEditItems = True
            shouldDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.CancelCommandName Then
            shouldDisableCommandItem = False
            shouldDisableEditItems = False
        End If
    End Sub
    Protected Sub RadGridStaff_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles RadGridStaff.PreRender
        If shouldDisableEditItems Then
            For Each dataItem As GridDataItem In RadGridStaff.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = False
            Next
        ElseIf shouldDisableCommandItem Then
            Dim commandItem As GridCommandItem = DirectCast(RadGridStaff.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = False
        Else
            For Each dataItem As GridDataItem In RadGridStaff.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = True
            Next
            Dim commandItem As GridCommandItem = DirectCast(RadGridStaff.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = True
        End If
    End Sub
    Private Sub btnSearch_Click(ByVal source As Object, ByVal e As EventArgs) Handles btnSearch.Click
        Dim oControl As New System.Web.UI.Control
        oControl = DirectCast(source, Control).NamingContainer
        pnlSearch = DirectCast(DirectCast(oControl, GridItem).FindControl("pnlSearch"), Panel)
        RadGridCusSearch = DirectCast(DirectCast(oControl, GridItem).FindControl("RadGridCusSearch"), RadGrid)
        txtFirstName = DirectCast(DirectCast(oControl, GridItem).FindControl("txtFirstName"), TextBox)
        txtLastName = DirectCast(DirectCast(oControl, GridItem).FindControl("txtLastName"), TextBox)
       RadGridCusSearch.Rebind()
        shouldDisableEditItems = True
        If RadGridCusSearch.Items.Count > 0 Then
            pnlSearch.Height = 300
        End If
    End Sub
    'Load the Staff Roles
    Private Sub GetStaffRoleCodes(ByRef ddlRoles As RadComboBox)
        ddlRoles.DataSource = GetApplicationCodes("ABS", "STAFF_ROLE", True)
        ddlRoles.DataTextField = "Description"
        ddlRoles.DataValueField = "Code"
        ddlRoles.DataBind()
    End Sub

    Public Function StaffRoles_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "STAFF_ROLE", True)
    End Function

    Private Sub RadGridStaff_UpdateCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridStaff.UpdateCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)
        Dim oStaff As New SubmissionTypeStaff
        Dim arrStaffs As New ArrayList
        Dim intStaffID As Integer
        Dim strEmailAddress As String = String.Empty
        Dim strStaffRoleCode As String = String.Empty
        Dim strStaffRoleDescription As String = String.Empty

        Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
        ddlStaffRoles = DirectCast(editItem.FindControl("ddlStaffRoles"), RadComboBox)
        txtEmailAddress = DirectCast(editItem.FindControl("txtEmailAddress"), TextBox)

        intStaffID = RadGridStaff.Items(e.Item.ItemIndex)("SubmissionTypeStaffId").Text

        If ddlStaffRoles.Text <> "" Then
            strStaffRoleCode = ddlStaffRoles.SelectedItem.Value
            strStaffRoleDescription = ddlStaffRoles.SelectedItem.Text
        End If
        'If txtEmailAddress.Text <> "" Then
        strEmailAddress = txtEmailAddress.Text
        'End If

        'Submission Type is new update the Staff in the Session
        If GetSubType() Is Nothing Then
            UpdateStaffSession("UPDATE", Nothing, intStaffID, strStaffRoleCode, strStaffRoleDescription, strEmailAddress)
        ElseIf CallManager.ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Update(PortalId, intStaffID, strEmailAddress, strStaffRoleCode).ErrorCount > 0 Then
            e.Canceled = True
        End If

        RadGridStaff.Rebind()

    End Sub

    Private Sub RadGridStaff_InsertCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridStaff.InsertCommand


        Dim arrStaffs As New ArrayList

        Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
        'ddlStaffRoles = DirectCast(editItem.FindControl("ddlStaffRoles"), DropDownList)
        txtEmailAddress = DirectCast(editItem.FindControl("txtEmailAddress"), TextBox)
        RadGridCusSearch = DirectCast(editItem.FindControl("RadGridCusSearch"), RadGrid)

        For Each DataItem As GridDataItem In RadGridCusSearch.MasterTableView.Items
            Dim chkSelected As CheckBox = DataItem.FindControl("chkSelect")
            txtEmail = DataItem.FindControl("txtEmail")
            ddlStaffRoles = DataItem.FindControl("cboStaffRole")
            If chkSelected.Checked Then
                Dim oStaff As New SubmissionTypeStaff
                oStaff.MasterCustomerID = DataItem("MasterCustomerId").Text
                oStaff.SubCustomerID = DataItem("SubCustomerID").Text
                oStaff.StaffName = DataItem("LabelName").Text
                If ddlStaffRoles.Text <> "" Then
                    oStaff.StaffRoleCode = ddlStaffRoles.SelectedItem.Value
                    oStaff.StaffRoleDescription = ddlStaffRoles.SelectedItem.Text
                End If

                oStaff.EmailAddress = txtEmail.Text.Trim

                oStaff.AbstractCallCode = GetArgs()
                oStaff.SubmissionTypeCode = GetSubType()
                arrStaffs.Add(oStaff)
                'Exit For
            End If
        Next

        If arrStaffs.Count > 0 Then
            'Submission Type is new save the Staff into Session
            If GetSubType() Is Nothing Then
                UpdateStaffSession("ADD", arrStaffs, Nothing, Nothing, Nothing, Nothing)
            Else
                If CallManager.ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Insert(PortalId, arrStaffs).ErrorCount > 0 Then
                    e.Canceled = True
                End If
            End If
        End If

        RadGridStaff.Rebind()
    End Sub

    Private Sub RadGridStaff_DeleteCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridStaff.DeleteCommand

        Dim oStaff As New SubmissionTypeStaff
        Dim arrStaffs As New ArrayList
        Dim intStaffID As Integer

        intStaffID = RadGridStaff.Items(e.Item.ItemIndex)("SubmissionTypeStaffId").Text

        'Submission Type is new Delete the Staff from Session
        If GetSubType() Is Nothing Then
            UpdateStaffSession("DELETE", Nothing, intStaffID, Nothing, Nothing, Nothing)
        ElseIf CallManager.ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Delete(PortalId, intStaffID).ErrorCount > 0 Then
            'Submission Type exists delete the Staff from database
            e.Canceled = True
        End If

        RadGridStaff.Rebind()
    End Sub

    Private Sub UpdateStaffSession(ByVal Operation As String, Optional ByVal arrNewStaff As ArrayList = Nothing, _
                                    Optional ByVal intStaffID As Integer = Nothing, _
                                    Optional ByVal strStaffRole As String = Nothing, _
                                    Optional ByVal strStaffRoleDescription As String = Nothing, _
                                    Optional ByVal strEmailAddress As String = Nothing)
        Dim arrSessionStaff As New ArrayList
        Dim oStaff As SubmissionTypeStaff

        If Session("Staff") IsNot Nothing Then
            arrSessionStaff = DirectCast(Session("Staff"), ArrayList)
        End If

        Select Case Operation
            Case "ADD"
                For Each oStaff In arrNewStaff
                    If Not blnStaffExists(oStaff.MasterCustomerID, oStaff.SubCustomerID, oStaff.StaffRoleCode) Then
                        If arrSessionStaff Is Nothing Then
                            oStaff.SubmissionTypeStaffId = 1
                        Else
                            oStaff.SubmissionTypeStaffId = arrSessionStaff.Count + 1
                        End If
                        arrSessionStaff.Add(oStaff)
                    End If
                Next
                Session("Staff") = arrSessionStaff
            Case "DELETE"
                For Each oStaff In arrSessionStaff
                    If intStaffID = oStaff.SubmissionTypeStaffId Then
                        arrSessionStaff.Remove(oStaff)
                        Exit For
                    End If
                Next oStaff
            Case "UPDATE"
                For Each oStaff In arrSessionStaff
                    If intStaffID = oStaff.SubmissionTypeStaffId Then
                        oStaff.StaffRoleCode = strStaffRole
                        oStaff.StaffRoleDescription = strStaffRoleDescription
                        oStaff.EmailAddress = strEmailAddress
                        Exit For
                    End If
                Next oStaff
                Session("Staff") = arrSessionStaff
        End Select
    End Sub

    Private Function blnStaffExists(ByVal strMCID As String, ByVal intSubID As Integer, ByVal strRole As String) As Boolean
        Dim arrSessionStaff As New ArrayList
        Dim oStaff As SubmissionTypeStaff
        Dim blnExists As Boolean
        If Session("Staff") IsNot Nothing Then
            arrSessionStaff = DirectCast(Session("Staff"), ArrayList)
            For Each oStaff In arrSessionStaff
                If oStaff.MasterCustomerID = strMCID AndAlso oStaff.SubCustomerID = intSubID AndAlso _
                        oStaff.StaffRoleCode = strRole Then
                    blnExists = True
                    Exit For
                End If
            Next oStaff
        End If
        Return blnExists
    End Function

#End Region


#Region "Helper functions"

    Private Function isNullDate(ByVal value As Date) As Boolean

        If value = "#12:00:00 AM#" Then
            Return True
        End If
        Return False

    End Function
#End Region

#Region "Public methods"

    Public Overrides Sub SetupUpdateView(Optional ByVal SubmissionsExists As Boolean = False)
        Me.butContinue.Visible = False
        Me.butPrev.Visible = False
        Me.butUpdate.Visible = True
        _UpdateMode = True
        SetupControls()
    End Sub

#End Region




End Class
