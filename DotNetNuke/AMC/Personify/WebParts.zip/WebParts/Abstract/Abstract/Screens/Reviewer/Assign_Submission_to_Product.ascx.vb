Imports TIMSS.SQLObjects
Imports ScreenController.AbstractScreen

Public Class Assign_Submission_to_Product
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents SubmissionSearchPanel As Panel
    Protected WithEvents ProductSeachPanel As Panel

    Protected WithEvents TextBoxAuthor As TextBox
    Protected WithEvents TextBoxReviewer As TextBox

    Protected WithEvents RadComboCall As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxStatus As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxSubmissionType As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxTopic As Telerik.Web.UI.RadComboBox

    Protected WithEvents LinkButtonSearchSubmissions As LinkButton
    Protected WithEvents LinkButtonClearSubmissions As LinkButton
    Protected WithEvents LinkButtonSelectSubmissions As LinkButton

    Protected WithEvents RadDatePicker1 As Telerik.Web.UI.RadDatePicker
    Protected WithEvents RadDatePicker2 As Telerik.Web.UI.RadDatePicker
    Protected WithEvents RadGridSubmissions As Telerik.Web.UI.RadGrid

    Protected WithEvents RadComboBoxMeeting As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxTracks As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxDates As Telerik.Web.UI.RadComboBox
    Protected WithEvents btnGetSessions As Button
    Protected WithEvents RadGridSessions As Telerik.Web.UI.RadGrid
    Protected WithEvents LinkButtonAssignProduct As LinkButton

    Protected WithEvents RadComboBoxSessionType As Telerik.Web.UI.RadComboBox
    Protected WithEvents CheckBoxExludeSession As CheckBox

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim SubmissionIds() As Integer = Nothing
        If Request("sids") IsNot Nothing Then SubmissionIds = Session(Convert.ToString(Request("sids")))

        If Not Page.IsPostBack Then

            If SubmissionIds IsNot Nothing AndAlso SubmissionIds.Length > 0 Then
                SubmissionSearchPanel.Visible = False
                ProductSeachPanel.Visible = True
                Dim oCalls As TIMSS.API.AbstractInfo.IAbstractCalls = Nothing
                Dim oCall As TIMSS.API.AbstractInfo.IAbstractCall = Nothing

                'Get the Selected Call
                If GetArgs() IsNot Nothing Then
                    oCalls = CallManager.ABSCALLS_GET(PortalId, GetArgs())
                    oCall = oCalls(0)
                End If

                Dim Meetings As TIMSS.API.Core.SearchObject = CallManager.GetMeetings(PortalId)
                If Meetings.Results IsNot Nothing AndAlso Meetings.Results.Count > 0 Then
                    RadComboBoxMeeting.DataSource = Meetings.Results.Table
                    RadComboBoxMeeting.DataTextField = "ShortName"
                    RadComboBoxMeeting.DataValueField = "ProductId"
                    RadComboBoxMeeting.DataBind()
                    'Disable the Meeting drop down if the Call is already linked to a Meeting
                    If Not String.IsNullOrEmpty(oCall.PrimaryParentProduct) AndAlso oCall.PrimaryProductId > 0 Then
                        If RadComboBoxMeeting.Items.FindItemByValue(oCall.PrimaryProductId) IsNot Nothing Then
                            RadComboBoxMeeting.SelectedValue = oCall.PrimaryProductId
                        Else
                            Dim strCallMeeting As String = String.Empty
                            strCallMeeting = CallManager.GetSingleMeeting(PortalId, oCall.PrimaryProductId)
                            If Not String.IsNullOrEmpty(strCallMeeting) Then
                                RadComboBoxMeeting.Items.Add(New Telerik.Web.UI.RadComboBoxItem(strCallMeeting, oCall.PrimaryProductId))
                                RadComboBoxMeeting.SelectedValue = oCall.PrimaryProductId
                            Else
                                RadComboBoxMeeting.SelectedValue = ""
                                RadComboBoxMeeting.Text = "Select"
                                btnGetSessions.Enabled = False
                                ShowPopupMessage("Not able to find the Meeting linked to the Call.")
                            End If
                        End If
                        RadComboBoxMeeting.Enabled = False
                        'LoadSessions(oCall.PrimaryProductId)
                        LoadTracksAndDates(oCall.PrimaryProductId)
                    Else
                        RadComboBoxMeeting.SelectedValue = ""
                        RadComboBoxMeeting.Text = "Select"
                    End If
                End If

            Else
                SubmissionSearchPanel.Visible = True
                ProductSeachPanel.Visible = False
                RadComboCall.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
                RadComboBoxSubmissionType.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
                RadComboBoxStatus.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
                RadComboBoxTopic.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))

                Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls
                oABSCalls = CallManager.GetCallAndSubmissionType(PortalId)
                If oABSCalls IsNot Nothing AndAlso oABSCalls.Count > 0 Then
                    For Each oABSCall As TIMSS.API.AbstractInfo.IAbstractCall In oABSCalls
                        RadComboCall.Items.Add(New Telerik.Web.UI.RadComboBoxItem(oABSCall.Title, oABSCall.AbstractCallCode))
                        If oABSCall IsNot Nothing AndAlso oABSCall.AbstractCallSubmissionTypes IsNot Nothing AndAlso oABSCall.AbstractCallSubmissionTypes.Count > 0 Then
                            For Each oAbstractCallSubmissionType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType In oABSCall.AbstractCallSubmissionTypes
                                RadComboBoxSubmissionType.Items.Add(New Telerik.Web.UI.RadComboBoxItem(oAbstractCallSubmissionType.Description, oAbstractCallSubmissionType.SubmissionTypeCodeString))
                            Next
                        End If
                    Next
                End If

                Dim Statuses As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                           GetApplicationCodes("ABS", "EXTERNAL_STATUS", True)
                If Statuses IsNot Nothing AndAlso Statuses.Count > 0 Then
                    For Each Status As TIMSS.API.ApplicationInfo.IApplicationCode In Statuses
                        RadComboBoxStatus.Items.Add(New Telerik.Web.UI.RadComboBoxItem(Status.Description.ToString, Status.Code))
                    Next
                End If

                Dim Topics As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopics = CallManager.GetAbstractSubmissionTypeTopics(PortalId)
                If Topics IsNot Nothing AndAlso Topics.Count > 0 Then
                    For Each Topic As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopic In Topics
                        RadComboBoxTopic.Items.Add(New Telerik.Web.UI.RadComboBoxItem(Topic.TopicCode, Topic.TopicCode))
                    Next
                End If


                InitSearchSubmission()
            End If

        End If
    End Sub

#End Region

#Region "Helper functions"


#End Region

    Function ApplySearchCriteria(ByVal Submission As TIMSS.API.AbstractInfo.IAbstractSubmission) As Boolean
        Dim result As Boolean = True

        If RadComboCall.SelectedValue.Length > 0 Then
            If Submission.AbstractCallCode <> RadComboCall.SelectedValue Then Return False
        End If

        If RadComboBoxSubmissionType.SelectedValue.Length > 0 Then
            If Submission.SubmissionTypeCode <> RadComboBoxSubmissionType.SelectedValue Then Return False
        End If

        If RadComboBoxStatus.SelectedValue.Length > 0 Then
            If Submission.ExternalStatusCodeString <> RadComboBoxStatus.SelectedValue Then Return False
        End If

        If Submission.SubmissionDate < RadDatePicker1.SelectedDate Then Return False
        If Submission.SubmissionDate.AddDays(-1) > RadDatePicker2.SelectedDate Then Return False

        If RadComboBoxTopic.SelectedValue.Length > 0 Then
            Dim t As Boolean = False
            If Submission.AbstractSubmissionTopics IsNot Nothing AndAlso Submission.AbstractSubmissionTopics.Count > 0 Then
                For Each topic As TIMSS.API.AbstractInfo.IAbstractSubmissionTopic In Submission.AbstractSubmissionTopics
                    If topic.TopicCodeString = RadComboBoxTopic.SelectedValue Then
                        t = True
                        Exit For
                    End If
                Next
            End If
            If t = False Then Return False
        End If

        If TextBoxAuthor.Text.Trim.Length > 0 Then
            Dim t As Boolean = False
            If Submission.AbstractSubmissionAuthors IsNot Nothing AndAlso Submission.AbstractSubmissionAuthors.Count > 0 Then
                For Each author As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In Submission.AbstractSubmissionAuthors
                    If author.SearchName.StartsWith(TextBoxAuthor.Text.Trim) = True Then
                        t = True
                        Exit For
                    End If
                Next
            End If
            If t = False Then Return False
        End If

        If TextBoxReviewer.Text.Trim.Length > 0 Then
            Dim t As Boolean = False
            If Submission.AbstractSubmissionReviewers IsNot Nothing AndAlso Submission.AbstractSubmissionReviewers.Count > 0 Then
                For Each reviewer As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer In Submission.AbstractSubmissionReviewers
                    If reviewer.CustomerInfo.SearchName.StartsWith(TextBoxReviewer.Text.Trim) = True Then
                        t = True
                        Exit For
                    End If
                Next
            End If
            If t = False Then Return False
        End If

        Return result
    End Function

    Protected Sub LinkButtonSearchSubmissions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSearchSubmissions.Click

        RadGridSubmissions.Visible = True
        Dim AbstactCallCode As String = RadComboCall.SelectedValue
        Dim SubmissionTypeCode As String = RadComboBoxSubmissionType.SelectedValue
        Dim ExternalStatusCode As String = RadComboBoxStatus.SelectedValue
        Dim StartDate As Date = RadDatePicker1.SelectedDate
        Dim Enddate As Date = RadDatePicker2.SelectedDate

        Dim Submissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
        Submissions = CallManager.GetSubmissions(PortalId, AbstactCallCode, SubmissionTypeCode, ExternalStatusCode, StartDate, Enddate)

        If Submissions IsNot Nothing AndAlso Submissions.Count > 0 Then
            Dim SubmissionsDT As DataTable = New DataTable()
            SubmissionsDT.Columns.Add("SubmissionId", Type.GetType("System.Int32"))
            SubmissionsDT.Columns.Add("Title", Type.GetType("System.String"))
            SubmissionsDT.Columns.Add("Authors", Type.GetType("System.String"))
            SubmissionsDT.Columns.Add("Status", Type.GetType("System.String"))
            SubmissionsDT.Columns.Add("SubmissionType", Type.GetType("System.String"))
            SubmissionsDT.Columns.Add("Call", Type.GetType("System.String"))
            SubmissionsDT.Columns.Add("Link", Type.GetType("System.String"))

            Dim row As DataRow
            For Each Submission As TIMSS.API.AbstractInfo.IAbstractSubmission In Submissions
                If ApplySearchCriteria(Submission) = True Then

                    row = SubmissionsDT.NewRow()
                    row("SubmissionId") = Submission.AbstractSubmissionId
                    row("Title") = Submission.Title
                    row("Authors") = ""
                    If Submission.AbstractSubmissionAuthors IsNot Nothing AndAlso Submission.AbstractSubmissionAuthors.Count > 0 Then
                        For Each author As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In Submission.AbstractSubmissionAuthors
                            If row("Authors").ToString.Length > 0 Then row("Authors") += "<BR>"
                            row("Authors") += author.SearchName
                        Next
                    End If
                    row("Status") = Submission.ExternalStatusCode.Description
                    row("SubmissionType") = Submission.AbstractCallSubmissionTypeInfo.Description
                    row("Call") = Submission.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title
                    row("Link") = NavigateURL("", "s=" & ScreenController.AbstractScreen.Author_SubmissionEntryConfirmation & "&sid=" & Submission.AbstractSubmissionId.ToString)

                    SubmissionsDT.Rows.Add(row)
                End If
            Next
            RadGridSubmissions.DataSource = SubmissionsDT
            RadGridSubmissions.DataBind()

            LinkButtonSelectSubmissions.Visible = True

        Else
            RadGridSubmissions.DataSource = Nothing
            RadGridSubmissions.DataBind()
            LinkButtonSelectSubmissions.Visible = False
        End If

    End Sub


    Protected Sub InitSearchSubmission()
        TextBoxAuthor.Text = ""
        TextBoxReviewer.Text = ""

        RadComboCall.SelectedValue = ""
        RadComboBoxStatus.SelectedValue = ""
        RadComboBoxSubmissionType.SelectedValue = ""
        RadComboBoxTopic.SelectedValue = ""

        RadDatePicker1.SelectedDate = DateTime.Now.AddMonths(-1)
        RadDatePicker2.SelectedDate = DateTime.Now
    End Sub

    Protected Sub LinkButtonClearSubmissions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonClearSubmissions.Click
        InitSearchSubmission()
    End Sub

    Protected Sub LinkButtonSelectSubmissions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSelectSubmissions.Click

        Dim aos As New ArrayList
        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGridSubmissions.SelectedItems
            Dim SubmissionId As Integer = Convert.ToInt32(dataitem.Item("SubmissionId").Text)
            aos.Add(SubmissionId)
        Next
        If aos.Count > 0 Then

            Dim SubmissionIds(aos.Count - 1) As Integer
            aos.CopyTo(SubmissionIds)

            Dim MyGuid As Guid = Guid.NewGuid()
            Session(MyGuid.ToString) = SubmissionIds

            Response.Redirect(NavigateURL("", "s=" & ScreenController.AbstractScreen.Assign_Submission_to_Product & "&sids=" & MyGuid.ToString))

        End If

    End Sub

    Protected Sub RadComboBoxMeeting_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs)
        Dim ProductId As Integer = Integer.Parse(RadComboBoxMeeting.SelectedValue)
        LoadTracksAndDates(ProductId)
    End Sub

    Protected Sub LoadTracksAndDates(ByVal intMeetingID As Integer)
        Dim aTrack As New ArrayList
        Dim aStartDate As New ArrayList
        Dim Product As TIMSS.API.ProductInfo.IProduct = CallManager.GetSessions(PortalId, intMeetingID)
        If Product IsNot Nothing AndAlso Product.SubProducts IsNot Nothing AndAlso Product.SubProducts.Count > 0 Then
            For Each aProduct As TIMSS.API.ProductInfo.IProduct In Product.SubProducts
                If aProduct.Subsystem.Code = "MTG" Then
                    If aProduct.MeetingProduct.SessionTrackCode IsNot Nothing _
                                AndAlso aProduct.MeetingProduct.SessionTrackCode.Code.Length > 0 Then
                        If Not (aTrack.IndexOf(aProduct.MeetingProduct.SessionTrackCode.Description) >= 0) Then
                            aTrack.Add(aProduct.MeetingProduct.SessionTrackCode.Description)
                        End If
                    End If

                    If Not (aStartDate.IndexOf(aProduct.MeetingProduct.StartDate.ToString("MMMM d, yyyy")) >= 0) Then
                        aStartDate.Add(aProduct.MeetingProduct.StartDate.ToString("MMMM d, yyyy"))
                    End If
                End If
            Next
        End If
        aTrack.Sort()
        aStartDate.Sort()
        RadComboBoxTracks.DataSource = aTrack
        RadComboBoxTracks.DataBind()
        RadComboBoxDates.DataSource = aStartDate
        RadComboBoxDates.DataBind()
        RadComboBoxTracks.Items.Insert(0, New Telerik.Web.UI.RadComboBoxItem(""))
        RadComboBoxDates.Items.Insert(0, New Telerik.Web.UI.RadComboBoxItem(""))


        Dim SessionTypes As TIMSS.API.ApplicationInfo.IApplicationCodes = _
   GetApplicationCodes("MTG", "PRODUCT_TYPE", True)
        If SessionTypes IsNot Nothing AndAlso SessionTypes.Count > 0 Then
            For Each SessionType As TIMSS.API.ApplicationInfo.IApplicationCode In SessionTypes
                RadComboBoxSessionType.Items.Add(New Telerik.Web.UI.RadComboBoxItem(SessionType.Description.ToString, SessionType.Code))
            Next
            RadComboBoxSessionType.SelectedValue = "S"
        End If

    End Sub

    Protected Sub btnGetSessions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetSessions.Click

        Dim strFilter As String = String.Empty
        Dim dtSessionDate As DateTime
        If RadComboBoxMeeting.SelectedValue IsNot Nothing AndAlso RadComboBoxMeeting.Text <> "Select" Then

            RadGridSessions.Visible = True
            Dim Product As TIMSS.API.ProductInfo.IProduct = CallManager.GetSessions(PortalId, RadComboBoxMeeting.SelectedValue)

            If Product IsNot Nothing AndAlso Product.SubProducts IsNot Nothing AndAlso Product.SubProducts.Count > 0 Then

                Dim SesssionsDT As DataTable = New DataTable()
                SesssionsDT.Columns.Add("ProductId", Type.GetType("System.Int32"))
                SesssionsDT.Columns.Add("ShortName", Type.GetType("System.String"))
                SesssionsDT.Columns.Add("Track", Type.GetType("System.String"))
                SesssionsDT.Columns.Add("SessionType", Type.GetType("System.String"))
                SesssionsDT.Columns.Add("DateAndTime", Type.GetType("System.String"))
                SesssionsDT.Columns.Add("SessionDate", Type.GetType("System.String"))
                SesssionsDT.Columns.Add("Length", Type.GetType("System.Int32"))

                Dim row As DataRow

                For Each Subproduct As TIMSS.API.ProductInfo.IProduct In Product.SubProducts

                    'optional Exclude sessions with linked submission
                    Dim excludeSession As Boolean = False
                    If CheckBoxExludeSession.Checked = True Then
                        If CallManager.isInAbstractSubmissionProductLink(PortalId, Subproduct.ProductId) Then
                            excludeSession = True
                        End If
                    End If

                    If excludeSession = False AndAlso (String.IsNullOrEmpty(RadComboBoxSessionType.SelectedValue) Or Subproduct.ProductTypeCodeString = RadComboBoxSessionType.SelectedValue) Then
                        row = SesssionsDT.NewRow()
                        row("ProductId") = Subproduct.ProductId
                        row("ShortName") = Subproduct.ShortName

                        If Subproduct IsNot Nothing AndAlso Subproduct.MeetingProduct IsNot Nothing AndAlso Subproduct.MeetingProduct.SessionTrackCode IsNot Nothing Then
                            row("Track") = Subproduct.MeetingProduct.SessionTrackCode.Description
                        Else
                            row("Track") = ""
                        End If

                        row("SessionType") = Subproduct.ProductTypeCode.Description

                        If Subproduct IsNot Nothing AndAlso Subproduct.MeetingProduct IsNot Nothing Then
                            row("DateAndTime") = Subproduct.MeetingProduct.StartDate.ToString
                        Else
                            row("DateAndTime") = ""
                        End If

                        If Subproduct IsNot Nothing AndAlso Subproduct.MeetingProduct IsNot Nothing Then
                            row("SessionDate") = Subproduct.MeetingProduct.StartDate.ToShortDateString
                        Else
                            row("SessionDate") = ""
                        End If

                        If Subproduct IsNot Nothing AndAlso Subproduct.MeetingProduct IsNot Nothing Then
                            row("Length") = Subproduct.MeetingProduct.MeetingLength
                        Else
                            row("Length") = 0
                        End If

                        SesssionsDT.Rows.Add(row)
                    End If
                Next

                If RadComboBoxTracks.Text <> "" Then
                    strFilter = strFilter.Concat("Track = '", RadComboBoxTracks.Text, "'")
                End If

                If RadComboBoxDates.Text <> "" Then
                    dtSessionDate = Date.Parse(RadComboBoxDates.Text)
                    If strFilter.Length = 0 Then
                        strFilter = strFilter.Concat("SessionDate = '", dtSessionDate.Date.ToShortDateString, "'")
                    Else
                        strFilter = strFilter.Concat(strFilter, " and SessionDate = '", dtSessionDate.Date.ToShortDateString, "'")
                    End If
                End If

                RadGridSessions.DataSource = SesssionsDT.Select(strFilter)
                RadGridSessions.DataBind()

                LinkButtonAssignProduct.Visible = True
           
            End If
        Else
            ShowPopupMessage("Please select a Meeting")
        End If
    End Sub

    Protected Sub LinkButtonAssignProduct_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonAssignProduct.Click

        Dim aop As New ArrayList
        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGridSessions.SelectedItems
            Dim ProductId As Integer = Convert.ToInt32(dataitem.Item("ProductId").Text)
            aop.Add(ProductId)
        Next
        If aop.Count > 0 Then

            Dim ProductIds(aop.Count - 1) As Integer
            aop.CopyTo(ProductIds)


            Dim SubmissionIds() As Integer = Nothing
            If Request("sids") IsNot Nothing Then SubmissionIds = Session(Convert.ToString(Request("sids")))

            If SubmissionIds IsNot Nothing AndAlso SubmissionIds.Length > 0 Then

                Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
                oIssues = CallManager.AssignSubmissionsToProducts(PortalId, SubmissionIds, ProductIds)
                If oIssues Is Nothing Then
                    Me.ShowPopupMessage("Product assigned")
                    'ShowPopupMessageAndRedirect("Product assigned", NavigateURL("", "s=" & ScreenController.AbstractScreen.Assign_Submission_to_Product))
                    'Response.Redirect(NavigateURL("", "s=" & ScreenController.AbstractScreen.Assign_Submission_to_Product))
                Else
                    ShowPopupMessage(oIssues)
                End If
            Else
                'session expired
                ShowPopupMessage("Your web session expired")

            End If
        Else
            'nothing selected
            ShowPopupMessage("Please select a product")
        End If

    End Sub
End Class
