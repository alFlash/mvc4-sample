
Imports ScreenController.AbstractScreen
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports PersonifyWebCommon

Public Class BlankPage
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Controls & Variables"

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim popupMessage As New Telerik.Web.UI.RadToolTip
        Dim width As Integer = 75
        Me.Controls.Add(popupMessage)

        With popupMessage
            '.Position = Telerik.Web.UI.ToolTipPosition.BottomRight      
            '.RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow      
            .Position = Telerik.Web.UI.ToolTipPosition.TopRight
            .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
            '.Animation = Telerik.Web.UI.ToolTipAnimation.Fade      
            .Animation = Telerik.Web.UI.ToolTipAnimation.None
            .Title = "Message"
            .Width = 300
            .Height = 400
            '.Show()      
            '.RenderInPageRoot = True                  
            .VisibleOnPageLoad = True
            .HideEvent = Telerik.Web.UI.ToolTipHideEvent.ManualClose
        End With


        popupMessage.Controls.Add(New LiteralControl("test"))
    End Sub

  

#End Region








End Class
