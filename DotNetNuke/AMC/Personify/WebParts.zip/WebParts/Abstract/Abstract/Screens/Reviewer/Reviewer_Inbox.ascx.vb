
Imports ScreenController.AbstractScreen

Public Class Reviewer_Inbox
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents butContinue As Button
    Protected WithEvents ctlReviewerInbox As ReviewerInboxControl
    'Protected WithEvents LinkButtonCompleted As LinkButton


#End Region


#Region "Events"

    Private isCompleted As Boolean = False

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        'Dim MasterCustomerId As String = Nothing
        'Dim SubCustomerId As Integer = 0

        If Not IsPersonifyWebUserLoggedIn Then
            'Error
            'ShowPopupMessage("Please login first")
        End If

        If Convert.ToBoolean(Request("Completed")) = True Then isCompleted = True
        'If isCompleted = True Then
        '    LinkButtonCompleted.Text = "See my Inbox"
        'Else
        '    LinkButtonCompleted.Text = "See my completed reviews"
        'End If


        With ctlReviewerInbox
            .PortalId = PortalId
            .MasterCustomerId = MasterCustomerId
            .SubCustomerId = SubCustomerId
            .isCOMPLETED = isCompleted
        End With

    End Sub

    'Protected Sub LinkButtonCompleted_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonCompleted.Click
    '    Me.Response.Redirect(NavigateURL("", "s=" + Convert.ToString(ScreenController.AbstractScreen.Reviewer_Inbox) + "&" + "Completed=" & (Not isCompleted).ToString), True)
    'End Sub

#End Region


#Region "Helper functions"


#End Region


End Class
