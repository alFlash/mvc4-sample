Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI
Imports Personify.ApplicationManager

Public Class SubmissionEntryAuthorInformation
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region " Constants "
    Private Const C_DATATEXTFIELD As String = "Description"
    Private Const C_DATAVALUEFIELD As String = "Code"

#End Region

#Region "Properties"

    Private SubmissionId As Integer
    Private _SubmissionAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor
    Private _Submission As TIMSS.API.AbstractInfo.IAbstractSubmission

    Private authorDisclosures As Hashtable

    Private _authorId As Integer

    Private _SourceAuthorId As Long

    Public ReadOnly Property AbstractSubmissionId() As Integer
        Get
            If Request("sid") IsNot Nothing Then
                Return CInt(Request("sid"))
            Else
                Return 0
            End If
        End Get
    End Property

    Public Property AuthorId() As Long
        Get
            Return _SourceAuthorId
        End Get
        Set(ByVal value As Long)
            _SourceAuthorId = value
        End Set
    End Property



    Public ReadOnly Property Mode() As String
        Get
            If Request("mode") IsNot Nothing Then
                Return CStr(Request("mode"))
            Else
                Return Nothing
            End If
        End Get
    End Property

    Public Property HasAuthorAlreadySubmitted() As Boolean
        Get
            If Request("aid") IsNot Nothing Then
                Return True
            End If

            If ViewState("HasAuthorEnter") Is Nothing Then
                Return False
            End If

            Return ViewState("HasAuthorEnter")
        End Get
        Set(ByVal value As Boolean)
            ViewState("HasAuthorEnter") = value
        End Set
    End Property

#End Region

#Region "Controls"
    Protected WithEvents pnlMain As Panel
    Protected WithEvents lblMessage As Label

    Protected WithEvents RadComboBoxSuffix As RadComboBox
    Protected WithEvents RadComboBoxCountry As RadComboBox
    Protected WithEvents RadComboBoxAuthorRole As RadComboBox

    Protected WithEvents RadGridAuthorDisclosureQuestions As RadGrid
    Protected WithEvents RadGridCurrentAuthorsList As RadGrid
    Protected WithEvents lblCurrentAuthorsList As Label

    Protected WithEvents butPrevious As Button
    Protected WithEvents butDoneEnteringAuthors As Button
    Protected WithEvents butAddAnotherAuthor As Button


    Protected WithEvents RadTextBoxFirstName As RadTextBox
    Protected WithEvents RadTextBoxMI As RadTextBox
    Protected WithEvents RadTextBoxLastName As RadTextBox
    Protected WithEvents RadTextBoxCredentials As RadTextBox
    Protected WithEvents RadTextBoxInstitution As RadTextBox
    Protected WithEvents RadTextBoxDepartment As RadTextBox

    Protected WithEvents RadTextBoxAddress1 As RadTextBox
    Protected WithEvents RadTextBoxAddress2 As RadTextBox
    Protected WithEvents RadTextBoxCity As RadTextBox
    Protected WithEvents RadTextBoxState As RadTextBox
    Protected WithEvents RadTextBoxZip As RadTextBox
    Protected WithEvents chkAddressConfidential As CheckBox

    Protected WithEvents RadTextBoxEmail As RadTextBox
    Protected WithEvents RadTextBoxPhone As RadTextBox
    Protected WithEvents RadTextBoxFax As RadTextBox
    Protected WithEvents chkDontPublish As CheckBox

    Protected WithEvents chkPrimaryAuthor As CheckBox
    Protected WithEvents chkContributingAuthor As CheckBox
    'Protected WithEvents chkSponsoringAuthor As CheckBox
    Protected WithEvents chkPresentingAuthor As CheckBox

    Protected WithEvents lblInstruction As Label

    Protected WithEvents CustomValidatorEmail As CustomValidator
    Protected WithEvents butSkipAuthor As Button


#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SubmissionId = AbstractSubmissionId



        _Submission = CallManager.GetSubmission(PortalId, AbstractSubmissionId)

        If _Submission IsNot Nothing Then
            SubmissionId = _Submission.AbstractSubmissionId

            If Request("aid") IsNot Nothing Then
                AuthorId = CInt(Request("aid"))
            End If

            If AuthorId > 0 Then
                _SubmissionAuthor = _Submission.AbstractSubmissionAuthors.FindObject("AbstractSubmissionAuthorId", AuthorId) 'CallManager.GetAuthor(PortalId, AuthorId)
                SubmissionId = _SubmissionAuthor.AbstractSubmissionId
                authorDisclosures = New Hashtable
            ElseIf Mode = "Edit" Then
                Dim oAbstractSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission
                oAbstractSubmission = _Submission
                If oAbstractSubmission.AbstractSubmissionAuthors IsNot Nothing AndAlso oAbstractSubmission.AbstractSubmissionAuthors.Count > 0 Then
                    _SubmissionAuthor = oAbstractSubmission.AbstractSubmissionAuthors(0)
                    AuthorId = _SubmissionAuthor.AbstractSubmissionAuthorId
                End If
                SubmissionId = AbstractSubmissionId
                authorDisclosures = New Hashtable

            ElseIf _Submission.AbstractSubmissionAuthors IsNot Nothing AndAlso _Submission.AbstractSubmissionAuthors.Count > 0 AndAlso Not (Mode IsNot Nothing AndAlso String.Equals(Mode, "ADD")) Then
                'does not have author id parameter but exists in database - load default primary author                
                For i As Integer = 0 To _Submission.AbstractSubmissionAuthors.Count - 1
                    If _Submission.AbstractSubmissionAuthors(i).PrimaryAuthorFlag Then
                        _SubmissionAuthor = _Submission.AbstractSubmissionAuthors(i)
                        SubmissionId = _SubmissionAuthor.AbstractSubmissionId
                        authorDisclosures = New Hashtable
                        Exit For
                    End If
                Next
            End If
        Else
            SubmissionId = 0
        End If

        If Not IsPostBack Then
            If ValidateQS() Then
                pnlMain.Visible = True
                lblMessage.Visible = False
                LoadInterface()
            Else
                pnlMain.Visible = False
                lblMessage.Visible = True
                lblMessage.Text = "Query String arguments expected"
            End If

            Session("LoadAuthorDisclosureQuestions") = Nothing

            'butAddAnotherAuthor.Attributes.Add("onclick", "javascript: return confirm('You are sure you want to add another author?');")
        End If




    End Sub

    Protected Sub butDoneEnteringAuthors_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butDoneEnteringAuthors.Click
        If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oValidationIssues = SaveCustomer(1) 'next page

            'If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
            '    ShowPopupMessage(oValidationIssues)
            'Else
            '    ShowPopupMessage(Constants.Const_Save_Message)
            '    If AuthorId = 0 Then
            '        GoToNextPage(Author_SubmissionEntryContent, GetArgs, SubmissionId, _authorId, GetSubType)
            '    Else
            '        GoToNextPage(Author_SubmissionEntryContent, GetArgs, SubmissionId, CInt(AuthorId), GetSubType)
            '    End If
            'End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If
    End Sub


    Protected Sub butPrevious_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butPrevious.Click
        If Not String.IsNullOrEmpty(Request("returnurl")) Then
            Response.Redirect(Request("returnurl"))
        Else
            GoToNextPage(Author_SubmissionEntryGeneralInformation, GetArgs, SubmissionId, 0, GetSubType)
        End If
    End Sub

    Private Sub butSkipAuthor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butSkipAuthor.Click
        GoToNextPage(Author_SubmissionEntryContent, GetArgs, SubmissionId, 0, GetSubType)
    End Sub

    Protected Sub butAddAnotherAuthor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butAddAnotherAuthor.Click
        If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oValidationIssues = SaveCustomer(0) 'new author
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If
    End Sub

#End Region


#Region "Helper functions"

    Private Function ValidateQS() As Boolean
        If GetArgs() Is Nothing Or GetSubType() Is Nothing Or SubmissionId = 0 Then
            Return False
        Else
            Return True
        End If

    End Function
    Private Sub LoadInterface()

        'Suffix combobox
        Dim oCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        oCodes = GetApplicationCodes("CUS", "NAME_SUFFIX", True)
        With RadComboBoxSuffix
            .Items.Clear()
            .DataTextField = C_DATATEXTFIELD
            .DataValueField = C_DATAVALUEFIELD
            .DataSource = oCodes
            .DataBind()
            .Items.Add(New RadComboBoxItem("", ""))
            .SelectedIndex = .Items.Count
        End With

        'Country combobox
        Dim oCountries As TIMSS.API.ApplicationInfo.IApplicationCountries = Nothing
        oCountries = TIMSS.API.CachedApplicationData.ApplicationDataCache.Countries

        ' TIMSS.API.CachedApplicationData.ApplicationDataCache.Countries
        With RadComboBoxCountry
            .DataTextField = "CountryDescription"
            .DataValueField = "CountryCode"
            .DataSource = oCountries
            .DataBind()
        End With
        If Not Page.IsPostBack Then
            RadComboBoxCountry.SelectedValue = "USA"
        End If


        'Author roles combobox
        Dim oAuthorRoles As TIMSS.API.ApplicationInfo.IApplicationCodes = Nothing
        oAuthorRoles = GetApplicationCodes("ABS", "AUTHOR_ROLE", True)
        With RadComboBoxAuthorRole
            .DataTextField = C_DATATEXTFIELD
            .DataValueField = C_DATAVALUEFIELD
            .DataSource = oAuthorRoles
            .DataBind()
        End With

        lblInstruction.Text = CallManager.GetInstruction(PortalId, Constants.Const_InstructionType_Author, GetArgs, GetSubType)


        If _SubmissionAuthor IsNot Nothing Then
            LoadInformationBasedOnAuthor(_SubmissionAuthor)
        ElseIf _Submission.AbstractSubmissionAuthors.Count = 0 AndAlso Me.HasAuthorAlreadySubmitted = False Then
            'auto populate login customer info
            LoadInformationBasedOnCustomer()      
        End If

        If Mode IsNot Nothing AndAlso String.Equals(Mode, "ADD") Then
            butSkipAuthor.Visible = True
        Else
            butSkipAuthor.Visible = False
        End If


    End Sub


    Private Sub LoadInformationBasedOnAuthor(ByVal oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor)

        With oAuthor
            RadTextBoxFirstName.Text = .FirstName
            RadTextBoxMI.Text = .MiddleName
            RadTextBoxLastName.Text = .LastName
            RadTextBoxCredentials.Text = .NameCredentials
            RadComboBoxSuffix.SelectedValue = .NameSuffixString

            RadTextBoxDepartment.Text = .Department
            RadTextBoxInstitution.Text = .CompanyInstitutionName

            RadTextBoxAddress1.Text = .Address1
            RadTextBoxAddress2.Text = .Address2
            RadTextBoxCity.Text = .City
            RadTextBoxState.Text = .State
            RadTextBoxZip.Text = .PostalCode
            RadComboBoxCountry.SelectedValue = .CountryCodeString
            chkAddressConfidential.Checked = .ConfidentialAddressFlag

            RadTextBoxEmail.Text = .EmailAddress
            RadTextBoxPhone.Text = .Phone
            RadTextBoxFax.Text = .Fax
            chkDontPublish.Checked = .CanPublishPhoneFaxEmailFlag
            chkPresentingAuthor.Checked = .PresentingAuthorFlag
            chkPrimaryAuthor.Checked = .PrimaryAuthorFlag
            chkPrimaryAuthor.Enabled = Not .PrimaryAuthorFlag
            chkContributingAuthor.Checked = .CorrespondingAuthorFlag
            chkContributingAuthor.Enabled = Not .CorrespondingAuthorFlag
            'SponsoringAuthor

            RadComboBoxAuthorRole.SelectedValue = .AuthorRoleCodeString

            'Dim oAuthorDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosure
            'For Each oAuthorDisclosureQuestion In .AbstractSubmissionAuthorDisclosures
            '    With oAuthorDisclosureQuestion
            '        Dim authorDisclosure As New AuthorDisclosureItem(.AbstractSubmissionAuthorDisclosureId, .AbstractCallSubmissionTypeAuthorDisclosureControlId, .DisclosureRelationshipCodeString, .RelatedCustomerName, .DisclosureProductDescription, .CustomerDisclosureId)
            '        authorDisclosures.Add(.AbstractSubmissionAuthorDisclosureId, authorDisclosure)

            '    End With
            'Next
        End With

    End Sub

    Private Function GetCustomer(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.CustomerInfo.ICustomer

        Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

        oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
        With oCustomers
            .Filter.Add("MasterCustomerId", MCID)
            .Filter.Add("SubCustomerId", SCID)
            .Fill()
        End With

        Return oCustomers(0)

    End Function

    Private Sub LoadInformationBasedOnCustomer()

        Dim oCustomer As TIMSS.API.CustomerInfo.ICustomer = GetCustomer(Me.MasterCustomerId, Me.SubCustomerId)

        With oCustomer

            RadTextBoxFirstName.Text = .FirstName
            RadTextBoxMI.Text = .MiddleName
            RadTextBoxLastName.Text = .LastName
            RadTextBoxCredentials.Text = .NameCredentials
            RadComboBoxSuffix.SelectedValue = .NameSuffixString

            'RadTextBoxDepartment.Text = .Department
            'RadTextBoxInstitution.Text = .CompanyInstitutionName

            RadTextBoxAddress1.Text = .PrimaryAddress.Address.Address1
            RadTextBoxAddress2.Text = .PrimaryAddress.Address.Address2
            RadTextBoxCity.Text = .PrimaryAddress.Address.City
            RadTextBoxState.Text = .PrimaryAddress.Address.State
            RadTextBoxZip.Text = .PrimaryAddress.Address.PostalCode
            RadComboBoxCountry.SelectedValue = .PrimaryAddress.Address.CountryCodeString
            chkAddressConfidential.Checked = .PrimaryAddress.ConfidentialFlag

            RadTextBoxEmail.Text = .PrimaryEmailAddress
            RadTextBoxPhone.Text = .PrimaryPhone
            RadTextBoxFax.Text = .PrimaryFax

        End With

        'Default to primary author        
        Dim item As RadComboBoxItem
        item = RadComboBoxAuthorRole.FindItemByValue("PRIMARY_AUTHOR")
        If item IsNot Nothing Then
            item.Selected = True
        End If
        chkPrimaryAuthor.Checked = True
        chkPrimaryAuthor.Enabled = False

        chkContributingAuthor.Checked = True
        chkContributingAuthor.Enabled = False

    End Sub



    Protected Sub RadGridCurrentAuthorsList_NeedDataSource(ByVal [source] As Object, _
       ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()
        list = LoadSubmissionAuthors()
        If list IsNot Nothing AndAlso list.Count > 0 Then
            RadGridCurrentAuthorsList.DataSource = list
            RadGridCurrentAuthorsList.Visible = True
            lblCurrentAuthorsList.Visible = True
        Else
            RadGridCurrentAuthorsList.Visible = False
            lblCurrentAuthorsList.Visible = False
        End If
    End Sub

    Private Function LoadSubmissionAuthors() As ArrayList
        Dim oAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        oAuthors = CallManager.GetAuthors(PortalId, SubmissionId)

        Dim list As ArrayList = New ArrayList()


        If oAuthors IsNot Nothing AndAlso oAuthors.Count > 0 Then

            For i As Integer = 0 To oAuthors.Count - 1
                Dim row As AuthorData = New AuthorData()
                row.AuthorId = oAuthors(i).AbstractSubmissionAuthorId
                row.Name = oAuthors(i).FirstName & " " & oAuthors(i).LastName
                row.Roles = oAuthors(i).AuthorRoleCode.Description
                Dim flags As String = ""
                If oAuthors(i).PrimaryAuthorFlag = True Then flags += "<br />" + "Primary"
                If oAuthors(i).CorrespondingAuthorFlag = True Then flags += "<br />" + "Corresponding"
                If oAuthors(i).PresentingAuthorFlag = True Then flags += "<br />" + "Presenting"
                row.Flags = flags
                row.EditUrl = GetAuthorPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryAuthorInformation, GetArgs, AbstractSubmissionId, oAuthors(i).AbstractSubmissionAuthorId, GetSubType)
                list.Add(row)
            Next
        End If

        Return list

    End Function

    'Protected Sub RadGridAuthorDisclosureQuestions_ItemDataBound(ByVal [source] As Object, _
    '     ByVal e As Telerik.Web.UI.GridItemEventArgs)

    '    If authorDisclosures IsNot Nothing Then
    '        If (TypeOf e.Item Is GridDataItem) Then
    '            If authorDisclosures.ContainsKey(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("AuthorDisclosureControlId")), Long)) Then
    '                Dim txtRelatedCustomerName As TextBox = CType(e.Item, GridDataItem).FindControl("txtRelatedCustomerName")
    '                Dim txtDisclosureProductDescription As TextBox = CType(e.Item, GridDataItem).FindControl("txtDisclosureProductDescription")
    '                txtDisclosureProductDescription.Text = CType(authorDisclosures(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("AuthorDisclosureControlId")), Long)), AuthorDisclosureItem).DisclosureProductDescription
    '                txtRelatedCustomerName.Text = CType(authorDisclosures(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("AuthorDisclosureControlId")), Long)), AuthorDisclosureItem).RelatedCustomerName
    '            End If
    '        End If
    '    End If
    'End Sub

    Private Sub RadGridAuthorDisclosureQuestions_ItemCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridAuthorDisclosureQuestions.ItemCommand

        If e.CommandName = "AddAuthorDisclosureQuestion" Then

            Dim list As ArrayList = LoadAuthorDisclosureQuestions()


            Dim rows(list.Count - 1) As AuthorDisclosureQuestionsData
            list.CopyTo(rows)


            Dim list2 As New ArrayList
            'save the text

            For i As Integer = 0 To RadGridAuthorDisclosureQuestions.Items.Count - 1
                'For Each QuestionItem As Telerik.Web.UI.GridDataItem In RadGridAuthorDisclosureQuestions.Items
                Dim QuestionItem As Telerik.Web.UI.GridDataItem = RadGridAuthorDisclosureQuestions.Items(i)

                Dim txtRelatedCustomerName As TextBox = QuestionItem.FindControl("txtRelatedCustomerName")
                Dim txtDisclosureProductDescription As TextBox = QuestionItem.FindControl("txtDisclosureProductDescription")
                Dim AbstractCallSubmissionTypeAuthorDisclosureControlId As Integer = Convert.ToInt32(QuestionItem.Item("AbstractCallSubmissionTypeAuthorDisclosureControlId").Text)

                If rows(i).AuthorDisclosureControlId = AbstractCallSubmissionTypeAuthorDisclosureControlId Then

                    rows(i).RelatedCustomerName = txtRelatedCustomerName.Text
                    rows(i).DisclosureProductDescription = txtDisclosureProductDescription.Text
                    list2.Add(rows(i))
                End If

            Next


            'add a new line and rebind

            Dim line As Integer = e.Item.ItemIndex

            Dim oldline As AuthorDisclosureQuestionsData = CType(list2(line), AuthorDisclosureQuestionsData)
            Dim newline As New AuthorDisclosureQuestionsData
            newline.AbstractCallCode = oldline.AbstractCallCode
            newline.SubmissionTypeCode = oldline.SubmissionTypeCode
            newline.AuthorDisclosureControlId = oldline.AuthorDisclosureControlId
            newline.DisclosureRelationshipCode = oldline.DisclosureRelationshipCode
            newline.QuestionSeq = oldline.QuestionSeq
            newline.QuestionText = oldline.QuestionText

            list2.Insert(line + 1, newline)

            Session("LoadAuthorDisclosureQuestions") = list2

            RadGridAuthorDisclosureQuestions.DataSource = list2
            RadGridAuthorDisclosureQuestions.Rebind()
        End If

    End Sub
    Protected Sub RadGridAuthorDisclosureQuestions_NeedDataSource(ByVal [source] As Object, _
       ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()
        RadGridAuthorDisclosureQuestions.DataSource = LoadAuthorDisclosureQuestions()

    End Sub

    Private Function LoadAuthorDisclosureQuestions() As ArrayList

        Dim list As ArrayList = New ArrayList()
        If Session("LoadAuthorDisclosureQuestions") Is Nothing Then

            Dim oAbstractSubmissionAuthorDisclosures As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosures
            oAbstractSubmissionAuthorDisclosures = CallManager.ABSSubmissionType_GetAuthorDisclosureQuestionsAnswers(PortalId, AuthorId)

            Dim oAbstractCallSubmissionTypeAuthorDisclosureControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
            oAbstractCallSubmissionTypeAuthorDisclosureControls = CallManager.ABSSubmissionType_GetAuthorDisclosureQuestions(PortalId, GetArgs, GetSubType)

            If oAbstractSubmissionAuthorDisclosures IsNot Nothing AndAlso oAbstractSubmissionAuthorDisclosures.Count > 0 Then
                'load from responses first
                For i As Integer = 0 To oAbstractSubmissionAuthorDisclosures.Count - 1
                    Dim row As AuthorDisclosureQuestionsData = New AuthorDisclosureQuestionsData()

                    'find the related question
                    Dim question As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl
                    question = oAbstractCallSubmissionTypeAuthorDisclosureControls.FindObject("AbstractCallSubmissionTypeAuthorDisclosureControlId", oAbstractSubmissionAuthorDisclosures(i).AbstractCallSubmissionTypeAuthorDisclosureControlId)

                    If question IsNot Nothing Then

                        row.AuthorDisclosureControlId = oAbstractSubmissionAuthorDisclosures(i).AbstractCallSubmissionTypeAuthorDisclosureControlId
                        'row.AbstractCallCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).AbstractCallCode
                        'row.SubmissionTypeCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).SubmissionTypeCode
                        row.DisclosureRelationshipCode = question.DisclosureRelationshipCodeString
                        row.QuestionSeq = question.QuestionSequence
                        row.QuestionText = question.QuestionText
                        row.RelatedCustomerName = oAbstractSubmissionAuthorDisclosures(i).RelatedCustomerName
                        row.DisclosureProductDescription = oAbstractSubmissionAuthorDisclosures(i).DisclosureProductDescription
                        list.Add(row)
                    End If
                Next
                'any previously unanswered questions?
                If oAbstractCallSubmissionTypeAuthorDisclosureControls IsNot Nothing AndAlso oAbstractCallSubmissionTypeAuthorDisclosureControls.Count > 0 Then

                    For i As Integer = 0 To oAbstractCallSubmissionTypeAuthorDisclosureControls.Count - 1
                        If oAbstractSubmissionAuthorDisclosures.FindObject("AbstractCallSubmissionTypeAuthorDisclosureControlId", oAbstractCallSubmissionTypeAuthorDisclosureControls(i).AbstractCallSubmissionTypeAuthorDisclosureControlId) Is Nothing Then
                            Dim row As AuthorDisclosureQuestionsData = New AuthorDisclosureQuestionsData()
                            row.AuthorDisclosureControlId = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).AbstractCallSubmissionTypeAuthorDisclosureControlId
                            row.AbstractCallCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).AbstractCallCode
                            row.SubmissionTypeCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).SubmissionTypeCode
                            row.DisclosureRelationshipCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).DisclosureRelationshipCodeString
                            row.QuestionSeq = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).QuestionSequence
                            row.QuestionText = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).QuestionText
                            list.Add(row)
                        End If
                    Next
                End If

            Else
                'load questions
                If oAbstractCallSubmissionTypeAuthorDisclosureControls IsNot Nothing AndAlso oAbstractCallSubmissionTypeAuthorDisclosureControls.Count > 0 Then

                    For i As Integer = 0 To oAbstractCallSubmissionTypeAuthorDisclosureControls.Count - 1
                        Dim row As AuthorDisclosureQuestionsData = New AuthorDisclosureQuestionsData()
                        row.AuthorDisclosureControlId = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).AbstractCallSubmissionTypeAuthorDisclosureControlId
                        row.AbstractCallCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).AbstractCallCode
                        row.SubmissionTypeCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).SubmissionTypeCode
                        row.DisclosureRelationshipCode = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).DisclosureRelationshipCodeString
                        row.QuestionSeq = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).QuestionSequence
                        row.QuestionText = oAbstractCallSubmissionTypeAuthorDisclosureControls(i).QuestionText
                        list.Add(row)
                    Next
                End If
            End If

            Session("LoadAuthorDisclosureQuestions") = list
        Else
            list = Session("LoadAuthorDisclosureQuestions")
        End If

        Return list

    End Function

   
    Private Function ValidateSubmissionTypeDates() As Boolean
        Return True
    End Function



    Private Function SaveCustomer(ByVal mode As Integer) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oAbstractSubmissionAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
        oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)
        oAbstractSubmissions.Filter.Add("AbstractSubmissionId", SubmissionId)
        oAbstractSubmissions.Fill()
        If oAbstractSubmissions Is Nothing OrElse oAbstractSubmissions.Count = 0 Then
            Return Nothing
        End If

        oAbstractSubmissionAuthor = Nothing
        If _SubmissionAuthor IsNot Nothing Then
            For i As Integer = 0 To oAbstractSubmissions(0).AbstractSubmissionAuthors.Count - 1
                If oAbstractSubmissions(0).AbstractSubmissionAuthors(i).AbstractSubmissionAuthorId = _SubmissionAuthor.AbstractSubmissionAuthorId Then
                    oAbstractSubmissionAuthor = oAbstractSubmissions(0).AbstractSubmissionAuthors(i)
                    'Exit For
                    'Else
                    'we have a new Primary Author
                    'If chkPrimaryAuthor.Checked Then oAbstractSubmissions(0).AbstractSubmissionAuthors(i).PrimaryAuthorFlag = False
                End If
            Next
        Else
            oAbstractSubmissionAuthor = oAbstractSubmissions(0).AbstractSubmissionAuthors.AddNew
        End If

        'if it's a new primary set to false anybody else and try to keep the labelname
        Dim newPrimaryAuthor As Boolean = chkPrimaryAuthor.Checked
        Dim oldPrimaryAuthorrLabelName As String = String.Empty  'if you have the name is old, if not it's the same or new
        If newPrimaryAuthor = True Then
            For i As Integer = 0 To oAbstractSubmissions(0).AbstractSubmissionAuthors.Count - 1
                If oAbstractSubmissions(0).AbstractSubmissionAuthors(i).AbstractSubmissionAuthorId <> oAbstractSubmissionAuthor.AbstractSubmissionAuthorId Then
                    If oAbstractSubmissions(0).AbstractSubmissionAuthors(i).PrimaryAuthorFlag = True Then
                        oldPrimaryAuthorrLabelName = oAbstractSubmissions(0).AbstractSubmissionAuthors(i).LabelName
                    End If
                    oAbstractSubmissions(0).AbstractSubmissionAuthors(i).PrimaryAuthorFlag = False
                End If
            Next
        End If

        'if it's a new corresponding set to false anybody else and try to keep the labelname
        Dim newCorrespondingAuthor As Boolean = chkContributingAuthor.Checked
        Dim oldCorrespondingAuthorLabelName As String = String.Empty
        If newCorrespondingAuthor = True Then
            For i As Integer = 0 To oAbstractSubmissions(0).AbstractSubmissionAuthors.Count - 1
                If oAbstractSubmissions(0).AbstractSubmissionAuthors(i).AbstractSubmissionAuthorId <> oAbstractSubmissionAuthor.AbstractSubmissionAuthorId Then
                    If oAbstractSubmissions(0).AbstractSubmissionAuthors(i).CorrespondingAuthorFlag = True Then
                        oldCorrespondingAuthorLabelName = oAbstractSubmissions(0).AbstractSubmissionAuthors(i).LabelName
                    End If
                    oAbstractSubmissions(0).AbstractSubmissionAuthors(i).CorrespondingAuthorFlag = False
                Else
                End If
            Next
        End If

        With oAbstractSubmissionAuthor

            'create a new customer only for the primary, presenting and Contributing author
            Dim ocustomers As TIMSS.API.CustomerInfo.ICustomers = _
       CallManager.GetCustomer(PortalId, chkPresentingAuthor.Checked OrElse chkPrimaryAuthor.Checked OrElse chkContributingAuthor.Checked, RadTextBoxFirstName.Text, RadTextBoxLastName.Text, RadTextBoxEmail.Text, RadComboBoxCountry.SelectedValue, RadTextBoxCity.Text, RadTextBoxState.Text, RadTextBoxAddress1.Text, RadTextBoxAddress2.Text, RadTextBoxZip.Text)
            If ocustomers IsNot Nothing AndAlso ocustomers.Count > 0 AndAlso (String.Compare(.MasterCustomerId, ocustomers(0).MasterCustomerId, True) <> 0 OrElse .SubCustomerId <> ocustomers(0).SubCustomerId) Then
                If ocustomers.ValidationIssues IsNot Nothing AndAlso ocustomers.ValidationIssues.Count > 0 Then
                    ShowPopupMessage(ocustomers.ValidationIssues)
                    'exit everything, try next time
                    Return Nothing
                Else
                    .MasterCustomerId = ocustomers(0).MasterCustomerId
                    .SubCustomerId = ocustomers(0).SubCustomerId                    
                End If
            End If

            'need remove if's and readonly when api done
            .AbstractSubmissionId = SubmissionId
            .FirstName = RadTextBoxFirstName.Text
            .MiddleName = RadTextBoxMI.Text
            .LastName = RadTextBoxLastName.Text
            If String.Compare(RadTextBoxCredentials.Text, "Credentials", True) <> 0 Then .NameCredentials = RadTextBoxCredentials.Text
            .NameSuffix = .NameSuffix.List(RadComboBoxSuffix.SelectedValue).ToCodeObject
            .ReadOnly("Department") = False
            If String.Compare(RadTextBoxDepartment.Text, "Department", True) <> 0 Then .Department = RadTextBoxDepartment.Text
            .ReadOnly("CompanyInstitutionName") = False
            If String.Compare(RadTextBoxInstitution.Text, "Institution", True) <> 0 Then .CompanyInstitutionName = RadTextBoxInstitution.Text

            If String.Compare(.AddressTypeCodeString, "HOME") <> 0 Then .AddressTypeCode = .AddressTypeCode.List("HOME").ToCodeObject

            .ReadOnly("CountryCode") = False
            If String.Compare(.CountryCodeString, RadComboBoxCountry.SelectedValue) <> 0 Then .CountryCode = .CountryCode.List(RadComboBoxCountry.SelectedValue).ToCodeObject

            .ReadOnly("Address1") = False
            If String.Compare(.Address1, RadTextBoxAddress1.Text) <> 0 Then .Address1 = RadTextBoxAddress1.Text
            .ReadOnly("Address2") = False
            If String.Compare(RadTextBoxAddress2.Text, "Address2", True) <> 0 Then If String.Compare(.Address2, RadTextBoxAddress2.Text) <> 0 Then .Address2 = RadTextBoxAddress2.Text
            .ReadOnly("City") = False
            If String.Compare(.City, RadTextBoxCity.Text) <> 0 Then .City = RadTextBoxCity.Text
            .ReadOnly("State") = False
            If String.Compare(.State, RadTextBoxState.Text) <> 0 Then .State = RadTextBoxState.Text
            .ReadOnly("PostalCode") = False
            If String.Compare(.PostalCode, RadTextBoxZip.Text) <> 0 Then .PostalCode = RadTextBoxZip.Text
            .ConfidentialAddressFlag = chkAddressConfidential.Checked
            If String.Compare(.EmailAddress, RadTextBoxEmail.Text) <> 0 Then .EmailAddress = RadTextBoxEmail.Text
            .Phone = RadTextBoxPhone.Text
            .Fax = RadTextBoxFax.Text
            .CanPublishPhoneFaxEmailFlag = chkDontPublish.Checked
            .PresentingAuthorFlag = chkPresentingAuthor.Checked
            .PrimaryAuthorFlag = chkPrimaryAuthor.Checked
            .CorrespondingAuthorFlag = chkContributingAuthor.Checked
            'SponsoringAuthor

            .AuthorRoleCode = .AuthorRoleCode.List(RadComboBoxAuthorRole.SelectedValue).ToCodeObject



            If AuthorId > 0 Then
                .AbstractSubmissionAuthorDisclosures.RemoveAll()
            End If

            For Each QuestionItem As Telerik.Web.UI.GridDataItem In RadGridAuthorDisclosureQuestions.Items
                Dim txtRelatedCustomerName As TextBox = QuestionItem.FindControl("txtRelatedCustomerName")
                Dim txtDisclosureProductDescription As TextBox = QuestionItem.FindControl("txtDisclosureProductDescription")
                Dim AbstractCallSubmissionTypeAuthorDisclosureControlId As Integer = Convert.ToInt32(QuestionItem.Item("AbstractCallSubmissionTypeAuthorDisclosureControlId").Text)
                Dim DisclosureRelationshipCode As String = QuestionItem.Item("DisclosureRelationshipCode").Text

                If Not String.IsNullOrEmpty(txtRelatedCustomerName.Text) Then
                    With .AbstractSubmissionAuthorDisclosures.AddNew
                        .AbstractCallSubmissionTypeAuthorDisclosureControlId = AbstractCallSubmissionTypeAuthorDisclosureControlId
                        .DisclosureRelationshipCode = .DisclosureRelationshipCode.List(DisclosureRelationshipCode).ToCodeObject
                        .RelatedCustomerName = txtRelatedCustomerName.Text
                        .ReadOnly("DisclosureProductDescription") = False
                        If Not String.IsNullOrEmpty(txtDisclosureProductDescription.Text) Then
                            .DisclosureProductDescription = txtDisclosureProductDescription.Text

                        End If
                        '.CustomerDisclosureId = 0
                    End With
                End If

            Next

        End With

        oAbstractSubmissions.Save()
        If AuthorId = 0 AndAlso (oAbstractSubmissions.ValidationIssues Is Nothing OrElse oAbstractSubmissions.ValidationIssues.ErrorCount = 0) Then
            _authorId = oAbstractSubmissionAuthor.AbstractSubmissionAuthorId
        End If


        If oAbstractSubmissions.ValidationIssues IsNot Nothing AndAlso oAbstractSubmissions.ValidationIssues.ErrorCount > 0 Then
            ShowPopupMessage(oAbstractSubmissions.ValidationIssues)
        Else
            'if no validations and if new author or contributing show message
            'If oAbstractSubmissions.ValidationIssues Is Nothing OrElse oAbstractSubmissions.ValidationIssues.Count = 0 Then
            Dim message As String = ""
            If newPrimaryAuthor AndAlso Not String.IsNullOrEmpty(oldPrimaryAuthorrLabelName) Then
                message = String.Concat(message, "Primary Author for this submission has been changed from " + oldPrimaryAuthorrLabelName + " to ", oAbstractSubmissionAuthor.LabelName)
            End If

            If newCorrespondingAuthor AndAlso Not String.IsNullOrEmpty(oldCorrespondingAuthorLabelName) Then
                If Not String.IsNullOrEmpty(message) Then message += "<br />"
                message = String.Concat(message, "Corresponding Author for this submission has been changed from " + oldCorrespondingAuthorLabelName, " to ", oAbstractSubmissionAuthor.LabelName)
            End If

            If Not String.IsNullOrEmpty(message) Then
                Dim nexturl As String
                If mode = 0 Then
                    nexturl = AppendReturnURL(GetNextPageURL(Author_SubmissionEntryAuthorInformation, GetArgs, SubmissionId, 0, GetSubType, "ADD"))
                Else
                    If Not String.IsNullOrEmpty(Request("returnurl")) Then
                        nexturl = Request("returnurl")
                    Else
                        If AuthorId = 0 Then
                            nexturl = GetNextPageURL(Author_SubmissionEntryContent, GetArgs, SubmissionId, _authorId, GetSubType)
                        Else
                            nexturl = GetNextPageURL(Author_SubmissionEntryContent, GetArgs, SubmissionId, CInt(AuthorId), GetSubType)
                        End If
                    End If
                End If
                ShowPopupMessageAndRedirect(message, nexturl)
            Else
                If mode = 0 Then
                    'Response.Redirect(AppendReturnURL(GetNextPageURL(Author_SubmissionEntryAuthorInformation, GetArgs, SubmissionId, 0, GetSubType, "ADD")))
                    Response.Redirect(GetNextPageURL(Author_SubmissionEntryAuthorInformation, GetArgs, SubmissionId, 0, GetSubType, "ADD"))
                Else
                    If Not String.IsNullOrEmpty(Request("returnurl")) Then
                        Response.Redirect(Request("returnurl"))
                    Else
                        If AuthorId = 0 Then
                            GoToNextPage(Author_SubmissionEntryContent, GetArgs, SubmissionId, _authorId, GetSubType)
                        Else
                            GoToNextPage(Author_SubmissionEntryContent, GetArgs, SubmissionId, CInt(AuthorId), GetSubType)
                        End If
                    End If
                End If
            End If
            'End If
        End If

        Return oAbstractSubmissions.ValidationIssues
    End Function


    Private Sub LoadEmptyInterface()
        HasAuthorAlreadySubmitted = True

        RadTextBoxFirstName.Text = ""
        RadTextBoxMI.Text = ""
        RadTextBoxLastName.Text = ""
        RadTextBoxCredentials.Text = ""
        RadComboBoxSuffix.SelectedIndex = 0
        RadComboBoxAuthorRole.SelectedIndex = 0

        RadTextBoxDepartment.Text = ""
        RadTextBoxInstitution.Text = ""


        RadTextBoxAddress1.Text = ""
        RadTextBoxAddress2.Text = ""
        RadTextBoxCity.Text = ""
        RadTextBoxState.Text = ""
        RadTextBoxZip.Text = ""
        RadComboBoxCountry.SelectedValue = "USA"
        chkAddressConfidential.Checked = False

        RadTextBoxEmail.Text = ""
        RadTextBoxPhone.Text = ""
        RadTextBoxFax.Text = ""
        chkDontPublish.Checked = False
        chkPresentingAuthor.Checked = False
        chkPrimaryAuthor.Checked = False
        chkContributingAuthor.Checked = False

        Dim questions As New Hashtable
        Dim oTypeAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
        oTypeAuthorDisclosureQuestions = CallManager.ABSSubmissionType_GetAuthorDisclosureQuestions(PortalId, GetArgs, GetSubType)

        Dim index As Integer = 0
        For Each QuestionItem As Telerik.Web.UI.GridDataItem In RadGridAuthorDisclosureQuestions.Items
            Dim txtRelatedCustomerName As TextBox = QuestionItem.FindControl("txtRelatedCustomerName")
            Dim txtDisclosureProductDescription As TextBox = QuestionItem.FindControl("txtDisclosureProductDescription")
            If oTypeAuthorDisclosureQuestions IsNot Nothing AndAlso oTypeAuthorDisclosureQuestions.Count > 0 Then
                For i As Integer = 0 To oTypeAuthorDisclosureQuestions.Count - 1
                    If CInt(QuestionItem.OwnerTableView.DataKeyValues(index)("AuthorDisclosureControlId")) = oTypeAuthorDisclosureQuestions(i).AbstractCallSubmissionTypeAuthorDisclosureControlId Then
                        txtDisclosureProductDescription.Text = ""
                        txtRelatedCustomerName.Text = ""
                        Exit For
                    End If

                Next
            End If
            index = index + 1
        Next
    End Sub



    Protected Sub CustomValidatorEmail_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidatorEmail.ServerValidate
        args.IsValid = Not String.IsNullOrEmpty(RadTextBoxEmail.Text) OrElse (Not chkPrimaryAuthor.Checked AndAlso Not chkContributingAuthor.Checked AndAlso Not chkPresentingAuthor.Checked)
    End Sub

#End Region


    'Public Class AuthorDisclosure
    'Public RelatedCustomerName As String
    'Public DisclosureProductDescription As String
    'Public DisclosureRelationshipCode As String
    'End Class





End Class

Public Class AuthorRole
    Private _Code As String
    Private _Description As String

    Public Property Code() As String
        Get
            Return _Code
        End Get
        Set(ByVal value As String)
            _Code = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return _Description
        End Get
        Set(ByVal value As String)
            _Description = value
        End Set
    End Property
    Public Sub New(ByVal Code As String, ByVal Description As String)
        Me.Code = Code
        Me.Description = Description
    End Sub
End Class

Public Class AuthorDisclosureItem
    Private _AbstractCallSubmissionTypeAuthorDisclosureControlId As Integer
    Private _DisclosureRelationshipCode As String
    Private _RelatedCustomerName As String
    Private _DisclosureProductDescription As String
    Private _CustomerDisclosureId As Integer
    Private _AbstractSubmissionAuthorDisclosureId As String



    Public Property AbstractSubmissionAuthorDisclosureId() As Integer
        Get
            Return _AbstractSubmissionAuthorDisclosureId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionAuthorDisclosureId = value
        End Set
    End Property


    Public Property AbstractCallSubmissionTypeAuthorDisclosureControlId() As Integer
        Get
            Return _AbstractCallSubmissionTypeAuthorDisclosureControlId
        End Get
        Set(ByVal value As Integer)
            _AbstractCallSubmissionTypeAuthorDisclosureControlId = value
        End Set
    End Property

    Public Property DisclosureRelationshipCode() As String
        Get
            Return _DisclosureRelationshipCode
        End Get
        Set(ByVal value As String)
            _DisclosureRelationshipCode = value
        End Set
    End Property

    Public Property RelatedCustomerName() As String
        Get
            Return _RelatedCustomerName
        End Get
        Set(ByVal value As String)
            _RelatedCustomerName = value
        End Set
    End Property

    Public Property DisclosureProductDescription() As String
        Get
            Return _DisclosureProductDescription
        End Get
        Set(ByVal value As String)
            _DisclosureProductDescription = value
        End Set
    End Property

    Public Property CustomerDisclosureId() As Integer
        Get
            Return _CustomerDisclosureId
        End Get
        Set(ByVal value As Integer)
            _CustomerDisclosureId = value
        End Set
    End Property


    Public Sub New(ByVal oAbstractSubmissionAuthorDisclosureId As Integer, ByVal oAbstractCallSubmissionTypeAuthorDisclosureControlId As Integer, ByVal DisclosureRelationshipCode As String, ByVal RelatedCustomerName As String, ByVal DisclosureProductDescription As String, ByVal CustomerDisclosureId As Integer)

        _AbstractSubmissionAuthorDisclosureId = oAbstractSubmissionAuthorDisclosureId
        Me.AbstractCallSubmissionTypeAuthorDisclosureControlId = oAbstractCallSubmissionTypeAuthorDisclosureControlId
        Me.DisclosureRelationshipCode = DisclosureRelationshipCode
        Me.RelatedCustomerName = RelatedCustomerName
        Me.DisclosureProductDescription = DisclosureProductDescription
        Me.CustomerDisclosureId = CustomerDisclosureId
    End Sub
End Class