Imports ScreenController.AbstractScreen
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports System.Collections.Generic
Imports Constants
Imports Personify

Public Class ReviewProcess
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables & Properties"

    Protected WithEvents butContinue As Button
    Protected WithEvents butPrev As Button
    Protected WithEvents rdTopicNone As RadioButton
    Protected WithEvents rdTopicSystem As RadioButton
    Protected WithEvents rdTopicCustom As RadioButton
    Protected WithEvents rdKeywordNone As RadioButton
    Protected WithEvents rdKeywordSystem As RadioButton
    Protected WithEvents rdKeywordCustom As RadioButton
    Protected WithEvents rbReviewRuleList As RadioButtonList
    Protected WithEvents rbReviewByList As RadioButtonList

    Protected WithEvents chkAllowAttachment As CheckBox
    Protected WithEvents txtReviewerAssignments As RadNumericTextBox
    Protected WithEvents txtReviewerOpenAssignments As RadNumericTextBox
    Protected WithEvents txtDayToReview As RadNumericTextBox
    Protected WithEvents txtMinReviewer As RadNumericTextBox
    Protected WithEvents ddlReviewApproveCode As RadComboBox

    Protected WithEvents radReviewProcessInstruction As RadEditor
    Protected WithEvents butUpdate As Button

    Protected WithEvents RadGridScoring As RadGrid
    Protected WithEvents odsScoringCriterionCode As ObjectDataSource
    Protected WithEvents odsAnswerTypeCode As ObjectDataSource
    Protected WithEvents ReorderChanges As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents lblTitlePage As Label
    Protected WithEvents lblCallCode As Label

    Protected WithEvents rbStaffReviewYes As RadioButton
    Protected WithEvents rbStaffReviewNo As RadioButton
    Protected WithEvents rbFinalStageYes As RadioButton
    Protected WithEvents rbFinalStageNo As RadioButton

    Protected WithEvents txtQuestions As TextBox
    Protected WithEvents ddlResponse As RadComboBox
    Protected WithEvents ddlAnswer As RadComboBox
    Protected WithEvents ddlScore As RadComboBox
    Protected WithEvents chkComments As CheckBox
    Private shouldDisableCommandItem As Boolean
    Private shouldDisableEditItems As Boolean

#End Region


#Region "Helper functions"
    Private Sub UpdateQuestionOrder()
        If ReorderChanges.Value = "" Then
            Exit Sub
        End If

        CallManager.ABSSubmissionType_ScoringControl_Reorder(PortalId, GetArgs, GetSubType, ReorderChanges.Value)
        ReorderChanges.Value = ""
    End Sub

    Private Function SubmissionScoringProperties_Set(ByVal e As Telerik.Web.UI.GridCommandEventArgs) As WEB_SUBMISSIONSCORING
        Dim editedItem As Telerik.Web.UI.GridEditableItem = CType(e.Item, Telerik.Web.UI.GridEditableItem)

        Dim newValues As Hashtable = New Hashtable
        'The GridTableView will fill the values from all editable columns in the hash
        e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editedItem)
        Dim oSubmissionScoring As New WEB_SUBMISSIONSCORING

        'For Each entry As DictionaryEntry In newValues
        '    Select Case entry.Key.ToString
        '        Case "ScoringCriterionCodeString"
        '            oSubmissionScoring.ScoringCriterionCode = entry.Value.ToString
        '        Case "AnswerTypeCodeString"
        '            oSubmissionScoring.AnswerTypeCode = entry.Value.ToString
        '        Case "ScoringAnswerCodeString"
        '            oSubmissionScoring.ScoringAnswerCode = entry.Value.ToString
        '        Case "SubmissionScoringCriterionDescription"
        '            oSubmissionScoring.SubmissionScoringCriterionDescription = entry.Value.ToString
        '        Case "AllowCommentsFlag"
        '            oSubmissionScoring.AllowCommentsFlag = IIf(entry.Value.ToString = "True", True, False)
        '    End Select
        'Next

        Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
        txtQuestions = DirectCast(editItem.FindControl("txtQuestions"), TextBox)
        ddlResponse = DirectCast(editItem.FindControl("ddlResponse"), RadComboBox)
        ddlAnswer = DirectCast(editItem.FindControl("ddlAnswer"), RadComboBox)
        ddlScore = DirectCast(editItem.FindControl("ddlScore"), RadComboBox)
        chkComments = DirectCast(editItem.FindControl("chkComments"), CheckBox)

        oSubmissionScoring.SubmissionScoringCriterionDescription = txtQuestions.Text
        If ddlResponse.Text <> "" Then
            oSubmissionScoring.ScoringCriterionCode = ddlResponse.SelectedItem.Value
        End If
        If ddlAnswer.Text <> "" Then
            oSubmissionScoring.AnswerTypeCode = ddlAnswer.SelectedItem.Value
        End If
        If ddlScore.Text <> "" Then
            oSubmissionScoring.ScoringAnswerCode = ddlScore.SelectedItem.Value
        End If
        oSubmissionScoring.AllowCommentsFlag = IIf(chkComments.Checked, True, False)
        Return oSubmissionScoring
    End Function

    Private Sub SetupControls()

        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        appCodes = GetApplicationCodes("ABS", "REVIEWER_APPROVED_FOR", True)
        ddlReviewApproveCode.DataSource = appCodes
        ddlReviewApproveCode.DataTextField = "Description"
        ddlReviewApproveCode.DataValueField = "Code"
        ddlReviewApproveCode.DataBind()
        ddlReviewApproveCode.Items.Insert(0, New RadComboBoxItem(""))

        appCodes = GetApplicationCodes("ABS", "REVIEW_BLIND_RULE", True)
        rbReviewRuleList.DataSource = appCodes
        rbReviewRuleList.DataTextField = "Description"
        rbReviewRuleList.DataValueField = "Code"
        rbReviewRuleList.DataBind()

        appCodes = GetApplicationCodes("ABS", "REVIEW_TYPE", True)
        rbReviewByList.DataSource = appCodes
        rbReviewByList.DataTextField = "Description"
        rbReviewByList.DataValueField = "Code"
        rbReviewByList.DataBind()

        'Load data if exists
        If GetArgs() IsNot Nothing AndAlso GetSubType() IsNot Nothing Then
            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            Dim absSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType

            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                absSubType = absSubTypes(0)
                lblCallCode.Text = absSubType.AbstractCallCode + " - "
                lblTitlePage.Text = absSubType.Description
                txtMinReviewer.Text = absSubType.DefaultMinReqReviewersPerSubmission
                txtDayToReview.Text = absSubType.DefaultDaysToReview
                txtReviewerAssignments.Text = absSubType.DefaultMaxReviewerAssignments
                txtReviewerOpenAssignments.Text = absSubType.DefaultMaxReviewerOpenAssignments

                Dim absInstruction As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeInstruction
                For Each absInstruction In absSubType.AbstractCallSubmissionTypeInstructions
                    If absInstruction.InstructionTypeCodeString.ToUpper = Const_InstructionType_Socring Then
                        Me.radReviewProcessInstruction.Content = absInstruction.InstructionText
                        Exit For
                    End If
                Next

                Dim item As ListItem = Me.rbReviewByList.Items.FindByValue(absSubType.ReviewTypeCodeString)
                If item IsNot Nothing Then
                    item.Selected = True
                End If

                item = Me.rbReviewRuleList.Items.FindByValue(absSubType.ReviewBlindRuleCodeString)
                If item IsNot Nothing Then
                    item.Selected = True
                Else
                    Me.rbReviewRuleList.Items(0).Selected = True
                End If

                Dim comboBoxItem As RadComboBoxItem = ddlReviewApproveCode.FindItemByValue(absSubType.ReviewerApprovedForCodeString)
                If comboBoxItem IsNot Nothing Then
                    comboBoxItem.Selected = True
                End If

                rbFinalStageYes.Checked = absSubType.FinalistStageFlag
                rbStaffReviewYes.Checked = absSubType.StaffReviewStageFlag
                rbFinalStageNo.Checked = Not absSubType.FinalistStageFlag
                rbStaffReviewNo.Checked = Not absSubType.StaffReviewStageFlag
                RadGridScoring.SortingSettings.EnableSkinSortStyles = False
                RadGridScoring.DataSource = CallManager.ABSSubmissionTypeScoringCriterion_Get(PortalId, GetArgs, GetSubType)

            End If

        End If
    End Sub

    Private Sub InitializeControls()

        If GetArgs() IsNot Nothing AndAlso GetSubType() IsNot Nothing Then
            UpdateQuestionOrder()

            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                Me.RadGridScoring.DataSource = absSubTypes(0).AbstractCallSubmissionTypeScoringControls
            End If

        End If

    End Sub

    Private Function IsTopicChecked() As Boolean
        If rdTopicNone.Checked OrElse rdTopicSystem.Checked OrElse rdTopicCustom.Checked Then
            Return True
        End If
        Return False
    End Function

    Private Function IsKeywordChecked() As Boolean
        If rdKeywordNone.Checked OrElse rdKeywordSystem.Checked OrElse rdKeywordCustom.Checked Then
            Return True
        End If
        Return False
    End Function



    Private Function GetWebSubmissionTypeUponSave() As WEB_SUBMISSIONTYPE
        Dim absSubType As New WEB_SUBMISSIONTYPE
        absSubType.Call_Code = GetArgs()
        absSubType.SubmissionTypeCode = GetSubType()

        If txtMinReviewer.Value.HasValue Then
            absSubType.DefaultMinReqReviewersPerSubmission = txtMinReviewer.Text
        Else
            absSubType.DefaultMinReqReviewersPerSubmission = 0
        End If
        If txtDayToReview.Value.HasValue Then
            absSubType.DefaultDaysToReview = txtDayToReview.Text
        Else
            absSubType.DefaultDaysToReview = 0
        End If
        If txtReviewerAssignments.Value.HasValue Then
            absSubType.DefaultMaxReviewerAssignments = Me.txtReviewerAssignments.Text
        Else
            absSubType.DefaultMaxReviewerAssignments = 0
        End If
        If txtReviewerOpenAssignments.Value.HasValue Then
            absSubType.DefaultMaxReviewerOpenAssignments = Me.txtReviewerOpenAssignments.Text
        Else
            absSubType.DefaultMaxReviewerOpenAssignments = 0
        End If

        absSubType.FinalistStageFlag = rbFinalStageYes.Checked
        absSubType.StaffReviewStageFlag = rbStaffReviewYes.Checked

        absSubType.ReviewBlindRuleCode = Me.rbReviewRuleList.SelectedItem.Value
        absSubType.ReviewTypeCode = Me.rbReviewByList.SelectedItem.Value
        absSubType.ReviewerApprovedForCode = Me.ddlReviewApproveCode.SelectedItem.Value

        absSubType.ABSInstruction_Get(Const_InstructionType_Socring, Language, Me.radReviewProcessInstruction.Content)

        Return absSubType
    End Function

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            'Todo: should we check if querystring is valid(?) If not valid - hide the page
            SetupControls()
        Else
            InitializeControls()
        End If

    End Sub

    Private Sub butContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butContinue.Click

        If Page.IsValid Then
            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)

            If oIssues.ErrorCount > 0 Then
                Me.ShowPopupMessage(oIssues)
            Else
                GoToNextPage(Admin_SubmissionTypeUpdate, GetArgs, "", GetSubType)                
            End If
        End If

    End Sub


    Private Sub butUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdate.Click

        If Page.IsValid Then
            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()

            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)

            If oIssues IsNot Nothing AndAlso oIssues.ErrorCount > 0 Then
                Me.ShowPopupMessage(oIssues)
            Else
                RadGridScoring.Rebind()
                ShowPopupMessage(Constants.Const_Save_Message)
            End If
        End If       
    End Sub


    Private Sub butPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butPrev.Click
        GoToNextPage(Admin_MaterialsRequirements, GetArgs, "", GetSubType)
    End Sub

    Private Sub RadGridScoring_DeleteCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridScoring.DeleteCommand
        Dim oSubmissionScoring As New WEB_SUBMISSIONSCORING

        oSubmissionScoring.AbstractCallSubmissionTypeScoringControlId = CType(RadGridScoring.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeScoringControlId").Text, Integer)
        Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeScoringControl_Delete(PortalId, GetArgs, GetSubType, oSubmissionScoring)
        If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
            e.Canceled = True
        Else
            InitializeControls()
        End If
    End Sub

    Private Sub RadGridScoring_UpdateCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridScoring.UpdateCommand
        Dim oSubmissionScoring As WEB_SUBMISSIONSCORING
        Dim oSubmissionScorings As New List(Of WEB_SUBMISSIONSCORING)
        Try
            oSubmissionScoring = SubmissionScoringProperties_Set(e)
            oSubmissionScoring.AbstractCallSubmissionTypeScoringControlId = CType(RadGridScoring.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeScoringControlId").Text, Integer)
            oSubmissionScoring.SubmissionScoringCriterionSeq = CType(RadGridScoring.Items(e.Item.ItemIndex)("SubmissionScoringCriterionSequence").Text, Integer)

            oSubmissionScorings.Add(oSubmissionScoring)
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeScoringControl_Update(PortalId, GetArgs, GetSubType, oSubmissionScorings)
            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Private Sub RadGridScoring_InsertCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridScoring.InsertCommand
        Try
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeScoringControl_Create(PortalId, GetArgs, GetSubType, SubmissionScoringProperties_Set(e))
            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Protected Sub RadGridScoring_ItemCreated(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridScoring.ItemCreated
        If TypeOf e.Item Is GridCommandItem Then
            Dim commandItem As GridCommandItem = CType(e.Item, GridCommandItem)
            Dim RebindButton As LinkButton
            Dim RefreshButton As Button
            Dim NewButton As Button
            NewButton = CType(commandItem.FindControl("AddNewRecordButton"), Button)
            NewButton.Visible = False
            RebindButton = CType(commandItem.FindControl("RebindGridButton"), LinkButton)
            RebindButton.Visible = False
            RefreshButton = CType(commandItem.FindControl("RefreshButton"), Button)
            RefreshButton.Visible = False
        End If
    End Sub

    Protected Sub GridTextBlock_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridScoring.ItemDataBound
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then
            Dim Item As GridEditableItem = DirectCast(e.Item, GridEditableItem)
            txtQuestions = DirectCast(Item.FindControl("txtQuestions"), TextBox)
            ddlResponse = DirectCast(Item.FindControl("ddlResponse"), RadComboBox)
            FillDropDowns(ddlResponse, "SCORING_CRITERION")
            ddlAnswer = DirectCast(Item.FindControl("ddlAnswer"), RadComboBox)
            FillDropDowns(ddlAnswer, "ANSWER_TYPE")
            ddlScore = DirectCast(Item.FindControl("ddlScore"), RadComboBox)
            FillDropDowns(ddlScore, "SCORING_ANSWER")
            If Not e.Item.OwnerTableView.IsItemInserted Then

                Dim comboxItem As RadComboBoxItem
                comboxItem = ddlResponse.Items.FindItemByText(Item("ScoringCriterionCodeString").Text)
                If comboxItem IsNot Nothing Then
                    comboxItem.Selected = True
                End If

                comboxItem = ddlAnswer.Items.FindItemByText(Item("AnswerTypeCodeString").Text)
                If comboxItem IsNot Nothing Then
                    comboxItem.Selected = True
                End If
                comboxItem = ddlScore.Items.FindItemByText(Item("ScoringAnswerCode.Description").Text)
                If comboxItem IsNot Nothing Then
                    comboxItem.Selected = True
                End If

                chkComments = DirectCast(Item.FindControl("chkComments"), CheckBox)
                If Not Item("SubmissionScoringCriterionDescription").Text = "&nbsp;" Then
                    txtQuestions.Text = Item("SubmissionScoringCriterionDescription").Text
                Else
                    txtQuestions.Text = String.Empty
                End If
            End If
        End If
    End Sub


    Protected Sub RadGridScoring_ItemCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridScoring.ItemCommand
        If e.CommandName = RadGrid.EditCommandName Then
            shouldDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.InitInsertCommandName Then
            shouldDisableEditItems = True
            shouldDisableCommandItem = True
            'cancel the default operation 
            e.Canceled = True
            Dim newValues As System.Collections.Specialized.ListDictionary = New System.Collections.Specialized.ListDictionary()
            newValues("AllowCommentsFlag") = False
            e.Item.OwnerTableView.InsertItem(newValues)
        ElseIf e.CommandName = RadGrid.CancelCommandName Then
            shouldDisableCommandItem = False
            shouldDisableEditItems = False
        End If
    End Sub

    Protected Sub RadGridStaff_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles RadGridScoring.PreRender
        If shouldDisableEditItems Then
            For Each dataItem As GridDataItem In RadGridScoring.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = False
            Next
        ElseIf shouldDisableCommandItem Then
            Dim commandItem As GridCommandItem = DirectCast(RadGridScoring.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = False
        Else
            For Each dataItem As GridDataItem In RadGridScoring.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = True
            Next
            Dim commandItem As GridCommandItem = DirectCast(RadGridScoring.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = True
        End If
    End Sub

    Private Sub FillDropDowns(ByRef ddlRoles As RadComboBox, ByVal strType As String)
        ddlRoles.DataSource = GetApplicationCodes("ABS", strType, True)
        ddlRoles.DataTextField = "Description"
        ddlRoles.DataValueField = "Code"
        ddlRoles.DataBind()
    End Sub

#End Region

#Region "Public methods"
    Private Sub DisableGrid(ByVal objGrid As Telerik.Web.UI.RadGrid, ByVal MoveUpButtonName As String, ByVal MoveDownButtonName As String)

        Me.FindControl(MoveUpButtonName).Visible = False

        Me.FindControl(MoveDownButtonName).Visible = False

        objGrid.Columns(0).Display = False
        objGrid.Columns(objGrid.Columns.Count - 1).Display = False

        For Each grdCmdItem As GridCommandItem In objGrid.MasterTableView.GetItems(GridItemType.CommandItem)

            If objGrid.Items.Count > 0 Then
                Dim btn As Button = DirectCast(grdCmdItem.FindControl("AddNewRecordButton"), Button)
                btn.Visible = False

                Dim lnkbtn1 As LinkButton = DirectCast(grdCmdItem.FindControl("InitInsertButton"), LinkButton)
                lnkbtn1.Visible = False

            End If
        Next
    End Sub

    Public Overrides Sub SetupUpdateView(Optional ByVal SubmissionsExists As Boolean = False)
        Me.butContinue.Visible = False
        Me.butPrev.Visible = False
        Me.butUpdate.Visible = True
        SetupControls()

        If SubmissionsExists Then
            DisableGrid(RadGridScoring, "btnMoveUp", "btnMoveDown")
            rbReviewRuleList.Enabled = False
            rbReviewByList.Enabled = False
            txtMinReviewer.Enabled = False

            ddlReviewApproveCode.Enabled = False

            rbStaffReviewYes.Enabled = False
            rbStaffReviewNo.Enabled = False

            rbFinalStageNo.Enabled = False
            rbFinalStageYes.Enabled = False

            'txtReviewerAssignments.Enabled = False
            'txtReviewerOpenAssignments.Enabled = False

            'txtDayToReview.Enabled = False

        End If
    End Sub

    Public Function ScoringCriterionCode_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "SCORING_CRITERION", True)
    End Function

    Public Function AnswerTypeCode_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "ANSWER_TYPE", True)
    End Function

    Public Function ScoringAnswerCode_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "SCORING_ANSWER", True)
    End Function

#End Region

End Class
