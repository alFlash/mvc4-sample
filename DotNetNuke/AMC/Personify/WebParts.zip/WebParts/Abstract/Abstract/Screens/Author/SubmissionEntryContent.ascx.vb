Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI
Imports System.IO

Public Class SubmissionEntryContent
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

        Dim oSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        If _SubmissionType Is Nothing Then
            oSubmissionTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)
            If oSubmissionTypes IsNot Nothing AndAlso oSubmissionTypes.Count > 0 Then
                _SubmissionType = oSubmissionTypes(0)
            End If
        End If
        _SubmissionType.AbstractCallSubmissionTypeTextBlockControls.Sort("BlockSequence", ComponentModel.ListSortDirection.Ascending)
        LoadTextBlocks(_SubmissionType.AbstractCallSubmissionTypeTextBlockControls)

    End Sub

#End Region

#Region "Properties"

    Dim disclosureQuestions As Hashtable


    'Public Property AttachmentList() As ArrayList
    '    Get
    '        Return Session("AttachmentList")
    '    End Get
    '    Set(ByVal value As ArrayList)
    '        Session("AttachmentList") = value
    '    End Set
    'End Property

    Public ReadOnly Property AbstractSubmissionId() As Integer
        Get
            If Request("sid") IsNot Nothing Then
                Return CInt(Request("sid"))
            Else
                Return 0
            End If
        End Get
    End Property

    Public ReadOnly Property AuthorId() As Integer
        Get
            If Request("aid") IsNot Nothing Then
                Return CInt(Request("aid"))
            Else
                Return 0
            End If
        End Get
    End Property

#End Region

    Private _mode As String = String.Empty
    Public ReadOnly Property Mode() As String
        Get
            'If Request("mode") IsNot Nothing Then
            '    Return CStr(Request("mode"))
            'Else
            '    Return String.Empty
            'End If


            If String.IsNullOrEmpty(_mode) Then
                If ABS_AcessControl_IsAuthorBelongToSubmission(Me.MasterCustomerId, Me.SubCustomerId, Request("sid")) Then
                    _mode = "Edit"
                Else
                    _mode = "View"
                End If
            End If
            Return _mode
        End Get
    End Property



    Public Property FileTypeErrorMessage() As String
        Get
            If ViewState("FileTypeErrorMessage") Is Nothing Then
                Return String.Empty
            End If
            Return ViewState("FileTypeErrorMessage")
        End Get
        Set(ByVal value As String)
            ViewState("FileTypeErrorMessage") = value
        End Set
    End Property


    Public Property FileTypeRegularExpression() As String
        Get
            If ViewState("FileTypeRegularExpression") Is Nothing Then
                Return String.Empty
            End If
            Return ViewState("FileTypeRegularExpression")
        End Get
        Set(ByVal value As String)
            ViewState("FileTypeRegularExpression") = value
        End Set
    End Property

    Public Property DoesFileTypeExist() As String 'Using Y or N
        Get
            Return ViewState("DoesFileTypeExist")
        End Get
        Set(ByVal value As String)
            ViewState("DoesFileTypeExist") = value
        End Set
    End Property

#Region "Controls"

    Protected WithEvents pnlMain As Panel
    Protected WithEvents lblMessage As Label

    Protected WithEvents fileUpload As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents RadGridDisclosureQuestions As RadGrid
    Protected WithEvents RadTextBoxDescription As RadTextBox
    'Protected WithEvents labelNoResults As Label
    'Protected WithEvents repeaterAttachments As Repeater

    Protected WithEvents RadComboBoxRecordPresentation As RadComboBox
    Protected WithEvents RadComboBoxTakePhotographs As RadComboBox
    Protected WithEvents RadComboBoxPublish As RadComboBox
    Protected WithEvents RadComboBoxOtherPresentations As RadComboBox

    Protected WithEvents phTextBlocks As PlaceHolder
    Protected WithEvents butPrevious As Button
    Protected WithEvents butConfirm As Button

    Protected WithEvents lblInstruction As Label
    Protected WithEvents pnlAttachment As Panel

    Protected WithEvents lblAttachmentsExplanation1 As Label
    Protected WithEvents lblAttachmentsExplanation2 As Label

    Private _SubmissionType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType

    Protected WithEvents fileUploader As FileUpload

    Protected WithEvents RegularExpressionValidatorUpload As RegularExpressionValidator
    Protected ErrorUploadLabel As Label

    Protected AbstractCallCodeHiddenField As HiddenField
    Protected SubmissionTypeCodeHiddenField As HiddenField
    Protected WithEvents ctlSubmissionAttachments As SubmissionAttachments

    Protected WithEvents RadAjaxPanelUploadAttachments As Telerik.Web.UI.RadAjaxPanel
    Protected WithEvents pnlSubmissionDisclosureQuestions As Panel
    Protected UploadTable As System.Web.UI.HtmlControls.HtmlTable

#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Page.Form.Attributes.Add("enctype", "multipart/form-data")

        If Mode = "Edit" Then
            Dim _Submission As TIMSS.API.AbstractInfo.IAbstractSubmission
            _Submission = CallManager.GetSubmission(PortalId, AbstractSubmissionId)
            If _Submission.ExternalStatusCodeString <> "DRAFT" Then _mode = "View"
        End If

        If ValidateQS() AndAlso Mode = "Edit" Then
            SetupControls()
        Else
            pnlMain.Visible = False
            lblMessage.Visible = True
            lblMessage.Text = "Query String arguments expected"
        End If


        With ctlSubmissionAttachments
            .AbstractSubmissionId = AbstractSubmissionId
            .AdditionalPathExtension = String.Concat(AbstractCallCodeHiddenField.Value, "\", SubmissionTypeCodeHiddenField.Value, "\", AbstractSubmissionId)
            .IsEdit = True
            .PortalId = PortalId
        End With


        ValidateAttachments()

    End Sub

    Private Sub ValidateAttachments()

        If DoesFileTypeExist IsNot Nothing AndAlso DoesFileTypeExist = "Y" Then
            RegularExpressionValidatorUpload.ValidationExpression = CStr(FileTypeRegularExpression)
            RegularExpressionValidatorUpload.ErrorMessage = CStr(FileTypeErrorMessage)
            Exit Sub

        ElseIf DoesFileTypeExist IsNot Nothing AndAlso DoesFileTypeExist = "N" Then
            If Not IsPostBack Then
                RadAjaxPanelUploadAttachments.Visible = False
            End If
            Exit Sub
        End If

        Dim oAbstractCallSubmissionTypeFileTypeControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeFileTypeControls
        oAbstractCallSubmissionTypeFileTypeControls = CallManager.GetAbstractCallSubmissionTypeFileTypeControls(PortalId, GetArgs(), GetSubType())
        If oAbstractCallSubmissionTypeFileTypeControls IsNot Nothing AndAlso oAbstractCallSubmissionTypeFileTypeControls.Count > 0 Then

            Dim MaxAttachments As Integer
            Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            oAbstractCallSubmissionTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs(), GetSubType())
            If oAbstractCallSubmissionTypes IsNot Nothing AndAlso oAbstractCallSubmissionTypes.Count > 0 Then
                MaxAttachments = oAbstractCallSubmissionTypes(0).MaxAttachments
            End If

            Dim oAbstractSubmissionAttachments As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles
            oAbstractSubmissionAttachments = CallManager.GetSubmissionAttachments(PortalId, AbstractSubmissionId)

            If MaxAttachments = 0 OrElse (oAbstractSubmissionAttachments IsNot Nothing And oAbstractSubmissionAttachments.Count < MaxAttachments) Then
                Dim regex As String = ""
                Dim errormessage As String = "Please select a valid file:"
                For Each oAbstractCallSubmissionTypeFileTypeControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeFileTypeControl In oAbstractCallSubmissionTypeFileTypeControls
                    If regex.Length > 0 Then regex = String.Concat(regex, "|")
                    If errormessage.Length > 0 Then errormessage = String.Concat(errormessage, " ")
                    regex = String.Concat(regex, oAbstractCallSubmissionTypeFileTypeControl.FileTypeCodeString)
                    errormessage = String.Concat(errormessage, "*.", oAbstractCallSubmissionTypeFileTypeControl.FileTypeCodeString)
                Next
                FileTypeRegularExpression = String.Concat("(?i:^([a-zA-Z].*|[1-9].*)\.(", regex, ")$)")
                RegularExpressionValidatorUpload.ValidationExpression = FileTypeRegularExpression
                FileTypeErrorMessage = errormessage
                RegularExpressionValidatorUpload.ErrorMessage = errormessage
                DoesFileTypeExist = "Y"
            End If
        Else
            DoesFileTypeExist = "N"
            RadAjaxPanelUploadAttachments.Visible = False
        End If

    End Sub
    Private Function ValidateQS() As Boolean
        If GetArgs() Is Nothing Or GetSubType() Is Nothing Or AbstractSubmissionId = 0 Then
            Return False
        Else
            Return True
        End If

    End Function

    Protected Sub btnSubmitAttachments_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        BindValidResults()
    End Sub



    Private Sub BindValidResults()

        If Page.IsValid Then

            If Request.Files.Count > 0 Then
                Dim attachment As New ArrayList
                If Not [Object].Equals(UploadedFile.FromHttpPostedFile(Request.Files(0)), Nothing) Then
                    Dim filename As String = UploadedFile.FromHttpPostedFile(Request.Files(0)).GetName

                    If Not String.IsNullOrEmpty(Request.Files(0).FileName) Then

                        Dim targetFolder As String = Path.GetTempPath()
                        Dim validFile As UploadedFile = UploadedFile.FromHttpPostedFile(Request.Files(0))

                        validFile.SaveAs(targetFolder & filename, True)
                        If validFile.ContentLength > 0 Then

                            ErrorUploadLabel.Text = ""

                            Dim MaxAttachments As Integer
                            Dim MaxFileSizeMB As Integer
                            Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
                            oAbstractCallSubmissionTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs(), GetSubType())
                            If oAbstractCallSubmissionTypes IsNot Nothing AndAlso oAbstractCallSubmissionTypes.Count > 0 Then
                                MaxFileSizeMB = oAbstractCallSubmissionTypes(0).MaxFileSizeMB
                                MaxAttachments = oAbstractCallSubmissionTypes(0).MaxAttachments
                            End If

                            If MaxFileSizeMB = 0 OrElse MaxFileSizeMB * 1024 * 1024 > validFile.ContentLength Then


                                Dim oAbstractSubmissionAttachments As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles
                                oAbstractSubmissionAttachments = CallManager.GetSubmissionAttachments(PortalId, AbstractSubmissionId)

                                If MaxAttachments = 0 OrElse (oAbstractSubmissionAttachments IsNot Nothing And oAbstractSubmissionAttachments.Count < MaxAttachments) Then
                                    ErrorUploadLabel.Text = ""


                                    Dim AdditionalPathExtension As String = String.Concat(AbstractCallCodeHiddenField.Value, "\", SubmissionTypeCodeHiddenField.Value, "\", AbstractSubmissionId)
                                    Dim status As String = _
                     TIMSS.ThirdPartyInterfaces.FileOperation.UploadFile(TIMSS.Server.BusinessMessages.FileUploadDownload.UploadResourceType.AbstractFiles, targetFolder & filename, AdditionalPathExtension)

                                    If status.Length > 1 AndAlso Not status.Contains("has successfully been upload") Then
                                        ErrorUploadLabel.Text = status
                                    Else
                                        ErrorUploadLabel.Text = ""
                                    End If

                                    'save in file table

                                    Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
                                    oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)
                                    oAbstractSubmissions.Filter.Add("AbstractSubmissionId", AbstractSubmissionId)
                                    oAbstractSubmissions.Fill()
                                    If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then
                                        With oAbstractSubmissions(0).AbstractSubmissionFiles.AddNew

                                            .FileName = filename
                                            'TODO check filesize 
                                            'todo check column File_Size_MB type because does not accept 1.48
                                            .ReadOnly("FileSizeMB") = False
                                            .FileSizeMB = validFile.ContentLength
                                            .Description = RadTextBoxDescription.Text
                                            Dim fileType() As String = filename.Split(".")
                                            If fileType.Length > 0 Then
                                                .FileTypeCode = .FileTypeCode.List(fileType(fileType.Length - 1).ToUpper).ToCodeObject
                                            End If
                                        End With

                                        oAbstractSubmissions.Save()

                                        If oAbstractSubmissions.ValidationIssues IsNot Nothing AndAlso oAbstractSubmissions.ValidationIssues.ErrorCount > 0 Then
                                            ShowPopupMessage(oAbstractSubmissions.ValidationIssues)
                                        Else
                                            ctlSubmissionAttachments.Reload()
                                            ValidateAttachments()
                                        End If
                                    End If
                                Else
                                    ErrorUploadLabel.Text = String.Concat("Maximum attachments: ", MaxAttachments)
                                End If
                            Else
                                ErrorUploadLabel.Text = String.Concat("Maximum file size is ", MaxFileSizeMB, " MB")
                            End If

                        Else
                            ErrorUploadLabel.Text = "Please try again"
                        End If
                    End If
                End If

                RadTextBoxDescription.Text = String.Empty

            End If


        End If

    End Sub


#End Region


#Region "Helper functions"

    Private Sub SetupControls()

        If Not IsPostBack Then

            pnlMain.Visible = True
            lblMessage.Visible = False

            If _SubmissionType IsNot Nothing Then

                Dim instructionText As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeInstruction
                instructionText = _SubmissionType.AbstractCallSubmissionTypeInstructions.FindObject("InstructionTypeCodeString", Constants.Const_InstructionType_Material)
                If instructionText IsNot Nothing Then
                    lblInstruction.Text = instructionText.InstructionText
                End If

                instructionText = _SubmissionType.AbstractCallSubmissionTypeInstructions.FindObject("InstructionTypeCodeString", Constants.Const_InstructionType_Attachment)
                If instructionText IsNot Nothing Then
                    lblAttachmentsExplanation1.Text = instructionText.InstructionText
                End If

                LoadContentData()

                pnlAttachment.Visible = _SubmissionType.AllowWebAttachmentFlag

            End If
        End If


    End Sub


    Protected Sub RadGridDisclosureQuestions_NeedDataSource(ByVal [source] As Object, _
           ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = LoadDisclosureQuestions()
        RadGridDisclosureQuestions.DataSource = list

        If list.Count = 0 Then
            pnlSubmissionDisclosureQuestions.Visible = False
        End If
    End Sub

    Protected Sub RadGridDisclosureQuestions_ItemDataBound(ByVal [source] As Object, _
           ByVal e As Telerik.Web.UI.GridItemEventArgs)

        If (TypeOf e.Item Is GridDataItem) Then

            Dim answerCode As String = String.Empty
            answerCode = CType(e.Item.DataItem, TypeDisclosureQuestionsData).DisclosureAnswerCode

            Dim oSubCodes As TIMSS.API.ApplicationInfo.IApplicationSubcodes
            oSubCodes = GetApplicationSubCodes("ABS", "DISCLOSURE_ANSWER", answerCode, True)

            Dim drpDisclosureAnswer As DropDownList = CType(e.Item, GridDataItem).FindControl("drpDisclosureAnswer")
            drpDisclosureAnswer.DataSource = oSubCodes
            drpDisclosureAnswer.DataTextField = "Description"
            drpDisclosureAnswer.DataValueField = "Subcode"
            drpDisclosureAnswer.DataBind()

            If disclosureQuestions IsNot Nothing Then
                If disclosureQuestions.ContainsKey(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("TypeDisclosureControlId")), Long)) Then
                    drpDisclosureAnswer.SelectedValue = CType(disclosureQuestions(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("TypeDisclosureControlId")), Long)), DisclosureQuestionItem).DisclosureAnswerSubCode

                End If
            End If


            Dim txtDisclosureAnswer As TextBox = CType(e.Item, GridDataItem).FindControl("txtDisclosureAnswer")

            If txtDisclosureAnswer IsNot Nothing Then
                If disclosureQuestions.ContainsKey(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("TypeDisclosureControlId")), Long)) Then


                    txtDisclosureAnswer.Text = CType(disclosureQuestions(CType((CType(e.Item, GridDataItem).OwnerTableView.DataKeyValues(e.Item.ItemIndex)("TypeDisclosureControlId")), Long)), DisclosureQuestionItem).DisclosureAnswerText
                End If
            End If
        End If
    End Sub

    Private Function LoadDisclosureQuestions() As ArrayList
        Dim oTypeDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls
        oTypeDisclosureQuestions = CallManager.ABSSubmissionType_GetDisclosureQuestions(PortalId, GetArgs, GetSubType)

        Dim list As ArrayList = New ArrayList()


        If oTypeDisclosureQuestions IsNot Nothing AndAlso oTypeDisclosureQuestions.Count > 0 Then

            For i As Integer = 0 To oTypeDisclosureQuestions.Count - 1
                Dim row As TypeDisclosureQuestionsData = New TypeDisclosureQuestionsData()
                row.TypeDisclosureControlId = oTypeDisclosureQuestions(i).AbstractCallSubmissionTypeDisclosureQuestionControlId
                row.AbstractCallCode = oTypeDisclosureQuestions(i).AbstractCallCode
                row.SubmissionTypeCode = oTypeDisclosureQuestions(i).SubmissionTypeCode
                row.QuestionSeq = oTypeDisclosureQuestions(i).QuestionSequence
                row.QuestionText = oTypeDisclosureQuestions(i).QuestionText
                row.DisclosureQuestionCode = oTypeDisclosureQuestions(i).DisclosureQuestionCodeString
                row.DisclosureAnswerCode = oTypeDisclosureQuestions(i).DisclosureAnswerCodeString
                row.RejectionDisclosureAnswerSubcode = oTypeDisclosureQuestions(i).RejectionDisclosureAnswerSubcodeString
                row.Required = oTypeDisclosureQuestions(i).AnswerRequiredFlag
                row.CodedAnswerFlag = oTypeDisclosureQuestions(i).CodedAnswerFlag

                'If row.QuestionSeq > _LargestSeq Then
                '_LargestSeq = row.QuestionSeq
                'End If
                list.Add(row)
            Next
        End If

        Return list

    End Function

    Private Sub LoadTextBlocks(ByVal oAbstractCallSubmissionTypeTextBlockControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls)
        'Dim oAbstractCallSubmissionTypeTextBlockControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls
        'oAbstractCallSubmissionTypeTextBlockControls = CallManager.ABSSubmissionTypeTextBlock_Get(PortalId, GetArgs, GetSubType)

        If oAbstractCallSubmissionTypeTextBlockControls IsNot Nothing AndAlso oAbstractCallSubmissionTypeTextBlockControls.Count > 0 Then
            For Each oAbstractCallSubmissionTypeTextBlockControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl In oAbstractCallSubmissionTypeTextBlockControls
                Dim textBlockHeadingLabel As New Label
                With textBlockHeadingLabel
                    .Text = String.Concat("<h4>", oAbstractCallSubmissionTypeTextBlockControl.Heading, "</h4>")
                    .ID = "lblHeading" & oAbstractCallSubmissionTypeTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId 'InstructionText
                    .Width = Unit.Pixel(400)
                    '.CssClass = "h4"
                End With
                phTextBlocks.Controls.Add(textBlockHeadingLabel)
                Dim newline As New System.Web.UI.WebControls.Literal
                newline.Text = "<br/>"
                phTextBlocks.Controls.Add(newline)


                If Not String.IsNullOrEmpty(oAbstractCallSubmissionTypeTextBlockControl.InstructionCaptionText) Then
                    Dim textBlockLabel As New Label
                    With textBlockLabel
                        .Text = String.Concat(oAbstractCallSubmissionTypeTextBlockControl.InstructionCaptionText)
                        .ID = "lbl" & oAbstractCallSubmissionTypeTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId 'InstructionCaptionText
                        .Width = Unit.Pixel(500)
                    End With
                    phTextBlocks.Controls.Add(textBlockLabel)
                    newline = New System.Web.UI.WebControls.Literal
                    newline.Text = "<br/>"
                    phTextBlocks.Controls.Add(newline)
                End If

                If Not String.IsNullOrEmpty(oAbstractCallSubmissionTypeTextBlockControl.InstructionText) Then
                    Dim textBlockLabel2 As New Label
                    With textBlockLabel2
                        .Text = String.Concat("<h5>", oAbstractCallSubmissionTypeTextBlockControl.InstructionText, "</h5>")
                        .ID = "lbl2" & oAbstractCallSubmissionTypeTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId 'InstructionText
                        .Width = Unit.Pixel(500)
                    End With
                    phTextBlocks.Controls.Add(textBlockLabel2)
                    newline = New System.Web.UI.WebControls.Literal
                    newline.Text = "<br/>"
                    phTextBlocks.Controls.Add(newline)
                End If

                Dim textBlockTextbox As New RadEditor
                With textBlockTextbox
                    .EnableResize = False                    
                    '.TextMode = InputMode.MultiLine
                    .ID = "txt" & oAbstractCallSubmissionTypeTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId 'InstructionText
                    '.MaxLength = oAbstractCallSubmissionTypeTextBlockControl.MaxWordCount
                    .Width = Unit.Pixel(650)
                    .Height = Unit.Pixel(400) 'Unit.Pixel(15 * (1 + oAbstractCallSubmissionTypeTextBlockControl.MaxWordCount / 50))                    
                    textBlockTextbox.SkinID = "DefaultSetOfTools"
                    .ToolsFile = ModulePath + "/FullSetOfTools.xml"
                End With
                phTextBlocks.Controls.Add(textBlockTextbox)
                newline = New System.Web.UI.WebControls.Literal
                newline.Text = "<br/>"
                phTextBlocks.Controls.Add(newline)

                'field for size
                Dim SizeLabel As New Label
                SizeLabel.Text = "Maximum characters count: " + oAbstractCallSubmissionTypeTextBlockControl.MaxWordCount.ToString  'char count actually
                phTextBlocks.Controls.Add(SizeLabel)

                'field for size
                Dim SizeHiddenField As New HiddenField
                SizeHiddenField.ID = "size" & oAbstractCallSubmissionTypeTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId
                SizeHiddenField.Value = oAbstractCallSubmissionTypeTextBlockControl.MaxWordCount 'char count actually
                phTextBlocks.Controls.Add(SizeHiddenField)

                'validator for size
                Dim oCustomValidator As New CustomValidator
                'oCustomValidator.ErrorMessage = " Characters: " + oAbstractCallSubmissionTypeTextBlockControl.MaxWordCount.ToString()
                oCustomValidator.ControlToValidate = textBlockTextbox.ID
                oCustomValidator.ValidationGroup = "BlockText"

                AddHandler oCustomValidator.ServerValidate, AddressOf SizeCustomValidator_ServerValidate

                phTextBlocks.Controls.Add(oCustomValidator)

                newline = New System.Web.UI.WebControls.Literal
                newline.Text = "<br/><br />"
                phTextBlocks.Controls.Add(newline)

            Next
        End If
    End Sub

    Protected Sub SizeCustomValidator_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs)
        Dim MaxSize As Integer
        Dim ActualSize As Integer

        Dim oCustomValidator As CustomValidator = CType(source, CustomValidator)
        Dim SizeHiddenField As HiddenField
        SizeHiddenField = CType(phTextBlocks.FindControl(oCustomValidator.ControlToValidate.Replace("txt", "size")), HiddenField)
        If SizeHiddenField IsNot Nothing Then
            MaxSize = Convert.ToInt32(SizeHiddenField.Value)
        End If

        Dim textBlockTextbox As RadEditor
        textBlockTextbox = CType(phTextBlocks.FindControl(oCustomValidator.ControlToValidate), RadEditor)
        If textBlockTextbox IsNot Nothing Then
            'Dim re As New System.Text.RegularExpressions.Regex("\s+", System.Text.RegularExpressions.RegexOptions.IgnoreCase)
            'Dim ActualText As String = textBlockTextbox.Text.Replace("-", "").Trim()
            'ActualText = re.Replace(ActualText, " ")
            'ActualSize = ActualText.Trim().Length
            Dim ActualText As String = textBlockTextbox.Text.Trim()
            '[\,.]
            Dim strRegex As String = "[\,.;:?]|[\n]"
            Dim re As New System.Text.RegularExpressions.Regex(strRegex, System.Text.RegularExpressions.RegexOptions.IgnoreCase)
            ActualText = re.Replace(ActualText, "")
            ActualSize = ActualText.Trim().Length

        End If


        If MaxSize = 0 OrElse ActualSize <= MaxSize Then
            args.IsValid = True
        Else
            oCustomValidator.ErrorMessage = "  Exceeded Word Count. Total Characters: " + ActualSize.ToString()
            args.IsValid = False
        End If
    End Sub


    Protected Sub butConfirm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butConfirm.Click
        If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oValidationIssues = SaveContent()

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                ShowPopupMessage(oValidationIssues)
            Else
                ShowPopupMessage(Constants.Const_Save_Message)
                Dim url As String
                If Not String.IsNullOrEmpty(Request("returnurl")) Then
                    url = Request("returnurl")
                Else
                    url = GetNextPageURL(Author_SubmissionEntryConfirmation, GetArgs, AbstractSubmissionId, 0, GetSubType)
                End If
                Response.Redirect(url, True)
            End If
        Else
            ShowPopupMessage(Constants.Const_ContentPageError)
        End If

    End Sub
    Private Function ValidateSubmissionTypeDates() As Boolean

        Return True
    End Function


    Protected Sub butPrevious_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butPrevious.Click
        Dim url As String
        If Not String.IsNullOrEmpty(Request("returnurl")) Then
            url = Request("returnurl")
        Else
            url = GetAuthorPageURL(Author_SubmissionEntryAuthorInformation, GetArgs, AbstractSubmissionId, AuthorId, GetSubType)
        End If
        Response.Redirect(url, True)
    End Sub

    Protected Sub LoadContentData()
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
        oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)
        oAbstractSubmissions.Filter.Add("AbstractSubmissionId", AbstractSubmissionId)
        oAbstractSubmissions.Fill()
        If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then
            With oAbstractSubmissions(0)


                AbstractCallCodeHiddenField.Value = oAbstractSubmissions(0).AbstractCallCode
                SubmissionTypeCodeHiddenField.Value = oAbstractSubmissions(0).SubmissionTypeCode

                Dim item As RadComboBoxItem
                If .PermissionToRecordFlag Then
                    item = RadComboBoxRecordPresentation.FindItemByValue("Y")
                Else
                    item = RadComboBoxRecordPresentation.FindItemByValue("N")
                End If
                If item IsNot Nothing Then
                    item.Selected = True
                End If

                If .PermissionToPhotographFlag Then
                    item = RadComboBoxTakePhotographs.FindItemByValue("Y")
                Else
                    item = RadComboBoxTakePhotographs.FindItemByValue("N")
                End If
                If item IsNot Nothing Then
                    item.Selected = True
                End If

                If .PermissionToPublishFlag Then
                    item = RadComboBoxPublish.FindItemByValue("Y")
                Else
                    item = RadComboBoxPublish.FindItemByValue("N")
                End If
                If item IsNot Nothing Then
                    item.Selected = True
                End If


                If .ConsiderForOtherTypeFlag Then
                    item = RadComboBoxOtherPresentations.FindItemByValue("Y")
                Else
                    item = RadComboBoxOtherPresentations.FindItemByValue("N")
                End If
                If item IsNot Nothing Then
                    item.Selected = True
                End If
            End With

            Dim oAbstractSubmissionTextBlocks As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlocks
            oAbstractSubmissionTextBlocks = oAbstractSubmissions(0).AbstractSubmissionTextBlocks
            If oAbstractSubmissionTextBlocks IsNot Nothing Then
                For Each oAbstractSubmissionTextBlock As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlock In oAbstractSubmissionTextBlocks
                    Dim textBlockTextbox As RadEditor
                    textBlockTextbox = CType(phTextBlocks.FindControl("txt" & oAbstractSubmissionTextBlock.AbstractCallSubmissionTypeTextBlockControlId), RadEditor)
                    If textBlockTextbox IsNot Nothing Then
                        textBlockTextbox.Content = oAbstractSubmissionTextBlock.BlockText
                    End If
                Next
            End If

            Dim oAbstractSubmissionFiles As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles
            oAbstractSubmissionFiles = oAbstractSubmissions(0).AbstractSubmissionFiles

            'Dim AttachmentList As ArrayList = New ArrayList

            'For Each oAbstractSubmissionFile As TIMSS.API.AbstractInfo.IAbstractSubmissionFile In oAbstractSubmissionFiles
            '    Dim attachment As New AttachmentItem(oAbstractSubmissionFile.FileName, oAbstractSubmissionFile.FileSizeMB * 1024 * 1024, oAbstractSubmissionFile.Description)
            '    AttachmentList.Add(attachment)
            'Next

            'If AttachmentList IsNot Nothing AndAlso AttachmentList.Count > 0 Then
            '    RadTextBoxDescription.Text = String.Empty
            '    'labelNoResults.Text = "Uploaded Files"
            'End If

            'repeaterAttachments.Visible = True
            'repeaterAttachments.DataSource = AttachmentList
            'repeaterAttachments.DataBind()

            disclosureQuestions = New Hashtable
            Dim oDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractSubmissionDisclosures
            oDisclosureQuestions = oAbstractSubmissions(0).AbstractSubmissionDisclosures
            For Each oDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractSubmissionDisclosure In oDisclosureQuestions
                With oDisclosureQuestion
                    Dim disclosureQuestion As New DisclosureQuestionItem(.AbstractCallSubmissionTypeDisclosureQuestionControlId, .QuestionText, .DisclosureAnswerSubcodeString, .DisclosureAnswerText)
                    disclosureQuestions.Add(.AbstractCallSubmissionTypeDisclosureQuestionControlId, disclosureQuestion)
                End With
            Next
        End If
    End Sub

    Protected Function SaveContent() As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions
        oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)
        oAbstractSubmissions.Filter.Add("AbstractSubmissionId", AbstractSubmissionId)
        oAbstractSubmissions.Fill()
        If oAbstractSubmissions Is Nothing OrElse oAbstractSubmissions.Count = 0 Then
            Return Nothing
        End If
        With oAbstractSubmissions(0)
            .PermissionToRecordFlag = IIf(RadComboBoxRecordPresentation.SelectedValue = "Y", True, False)
            .PermissionToPhotographFlag = IIf(RadComboBoxTakePhotographs.SelectedValue = "Y", True, False)
            .PermissionToPublishFlag = IIf(RadComboBoxPublish.SelectedValue = "Y", True, False)
            .ConsiderForOtherTypeFlag = IIf(RadComboBoxOtherPresentations.SelectedValue = "Y", True, False)
        End With

        oAbstractSubmissions(0).AbstractSubmissionTextBlocks.RemoveAll()

        Dim oAbstractCallSubmissionTypeTextBlockControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls
        oAbstractCallSubmissionTypeTextBlockControls = CallManager.ABSSubmissionTypeTextBlock_Get(PortalId, GetArgs, GetSubType)
        If oAbstractCallSubmissionTypeTextBlockControls IsNot Nothing Then
            For Each oAbstractCallSubmissionTypeTextBlockControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl In oAbstractCallSubmissionTypeTextBlockControls
                Dim textBlockTextbox As RadEditor
                textBlockTextbox = CType(phTextBlocks.FindControl("txt" & oAbstractCallSubmissionTypeTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId), RadEditor)
                If textBlockTextbox IsNot Nothing Then
                    Dim oAbstractSubmissionTextBlock As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlock
                    oAbstractSubmissionTextBlock = oAbstractSubmissions(0).AbstractSubmissionTextBlocks.AddNew
                    oAbstractSubmissionTextBlock.AbstractCallSubmissionTypeTextBlockControlId = CInt(textBlockTextbox.ID.Substring(3))
                    oAbstractSubmissionTextBlock.BlockText = PersonifyWebCommon.ConvertUnRecognizedSymbols(textBlockTextbox.Content)
                End If
            Next
        End If

        'oAbstractSubmissions(0).AbstractSubmissionFiles.RemoveAll()



        Dim oTypeDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls
        oTypeDisclosureQuestions = CallManager.ABSSubmissionType_GetDisclosureQuestions(PortalId, GetArgs, GetSubType)

        oAbstractSubmissions(0).AbstractSubmissionDisclosures.RemoveAll()

        Dim index As Integer = 0
        Dim RejectionBecauseOfTheAnswer As New ArrayList

        For Each QuestionItem As Telerik.Web.UI.GridDataItem In RadGridDisclosureQuestions.Items
            'The answer will either be in DropDown OR in TextBox
            Dim drpDisclosureQuestion As DropDownList = QuestionItem.FindControl("drpDisclosureAnswer")
            Dim txtDisclosureQuestion As TextBox = QuestionItem.FindControl("txtDisclosureAnswer")

            If (oTypeDisclosureQuestions IsNot Nothing OrElse txtDisclosureQuestion IsNot Nothing) AndAlso oTypeDisclosureQuestions.Count > 0 Then
                For i As Integer = 0 To oTypeDisclosureQuestions.Count - 1
                    If CInt(QuestionItem.OwnerTableView.DataKeyValues(index)("TypeDisclosureControlId")) = oTypeDisclosureQuestions(i).AbstractCallSubmissionTypeDisclosureQuestionControlId Then

                        Dim oDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractSubmissionDisclosure
                        oDisclosureQuestion = oAbstractSubmissions(0).AbstractSubmissionDisclosures.AddNew

                        With oDisclosureQuestion
                            .AbstractCallSubmissionTypeDisclosureQuestionControlId = oTypeDisclosureQuestions(i).AbstractCallSubmissionTypeDisclosureQuestionControlId
                            If oTypeDisclosureQuestions(i).AnswerRequiredFlag Then
                                'Check if drpDisclosureQuestion exists
                                If drpDisclosureQuestion IsNot Nothing AndAlso oTypeDisclosureQuestions(i).CodedAnswerFlag = True Then
                                    If drpDisclosureQuestion.SelectedValue = oTypeDisclosureQuestions(i).RejectionDisclosureAnswerSubcodeString Then
                                        RejectionBecauseOfTheAnswer.Add(oTypeDisclosureQuestions(i).QuestionText)
                                    End If
                                End If

                            End If
                            .DisclosureAnswerSubcode = .DisclosureAnswerSubcode.List(drpDisclosureQuestion.SelectedValue).ToCodeObject
                            'If text box, then set the disclosure 
                            If txtDisclosureQuestion IsNot Nothing Then
                                .DisclosureAnswerText = txtDisclosureQuestion.Text
                            End If

                            .QuestionText = oTypeDisclosureQuestions(i).QuestionText
                        End With

                        Exit For
                    End If
                Next
            End If
            index = index + 1
        Next

        If oAbstractSubmissions(0).AbstractCallSubmissionTypeInfo IsNot Nothing _
            AndAlso oAbstractSubmissions(0).AbstractCallSubmissionTypeInfo.MinAttachments > 0 _
            AndAlso oAbstractSubmissions(0).AbstractSubmissionFiles IsNot Nothing _
            AndAlso oAbstractSubmissions(0).AbstractSubmissionFiles.Count < 1 Then
            Dim oMinAttachmentsList As New TIMSS.API.Core.Validation.IssuesCollection
            Dim oMinAttachmentsObj As New TIMSS.API.Core.BusinessObject()
            Dim oMinAttachmentsIssue As New TIMSS.API.Core.Validation.IssueBase(oMinAttachmentsObj)
            With oMinAttachmentsIssue
                .Message = "Please select minimum " & oAbstractSubmissions(0).AbstractCallSubmissionTypeInfo.MinAttachments.ToString & " file(s) to upload."
                .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                .ResponseRequired = False
            End With
            oMinAttachmentsList.Add(oMinAttachmentsIssue)
            Return oMinAttachmentsList
        End If

            If RejectionBecauseOfTheAnswer IsNot Nothing AndAlso RejectionBecauseOfTheAnswer.Count > 0 Then
                Dim oIssuesList As New TIMSS.API.Core.Validation.IssuesCollection
                For i As Integer = 0 To RejectionBecauseOfTheAnswer.Count - 1
                    Dim obj As New TIMSS.API.Core.BusinessObject()
                    Dim oIssue As New TIMSS.API.Core.Validation.IssueBase(obj)
                    With oIssue
                        .Message = "Rejected because of the answer to question " & RejectionBecauseOfTheAnswer(i)
                        .Severity = TIMSS.API.Core.Validation.IssueSeverityEnum.Error
                        .ResponseRequired = False
                    End With
                    oIssuesList.Add(oIssue)
                Next
                Return oIssuesList

            Else
                oAbstractSubmissions.Save()
                Return oAbstractSubmissions.ValidationIssues
            End If

    End Function
#End Region






End Class

'Public Class AttachmentItem
'    Private _Description As String
'    Private _AttachmentName As String
'    Private _ContentLength As String
'    Public Property AttachmentName() As String
'        Get
'            Return _AttachmentName
'        End Get
'        Set(ByVal value As String)
'            _AttachmentName = value
'        End Set
'    End Property

'    Public Property Description() As String
'        Get
'            Return _Description
'        End Get
'        Set(ByVal value As String)
'            _Description = value
'        End Set
'    End Property
'    Public Property ContentLength() As String
'        Get
'            Return _ContentLength
'        End Get
'        Set(ByVal value As String)
'            _ContentLength = value
'        End Set
'    End Property
'    Public Sub New(ByVal AttachmentName As String, ByVal ContentLength As String, ByVal Description As String)
'        Me.AttachmentName = AttachmentName
'        Me.ContentLength = ContentLength
'        Me.Description = Description
'    End Sub
'End Class


Public Class DisclosureQuestionItem
    Private _TypeDisclosureControlId As Integer
    Private _QuestionText As String = Nothing
    'Private _DisclosureQuestionCode As String
    'Private _DisclosureAnswerCode As String
    Private _DisclosureAnswerSubCode As String
    Private _DisclosureAnswerText As String

    Public Property TypeDisclosureControlId() As Integer
        Get
            Return _TypeDisclosureControlId
        End Get
        Set(ByVal value As Integer)
            _TypeDisclosureControlId = value
        End Set
    End Property

    Public Property QuestionText() As String
        Get
            Return _QuestionText
        End Get
        Set(ByVal value As String)
            _QuestionText = value
        End Set
    End Property
    Public Property DisclosureAnswerText() As String
        Get
            Return _DisclosureAnswerText
        End Get
        Set(ByVal value As String)
            _DisclosureAnswerText = value
        End Set
    End Property
    'Public Property DisclosureQuestionCode() As String
    '    Get
    '        Return _DisclosureQuestionCode
    '    End Get
    '    Set(ByVal value As String)
    '        _DisclosureQuestionCode = value
    '    End Set
    'End Property

    'Public Property DisclosureAnswerCode() As String
    '    Get
    '        Return _DisclosureAnswerCode
    '    End Get
    '    Set(ByVal value As String)
    '        _DisclosureAnswerCode = value
    '    End Set
    'End Property

    Public Property DisclosureAnswerSubCode() As String
        Get
            Return _DisclosureAnswerSubCode
        End Get
        Set(ByVal value As String)
            _DisclosureAnswerSubCode = value
        End Set
    End Property




    Public Sub New(ByVal TypeDisclosureControlId As Integer, ByVal QuestionText As String, ByVal DisclosureAnswerSubCode As String, ByVal DisclosureAnswerText As String)
        Me.TypeDisclosureControlId = TypeDisclosureControlId
        Me.QuestionText = QuestionText
        'Me.DisclosureQuestionCode = DisclosureQuestionCode
        'Me.DisclosureAnswerCode = DisclosureAnswerCode
        Me.DisclosureAnswerText = DisclosureAnswerText
        Me.DisclosureAnswerSubCode = DisclosureAnswerSubCode
    End Sub
End Class
