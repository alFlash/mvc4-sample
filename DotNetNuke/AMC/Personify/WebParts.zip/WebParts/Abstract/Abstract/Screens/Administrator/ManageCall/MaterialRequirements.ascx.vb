Imports ScreenController.AbstractScreen
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports Constants

Public Class MaterialRequirements
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables & Properties"

    Protected WithEvents butContinue As Button
    Protected WithEvents butPrev As Button
    Protected WithEvents rdTopicNone As RadioButton
    Protected WithEvents rdTopicSystem As RadioButton
    Protected WithEvents rdTopicCustom As RadioButton
    Protected WithEvents rdKeywordNone As RadioButton
    Protected WithEvents rdKeywordSystem As RadioButton
    Protected WithEvents rdKeywordCustom As RadioButton

    Protected WithEvents chkAllowAttachment As CheckBox
    Protected WithEvents txtMinAttachment As RadNumericTextBox
    Protected WithEvents txtMaxAttachment As RadNumericTextBox
    Protected WithEvents txtMaxSizePerFile As RadNumericTextBox

    Protected WithEvents RadAuthorSubmissionInstructions As RadEditor
    Protected WithEvents radAttachmentInstructions As RadEditor
    Protected WithEvents GridSubmissionDisclosureQuestions As RadGrid
    Protected WithEvents pnlAttachment As Panel

    Protected WithEvents butUpdate As Button
    Protected WithEvents GridTextBlock As RadGrid
    Protected WithEvents butMoveTextup As ImageButton
    Protected WithEvents butMoveTextdown As ImageButton
    Protected WithEvents chkFileTypes As CheckBoxList

    Protected WithEvents lblCallCode As Label
    Protected WithEvents lblTitlePage As Label

    Protected WithEvents ReorderChanges_GridTextBlock As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents ReorderChanges_GridSubmissionDisclosureQuestions As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents RadGridTopics As RadGrid
    Protected WithEvents RadGridKeywords As RadGrid
    Protected WithEvents ddlKeywordSystemList As RadComboBox
    Protected WithEvents ddlTopicSystemList As RadComboBox
    Protected WithEvents pnlTopics As Panel
    Protected WithEvents pnlKeywords As Panel

    Protected WithEvents ddlDisclosureAnswerCode As RadComboBox
    Protected WithEvents ddlRejectionDisclosureAnswerSubcode As RadComboBox
    Protected WithEvents ddlDisclosureQuestionCode As RadComboBox

    Protected WithEvents chkCodedAnswerFlag As CheckBox
    Protected WithEvents txtSubmissionDisclosureQuestions As RadTextBox
    Protected WithEvents chkAnswerRequiredFlag As CheckBox

    Protected WithEvents txtHeading As RadTextBox
    Protected WithEvents txtLimit As RadNumericTextBox
    Protected WithEvents txtInstruction As RadTextBox

    'Private _UpdateMode As Boolean = False
    Private _HashExistingTopics As Hashtable
    Private _HashExistingKeywords As Hashtable
    Private _EditItemIndex As Integer = -1
    Private _AnswerCodeChanged As Boolean = False
    Private _LoadEditTemplate As Boolean = False

    Private grdTextBlocksDisableCommandItem As Boolean
    Private grdTextBlocksDisableEditItems As Boolean

    Private grdQuestionsDisableCommandItem As Boolean
    Private grdQuestionsDisableEditItems As Boolean

#End Region


#Region "Helper functions"

    Private Function DisclosureAnswerCode_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "DISCLOSURE_ANSWER", True)
    End Function

    Private Function DisclosureQuestionCode_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "DISCLOSURE_QUESTION", True)
    End Function

    Private Function RejectionDisclosureAnswerSubcode_Get(ByVal Code As String) As TIMSS.API.ApplicationInfo.IApplicationSubcodes
        Return GetApplicationSubCodes("ABS", "DISCLOSURE_ANSWER", Code, True)
    End Function

    Private Sub SetupControls()
        'ddlSubmissionType
        'Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        'appCodes =  GetApplicationCodes( "ABS", "SUBMISSION_TYPE")
        'Load data if exists        
        'chkFileTypes
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        appCodes = GetApplicationCodes("ABS", "FILE_TYPE", True)

        chkFileTypes.DataSource = appCodes
        chkFileTypes.DataTextField = "Description"
        chkFileTypes.DataValueField = "Code"
        chkFileTypes.DataBind()

        If GetArgs() IsNot Nothing AndAlso GetSubType() IsNot Nothing Then
            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            Dim absSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType

            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                absSubType = absSubTypes(0)
                lblCallCode.Text = absSubType.AbstractCallCode + " - "
                lblTitlePage.Text = absSubType.Description

                Select Case absSubType.ValidateKeywordControlCodeString
                    Case Const_Validation_None
                        rdKeywordNone.Checked = True
                        rdKeywordChanged()
                    Case Const_Validation_SystemCode
                        rdKeywordSystem.Checked = True
                        rdKeywordChanged(absSubType.ValidationKeywordCodeString)
                    Case Const_Validation_Custom
                        rdKeywordCustom.Checked = True
                        rdKeywordChanged()
                End Select
                Select Case absSubType.ValidateTopicControlCodeString
                    Case Const_Validation_None
                        rdTopicNone.Checked = True
                        rdTopicChanged()
                    Case Const_Validation_SystemCode
                        rdTopicSystem.Checked = True
                        rdTopicChanged(absSubType.ValidationTopicCodeString)
                    Case Const_Validation_Custom
                        rdTopicCustom.Checked = True
                        rdTopicChanged()
                End Select

                Me.chkAllowAttachment.Checked = absSubType.AllowWebAttachmentFlag
                If Me.chkAllowAttachment.Checked Then
                    pnlAttachment.Visible = True
                Else
                    pnlAttachment.Visible = False
                End If
                Me.txtMinAttachment.Text = absSubType.MinAttachments
                Me.txtMaxAttachment.Text = absSubType.MaxAttachments
                Me.txtMaxSizePerFile.Text = absSubType.MaxFileSizeMB

                'Instructions
                Dim absInstruction As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeInstruction
                For Each absInstruction In absSubType.AbstractCallSubmissionTypeInstructions
                    If absInstruction.InstructionTypeCodeString.ToUpper = Const_InstructionType_Material Then
                        Me.RadAuthorSubmissionInstructions.Content = absInstruction.InstructionText
                    End If
                    If absInstruction.InstructionTypeCodeString.ToUpper = Const_InstructionType_Attachment Then
                        Me.radAttachmentInstructions.Content = absInstruction.InstructionText
                    End If
                Next

                'Submission Disclosure 
                GridSubmissionDisclosureQuestions.SortingSettings.EnableSkinSortStyles = False
                Me.GridSubmissionDisclosureQuestions.DataSource = absSubType.AbstractCallSubmissionTypeDisclosureQuestionControls
                'Me.GridSubmissionDisclosureQuestions.DataBind()
                GridTextBlock.SortingSettings.EnableSkinSortStyles = False
                Me.GridTextBlock.DataSource = absSubType.AbstractCallSubmissionTypeTextBlockControls
                'Me.GridTextBlock.DataBind()

                'Dim imagesFolder As String = GetImagesFolder(PortalId)
                'butMoveTextup.ImageUrl = ResolveUrl("~/" & imagesFolder & "/up_24.gif")
                'butMoveTextdown.ImageUrl = ResolveUrl("~/" & imagesFolder & "/down_24.gif")

                Dim oFileType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeFileTypeControl
                For Each oFileType In absSubType.AbstractCallSubmissionTypeFileTypeControls
                    For Each item As ListItem In Me.chkFileTypes.Items
                        If item.Value = oFileType.FileTypeCodeString Then
                            item.Selected = True
                            Exit For
                        End If
                    Next
                Next


            End If

        End If
    End Sub

    Private Sub RadGridTopics_NeedDataSource(ByVal source As System.Object, ByVal e As GridNeedDataSourceEventArgs) Handles RadGridTopics.NeedDataSource
        'Get the existing Topics
        _HashExistingTopics = CallManager.ABSSubmissionType_ExistingTopics_Get(PortalId, GetArgs(), GetSubType())
        RadGridTopics.DataSource = CallManager.ABSSubmissionType_TopicsKeywords_Get(PortalId, "SUBMISSION_TOPIC")
    End Sub

    Protected Sub RadGridTopics_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridTopics.ItemDataBound
        Dim chkSelectTopic As CheckBox
        If TypeOf e.Item Is GridDataItem Then
            Dim dataItem As GridDataItem = DirectCast(e.Item, GridDataItem)
            chkSelectTopic = CType(dataItem.FindControl("chkSelectTopic"), CheckBox)
            Dim strTopic As String = dataItem("Key").Text.ToString()
            'Check if the Topic already exitsts
            If _HashExistingTopics IsNot Nothing Then
                If _HashExistingTopics.Contains(strTopic) Then
                    chkSelectTopic.Checked = True
                End If
            End If
        End If
    End Sub

    Private Sub RadGridKeywords_NeedDataSource(ByVal source As System.Object, ByVal e As GridNeedDataSourceEventArgs) Handles RadGridKeywords.NeedDataSource
        'Get the existing Topics
        _HashExistingKeywords = CallManager.ABSSubmissionType_ExistingKeywords_Get(PortalId, GetArgs(), GetSubType())
        RadGridKeywords.DataSource = CallManager.ABSSubmissionType_TopicsKeywords_Get(PortalId, "SUBMISSION_KEYWORD")
    End Sub

    Protected Sub RadGridKeywords_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles RadGridKeywords.ItemDataBound
        Dim chkSelectKeyword As CheckBox
        If TypeOf e.Item Is GridDataItem Then
            Dim dataItem As GridDataItem = DirectCast(e.Item, GridDataItem)
            chkSelectKeyword = CType(dataItem.FindControl("chkSelectKeyword"), CheckBox)
            Dim strKeyword As String = dataItem.DataItem.Key
            'Check if the Keyword already exists
            If _HashExistingKeywords IsNot Nothing Then
                If _HashExistingKeywords.Contains(strKeyword) Then
                    chkSelectKeyword.Checked = True
                End If
            End If
        End If
    End Sub


    Private Function IsTopicChecked() As Boolean
        If rdTopicNone.Checked OrElse rdTopicSystem.Checked OrElse rdTopicCustom.Checked Then
            Return True
        End If
        Return False
    End Function

    Private Function GetTopicChecedCodeString() As String
        If rdTopicNone.Checked Then
            Return Const_Validation_None
        End If
        If rdTopicSystem.Checked Then
            Return Const_Validation_SystemCode
        End If
        If rdTopicCustom.Checked Then
            Return Const_Validation_Custom
        End If
        Return Nothing
    End Function

    Private Function IsKeywordChecked() As Boolean
        If rdKeywordNone.Checked OrElse rdKeywordSystem.Checked OrElse rdKeywordCustom.Checked Then
            Return True
        End If
        Return False
    End Function

    Private Function GetKeywordChecedCodeString() As String
        If rdKeywordNone.Checked Then
            Return Const_Validation_None
        End If
        If rdKeywordSystem.Checked Then
            Return Const_Validation_SystemCode
        End If
        If rdKeywordCustom.Checked Then
            Return Const_Validation_Custom
        End If
        Return Nothing
    End Function

    Private Sub InitializeControls()

        If GetArgs() IsNot Nothing AndAlso GetSubType() IsNot Nothing Then
            UpdateOrder()

            Dim absSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
            absSubTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)

            If absSubTypes IsNot Nothing AndAlso absSubTypes.Count > 0 Then
                GridTextBlock.DataSource = absSubTypes(0).AbstractCallSubmissionTypeTextBlockControls
                GridSubmissionDisclosureQuestions.DataSource = absSubTypes(0).AbstractCallSubmissionTypeDisclosureQuestionControls
            End If
        End If

    End Sub

    Private Sub UpdateOrder()
        If ReorderChanges_GridTextBlock.Value = "" Then
            If ReorderChanges_GridSubmissionDisclosureQuestions.Value = "" Then
                Exit Sub
            Else
                CallManager.ABSSubmissionType_DisclosureQuestion_Reorder(PortalId, GetArgs, GetSubType, ReorderChanges_GridSubmissionDisclosureQuestions.Value)
                ReorderChanges_GridSubmissionDisclosureQuestions.Value = ""
            End If
        Else
            CallManager.ABSSubmissionType_TextBlock_Reorder(PortalId, GetArgs, GetSubType, ReorderChanges_GridTextBlock.Value)
            ReorderChanges_GridTextBlock.Value = ""
            If ReorderChanges_GridSubmissionDisclosureQuestions.Value = "" Then
                Exit Sub
            Else
                CallManager.ABSSubmissionType_DisclosureQuestion_Reorder(PortalId, GetArgs, GetSubType, ReorderChanges_GridSubmissionDisclosureQuestions.Value)
                ReorderChanges_GridSubmissionDisclosureQuestions.Value = ""
            End If
        End If
    End Sub

    Private Function GetWebSubmissionTypeUponSave() As WEB_SUBMISSIONTYPE

        Dim absSubType As New WEB_SUBMISSIONTYPE
        absSubType.Call_Code = GetArgs()
        absSubType.SubmissionTypeCode = GetSubType()

        absSubType.ValidateKeywordControlCode = Me.GetKeywordChecedCodeString
        absSubType.ValidateTopicControlCode = Me.GetTopicChecedCodeString

        If Me.rdTopicSystem.Checked Then
            absSubType.ValidationTopicCode = Me.ddlTopicSystemList.SelectedItem.Value
        End If

        If Me.rdKeywordSystem.Checked Then
            absSubType.ValidationKeywordCode = Me.ddlKeywordSystemList.SelectedItem.Value
        End If

        absSubType.AllowWebAttachmentFlag = Me.chkAllowAttachment.Checked

        If chkAllowAttachment.Checked Then
            If txtMinAttachment.Value.HasValue Then
                absSubType.MinAttachments = Me.txtMinAttachment.Text
            Else
                absSubType.MinAttachments = 0
            End If
            If txtMaxAttachment.Value.HasValue Then
                absSubType.MaxAttachments = Me.txtMaxAttachment.Text
            Else
                absSubType.MaxAttachments = 0
            End If
            If txtMaxSizePerFile.Value.HasValue Then
                absSubType.MaxFileSizeMB = Me.txtMaxSizePerFile.Text
            Else
                absSubType.MaxFileSizeMB = 0
            End If
        End If

        absSubType.ABSInstruction_Get(Const_InstructionType_Material, Language, Me.RadAuthorSubmissionInstructions.Content)
        absSubType.ABSInstruction_Get(Const_InstructionType_Attachment, Language, radAttachmentInstructions.Content)

        For Each item As ListItem In Me.chkFileTypes.Items
            absSubType.ABSFileTypes_Add(item.Value, item.Selected)
        Next


        Return absSubType

    End Function

    Private Function TextBlockProperties_Set(ByVal e As Telerik.Web.UI.GridCommandEventArgs) As WEB_SUBMISSIONTEXTBLOCK
        Dim editedItem As Telerik.Web.UI.GridEditableItem = CType(e.Item, Telerik.Web.UI.GridEditableItem)

        Dim newValues As Hashtable = New Hashtable
        'The GridTableView will fill the values from all editable columns in the hash
        e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editedItem)
        Dim oTextBlock As New WEB_SUBMISSIONTEXTBLOCK

        'For Each entry As DictionaryEntry In newValues
        '    Select Case entry.Key.ToString
        '        Case "Heading"
        '            oTextBlock.Heading = entry.Value.ToString
        '        Case "MaxWordCount"
        '            oTextBlock.MaxWordCount = entry.Value.ToString
        '        Case "InstructionText"
        '            oTextBlock.InstructionText = entry.Value.ToString
        '    End Select
        'Next

        Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
        Dim txtHeading As RadTextBox = DirectCast(editItem.FindControl("txtHeading"), RadTextBox)
        Dim txtLimit As RadNumericTextBox = DirectCast(editItem.FindControl("txtLimit"), RadNumericTextBox)
        Dim txtInstruction As RadTextBox = DirectCast(editItem.FindControl("txtInstruction"), RadTextBox)

        oTextBlock.Heading = txtHeading.Text
        oTextBlock.MaxWordCount = txtLimit.Text
        oTextBlock.InstructionText = txtInstruction.Text

        Return oTextBlock
    End Function

    Private Function DisclosureQuestionProperties_Set(ByVal e As Telerik.Web.UI.GridCommandEventArgs) As WEB_SUBMISSIONDISCLOSUREQUESTION
        Dim editedItem As Telerik.Web.UI.GridEditableItem = CType(e.Item, Telerik.Web.UI.GridEditableItem)

        Dim newValues As Hashtable = New Hashtable
        'The GridTableView will fill the values from all editable columns in the hash
        'e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editedItem)
        Dim oDisclosureQuestion As New WEB_SUBMISSIONDISCLOSUREQUESTION

        'For Each entry As DictionaryEntry In newValues
        '    Select Case entry.Key.ToString
        '        Case "DisclosureQuestionCode"
        '            oDisclosureQuestion.DisclosureQuestionCode = entry.Value.ToString
        '        Case "QuestionText"
        '            oDisclosureQuestion.QuestionText = entry.Value.ToString
        '        Case "DisclosureAnswerCode"
        '            oDisclosureQuestion.DisclosureAnswerCode = entry.Value.ToString
        '        Case "RejectionDisclosureAnswerSubcode"
        '            oDisclosureQuestion.RejectionDisclosureAnswerSubcode = entry.Value.ToString
        '        Case "AnswerRequiredFlag"
        '            oDisclosureQuestion.AnswerRequiredFlag = IIf(entry.Value.ToString = "True", True, False)
        '    End Select
        'Next
        oDisclosureQuestion.DisclosureAnswerCode = ddlDisclosureAnswerCode.SelectedValue
        oDisclosureQuestion.RejectionDisclosureAnswerSubcode = ddlRejectionDisclosureAnswerSubcode.SelectedValue
        oDisclosureQuestion.DisclosureQuestionCode = ddlDisclosureQuestionCode.SelectedValue
        oDisclosureQuestion.QuestionText = txtSubmissionDisclosureQuestions.Text
        oDisclosureQuestion.AnswerRequiredFlag = chkAnswerRequiredFlag.Checked

        'AN - add coded answer flag
        oDisclosureQuestion.CodedAnswerFlag = chkCodedAnswerFlag.Checked

        Return oDisclosureQuestion
    End Function

    Private Function IsFilesTypeSelected() As Boolean

        If chkAllowAttachment.Checked AndAlso (Not String.IsNullOrEmpty(txtMinAttachment.Text) AndAlso CInt(txtMinAttachment.Text) > 0) Then
            For Each item As ListItem In Me.chkFileTypes.Items
                If item.Selected = True Then
                    Return True
                End If
            Next
            Return False
        End If

        Return True
    End Function
#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            'Todo: should we check if querystring is valid(?) If not valid - hide the page
            SetupControls()
        Else
            InitializeControls() 'This is required due to grid required datasource
        End If


    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        If Not _AnswerCodeChanged AndAlso _LoadEditTemplate Then
            If Not _EditItemIndex = -1 Then
                ddlDisclosureAnswerCode.DataTextField = "Description"
                ddlDisclosureAnswerCode.DataValueField = "Code"
                ddlDisclosureAnswerCode.DataSource = DisclosureAnswerCode_Get()
                ddlDisclosureAnswerCode.DataBind()
                For Each item As RadComboBoxItem In ddlDisclosureAnswerCode.Items
                    If item.Text = GridSubmissionDisclosureQuestions.Items(_EditItemIndex)("DisclosureAnswerCode").Text Then
                        ddlDisclosureAnswerCode.SelectedIndex = item.Index
                        Exit For
                    End If
                Next

                ddlRejectionDisclosureAnswerSubcode.DataTextField = "Description"
                ddlRejectionDisclosureAnswerSubcode.DataValueField = "Subcode"
                ddlRejectionDisclosureAnswerSubcode.DataSource = RejectionDisclosureAnswerSubcode_Get(ddlDisclosureAnswerCode.SelectedValue)
                ddlRejectionDisclosureAnswerSubcode.DataBind()
                For Each item As RadComboBoxItem In ddlRejectionDisclosureAnswerSubcode.Items
                    If item.Text = GridSubmissionDisclosureQuestions.Items(_EditItemIndex)("RejectionDisclosureAnswerSubcode").Text Then
                        ddlRejectionDisclosureAnswerSubcode.SelectedIndex = item.Index
                        Exit For
                    End If
                Next

                ddlDisclosureQuestionCode.DataTextField = "Description"
                ddlDisclosureQuestionCode.DataValueField = "Code"
                ddlDisclosureQuestionCode.DataSource = DisclosureQuestionCode_Get()
                ddlDisclosureQuestionCode.DataBind()
                For Each item As RadComboBoxItem In ddlDisclosureQuestionCode.Items
                    If item.Text = GridSubmissionDisclosureQuestions.Items(_EditItemIndex)("DisclosureQuestionCode").Text Then
                        ddlDisclosureQuestionCode.SelectedIndex = item.Index
                        Exit For
                    End If
                Next
                txtSubmissionDisclosureQuestions.Text = GridSubmissionDisclosureQuestions.Items(_EditItemIndex)("QuestionText").Text
                'AN - Coded answer flag
                chkCodedAnswerFlag.Checked = CType(GridSubmissionDisclosureQuestions.Items(_EditItemIndex)("CodedAnswerFlag").Controls(0), CheckBox).Checked

                chkAnswerRequiredFlag.Checked = CType(GridSubmissionDisclosureQuestions.Items(_EditItemIndex)("AnswerRequiredFlag").Controls(0), CheckBox).Checked
            Else
                ddlDisclosureAnswerCode.DataTextField = "Description"
                ddlDisclosureAnswerCode.DataValueField = "Code"
                ddlDisclosureAnswerCode.DataSource = DisclosureAnswerCode_Get()
                ddlDisclosureAnswerCode.DataBind()

                ddlRejectionDisclosureAnswerSubcode.DataTextField = "Description"
                ddlRejectionDisclosureAnswerSubcode.DataValueField = "Subcode"
                ddlRejectionDisclosureAnswerSubcode.DataSource = RejectionDisclosureAnswerSubcode_Get(ddlDisclosureAnswerCode.SelectedValue)
                ddlRejectionDisclosureAnswerSubcode.DataBind()

                ddlDisclosureQuestionCode.DataTextField = "Description"
                ddlDisclosureQuestionCode.DataValueField = "Code"
                ddlDisclosureQuestionCode.DataSource = DisclosureQuestionCode_Get()
                ddlDisclosureQuestionCode.DataBind()
            End If
        End If
    End Sub

    Private Sub ddlDisclosureAnswerCode_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlDisclosureAnswerCode.SelectedIndexChanged
        ddlRejectionDisclosureAnswerSubcode.DataTextField = "Description"
        ddlRejectionDisclosureAnswerSubcode.DataValueField = "Subcode"
        ddlRejectionDisclosureAnswerSubcode.DataSource = RejectionDisclosureAnswerSubcode_Get(ddlDisclosureAnswerCode.SelectedValue)
        ddlRejectionDisclosureAnswerSubcode.DataBind()
        _AnswerCodeChanged = True
    End Sub

    Private Sub butUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdate.Click

        If IsFilesTypeSelected() = False Then
            ShowPopupMessage(Constants.Const_FileTypeError)
            Exit Sub
        End If

        If IsTopicChecked() AndAlso IsKeywordChecked() Then

            'Save Topics and Keywords
            If rdTopicCustom.Checked Then
                SaveCallTopics()
            End If

            If rdKeywordCustom.Checked Then
                SaveKeywords()
            End If

            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)

            If oIssues.ErrorCount > 0 Then
                ShowPopupMessage(oIssues)
            Else
                GridTextBlock.Rebind()
                GridSubmissionDisclosureQuestions.Rebind()
                ShowPopupMessage(Constants.Const_Save_Message)
                'GoToNextPage(Admin_ReviewProcess, GetArgs, "", GetSubType)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If

    End Sub

    Private Sub butContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butContinue.Click

        If IsFilesTypeSelected() = False Then
            ShowPopupMessage(Constants.Const_FileTypeError)
            Exit Sub
        End If

        If IsTopicChecked() AndAlso IsKeywordChecked() Then

            'Save Topics and Keywords
            If rdTopicCustom.Checked Then
                SaveCallTopics()
            End If

            If rdKeywordCustom.Checked Then
                SaveKeywords()
            End If

            Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)

            If oIssues.ErrorCount > 0 Then
                ShowPopupMessage(oIssues)
            Else
                GoToNextPage(Admin_ReviewProcess, GetArgs, "", GetSubType)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If

    End Sub

    Private Sub butPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butPrev.Click
        GoToNextPage(Admin_AuthorRequirements, GetArgs, "", GetSubType)
    End Sub

    Private Sub chkAllowAttachment_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkAllowAttachment.CheckedChanged
        If chkAllowAttachment.Checked Then
            pnlAttachment.Visible = True
        Else
            pnlAttachment.Visible = False
        End If
    End Sub

#End Region

#Region "Public methods"

    Private Sub DisableGrid(ByVal objGrid As Telerik.Web.UI.RadGrid, ByVal MoveUpButtonName As String, ByVal MoveDownButtonName As String)

        Me.FindControl(MoveUpButtonName).Visible = False

        Me.FindControl(MoveDownButtonName).Visible = False

        objGrid.Columns(0).Display = False
        objGrid.Columns(objGrid.Columns.Count - 1).Display = False

        For Each grdCmdItem As GridCommandItem In objGrid.MasterTableView.GetItems(GridItemType.CommandItem)

            If objGrid.Items.Count > 0 Then
                Dim btn As Button = DirectCast(grdCmdItem.FindControl("AddNewRecordButton"), Button)
                btn.Visible = False

                Dim lnkbtn1 As LinkButton = DirectCast(grdCmdItem.FindControl("InitInsertButton"), LinkButton)
                lnkbtn1.Visible = False

            End If
        Next
    End Sub

    Public Overrides Sub SetupUpdateView(Optional ByVal SubmissionsExists As Boolean = False)
        Me.butContinue.Visible = False
        Me.butPrev.Visible = False
        Me.butUpdate.Visible = True
        SetupControls()

        If SubmissionsExists Then
            DisableGrid(GridTextBlock, "btnGridTextBlockMoveUp", "btnGridTextBlockMoveDown")
            DisableGrid(GridSubmissionDisclosureQuestions, "btnGridSubmissionDisclosureQuestionsMoveUp", "btnGridSubmissionDisclosureQuestionsMoveDown")

            txtMinAttachment.Enabled = False
            txtMaxAttachment.Enabled = False

            For i As Integer = 0 To chkFileTypes.Items.Count - 1
                If chkFileTypes.Items(i).Selected = True Then
                    chkFileTypes.Items(i).Enabled = False
                End If
            Next

            ddlTopicSystemList.Enabled = False
            ddlKeywordSystemList.Enabled = False

            chkAllowAttachment.Enabled = False
        End If
    End Sub

#End Region

#Region "Grid related methods"

    Private Sub GridTextBlock_DeleteCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridTextBlock.DeleteCommand

        Dim ID As String = GridTextBlock.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeTextBlockControlId").Text
        Dim blockSeq As String = GridTextBlock.Items(e.Item.ItemIndex)("BlockSequence").Text
        Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeTextBlock_Delete(PortalId, ID, blockSeq, GetArgs, GetSubType)

        If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
            e.Canceled = True
        Else
            InitializeControls()
        End If

    End Sub

    Private Sub GridTextBlock_InsertCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridTextBlock.InsertCommand

        Dim oBlockText As WEB_SUBMISSIONTEXTBLOCK = TextBlockProperties_Set(e)
        Try
            oBlockText.VisiblityCode = "ALL"
            oBlockText.BlockType = "SUBMISSION"
            oBlockText.Call_Code = GetArgs()
            oBlockText.SubmissionTypeCode = GetSubType()
            oBlockText.AbstractCallSubmissionTypeTextBlockControlId = -1

            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeTextBlock_Update(PortalId, oBlockText)

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If

        Catch ex As Exception
            e.Canceled = True
        End Try

    End Sub


    Private Sub GridTextBlock_UpdateCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridTextBlock.UpdateCommand

        Try
            Dim oBlockText As WEB_SUBMISSIONTEXTBLOCK = TextBlockProperties_Set(e)
            oBlockText.AbstractCallSubmissionTypeTextBlockControlId = CType(GridTextBlock.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeTextBlockControlId").Text, Integer)
            oBlockText.BlockSeq = CType(GridTextBlock.Items(e.Item.ItemIndex)("BlockSequence").Text, Integer)
            oBlockText.Call_Code = GetArgs()
            oBlockText.SubmissionTypeCode = GetSubType()

            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeTextBlock_Update(PortalId, oBlockText)
            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Private Sub GridSubmissionDisclosureQuestions_DeleteCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridSubmissionDisclosureQuestions.DeleteCommand
        Dim ID As String = GridSubmissionDisclosureQuestions.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeDisclosureQuestionControlId").Text
        Dim QuestionSequence As String = GridSubmissionDisclosureQuestions.Items(e.Item.ItemIndex)("QuestionSequence").Text
        Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeDisclosureQuestion_Delete(PortalId, ID, QuestionSequence, GetArgs, GetSubType)

        If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
            e.Canceled = True
        Else
            InitializeControls()
        End If
    End Sub

    Private Sub GridSubmissionDisclosureQuestions_InsertCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridSubmissionDisclosureQuestions.InsertCommand

        Dim oDisclosureQuestion As WEB_SUBMISSIONDISCLOSUREQUESTION = DisclosureQuestionProperties_Set(e)
        Try
            oDisclosureQuestion.AbstractCallSubmissionTypeDisclosureQuestionControlId = -1

            'AN - comment this out. The valiue is set from the UI
            'oDisclosureQuestion.CodedAnswerFlag = True
            oDisclosureQuestion.AbstractCallCode = GetArgs()
            oDisclosureQuestion.SubmissionTypeCode = GetSubType()

            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeDisclosureQuestion_Update(PortalId, oDisclosureQuestion)

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If

        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Private Sub GridSubmissionDisclosureQuestions_ItemCreated(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles GridSubmissionDisclosureQuestions.ItemCreated
        If TypeOf e.Item Is GridCommandItem Then
            Dim commandItem As GridCommandItem = CType(e.Item, GridCommandItem)
            Dim RebindButton As LinkButton
            Dim RefreshButton As Button
            Dim NewButton As Button
            NewButton = CType(commandItem.FindControl("AddNewRecordButton"), Button)
            NewButton.Visible = False
            RebindButton = CType(commandItem.FindControl("RebindGridButton"), LinkButton)
            RebindButton.Visible = False
            RefreshButton = CType(commandItem.FindControl("RefreshButton"), Button)
            RefreshButton.Visible = False
        End If
        If TypeOf e.Item Is GridEditFormItem And e.Item.IsInEditMode Then
            Dim editItem As GridEditFormItem = e.Item
            _LoadEditTemplate = True
            _EditItemIndex = editItem.ItemIndex
            ddlDisclosureAnswerCode = editItem.FindControl("ddlDisclosureAnswerCode")
            ddlRejectionDisclosureAnswerSubcode = editItem.FindControl("ddlRejectionDisclosureAnswerSubcode")
            ddlDisclosureQuestionCode = editItem.FindControl("ddlDisclosureQuestionCode")
            txtSubmissionDisclosureQuestions = editItem.FindControl("txtSubmissionDisclosureQuestions")
            'AN
            chkCodedAnswerFlag = editItem.FindControl("chkCodedAnswerFlag")
            chkAnswerRequiredFlag = editItem.FindControl("chkAnswerRequiredFlag")

        End If
    End Sub

    Private Sub GridSubmissionDisclosureQuestions_UpdateCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridSubmissionDisclosureQuestions.UpdateCommand
        Try
            Dim oDisclosureQuestion As WEB_SUBMISSIONDISCLOSUREQUESTION = DisclosureQuestionProperties_Set(e)
            oDisclosureQuestion.AbstractCallSubmissionTypeDisclosureQuestionControlId = GridSubmissionDisclosureQuestions.Items(e.Item.ItemIndex)("AbstractCallSubmissionTypeDisclosureQuestionControlId").Text
            oDisclosureQuestion.QuestionSequence = GridSubmissionDisclosureQuestions.Items(e.Item.ItemIndex)("QuestionSequence").Text
            oDisclosureQuestion.AbstractCallCode = GetArgs()
            oDisclosureQuestion.SubmissionTypeCode = GetSubType()

            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = CallManager.ABSSubmissionTypeDisclosureQuestion_Update(PortalId, oDisclosureQuestion)
            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                InitializeControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Private Sub SaveCallTopics()

        If GetArgs() Is Nothing OrElse GetSubType() Is Nothing Then
            Exit Sub
        End If

        Dim absSubTypeTopics As New WEB_SUBMISSIONTYPE

        absSubTypeTopics.Call_Code = GetArgs()
        absSubTypeTopics.SubmissionTypeCode = GetSubType()

        Dim chkSelectTopic As CheckBox

        For Each dataItem As GridDataItem In RadGridTopics.MasterTableView.Items
            chkSelectTopic = dataItem.FindControl("chkSelectTopic")
            absSubTypeTopics.ABSCallTopic_Add(dataItem("Key").Text, chkSelectTopic.Checked)
        Next

        CallManager.ABSSubmissionType_Topics_Update(PortalId, absSubTypeTopics)

    End Sub

    Private Sub SaveKeywords()

        If GetArgs() Is Nothing OrElse GetSubType() Is Nothing Then
            Exit Sub
        End If

        Dim absSubTypeTopics As New WEB_SUBMISSIONTYPE

        absSubTypeTopics.Call_Code = GetArgs()
        absSubTypeTopics.SubmissionTypeCode = GetSubType()

        Dim chkSelectKeyword As CheckBox

        For Each dataItem As GridDataItem In RadGridKeywords.MasterTableView.Items
            chkSelectKeyword = dataItem.FindControl("chkSelectKeyword")
            absSubTypeTopics.ABSCallKeyword_Add(dataItem("Key").Text, chkSelectKeyword.Checked)
        Next

        CallManager.ABSSubmissionType_Keywords_Update(PortalId, absSubTypeTopics)

    End Sub


    Private Sub rdTopicSection_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdTopicSystem.CheckedChanged, rdTopicCustom.CheckedChanged, rdTopicNone.CheckedChanged
        rdTopicChanged()
    End Sub

    Private Sub rdTopicChanged(Optional ByVal SystemList_CodeValue As String = Nothing)
        If rdTopicNone.Checked Then
            RadGridTopics.Visible = False
            ddlTopicSystemList.Enabled = False
            pnlTopics.Visible = False
        ElseIf rdTopicSystem.Checked Then
            RadGridTopics.Visible = False
            ddlTopicSystemList.Enabled = True
            Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            appCodes = GetApplicationCodes("ABS", "SUBMISSION_TOPIC", True)
            ddlTopicSystemList.DataSource = appCodes
            ddlTopicSystemList.DataTextField = "Description"
            ddlTopicSystemList.DataValueField = "Code"
            ddlTopicSystemList.DataBind()
            If Not String.IsNullOrEmpty(SystemList_CodeValue) Then
                If ddlTopicSystemList.FindItemByValue(SystemList_CodeValue) IsNot Nothing Then
                    ddlTopicSystemList.FindItemByValue(SystemList_CodeValue).Selected = True
                End If
            End If
            pnlTopics.Visible = False
        ElseIf rdTopicCustom.Checked Then
            ddlTopicSystemList.Enabled = False
            RadGridTopics.Visible = True
            RadGridTopics.Rebind()
            pnlTopics.Visible = True
            pnlTopics.Height = 120
        End If
    End Sub

    Private Sub rdKeywordSection_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdKeywordSystem.CheckedChanged, rdKeywordCustom.CheckedChanged, rdKeywordNone.CheckedChanged
        rdKeywordChanged()
    End Sub


    Private Sub rdKeywordChanged(Optional ByVal SystemList_CodeValue As String = Nothing)
        If rdKeywordNone.Checked Then
            RadGridKeywords.Visible = False
            ddlKeywordSystemList.Enabled = False
            pnlKeywords.Visible = False
        ElseIf rdKeywordSystem.Checked Then
            RadGridKeywords.Visible = False
            ddlKeywordSystemList.Enabled = True
            Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            appCodes = GetApplicationCodes("ABS", "SUBMISSION_KEYWORD", True)
            ddlKeywordSystemList.DataSource = appCodes
            ddlKeywordSystemList.DataTextField = "Description"
            ddlKeywordSystemList.DataValueField = "Code"
            ddlKeywordSystemList.DataBind()
            If Not String.IsNullOrEmpty(SystemList_CodeValue) Then
                If ddlKeywordSystemList.FindItemByValue(SystemList_CodeValue) IsNot Nothing Then
                    ddlKeywordSystemList.FindItemByValue(SystemList_CodeValue).Selected = True
                End If
            End If
            pnlKeywords.Visible = False
        ElseIf rdKeywordCustom.Checked Then
            ddlKeywordSystemList.Enabled = False
            RadGridKeywords.Visible = True
            RadGridKeywords.Rebind()
            pnlKeywords.Visible = True
            pnlKeywords.Height = 120
        End If
    End Sub

    Protected Sub GridTextBlock_ItemCreated(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles GridTextBlock.ItemCreated
        If TypeOf e.Item Is GridCommandItem Then
            Dim commandItem As GridCommandItem = CType(e.Item, GridCommandItem)
            Dim RebindButton As LinkButton
            Dim RefreshButton As Button
            Dim NewButton As Button
            NewButton = CType(commandItem.FindControl("AddNewRecordButton"), Button)
            NewButton.Visible = False
            RebindButton = CType(commandItem.FindControl("RebindGridButton"), LinkButton)
            RebindButton.Visible = False
            RefreshButton = CType(commandItem.FindControl("RefreshButton"), Button)
            RefreshButton.Visible = False
        End If
    End Sub

    Protected Sub GridTextBlock_ItemDataBound(ByVal sender As Object, ByVal e As GridItemEventArgs) Handles GridTextBlock.ItemDataBound
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then
            Dim Item As GridEditableItem = DirectCast(e.Item, GridEditableItem)
            txtHeading = DirectCast(Item.FindControl("txtHeading"), RadTextBox)
            txtLimit = DirectCast(Item.FindControl("txtLimit"), RadNumericTextBox)
            txtInstruction = DirectCast(Item.FindControl("txtInstruction"), RadTextBox)
            If Not e.Item.OwnerTableView.IsItemInserted Then
                If Not Item("Heading").Text = "&nbsp;" Then
                    txtHeading.Text = Item("Heading").Text
                Else
                    txtHeading.Text = String.Empty
                End If
                If Not Item("MaxWordCount").Text = "&nbsp;" Then
                    txtLimit.Text = Item("MaxWordCount").Text
                Else
                    txtLimit.Text = String.Empty
                End If
                If Not Item("InstructionText").Text = "&nbsp;" Then
                    txtInstruction.Text = Item("InstructionText").Text
                Else
                    txtInstruction.Text = String.Empty
                End If
            End If
        End If
    End Sub

    Protected Sub GridTextBlock_ItemCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles GridTextBlock.ItemCommand
        If e.CommandName = RadGrid.EditCommandName Then
            grdTextBlocksDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.InitInsertCommandName Then
            grdTextBlocksDisableEditItems = True
            grdTextBlocksDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.CancelCommandName Then
            grdTextBlocksDisableCommandItem = False
            grdTextBlocksDisableEditItems = False
        End If
    End Sub

    Protected Sub GridTextBlock_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles GridTextBlock.PreRender
        If grdTextBlocksDisableEditItems Then
            For Each dataItem As GridDataItem In GridTextBlock.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = False
            Next
        ElseIf grdTextBlocksDisableCommandItem Then
            Dim commandItem As GridCommandItem = DirectCast(GridTextBlock.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = False
        Else
            For Each dataItem As GridDataItem In GridTextBlock.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = True
            Next
            Dim commandItem As GridCommandItem = DirectCast(GridTextBlock.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = True
        End If
    End Sub

    Protected Sub GridSubmissionDisclosureQuestions_ItemCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles GridSubmissionDisclosureQuestions.ItemCommand
        If e.CommandName = RadGrid.EditCommandName Then
            grdQuestionsDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.InitInsertCommandName Then
            grdQuestionsDisableEditItems = True
            grdQuestionsDisableCommandItem = True
        ElseIf e.CommandName = RadGrid.CancelCommandName Then
            grdQuestionsDisableCommandItem = False
            grdQuestionsDisableEditItems = False
        End If
    End Sub


    Protected Sub GridSubmissionDisclosureQuestions_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles GridSubmissionDisclosureQuestions.PreRender
        If grdQuestionsDisableEditItems Then
            For Each dataItem As GridDataItem In GridSubmissionDisclosureQuestions.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = False
            Next
        ElseIf grdQuestionsDisableCommandItem Then
            Dim commandItem As GridCommandItem = DirectCast(GridSubmissionDisclosureQuestions.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = False
        Else
            For Each dataItem As GridDataItem In GridSubmissionDisclosureQuestions.MasterTableView.Items
                TryCast(dataItem("EditCommandColumn").Controls(0), LinkButton).Enabled = True
            Next
            Dim commandItem As GridCommandItem = DirectCast(GridSubmissionDisclosureQuestions.MasterTableView.GetItems(GridItemType.CommandItem)(0), GridCommandItem)
            commandItem.Enabled = True
        End If
        If chkCodedAnswerFlag IsNot Nothing Then
            ' HideShowDisclosureOptions(chkCodedAnswerFlag.Checked)
        End If

    End Sub


#End Region


    Private Sub HideShowDisclosureOptions(ByVal ShowControls As Boolean)

        ddlDisclosureAnswerCode.Visible = ShowControls
        ddlRejectionDisclosureAnswerSubcode.Visible = ShowControls
    End Sub

    Private Sub chkCodedAnswerFlag_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkCodedAnswerFlag.CheckedChanged

        'If coded answer is true, display disclosure answer code and reject answer code .. else hide them

        ' HideShowDisclosureOptions(chkCodedAnswerFlag.Checked)
        '
    End Sub


End Class
