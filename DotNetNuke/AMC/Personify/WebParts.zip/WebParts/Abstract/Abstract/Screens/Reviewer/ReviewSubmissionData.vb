Public Class ReviewSubmissionData

    Private _AbstractCallTitle As String = Nothing
    Public Property AbstractCallTitle() As String
        Get
            Return _AbstractCallTitle
        End Get
        Set(ByVal value As String)
            _AbstractCallTitle = value
        End Set
    End Property

    Private _SubmissionType As String = Nothing
    Public Property SubmissionType() As String
        Get
            Return _SubmissionType
        End Get
        Set(ByVal value As String)
            _SubmissionType = value
        End Set
    End Property

    Private _AbstractCallCode As String = Nothing
    Public Property AbstractCallCode() As String
        Get
            Return _AbstractCallCode
        End Get
        Set(ByVal value As String)
            _AbstractCallCode = value
        End Set
    End Property

    Private _SubmissionTypeCode As String = Nothing
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property
    Private _SubmissionTitle As String = Nothing
    Public Property SubmissionTitle() As String
        Get
            Return _SubmissionTitle
        End Get
        Set(ByVal value As String)
            _SubmissionTitle = value
        End Set
    End Property

    Private _AbstractSubmissionReviewerId As Integer = 0
    Public Property AbstractSubmissionReviewerId() As Integer
        Get
            Return _AbstractSubmissionReviewerId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionReviewerId = value
        End Set
    End Property

    Private _AbstractSubmissionId As Integer = 0
    Public Property AbstractSubmissionId() As Integer
        Get
            Return _AbstractSubmissionId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionId = value
        End Set
    End Property

    Private _ReviewBlindRule As String
    Public Property ReviewBlindRule() As String
        Get
            Return _ReviewBlindRule
        End Get
        Set(ByVal value As String)
            _ReviewBlindRule = value
        End Set
    End Property

    Private _SubmissionDate As String
    Public Property SubmissionDate() As String
        Get
            Return _SubmissionDate
        End Get
        Set(ByVal value As String)
            _SubmissionDate = value
        End Set
    End Property


    Private _ExpertiseLevel As String
    Public Property ExpertiseLevel() As String
        Get
            Return _ExpertiseLevel
        End Get
        Set(ByVal value As String)
            _ExpertiseLevel = value
        End Set
    End Property

    Private _SubmissionCategory As String
    Public Property SubmissionCategory() As String
        Get
            Return _SubmissionCategory
        End Get
        Set(ByVal value As String)
            _SubmissionCategory = value
        End Set
    End Property

    Private _SubmissionTopic As String
    Public Property SubmissionTopic() As String
        Get
            Return _SubmissionTopic
        End Get
        Set(ByVal value As String)
            _SubmissionTopic = value
        End Set
    End Property

    Private _MasterCustomerId As String
    Public Property MasterCustomerId() As String
        Get
            Return _MasterCustomerId
        End Get
        Set(ByVal value As String)
            _MasterCustomerId = value
        End Set
    End Property

    Private _SubCustomerId As Integer
    Public Property SubCustomerId() As Integer
        Get
            Return _SubCustomerId
        End Get
        Set(ByVal value As Integer)
            _SubCustomerId = value
        End Set
    End Property

    Public ReadOnly Property OrganizationId(ByVal PortalId As Integer) As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId(ByVal PortalId As Integer) As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

   

    Public ReviewScoring() As ReviewScoringData

    Public Function GetData(ByVal PortalId As String, ByVal SubmissionReviewerId As Integer) As Boolean

        Dim result As Boolean

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers
        Dim CallManager As New CallManagerHelper(OrganizationId(PortalId), OrganizationUnitId(PortalId))
        oAbstractSubmissionReviewers = CallManager.GetSubmissionReviewerData(PortalId, SubmissionReviewerId)

        If oAbstractSubmissionReviewers Is Nothing OrElse oAbstractSubmissionReviewers.Count <> 1 Then
            'show message or throw exception; show message expect 1 record but have count
            Return False
        End If

        If oAbstractSubmissionReviewers IsNot Nothing AndAlso oAbstractSubmissionReviewers.Count = 1 Then

            MasterCustomerId = oAbstractSubmissionReviewers(0).MasterCustomerId
            SubCustomerId = oAbstractSubmissionReviewers(0).SubCustomerId

            AbstractSubmissionReviewerId = oAbstractSubmissionReviewers(0).AbstractSubmissionReviewerId
            'AssignmentStatusCode = oAbstractSubmissionReviewers(0).AssignmentStatusCodeString
            AbstractCallTitle = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title
            AbstractCallCode = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.AbstractCallInfo.AbstractCallCode
            SubmissionTitle = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.Title
            SubmissionType = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.Description
            SubmissionTypeCode = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCodeString
            SubmissionDate = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.SubmissionDate
            ReviewBlindRule = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.ReviewBlindRuleCode.Description

            If oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionTopics IsNot Nothing AndAlso oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionTopics.Count > 0 Then
                For i As Integer = 0 To oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionTopics.Count - 1
                    If i <> 0 Then SubmissionTopic += "; "
                    SubmissionTopic += oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionTopics(i).TopicCodeString
                Next
            End If

            If oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionKeywords IsNot Nothing AndAlso oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionKeywords.Count > 0 Then
                For i As Integer = 0 To oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionKeywords.Count - 1
                    If i <> 0 Then SubmissionTopic += "; "
                    SubmissionTopic += oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionKeywords(i).KeywordCodeString
                Next
            End If

            SubmissionCategory = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.CategoryCodeString
            AbstractSubmissionId = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.AbstractSubmissionId

            Dim oAbstractCallSubmissionTypeScoringControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls

            oAbstractCallSubmissionTypeScoringControls = CallManager.GetAbstractCallSubmissionTypeScoringControls(PortalId, AbstractCallCode, SubmissionTypeCode)

            If oAbstractCallSubmissionTypeScoringControls IsNot Nothing AndAlso oAbstractCallSubmissionTypeScoringControls.Count > 0 Then

                Dim oReviewScoring(oAbstractCallSubmissionTypeScoringControls.Count - 1) As ReviewScoringData

                For j As Integer = 0 To oAbstractCallSubmissionTypeScoringControls.Count - 1

                    oReviewScoring(j) = New ReviewScoringData
                    oReviewScoring(j).AbstractCallSubmissionTypeScoringControlId = oAbstractCallSubmissionTypeScoringControls(j).AbstractCallSubmissionTypeScoringControlId
                    oReviewScoring(j).AnswerTypeCodeString = oAbstractCallSubmissionTypeScoringControls(j).AnswerTypeCodeString
                    oReviewScoring(j).ScoringAnswerCodeString = oAbstractCallSubmissionTypeScoringControls(j).ScoringAnswerCodeString
                    oReviewScoring(j).SubmissionScoringCriterionDescription = oAbstractCallSubmissionTypeScoringControls(j).SubmissionScoringCriterionDescription
                    oReviewScoring(j).ScoringCriterionCodeString = oAbstractCallSubmissionTypeScoringControls(j).ScoringCriterionCodeString
                    oReviewScoring(j).AllowCommentsFlag = oAbstractCallSubmissionTypeScoringControls(j).AllowCommentsFlag

                    If oAbstractSubmissionReviewers(0).AbstractSubmissionScorings IsNot Nothing AndAlso oAbstractSubmissionReviewers(0).AbstractSubmissionScorings.Count > 0 Then

                        Dim foundIndex As Integer = -1
                        For k As Integer = 0 To oAbstractSubmissionReviewers(0).AbstractSubmissionScorings.Count - 1
                            If oAbstractSubmissionReviewers(0).AbstractSubmissionScorings(k).AbstractCallSubmissionTypeScoringControlId = oAbstractCallSubmissionTypeScoringControls(j).AbstractCallSubmissionTypeScoringControlId Then
                                foundIndex = k
                                Exit For
                            End If
                        Next

                        If foundIndex > -1 Then
                            oReviewScoring(j).ScoringAnswerSubcode = oAbstractSubmissionReviewers(0).AbstractSubmissionScorings(foundIndex).ScoringAnswerSubcodeString
                            oReviewScoring(j).ScoringAnswerText = oAbstractSubmissionReviewers(0).AbstractSubmissionScorings(foundIndex).ScoringAnswerText
                            oReviewScoring(j).Comments = oAbstractSubmissionReviewers(0).AbstractSubmissionScorings(foundIndex).Comments
                        End If

                    End If


                Next

                ReviewScoring = oReviewScoring

                result = True
            End If



        End If
        Return result
    End Function

End Class
