Public Class ReviewerSearchData

    Private _MasterCustomerId As String = Nothing
    Public Property MasterCustomerId() As String
        Get
            Return _MasterCustomerId
        End Get
        Set(ByVal value As String)
            _MasterCustomerId = value
        End Set
    End Property

    Private _SubCustomerId As Integer = Nothing
    Public Property SubCustomerId() As Integer
        Get
            Return _SubCustomerId
        End Get
        Set(ByVal value As Integer)
            _SubCustomerId = value
        End Set
    End Property

    Private _AbstractCallSubmissionTypeReviewerId As Integer = Nothing
    Public Property AbstractCallSubmissionTypeReviewerId() As Integer
        Get
            Return _AbstractCallSubmissionTypeReviewerId
        End Get
        Set(ByVal value As Integer)
            _AbstractCallSubmissionTypeReviewerId = value
        End Set
    End Property

    Private _Name As String = Nothing
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property

    Private _Link As String = Nothing
    Public Property Link() As String
        Get
            Return _Link
        End Get
        Set(ByVal value As String)
            _Link = value
        End Set
    End Property

    Private _Institution As String = Nothing
    Public Property Institution() As String
        Get
            Return _Institution
        End Get
        Set(ByVal value As String)
            _Institution = value
        End Set
    End Property

    Private _OpenReviews As String = Nothing
    Public Property OpenReviews() As String
        Get
            Return _OpenReviews
        End Get
        Set(ByVal value As String)
            _OpenReviews = value
        End Set
    End Property

    Private _Expertise As String = Nothing
    Public Property Expertise() As String
        Get
            Return _Expertise
        End Get
        Set(ByVal value As String)
            _Expertise = value
        End Set
    End Property

    Private _LevelOfExpertise As String = Nothing
    Public Property LevelOfExpertise() As String
        Get
            Return _LevelOfExpertise
        End Get
        Set(ByVal value As String)
            _LevelOfExpertise = value
        End Set
    End Property

    Private _AverageScore As String = Nothing
    Public Property AverageScore() As String
        Get
            Return _AverageScore
        End Get
        Set(ByVal value As String)
            _AverageScore = value
        End Set
    End Property

    Private _Completed As String = Nothing
    Public Property Completed() As String
        Get
            Return _Completed
        End Get
        Set(ByVal value As String)
            _Completed = value
        End Set
    End Property

    Private _NumberOfAssignments As Integer = Nothing
    Public Property NumberOfAssignments() As Integer
        Get
            Return _NumberOfAssignments
        End Get
        Set(ByVal value As Integer)
            _NumberOfAssignments = value
        End Set
    End Property

    Private _NumberOfOpenAssignments As Integer = Nothing
    Public Property NumberOfOpenAssignments() As Integer
        Get
            Return _NumberOfOpenAssignments
        End Get
        Set(ByVal value As Integer)
            _NumberOfOpenAssignments = value
        End Set
    End Property
End Class
