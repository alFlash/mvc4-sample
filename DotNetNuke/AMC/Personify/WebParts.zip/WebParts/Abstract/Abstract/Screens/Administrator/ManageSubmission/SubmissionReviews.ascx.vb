Imports TIMSS.API.Core
Imports Personify.ApplicationManager.Commons
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic
Imports Telerik.Web.UI

Public Class SubmissionReviews
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private _EditItemIndex As Integer = -1
    Private _LoadEditTemplate As Boolean = False
    Private _AnswerCodeChanged As Boolean = False
#End Region

#Region "Controls"
    Protected WithEvents btnReturnToReviewer As Button
    Protected WithEvents RadGridReviewers As RadGrid
    Protected WithEvents ddlReviewStatus As RadComboBox
    Protected WithEvents pnlComment As Panel
    Protected WithEvents txtComments As RadTextBox
    Protected WithEvents rdtReviewDueDate As RadDatePicker
#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetupControls()
    End Sub

    Private Sub RadGridReviewers_ItemCreated(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles RadGridReviewers.ItemCreated
        If TypeOf e.Item Is GridEditFormItem And e.Item.IsInEditMode Then
            Dim editItem As GridEditFormItem = e.Item
            _EditItemIndex = editItem.ItemIndex
            pnlComment = editItem.FindControl("pnlComment")
            ddlReviewStatus = editItem.FindControl("ddlReviewStatus")
            txtComments = editItem.FindControl("txtComments")
            rdtReviewDueDate = editItem.FindControl("rdtReviewDueDate")

            _LoadEditTemplate = True
        End If
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        If Not _AnswerCodeChanged AndAlso _LoadEditTemplate Then
            ddlReviewStatus.DataTextField = "Description"
            ddlReviewStatus.DataValueField = "Code"
            ddlReviewStatus.DataSource = AssignmentStatusCode_Get()
            ddlReviewStatus.DataBind()
            If Not _EditItemIndex = -1 Then
                For Each item As RadComboBoxItem In ddlReviewStatus.Items

                    'set review due date
                    rdtReviewDueDate.SelectedDate = RadGridReviewers.Items(_EditItemIndex)("ReviewDueDate").Text
                    'AssignmentStatusCodeDescription

                    If item.Text = RadGridReviewers.Items(_EditItemIndex)("status").Text Then
                        ddlReviewStatus.SelectedIndex = item.Index
                        If item.Value = "RETURN_REVIEW" Then
                            pnlComment.Visible = True
                            If Not RadGridReviewers.Items(_EditItemIndex)("CommentsToReviewer").Text = "&nbsp;" Then
                                txtComments.Text = RadGridReviewers.Items(_EditItemIndex)("CommentsToReviewer").Text
                            Else
                                txtComments.Text = ""
                            End If
                        Else
                            pnlComment.Visible = False
                        End If
                        Exit For
                    End If
                Next
            End If
        End If
    End Sub

    Private Sub ddlReviewStatus_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlReviewStatus.SelectedIndexChanged
        If ddlReviewStatus.SelectedValue = "RETURN_REVIEW" Then
            pnlComment.Visible = True
            If Not RadGridReviewers.Items(_EditItemIndex)("CommentsToReviewer").Text = "&nbsp;" Then
                txtComments.Text = RadGridReviewers.Items(_EditItemIndex)("CommentsToReviewer").Text
            Else
                txtComments.Text = ""
            End If
        Else
            pnlComment.Visible = False
        End If
            _AnswerCodeChanged = True
    End Sub

#End Region

#Region "Helper functions"

    Private Sub SetupControls()
        Dim oReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers = CallManager.GetSubmission(PortalId, CType(GetAbsSubId(), Integer)).AbstractSubmissionReviewers

        Dim oWebReviewers As New List(Of WEB_SUBMISSIONREVIEWER)
        Dim oWebReviewer As WEB_SUBMISSIONREVIEWER
        For Each oReviewer As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer In oReviewers
            oWebReviewer = New WEB_SUBMISSIONREVIEWER
            With oWebReviewer
                .AbstractSubmissionReviewerId = oReviewer.AbstractSubmissionReviewerId
                .AssignmentStatusCodeDescription = oReviewer.AssignmentStatusCode.Description
                .CommentsToReviewer = oReviewer.CommentsToReviewer
                .LastFirstName = oReviewer.CustomerInfo.LastFirstName
                .ReviewDueDate = oReviewer.ReviewDueDate
                .InstitutionListString = InstitutionList_Concat(oReviewer.CustomerInfo.Relationships)
                .EducationListString = EducationList_Concat(oReviewer.CustomerInfo.EducationList)
                .LinkToReview = NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_ReviewSubmission & "&srid=" & oReviewer.AbstractSubmissionReviewerId.ToString)
            End With
            oWebReviewers.Add(oWebReviewer)
        Next

        RadGridReviewers.DataSource = oWebReviewers
    End Sub


    Private Function InstitutionList_Concat(ByVal InstitutionList As TIMSS.API.CustomerInfo.ICustomerRelationships) As String
        Dim InstitutionStr As String = ""
        For Each Institution As TIMSS.API.CustomerInfo.ICustomerRelationship In InstitutionList
            If Institution.RelationshipType.Code = Constants.Const_RelationshipType_Employment Then
                InstitutionStr = String.Concat(InstitutionStr, Institution.RelatedName, Environment.NewLine)
            End If
        Next
        Return InstitutionStr
    End Function

    Private Function EducationList_Concat(ByVal EductionList As TIMSS.API.CustomerInfo.ICustomerEducationList) As String
        Dim EducationStr As String = ""
        For Each Education As TIMSS.API.CustomerInfo.ICustomerEducation In EductionList
            EducationStr = String.Concat(EducationStr, Education.InstitutionName, ", ", Education.ProgDegreeCode.Description, Environment.NewLine)
        Next
        Return EducationStr
    End Function

    Private Function AssignmentStatusCode_Get() As TIMSS.API.ApplicationInfo.IApplicationCodes
        Return GetApplicationCodes("ABS", "ASSIGNMENT_STATUS", True)
    End Function

    Private Sub RadGridReviewers_UpdateCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGridReviewers.UpdateCommand
        Try
            Dim oSubmissionReviewer As New WEB_SUBMISSIONREVIEWER
            oSubmissionReviewer.AbstractSubmissionReviewerId = RadGridReviewers.Items(e.Item.ItemIndex)("AbstractSubmissionReviewerId").Text
            oSubmissionReviewer.AssignmentStatusCodeDescription = ddlReviewStatus.SelectedValue
            oSubmissionReviewer.CommentsToReviewer = txtComments.Text
            If rdtReviewDueDate.SelectedDate.HasValue Then
                oSubmissionReviewer.ReviewDueDate = rdtReviewDueDate.SelectedDate.Value
            Else
                e.Canceled = True
            End If
            
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection = SubmissionManager.ABSSubmissionReviwer_Update(PortalId, CType(GetAbsSubId(), Long), oSubmissionReviewer)
            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                e.Canceled = True
            Else
                SetupControls()
            End If
        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

#End Region

#Region "Public Function"

#End Region




End Class
