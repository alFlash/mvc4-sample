Imports ScreenController.AbstractScreen
Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports System.Collections.Generic
Imports System.Web.UI.WebControls

Public Class SubmissionTypeReviewer
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This Call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method Call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents GridSubmissionTypeReviewers As RadGrid
    Protected WithEvents lblReviewerType As Label
    Protected WithEvents lblMinNoReviewers As Label
    Protected WithEvents ddlQuickSearch As RadComboBox
    Protected WithEvents lbtnSelectAll As LinkButton
    Protected WithEvents lbtnSelectNone As LinkButton
    Protected WithEvents ddlActions As RadComboBox
    Protected WithEvents LinkAssignReviewer As HyperLink

#End Region

#Region "Helper functions"

    Private Sub SetupControls()

        Dim sourceTable As DataTable = ReviewManager.ABS_SubmissionTypeReviewers_Get(PortalId, GetArgs, GetSubType)

        GridSubmissionTypeReviewers.DataSource = sourceTable
        GridSubmissionTypeReviewers.DataBind()

        Dim oSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes = CallManager.ABSSubmissionType_Get(PortalId, GetArgs, GetSubType)
        If oSubTypes.Count = 1 Then
            Select Case oSubTypes(0).ReviewTypeCode.Code
                Case Constants.Const_ReviewBy_Reviewer
                    lblReviewerType.Text = "Individual Reviewers"
                Case Constants.Const_ReviewBy_Board
                    lblReviewerType.Text = "Review Board"
            End Select

            lblMinNoReviewers.Text = oSubTypes(0).DefaultMinReqReviewersPerSubmission
            LinkAssignReviewer.NavigateUrl = Me.GetNextPageURL(ScreenController.AbstractScreen.Reviewer_Search, GetArgs, "", GetSubType, "")
        End If

    End Sub

    Private Function GetAllEmailObjects(ByVal ReviewerList() As Integer) As ArrayList
        Dim EmailList As New ArrayList
        For Each ReviewerID As Integer In ReviewerList
            EmailList.Add(GetReviewerEmailObject(ReviewerID))
        Next
        Return EmailList
    End Function
   
    Private Function GetReviewerEmailObject(ByVal ReviewerID As Integer) As AbstractEmail
        Dim oReviewers As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers = CallManager.GetAbstractCallSubmissionTypeReviewers(PortalId, ReviewerID)

        If oReviewers.Count = 1 Then
            Dim oEmail As New AbstractEmail
            oEmail.EmailName = String.Concat(oReviewers(0).CustomerInfo.FirstName, " ", oReviewers(0).CustomerInfo.LastName)
            oEmail.EmailAddress = oReviewers(0).EmailAddress
            Return oEmail
        End If

        Return Nothing
    End Function


#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            SetupControls()

            'If IsPersonifyWebUserLoggedIn AndAlso IsSubmissionTypeStaff(MasterCustomerId, SubCustomerId, GetArgs, GetSubType) Then
            '    SetupControls()
            'Else
            '    Me.Visible = False
            'End If

        End If

    End Sub

    Private Sub ddlQuickSearch_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlQuickSearch.SelectedIndexChanged
        If Not (ddlQuickSearch.SelectedValue = "-1") Then
            Dim sourceTable As DataTable = ReviewManager.ABS_SubmissionTypeReviewers_Get(PortalId, GetArgs, GetSubType, ddlQuickSearch.SelectedValue)

            GridSubmissionTypeReviewers.DataSource = sourceTable
            GridSubmissionTypeReviewers.DataBind()
        End If
    End Sub

    Private Sub lbtnSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnSelectAll.Click
        For Each oItem As Telerik.Web.UI.GridDataItem In GridSubmissionTypeReviewers.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                CType(oItem.FindControl("chkSelect"), CheckBox).Checked = True
            End If
        Next
    End Sub

    Private Sub lbtnSelectNone_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnSelectNone.Click
        For Each oItem As Telerik.Web.UI.GridDataItem In GridSubmissionTypeReviewers.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                CType(oItem.FindControl("chkSelect"), CheckBox).Checked = False
            End If
        Next
    End Sub

    Private Sub ddlActions_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlActions.SelectedIndexChanged
        Dim Reviewers As New ArrayList

        For Each oItem As Telerik.Web.UI.GridDataItem In GridSubmissionTypeReviewers.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                If CType(oItem.FindControl("chkSelect"), CheckBox).Checked Then
                    Reviewers.Add(Convert.ToInt32(oItem.Item("AbstractCallSubmissionTypeReviewerId").Text))
                End If
            End If
        Next

        If Reviewers.Count > 0 Then
            Dim ReviewerIds(Reviewers.Count - 1) As Integer
            Reviewers.CopyTo(ReviewerIds)

            Dim MyGuid As Guid = Guid.NewGuid()

            Select Case ddlActions.SelectedValue
                Case "AssignToSubmission"
                    Session(MyGuid.ToString) = ReviewerIds
                    Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Assign_Reviewer_to_Submission, String), "&rids=", MyGuid.ToString, "&args=", GetArgs, "&type=", GetSubType)))
                Case "SendEmail"
                    Session(Constants.Const_EmailListSessionName) = GetAllEmailObjects(ReviewerIds)
                    Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Admin_Email, String))))
            End Select
        End If
    End Sub
    'Private Sub butUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdate.Click

    '    'If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then

    '    '    Dim absSubType As WEB_SUBMISSIONTYPE = GetWebSubmissionTypeUponSave()
    '    '    Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection

    '    '    If GetSubType() IsNot Nothing Then
    '    '        oValidationIssues = CallManager.ABSSubmissionType_Update(PortalId, absSubType)
    '    '    Else
    '    '        oValidationIssues = CallManager.ABSSubmissionType_Create(PortalId, absSubType)
    '    '    End If

    '    '    If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
    '    '        ShowPopupMessage(oValidationIssues)
    '    '    Else
    '    '        ShowPopupMessage(Constants.Const_Save_Message)
    '    '    End If
    '    'Else
    '    '    ShowPopupMessage(Constants.Const_PageError_Meesage)
    '    'End If
    'End Sub

    'Private Sub butContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butContinue.Click


    'End Sub


    
#End Region


#Region "Public methods"

    Public Overrides Sub SetupUpdateView(Optional ByVal SubmissionsExists As Boolean = False)
        'Me.butContinue.Visible = False
        'Me.butPrev.Visible = False
        'Me.butUpdate.Visible = True
        '_UpdateMode = True
        SetupControls()
    End Sub

#End Region





End Class
