Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI

Public Class MySubmissions
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"


#End Region

#Region "Controls"
    Protected WithEvents ctlAuthorSubmissions As AuthorSubmissions
#End Region
#Region "Properties"
    Private _IsClosed As Boolean
    Public ReadOnly Property IsClosed() As Boolean
        Get
            If Request("IsClosed") IsNot Nothing Then
                If Request("IsClosed") = "true" Then
                    _IsClosed = True
                Else
                    _IsClosed = False
                End If
            Else
                _IsClosed = False
            End If
            Return _IsClosed
        End Get
    End Property
#End Region
#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPersonifyWebUserLoggedIn Then
            'Error
            ShowPopupMessage("Please login first")
        End If

        With ctlAuthorSubmissions
            .PortalId = PortalId
            .MasterCustomerId = MasterCustomerId
            .SubCustomerId = SubCustomerId
            .IsClosed = IsClosed
            .GetArgs = GetArgs()
            .GetSubType = GetSubType()
        End With
    End Sub



#End Region


#Region "Helper functions"


#End Region




    

End Class

