Imports TIMSS.API.Core
Imports Personify.ApplicationManager.Commons
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic

Public Class SubmissionSearchList
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private _DoSearch As Boolean = True
#End Region

#Region "Controls"

    Protected WithEvents ddlCallCode As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlInternalStatus As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlSubType As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlExternalStatus As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlTopic As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlActionNeeded As Telerik.Web.UI.RadComboBox
    Protected WithEvents txtAuthorFirstName As TextBox
    Protected WithEvents txtAuthorLastName As TextBox
    Protected WithEvents txtReviewerFirstName As TextBox
    Protected WithEvents txtReviewerLastName As TextBox
    Protected WithEvents rdSubmittedAfter As Telerik.Web.UI.RadDatePicker
    Protected WithEvents rdSubmittedBefore As Telerik.Web.UI.RadDatePicker
    Protected WithEvents lbtnExpand As LinkButton
    Protected WithEvents lbtnClearSearch As LinkButton
    Protected WithEvents btnSearch As Button
    Protected WithEvents RadGridSubmissions As Telerik.Web.UI.RadGrid
    Protected WithEvents lbtnSelectAll As LinkButton
    Protected WithEvents lbtnSelectNone As LinkButton
    Protected WithEvents ddlActions As Telerik.Web.UI.RadComboBox
    Protected WithEvents chkTransferred As CheckBox

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Not Page.IsPostBack Then
            SetupControls()
            _DoSearch = False
        End If

        'RTW To do: need to check if postback by dropdown - don't do search

    End Sub

    Private Sub lbtnSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnSelectAll.Click
        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridSubmissions.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                CType(oItem.FindControl("chkSelect"), CheckBox).Checked = True
            End If
        Next
    End Sub

    Private Sub lbtnSelectNone_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnSelectNone.Click
        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridSubmissions.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                CType(oItem.FindControl("chkSelect"), CheckBox).Checked = False
            End If
        Next
    End Sub

    Private Sub lbtnClearSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbtnClearSearch.Click
        Me.ddlActionNeeded.SelectedValue = "-1"
        If Me.ddlCallCode.Enabled Then Me.ddlCallCode.SelectedValue = "-1"
        Me.ddlExternalStatus.SelectedValue = "-1"
        Me.ddlInternalStatus.SelectedValue = "-1"
        If Me.ddlSubType.Enabled Then Me.ddlSubType.SelectedValue = "-1"
        Me.ddlTopic.SelectedValue = "-1"
        Me.txtAuthorFirstName.Text = ""
        Me.txtAuthorLastName.Text = ""
        Me.txtReviewerFirstName.Text = ""
        Me.txtReviewerLastName.Text = ""
        Me.rdSubmittedAfter.SelectedDate = Nothing
        Me.rdSubmittedBefore.SelectedDate = Nothing
        RadGridSubmissions.DataSource = Nothing
        RadGridSubmissions.Rebind()
    End Sub

    Private Sub ddlSubType_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlSubType.SelectedIndexChanged
        If Not ddlCallCode.SelectedValue = "-1" Then
            ReloadTopics()
        End If
        _DoSearch = False
    End Sub

    Private Sub ddlCallCode_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlCallCode.SelectedIndexChanged


        If Not ddlCallCode.SelectedValue = "-1" Then
            'ddlSubType.DataSource = CallManager.ABSSubmissionType_Get(PortalId, ddlCallCode.SelectedValue)
            'ddlSubType.DataBind()
            'ddlSubType.Items.Insert(0, GetInitItem())
            'ReloadTopics()
        End If

    End Sub

    Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        RadGridSubmissions.Rebind()
    End Sub

    Private Sub ddlActions_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlActions.SelectedIndexChanged
        Dim Submissions As New ArrayList

        For Each oItem As Telerik.Web.UI.GridDataItem In RadGridSubmissions.Items
            If oItem.FindControl("chkSelect") IsNot Nothing Then
                If CType(oItem.FindControl("chkSelect"), CheckBox).Checked Then
                    Submissions.Add(Convert.ToInt32(oItem.Item("AbstractSubmissionId").Text))
                End If
            End If
        Next

        If Submissions.Count > 0 Then
            Dim SubmissionIds(Submissions.Count - 1) As Integer
            Submissions.CopyTo(SubmissionIds)

            Dim MyGuid As Guid = Guid.NewGuid()

            Select Case ddlActions.SelectedValue
                Case "AssignToSession"
                    Session(MyGuid.ToString) = SubmissionIds
                    Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Assign_Submission_to_Product, String), "&sids=", MyGuid.ToString, "&args=", ddlCallCode.SelectedValue)))
                Case "AssignToReview"
                    Session(MyGuid.ToString) = SubmissionIds
                    Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Assign_Submission_to_Reviewers, String), "&sids=", MyGuid.ToString, "&args=", ddlCallCode.SelectedValue, "&type=", Me.ddlSubType.SelectedValue)))
                Case "SendEmail"
                    Session(Constants.Const_EmailListSessionName) = GetAllEmailObjects(SubmissionIds)
                    Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Admin_Email, String))))
            End Select
        End If

    End Sub

   
    Private Sub RadGridSubmissions_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGridSubmissions.NeedDataSource

        If Not _DoSearch OrElse Request.Form.Item("__EVENTTARGET").Contains("ddlSubType") Then
            Exit Sub
        End If

        Dim oParameters As New List(Of TIMSS.API.Core.SearchProperty)
        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionId")
        oParm.ShowInResults = True
        oParm.UseInQuery = False
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("Title")
        oParm.ShowInResults = True
        oParm.UseInQuery = False
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
        oParm.ShowInResults = True
        If Not (ddlCallCode.SelectedValue = "-1") Then
            oParm.UseInQuery = True
            oParm.Value = ddlCallCode.SelectedValue
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

        Dim t As TIMSS.API.AbstractInfo.IAbstractSubmission
        oParm = New TIMSS.API.Core.SearchProperty("InternalStatusCode")
        oParm.ShowInResults = True
        If Not (ddlInternalStatus.SelectedValue = "-1") Then
            oParm.UseInQuery = True
            oParm.Value = ddlInternalStatus.SelectedValue
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

       
        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeInfo.SubmissionTypeCode")
        oParm.ShowInResults = True
        If Not (ddlSubType.SelectedValue = "-1") Then
            oParm.UseInQuery = True
            oParm.Value = ddlSubType.SelectedValue
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

        If Not (ddlExternalStatus.SelectedValue = "-1") Then
            oParm = New TIMSS.API.Core.SearchProperty("ExternalStatusCode")
            oParm.ShowInResults = False
            oParm.UseInQuery = True
            oParm.Value = ddlExternalStatus.SelectedValue
            oParameters.Add(oParm)
        Else
            oParm = New TIMSS.API.Core.SearchProperty("ExternalStatusCode")
            oParm.ShowInResults = False
            oParm.UseInQuery = True
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.NotEqualTo
            oParm.Value = "DRAFT"
            oParameters.Add(oParm)
        End If

        If Not (ddlTopic.SelectedValue = "-1") Then
            oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionTopics.TopicCode")
            oParm.ShowInResults = False
            oParm.UseInQuery = True
            oParm.Value = ddlTopic.SelectedValue
            oParameters.Add(oParm)
        End If

        oParm = New TIMSS.API.Core.SearchProperty("RequiresStaffActionFlag")
        oParm.ShowInResults = True
        If Not (ddlActionNeeded.SelectedValue = "-1") Then
            oParm.UseInQuery = True
            oParm.Value = IIf(ddlActionNeeded.SelectedValue = "Yes", "Y", "N")
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionAuthors.FirstName")
        oParm.ShowInResults = True
        If Not (txtAuthorFirstName.Text = "") Then
            oParm.UseInQuery = True
            oParm.Value = txtAuthorFirstName.Text
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Contains
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionAuthors.LastName")
        oParm.ShowInResults = True
        If Not (txtAuthorLastName.Text = "") Then
            oParm.UseInQuery = True
            oParm.Value = txtAuthorLastName.Text
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Contains
        Else
            oParm.UseInQuery = False
        End If
        oParameters.Add(oParm)

        If Not (txtReviewerFirstName.Text = "") Then
            oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.CustomerInfo.FirstName")
            oParm.UseInQuery = True
            oParm.Value = txtReviewerFirstName.Text
            oParm.ShowInResults = False
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Contains
            oParameters.Add(oParm)
        End If

        If Not (txtReviewerLastName.Text = "") Then
            oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.CustomerInfo.LastName")
            oParm.UseInQuery = True
            oParm.Value = txtReviewerLastName.Text
            oParm.ShowInResults = False
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Contains
            oParameters.Add(oParm)
        End If

        If rdSubmittedAfter.SelectedDate.HasValue Then
            oParm = New TIMSS.API.Core.SearchProperty("SubmissionDate")
            oParm.ShowInResults = False
            oParm.UseInQuery = True
            oParm.Value = rdSubmittedAfter.SelectedDate
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.GreaterThan
            oParameters.Add(oParm)
        End If

        If rdSubmittedBefore.SelectedDate.HasValue Then
            oParm = New TIMSS.API.Core.SearchProperty("SubmissionDate")
            oParm.ShowInResults = False
            oParm.UseInQuery = True
            oParm.Value = rdSubmittedBefore.SelectedDate
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.LessThan
            oParameters.Add(oParm)
        End If

        If chkTransferred.Checked Then
            oParm = New TIMSS.API.Core.SearchProperty("TransferredFlag")
            oParm.ShowInResults = False
            oParm.UseInQuery = True
            oParm.Value = "N"
            oParameters.Add(oParm)
        End If

        Dim oSubmissions As DataTable = SubmissionManager.ABS_Submission_Get(PortalId, oParameters)
        Dim oSubList As New List(Of WEB_SUBMISSION)
        Dim oSub As WEB_SUBMISSION
        If oSubmissions IsNot Nothing Then
            For Each oSubmission As DataRow In oSubmissions.Rows
                If Not (SubmissionManager.CheckIfRecordExist(oSubList, oSubmission)) Then
                    oSub = New WEB_SUBMISSION(oSubmission)
                    oSubList.Add(oSub)
                End If
            Next
        End If
        RadGridSubmissions.DataSource = oSubList

    End Sub

#End Region


#Region "Helper functions"
    Private Function GetAllEmailObjects(ByVal SubmissionList() As Integer) As ArrayList
        Dim EmailList As New ArrayList
        For Each SubmissionID As Integer In SubmissionList
            EmailList.Add(GetCorrespondingAuthorEmailObject(SubmissionID))
        Next
        Return EmailList
    End Function

    Private Function GetCorrespondingAuthorEmailObject(ByVal SubmissionId As Integer) As AbstractEmail
        Dim oSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = CallManager.GetAbstractSubmission(PortalId, SubmissionId)

        If oSubmissions.Count = 1 Then
            For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oSubmissions(0).AbstractSubmissionAuthors
                If oAuthor.CorrespondingAuthorFlag Then
                    Dim oEmail As New AbstractEmail
                    oEmail.EmailName = String.Concat(oAuthor.FirstName, " ", oAuthor.LastName)
                    oEmail.EmailAddress = oAuthor.EmailAddress
                    Return oEmail
                End If
            Next
        End If

        Return Nothing
    End Function

    Private Function GetPrimaryAuthorEmailObject(ByVal SubmissionId As Integer) As AbstractEmail
        Dim oSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = CallManager.GetAbstractSubmission(PortalId, SubmissionId)

        If oSubmissions.Count = 1 Then
            For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oSubmissions(0).AbstractSubmissionAuthors
                If oAuthor.PrimaryAuthorFlag Then
                    Dim oEmail As New AbstractEmail
                    oEmail.EmailName = String.Concat(oAuthor.FirstName, " ", oAuthor.LastName)
                    oEmail.EmailAddress = oAuthor.EmailAddress
                    Return oEmail
                End If
            Next
        End If

        Return Nothing
    End Function

    Private Function GetInitItem() As Telerik.Web.UI.RadComboBoxItem
        Dim oItem As New Telerik.Web.UI.RadComboBoxItem
        oItem.Text = ""
        oItem.Value = "-1"
        'oItem.Selected = True
        Return oItem
    End Function

    Private Sub SetupControls()
        ddlCallCode.DataSource = CallManager.ABSALLCALLS_GET(PortalId, "", "CallTypeCode", TIMSS.Enumerations.SortDirection.Ascending)
        ddlCallCode.DataBind()
        ddlCallCode.Items.Insert(0, GetInitItem())


        Dim item As Telerik.Web.UI.RadComboBoxItem
        If GetArgs() IsNot Nothing Then
            item = ddlCallCode.FindItemByValue(Me.GetArgs)
            If item IsNot Nothing Then
                item.Selected = True
                ddlCallCode.Enabled = False
            End If
        End If

        'ddlSubType.DataSource = CallManager.ABSSubmissionType_Get(PortalId, "")
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        appCodes = GetApplicationCodes("ABS", "SUBMISSION_TYPE", True)

        ddlSubType.DataSource = appCodes
        ddlSubType.DataBind()
        ddlSubType.Items.Insert(0, GetInitItem())

        If GetSubType() IsNot Nothing Then
            item = ddlSubType.FindItemByValue(Me.GetSubType)
            If item IsNot Nothing Then
                item.Selected = True
                ddlSubType.Enabled = False
            End If
        End If


        ddlInternalStatus.DataSource = GetApplicationCodes("ABS", "INTERNAL_STATUS", True)
        ddlInternalStatus.DataBind()
        ddlInternalStatus.Items.Insert(0, GetInitItem())
        item = ddlInternalStatus.Items.FindItemByValue("PENDING_SUBMISSION")
        If item IsNot Nothing Then
            ddlInternalStatus.Items.Remove(item)
        End If

        ddlExternalStatus.DataSource = GetApplicationCodes("ABS", "EXTERNAL_STATUS", True)
        ddlExternalStatus.DataBind()
        ddlExternalStatus.Items.Insert(0, GetInitItem())
        item = ddlExternalStatus.Items.FindItemByValue("DRAFT")
        If item IsNot Nothing Then
            ddlExternalStatus.Items.Remove(item)
        End If

        ddlTopic.DataSource = CallManager.ABSSubmissionType_Topic_Get(PortalId, "", "")
        ddlTopic.DataBind()
        ddlTopic.Items.Insert(0, GetInitItem())

        RadGridSubmissions.DataSource = Nothing
        RadGridSubmissions.DataBind()

        'Add the tasks
        If GetArgs() Is Nothing OrElse GetSubType() Is Nothing Then
            Dim comboBoxItem As Telerik.Web.UI.RadComboBoxItem = ddlActions.Items.FindItemByValue("AssignToSession")
            If comboBoxItem IsNot Nothing Then
                comboBoxItem.Remove()
            End If
            chkTransferred.Visible = False
        End If

    End Sub

    Private Sub ReloadTopics()
        Dim tempSubType As String = ""
        Dim tempCallCode As String = ""
        ddlTopic.Items.Clear()

        If Not ddlSubType.SelectedValue = "-1" Then
            tempSubType = ddlSubType.SelectedValue
        End If
        If Not ddlCallCode.SelectedValue = "-1" Then
            tempCallCode = ddlCallCode.SelectedValue
        End If

        'ddlTopic.DataSource = CallManager.ABSSubmissionType_Topic_Get(PortalId, tempCallCode, tempSubType)
        ddlTopic.DataSource = GetTopics(tempCallCode, tempSubType)
        ddlTopic.DataBind()
        ddlTopic.Items.Insert(0, GetInitItem())
    End Sub


    Private Function GetTopics(ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.ApplicationInfo.IApplicationSubcodes

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes = Nothing

        If (Not ABSCALLCode = "") And (Not SubmissionTypeCode = "") Then
            oCallSubTypes = CallManager.ABSSubmissionType_Get(PortalId, ABSCALLCode, SubmissionTypeCode)
        ElseIf (Not ABSCALLCode = "") Then
            oCallSubTypes = CallManager.ABSSubmissionType_Get(PortalId, ABSCALLCode)
        ElseIf (Not SubmissionTypeCode = "") Then
            oCallSubTypes = CallManager.ABSSubmissionType_Get(PortalId, "", SubmissionTypeCode)
        Else
            Dim oAbsSubTypeTopics As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopics

            oAbsSubTypeTopics = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeTopics")
            oAbsSubTypeTopics.Fill()

            Return oAbsSubTypeTopics
        End If


        If oCallSubTypes IsNot Nothing AndAlso oCallSubTypes.Count > 0 Then



            Return Me.GetApplicationSubCodes("ABS", "SUBMISSION_TOPIC", oCallSubTypes(0).ValidationTopicCodeString, False)

            'Return oCallSubTypes(0).AbstractCallSubmissionTypeTopics

        End If

        Return Nothing
    End Function


#End Region

#Region "Public Function"

#End Region


#Region "Overrides methods"
    Public Overrides Sub SetupUpdateView(Optional ByVal SubmissionsExists As Boolean = False)
        SetupControls()
    End Sub

#End Region
   
  

End Class
