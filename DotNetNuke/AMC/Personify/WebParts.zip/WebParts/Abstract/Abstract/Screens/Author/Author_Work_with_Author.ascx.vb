Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI

Public Class Author_Work_with_Author
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region " Constants "
    Private Const C_DATATEXTFIELD As String = "Description"
    Private Const C_DATAVALUEFIELD As String = "Code"

#End Region
#Region "Properties"
    Public ReadOnly Property AbstractSubmissionAuthorId() As Integer
        Get
            If Request("aid") IsNot Nothing Then
                Return CInt(Request("aid"))
            Else
                Return 0
            End If
        End Get
    End Property

    Public Property mcid() As String
        Get
            Return ViewState("mcid")
        End Get
        Set(ByVal value As String)
            ViewState("mcid") = value
        End Set
    End Property

    Public Property scid() As Integer
        Get
            Return ViewState("scid")
        End Get
        Set(ByVal value As Integer)
            ViewState("scid") = value
        End Set
    End Property
    Private _mcid As String
    Private _scid As Integer

#End Region

#Region "Controls"

    Protected WithEvents pnlMain As Panel
    Protected WithEvents lblMessage As Label

    Protected WithEvents lblFullName As Label
    Protected WithEvents lblInstitution As Label
    Protected WithEvents RadComboBoxSuffix As RadComboBox
    Protected WithEvents RadComboBoxCountry As RadComboBox

    Protected WithEvents RadTextBoxFirstName As RadTextBox
    Protected WithEvents RadTextBoxMI As RadTextBox
    Protected WithEvents RadTextBoxLastName As RadTextBox
    Protected WithEvents RadTextBoxCredentials As RadTextBox
    Protected WithEvents RadTextBoxInstitution As RadTextBox
    Protected WithEvents RadTextBoxDepartment As RadTextBox

    Protected WithEvents RadTextBoxAddress1 As RadTextBox
    Protected WithEvents RadTextBoxAddress2 As RadTextBox
    Protected WithEvents RadTextBoxCity As RadTextBox
    Protected WithEvents RadTextBoxState As RadTextBox
    Protected WithEvents RadTextBoxZip As RadTextBox
    Protected WithEvents CheckBoxConfidential As CheckBox

    Protected WithEvents RadTextBoxEmail As RadTextBox
    Protected WithEvents RadTextBoxPhone As RadTextBox
    'Protected WithEvents RadTextBoxFax As RadTextBox
    Protected WithEvents CheckBoxDontPublish As CheckBox


    Protected WithEvents RadGridAuthorDisclosureQuestions As RadGrid
    Protected WithEvents ctlAuthorSubmissions As AuthorSubmissions
    Protected WithEvents ctlAuthorReviews As AuthorReviews

    Protected WithEvents ctlAuthorHistory As AuthorHistory

    Protected WithEvents btnSaveAuthor As Button



#End Region
#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If ValidateQS() Then
            pnlMain.Visible = True
            lblMessage.Visible = False
            If Not Page.IsPostBack Then
                LoadInterface()
            End If
            LoadUserControls()
            LoadComboBoxes()
        Else
            pnlMain.Visible = False
            lblMessage.Visible = True
            lblMessage.Text = "Query String arguments expected"
        End If


    End Sub

    Private Function ValidateQS() As Boolean
        If AbstractSubmissionAuthorId = 0 Then
            Return False
        Else
            Return True
        End If

    End Function

    Protected Sub RadGridAuthorDisclosureQuestions_NeedDataSource(ByVal [source] As Object, _
          ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)

        Dim list As ArrayList = New ArrayList()
        Dim oAuthorDisclosureControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
        oAuthorDisclosureControls = CallManager.ABSSubmissionType_GetAuthorDisclosureQuestions(PortalId, "", "") 'GetArgs, GetSubType)

        Dim oAbstractSubmissionAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor
        oAbstractSubmissionAuthor = CallManager.GetAuthor(PortalId, AbstractSubmissionAuthorId)

        If oAbstractSubmissionAuthor.AbstractSubmissionAuthorDisclosures IsNot Nothing AndAlso oAbstractSubmissionAuthor.AbstractSubmissionAuthorDisclosures.Count > 0 Then

            If oAbstractSubmissionAuthor IsNot Nothing Then
                For Each oAuthorDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosure In oAbstractSubmissionAuthor.AbstractSubmissionAuthorDisclosures

                    Dim row As AuthorDisclosureQuestionsData = New AuthorDisclosureQuestionsData()
                    row.AuthorDisclosureControlId = oAuthorDisclosureQuestion.AbstractCallSubmissionTypeAuthorDisclosureControlId
                    row.RelatedCustomerName = oAuthorDisclosureQuestion.RelatedCustomerName
                    row.DisclosureProductDescription = oAuthorDisclosureQuestion.DisclosureProductDescription

                    If oAuthorDisclosureControls IsNot Nothing AndAlso oAuthorDisclosureControls.Count > 0 Then
                        For Each oDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl In oAuthorDisclosureControls
                            If oDisclosureQuestion.AbstractCallSubmissionTypeAuthorDisclosureControlId = oAuthorDisclosureQuestion.AbstractCallSubmissionTypeAuthorDisclosureControlId Then
                                row.AbstractCallCode = oDisclosureQuestion.AbstractCallCode
                                row.SubmissionTypeCode = oDisclosureQuestion.SubmissionTypeCode
                                row.DisclosureRelationshipCode = oDisclosureQuestion.DisclosureRelationshipCode.Description
                                row.QuestionSeq = oDisclosureQuestion.QuestionSequence
                                row.QuestionText = oDisclosureQuestion.QuestionText
                                Exit For
                            End If
                        Next
                    End If
                    list.Add(row)
                Next
            End If
        End If

        RadGridAuthorDisclosureQuestions.DataSource = list
    End Sub

    Protected Sub btnSaveAuthor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSaveAuthor.Click
        If Page.IsValid AndAlso ValidateSubmissionTypeDates() Then
            Dim oValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oValidationIssues = SaveAuthor()

            If oValidationIssues IsNot Nothing AndAlso oValidationIssues.ErrorCount > 0 Then
                ShowPopupMessage(oValidationIssues)
            Else
                ShowPopupMessage(Constants.Const_Save_Message)
            End If
        Else
            ShowPopupMessage(Constants.Const_PageError_Meesage)
        End If

    End Sub
    Private Function ValidateSubmissionTypeDates() As Boolean

        Return True
    End Function
    Private Function SaveAuthor() As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oAbstractSubmissionAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        oAbstractSubmissionAuthors = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors"), TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors)

        With oAbstractSubmissionAuthors
            .Filter.Add("AbstractSubmissionAuthorId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionAuthorId)
            .Fill()
        End With

        If oAbstractSubmissionAuthors IsNot Nothing AndAlso oAbstractSubmissionAuthors.Count > 0 Then
            With oAbstractSubmissionAuthors(0)
                .FirstName = RadTextBoxFirstName.Text
                .MiddleName = RadTextBoxMI.Text
                .LastName = RadTextBoxLastName.Text
                .NameSuffix = .NameSuffix.List(RadComboBoxSuffix.SelectedValue).ToCodeObject

                '.Department = RadTextBoxDepartment.Text
                .CompanyInstitutionName = RadTextBoxInstitution.Text
                .NameCredentials = RadTextBoxCredentials.Text

                .Address1 = RadTextBoxAddress1.Text
                .Address2 = RadTextBoxAddress2.Text
                .City = RadTextBoxCity.Text
                .State = RadTextBoxState.Text
                .PostalCode = RadTextBoxZip.Text
                .CountryCode = .CountryCode.List(RadComboBoxCountry.SelectedValue).ToCodeObject
                .ConfidentialAddressFlag = CheckBoxConfidential.Checked

                .EmailAddress = RadTextBoxEmail.Text
                .Phone = RadTextBoxPhone.Text
                '.Fax = RadTextBoxFax.Text
                .CanPublishPhoneFaxEmailFlag = CheckBoxDontPublish.Checked

            End With

            ''RadGridAuthorDisclosureQuestions  is read only for now
            'Dim questions As New Hashtable
            'Dim oTypeAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
            'oTypeAuthorDisclosureQuestions = CallManager.ABSSubmissionType_GetAuthorDisclosureQuestions(PortalId, GetArgs, GetSubType)

            'Dim index As Integer = 0
            'For Each QuestionItem As Telerik.Web.UI.GridDataItem In RadGridAuthorDisclosureQuestions.Items
            '    Dim txtRelatedCustomerName As TextBox = QuestionItem.FindControl("txtRelatedCustomerName")
            '    Dim txtDisclosureProductDescription As TextBox = QuestionItem.FindControl("txtDisclosureProductDescription")
            '    If oTypeAuthorDisclosureQuestions IsNot Nothing AndAlso oTypeAuthorDisclosureQuestions.Count > 0 Then
            '        For i As Integer = 0 To oTypeAuthorDisclosureQuestions.Count - 1
            '            If CInt(QuestionItem.OwnerTableView.DataKeyValues(index)("AuthorDisclosureControlId")) = oTypeAuthorDisclosureQuestions(i).AbstractCallSubmissionTypeAuthorDisclosureControlId Then
            '                Dim oAuthorDisclosure As New AuthorDisclosure
            '                With oAuthorDisclosure
            '                    .DisclosureProductDescription = txtDisclosureProductDescription.Text
            '                    .RelatedCustomerName = txtRelatedCustomerName.Text
            '                    .DisclosureRelationshipCode = oTypeAuthorDisclosureQuestions(i).DisclosureRelationshipCodeString
            '                End With
            '                questions.Add(oTypeAuthorDisclosureQuestions(i).AbstractCallSubmissionTypeAuthorDisclosureControlId, oAuthorDisclosure)
            '                Exit For
            '            End If

            '        Next
            '    End If
            '    index = index + 1
            'Next
            'For Each question As DictionaryEntry In questions
            '    Dim oAuthorDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosure
            '    Dim found As Boolean = False
            '    For Each oAuthorDisclosureQuestion In oAbstractSubmissionAuthors(0).AbstractSubmissionAuthorDisclosures
            '        If oAuthorDisclosureQuestion.CustomerDisclosureId = CInt(question.Key) Then
            '            With oAuthorDisclosureQuestion
            '                .CustomerDisclosureId = CInt(question.Key)
            '                .DisclosureRelationshipCode = .DisclosureRelationshipCode.List(CType(question.Value, AuthorDisclosure).DisclosureRelationshipCode).ToCodeObject
            '                .RelatedCustomerName = CType(question.Value, AuthorDisclosure).RelatedCustomerName
            '                .DisclosureProductDescription = CType(question.Value, AuthorDisclosure).DisclosureProductDescription
            '            End With
            '            found = True
            '            Exit For
            '        End If
            '    Next
            '    If Not found Then
            '        oAuthorDisclosureQuestion = oAbstractSubmissionAuthors(0).AbstractSubmissionAuthorDisclosures.AddNew
            '        With oAuthorDisclosureQuestion
            '            .CustomerDisclosureId = CInt(question.Key)
            '            .DisclosureRelationshipCode = .DisclosureRelationshipCode.List(CType(question.Value, AuthorDisclosure).DisclosureRelationshipCode).ToCodeObject
            '            .RelatedCustomerName = CType(question.Value, AuthorDisclosure).RelatedCustomerName
            '            .DisclosureProductDescription = CType(question.Value, AuthorDisclosure).DisclosureProductDescription
            '        End With
            '    End If
            'Next
            oAbstractSubmissionAuthors.Save()
            Return oAbstractSubmissionAuthors.ValidationIssues
        Else
            Return Nothing
        End If
    End Function

#End Region


#Region "Helper functions"
    Private Sub LoadComboBoxes()
        'Suffix combobox
        Dim oCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        oCodes = GetApplicationCodes("CUS", "NAME_SUFFIX", True)
        With RadComboBoxSuffix
            .Items.Clear()
            .DataTextField = C_DATATEXTFIELD
            .DataValueField = C_DATAVALUEFIELD
            .DataSource = oCodes
            .DataBind()
            .Items.Add(New RadComboBoxItem("", ""))
            .SelectedIndex = .Items.Count
        End With

        'Country combobox
        Dim oCountries As TIMSS.API.ApplicationInfo.IApplicationCountries = Nothing
        'oCountries = GetApplicationCountries(PortalId)
        oCountries = TIMSS.API.CachedApplicationData.ApplicationDataCache.Countries

        ' TIMSS.API.CachedApplicationData.ApplicationDataCache.Countries
        With RadComboBoxCountry
            .DataTextField = "CountryDescription"
            .DataValueField = "CountryCode"
            .DataSource = oCountries
            .DataBind()
        End With
    End Sub

    Private Sub LoadUserControls()
       
        With ctlAuthorSubmissions
            .PortalId = PortalId
            .MasterCustomerId = mcid
            .SubCustomerId = scid
            .IsClosed = False
        End With

        With ctlAuthorHistory
            .PortalId = PortalId
            .MasterCustomerId = mcid
            .SubCustomerId = scid
        End With

        With ctlAuthorReviews
            .PortalId = PortalId
            .MasterCustomerId = mcid
            .SubCustomerId = scid
            .CallCode = GetArgs()
            .SubTypeCode = GetSubType()
        End With
    End Sub

    Private Sub LoadInterface()
        Dim oAbstractSubmissionAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor
        oAbstractSubmissionAuthor = CallManager.GetAuthor(PortalId, AbstractSubmissionAuthorId)
        If oAbstractSubmissionAuthor IsNot Nothing Then
            With oAbstractSubmissionAuthor
                lblFullName.Text = .FirstName & " " & .LastName
                lblInstitution.Text = .CompanyInstitutionName

                RadTextBoxFirstName.Text = .FirstName
                RadTextBoxMI.Text = .MiddleName
                RadTextBoxEmail.Text = .EmailAddress
                RadTextBoxLastName.Text = .LastName
                RadTextBoxPhone.Text = .Phone
                RadComboBoxSuffix.SelectedValue = .NameSuffixString
                CheckBoxDontPublish.Checked = Not .CanPublishPhoneFaxEmailFlag
                RadTextBoxInstitution.Text = .CompanyInstitutionName
                RadTextBoxCredentials.Text = .NameCredentials
                RadTextBoxAddress1.Text = .Address1
                RadTextBoxAddress2.Text = .Address2
                RadTextBoxCity.Text = .City
                RadTextBoxState.Text = .State
                RadTextBoxZip.Text = .PostalCode
                RadComboBoxCountry.SelectedValue = .CountryCodeString
                CheckBoxConfidential.Checked = .ConfidentialAddressFlag
                mcid = .MasterCustomerId
                scid = .SubCustomerId
            End With

        End If
     
    End Sub

#End Region



    Public Class AuthorDisclosure
        Public RelatedCustomerName As String
        Public DisclosureProductDescription As String
        Public DisclosureRelationshipCode As String
    End Class


End Class

