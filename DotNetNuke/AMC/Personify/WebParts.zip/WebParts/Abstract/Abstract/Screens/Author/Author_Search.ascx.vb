Imports TIMSS.SQLObjects
Imports ScreenController.AbstractScreen

Public Class Author_Search
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected WithEvents TextBoxFirstName As TextBox
    Protected WithEvents TextBoxLastName As TextBox
    Protected WithEvents TextBoxEmail As TextBox
    Protected WithEvents TextBoxPhone As TextBox
    Protected WithEvents TextBoxCity As TextBox
    Protected WithEvents RadComboBoxInstitution As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxCredentials As Telerik.Web.UI.RadComboBox
    Protected WithEvents RadComboBoxState As Telerik.Web.UI.RadComboBox

    Protected WithEvents LinkButtonClearSearch As LinkButton
    Protected WithEvents LinkButtonSearch As LinkButton
    Protected WithEvents LinkButtonEmail As LinkButton

    Protected WithEvents RadGrid1 As Telerik.Web.UI.RadGrid

#End Region


#Region "Events"


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Not Page.IsPostBack Then

            Dim oAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors


            oAuthors = CallManager.GetAuthors(PortalId, TextBoxFirstName.Text, TextBoxLastName.Text, RadComboBoxInstitution.SelectedValue, RadComboBoxCredentials.SelectedValue, TextBoxEmail.Text, TextBoxPhone.Text, TextBoxCity.Text, RadComboBoxState.SelectedValue)

            RadComboBoxInstitution.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
            RadComboBoxCredentials.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))
            RadComboBoxState.Items.Add(New Telerik.Web.UI.RadComboBoxItem("Select", ""))

            Dim aInstitution As New ArrayList
            'Dim aCredentials As New ArrayList
            Dim aState As New ArrayList

            If oAuthors IsNot Nothing AndAlso oAuthors.Count > 0 Then
                For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAuthors
                    If oAuthor.CompanyInstitutionName IsNot Nothing AndAlso oAuthor.CompanyInstitutionName.Length > 0 Then
                        If aInstitution.IndexOf(oAuthor.CompanyInstitutionName) < 0 Then
                            aInstitution.Add(oAuthor.CompanyInstitutionName)
                        End If
                    End If
                    'If oAuthor.NameCredentials IsNot Nothing AndAlso oAuthor.NameCredentials.Length > 0 Then
                    '    If aCredentials.IndexOf(oAuthor.NameCredentials) < 0 Then
                    '        aCredentials.Add(oAuthor.NameCredentials)
                    '    End If
                    'End If
                    If oAuthor.State IsNot Nothing AndAlso oAuthor.State.Length > 0 Then
                        If aState.IndexOf(oAuthor.State) < 0 Then
                            aState.Add(oAuthor.State)
                        End If
                    End If
                Next
            End If


            If aInstitution IsNot Nothing AndAlso aInstitution.Count > 0 Then
                Dim Institution(aInstitution.Count - 1) As String
                aInstitution.CopyTo(Institution)
                Array.Sort(Institution)
                For Each anInstitution As String In Institution
                    RadComboBoxInstitution.Items.Add(New Telerik.Web.UI.RadComboBoxItem(anInstitution, anInstitution))
                Next
            End If

            'If aCredentials IsNot Nothing AndAlso aCredentials.Count > 0 Then
            '    Dim Credentials(aCredentials.Count - 1) As String
            '    aCredentials.CopyTo(Credentials)
            '    Array.Sort(Credentials)
            '    For Each anCredentials As String In Credentials
            '        RadComboBoxCredentials.Items.Add(New Telerik.Web.UI.RadComboBoxItem(anCredentials, anCredentials))
            '    Next
            'End If

            Dim Credentials As TIMSS.API.ApplicationInfo.IApplicationCodes = _
                 GetApplicationCodes("CUS", "CREDENTIALS", True)
            If Credentials IsNot Nothing AndAlso Credentials.Count > 0 Then
                For Each Credential As TIMSS.API.ApplicationInfo.IApplicationCode In Credentials
                    RadComboBoxCredentials.Items.Add(New Telerik.Web.UI.RadComboBoxItem(Credential.Description.ToString, Credential.Code))
                Next
            End If

            If aState IsNot Nothing AndAlso aState.Count > 0 Then
                Dim State(aState.Count - 1) As String
                aState.CopyTo(State)
                Array.Sort(State)
                For Each anState As String In State
                    RadComboBoxState.Items.Add(New Telerik.Web.UI.RadComboBoxItem(anState, anState))
                Next
            End If


            reset_search()

        End If
    End Sub

#End Region


#Region "Helper functions"


#End Region


    Function EmailAddressCheck(ByVal emailAddress As String) As Boolean
        Dim pattern As String = "\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*([,;]\s*\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)*"
        Dim emailAddressMatch As System.Text.RegularExpressions.Match = System.Text.RegularExpressions.Regex.Match(emailAddress, pattern)
        If emailAddressMatch.Success Then
            EmailAddressCheck = True
        Else
            EmailAddressCheck = False
        End If
    End Function

    Protected Sub LinkButtonEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonEmail.Click

        Dim Emails As New ArrayList

        For Each dataitem As Telerik.Web.UI.GridDataItem In RadGrid1.SelectedItems

            Dim EmailAddress As String = dataitem.Item("Email").Text
            If EmailAddressCheck(EmailAddress) = True Then
                Dim oEmail As New AbstractEmail
                oEmail.EmailName = dataitem.Item("FullName").Text
                oEmail.EmailAddress = EmailAddress
                Emails.Add(oEmail)
            End If
        Next

        If Emails.Count > 0 Then
            Session(Constants.Const_EmailListSessionName) = Emails
            Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Admin_Email, String))))
        End If

    End Sub

    Protected Sub LinkButtonSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSearch.Click

        Dim AuthorsDT As DataTable = GetAuthorsData()
        RadGrid1.DataSource = AuthorsDT
        RadGrid1.DataBind()

        If AuthorsDT.Rows.Count > 0 Then
            LinkButtonEmail.Visible = True
        Else
            LinkButtonEmail.Visible = False
        End If

    End Sub

    Private Sub RadGrid1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGrid1.NeedDataSource
        If Page.IsPostBack Then RadGrid1.DataSource = GetAuthorsData()
    End Sub


    Private Sub reset_search()
        TextBoxFirstName.Text = ""
        TextBoxLastName.Text = ""

        TextBoxEmail.Text = ""
        TextBoxPhone.Text = ""
        TextBoxCity.Text = ""

        RadComboBoxInstitution.SelectedIndex = 0
        RadComboBoxCredentials.SelectedIndex = 0
        RadComboBoxState.SelectedIndex = 0
    End Sub

    Protected Sub LinkButtonClearSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonClearSearch.Click
        reset_search()
    End Sub


    Public Function GetAuthorsData() As DataTable

        Dim AuthorsDT As DataTable = New DataTable()

        Dim oAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors

        oAuthors = CallManager.GetAuthors(PortalId, TextBoxFirstName.Text, TextBoxLastName.Text, RadComboBoxInstitution.SelectedValue, RadComboBoxCredentials.SelectedValue, TextBoxEmail.Text, TextBoxPhone.Text, TextBoxCity.Text, RadComboBoxState.SelectedValue)

        If oAuthors IsNot Nothing AndAlso oAuthors.Count > 0 Then


            AuthorsDT.Columns.Add("AuthorId", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("FullName", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("Institution", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("Credentials", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("Email", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("Phone", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("City", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("State", Type.GetType("System.String"))
            AuthorsDT.Columns.Add("Link", Type.GetType("System.String"))

            Dim row As DataRow
            For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAuthors
                row = AuthorsDT.NewRow()
                row("AuthorId") = oAuthor.AbstractSubmissionAuthorId
                row("FullName") = oAuthor.LastName + ", " + oAuthor.FirstName
                row("Institution") = oAuthor.CompanyInstitutionName
                row("Credentials") = oAuthor.NameCredentials
                row("Email") = oAuthor.EmailAddress
                row("Phone") = oAuthor.Phone
                row("City") = oAuthor.City
                row("State") = oAuthor.State
                row("Link") = NavigateURL("", "s=" & ScreenController.AbstractScreen.Author_Work_with_Author & "&aid=" & oAuthor.AbstractSubmissionAuthorId)
                AuthorsDT.Rows.Add(row)
            Next

            Return AuthorsDT

        End If

        Return AuthorsDT

    End Function


End Class
