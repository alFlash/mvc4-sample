
Imports ScreenController.AbstractScreen

Public Class Review_Submission
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"

    Protected SubmissionTypeLabel As Label
    Protected SubmissionTitleLabel As Label
    Protected AbstractCallTitleLabel As Label
    Protected ExpertiseLevelLabel As Label
    Protected ReviewBlindRuleLabel As Label
    Protected SubmissionCategoryLabel As Label
    Protected SubmissionDateLabel As Label
    Protected SubmissionTopicLabel As Label

    Protected WithEvents LinkButtonSubmitScore As LinkButton
    Protected WithEvents LinkButtonSubmitTo As LinkButton

    Protected WithEvents Repeater1 As Repeater
    Protected WithEvents RadMultiPage1 As Telerik.Web.UI.RadMultiPage

    Protected WithEvents ctlSubmissionTextBlocks As SubmissionTextBlocks
    Protected WithEvents ctlSubmissionAttachments As SubmissionAttachments
    Protected WithEvents RadTabStrip1 As Telerik.Web.UI.RadTabStrip

    Protected MessageLabel As Label
    Protected Panel1 As Panel
    Protected WithEvents lblReviewerInstruction As Label


#End Region


#Region "Events"

    Private _SubmissionReviewerId As Integer = 0
    Private _rid As New ReviewSubmissionData()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
 
        _SubmissionReviewerId = Integer.Parse(Request("srid"))

        If Not _SubmissionReviewerId > 0 Then
            MessageLabel.Text = "Nothing selected"
        Else

            _rid.GetData(PortalId, _SubmissionReviewerId)

            With ctlSubmissionAttachments
                .AbstractSubmissionId = _rid.AbstractSubmissionId
                Dim AdditionalPathExtension As String = String.Concat(_rid.AbstractCallCode, "\", _rid.SubmissionTypeCode, "\", _rid.AbstractSubmissionId)
                .AdditionalPathExtension = AdditionalPathExtension
                .IsEdit = False
                .PortalId = PortalId
            End With

            With ctlSubmissionTextBlocks
                .AbstractSubmissionId = _rid.AbstractSubmissionId
                .EditNavigateURL = ""
                .IsEdit = False
                .PortalId = PortalId
                .ShowInstruction = False
            End With

            If Not Page.IsPostBack Then

                If MasterCustomerId.ToUpper <> _rid.MasterCustomerId Or SubCustomerId <> _rid.SubCustomerId Then
                    'read only mode
                    LinkButtonSubmitTo.Visible = False
                    LinkButtonSubmitScore.Visible = False
                End If

                AbstractCallTitleLabel.Text = _rid.AbstractCallTitle
                ExpertiseLevelLabel.Text = _rid.ExpertiseLevel
                ReviewBlindRuleLabel.Text = _rid.ReviewBlindRule
                SubmissionCategoryLabel.Text = _rid.SubmissionCategory
                If Not PersonifyWebCommon.isNullDate(_rid.SubmissionDate) Then
                    SubmissionDateLabel.Text = _rid.SubmissionDate
                Else
                    SubmissionDateLabel.Text = String.Empty
                End If

                SubmissionTitleLabel.Text = _rid.SubmissionTitle
                SubmissionTopicLabel.Text = _rid.SubmissionTopic
                SubmissionTypeLabel.Text = _rid.SubmissionType


                lblReviewerInstruction.Text = CallManager.GetInstruction(PortalId, Constants.Const_InstructionType_Socring, _rid.AbstractCallCode, _rid.SubmissionTypeCode)

                If _rid.ReviewScoring IsNot Nothing AndAlso _rid.ReviewScoring.Length > 0 Then

                    Repeater1.DataSource = _rid.ReviewScoring
                    Repeater1.DataBind()

                    For Each rptItem As RepeaterItem In Repeater1.Items


                        Dim HiddenFieldId As HiddenField = CType(rptItem.FindControl("HiddenFieldId"), HiddenField)
                        Dim AbstractCallSubmissionTypeScoringControlId As Integer = Convert.ToString(HiddenFieldId.Value)

                        Dim index As Integer = -1
                        For j As Integer = 0 To _rid.ReviewScoring.Length - 1
                            If _rid.ReviewScoring(j).AbstractCallSubmissionTypeScoringControlId = AbstractCallSubmissionTypeScoringControlId Then
                                index = j
                                Exit For
                            End If
                        Next

                        If index >= 0 Then

                            Dim ComboBox As DropDownList = CType(rptItem.FindControl("RadComboBoxScore"), DropDownList)
                            Dim txtAnswerCodeScore As TextBox = CType(rptItem.FindControl("txtAnswerCodeScore"), TextBox)

                            If _rid.ReviewScoring(index).AnswerTypeCodeString = "DROP_DOWN" Then
                                'if DROP_DOWN
                                'Answer text box is disabled
                                txtAnswerCodeScore.Visible = False
                                txtAnswerCodeScore.Enabled = False
                                Dim RFVAnswer As RequiredFieldValidator = CType(rptItem.FindControl("RFVAnswer"), RequiredFieldValidator)
                                RFVAnswer.Visible = False
                                RFVAnswer.Enabled = False


                                Dim ScoringCriterions As TIMSS.API.ApplicationInfo.IApplicationSubcodes = GetApplicationSubCodes("ABS", "SCORING_ANSWER", _rid.ReviewScoring(index).ScoringAnswerCodeString, True)

                                If ScoringCriterions IsNot Nothing AndAlso ScoringCriterions.Count > 0 Then
                                    ComboBox.Enabled = True
                                    ComboBox.Items.Add(New ListItem("Select", ""))
                                    For Each Score As TIMSS.API.ApplicationInfo.IApplicationSubcode In ScoringCriterions
                                        ComboBox.Items.Add(New ListItem(Score.Description, Score.Subcode))
                                    Next

                                    If _rid.ReviewScoring(index).ScoringAnswerSubcode IsNot Nothing AndAlso _rid.ReviewScoring(index).ScoringAnswerSubcode.Length > 0 Then
                                        ComboBox.SelectedValue = _rid.ReviewScoring(index).ScoringAnswerSubcode
                                    Else
                                        ComboBox.SelectedIndex = 0
                                    End If

                                    'display the comments
                                    If _rid.ReviewScoring(index).AllowCommentsFlag = True Then
                                        Dim textbox As TextBox = CType(rptItem.FindControl("TextBoxComments"), TextBox)
                                        textbox.Visible = True
                                        textbox.Enabled = True
                                        textbox.Text = _rid.ReviewScoring(index).Comments
                                    Else
                                        Dim textbox As TextBox = CType(rptItem.FindControl("TextBoxComments"), TextBox)
                                        textbox.Visible = False
                                        textbox.Enabled = False
                                    End If
                                End If

                                'Dim RequiredFieldValidatorComments As RequiredFieldValidator = CType(rptItem.FindControl("RequiredFieldValidatorComments"), RequiredFieldValidator)
                                'RequiredFieldValidatorComments.Visible = False
                                'RequiredFieldValidatorComments.Enabled = False

                                If _rid.ReviewScoring(index).Comments IsNot Nothing AndAlso _rid.ReviewScoring(index).Comments.Length > 0 Then
                                    Dim textbox As TextBox = CType(rptItem.FindControl("TextBoxComments"), TextBox)
                                    textbox.Text = _rid.ReviewScoring(index).Comments
                                End If

                            Else
                                'if only text
                                ComboBox.Visible = False
                                ComboBox.Enabled = False
                                

                                Dim requiredfieldvalidatorscore As RequiredFieldValidator = CType(rptItem.FindControl("RequiredFieldValidatorScore"), RequiredFieldValidator)
                                requiredfieldvalidatorscore.Visible = False
                                requiredfieldvalidatorscore.Enabled = False

                                'answer code is enabled
                                txtAnswerCodeScore.Visible = True
                                txtAnswerCodeScore.Enabled = True
                                Dim RFVAnswer As RequiredFieldValidator = CType(rptItem.FindControl("RFVAnswer"), RequiredFieldValidator)
                                RFVAnswer.Visible = True
                                RFVAnswer.Enabled = True


                                If _rid.ReviewScoring(index).ScoringAnswerText IsNot Nothing AndAlso _rid.ReviewScoring(index).ScoringAnswerText.Length > 0 Then
                                    Dim textbox As TextBox = CType(rptItem.FindControl("txtAnswerCodeScore"), TextBox)
                                    textbox.Text = _rid.ReviewScoring(index).ScoringAnswerText
                                End If

                            End If
                            'display comments
                            If _rid.ReviewScoring(index).AllowCommentsFlag = True Then
                                Dim textbox As TextBox = CType(rptItem.FindControl("TextBoxComments"), TextBox)
                                textbox.Visible = True
                                textbox.Enabled = True
                                textbox.Text = _rid.ReviewScoring(index).Comments
                            Else
                                Dim textbox As TextBox = CType(rptItem.FindControl("TextBoxComments"), TextBox)
                                textbox.Visible = False
                                textbox.Enabled = False
                            End If

                        End If
                    Next
                End If

            End If
        End If



    End Sub

#End Region


#Region "Helper functions"


#End Region


    Protected Sub LinkButtonSubmitTo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSubmitTo.Click
        RadTabStrip1.SelectedIndex = 1        
        RadMultiPage1.SelectedIndex = 1
    End Sub

    Protected Sub LinkButtonSubmitScore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButtonSubmitScore.Click
        For Each rptItem As RepeaterItem In Repeater1.Items
            Dim RequiredFieldValidatorScore As RequiredFieldValidator = CType(rptItem.FindControl("RequiredFieldValidatorScore"), RequiredFieldValidator)
            If RequiredFieldValidatorScore.Enabled = True Then RequiredFieldValidatorScore.Validate()

            'Dim requiredfieldvalidatorcomments As RequiredFieldValidator = CType(rptItem.FindControl("RequiredFieldValidatorComments"), RequiredFieldValidator)
            'If requiredfieldvalidatorcomments.Enabled = True Then requiredfieldvalidatorcomments.Validate()

        Next

        If Page.IsValid Then

            ''MasterCustomerId, SubCustomerId read only

            _rid.GetData(PortalId, _SubmissionReviewerId)

            Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers
            Dim oAbstractSubmissionReviewer As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer
            oAbstractSubmissionReviewers = CallManager.GetSubmissionReviewerData(PortalId, _SubmissionReviewerId)
            oAbstractSubmissionReviewer = oAbstractSubmissionReviewers(0)
            'save new
            For Each rptItem As RepeaterItem In Repeater1.Items

                Dim HiddenFieldId As HiddenField = CType(rptItem.FindControl("HiddenFieldId"), HiddenField)
                Dim AbstractCallSubmissionTypeScoringControlId As Integer = Convert.ToString(HiddenFieldId.Value)

                'what's needed
                Dim scoringControlIndex As Integer = -1
                For j As Integer = 0 To _rid.ReviewScoring.Length - 1
                    If _rid.ReviewScoring(j).AbstractCallSubmissionTypeScoringControlId = AbstractCallSubmissionTypeScoringControlId Then
                        scoringControlIndex = j
                        Exit For
                    End If
                Next

                'what is already saved
                Dim savedScorIndex As Integer = -1
                If oAbstractSubmissionReviewers(0).AbstractSubmissionScorings IsNot Nothing AndAlso oAbstractSubmissionReviewers(0).AbstractSubmissionScorings.Count > 0 Then
                    For j As Integer = 0 To oAbstractSubmissionReviewer.AbstractSubmissionScorings.Count - 1
                        If oAbstractSubmissionReviewers(0).AbstractSubmissionScorings(j).AbstractCallSubmissionTypeScoringControlId = AbstractCallSubmissionTypeScoringControlId Then
                            savedScorIndex = j
                            Exit For
                        End If
                    Next
                End If

                'if is not already save create a new one
                If savedScorIndex < 0 Then
                    oAbstractSubmissionReviewers(0).AbstractSubmissionScorings.AddNew()
                    savedScorIndex = oAbstractSubmissionReviewer.AbstractSubmissionScorings.Count - 1
                End If

                'fill with data
                With oAbstractSubmissionReviewers(0).AbstractSubmissionScorings(scoringControlIndex)
                    .AbstractSubmissionId = _rid.AbstractSubmissionId
                    .AbstractSubmissionReviewerId = _rid.AbstractSubmissionReviewerId
                    .AbstractCallSubmissionTypeScoringControlId = _rid.ReviewScoring(scoringControlIndex).AbstractCallSubmissionTypeScoringControlId
                    .SubmissionScoringCriterionDescription = _rid.ReviewScoring(scoringControlIndex).SubmissionScoringCriterionDescription
                    .ScoringCriterionCode = .ScoringCriterionCode.List(_rid.ReviewScoring(scoringControlIndex).ScoringCriterionCodeString).ToCodeObject


                    If _rid.ReviewScoring(scoringControlIndex).AnswerTypeCodeString = "DROP_DOWN" Then
                        Dim ComboBox As DropDownList = CType(rptItem.FindControl("RadComboBoxScore"), DropDownList)
                        .ScoringAnswerSubcode.Code = ComboBox.SelectedValue
                    End If

                    If _rid.ReviewScoring(scoringControlIndex).AnswerTypeCodeString <> "DROP_DOWN" Then
                        Dim textbox As TextBox = CType(rptItem.FindControl("txtAnswerCodeScore"), TextBox)
                        .ScoringAnswerText = textbox.Text
                    End If

                    If _rid.ReviewScoring(scoringControlIndex).AllowCommentsFlag Then
                        Dim textbox As TextBox = CType(rptItem.FindControl("TextBoxComments"), TextBox)
                        If textbox.Text IsNot Nothing Then
                            .Comments = textbox.Text
                        End If
                    End If

                    

                End With

            Next

            'Sreedar: oAbstractSubmissionReviewers
            oAbstractSubmissionReviewer.AssignmentStatusCode.Code = Constants.Const_AssignmentStatus_Completed
            oAbstractSubmissionReviewer.EventStatusCode = Constants.Const_EventCode_RVWR_REVIEW_COMPLETED
            oAbstractSubmissionReviewers.Save()

            If oAbstractSubmissionReviewers.ValidationIssues IsNot Nothing AndAlso oAbstractSubmissionReviewers.ValidationIssues.ErrorCount > 0 Then
                'error on save
                ShowPopupMessage(oAbstractSubmissionReviewers.ValidationIssues)
            Else
                GoToNextPage(ScreenController.AbstractScreen.Reviewer_Inbox, "", "")
            End If
        End If

    End Sub



End Class
