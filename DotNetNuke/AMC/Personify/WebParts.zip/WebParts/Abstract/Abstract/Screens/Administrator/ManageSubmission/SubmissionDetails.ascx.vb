
Imports ScreenController.AbstractScreen
Imports System.Collections.Generic
Imports Telerik.Web.UI

Public Class SubmissionDetails
    Inherits AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This Call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method Call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Variables"
    Private LargestSeq As Integer
    'Private CallCode As String
    Private SubType As String
    Private ReorderedDisclosureQuestions As ArrayList
    Private _newPageFlag As Boolean = False
#End Region

#Region "Controls"
    Protected WithEvents lblSubmissionTitle As Label
    Protected WithEvents lblActionNeeded As Label
    Protected WithEvents lblCorrespondingAuthorValue As Label
    Protected WithEvents lblAbsCallValue As Label
    Protected WithEvents lblOpenInvitationsValue As Label
    Protected WithEvents lblPrimaryAuthorValue As Label
    Protected WithEvents lblSubmittedOnValue As Label
    Protected WithEvents lblUnderReviewValue As Label
    Protected WithEvents lblPresentingAuthorValue As Label
    Protected WithEvents lblCompletedValue As Label
    Protected WithEvents lblPrimaryTopicValue As Label
    Protected WithEvents lblRequiredReviewsValue As Label
    Protected WithEvents txtTopics As Telerik.Web.UI.RadTextBox
    Protected WithEvents txtKeywords As Telerik.Web.UI.RadTextBox
    Protected WithEvents lblInternalStatusValue As Label
    Protected WithEvents lblExternalStatusValue As Label
    Protected WithEvents btnAssignReviewers As Button
    Protected WithEvents btnAssignToSession As Button
    Protected WithEvents btnAccept As Button
    Protected WithEvents btnDecline As Button
    Protected WithEvents btnReturnToAuthor As Button

    Protected WithEvents radTabMenu As RadTabStrip
    Protected WithEvents radMultiTabContent As RadMultiPage

    Protected WithEvents butAddFinalist As Button
    Protected WithEvents lblSubmissionIDValue As Label
    'Protected WithEvents lblTitleValue As Label
    Protected WithEvents lblCategoryValue As Label
    Protected WithEvents lblLengthInMinutesValue As Label
    Protected WithEvents lblTopics As Label
    Protected WithEvents lblKeywords As Label
    Protected WithEvents lblAssignedProducts As Label
    Protected WithEvents pnlAssignedProducts As Panel    
    Protected WithEvents butPreviousPage As Button

    Protected WithEvents butStaffReviewAccept As Button
    Protected WithEvents butStaffReviewDecline As Button

    Protected WithEvents butEditSubmission As Button

#End Region

#Region "Properties"


    Private Property CallCode() As String
        Get
            Return ViewState("CallCode")
        End Get
        Set(ByVal value As String)
            ViewState("CallCode") = value
        End Set
    End Property

    Private Property SubmissionTypeCode() As String
        Get
            Return ViewState("SubmissionTypeCode")
        End Get
        Set(ByVal value As String)
            ViewState("SubmissionTypeCode") = value
        End Set
    End Property


    Private Property PreviousURL() As String
        Get
            Return ViewState("PreviousURL")
        End Get
        Set(ByVal value As String)
            ViewState("PreviousURL") = value
        End Set
    End Property
#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Not Page.IsPostBack Then
            SetupControls()
            AddPageView("PVDetails")
        End If

    End Sub

    Private Sub btnDecline_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDecline.Click
        SubmissionManager.ABS_Submission_Update(PortalId, GetAbsSubId, Constants.Const_EventCode_SUBMISSION_DECLINED)
        SetupControls()
    End Sub

    Private Sub btnAccept_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAccept.Click
        SubmissionManager.ABS_Submission_Update(PortalId, GetAbsSubId, Constants.Const_EventCode_SUBMISSION_ACCEPTED)
        SetupControls()
    End Sub

    Private Sub butAddFinalist_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butAddFinalist.Click
        SubmissionManager.ABS_Submission_Update(PortalId, GetAbsSubId, Constants.Const_EventCode_ACCEPTED_AS_FINALIST)
        SetupControls()
    End Sub

    Private Sub btnAssignReviewers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAssignReviewers.Click
        AssignActions(Constants.Const_AssignToReviewer)
    End Sub

    Private Sub btnAssignToSession_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAssignToSession.Click
        AssignActions(Constants.Const_AssignToSession)
    End Sub

    Private Sub butStaffReviewAccept_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butStaffReviewAccept.Click
        SubmissionManager.ABS_Submission_Update(PortalId, GetAbsSubId, Constants.Const_EventCode_ACCEPTED_FOR_REVIEW)
        SetupControls()
    End Sub

    Private Sub butStaffReviewDecline_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butStaffReviewDecline.Click
        SubmissionManager.ABS_Submission_Update(PortalId, GetAbsSubId, Constants.Const_EventCode_NOT_ACCEPTED_FOR_REVIEW)
        SetupControls()
    End Sub

    Private Sub butEditSubmission_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butEditSubmission.Click
        Me.Response.Redirect(GetEditSubmissionPageURL(Author_SubmissionEntryGeneralInformation, CallCode, Nothing, SubmissionTypeCode, GetAbsSubId), True)
    End Sub
    Private Sub btnReturnToAuthor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReturnToAuthor.Click
        'SubmissionManager.ABS_Submission_Update(PortalId, GetAbsSubId, Constants., Constants.Const_InternalCode_NeedAuthorChanges)
        'SetupControls()
    End Sub

    Protected Sub radTabMenu_TabClick(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadTabStripEventArgs) Handles radTabMenu.TabClick
        e.Tab.PageViewID = AddPageView(e.Tab.PageViewID)
        e.Tab.PageView.Selected = True
    End Sub

    Private Sub butPreviousPage_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butPreviousPage.Click
        Me.Response.Redirect(Me.PreviousURL, True)
    End Sub

    Private Sub radMultiTabContent_PageViewCreated(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadMultiPageEventArgs) Handles radMultiTabContent.PageViewCreated
        Dim seq As Integer = 0
        If _newPageFlag Then
            seq = CInt(ViewState("sequence")) + 1
            ViewState("sequence") = seq.ToString
        Else
            seq = e.PageView.MultiPage.PageViews.Count
        End If

        Dim ControlName As String = Nothing
        Select Case e.PageView.ID
            Case "PVDetails"
                ControlName = ScreenController.Screen_GetName(Admin_DisclosureDetails)
            Case "PVAuthorDetails"
                ControlName = ScreenController.Screen_GetName(Admin_AuthorDetails)
            Case "PVSubmissionContent"
                Dim ctlSubmissionTextBlocks As SubmissionTextBlocks = LoadControl(ScreenController.Screen_GetName(Admin_SubmissionTextBlock))
                With ctlSubmissionTextBlocks
                    .AbstractSubmissionId = GetAbsSubId()
                    .EditNavigateURL = ""
                    .IsEdit = False
                    .PortalId = PortalId
                    .ID = String.Concat(e.PageView.ID, "_TabContent")
                End With
                e.PageView.Controls.Add(ctlSubmissionTextBlocks)
            Case "PVAttachments"
                Dim ctlSubmissionAttachments As SubmissionAttachments = LoadControl(ScreenController.Screen_GetName(Admin_SubmissionAttachment))
                With ctlSubmissionAttachments
                    .AbstractSubmissionId = GetAbsSubId()
                    Dim oSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = CallManager.GetAbstractSubmission(PortalId, .AbstractSubmissionId)
                    Dim AdditionalPathExtension As String = String.Concat(oSubmissions(0).AbstractCallCode, "\", oSubmissions(0).SubmissionTypeCode, "\", GetAbsSubId)
                    .AdditionalPathExtension = AdditionalPathExtension
                    .IsEdit = False
                    .PortalId = PortalId
                    .ID = String.Concat(e.PageView.ID, "_TabContent")
                End With
                e.PageView.Controls.Add(ctlSubmissionAttachments)
            Case "PVReviews"
                ControlName = ScreenController.Screen_GetName(Admin_SubmissionReviews)
            Case "PVHistory"
                ControlName = ScreenController.Screen_GetName(Admin_SubmissionHistory)
        End Select

        If ControlName IsNot Nothing Then
            Dim ABSPage As AbstractScreenBase = LoadControl(ControlName)
            ABSPage.ID = String.Concat(e.PageView.ID, "_TabContent")
            e.PageView.Controls.Add(ABSPage)
            If _newPageFlag Then
                ABSPage.SetupUpdateView()
            End If
        End If

    End Sub

#End Region

#Region "Helper functions"
    Public Function GetEditSubmissionPageURL(ByVal screenId As ScreenController.AbstractScreen, ByVal args As String, ByVal action As String, Optional ByVal type As String = Nothing, Optional ByVal sids As String = Nothing) As String

        Dim strURLBuilder As New System.Text.StringBuilder
        strURLBuilder.Append("s=")
        strURLBuilder.Append(screenId)
        If Not String.IsNullOrEmpty(action) Then
            strURLBuilder.Append("&action=")
            strURLBuilder.Append(action)
        End If
        If Not String.IsNullOrEmpty(args) Then
            strURLBuilder.Append("&args=")
            strURLBuilder.Append(args)
        End If
        If type IsNot Nothing AndAlso Not String.IsNullOrEmpty(type) Then
            strURLBuilder.Append("&type=")
            strURLBuilder.Append(type)
        End If
        If sids IsNot Nothing AndAlso Not String.IsNullOrEmpty(sids) Then
            strURLBuilder.Append("&sid=")
            strURLBuilder.Append(sids)
        End If
        strURLBuilder.Append("&mode=Y")
        Return NavigateURL("", strURLBuilder.ToString)
    End Function

    Private Sub SetAssignProductIfExist(ByVal oSubmissionProductLinks As TIMSS.API.AbstractInfo.IAbstractSubmissionProductLinks)
        If oSubmissionProductLinks IsNot Nothing Then
            For Each oSubmissionLink As TIMSS.API.AbstractInfo.IAbstractSubmissionProductLink In oSubmissionProductLinks
                If String.IsNullOrEmpty(lblAssignedProducts.Text) Then
                    Me.lblAssignedProducts.Text = String.Concat(oSubmissionLink.ProductInfo.ShortName, " - ", oSubmissionLink.ProductInfo.MeetingProduct.StartDate)
                Else
                    Me.lblAssignedProducts.Text = String.Concat(lblAssignedProducts.Text, "<br>", oSubmissionLink.ProductInfo.ShortName, " - ", oSubmissionLink.ProductInfo.MeetingProduct.StartDate)
                End If
            Next
        End If

        If String.IsNullOrEmpty(lblAssignedProducts.Text) Then
            pnlAssignedProducts.Visible = False
        End If
    End Sub

    Private Function AddPageView(ByVal pageViewID As String) As String
        Dim pageView As New RadPageView()
        pageView.ID = pageViewID
        _newPageFlag = True
        Me.radMultiTabContent.PageViews.Add(pageView)
        radMultiTabContent.SelectedIndex = radMultiTabContent.PageViews.Count - 1
        Return pageViewID
    End Function

    Private Sub AssignActions(ByVal Action As String)

        Dim SubmissionIds(0) As Integer
        SubmissionIds(0) = CType(GetAbsSubId(), Integer)


        Dim MyGuid As Guid = Guid.NewGuid()
        Session(MyGuid.ToString) = SubmissionIds

        Select Case Action
            Case Constants.Const_AssignToSession
                Response.Redirect(NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Assign_Submission_to_Product, String), _
                        "&sids=", MyGuid.ToString, "&args=", CallCode)))
            Case Constants.Const_AssignToReviewer
                GoToNextPage(ScreenController.AbstractScreen.Assign_Submission_to_Reviewers, CallCode, "", SubmissionTypeCode, MyGuid.ToString)
        End Select
    End Sub

    Private Sub SetupControls()
        Dim oSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission = CallManager.GetSubmission(PortalId, CType(GetAbsSubId(), Integer))
        With oSubmission
            CallCode = oSubmission.AbstractCallCode
            SubmissionTypeCode = oSubmission.SubmissionTypeCode
            lblSubmissionIDValue.Text = .AbstractSubmissionId
            'lblTitleValue.Text = .Title
            lblSubmissionTitle.Text = .Title
            lblAbsCallValue.Text = .AbstractCallCode
            lblCompletedValue.Text = .NumberOfCompletedReviews
            lblRequiredReviewsValue.Text = .MinNumberOfRequiredReviewers
            lblSubmittedOnValue.Text = .SubmissionDate.ToString
            lblCategoryValue.Text = .CategoryCode.Description
            lblLengthInMinutesValue.Text = .LengthInMinutes

            If .RequiresStaffActionFlag = True Then
                lblActionNeeded.Visible = True
            Else
                lblActionNeeded.Visible = False
            End If
            For Each Author As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In .AbstractSubmissionAuthors
                If Author.CorrespondingAuthorFlag Then
                    lblCorrespondingAuthorValue.Text = String.Concat(Author.FirstName, " ", Author.LastName)
                End If
                If Author.PrimaryAuthorFlag Then
                    lblPrimaryAuthorValue.Text = String.Concat(Author.FirstName, " ", Author.LastName)
                End If
                If Author.PresentingAuthorFlag Then
                    lblPresentingAuthorValue.Text = String.Concat(Author.FirstName, " ", Author.LastName)
                End If
            Next

            lblPrimaryTopicValue.Text = .PrimaryTopicCode

            lblTopics.Text = String.Empty
            For Each Topic As TIMSS.API.AbstractInfo.IAbstractSubmissionTopic In .AbstractSubmissionTopics
                If Not Topic.PrimaryTopicFlag Then
                    If String.IsNullOrEmpty(lblTopics.Text) Then
                        lblTopics.Text = Topic.TopicCode.Description
                    Else
                        lblTopics.Text = String.Concat(lblTopics.Text, "<br>", Topic.TopicCode.Description)
                    End If
                End If
            Next

            lblKeywords.Text = String.Empty
            For Each Keyword As TIMSS.API.AbstractInfo.IAbstractSubmissionKeyword In .AbstractSubmissionKeywords
                If String.IsNullOrEmpty(lblKeywords.Text) Then
                    lblKeywords.Text = Keyword.KeywordCode.Description
                Else
                    lblKeywords.Text = String.Concat(lblKeywords.Text, "<br>", Keyword.KeywordCode.Description)
                End If
            Next


            lblOpenInvitationsValue.Text = .NumberOfInvitedReviewers
            lblUnderReviewValue.Text = .NumberOfAcceptedReviewers

            lblInternalStatusValue.Text = .InternalStatusCode.Description
            lblExternalStatusValue.Text = .ExternalStatusCode.Description

            If .ExternalStatusCode.Code = "ACCEPTED" Then
                btnAssignToSession.Enabled = True
            Else
                btnAssignToSession.Enabled = False
            End If

            If .InternalStatusCodeString = Constants.Const_InternalStatus_Final_Decision Then
                Me.btnAssignReviewers.Enabled = False
            Else
                Me.btnAssignReviewers.Enabled = True
            End If


            HideActionButtonsByDefault()
            If .AbstractCallSubmissionTypeInfo.StaffReviewStageFlag AndAlso .InternalStatusCodeString = "NEED_STAFF_REVIEW" Then
                'Staff view stage
                butStaffReviewAccept.Visible = True
                butStaffReviewDecline.Visible = True
            ElseIf .NumberOfCompletedReviews < .MinNumberOfRequiredReviewers Then
                'Does not meet the minimum reviewer requirement 
                If oSubmission.AbstractCallSubmissionTypeInfo.FinalistStageFlag Then
                    butAddFinalist.Visible = True
                Else
                    btnAccept.Visible = True
                End If
                btnDecline.Visible = True
            ElseIf oSubmission.AbstractCallSubmissionTypeInfo.FinalistStageFlag AndAlso Not oSubmission.FinalistFlag Then
                'Finalist stage and has not been accepted & meet the review requirement
                butAddFinalist.Visible = True
                btnDecline.Visible = True
            Else
                'fulfill all other conditions - staff can either accept or decline                
                btnAccept.Visible = True
                btnAccept.Enabled = True
                btnDecline.Visible = True
            End If

            SetAssignProductIfExist(.AbstractSubmissionProductLinks)
        End With


        If Request.UrlReferrer IsNot Nothing Then
            Me.PreviousURL = Request.UrlReferrer.AbsoluteUri
        Else
            Me.butPreviousPage.Visible = False
        End If


    End Sub

    Private Sub HideActionButtonsByDefault()
        butAddFinalist.Visible = False
        btnAccept.Visible = False
        btnDecline.Visible = False
        butStaffReviewAccept.Visible = False
        butStaffReviewDecline.Visible = False
    End Sub

#End Region

#Region "Public Function"

#End Region



End Class
