Imports System.Collections.Generic
Imports Microsoft.VisualBasic
Imports System.ComponentModel

Public Class WEB_SUBMISSION

    Private _AbstractCallCode As String
    Private _SubmissionTypeCode As String
    Private _AbstractSubmissionId As Integer
    Private _Title As String
    Private _AbstractSubmissionAuthors As String
    Private _RequiresStaffActionFlag As Boolean
    Private _InternalStatusCodeString As String
    Private _SubmissionDetailURL As String

    Public IsChange_AbstractCallCode As String
    Public IsChange_SubmissionTypeCode As String
    Public IsChange_AbstractSubmissionId As Integer
    Public IsChange_Title As String
    Public IsChange_AbstractSubmissionAuthors As String
    Public IsChange_RequiresStaffActionFlag As Boolean
    Public IsChange_InternalStatusCodeString As String

    Public Sub New(ByVal Submission As DataRow)
        With Submission
            _AbstractCallCode = .Item("AbstractCallCode").ToString
            _SubmissionTypeCode = .Item("AbstractCallSubmissionTypeInfo.SubmissionTypeCode").ToString
            _AbstractSubmissionId = CType(.Item("AbstractSubmissionId").ToString, Integer)
            _Title = .Item("Title").ToString
            _AbstractSubmissionAuthors = ConcatAuthorNames(.Item("AbstractSubmissionAuthors.FirstName").ToString, .Item("AbstractSubmissionAuthors.LastName").ToString)
            _RequiresStaffActionFlag = IIf(.Item("RequiresStaffActionFlag").ToString = "Y", True, False)
            _InternalStatusCodeString = .Item("InternalStatusCode").ToString
            _SubmissionDetailURL = NavigateURL("", String.Concat("s=", CType(ScreenController.AbstractScreen.Admin_SubmissionDetails, String), "&AbsSubId=", .Item("AbstractSubmissionId").ToString))
        End With
    End Sub

#Region "Functions / Methods"

    Public Function ConcatAuthorNames(ByVal AuthorFirstName As String, ByVal AuthorLastName As String) As String
        Dim AuthorNames As String = Nothing

        AuthorNames = String.Concat(AuthorNames, authorfirstname, " ", AuthorLastName)

        Return AuthorNames
    End Function

#End Region

#Region "Properties"
    Public Property AbstractCallCode() As String
        Get
            Return _AbstractCallCode
        End Get
        Set(ByVal value As String)
            _AbstractCallCode = value
            IsChange_AbstractCallCode = True
        End Set
    End Property

    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
            IsChange_SubmissionTypeCode = True
        End Set
    End Property
    Public Property AbstractSubmissionId() As Integer
        Get
            Return _AbstractSubmissionId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionId = value
            IsChange_AbstractSubmissionId = True
        End Set
    End Property
    Public Property Title() As String
        Get
            Return _Title
        End Get
        Set(ByVal value As String)
            _Title = value
            IsChange_Title = True
        End Set
    End Property
    Public Property AbstractSubmissionAuthors() As String
        Get
            Return _AbstractSubmissionAuthors
        End Get
        Set(ByVal value As String)
            _AbstractSubmissionAuthors = value
            IsChange_AbstractSubmissionAuthors = True
        End Set
    End Property

    Public Property RequiresStaffActionFlag() As Boolean
        Get
            Return _RequiresStaffActionFlag
        End Get
        Set(ByVal value As Boolean)
            _RequiresStaffActionFlag = value
            IsChange_RequiresStaffActionFlag = True
        End Set
    End Property
    Public Property InternalStatusCodeString() As String
        Get
            Return _InternalStatusCodeString
        End Get
        Set(ByVal value As String)
            _InternalStatusCodeString = value
            IsChange_InternalStatusCodeString = True
        End Set
    End Property

    Public Property SubmissionDetailURL() As String
        Get
            Return _SubmissionDetailURL
        End Get
        Set(ByVal value As String)
            _SubmissionDetailURL = value
        End Set
    End Property

#End Region


End Class


Public Class WEB_AUTHORDISCLOSUREQUESTION
    Private _AuthorDisclosureQuestionText As String
    Private _DisclosureRelationshipCodeString As String
    Private _RelatedCustomerName As String

    Public Property AuthorDisclosureQuestionText() As String
        Get
            Return _AuthorDisclosureQuestionText
        End Get
        Set(ByVal value As String)
            _AuthorDisclosureQuestionText = value
        End Set
    End Property

    Public Property DisclosureRelationshipCodeString() As String
        Get
            Return _DisclosureRelationshipCodeString
        End Get
        Set(ByVal value As String)
            _DisclosureRelationshipCodeString = value
        End Set
    End Property

    Public Property RelatedCustomerName() As String
        Get
            Return _RelatedCustomerName
        End Get
        Set(ByVal value As String)
            _RelatedCustomerName = value
        End Set
    End Property
End Class

Public Class WEB_SUBMISSIONAUTHOR
    Private _AbstractSubmissionAuthorId As Integer
    Private _LastFirstName As String
    Private _CompanyInstitutionName As String
    Private _AuthorRoleCodeString As String
    Private _IsCustomer As Boolean

    Public Property AbstractSubmissionAuthorId() As Integer
        Get
            Return _AbstractSubmissionAuthorId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionAuthorId = value
        End Set
    End Property

    Public Property LastFirstName() As String
        Get
            Return _LastFirstName
        End Get
        Set(ByVal value As String)
            _LastFirstName = value
        End Set
    End Property

    Public Property CompanyInstitutionName() As String
        Get
            Return _CompanyInstitutionName
        End Get
        Set(ByVal value As String)
            _CompanyInstitutionName = value
        End Set
    End Property

    Public Property AuthorRoleCodeString() As String
        Get
            Return _AuthorRoleCodeString
        End Get
        Set(ByVal value As String)
            _AuthorRoleCodeString = value
        End Set
    End Property

    Public Property IsCustomer() As Boolean
        Get
            Return _IsCustomer
        End Get
        Set(ByVal value As Boolean)
            _IsCustomer = value
        End Set
    End Property

End Class

Public Class WEB_ACTIVITY
    Private _AbstractSubmissionActivityId As Integer
    Private _ReviewProcessEventCodeString As String
    Private _ReviewProcessEventDate As String
    Private _ReviewerName As String
    Private _PreviousExternalStatusCodeString As String
    Private _NewExternalStatusCodeString As String
    Private _PreviousInternalStatusCodeString As String
    Private _NewInternalStatusCodeString As String
    Private _NewAssignmentStatusCodeString As String
    Private _SubmissionTitle As String

    Public Property AbstractSubmissionActivityId() As Integer
        Get
            Return _AbstractSubmissionActivityId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionActivityId = value
        End Set
    End Property

    Public Property ReviewProcessEventCodeString() As String
        Get
            Return _ReviewProcessEventCodeString
        End Get
        Set(ByVal value As String)
            _ReviewProcessEventCodeString = value
        End Set
    End Property

    Public Property ReviewProcessEventDate() As String
        Get
            Return _ReviewProcessEventDate
        End Get
        Set(ByVal value As String)
            _ReviewProcessEventDate = value
        End Set
    End Property

    Public Property ReviewerName() As String
        Get
            Return _ReviewerName
        End Get
        Set(ByVal value As String)
            _ReviewerName = value
        End Set
    End Property

    Public Property PreviousExternalStatusCodeString() As String
        Get
            Return _PreviousExternalStatusCodeString
        End Get
        Set(ByVal value As String)
            _PreviousExternalStatusCodeString = value
        End Set
    End Property

    Public Property NewExternalStatusCodeString() As String
        Get
            Return _NewExternalStatusCodeString
        End Get
        Set(ByVal value As String)
            _NewExternalStatusCodeString = value
        End Set
    End Property

    Public Property PreviousInternalStatusCodeString() As String
        Get
            Return _PreviousInternalStatusCodeString
        End Get
        Set(ByVal value As String)
            _PreviousInternalStatusCodeString = value
        End Set
    End Property

    Public Property NewInternalStatusCodeString() As String
        Get
            Return _NewInternalStatusCodeString
        End Get
        Set(ByVal value As String)
            _NewInternalStatusCodeString = value
        End Set
    End Property

    Public Property NewAssignmentStatusCodeString() As String
        Get
            Return _NewAssignmentStatusCodeString
        End Get
        Set(ByVal value As String)
            _NewAssignmentStatusCodeString = value
        End Set
    End Property

    Public Property SubmissionTitle() As String
        Get
            Return _SubmissionTitle
        End Get
        Set(ByVal value As String)
            _SubmissionTitle = value
        End Set
    End Property
End Class

Public Class WEB_SUBMISSIONREVIEWER
    Private _AbstractSubmissionReviewerId As Integer
    Private _LastFirstName As String
    Private _AssignmentStatusCodeDescription As String
    Private _ReviewDueDate As String
    Private _InstitutionListString As String
    Private _EducationListString As String
    Private _CommentsToReviewer As String
    Private _LinkToReview As String

    Public Property AbstractSubmissionReviewerId() As Integer
        Get
            Return _AbstractSubmissionReviewerId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionReviewerId = value
        End Set
    End Property

    Public Property LastFirstName() As String
        Get
            Return _LastFirstName
        End Get
        Set(ByVal value As String)
            _LastFirstName = value
        End Set
    End Property

    Public Property AssignmentStatusCodeDescription() As String
        Get
            Return _AssignmentStatusCodeDescription
        End Get
        Set(ByVal value As String)
            _AssignmentStatusCodeDescription = value
        End Set
    End Property

    Public Property ReviewDueDate() As String
        Get
            Return _ReviewDueDate
        End Get
        Set(ByVal value As String)
            _ReviewDueDate = value
        End Set
    End Property

    Public Property InstitutionListString() As String
        Get
            Return _InstitutionListString
        End Get
        Set(ByVal value As String)
            _InstitutionListString = value
        End Set
    End Property

    Public Property EducationListString() As String
        Get
            Return _EducationListString
        End Get
        Set(ByVal value As String)
            _EducationListString = value
        End Set
    End Property

    Public Property CommentsToReviewer() As String
        Get
            Return _CommentsToReviewer
        End Get
        Set(ByVal value As String)
            _CommentsToReviewer = value
        End Set
    End Property

    Public Property LinkToReview() As String
        Get
            Return _LinkToReview
        End Get
        Set(ByVal value As String)
            _LinkToReview = value
        End Set
    End Property


End Class
