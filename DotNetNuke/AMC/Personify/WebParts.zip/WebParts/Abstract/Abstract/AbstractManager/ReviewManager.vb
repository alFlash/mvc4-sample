Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects


Imports Constants

Public Class ReviewManagerHelper
    Inherits BaseHelperClass


    Public Sub New(ByVal OrgId As String, ByVal OrgUnitId As String)
        MyBase.New(OrgId, OrgUnitId)
    End Sub

#Region "Submission  Reviewers"

#End Region

#Region "Submission Type  Reviewers"

    'Public Function ABS_SubmissionTypeReviewers_AssignmentStatus_Get(ByVal PortalId As Integer, ByVal CallCode As String, ByVal SubTypeCode As String, Optional ByVal SearchDueDateOption As String = "") As DataTable


    '    'Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
    '    'searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeReviewers")
    '    'searchObj.EnforceLimits = False
    '    ''TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer()


    '    ''need to find why out this parameter is added by default: product id
    '    ' ''searchObj.Parameters(0).UseInQuery = False
    '    ' ''searchObj.Parameters(0).ShowInResults = True

    '    'Dim oParm As TIMSS.API.Core.SearchProperty
    '    '' Dim t As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers
    '    ''Dim d As TIMSS.API.AbstractInfo.IAbstractSubmissions
    '    ''d(0).AbstractCallCode
    '    ''d(0).SubmissionTypeCode
    '    '' d(0).AbstractSubmissionReviewers(0).AbstractSubmissionReviewerId
    '    ''Dim x As TIMSS.API.AbstractInfo.IAbstractReviewer
    '    'Dim t As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers
    '    ''t(0).AbstractSubmissionReviewers(0).ReviewDueDate
    '    ''t
    '    '' searchObj.
    '    'oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
    '    'oParm.UseInQuery = True
    '    'oParm.ShowInResults = False
    '    'oParm.Value = CallCode
    '    'searchObj.Parameters.Add(oParm)

    '    'oParm = New TIMSS.API.Core.SearchProperty("SubmissionTypeCode")
    '    'oParm.UseInQuery = True
    '    'oParm.ShowInResults = False
    '    'oParm.Value = SubTypeCode
    '    'searchObj.Parameters.Add(oParm)

    '    ''oParm = New TIMSS.API.Core.SearchProperty("MasterProductFlag")
    '    ''oParm.UseInQuery = True
    '    ''oParm.ShowInResults = False
    '    ''oParm.Value = "Y"
    '    ''searchObj.Parameters.Add(oParm)

    '    'oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeReviewerId")
    '    'oParm.UseInQuery = False
    '    'oParm.ShowInResults = True
    '    'searchObj.Parameters.Add(oParm)

    '    'oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.AssignmentStatusCode")
    '    'oParm.UseInQuery = False
    '    'oParm.ShowInResults = True
    '    'searchObj.Parameters.Add(oParm)

    '    'oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.ReviewDueDate")
    '    'If String.IsNullOrEmpty(SearchDueDateOption) Then
    '    '    oParm.UseInQuery = False
    '    'Else
    '    '    oParm.UseInQuery = True
    '    '    Select Case SearchDueDateOption
    '    '        Case "ReviewLateDue"
    '    '            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.LessThan
    '    '            oParm.Value = DateTime.Today.Date
    '    '        Case "ReviewDueInTwoDays"
    '    '            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Between
    '    '            oParm.Value = String.Concat(DateTime.Today.Date, ", ", DateTime.Today.AddDays(2).Date)
    '    '    End Select
    '    'End If
    '    'oParm.ShowInResults = True
    '    'searchObj.Parameters.Add(oParm)



    '    'oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.LastFirstName")
    '    'oParm.UseInQuery = False
    '    'oParm.ShowInResults = True
    '    'searchObj.Parameters.Add(oParm)

    '    'searchObj.Search()

    '    'Return searchObj.Results.Table
    'End Function
    Public Function ABS_SubmissionTypeReviewers_AssignmentStatus_Get(ByVal PortalId As Integer, ByVal CallCode As String, ByVal SubTypeCode As String, Optional ByVal SearchDueDateOption As String = "") As DataTable

        Dim oRequestSet As New TIMSS.DataAccess.RequestSet
        Dim oSingleRequest As TIMSS.DataAccess.SimpleRequest

        'Build the SQL - Using the Negative Logic to Select the Rows
        Dim strSQLQuery As System.Text.StringBuilder
        strSQLQuery = New System.Text.StringBuilder
        strSQLQuery.Append("select last_first_name, r.ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID, ASSIGNMENT_STATUS_CODE,Count(*) as 'ReviewCount' from abs_Call_submission_type_reviewer r left outer join abs_submission_reviewer sr on sr.ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID = r.ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID, CUSTOMER c Where r.ABS_CALL_CODE='")
        strSQLQuery.Append(CallCode)
        strSQLQuery.Append("' and r.SUBMISSION_TYPE_CODE='")
        strSQLQuery.Append(SubTypeCode)
        strSQLQuery.Append("' and r.Master_customer_id = c.master_customer_id Group by last_first_name,ASSIGNMENT_STATUS_CODE,r.ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID")

        oSingleRequest = New TIMSS.DataAccess.SimpleRequest("Abstract Submission Type Reviewer", strSQLQuery.ToString)
        oRequestSet.Add(CType(oSingleRequest, TIMSS.Interfaces.IRequest))

        Return TIMSS.Global.GetDataSet(oRequestSet).Tables(0)
    End Function

    Public Function ABS_SubmissionTypeReviewers_Expertise_Get(ByVal PortalId As Integer, ByVal CallCode As String, ByVal SubTypeCode As String) As DataTable



        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeReviewers")
        searchObj.EnforceLimits = False


        Dim oParm As TIMSS.API.Core.SearchProperty

        Dim t As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers
        't(0).AbstractSubmissionReviewers(0).ReviewDueDate
        't(0).AbstractReviewerInfo.AbstractReviewerExpertiseList(0).ExpertiseCode.Description
        't(0).AbstractReviewerInfo.AbstractReviewerExpertiseList(0).ExpertiseLevelCode.Description
        ' searchObj.
        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = CallCode
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubmissionTypeCode")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubTypeCode
        searchObj.Parameters.Add(oParm)


        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeReviewerId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractReviewerInfo.AbstractReviewerExpertiseList.ExpertiseCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)


        oParm = New TIMSS.API.Core.SearchProperty("AbstractReviewerInfo.AbstractReviewerExpertiseList.ExpertiseLevelCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)


        searchObj.Search()

        Return searchObj.Results.Table

    End Function

    Public Function ABS_SubmissionTypeReviewers_Instutiution_Get(ByVal PortalId As Integer, ByVal CallCode As String, ByVal SubTypeCode As String) As DataTable



        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeReviewers")
        searchObj.EnforceLimits = False

        Dim oParm As TIMSS.API.Core.SearchProperty
        'Dim t As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = CallCode
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubmissionTypeCode")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = SubTypeCode
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallSubmissionTypeReviewerId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)


        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.Relationships.RelationshipType")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = Constants.Const_RelationshipType_Employment
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.Relationships.RelatedName")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        Return searchObj.Results.Table

    End Function

    Public Function ABS_SubmissionTypeReviewers_Get(ByVal PortalId As Integer, ByVal CallCode As String, ByVal SubTypeCode As String, Optional ByVal SearchDueDateOption As String = "") As DataTable

        Dim dt_MasterTable As DataTable
        Dim dt_AssignmentStatus As DataTable
        Dim dt_Expertise As DataTable
        Dim dt_Instutitution As DataTable
        Dim relationshipHash As Hashtable

        'ABS_SubmissionTypeReviewers_Expertise_Get()

        dt_AssignmentStatus = ABS_SubmissionTypeReviewers_AssignmentStatus_Get(PortalId, CallCode, SubTypeCode, SearchDueDateOption)
        dt_Instutitution = ABS_SubmissionTypeReviewers_Instutiution_Get(PortalId, CallCode, SubTypeCode)

        If dt_AssignmentStatus.Rows.Count = 0 Then
            Return Nothing
        End If

        dt_MasterTable = CreateSubmissionTypeReviewerTable(dt_AssignmentStatus)
        relationshipHash = CreateSubmissionTypeReviewersInstutiution_Hash(dt_Instutitution)

        For Each row As DataRow In dt_MasterTable.Rows
            Dim reviewerId As String = row("AbstractCallSubmissionTypeReviewerId")
            If relationshipHash.Contains(reviewerId) Then
                row("RelatedName") = relationshipHash(reviewerId)
            End If
        Next




        Return dt_MasterTable
    End Function
#End Region

#Region "Private functions"


    Private Function CreateSubmissionTypeReviewerTable(ByVal sourceTable As DataTable) As DataTable

        Dim dt As New DataTable
        Dim existingRowHash As New Hashtable

        dt.Columns.Add("AbstractCallSubmissionTypeReviewerId", GetType(System.String))
        'dt.Columns.Add("ASSIGNMENT_STATUS_CODE", Type.GetType(System.String))
        dt.Columns.Add("LastFirstName", GetType(System.String))
        'dt.Columns.Add("ReviewDueDate", GetType(System.String))
        dt.Columns.Add("Expertise", GetType(System.String))
        dt.Columns.Add("RelatedName", GetType(System.String))
        dt.Columns.Add("CurrentReviews", GetType(System.Int32))
        dt.Columns.Add("CompletedReviews", GetType(System.Int32))
        dt.Columns.Add("TotalReviews", GetType(System.Int32))

        For Each row As DataRow In sourceTable.Rows
            Dim dr As DataRow
            If Not (row("ASSIGNMENT_STATUS_CODE").Equals(System.DBNull.Value)) Then
                If Not existingRowHash.Contains(row("ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID")) Then
                    dr = dt.NewRow
                    dr("AbstractCallSubmissionTypeReviewerId") = row("ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID")
                    dr("LastFirstName") = row("last_first_name")
                    dr("CurrentReviews") = IIf(GetReviewsCount(row("ASSIGNMENT_STATUS_CODE"), True) = 1, row("ReviewCount"), 0)
                    dr("CompletedReviews") = IIf(GetReviewsCount(row("ASSIGNMENT_STATUS_CODE"), False) = 1, row("ReviewCount"), 0)
                    dr("TotalReviews") = dr("CurrentReviews") + dr("CompletedReviews")

                    dt.Rows.Add(dr)
                    existingRowHash.Add(row("ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID"), dr)
                Else
                    dr = existingRowHash(row("ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID"))

                    dr("CurrentReviews") = dr("CurrentReviews") + IIf(GetReviewsCount(row("ASSIGNMENT_STATUS_CODE"), True) = 1, row("ReviewCount"), 0)
                    dr("CompletedReviews") = dr("CompletedReviews") + IIf(GetReviewsCount(row("ASSIGNMENT_STATUS_CODE"), False) = 1, row("ReviewCount"), 0)
                    dr("TotalReviews") = dr("CurrentReviews") + dr("CompletedReviews")
                End If
            Else
                dr = dt.NewRow
                dr("AbstractCallSubmissionTypeReviewerId") = row("ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID")
                dr("LastFirstName") = row("last_first_name")
                'dr("ReviewDueDate") = row("AbstractSubmissionReviewers.ReviewDueDate")
                dr("CurrentReviews") = 0
                dr("CompletedReviews") = 0
                dr("TotalReviews") = 0
                dt.Rows.Add(dr)
                existingRowHash.Add(row("ABS_CALL_SUBMISSION_TYPE_REVIEWER_ID"), dr)
            End If
        Next

        Return dt

    End Function

    Private Function CreateSubmissionTypeReviewersInstutiution_Hash(ByVal source As DataTable) As Hashtable
        Dim sourceHash As New Hashtable
        For Each row As DataRow In source.Rows
            Dim reviewerId As String = row("AbstractCallSubmissionTypeReviewerId")
            Dim relatedName As String = row("CustomerInfo.Relationships.RelatedName")
            If Not sourceHash.Contains(reviewerId) Then
                sourceHash.Add(reviewerId, relatedName)
            Else
                sourceHash(reviewerId) = String.Concat(String.Concat(sourceHash(reviewerId), ", "), relatedName)
            End If
        Next
        Return sourceHash
    End Function

    Private Function GetReviewsCount(ByVal statusCode As String, ByVal isCurrent As Boolean) As Integer

        Select Case statusCode
            Case Const_AssignmentStatus_Invited
                If isCurrent Then Return 1 Else Return 0
            Case Const_AssignmentStatus_UnderReview
                If isCurrent Then Return 1 Else Return 0
            Case Const_AssignmentStatus_Completed
                If isCurrent Then Return 0 Else Return 1
            Case Const_AssignmentStatus_Declined
                If isCurrent Then Return 0 Else Return 1
            Case Const_AssignmentStatus_Withdraw
                If isCurrent Then Return 0 Else Return 1
            Case Const_AssignmentStatus_Cancelled
                If isCurrent Then Return 0 Else Return 1
            Case Const_AssignmentStatus_ReturnReview
                If isCurrent Then Return 1 Else Return 0
        End Select
    End Function

#End Region

End Class
