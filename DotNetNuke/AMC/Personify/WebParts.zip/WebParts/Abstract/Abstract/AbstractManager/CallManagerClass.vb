Imports System.Collections.Generic
Imports Microsoft.VisualBasic
Imports System.ComponentModel

Public Class WEB_SUBMISSIONTYPE

    Private _Call_Code As String
    Private _SubmissionTypeCode As String
    Private _Description As String
    Private _SubmissionWebStartDate As DateTime
    Private _SubmissionWebEndDate As DateTime
    Private _SubmissionStartDate As DateTime
    Private _SubmissionEndDate As DateTime
    Private _ReviewEndDate As DateTime
    Private _AnnouncementDate As DateTime
    Private _ValidateTopicControlCode As String
    Private _ValidateKeywordControlCode As String
    Private _ValidationTopicCode As String
    Private _ValidationKeywordCode As String

    Private _AllowWebAttachmentFlag As Boolean
    Private _MinAttachments As Integer
    Private _MaxAttachments As Integer
    Private _MaxFileSizeMB As Integer
    Private _DefaultDaysToReview As Integer
    Private _DefaultMaxReviewerAssignments As Integer
    Private _DefaultMaxReviewerOpenAssignments As Integer
    Private _DefaultMinReqReviewersPerSubmission As Integer
    Private _MaxSubmissions As Integer
    Private _MaxFinalistSubmissions As Integer
    Private _MaxAcceptedSubmissions As Integer
    Private _DefaultMaxSubmissionsPerAuthor As Integer
    Private _DefaultMaxAcceptedSubmissionsPerAuthor As Integer
    
    Private _PrimaryAuthorMustBeMemberFlag As Boolean
    Private _AllowViewingByAllAuthorsFlag As Boolean
    Private _AuthorValidationStoredProcedure As String    
    Private _ReviewTypeCode As String
    Private _ReviewBlindRuleCode As String
    Private _FinalistStageFlag As Boolean
    Private _StaffReviewStageFlag As Boolean

    Private _ABSScoringControl As List(Of WEB_SUBMISSIONSCORING)
    Private _ABSInstructions As List(Of WEB_ABS_INSTRUCTION)
    Private _ABSTextBlock As List(Of WEB_SUBMISSIONTEXTBLOCK)    
    Private _ABSCallTopics As List(Of WEB_ABS_CODE_ITEM)
    Private _ABSCallKeywords As List(Of WEB_ABS_CODE_ITEM)
    Private _ABSFileTypes As List(Of WEB_ABS_CODE_ITEM)
    Private _ReviewerApprovedForCode As String

    Public IsChange_Call_Code As Boolean
    Public IsChange_SubmissionTypeCode As Boolean
    Public IsChange_Description As Boolean
    Public IsChange_SubmissionWebStartDate As Boolean
    Public IsChange_SubmissionWebEndDate As Boolean
    Public IsChange_SubmissionStartDate As Boolean
    Public IsChange_SubmissionEndDate As Boolean
    Public IsChange_ReviewEndDate As Boolean
    Public IsChange_AnnouncementDate As Boolean
    Public IsChange_ValidateTopicControlCode As Boolean
    Public IsChange_ValidateKeywordControlCode As Boolean
    Public IsChange_AllowWebAttachmentFlag As Boolean
    Public IsChange_MinAttachments As Boolean
    Public IsChange_MaxAttachments As Boolean
    Public IsChange_MaxFileSizeMB As Boolean
    Public IsChange_DefaultDaysToReview As Boolean
    Public IsChange_DefaultMaxReviewerAssignments As Boolean
    Public IsChange_DefaultMaxReviewerOpenAssignments As Boolean
    Public IsChange_DefaultMinReqReviewersPerSubmission As Boolean
    Public IsChange_MaxSubmissions As Boolean
    Public IsChange_MaxFinalistSubmissions As Boolean
    Public IsChange_MaxAcceptedSubmissions As Boolean
    Public IsChange_DefaultMaxSubmissionsPerAuthor As Boolean
    Public IsChange_DefaultMaxAcceptedSubmissionsPerAuthor As Boolean
    Public IsChange_PrimaryAuthorMustBeMemberFlag As Boolean
    Public IsChange_AllowViewingByAllAuthorsFlag As Boolean
    Public IsChange_AuthorValidationStoredProcedure As Boolean
    Public IsChange_ReviewTypeCode As Boolean
    Public IsChange_ReviewBlindRuleCode As Boolean
    Public IsChange_ABSFileTypes As Boolean
    Public IsChange_FinalistStageFlag As Boolean
    Public IsChange_StaffReviewStageFlag As Boolean
    Public IsChange_ValidationTopicCode As Boolean
    Public IsChange_ValidationKeywordCode As Boolean
    Public IsChange_ReviewerApprovedForCode As Boolean

    Public Sub New()
        _ABSInstructions = New List(Of WEB_ABS_INSTRUCTION)
        _ABSTextBlock = New List(Of WEB_SUBMISSIONTEXTBLOCK)
        _ABSCallTopics = New List(Of WEB_ABS_CODE_ITEM)
        _ABSCallKeywords = New List(Of WEB_ABS_CODE_ITEM)
        _ABSFileTypes = New List(Of WEB_ABS_CODE_ITEM)
    End Sub

#Region "Functions / Methods"

    ' ''START Text Block
    ''Public Sub Add_ABSTextBlock(ByVal item As WEB_SUBMISSIONTEXTBLOCK)
    ''    _ABSTextBlock.Add(item)
    ''End Sub

    ''Public Sub Add_ABSTextBlock(ByVal blockTypeCode As String, ByVal seq As Integer, ByVal heading As String, ByVal visibilityCode As Boolean, ByVal maxWordCount As Integer, ByVal text As String)
    ''    Dim item As New WEB_SUBMISSIONTEXTBLOCK
    ''    item.BlockType = blockTypeCode
    ''    item.BlockSeq = seq
    ''    item.Heading = heading
    ''    item.MaxWordCount = maxWordCount
    ''    item.VisiblityCode = visibilityCode
    ''    item.InstructionText = text
    ''    Add_ABSTextBlock(item)
    ''End Sub

    ''Public Sub Remove_ABSTextBlock(ByVal item As WEB_SUBMISSIONTEXTBLOCK)
    ''    _ABSTextBlock.Remove(item)
    ''End Sub

    ''Public Function Get_ABSTextBlocks() As List(Of WEB_SUBMISSIONTEXTBLOCK)
    ''    Return _ABSTextBlock
    ''End Function
    ' ''END Text Block

#Region "Instruction"
    Public Sub Add_ABSInstruction(ByVal item As WEB_ABS_INSTRUCTION)
        _ABSInstructions.Add(item)
    End Sub

    Public Sub ABSInstruction_Get(ByVal instructionType As String, ByVal language As String, ByVal instructionText As String)
        Dim item As New WEB_ABS_INSTRUCTION
        item.Instruction_Type_Code = instructionType
        item.Language = language
        item.Instruction_Text = instructionText
        Add_ABSInstruction(item)
    End Sub

    Public Sub Remove_ABSInstruction(ByVal item As WEB_ABS_INSTRUCTION)
        _ABSInstructions.Remove(item)
    End Sub

    Public Function ABSInstructions_Get() As List(Of WEB_ABS_INSTRUCTION)
        Return _ABSInstructions
    End Function
#End Region
   
#Region "Call Topic"    
    Public Sub ABSCallTopic_Add(ByVal item As WEB_ABS_CODE_ITEM)
        _ABSCallTopics.Add(item)
    End Sub

    Public Sub ABSCallTopic_Add(ByVal strTopicCode As String, ByVal blnSelected As Boolean)
        Dim item As New WEB_ABS_CODE_ITEM
        item.Code = strTopicCode
        item.Selected = blnSelected
        _ABSCallTopics.Add(item)
    End Sub

    Public Function ABSCallTopics_Get() As List(Of WEB_ABS_CODE_ITEM)
        Return _ABSCallTopics
    End Function
#End Region

#Region "Call Keywords"

    Public Sub ABSCallKeyword_Add(ByVal item As WEB_ABS_CODE_ITEM)
        _ABSCallKeywords.Add(item)
    End Sub

    Public Sub ABSCallKeyword_Add(ByVal strKeyword As String, ByVal blnSelected As Boolean)
        Dim item As New WEB_ABS_CODE_ITEM
        item.Code = strKeyword
        item.Selected = blnSelected
        _ABSCallKeywords.Add(item)
    End Sub

    Public Function ABSCallKeywords_Get() As List(Of WEB_ABS_CODE_ITEM)
        Return _ABSCallKeywords
    End Function

#End Region

#Region "File types"
    Public Sub ABSFileTypes_Add(ByVal item As WEB_ABS_CODE_ITEM)
        _ABSFileTypes.Add(item)
    End Sub

    Public Sub ABSFileTypes_Add(ByVal code As String, ByVal selected As Boolean)
        Dim item As New WEB_ABS_CODE_ITEM
        item.Code = code
        item.Selected = selected
        ABSFileTypes_Add(item)
    End Sub

    Public Sub ABSFileTypes_Remove(ByVal item As WEB_ABS_CODE_ITEM)
        _ABSFileTypes.Remove(item)
    End Sub

    Public Function ABSFileTypes_Get() As List(Of WEB_ABS_CODE_ITEM)
        Return _ABSFileTypes
    End Function

#End Region


#End Region

#Region "Properties"
    Public Property Call_Code() As String
        Get
            Return _Call_Code
        End Get
        Set(ByVal value As String)
            _Call_Code = value
            IsChange_Call_Code = True
        End Set
    End Property

    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
            IsChange_SubmissionTypeCode = True
        End Set
    End Property
    Public Property Description() As String
        Get
            Return _Description
        End Get
        Set(ByVal value As String)
            _Description = value
            IsChange_Description = True
        End Set
    End Property
    Public Property SubmissionWebStartDate() As DateTime
        Get
            Return _SubmissionWebStartDate
        End Get
        Set(ByVal value As DateTime)
            _SubmissionWebStartDate = value
            IsChange_SubmissionWebStartDate = True
        End Set
    End Property
    Public Property SubmissionWebEndDate() As DateTime
        Get
            Return _SubmissionWebEndDate
        End Get
        Set(ByVal value As DateTime)
            _SubmissionWebEndDate = value
            IsChange_SubmissionWebEndDate = True
        End Set
    End Property

    Public Property SubmissionStartDate() As DateTime
        Get
            Return _SubmissionStartDate
        End Get
        Set(ByVal value As DateTime)
            _SubmissionStartDate = value
            IsChange_SubmissionStartDate = True
        End Set
    End Property
    Public Property SubmissionEndDate() As DateTime
        Get
            Return _SubmissionEndDate
        End Get
        Set(ByVal value As DateTime)
            _SubmissionEndDate = value
            IsChange_SubmissionEndDate = True
        End Set
    End Property
    Public Property ReviewEndDate() As DateTime
        Get
            Return _ReviewEndDate
        End Get
        Set(ByVal value As DateTime)
            _ReviewEndDate = value
            IsChange_ReviewEndDate = True
        End Set
    End Property
    Public Property AnnouncementDate() As DateTime
        Get
            Return _AnnouncementDate
        End Get
        Set(ByVal value As DateTime)
            _AnnouncementDate = value
            IsChange_AnnouncementDate = True
        End Set
    End Property

    Public Property ValidateTopicControlCode() As String
        Get
            Return _ValidateTopicControlCode
        End Get
        Set(ByVal value As String)
            _ValidateTopicControlCode = value
            IsChange_ValidateTopicControlCode = True
        End Set
    End Property
    Public Property ValidateKeywordControlCode() As String
        Get
            Return _ValidateKeywordControlCode
        End Get
        Set(ByVal value As String)
            _ValidateKeywordControlCode = value
            IsChange_ValidateKeywordControlCode = True
        End Set
    End Property

    Public Property ValidationTopicCode() As String
        Get
            Return _ValidationTopicCode
        End Get
        Set(ByVal value As String)
            _ValidationTopicCode = value
            IsChange_ValidationTopicCode = True
        End Set
    End Property

    Public Property ValidationKeywordCode() As String
        Get
            Return _ValidationKeywordCode
        End Get
        Set(ByVal value As String)
            _ValidationKeywordCode = value
            IsChange_ValidationKeywordCode = True
        End Set
    End Property


    Public Property AllowWebAttachmentFlag() As Boolean
        Get
            Return _AllowWebAttachmentFlag
        End Get
        Set(ByVal value As Boolean)
            _AllowWebAttachmentFlag = value
            IsChange_AllowWebAttachmentFlag = True
        End Set
    End Property
    Public Property MinAttachments() As Integer
        Get
            Return _MinAttachments
        End Get
        Set(ByVal value As Integer)
            _MinAttachments = value
            IsChange_MinAttachments = True
        End Set
    End Property

    Public Property MaxAttachments() As Integer
        Get
            Return _MaxAttachments
        End Get
        Set(ByVal value As Integer)
            _MaxAttachments = value
            IsChange_MaxAttachments = True
        End Set
    End Property
    Public Property MaxFileSizeMB() As Integer
        Get
            Return _MaxFileSizeMB
        End Get
        Set(ByVal value As Integer)
            _MaxFileSizeMB = value
            IsChange_MaxFileSizeMB = True
        End Set
    End Property
    Public Property DefaultDaysToReview() As Integer
        Get
            Return _DefaultDaysToReview
        End Get
        Set(ByVal value As Integer)
            _DefaultDaysToReview = value
            IsChange_DefaultDaysToReview = True
        End Set
    End Property
    Public Property DefaultMaxReviewerAssignments() As Integer
        Get
            Return _DefaultMaxReviewerAssignments
        End Get
        Set(ByVal value As Integer)
            _DefaultMaxReviewerAssignments = value
            IsChange_DefaultMaxReviewerAssignments = True
        End Set
    End Property
    Public Property DefaultMaxReviewerOpenAssignments() As Integer
        Get
            Return _DefaultMaxReviewerOpenAssignments
        End Get
        Set(ByVal value As Integer)
            _DefaultMaxReviewerOpenAssignments = value
            IsChange_DefaultMaxReviewerOpenAssignments = True
        End Set
    End Property
    Public Property DefaultMinReqReviewersPerSubmission() As Integer
        Get
            Return _DefaultMinReqReviewersPerSubmission
        End Get
        Set(ByVal value As Integer)
            _DefaultMinReqReviewersPerSubmission = value
            IsChange_DefaultMinReqReviewersPerSubmission = True
        End Set
    End Property

    Public Property MaxSubmissions() As Integer
        Get
            Return _MaxSubmissions
        End Get
        Set(ByVal value As Integer)
            _MaxSubmissions = value
            IsChange_MaxSubmissions = True
        End Set
    End Property
    Public Property MaxFinalistSubmissions() As Integer
        Get
            Return _MaxFinalistSubmissions
        End Get
        Set(ByVal value As Integer)
            _MaxFinalistSubmissions = value
            IsChange_MaxFinalistSubmissions = True
        End Set
    End Property
    Public Property MaxAcceptedSubmissions() As Integer
        Get
            Return _MaxAcceptedSubmissions
        End Get
        Set(ByVal value As Integer)
            _MaxAcceptedSubmissions = value
            IsChange_MaxAcceptedSubmissions = True
        End Set
    End Property
    Public Property DefaultMaxSubmissionsPerAuthor() As Integer
        Get
            Return _DefaultMaxSubmissionsPerAuthor
        End Get
        Set(ByVal value As Integer)
            _DefaultMaxSubmissionsPerAuthor = value
            IsChange_DefaultMaxSubmissionsPerAuthor = True
        End Set
    End Property
    Public Property DefaultMaxAcceptedSubmissionsPerAuthor() As Integer
        Get
            Return _DefaultMaxAcceptedSubmissionsPerAuthor
        End Get
        Set(ByVal value As Integer)
            _DefaultMaxAcceptedSubmissionsPerAuthor = value
            IsChange_DefaultMaxAcceptedSubmissionsPerAuthor = True
        End Set
    End Property
    Public Property PrimaryAuthorMustBeMemberFlag() As Boolean
        Get
            Return _PrimaryAuthorMustBeMemberFlag
        End Get
        Set(ByVal value As Boolean)
            _PrimaryAuthorMustBeMemberFlag = value
            IsChange_PrimaryAuthorMustBeMemberFlag = True
        End Set
    End Property
    Public Property AllowViewingByAllAuthorsFlag() As Boolean
        Get
            Return _AllowViewingByAllAuthorsFlag
        End Get
        Set(ByVal value As Boolean)
            _AllowViewingByAllAuthorsFlag = value
            IsChange_AllowViewingByAllAuthorsFlag = True
        End Set
    End Property
    Public Property AuthorValidationStoredProcedure() As String
        Get
            Return _AuthorValidationStoredProcedure
        End Get
        Set(ByVal value As String)
            _AuthorValidationStoredProcedure = value
            IsChange_AuthorValidationStoredProcedure = True
        End Set
    End Property

    Public Property ReviewTypeCode() As String
        Get
            Return _ReviewTypeCode
        End Get
        Set(ByVal value As String)
            _ReviewTypeCode = value
            IsChange_ReviewTypeCode = True
        End Set
    End Property
    Public Property ReviewBlindRuleCode() As String
        Get
            Return _ReviewBlindRuleCode
        End Get
        Set(ByVal value As String)
            _ReviewBlindRuleCode = value
            IsChange_ReviewBlindRuleCode = True
        End Set
    End Property

    Public Property FinalistStageFlag() As Boolean
        Get
            Return _FinalistStageFlag
        End Get
        Set(ByVal value As Boolean)
            _FinalistStageFlag = value
            IsChange_FinalistStageFlag = True
        End Set
    End Property

    Public Property StaffReviewStageFlag() As Boolean
        Get
            Return _StaffReviewStageFlag
        End Get
        Set(ByVal value As Boolean)
            _StaffReviewStageFlag = value
            IsChange_StaffReviewStageFlag = True
        End Set
    End Property

    Public Property ReviewerApprovedForCode() As String
        Get
            Return _ReviewerApprovedForCode
        End Get
        Set(ByVal value As String)
            _ReviewerApprovedForCode = value
            IsChange_ReviewerApprovedForCode = True
        End Set
    End Property
#End Region


    Public Class WEB_ABS_INSTRUCTION

        Public Instruction_Type_Code As String
        Public Language As String
        Public Instruction_Text As String
        Public Instruction_Caption_Text As String
        Public Comments As String

    End Class

    Public Class WEB_ABS_CODE_ITEM
        Public Code As String
        Public Selected As Boolean
    End Class

End Class

Public Class WEB_SUBMISSIONDISCLOSUREQUESTION

    Private _AbstractCallSubmissionTypeDisclosureQuestionControlId As Integer
    Private _QuestionText As String
    Private _QuestionSequence As Integer
    Private _DisclosureQuestionCode As String
    Private _DisclosureAnswerCode As String
    Private _RejectionDisclosureAnswerSubcode As String
    Private _AnswerRequiredFlag As Boolean
    Private _CodedAnswerFlag As Boolean
    Private _AbstractCallCode As String
    Private _SubmissionTypeCode As String


    Public Property AbstractCallSubmissionTypeDisclosureQuestionControlId() As Integer
        Get
            Return _AbstractCallSubmissionTypeDisclosureQuestionControlId
        End Get
        Set(ByVal value As Integer)
            _AbstractCallSubmissionTypeDisclosureQuestionControlId = value
        End Set
    End Property
    Public Property QuestionText() As String
        Get
            Return _QuestionText
        End Get
        Set(ByVal value As String)
            _QuestionText = value
        End Set
    End Property
    Public Property QuestionSequence() As Integer
        Get
            Return _QuestionSequence
        End Get
        Set(ByVal value As Integer)
            _QuestionSequence = value
        End Set
    End Property
    Public Property DisclosureQuestionCode() As String
        Get
            Return _DisclosureQuestionCode
        End Get
        Set(ByVal value As String)
            _DisclosureQuestionCode = value
        End Set
    End Property
    Public Property DisclosureAnswerCode() As String
        Get
            Return _DisclosureAnswerCode
        End Get
        Set(ByVal value As String)
            _DisclosureAnswerCode = value
        End Set
    End Property
    Public Property RejectionDisclosureAnswerSubcode() As String
        Get
            Return _RejectionDisclosureAnswerSubcode
        End Get
        Set(ByVal value As String)
            _RejectionDisclosureAnswerSubcode = value
        End Set
    End Property
    Public Property AnswerRequiredFlag() As Boolean
        Get
            Return _AnswerRequiredFlag
        End Get
        Set(ByVal value As Boolean)
            _AnswerRequiredFlag = value
        End Set
    End Property
    Public Property CodedAnswerFlag() As Boolean
        Get
            Return _CodedAnswerFlag
        End Get
        Set(ByVal value As Boolean)
            _CodedAnswerFlag = value
        End Set
    End Property
    Public Property AbstractCallCode() As String
        Get
            Return _AbstractCallCode
        End Get
        Set(ByVal value As String)
            _AbstractCallCode = value

        End Set
    End Property
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property
End Class

Public Class WEB_SUBMISSIONTEXTBLOCK

    Private _BlockType As String
    Private _BlockSeq As Integer
    Private _Heading As String
    Private _VisiblityCode As String
    Private _MaxWordCount As Integer
    Private _InstructionText As String
    Private _TransferToProductDesc As Boolean
    Private _Call_Code As String
    Private _SubmissionTypeCode As String
    Private _AbstractCallSubmissionTypeTextBlockControlId As Integer

    Public Property AbstractCallSubmissionTypeTextBlockControlId() As Integer
        Get
            Return _AbstractCallSubmissionTypeTextBlockControlId
        End Get
        Set(ByVal value As Integer)
            _AbstractCallSubmissionTypeTextBlockControlId = value
        End Set
    End Property

    Public Property BlockType() As String
        Get
            Return _BlockType
        End Get
        Set(ByVal value As String)
            _BlockType = value
        End Set
    End Property
    Public Property BlockSeq() As Integer
        Get
            Return _BlockSeq
        End Get
        Set(ByVal value As Integer)
            _BlockSeq = value
        End Set
    End Property
    Public Property Heading() As String
        Get
            Return _Heading
        End Get
        Set(ByVal value As String)
            _Heading = value
        End Set
    End Property
    Public Property VisiblityCode() As String
        Get
            Return _VisiblityCode
        End Get
        Set(ByVal value As String)
            _VisiblityCode = value
        End Set
    End Property
    Public Property MaxWordCount() As Integer
        Get
            Return _MaxWordCount
        End Get
        Set(ByVal value As Integer)
            _MaxWordCount = value
        End Set
    End Property
    Public Property InstructionText() As String
        Get
            Return _InstructionText
        End Get
        Set(ByVal value As String)
            _InstructionText = value
        End Set
    End Property
    Public Property TransferToProductDesc() As Boolean
        Get
            Return _TransferToProductDesc
        End Get
        Set(ByVal value As Boolean)
            _TransferToProductDesc = value
        End Set
    End Property

    Public Property Call_Code() As String
        Get
            Return _Call_Code
        End Get
        Set(ByVal value As String)
            _Call_Code = value           
        End Set
    End Property

    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value            
        End Set
    End Property
End Class

Public Class WEB_SUBMISSIONSCORING

    Private _AbstractCallSubmissionTypeScoringControlId As Integer
    Private _ScoringCriterionCode As String
    Private _AnswerTypeCode As String
    Private _ScoringAnswerCode As String
    Private _SubmissionScoringCriterionSeq As Integer
    Private _SubmissionScoringCriterionDescription As String
    Private _AllowCommentsFlag As Boolean

    Public Property AbstractCallSubmissionTypeScoringControlId() As Integer
        Get
            Return _AbstractCallSubmissionTypeScoringControlId
        End Get
        Set(ByVal value As Integer)
            _AbstractCallSubmissionTypeScoringControlId = value
        End Set
    End Property

    Public Property ScoringCriterionCode() As String
        Get
            Return _ScoringCriterionCode
        End Get
        Set(ByVal value As String)
            _ScoringCriterionCode = value
        End Set
    End Property
    Public Property AnswerTypeCode() As String
        Get
            Return _AnswerTypeCode
        End Get
        Set(ByVal value As String)
            _AnswerTypeCode = value
        End Set
    End Property
    Public Property ScoringAnswerCode() As String
        Get
            Return _ScoringAnswerCode
        End Get
        Set(ByVal value As String)
            _ScoringAnswerCode = value
        End Set
    End Property
    Public Property SubmissionScoringCriterionSeq() As Integer
        Get
            Return _SubmissionScoringCriterionSeq
        End Get
        Set(ByVal value As Integer)
            _SubmissionScoringCriterionSeq = value
        End Set
    End Property
    Public Property SubmissionScoringCriterionDescription() As String
        Get
            Return _SubmissionScoringCriterionDescription
        End Get
        Set(ByVal value As String)
            _SubmissionScoringCriterionDescription = value
        End Set
    End Property
    Public Property AllowCommentsFlag() As Boolean
        Get
            Return _AllowCommentsFlag
        End Get
        Set(ByVal value As Boolean)
            _AllowCommentsFlag = value
        End Set
    End Property

End Class

Public Class AuthorDisclosureQuestionsData

    Private _AuthorDisclosureControlId As Integer
    Public Property AuthorDisclosureControlId() As Integer
        Get
            Return _AuthorDisclosureControlId
        End Get
        Set(ByVal value As Integer)
            _AuthorDisclosureControlId = value
        End Set
    End Property

    Private _AbstractCallCode As String = Nothing
    Public Property AbstractCallCode() As String
        Get
            Return _AbstractCallCode
        End Get
        Set(ByVal value As String)
            _AbstractCallCode = value
        End Set
    End Property

    Private _SubmissionTypeCode As String = Nothing
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property

    Private _DisclosureRelationshipCode As String = Nothing
    Public Property DisclosureRelationshipCode() As String
        Get
            Return _DisclosureRelationshipCode
        End Get
        Set(ByVal value As String)
            _DisclosureRelationshipCode = value
        End Set
    End Property

    Private _QuestionSeq As Integer = 0
    Public Property QuestionSeq() As Integer
        Get
            Return _QuestionSeq
        End Get
        Set(ByVal value As Integer)
            _QuestionSeq = value
        End Set
    End Property

    Private _QuestionText As String = Nothing
    Public Property QuestionText() As String
        Get
            Return _QuestionText
        End Get
        Set(ByVal value As String)
            _QuestionText = value
        End Set
    End Property

    'Private _Answer As String = Nothing
    'Public Property Answer() As String
    '    Get
    '        Return _Answer
    '    End Get
    '    Set(ByVal value As String)
    '        _Answer = value
    '    End Set
    'End Property

    Private _RelatedCustomerName As String = Nothing
    Public Property RelatedCustomerName() As String
        Get
            Return _RelatedCustomerName
        End Get
        Set(ByVal value As String)
            _RelatedCustomerName = value
        End Set
    End Property

    Private _DisclosureProductDescription As String = Nothing
    Public Property DisclosureProductDescription() As String
        Get
            Return _DisclosureProductDescription
        End Get
        Set(ByVal value As String)
            _DisclosureProductDescription = value
        End Set
    End Property
End Class

Public Class AuthorData

    Private _AuthorId As Integer
    Public Property AuthorId() As Integer
        Get
            Return _AuthorId
        End Get
        Set(ByVal value As Integer)
            _AuthorId = value
        End Set
    End Property

    Private _Name As String = Nothing
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property

    Private _Roles As String = Nothing
    Public Property Roles() As String
        Get
            Return _Roles
        End Get
        Set(ByVal value As String)
            _Roles = value
        End Set
    End Property

    Private _EditUrl As String = Nothing
    Public Property EditUrl() As String
        Get
            Return _EditUrl
        End Get
        Set(ByVal value As String)
            _EditUrl = value
        End Set
    End Property

    Private _Flags As String = Nothing
    Public Property Flags() As String
        Get
            Return _Flags
        End Get
        Set(ByVal value As String)
            _Flags = value
        End Set
    End Property

End Class

'Staff Class
Public Class SubmissionTypeStaff

    Private _SubmissionTypeStaffId As Integer
    Public Property SubmissionTypeStaffId() As Integer
        Get
            Return _SubmissionTypeStaffId
        End Get
        Set(ByVal value As Integer)
            _SubmissionTypeStaffId = value
        End Set
    End Property

    Private _AbstractCallCode As String = Nothing
    Public Property AbstractCallCode() As String
        Get
            Return _AbstractCallCode
        End Get
        Set(ByVal value As String)
            _AbstractCallCode = value
        End Set
    End Property

    Private _SubmissionTypeCode As String = Nothing
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property

    Private _MasterCustomerID As String = Nothing
    Public Property MasterCustomerID() As String
        Get
            Return _MasterCustomerID
        End Get
        Set(ByVal value As String)
            _MasterCustomerID = value
        End Set
    End Property

    Private _SubCustomerID As Integer = 0
    Public Property SubCustomerID() As Integer
        Get
            Return _SubCustomerID
        End Get
        Set(ByVal value As Integer)
            _SubCustomerID = value
        End Set
    End Property

    Private _StaffName As String = Nothing
    Public Property StaffName() As String
        Get
            Return _StaffName
        End Get
        Set(ByVal value As String)
            _StaffName = value
        End Set
    End Property

    Private _StaffRoleCode As String = Nothing
    Public Property StaffRoleCode() As String
        Get
            Return _StaffRoleCode
        End Get
        Set(ByVal value As String)
            _StaffRoleCode = value
        End Set
    End Property
    Private _StaffRoleDescription As String = Nothing
    Public Property StaffRoleDescription() As String
        Get
            Return _StaffRoleDescription
        End Get
        Set(ByVal value As String)
            _StaffRoleDescription = value
        End Set
    End Property

    Private _EmailAddress As String = Nothing
    Public Property EmailAddress() As String
        Get
            Return _EmailAddress
        End Get
        Set(ByVal value As String)
            _EmailAddress = value
        End Set
    End Property

End Class

Public Class TypeDisclosureQuestionsData

    Private _TypeDisclosureControlId As Integer
    Public Property TypeDisclosureControlId() As Integer
        Get
            Return _TypeDisclosureControlId
        End Get
        Set(ByVal value As Integer)
            _TypeDisclosureControlId = value
        End Set
    End Property

    Private _AbstractCallCode As String = Nothing
    Public Property AbstractCallCode() As String
        Get
            Return _AbstractCallCode
        End Get
        Set(ByVal value As String)
            _AbstractCallCode = value
        End Set
    End Property

    Private _SubmissionTypeCode As String = Nothing
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property

    Private _DisclosureRelationshipCode As String = Nothing
    Public Property DisclosureRelationshipCode() As String
        Get
            Return _DisclosureRelationshipCode
        End Get
        Set(ByVal value As String)
            _DisclosureRelationshipCode = value
        End Set
    End Property

    Private _QuestionSeq As Integer = 0
    Public Property QuestionSeq() As Integer
        Get
            Return _QuestionSeq
        End Get
        Set(ByVal value As Integer)
            _QuestionSeq = value
        End Set
    End Property

    Private _QuestionText As String = Nothing
    Public Property QuestionText() As String
        Get
            Return _QuestionText
        End Get
        Set(ByVal value As String)
            _QuestionText = value
        End Set
    End Property

    Private _DisclosureQuestionCode As String = Nothing
    Public Property DisclosureQuestionCode() As String
        Get
            Return _DisclosureQuestionCode
        End Get
        Set(ByVal value As String)
            _DisclosureQuestionCode = value
        End Set
    End Property

    Private _DisclosureAnswerCode As String = Nothing
    Public Property DisclosureAnswerCode() As String
        Get
            Return _DisclosureAnswerCode
        End Get
        Set(ByVal value As String)
            _DisclosureAnswerCode = value
        End Set
    End Property

    Private _DisclosureAnswerText As String = Nothing
    Public Property DisclosureAnswerText() As String
        Get
            Return _DisclosureAnswerText
        End Get
        Set(ByVal value As String)
            _DisclosureAnswerText = value
        End Set
    End Property

    Private _RejectionDisclosureAnswerSubcode As String = Nothing
    Public Property RejectionDisclosureAnswerSubcode() As String
        Get
            Return _RejectionDisclosureAnswerSubcode
        End Get
        Set(ByVal value As String)
            _RejectionDisclosureAnswerSubcode = value
        End Set
    End Property

    Private _Required As Boolean = False
    Public Property Required() As Boolean
        Get
            Return _Required
        End Get
        Set(ByVal value As Boolean)
            _Required = value
        End Set
    End Property

    Private _CodedAnswerFlag As Boolean = False
    Public Property CodedAnswerFlag() As Boolean
        Get
            Return _CodedAnswerFlag
        End Get
        Set(ByVal value As Boolean)
            _CodedAnswerFlag = value
        End Set
    End Property

End Class

Public Class CallTopicData

    Private _SubmissionId As Integer
    Public Property SubmissionId() As Integer
        Get
            Return _SubmissionId
        End Get
        Set(ByVal value As Integer)
            _SubmissionId = value
        End Set
    End Property
    Private _TopicCode As String
    Public Property TopicCode() As String
        Get
            Return _TopicCode
        End Get
        Set(ByVal value As String)
            _TopicCode = value
        End Set
    End Property

End Class

Public Class AbstractEmail
    Private _EmailName As String
    Private _EmailAddress As String

    Public Property EmailName() As String
        Get
            Return _EmailName
        End Get
        Set(ByVal value As String)
            _EmailName = value
        End Set
    End Property

    Public Property EmailAddress() As String
        Get
            Return _EmailAddress
        End Get
        Set(ByVal value As String)
            _EmailAddress = value
        End Set
    End Property
End Class

#Region "ENUM"

Public Enum MoveDirection
    Up
    Down
End Enum

#End Region
