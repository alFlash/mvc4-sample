Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports TIMSS.API.Core
Imports TIMSS.SQLObjects

Imports TIMSS.API.AbstractInfo
Imports System.Collections.Generic


Public Class CallManagerHelper
    Inherits BaseHelperClass


    Public Sub New(ByVal OrgId As String, ByVal OrgUnitId As String)
        MyBase.New(OrgId, OrgUnitId)
    End Sub


#Region "ABS CALL"

#Region "ABS CALL WEB Class"
    Public Class WEB_ABSCALL
        Public Title As String
        Public Description As String
        Public CallStartDate As Date
        Public CallEndDate As Date
        Public CallType As String
        Public CallCode As String
        Public MeetingValue As String 'Seperate by "|" contains PID, PCODE, ParentCode,Subsystem
        Public Comments As String
    End Class
#End Region

    Public Function ABSCALL_Create(ByVal PortalId As Integer, ByVal oWebABSCall As WEB_ABSCALL) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls
        Dim oABSCall As TIMSS.API.AbstractInfo.IAbstractCall

        oABSCalls = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCalls"), TIMSS.API.AbstractInfo.IAbstractCalls)

        oABSCall = oABSCalls.AddNew

        oABSCall.Title = oWebABSCall.Title
        oABSCall.Description = oWebABSCall.Description
        oABSCall.CallStartDate = oWebABSCall.CallStartDate
        oABSCall.CallTypeCode = oABSCall.CallTypeCode.List(oWebABSCall.CallType).ToCodeObject
        oABSCall.AbstractCallCode = oWebABSCall.CallCode
        If PersonifyWebCommon.isNullDate(oWebABSCall.CallEndDate) Then
            oABSCall.SourceRow("CALL_END_DATE") = DBNull.Value
        Else
            oABSCall.CallEndDate = oWebABSCall.CallEndDate
        End If
        oABSCall.Comments = oWebABSCall.Comments
        oABSCalls.Save()


        Return oABSCalls.ValidationIssues


    End Function

    Public Function ABSCALL_Update(ByVal PortalId As Integer, ByVal oWebABSCall As WEB_ABSCALL) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls
        Dim oABSCall As TIMSS.API.AbstractInfo.IAbstractCall

        oABSCalls = ABSCALLS_GET(PortalId, oWebABSCall.CallCode)
        'If oWebABSCall.CallCode.ToUpper = OldCallCode.ToUpper Then
        '    oABSCalls = ABSCALLS_GET(PortalId, oWebABSCall.CallCode)
        'Else
        '    oABSCalls = ABSCALLS_GET(PortalId, OldCallCode)
        '    If oABSCalls IsNot Nothing AndAlso oABSCalls.Count > 0 Then
        '        oABSCalls(0).AbstractCallCode = oWebABSCall.CallCode
        '    End If
        'End If

        If oABSCalls IsNot Nothing AndAlso oABSCalls.Count > 0 Then
            oABSCall = oABSCalls(0)

            oABSCall.Title = oWebABSCall.Title
            oABSCall.Description = oWebABSCall.Description
            oABSCall.CallStartDate = oWebABSCall.CallStartDate
            If PersonifyWebCommon.isNullDate(oWebABSCall.CallEndDate) Then
                oABSCall.SourceRow("CALL_END_DATE") = DBNull.Value
            Else
                oABSCall.CallEndDate = oWebABSCall.CallEndDate
            End If
            oABSCall.Comments = oWebABSCall.Comments

            oABSCall.CallTypeCode = oABSCall.CallTypeCode.List(oWebABSCall.CallType).ToCodeObject
            oABSCall.AbstractCallCode = oWebABSCall.CallCode

            If oWebABSCall.MeetingValue <> "" Then
                Dim strValues() As String = oWebABSCall.MeetingValue.Split("|")
                oABSCall.PrimaryProductId = strValues(0)
                oABSCall.PrimaryProductCode = strValues(1)
                oABSCall.PrimaryParentProduct = strValues(2)
                oABSCall.PrimaryProductSubsystem = strValues(3)
            Else
                oABSCall.PrimaryProductId = 0
                oABSCall.PrimaryProductCode = ""
                oABSCall.PrimaryParentProduct = ""
                oABSCall.PrimaryProductSubsystem = ""
            End If

            oABSCalls.Save()

            Return oABSCalls.ValidationIssues

        End If

        Return Nothing

    End Function

    Public Function ABSCALLS_GET(ByVal portalId As Integer, ByVal CallCode As String) As TIMSS.API.AbstractInfo.IAbstractCalls

        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls

        oABSCalls = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCalls")
        With oABSCalls
            .Filter.Add("ABS_CALL_CODE", TIMSS.Enumerations.QueryOperatorEnum.Equals, CallCode)
            .Fill()
        End With

        Return oABSCalls

    End Function

    Public Function ABSCALLS_TABLE_GET(ByVal portalId As Integer, ByVal IsActive As Boolean) As DataTable



        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCalls")
        searchObj.EnforceLimits = False

        Dim oParm As TIMSS.API.Core.SearchProperty
        'Dim abs As TIMSS.API.AbstractInfo.IAbstractCall

        oParm = New TIMSS.API.Core.SearchProperty("AbstractCallCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        'oParm.Value = CallCode
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CallTypeCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)
 

        oParm = New TIMSS.API.Core.SearchProperty("CallStartDate")
        oParm.UseInQuery = True
        oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.LessThanOrEqual
        oParm.ShowInResults = True
        oParm.Value = TIMSS.Common.Functions.InvariantDateFormat(TIMSS.Global.App.ServerDateTime.Date.Year, TIMSS.Global.App.ServerDateTime.Date.Month, TIMSS.Global.App.ServerDateTime.Date.Day)
        searchObj.Parameters.Add(oParm)



        oParm = New TIMSS.API.Core.SearchProperty("CallEndDate")
        oParm.UseInQuery = True
        oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual
        oParm.ShowInResults = True
        oParm.Value = TIMSS.Common.Functions.InvariantDateFormat(TIMSS.Global.App.ServerDateTime.Date.Year, TIMSS.Global.App.ServerDateTime.Date.Month, TIMSS.Global.App.ServerDateTime.Date.Day)
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CallEndDate")
        oParm.UseInQuery = True
        oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.IsNull
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        Return searchObj.Results.Table

    End Function

    Public Function ABSALLCALLS_GET(ByVal portalId As Integer, ByVal strCallStatus As String, Optional ByVal SortPropertyName As String = "AddedOn", Optional ByVal SortOrder As TIMSS.Enumerations.SortDirection = TIMSS.Enumerations.SortDirection.Descending) As TIMSS.API.AbstractInfo.IAbstractCalls
        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls
        oABSCalls = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCalls")
        With oABSCalls
            If Not String.IsNullOrEmpty(strCallStatus) Then
                If strCallStatus = "Y" Then
                    .Filter.Add(New FilterItem("Call_End_Date is null or Call_End_Date >= '" & Date.Today & "'"))
                    '.Filter.Add("CallEndDate", TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual, Date.Today)
                Else
                    .Filter.Add("CallEndDate", TIMSS.Enumerations.QueryOperatorEnum.LessThan, Date.Today)
                End If
            End If
            '.Filter.Add("ABS_CALL_CODE", TIMSS.Enumerations.QueryOperatorEnum.Equals, CallCode)
            .SortProperties.Add(SortPropertyName, SortOrder)
            .Fill()
            '.Sort("AddedOn", ComponentModel.ListSortDirection.Descending)
        End With

        Return oABSCalls
    End Function




#End Region

#Region "ABS CALL SUBMISSION TYPE"


    Public Function ABSSubmissionType_Create(ByVal PortalId As Integer, ByVal oWebCallSubType As WEB_SUBMISSIONTYPE) As TIMSS.API.Core.Validation.IIssuesCollection




        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim oCallSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType
        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls
        Dim oABSCall As TIMSS.API.AbstractInfo.IAbstractCall

        oABSCalls = ABSCALLS_GET(PortalId, oWebCallSubType.Call_Code)

        If oABSCalls IsNot Nothing AndAlso oABSCalls.Count > 0 Then
            oABSCall = oABSCalls(0)
            oCallSubTypes = oABSCall.AbstractCallSubmissionTypes
            oCallSubType = oCallSubTypes.AddNew

            ABSSubmissionTypeProperties_Execute(oCallSubType, oWebCallSubType)

            With oCallSubType
                '.SubmissionTypeCode = .SubmissionTypeCode.List(oWebCallSubType.SubmissionTypeCode).ToCodeObject
                '.Description = oWebCallSubType.Description

                '.SubmissionTypeStartDate = oWebCallSubType.SubmissionStartDate
                '.SubmissionTypeEndDate = oWebCallSubType.SubmissionEndDate

                '.WebSubmittalStartDate = oWebCallSubType.SubmissionWebStartDate
                '.WebSubmittalEndDate = oWebCallSubType.SubmissionWebEndDate

                '.AnnouncementDate = oWebCallSubType.AnnouncementDate
                '.FinalReviewDate = oWebCallSubType.ReviewEndDate

                'May need to remove it later
                .ReviewTypeCode = .ReviewTypeCode.List("REVIEWER").ToCodeObject
                '.ReviewBlindRuleCode = .ReviewBlindRuleCode.List("SINGLE_BLIND").ToCodeObject
                '.ReviewerApprovedForCode = .ReviewerApprovedForCode.List("ABSTRACTS").ToCodeObject
                .ValidateTopicControlCode = .ValidateTopicControlCode.List("SUBMISSION_TYPE_LIST").ToCodeObject
                .ValidateKeywordControlCode = .ValidateKeywordControlCode.List("SUBMISSION_TYPE_LIST").ToCodeObject
                '.SetupCompletedFlag = True
            End With


            oCallSubTypes.Save()

            Return oCallSubTypes.ValidationIssues



        End If

        Return Nothing


    End Function

    Public Function ABSSubmissionType_Update(ByVal PortalId As Integer, ByVal oWebCallSubType As WEB_SUBMISSIONTYPE) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim oCallSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType

        oCallSubTypes = ABSSubmissionType_Get(PortalId, oWebCallSubType.Call_Code, oWebCallSubType.SubmissionTypeCode)

        If oCallSubTypes IsNot Nothing AndAlso oCallSubTypes.Count > 0 Then

            oCallSubType = oCallSubTypes(0)
            ABSSubmissionTypeProperties_Execute(oCallSubType, oWebCallSubType)
            ABSInstructionType_Execute(oCallSubType, oWebCallSubType.ABSInstructions_Get)
            ABSFileTyoesOperation_Execute(oCallSubType, oWebCallSubType.ABSFileTypes_Get)

            oCallSubTypes.Save()
            Return oCallSubTypes.ValidationIssues
        End If
        Return Nothing
    End Function

    Public Function ABSSubmissionTypeTextBlock_Update(ByVal PortalId As Integer, ByVal WebTextBlockControl As WEB_SUBMISSIONTEXTBLOCK) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oTextBlocks As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls
        Dim isFound As Boolean = False

        oTextBlocks = ABSSubmissionTypeTextBlock_Get(PortalId, WebTextBlockControl.Call_Code, WebTextBlockControl.SubmissionTypeCode)

        If oTextBlocks IsNot Nothing Then
            For Each oTextBlock As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl In oTextBlocks
                If oTextBlock.AbstractCallSubmissionTypeTextBlockControlId = WebTextBlockControl.AbstractCallSubmissionTypeTextBlockControlId Then
                    isFound = True
                    oTextBlock.BlockSequence = WebTextBlockControl.BlockSeq
                    oTextBlock.Heading = WebTextBlockControl.Heading
                    oTextBlock.MaxWordCount = WebTextBlockControl.MaxWordCount
                    oTextBlock.InstructionText = WebTextBlockControl.InstructionText
                    Exit For
                End If
            Next
            If isFound = False Then
                Dim ABSTextBlock As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl
                ABSTextBlock = oTextBlocks.AddNew()
                ABSTextBlock.BlockTypeCode = ABSTextBlock.BlockTypeCode.List(WebTextBlockControl.BlockType).ToCodeObject
                ABSTextBlock.Heading = WebTextBlockControl.Heading
                ABSTextBlock.VisibilityCode = ABSTextBlock.VisibilityCode.List(WebTextBlockControl.VisiblityCode).ToCodeObject
                ABSTextBlock.MaxWordCount = WebTextBlockControl.MaxWordCount
                ABSTextBlock.InstructionText = WebTextBlockControl.InstructionText
            End If

            oTextBlocks.Save()

            Return oTextBlocks.ValidationIssues
        End If

        Return Nothing

    End Function

    Public Function ABSSubmissionTypeDisclosureQuestion_Update(ByVal PortalId As Integer, ByVal WebDisclosureQuestionControl As WEB_SUBMISSIONDISCLOSUREQUESTION) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls
        Dim isFound As Boolean = False

        oDisclosureQuestions = ABSSubmissionTypeDisclosureQuestion_Get(PortalId, WebDisclosureQuestionControl.AbstractCallCode, WebDisclosureQuestionControl.SubmissionTypeCode)

        If oDisclosureQuestions IsNot Nothing Then
            For Each oDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControl In oDisclosureQuestions
                If oDisclosureQuestion.AbstractCallSubmissionTypeDisclosureQuestionControlId = WebDisclosureQuestionControl.AbstractCallSubmissionTypeDisclosureQuestionControlId Then
                    isFound = True
                    oDisclosureQuestion.CodedAnswerFlag = WebDisclosureQuestionControl.CodedAnswerFlag
                    oDisclosureQuestion.QuestionSequence = WebDisclosureQuestionControl.QuestionSequence
                    oDisclosureQuestion.QuestionText = WebDisclosureQuestionControl.QuestionText
                    If Not oDisclosureQuestion.CodedAnswerFlag Then
                        oDisclosureQuestion.DisclosureAnswerCode.Code = ""
                        oDisclosureQuestion.RejectionDisclosureAnswerSubcode.Code = ""
                    Else
                        oDisclosureQuestion.DisclosureAnswerCode = oDisclosureQuestion.DisclosureAnswerCode.List(WebDisclosureQuestionControl.DisclosureAnswerCode).ToCodeObject
                        oDisclosureQuestion.RejectionDisclosureAnswerSubcode = oDisclosureQuestion.RejectionDisclosureAnswerSubcode.List(WebDisclosureQuestionControl.RejectionDisclosureAnswerSubcode).ToCodeObject
                    End If

                    oDisclosureQuestion.DisclosureQuestionCode = oDisclosureQuestion.DisclosureQuestionCode.List(WebDisclosureQuestionControl.DisclosureQuestionCode).ToCodeObject

                    oDisclosureQuestion.AnswerRequiredFlag = WebDisclosureQuestionControl.AnswerRequiredFlag


                    Exit For
                End If
            Next
            If isFound = False Then
                Dim oABSDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControl
                oABSDisclosureQuestion = oDisclosureQuestions.AddNew()
                oABSDisclosureQuestion.CodedAnswerFlag = WebDisclosureQuestionControl.CodedAnswerFlag
                oABSDisclosureQuestion.QuestionText = WebDisclosureQuestionControl.QuestionText
                If Not oABSDisclosureQuestion.CodedAnswerFlag Then
                    oABSDisclosureQuestion.DisclosureAnswerCode.Code = ""
                    oABSDisclosureQuestion.RejectionDisclosureAnswerSubcode.Code = ""
                Else
                    oABSDisclosureQuestion.DisclosureAnswerCode = oABSDisclosureQuestion.DisclosureAnswerCode.List(WebDisclosureQuestionControl.DisclosureAnswerCode).ToCodeObject
                    oABSDisclosureQuestion.RejectionDisclosureAnswerSubcode = oABSDisclosureQuestion.RejectionDisclosureAnswerSubcode.List(WebDisclosureQuestionControl.RejectionDisclosureAnswerSubcode).ToCodeObject
                End If

                oABSDisclosureQuestion.DisclosureQuestionCode = oABSDisclosureQuestion.DisclosureQuestionCode.List(WebDisclosureQuestionControl.DisclosureQuestionCode).ToCodeObject
                oABSDisclosureQuestion.AnswerRequiredFlag = WebDisclosureQuestionControl.AnswerRequiredFlag                
            End If

            oDisclosureQuestions.Save()

            Return oDisclosureQuestions.ValidationIssues
        End If

        Return Nothing

    End Function

    Public Function ABSSubmissionTypeTextBlock_Delete(ByVal PortalId As Integer, ByVal AbstractCallSubmissionTypeTextBlockControlId As String, ByVal BlockSeq As String, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oCallSubTypeTextBlocks As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl = Nothing

        oCallSubTypeTextBlocks = ABSSubmissionType_Get(PortalId, ABSCALLCode, SubmissionTypeCode)(0).AbstractCallSubmissionTypeTextBlockControls

        For Each oCallSubTypeTextBlock As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl In oCallSubTypeTextBlocks
            If oCallSubTypeTextBlock.AbstractCallSubmissionTypeTextBlockControlId = AbstractCallSubmissionTypeTextBlockControlId Then
                objToDelete = oCallSubTypeTextBlock
            End If
            If oCallSubTypeTextBlock.BlockSequence > CType(BlockSeq, Integer) Then
                oCallSubTypeTextBlock.BlockSequence = oCallSubTypeTextBlock.BlockSequence - 1
            End If
        Next
        If objToDelete IsNot Nothing Then
            oCallSubTypeTextBlocks.Remove(objToDelete)
            oCallSubTypeTextBlocks.Save()
        End If

        Return oCallSubTypeTextBlocks.ValidationIssues

    End Function

    Public Function ABSSubmissionTypeDisclosureQuestion_Delete(ByVal PortalId As Integer, ByVal AbstractCallSubmissionTypeDisclosureQuestionControlId As String, ByVal QuestionSequence As String, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oCallSubTypeDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControl = Nothing

        oCallSubTypeDisclosureQuestions = ABSSubmissionType_Get(PortalId, ABSCALLCode, SubmissionTypeCode)(0).AbstractCallSubmissionTypeDisclosureQuestionControls

        For Each oCallSubTypeDislosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControl In oCallSubTypeDisclosureQuestions
            If oCallSubTypeDislosureQuestion.AbstractCallSubmissionTypeDisclosureQuestionControlId = AbstractCallSubmissionTypeDisclosureQuestionControlId Then
                objToDelete = oCallSubTypeDislosureQuestion
            End If
            If oCallSubTypeDislosureQuestion.QuestionSequence > CType(QuestionSequence, Integer) Then
                oCallSubTypeDislosureQuestion.QuestionSequence = oCallSubTypeDislosureQuestion.QuestionSequence - 1
            End If
        Next
        If objToDelete IsNot Nothing Then
            oCallSubTypeDisclosureQuestions.Remove(objToDelete)
            oCallSubTypeDisclosureQuestions.Save()
        End If

        Return oCallSubTypeDisclosureQuestions.ValidationIssues

    End Function

    Public Function ABSSubmissionType_Get(ByVal portalId As Integer, ByVal CallCode As String, Optional ByVal SubTypeCode As String = Nothing) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes



        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

        oCallSubTypes = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypes")
        With oCallSubTypes
            If Not String.IsNullOrEmpty(CallCode) Then
                .Filter.Add("ABS_CALL_CODE", TIMSS.Enumerations.QueryOperatorEnum.Equals, CallCode)
            End If
            If Not String.IsNullOrEmpty(SubTypeCode) Then
                .Filter.Add("SUBMISSION_TYPE_CODE", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubTypeCode)
            End If
            .Fill()
        End With

        Return oCallSubTypes

    End Function

    'Public  Function ABSSubmissionType_Get(ByVal portalId As Integer) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

    '   

    '    Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

    '    oCallSubTypes = TIMSS.Global.GetCollection(OrganizationId,OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypes")
    '    With oCallSubTypes
    '        .Fill()
    '    End With

    '    Return oCallSubTypes

    'End Function


    'Public  Function ABSSubmissionType_SubmissionDisclosure_Get_CustomList(ByVal portalId As Integer, ByVal CallCode As String, ByVal SubTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls

    '   

    '    Dim oCallSubTypeSubmissionDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls

    '    oCallSubTypeSubmissionDisclosureQuestions = TIMSS.Global.GetCollection(OrganizationId,OrganizationUnitId,TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeSubmissionDisclosureControls")
    '    oCallSubTypeSubmissionDisclosureQuestions.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, CallCode)
    '    oCallSubTypeSubmissionDisclosureQuestions.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubTypeCode)
    '    oCallSubTypeSubmissionDisclosureQuestions.Fill()

    '    Return oCallSubTypeSubmissionDisclosureQuestions

    'End Function

    Public Function ABSSubmissionType_GetAuthorDisclosureQuestions(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls


        Dim oCallSubTypeAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls

        oCallSubTypeAuthorDisclosureQuestions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeAuthorDisclosureControls")
        If ABSCALLCode IsNot Nothing AndAlso ABSCALLCode <> String.Empty Then
            oCallSubTypeAuthorDisclosureQuestions.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, ABSCALLCode)
        End If
        If SubmissionTypeCode IsNot Nothing AndAlso SubmissionTypeCode <> String.Empty Then
            oCallSubTypeAuthorDisclosureQuestions.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)
        End If
        oCallSubTypeAuthorDisclosureQuestions.Fill()
        oCallSubTypeAuthorDisclosureQuestions.Sort("QuestionSequence", ComponentModel.ListSortDirection.Ascending)

        Return oCallSubTypeAuthorDisclosureQuestions
    End Function

    Public Function ABSSubmissionType_GetAuthorDisclosureQuestionsAnswers(ByVal portalId As Integer, ByVal AbstractSubmissionAuthorId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosures


        Dim oAbstractSubmissionAuthorDisclosures As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthorDisclosures

        oAbstractSubmissionAuthorDisclosures = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthorDisclosures")
        oAbstractSubmissionAuthorDisclosures.Filter.Add("AbstractSubmissionAuthorId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionAuthorId)

        oAbstractSubmissionAuthorDisclosures.Fill()

        Return oAbstractSubmissionAuthorDisclosures
    End Function

    Public Function ABSSubmissionType_AddAuthorDisclosureQuestion(ByVal portalId As Integer, ByVal oAuthorDisclosureQuestion As AuthorDisclosureQuestionsData) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim oCallSubType As TIMSS.API.AbstractInfo.IAbstractCallSubmissionType
        Dim oSubTypeAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
        Dim oSubTypeAuthorDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl

        oCallSubTypes = ABSSubmissionType_Get(portalId, oAuthorDisclosureQuestion.AbstractCallCode, oAuthorDisclosureQuestion.SubmissionTypeCode)

        If oCallSubTypes IsNot Nothing AndAlso oCallSubTypes.Count > 0 Then
            oCallSubType = oCallSubTypes(0)
            oSubTypeAuthorDisclosureQuestions = oCallSubType.AbstractCallSubmissionTypeAuthorDisclosureControls
            oSubTypeAuthorDisclosureQuestion = oSubTypeAuthorDisclosureQuestions.AddNew

            oSubTypeAuthorDisclosureQuestion.DisclosureRelationshipCode = oSubTypeAuthorDisclosureQuestion.DisclosureRelationshipCode.List(oAuthorDisclosureQuestion.DisclosureRelationshipCode).ToCodeObject
            oSubTypeAuthorDisclosureQuestion.QuestionSequence = oAuthorDisclosureQuestion.QuestionSeq
            oSubTypeAuthorDisclosureQuestion.QuestionText = oAuthorDisclosureQuestion.QuestionText

            oSubTypeAuthorDisclosureQuestions.Save()

            Return oSubTypeAuthorDisclosureQuestions.ValidationIssues
        End If

        Return Nothing
    End Function

    Public Function ABSSubmissionType_UpdateAuthorDisclosureQuestion(ByVal portalId As Integer, ByVal oAuthorDisclosureQuestion As AuthorDisclosureQuestionsData) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oCallSubTypeAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl = Nothing

        oCallSubTypeAuthorDisclosureQuestions = ABSSubmissionType_GetAuthorDisclosureQuestions(portalId, oAuthorDisclosureQuestion.AbstractCallCode, oAuthorDisclosureQuestion.SubmissionTypeCode)

        For Each oCallSubTypeAuthorDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl In oCallSubTypeAuthorDisclosureQuestions
            If oCallSubTypeAuthorDisclosureQuestion.AbstractCallSubmissionTypeAuthorDisclosureControlId = oAuthorDisclosureQuestion.AuthorDisclosureControlId Then
                oCallSubTypeAuthorDisclosureQuestion.QuestionText = oAuthorDisclosureQuestion.QuestionText
                oCallSubTypeAuthorDisclosureQuestion.DisclosureRelationshipCode = oCallSubTypeAuthorDisclosureQuestion.DisclosureRelationshipCode.List(oAuthorDisclosureQuestion.DisclosureRelationshipCode).ToCodeObject
                Exit For
            End If
        Next
        oCallSubTypeAuthorDisclosureQuestions.Save()

        Return oCallSubTypeAuthorDisclosureQuestions.ValidationIssues
    End Function

    Public Function ABSSubmissionType_DeleteAuthorDisclosureQuestion(ByVal portalid As Integer, ByVal AuthorDisclosureControlId As String, ByVal QuestionSeq As String, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oCallSubTypeAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl = Nothing

        oCallSubTypeAuthorDisclosureQuestions = ABSSubmissionType_GetAuthorDisclosureQuestions(portalid, ABSCALLCode, SubmissionTypeCode)

        For Each oCallSubTypeAuthorDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl In oCallSubTypeAuthorDisclosureQuestions
            If oCallSubTypeAuthorDisclosureQuestion.AbstractCallSubmissionTypeAuthorDisclosureControlId = AuthorDisclosureControlId Then
                objToDelete = oCallSubTypeAuthorDisclosureQuestion
            End If
            If oCallSubTypeAuthorDisclosureQuestion.QuestionSequence > CType(QuestionSeq, Integer) Then
                oCallSubTypeAuthorDisclosureQuestion.QuestionSequence = oCallSubTypeAuthorDisclosureQuestion.QuestionSequence - 1
            End If
        Next
        If objToDelete IsNot Nothing Then
            oCallSubTypeAuthorDisclosureQuestions.Remove(objToDelete)
            oCallSubTypeAuthorDisclosureQuestions.Save()
        End If

        Return oCallSubTypeAuthorDisclosureQuestions.ValidationIssues
    End Function

    Public Function ABSSubmissionTypeScoringCriterion_Get(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

        oCallSubTypes = ABSSubmissionType_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        If oCallSubTypes IsNot Nothing And oCallSubTypes.Count > 0 Then
            Return oCallSubTypes(0).AbstractCallSubmissionTypeScoringControls            
        End If

        Return Nothing
    End Function

    Public Function ABSSubmissionTypeScoringControl_Update(ByVal portalid As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal ScoringControls As List(Of WEB_SUBMISSIONSCORING)) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oScoringControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls = ABSSubmissionTypeScoringCriterion_Get(portalid, ABSCALLCode, SubmissionTypeCode)

        If oScoringControls IsNot Nothing Then
            For Each WebScoringControl As WEB_SUBMISSIONSCORING In ScoringControls
                For Each oScoringControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControl In oScoringControls
                    With WebScoringControl
                        If oScoringControl.AbstractCallSubmissionTypeScoringControlId = .AbstractCallSubmissionTypeScoringControlId Then
                            oScoringControl.SubmissionScoringCriterionSequence = .SubmissionScoringCriterionSeq
                            oScoringControl.SubmissionScoringCriterionDescription = .SubmissionScoringCriterionDescription
                            oScoringControl.ScoringCriterionCode = oScoringControl.ScoringCriterionCode.List(.ScoringCriterionCode).ToCodeObject
                            oScoringControl.AnswerTypeCode = oScoringControl.AnswerTypeCode.List(.AnswerTypeCode).ToCodeObject

                            If oScoringControl.AnswerTypeCode.Code <> "TEXT_BOX" Then
                                oScoringControl.ScoringAnswerCode = oScoringControl.ScoringAnswerCode.List(.ScoringAnswerCode).ToCodeObject
                            Else
                                oScoringControl.ScoringAnswerCode.Code = ""
                            End If
                            oScoringControl.AllowCommentsFlag = .AllowCommentsFlag

                            Exit For
                        End If
                    End With
                Next

            Next

            oScoringControls.Save()
            Return oScoringControls.ValidationIssues
        End If

        Return Nothing
    End Function

    Public Function ABSSubmissionTypeScoringControl_Create(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal ScoringControl As WEB_SUBMISSIONSCORING) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oScoringControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls = ABSSubmissionTypeScoringCriterion_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        Dim CurrCount As Integer = oScoringControls.Count
        If oScoringControls IsNot Nothing Then
            Dim oScoringControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControl = oScoringControls.AddNew

            With ScoringControl
                oScoringControl.SubmissionScoringCriterionSequence = CurrCount + 1
                oScoringControl.SubmissionScoringCriterionDescription = .SubmissionScoringCriterionDescription
                oScoringControl.ScoringCriterionCode = oScoringControl.ScoringCriterionCode.List(.ScoringCriterionCode).ToCodeObject
                oScoringControl.AnswerTypeCode = oScoringControl.AnswerTypeCode.List(.AnswerTypeCode).ToCodeObject
                If oScoringControl.AnswerTypeCode.Code <> "TEXT_BOX" Then
                    oScoringControl.ScoringAnswerCode = oScoringControl.ScoringAnswerCode.List(.ScoringAnswerCode).ToCodeObject
                Else
                    oScoringControl.ScoringAnswerCode.Code = ""
                End If
                oScoringControl.AllowCommentsFlag = .AllowCommentsFlag
            End With

            oScoringControls.Save()
            Return oScoringControls.ValidationIssues
        End If

        Return Nothing
    End Function

    Public Function ABSSubmissionTypeScoringControl_Delete(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal ScoringControl As WEB_SUBMISSIONSCORING) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oScoringControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls = ABSSubmissionTypeScoringCriterion_Get(portalId, ABSCALLCode, SubmissionTypeCode)
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControl = Nothing

        If oScoringControls IsNot Nothing Then

            For Each oScoringControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControl In oScoringControls
                If oScoringControl.AbstractCallSubmissionTypeScoringControlId = ScoringControl.AbstractCallSubmissionTypeScoringControlId Then
                    objToDelete = oScoringControl
                End If
                If oScoringControl.SubmissionScoringCriterionSequence > ScoringControl.SubmissionScoringCriterionSeq Then
                    oScoringControl.SubmissionScoringCriterionSequence = oScoringControl.SubmissionScoringCriterionSequence - 1
                End If
            Next

            If objToDelete IsNot Nothing Then
                oScoringControls.Remove(objToDelete)
                oScoringControls.Save()
            End If

            Return oScoringControls.ValidationIssues
        End If

        Return Nothing
    End Function
    Public Function ABSSubmissionType_GetDisclosureQuestions(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls


        Dim oCallSubTypeDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls

        oCallSubTypeDisclosureQuestions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeDisclosureQuestionControls")
        oCallSubTypeDisclosureQuestions.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, ABSCALLCode)
        oCallSubTypeDisclosureQuestions.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)
        oCallSubTypeDisclosureQuestions.Fill()

        Return oCallSubTypeDisclosureQuestions
    End Function

    Public Function ABSSubmissionType_ScoringControl_Reorder(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal NewOrder As String) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim oScoringControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls = ABSSubmissionTypeScoringCriterion_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        If oScoringControls IsNot Nothing Then

            Dim reorderedRows As String() = NewOrder.Split(",")
            For Each oScoringControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControl In oScoringControls
                For i As Integer = 0 To reorderedRows.Length - 2
                    With oScoringControl
                        If .SubmissionScoringCriterionSequence = CType(reorderedRows(i), Integer) Then
                            .SubmissionScoringCriterionSequence = i + 1
                            Exit For
                        End If
                    End With
                Next
            Next

            oScoringControls.Save()
            Return oScoringControls.ValidationIssues
        End If
        Return Nothing
    End Function

    Public Function ABSSubmissionType_AuthorDisclosure_Reorder(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal NewOrder As String) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim oAuthorDisclosures As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls = ABSSubmissionType_GetAuthorDisclosureQuestions(portalId, ABSCALLCode, SubmissionTypeCode)

        If oAuthorDisclosures IsNot Nothing Then

            Dim reorderedRows As String() = NewOrder.Split(",")
            For Each oAuthorDisclosure As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl In oAuthorDisclosures
                For i As Integer = 0 To reorderedRows.Length - 2
                    With oAuthorDisclosure
                        If .QuestionSequence = CType(reorderedRows(i), Integer) Then
                            .QuestionSequence = i + 1
                            Exit For
                        End If
                    End With
                Next
            Next

            oAuthorDisclosures.Save()
            Return oAuthorDisclosures.ValidationIssues
        End If
        Return Nothing
    End Function

    Public Function ABSSubmissionType_TextBlock_Reorder(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal NewOrder As String) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim oTextBlocks As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls = ABSSubmissionTypeTextBlock_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        If oTextBlocks IsNot Nothing Then

            Dim reorderedRows As String() = NewOrder.Split(",")
            For Each oScoringControl As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControl In oTextBlocks
                For i As Integer = 0 To reorderedRows.Length - 2
                    With oScoringControl
                        If .BlockSequence = CType(reorderedRows(i), Integer) Then
                            .BlockSequence = i + 1
                            Exit For
                        End If
                    End With
                Next
            Next

            oTextBlocks.Save()
            Return oTextBlocks.ValidationIssues
        End If
        Return Nothing
    End Function

    Public Function ABSSubmissionType_DisclosureQuestion_Reorder(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, ByVal NewOrder As String) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim oDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls = ABSSubmissionTypeDisclosureQuestion_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        If oDisclosureQuestions IsNot Nothing Then

            Dim reorderedRows As String() = NewOrder.Split(",")
            For Each oDisclosureQuestion As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControl In oDisclosureQuestions
                For i As Integer = 0 To reorderedRows.Length - 2
                    With oDisclosureQuestion
                        If .QuestionSequence = CType(reorderedRows(i), Integer) Then
                            .QuestionSequence = i + 1
                            Exit For
                        End If
                    End With
                Next
            Next

            oDisclosureQuestions.Save()
            Return oDisclosureQuestions.ValidationIssues
        End If
        Return Nothing
    End Function

    Public Function ABSSubmissionTypeDisclosureQuestion_Get(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeDisclosureQuestionControls

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

        oCallSubTypes = ABSSubmissionType_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        If oCallSubTypes IsNot Nothing And oCallSubTypes.Count > 0 Then
            Return oCallSubTypes(0).AbstractCallSubmissionTypeDisclosureQuestionControls
        End If

        Return Nothing
    End Function

    Public Function ABSSubmissionTypeTextBlock_Get(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTextBlockControls

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes

        oCallSubTypes = ABSSubmissionType_Get(portalId, ABSCALLCode, SubmissionTypeCode)

        If oCallSubTypes IsNot Nothing And oCallSubTypes.Count > 0 Then
            Return oCallSubTypes(0).AbstractCallSubmissionTypeTextBlockControls
        End If

        Return Nothing
    End Function

    Public Function ABSSubmissionType_Topic_Get(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopics

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes = Nothing

        If (Not ABSCALLCode = "") And (Not SubmissionTypeCode = "") Then
            oCallSubTypes = ABSSubmissionType_Get(portalId, ABSCALLCode, SubmissionTypeCode)
        ElseIf (Not ABSCALLCode = "") Then
            oCallSubTypes = ABSSubmissionType_Get(portalId, ABSCALLCode)
        ElseIf (Not SubmissionTypeCode = "") Then
            oCallSubTypes = ABSSubmissionType_Get(portalId, "", SubmissionTypeCode)
        Else
            Dim oAbsSubTypeTopics As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopics

            oAbsSubTypeTopics = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeTopics")
            oAbsSubTypeTopics.Fill()

            Return oAbsSubTypeTopics
        End If


        If oCallSubTypes IsNot Nothing AndAlso oCallSubTypes.Count > 0 Then

            Return oCallSubTypes(0).AbstractCallSubmissionTypeTopics
        End If

        Return Nothing
    End Function
#End Region

#Region "Private Helper Functions"

#Region "Submission type helper"

    Private Sub ABSSubmissionTypeProperties_Execute(ByVal CallSubmissionType As IAbstractCallSubmissionType, ByVal WebCallSubType As WEB_SUBMISSIONTYPE)

        With WebCallSubType

            If .IsChange_SubmissionTypeCode Then
                CallSubmissionType.SubmissionTypeCode = CallSubmissionType.SubmissionTypeCode.List(.SubmissionTypeCode).ToCodeObject
            End If

            If .IsChange_Description Then
                CallSubmissionType.Description = .Description
            End If

            'START SUBMISSION Setting        

            If .IsChange_SubmissionStartDate Then
                If PersonifyWebCommon.isNullDate(.SubmissionStartDate) Then
                    CallSubmissionType.SourceRow("SUBMISSION_TYPE_START_DATE") = DBNull.Value
                Else
                    CallSubmissionType.SubmissionTypeStartDate = .SubmissionStartDate
                End If
            End If

            If .IsChange_SubmissionEndDate Then
                If PersonifyWebCommon.isNullDate(.SubmissionEndDate) Then
                    CallSubmissionType.SourceRow("SUBMISSION_TYPE_END_DATE") = DBNull.Value
                Else
                    CallSubmissionType.SubmissionTypeEndDate = .SubmissionEndDate
                End If
            End If

            If .IsChange_SubmissionWebStartDate Then
                If PersonifyWebCommon.isNullDate(.SubmissionWebStartDate) Then
                    CallSubmissionType.SourceRow("WEB_SUBMITTAL_START_DATE") = DBNull.Value
                Else
                    CallSubmissionType.WebSubmittalStartDate = .SubmissionWebStartDate
                End If
            End If

            If .IsChange_SubmissionWebEndDate Then
                If PersonifyWebCommon.isNullDate(.SubmissionWebEndDate) Then
                    CallSubmissionType.SourceRow("WEB_SUBMITTAL_END_DATE") = DBNull.Value
                Else
                    CallSubmissionType.WebSubmittalEndDate = .SubmissionWebEndDate
                End If
            End If

            If .IsChange_ReviewEndDate Then
                If PersonifyWebCommon.isNullDate(.ReviewEndDate) Then
                    CallSubmissionType.SourceRow("FINAL_REVIEW_DATE") = DBNull.Value
                Else
                    CallSubmissionType.FinalReviewDate = .ReviewEndDate
                End If
            End If

            If .IsChange_AnnouncementDate Then
                If PersonifyWebCommon.isNullDate(.AnnouncementDate) Then
                    CallSubmissionType.SourceRow("ANNOUNCEMENT_DATE") = DBNull.Value
                Else
                    CallSubmissionType.AnnouncementDate = .AnnouncementDate
                End If
            End If

            If .IsChange_ValidateTopicControlCode Then
                CallSubmissionType.ValidateTopicControlCode = CallSubmissionType.ValidateTopicControlCode.List(.ValidateTopicControlCode).ToCodeObject
            End If
            If .IsChange_ValidateKeywordControlCode Then
                CallSubmissionType.ValidateKeywordControlCode = CallSubmissionType.ValidateKeywordControlCode.List(.ValidateKeywordControlCode).ToCodeObject
            End If

            If .IsChange_ValidationTopicCode Then
                CallSubmissionType.ValidationTopicCode = CallSubmissionType.ValidationTopicCode.List(.ValidationTopicCode).ToCodeObject
            End If

            If .IsChange_ValidationKeywordCode Then
                CallSubmissionType.ValidationKeywordCode = CallSubmissionType.ValidationKeywordCode.List(.ValidationKeywordCode).ToCodeObject
            End If



            If .IsChange_MaxSubmissions Then
                CallSubmissionType.MaxSubmissions = .MaxSubmissions
            End If
            If .IsChange_MaxFinalistSubmissions Then
                CallSubmissionType.MaxFinalistSubmissions = .MaxFinalistSubmissions
            End If
            If .IsChange_MaxAcceptedSubmissions Then
                CallSubmissionType.MaxAcceptedSubmissions = .MaxAcceptedSubmissions
            End If
            If .IsChange_DefaultMaxSubmissionsPerAuthor Then
                CallSubmissionType.DefaultMaxSubmissionsPerAuthor = .DefaultMaxSubmissionsPerAuthor
            End If
            If .IsChange_DefaultMaxAcceptedSubmissionsPerAuthor Then
                CallSubmissionType.DefaultMaxAcceptedSubmissionsPerAuthor = .DefaultMaxAcceptedSubmissionsPerAuthor
            End If

            If .IsChange_PrimaryAuthorMustBeMemberFlag Then
                CallSubmissionType.PrimaryAuthorMustBeMemberFlag = .PrimaryAuthorMustBeMemberFlag
            End If
            If .IsChange_AllowViewingByAllAuthorsFlag Then
                CallSubmissionType.AllowViewingByAllAuthorsFlag = .AllowViewingByAllAuthorsFlag
            End If
            If .IsChange_AuthorValidationStoredProcedure Then
                CallSubmissionType.AuthorValidationStoredProcedure = .AuthorValidationStoredProcedure
            End If

            If .IsChange_StaffReviewStageFlag Then
                CallSubmissionType.StaffReviewStageFlag = .StaffReviewStageFlag
            End If

            If .IsChange_FinalistStageFlag Then
                CallSubmissionType.FinalistStageFlag = .FinalistStageFlag
            End If

            'END SUBMISSION Setting

            'START Attachment Setting
            If .IsChange_AllowWebAttachmentFlag Then
                CallSubmissionType.AllowWebAttachmentFlag = .AllowWebAttachmentFlag
                If CallSubmissionType.AllowWebAttachmentFlag Then
                    If .IsChange_MinAttachments Then
                        CallSubmissionType.MinAttachments = .MinAttachments
                    End If
                    If .IsChange_MaxAttachments Then
                        CallSubmissionType.MaxAttachments = .MaxAttachments
                    End If
                Else
                    CallSubmissionType.MinAttachments = 0
                    CallSubmissionType.MaxAttachments = 0
                End If
            End If

            If .IsChange_MaxFileSizeMB Then
                CallSubmissionType.MaxFileSizeMB = .MaxFileSizeMB
            End If
            'End Attachment Setting

            'START Reviewer configuration
            If .IsChange_DefaultDaysToReview Then
                CallSubmissionType.DefaultDaysToReview = .DefaultDaysToReview
            End If
            If .IsChange_DefaultMaxReviewerAssignments Then
                CallSubmissionType.DefaultMaxReviewerAssignments = .DefaultMaxReviewerAssignments
            End If
            If .IsChange_DefaultMaxReviewerOpenAssignments Then
                CallSubmissionType.DefaultMaxReviewerOpenAssignments = .DefaultMaxReviewerOpenAssignments
            End If
            If .IsChange_DefaultMinReqReviewersPerSubmission Then
                CallSubmissionType.DefaultMinReqReviewersPerSubmission = .DefaultMinReqReviewersPerSubmission
            End If

            If .IsChange_ReviewTypeCode Then
                CallSubmissionType.ReviewTypeCode = CallSubmissionType.ReviewTypeCode.List(.ReviewTypeCode).ToCodeObject
            End If
            If .IsChange_ReviewBlindRuleCode Then
                CallSubmissionType.ReviewBlindRuleCode = CallSubmissionType.ReviewBlindRuleCode.List(.ReviewBlindRuleCode).ToCodeObject
            End If

            If .IsChange_ReviewerApprovedForCode Then
                CallSubmissionType.ReviewerApprovedForCode = CallSubmissionType.ReviewerApprovedForCode.List(.ReviewerApprovedForCode).ToCodeObject
            End If

            'END Reviewer configuration
        End With
    End Sub

    Private Sub ABSInstructionType_Execute(ByVal CallSubmissionType As IAbstractCallSubmissionType, ByVal InstructionItems As List(Of WEB_SUBMISSIONTYPE.WEB_ABS_INSTRUCTION))
        Dim isFound As Boolean = False
        Dim toBeDeleted As New List(Of IAbstractCallSubmissionTypeInstruction)
        'START Instruction
        If InstructionItems IsNot Nothing AndAlso InstructionItems.Count > 0 Then
            For i As Integer = 0 To InstructionItems.Count - 1
                Dim ABSInstruction As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeInstruction
                Dim web_Instruction As WEB_SUBMISSIONTYPE.WEB_ABS_INSTRUCTION
                isFound = False
                web_Instruction = InstructionItems(i)
                For Each oInstruction As IAbstractCallSubmissionTypeInstruction In CallSubmissionType.AbstractCallSubmissionTypeInstructions
                    If oInstruction.InstructionTypeCode.Code = web_Instruction.Instruction_Type_Code Then
                        isFound = True
                        If Not String.IsNullOrEmpty(web_Instruction.Instruction_Text) Then
                            ABSInstruction = oInstruction
                            ABSInstruction.Language = web_Instruction.Language
                            ABSInstruction.InstructionText = web_Instruction.Instruction_Text
                        Else
                            toBeDeleted.Add(oInstruction)
                        End If
                        Exit For
                    End If
                Next
                If isFound = False Then
                    If Not String.IsNullOrEmpty(web_Instruction.Instruction_Text) Then
                        ABSInstruction = CallSubmissionType.AbstractCallSubmissionTypeInstructions.AddNew()
                        ABSInstruction.InstructionTypeCode = ABSInstruction.InstructionTypeCode.List(web_Instruction.Instruction_Type_Code).ToCodeObject
                        ABSInstruction.Language = web_Instruction.Language
                        ABSInstruction.InstructionText = web_Instruction.Instruction_Text
                    End If
                End If
                For Each item As IAbstractCallSubmissionTypeInstruction In toBeDeleted
                    CallSubmissionType.AbstractCallSubmissionTypeInstructions.Remove(item)
                Next
            Next
        End If
        'END Instruction
    End Sub

    Private Sub ABSFileTyoesOperation_Execute(ByVal CallSubmissionType As IAbstractCallSubmissionType, ByVal FileTypeItems As List(Of WEB_SUBMISSIONTYPE.WEB_ABS_CODE_ITEM))

        'START File Type         
        If FileTypeItems IsNot Nothing AndAlso FileTypeItems.Count > 0 Then

            Dim oFileTypeControl As IAbstractCallSubmissionTypeFileTypeControl
            Dim oFileTypeControlsHash As Hashtable
            Dim oDeleteFileTypeItemsHash As New Hashtable 'Code value                    

            oFileTypeControlsHash = ABS_FileTypeControl_Hash_Convert(CallSubmissionType.AbstractCallSubmissionTypeFileTypeControls)

            For Each oFileType As WEB_SUBMISSIONTYPE.WEB_ABS_CODE_ITEM In FileTypeItems
                Select Case oFileType.Selected
                    Case True
                        If Not oFileTypeControlsHash.Contains(oFileType.Code) Then
                            'Adding
                            Dim newFileTypeControl As IAbstractCallSubmissionTypeFileTypeControl
                            newFileTypeControl = CallSubmissionType.AbstractCallSubmissionTypeFileTypeControls.AddNew()
                            newFileTypeControl.FileTypeCode = newFileTypeControl.FileTypeCode.List(oFileType.Code).ToCodeObject
                        End If
                    Case False
                        If oFileTypeControlsHash.Contains(oFileType.Code) Then
                            'Deleting object
                            oDeleteFileTypeItemsHash.Add(oFileType.Code, oFileType.Code)
                        End If
                End Select
            Next
            If oDeleteFileTypeItemsHash.Count > 0 Then
                'START Perform delete operation
                Dim oDeleteItems As New List(Of IAbstractCallSubmissionTypeFileTypeControl)
                For Each oFileTypeControl In CallSubmissionType.AbstractCallSubmissionTypeFileTypeControls
                    If oDeleteFileTypeItemsHash.Contains(oFileTypeControl.FileTypeCodeString) Then
                        oDeleteItems.Add(oFileTypeControl)
                    End If
                Next
                For Each oFileTypeControl In oDeleteItems
                    CallSubmissionType.AbstractCallSubmissionTypeFileTypeControls.Remove(oFileTypeControl)
                Next
                'END Perform delete operation
            End If
        End If

    End Sub

#End Region


    Private Function ABS_FileTypeControl_Hash_Convert(ByVal fileTypeControls As IAbstractCallSubmissionTypeFileTypeControls) As Hashtable
        Dim oFileHash As New Hashtable
        For Each oFileType As IAbstractCallSubmissionTypeFileTypeControl In fileTypeControls
            If Not oFileHash.Contains(oFileType.FileTypeCodeString) Then
                oFileHash.Add(oFileType.FileTypeCodeString, oFileType.FileTypeCodeString)
            End If
        Next
        Return oFileHash

    End Function

#End Region

#Region "Reviewer"

    Public Function GetSubmissionReviewerData(ByVal PortalId As Integer, ByVal ReviewerId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers

        oAbstractSubmissionReviewers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionReviewers")
        oAbstractSubmissionReviewers.Filter.Add("AbstractSubmissionReviewerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, ReviewerId)

        oAbstractSubmissionReviewers.Fill()

        Return oAbstractSubmissionReviewers

    End Function


    Public Function GetAbstractCallSubmissionTypeScoringControls(ByVal PortalId As Integer, ByVal AbstractCallCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls

        Dim oAbstractCallSubmissionTypeScoringControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControls

        oAbstractCallSubmissionTypeScoringControls = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeScoringControls")
        oAbstractCallSubmissionTypeScoringControls.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractCallCode)
        oAbstractCallSubmissionTypeScoringControls.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)

        oAbstractCallSubmissionTypeScoringControls.Fill()
        oAbstractCallSubmissionTypeScoringControls.Sort("SubmissionScoringCriterionSequence", ComponentModel.ListSortDirection.Ascending)
        Return oAbstractCallSubmissionTypeScoringControls
    End Function




    Public Function GetReviewerInbox(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal isCOMPLETED As Boolean) As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers




        oAbstractSubmissionReviewers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionReviewers")
        oAbstractSubmissionReviewers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
        oAbstractSubmissionReviewers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
        If isCOMPLETED = True Then
            oAbstractSubmissionReviewers.Filter.Add("AssignmentStatusCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, "COMPLETED")
        Else
            oAbstractSubmissionReviewers.Filter.Add("AssignmentStatusCode", TIMSS.Enumerations.QueryOperatorEnum.IsIn, "'INVITED','UNDER_REVIEW'")
        End If
        oAbstractSubmissionReviewers.Fill()

        Return oAbstractSubmissionReviewers


    End Function

    Public Function SetSubmissionReviewerStatus(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal AbstractSubmissionReviewerId As Integer, ByVal AssignmentStatusCode As String, ByVal AssignmentStatusReasonCode As String) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers


        oAbstractSubmissionReviewers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionReviewers")
        oAbstractSubmissionReviewers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
        oAbstractSubmissionReviewers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
        oAbstractSubmissionReviewers.Filter.Add("AbstractSubmissionReviewerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionReviewerId)
        oAbstractSubmissionReviewers.Fill()

        If oAbstractSubmissionReviewers IsNot Nothing AndAlso oAbstractSubmissionReviewers.Count > 0 AndAlso oAbstractSubmissionReviewers(0) IsNot Nothing Then
            oAbstractSubmissionReviewers(0).AssignmentStatusCode = oAbstractSubmissionReviewers(0).AssignmentStatusCode.List(AssignmentStatusCode).ToCodeObject
            If AssignmentStatusReasonCode IsNot Nothing Then
                oAbstractSubmissionReviewers(0).AssignmentStatusReasonCode = oAbstractSubmissionReviewers(0).AssignmentStatusReasonCode.List(AssignmentStatusReasonCode).ToCodeObject
            End If

            Select Case AssignmentStatusCode
                Case Constants.Const_AssignmentStatus_UnderReview
                    oAbstractSubmissionReviewers(0).EventStatusCode = Constants.Const_EventCode_REVIEWER_ACCEPTS
                Case Constants.Const_AssignmentStatus_Declined
                    oAbstractSubmissionReviewers(0).EventStatusCode = Constants.Const_EventCode_REVIEWER_DECLINES
            End Select

            oAbstractSubmissionReviewers.Save()

            If oAbstractSubmissionReviewers.ValidationIssues.Count > 0 Then
                Return oAbstractSubmissionReviewers.ValidationIssues
            End If
        End If

        Return Nothing
        'ASSIGNMENT_STATUS
        'INVITED
        'UNDER_REVIEW
        'COMPLETED
        'DECLINED
        'WITHDREW
        'CANCELLED
        'ACCEPTED

    End Function

    Public Function GetSubmissionScorings(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer, ByVal AbstractSubmissionReviewerId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionScorings

        Dim oAbstractSubmissionScorings As TIMSS.API.AbstractInfo.IAbstractSubmissionScorings




        oAbstractSubmissionScorings = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionScorings")

        oAbstractSubmissionScorings.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
        oAbstractSubmissionScorings.Filter.Add("AbstractSubmissionReviewerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionReviewerId)

        oAbstractSubmissionScorings.Fill()

        Return oAbstractSubmissionScorings


    End Function

    Public Function GetCustomerSearch(ByVal PortalId As Integer, ByVal FirstName As String, ByVal LastName As String) As IQueryResult



        'Dim cacheKey As String = "GetCustomerSearch" & PortalId & "_" & FirstName & "_" & LastName.ToString
        'If Personify.WebUtility.DataCache.Fetch(cacheKey) Is Nothing Then

        Dim RenewalStoredProcedureRequest As IStoredProcedureRequest = New StoredProcedureRequest("ABS_CustomerSearch")

        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("first_name", FirstName, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("last_name", LastName, ParameterDirection.Input))

        Dim oQueryResult As IQueryResult
        Dim query As IQueryRequest = New QueryRequest(RenewalStoredProcedureRequest)

        oQueryResult = TIMSS.Global.App.Execute(query)

        'Personify.WebUtility.DataCache.Store(cacheKey, oQueryResult)
        'End If
        'Return Personify.WebUtility.DataCache.Fetch(cacheKey)
        Return oQueryResult

    End Function

    Public Function GetReviewersSearch(ByVal PortalId As Integer, ByVal FirstName As String, ByVal LastName As String, ByVal AprovedFor As String, ByVal AreaOfExpertise As String, ByVal LevelOfExpertise As String, ByVal TermEnding As DateTime) As IQueryResult



        'Dim cacheKey As String = "GetCustomerSearch" & PortalId & "_" & FirstName & "_" & LastName.ToString & "_" & AprovedFor & "_" & AreaOfExpertise & "_" & LevelOfExpertise & "_" & TermEnding.ToString
        'If Personify.WebUtility.DataCache.Fetch(cacheKey) Is Nothing Then

        Dim RenewalStoredProcedureRequest As IStoredProcedureRequest = New StoredProcedureRequest("ABS_ReviewerSearch")

        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("first_name", FirstName, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("last_name", LastName, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("reviewer_approved_for_code", AprovedFor, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("expertise_code", AreaOfExpertise, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("expertise_level_code", LevelOfExpertise, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("end_date", TermEnding, ParameterDirection.Input))

        Dim oQueryResult As IQueryResult
        Dim query As IQueryRequest = New QueryRequest(RenewalStoredProcedureRequest)

        oQueryResult = TIMSS.Global.App.Execute(query)

        'Personify.WebUtility.DataCache.Store(cacheKey, oQueryResult)
        'End If
        'Return Personify.WebUtility.DataCache.Fetch(cacheKey)

        Return oQueryResult

    End Function

    Public Function GetSubmissionReviewersSearch(ByVal PortalId As Integer, _
    ByVal AbstractCallCode As String, _
    ByVal SubmissionTypeCode As String, _
    ByVal FirstName As String, _
    ByVal LastName As String, _
    ByVal AprovedFor As String, _
    ByVal AreaOfExpertise As String, _
    ByVal LevelOfExpertise As String, _
    ByVal TermEnding As DateTime, _
    ByVal MaxNumberOfAssignments As Integer, _
    ByVal MaxNumberOfOpenAssignments As Integer) As IQueryResult


        '        Dim cacheKey As String = "ABS_SubmissionReviewerSearch" & PortalId & "_" & SubmissionId & "_" & FirstName & "_" & LastName.ToString & "_" & AprovedFor & "_" & AreaOfExpertise & "_" & LevelOfExpertise & "_" & TermEnding.ToString
        '       If Personify.WebUtility.DataCache.Fetch(cacheKey) Is Nothing Then

        Dim RenewalStoredProcedureRequest As IStoredProcedureRequest = New StoredProcedureRequest("ABS_SubmissionReviewerSearch")

        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("abs_Call_code", AbstractCallCode, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("submission_type_code", SubmissionTypeCode, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("first_name", FirstName, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("last_name", LastName, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("reviewer_approved_for_code", AprovedFor, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("expertise_code", AreaOfExpertise, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("expertise_level_code", LevelOfExpertise, ParameterDirection.Input))       
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("end_date", TermEnding, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("MaxNumberOfAssignments", MaxNumberOfAssignments, ParameterDirection.Input))
        RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("MaxNumberOfOpenAssignments", MaxNumberOfOpenAssignments, ParameterDirection.Input))

        Dim oQueryResult As IQueryResult
        Dim query As IQueryRequest = New QueryRequest(RenewalStoredProcedureRequest)

        oQueryResult = TIMSS.Global.App.Execute(query)
        Return oQueryResult

        '      Personify.WebUtility.DataCache.Store(cacheKey, oQueryResult)
        '     End If
        '    Return Personify.WebUtility.DataCache.Fetch(cacheKey)


    End Function

    Public Class AreaOfExpertise
        Public ExpertiseCode As String
        Public ExpertiseSubcode As String
        Public ExpertiseLevelCode As String
    End Class

    Public Function CreateReviewer(ByVal PortalId As Integer, ByVal Reviewers() As Reviewer, ByVal ReviewerApprovedForCode As String, ByVal ReviewerRoleCode As String, ByVal BeginDate As DateTime, ByVal EndDate As DateTime, ByVal AreaOfExpertises() As AreaOfExpertise) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim _AbstractReviewers As TIMSS.API.AbstractInfo.IAbstractReviewers = Nothing

        _AbstractReviewers = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractReviewers"), TIMSS.API.AbstractInfo.IAbstractReviewers)

        Dim oAbstractReviewer As TIMSS.API.AbstractInfo.IAbstractReviewer = Nothing


        If Reviewers IsNot Nothing AndAlso Reviewers.Length > 0 Then

            For Each oReviewer As Reviewer In Reviewers

                Dim oAbstractReviewers As TIMSS.API.AbstractInfo.IAbstractReviewer
                oAbstractReviewers = _AbstractReviewers.AddNew

                With oAbstractReviewers
                    .MasterCustomerId = oReviewer.MasterCustomerId
                    .SubCustomerId = oReviewer.SubCustomerId

                    If AreaOfExpertises IsNot Nothing AndAlso AreaOfExpertises.Length > 0 Then
                        For Each aoe As AreaOfExpertise In AreaOfExpertises
                            With .AbstractReviewerExpertiseList.AddNew()

                                .ExpertiseCode = .ExpertiseCode.List(aoe.ExpertiseCode).ToCodeObject
                                .ExpertiseSubcode = .ExpertiseSubcode.List(aoe.ExpertiseSubcode).ToCodeObject
                                .ExpertiseLevelCode = .ExpertiseLevelCode.List(aoe.ExpertiseLevelCode).ToCodeObject
                            End With
                        Next
                    End If

                    .Comments = String.Concat(.MasterCustomerId, "-", .SubCustomerId, "-", "-Comments")

                    With .AbstractReviewerTerms.AddNew
                        .ReviewerApprovedForCode = .ReviewerApprovedForCode.List(ReviewerApprovedForCode).ToCodeObject
                        .ReviewerRoleCode = .ReviewerRoleCode.List(ReviewerRoleCode).ToCodeObject
                        '.ActiveFlag = True
                        .EndDate = EndDate
                        .BeginDate = BeginDate
                    End With
                End With
            Next
        End If

        _AbstractReviewers.Save()


        If (_AbstractReviewers IsNot Nothing AndAlso _AbstractReviewers.ValidationIssues IsNot Nothing AndAlso _AbstractReviewers.ValidationIssues.Count > 0) Then
            'OrElse (oAbstractReviewer.AbstractReviewerExpertiseList.ValidationIssues IsNot Nothing AndAlso oAbstractReviewer.AbstractReviewerExpertiseList.ValidationIssues.Count > 0) Then
            Return _AbstractReviewers.ValidationIssues
        End If

        Return Nothing
    End Function

    Public Function GetCallAndSubmissionType(ByVal PortalId As Integer) As TIMSS.API.AbstractInfo.IAbstractCalls


        Dim oABSCalls As TIMSS.API.AbstractInfo.IAbstractCalls

        oABSCalls = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCalls")
        With oABSCalls
            .Fill()
        End With

        Return oABSCalls



    End Function

    Public Class Reviewer
        Public MasterCustomerId As String
        Public SubCustomerId As Integer
    End Class

    Public Function CreateSubmissionTypeReviewer(ByVal PortalId As Integer, ByVal AbstractCallCode As String, ByVal SubmissionTypeCode As String, ByVal Reviewers() As Reviewer) As TIMSS.API.Core.Validation.IIssuesCollection



        If Reviewers IsNot Nothing AndAlso Reviewers.Length > 0 Then

            Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes = Nothing
            oAbstractCallSubmissionTypes = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypes")

            oAbstractCallSubmissionTypes.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractCallCode)
            oAbstractCallSubmissionTypes.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)

            oAbstractCallSubmissionTypes.Fill()

            If oAbstractCallSubmissionTypes IsNot Nothing AndAlso oAbstractCallSubmissionTypes.Count > 0 Then
                For Each r As Reviewer In Reviewers
                    With oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeReviewers.AddNew()
                        '.AbstractCallSubmissionTypeReviewerId = oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeReviewers(0).AbstractCallSubmissionTypeReviewerId
                        .MasterCustomerId = r.MasterCustomerId
                        .SubCustomerId = r.SubCustomerId
                        .ReviewerSourceCode = .ReviewerSourceCode.List("REVIEWER").ToCodeObject
                        .ReviewerRoleCode = .ReviewerSourceCode.List("REVIEWER").ToCodeObject
                        .Comments = String.Concat(.MasterCustomerId, "-", .SubCustomerId, "-", .ReviewerSourceCodeString)
                    End With
                Next
                oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeReviewers.Save()

                If oAbstractCallSubmissionTypes.ValidationIssueResponses IsNot Nothing AndAlso oAbstractCallSubmissionTypes.ValidationIssues.ErrorCount > 0 Then
                    Return oAbstractCallSubmissionTypes.ValidationIssues
                End If
            End If
        End If

        Return Nothing
    End Function


    Public Function CreateSubmissionReviewers(ByVal PortalId As Integer, ByVal SubmissionId As Integer, ByVal AbstractCallSubmissionTypeReviewerIds() As Integer) As TIMSS.API.Core.Validation.IIssuesCollection



        If AbstractCallSubmissionTypeReviewerIds IsNot Nothing AndAlso AbstractCallSubmissionTypeReviewerIds.Length > 0 Then

            Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = Nothing
            oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")

            oAbstractSubmissions.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionId)
            oAbstractSubmissions.Fill()

            If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then
                Dim oAbstractSubmission As TIMSS.API.AbstractInfo.IAbstractSubmission
                oAbstractSubmission = oAbstractSubmissions(0)

                For Each AbstractCallSubmissionTypeReviewerId As Integer In AbstractCallSubmissionTypeReviewerIds
                    With oAbstractSubmission.AbstractSubmissionReviewers.AddNew()
                        '.AbstractCallSubmissionReviewerId = oAbstractSubmissions(0).AbstractCallSubmissionReviewers(0).AbstractCallSubmissionReviewerId
                        .AbstractCallSubmissionTypeReviewerId = AbstractCallSubmissionTypeReviewerId
                        .AssignmentStatusCode = .AssignmentStatusCode.List("INVITED").ToCodeObject
                        .ReviewerRoleCode = .ReviewerRoleCode.List("REVIEWER").ToCodeObject
                        .Comments = String.Concat(.AbstractSubmissionId, "-", .MasterCustomerId, "-", .SubCustomerId, "-", .AssignmentStatusCodeString, "-Comments")
                        .ReviewDueDate = DateTime.Now.AddDays(oAbstractSubmissions(0).AbstractCallSubmissionTypeInfo.DefaultDaysToReview)
                    End With
                Next
                oAbstractSubmission.EventStatusCode = Constants.Const_EventCode_REVIEWER_INVITED
                oAbstractSubmissions.Save()

                If oAbstractSubmissions.ValidationIssues IsNot Nothing AndAlso oAbstractSubmissions.ValidationIssues.ErrorCount > 0 Then
                    Return oAbstractSubmissions.ValidationIssues
                End If
            End If
        End If

        Return Nothing
    End Function



    Public Function CreateSubmissionsReviewers(ByVal PortalId As Integer, ByVal SubmissionId() As Integer, ByVal AbstractCallSubmissionTypeReviewerIds() As Integer) As TIMSS.API.Core.Validation.IIssuesCollection



        If AbstractCallSubmissionTypeReviewerIds IsNot Nothing AndAlso AbstractCallSubmissionTypeReviewerIds.Length > 0 Then

            Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = Nothing
            oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")

            'Dim CustomerIds As String = "'000000000748-0','000000002777-0','000000002928-0','000000003791-0'"
            Dim InSubmissionIds As String = ""
            If SubmissionId IsNot Nothing AndAlso SubmissionId.Length > 0 Then
                For Each aSubmissionId As Integer In SubmissionId
                    If InSubmissionIds.Length > 0 Then InSubmissionIds += ","
                    InSubmissionIds += aSubmissionId.ToString
                Next
            End If

            oAbstractSubmissions.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.IsIn, InSubmissionIds)

            oAbstractSubmissions.Fill()

            If SubmissionId IsNot Nothing AndAlso SubmissionId.Length > 0 Then

                For Each aSubmissionId As Integer In SubmissionId

                    'search for the object
                    Dim index As Integer = -1
                    If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then

                        For i As Integer = 0 To oAbstractSubmissions.Count - 1
                            If oAbstractSubmissions(i).AbstractSubmissionId = aSubmissionId Then
                                index = i
                                Exit For
                            End If
                        Next

                        If index >= 0 Then
                            'create reviewers for it
                            For Each AbstractCallSubmissionTypeReviewerId As Integer In AbstractCallSubmissionTypeReviewerIds
                                With oAbstractSubmissions(index).AbstractSubmissionReviewers.AddNew()
                                    .AbstractCallSubmissionTypeReviewerId = AbstractCallSubmissionTypeReviewerId
                                    .AssignmentStatusCode = .AssignmentStatusCode.List("INVITED").ToCodeObject
                                    .ReviewerRoleCode = .ReviewerRoleCode.List("REVIEWER").ToCodeObject
                                    .Comments = String.Concat(.AbstractSubmissionId, "-", .MasterCustomerId, "-", .SubCustomerId, "-", .AssignmentStatusCodeString, "-Comments")
                                    .EventStatusCode = Constants.Const_EventCode_REVIEWER_INVITED
                                    'to do: DUI changes needed
                                    ' If oAbstractSubmissions(0).AbstractCallSubmissionTypeInfo.DefaultDaysToReview > 0 Then
                                    .ReviewDueDate = DateTime.Now.AddDays(oAbstractSubmissions(0).AbstractCallSubmissionTypeInfo.DefaultDaysToReview).ToShortDateString
                                    'End If

                                End With
                            Next
                        End If

                    End If

                Next

            End If

            oAbstractSubmissions.Save()

            If oAbstractSubmissions.ValidationIssues IsNot Nothing AndAlso oAbstractSubmissions.ValidationIssues.ErrorCount > 0 Then
                Return oAbstractSubmissions.ValidationIssues
            End If
        End If

        Return Nothing
    End Function

    Public Function GetAbstractCallSubmissionTypeReviewers(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers



        'Dim cacheKey As String = "GetAbstractCallSubmissionTypeReviewers" & PortalId.ToString & MasterCustomerId & SubCustomerId.ToString
        'If Personify.WebUtility.DataCache.Fetch(cacheKey) Is Nothing Then



        Dim oAbstractCallSubmissionTypeReviewers As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers

        oAbstractCallSubmissionTypeReviewers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeReviewers")
        oAbstractCallSubmissionTypeReviewers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
        oAbstractCallSubmissionTypeReviewers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)

        oAbstractCallSubmissionTypeReviewers.Fill()

        If oAbstractCallSubmissionTypeReviewers IsNot Nothing And oAbstractCallSubmissionTypeReviewers.Count > 0 Then
            'Personify.WebUtility.DataCache.Store(cacheKey, oAbstractCallSubmissionTypeReviewers)
            Return oAbstractCallSubmissionTypeReviewers
            'Else
            ' Personify.WebUtility.DataCache.Remove(cacheKey)
        End If
        ' End If
        'Return Personify.WebUtility.DataCache.Fetch(cacheKey)

        Return Nothing
    End Function

    Public Function GetCustoemrInfo(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.CustomerInfo.ICustomers

        Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

        oCustomers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
        oCustomers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
        oCustomers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)

        oCustomers.Fill()

        If oCustomers IsNot Nothing And oCustomers.Count > 0 Then
            Return oCustomers
        End If

        Return Nothing
    End Function

    Public Function GetAbstractCallSubmissionTypeReviewers(ByVal PortalId As Integer, ByVal AbsSubTypeReviewerId As Integer) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers



        'Dim cacheKey As String = "GetAbstractCallSubmissionTypeReviewers" & PortalId.ToString & MasterCustomerId & SubCustomerId.ToString
        'If Personify.WebUtility.DataCache.Fetch(cacheKey) Is Nothing Then



        Dim oAbstractCallSubmissionTypeReviewers As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeReviewers

        oAbstractCallSubmissionTypeReviewers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeReviewers")
        oAbstractCallSubmissionTypeReviewers.Filter.Add("AbstractCallSubmissionTypeReviewerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbsSubTypeReviewerId)

        oAbstractCallSubmissionTypeReviewers.Fill()

        If oAbstractCallSubmissionTypeReviewers IsNot Nothing And oAbstractCallSubmissionTypeReviewers.Count > 0 Then
            'Personify.WebUtility.DataCache.Store(cacheKey, oAbstractCallSubmissionTypeReviewers)
            Return oAbstractCallSubmissionTypeReviewers
            'Else
            ' Personify.WebUtility.DataCache.Remove(cacheKey)
        End If
        ' End If
        'Return Personify.WebUtility.DataCache.Fetch(cacheKey)

        Return Nothing
    End Function

    Public Function UpdateAreasOfExpertise(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal AreaOfExpertises() As AreaOfExpertise) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oAbstractReviewers As TIMSS.API.AbstractInfo.IAbstractReviewers = Nothing

        oAbstractReviewers = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractReviewers"), TIMSS.API.AbstractInfo.IAbstractReviewers)



        oAbstractReviewers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
        oAbstractReviewers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)

        oAbstractReviewers.Fill()

        If oAbstractReviewers IsNot Nothing AndAlso oAbstractReviewers.Count > 0 AndAlso oAbstractReviewers(0) IsNot Nothing Then

            With oAbstractReviewers(0)
                'Remove all the expertise list .. and add them again... this is to take care of the deletes
                .AbstractReviewerExpertiseList.RemoveAll()
                If AreaOfExpertises IsNot Nothing AndAlso AreaOfExpertises.Length > 0 Then
                    For Each aoe As AreaOfExpertise In AreaOfExpertises


                        Dim savedExpertiseIndex As Integer = -1
                        If oAbstractReviewers(0).AbstractReviewerExpertiseList IsNot Nothing AndAlso oAbstractReviewers(0).AbstractReviewerExpertiseList.Count > 0 Then
                            For j As Integer = 0 To oAbstractReviewers(0).AbstractReviewerExpertiseList.Count - 1
                                If String.Compare(oAbstractReviewers(0).AbstractReviewerExpertiseList(j).ExpertiseCodeString, aoe.ExpertiseCode, True) = 0 AndAlso String.Compare(oAbstractReviewers(0).AbstractReviewerExpertiseList(j).ExpertiseSubcodeString, aoe.ExpertiseSubcode, True) = 0 Then
                                    savedExpertiseIndex = j
                                    Exit For
                                End If
                            Next
                        End If
                        If savedExpertiseIndex < 0 Then
                            .AbstractReviewerExpertiseList.AddNew()
                            savedExpertiseIndex = .AbstractReviewerExpertiseList.Count - 1
                        End If

                        With .AbstractReviewerExpertiseList(savedExpertiseIndex)
                            .ExpertiseCode = .ExpertiseCode.List(aoe.ExpertiseCode).ToCodeObject
                            .ExpertiseSubcode = .ExpertiseSubcode.List(aoe.ExpertiseSubcode).ToCodeObject
                            .ExpertiseLevelCode = .ExpertiseLevelCode.List(aoe.ExpertiseLevelCode).ToCodeObject
                        End With
                    Next
                End If

                .Comments = String.Concat(.MasterCustomerId, "-", .SubCustomerId, "-", "-Comments")

            End With
            oAbstractReviewers.Save()

        End If

        If (oAbstractReviewers IsNot Nothing AndAlso oAbstractReviewers.ValidationIssues IsNot Nothing AndAlso oAbstractReviewers.ValidationIssues.Count > 0) OrElse (oAbstractReviewers(0).AbstractReviewerExpertiseList.ValidationIssues IsNot Nothing AndAlso oAbstractReviewers(0).AbstractReviewerExpertiseList.ValidationIssues.Count > 0) Then
            Return oAbstractReviewers.ValidationIssues
        End If

        Return Nothing
    End Function

    Public Function GetSubmissions(ByVal PortalId As Integer, ByVal AbstractCallCode As String, ByVal SubmissionTypeCode As String, ByVal ExternalStatusCode As String, ByVal StartDate As DateTime, ByVal EndDate As DateTime) As TIMSS.API.AbstractInfo.IAbstractSubmissions
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions

        oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")

        If AbstractCallCode <> Nothing AndAlso AbstractCallCode.Length > 0 Then oAbstractSubmissions.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractCallCode)
        If SubmissionTypeCode <> Nothing AndAlso SubmissionTypeCode.Length > 0 Then oAbstractSubmissions.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)
        If ExternalStatusCode <> Nothing AndAlso ExternalStatusCode.Length > 0 Then oAbstractSubmissions.Filter.Add("ExternalStatusCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, ExternalStatusCode)
        If StartDate <> Nothing Then oAbstractSubmissions.Filter.Add("SubmissionDate", TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual, StartDate)
        If EndDate <> Nothing Then oAbstractSubmissions.Filter.Add("SubmissionDate", TIMSS.Enumerations.QueryOperatorEnum.LessThanOrEqual, EndDate.AddDays(1))

        oAbstractSubmissions.Fill()

        Return oAbstractSubmissions


    End Function

    Public Function GetMeetings(ByVal PortalId As Integer) As TIMSS.API.Core.SearchObject


        Dim key As String = "GetMeetings" & PortalId
        If PersonifyDataCache.Fetch(key) Is Nothing Then
            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty

            oParm = New TIMSS.API.Core.SearchProperty("Subsystem")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = "MTG"
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("ValidFlag")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = "Y"
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("MasterProductFlag")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = "Y"
            searchObj.Parameters.Add(oParm)

            'Changed to End Date
            oParm = New TIMSS.API.Core.SearchProperty("MeetingProduct.EndDate")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual
            oParm.Value = DateTime.Now
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("ProductId")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            'Added Sort Order
            oParm = New TIMSS.API.Core.SearchProperty("ShortName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            oParm.SortOrder = 1
            searchObj.Parameters.Add(oParm)

            searchObj.Search()

            PersonifyDataCache.Store(key, searchObj)
        End If
        Return PersonifyDataCache.Fetch(key)


    End Function
    Public Function GetSingleMeeting(ByVal PortalId As Integer, ByVal intProductID As Integer) As String
        Dim strMeetingName As String = String.Empty
        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")
        searchObj.EnforceLimits = False

        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("ProductId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = intProductID
        searchObj.Parameters.Add(oParm)

        'Added Sort Order
        oParm = New TIMSS.API.Core.SearchProperty("ShortName")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        oParm.SortOrder = 1
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            strMeetingName = searchObj.Results.Table.Rows(0).Item("ShortName")
        End If
        Return strMeetingName
    End Function

    Public Function GetSessions(ByVal PortalId As Integer, ByVal ProductId As Integer) As TIMSS.API.ProductInfo.IProduct


        Dim Products As TIMSS.API.ProductInfo.IProducts = _
        TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")
        Products.Filter.Add("ProductId", TIMSS.Enumerations.QueryOperatorEnum.Equals, ProductId)
        Products.Fill()
        If Products IsNot Nothing AndAlso Products.Count = 1 Then
            Return Products(0)
        End If

        Return Nothing

    End Function

    Public Function AssignSubmissionsToProducts(ByVal PortalId As Integer, ByVal SubmissionId() As Integer, ByVal ProductIds() As Integer) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = Nothing
        oAbstractSubmissions = CType(TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions"), TIMSS.API.AbstractInfo.IAbstractSubmissions)

        Dim InSubmissionIds As String = ""
        If SubmissionId IsNot Nothing AndAlso SubmissionId.Length > 0 Then
            For Each aSubmissionId As Integer In SubmissionId
                If InSubmissionIds.Length > 0 Then InSubmissionIds += ","
                InSubmissionIds += aSubmissionId.ToString
            Next
        End If

        oAbstractSubmissions.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.IsIn, InSubmissionIds)
        oAbstractSubmissions.Fill()

        If SubmissionId IsNot Nothing AndAlso SubmissionId.Length > 0 Then
            For Each aSubmissionId As Integer In SubmissionId
                'search for the object
                Dim index As Integer = -1
                If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions.Count > 0 Then
                    For i As Integer = 0 To oAbstractSubmissions.Count - 1
                        If oAbstractSubmissions(i).AbstractSubmissionId = aSubmissionId Then
                            index = i
                            Exit For
                        End If
                    Next
                    If index >= 0 Then
                        'create reviewers for it
                        For Each ProductId As Integer In ProductIds
                            If Not SubmissionAssignedToProduct(aSubmissionId, ProductId) Then
                                With oAbstractSubmissions(index).AbstractSubmissionProductLinks.AddNew()
                                    .ProductId = ProductId
                                    'Set the transfer flag
                                    oAbstractSubmissions(index).TransferredFlag = True
                                End With
                            End If
                        Next
                    End If
                End If
            Next
        End If

        oAbstractSubmissions.Save()

        If oAbstractSubmissions Is Nothing OrElse oAbstractSubmissions.ValidationIssues.ErrorCount > 0 Then
            Return oAbstractSubmissions.ValidationIssues
        End If

        Return Nothing
    End Function
    Public Function SubmissionAssignedToProduct(ByVal SubmissionID As Integer, ByVal ProductId As Integer) As Boolean
        Dim blnProductlinkExists As Boolean
        Dim oProductLinks As TIMSS.API.AbstractInfo.IAbstractSubmissionProductLinks
        oProductLinks = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionProductLinks")
        With oProductLinks
            oProductLinks.Filter.Add("AbstractSubmissionId", SubmissionID)
            oProductLinks.Filter.Add("ProductId", ProductId)
            oProductLinks.Fill()
        End With
        If oProductLinks IsNot Nothing AndAlso oProductLinks.Count > 0 Then
            blnProductlinkExists = True
        End If
        Return blnProductlinkExists
    End Function

    Public Function GetAbstractSubmissionReviewer(ByVal PortalId As String, ByVal ReviewerId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers
        Dim CallManager As New CallManagerHelper(OrganizationId(PortalId), OrganizationUnitId(PortalId))

        oAbstractSubmissionReviewers = CallManager.GetSubmissionReviewerData(PortalId, ReviewerId)

        If oAbstractSubmissionReviewers Is Nothing OrElse oAbstractSubmissionReviewers.Count <> 1 Then
            'show message or throw exception; show message expect 1 record but have count
            Return Nothing
        End If
        Return oAbstractSubmissionReviewers(0)
    End Function

#End Region

#Region "Author functions"

    Public Function GetAuthorSubmissions(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors

        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors



        oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors")
        oAbstractSubmissions.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
        oAbstractSubmissions.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
        oAbstractSubmissions.Fill()

        Return oAbstractSubmissions

    End Function

    Public Function GetAbstractSubmissionTypeKeywords(ByVal PortalId As Integer, ByVal AbstractCallCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeKeywords
        Dim oAbstractSubmissionTypeKeywords As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeKeywords


        oAbstractSubmissionTypeKeywords = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeKeywords")
        oAbstractSubmissionTypeKeywords.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractCallCode)
        oAbstractSubmissionTypeKeywords.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)

        oAbstractSubmissionTypeKeywords.Fill()

        Return oAbstractSubmissionTypeKeywords
    End Function

    Public Function GetAbstractSubmissionTypeTopics(ByVal PortalId As Integer) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopics
        Dim oAbstractSubmissionTypeTopics As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopics


        oAbstractSubmissionTypeTopics = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeTopics")
        oAbstractSubmissionTypeTopics.Filter.Add("PrimaryTopicFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
        oAbstractSubmissionTypeTopics.Fill()

        Return oAbstractSubmissionTypeTopics
    End Function

    Public Function GetInstruction(ByVal PortalId As Integer, ByVal InstructionTypeCode As String, ByVal AbstractCallCode As String, ByVal SubmissionTypeCode As String) As String
        Dim oAbstractSubmissionInstructions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeInstructions

        Dim instruction As String = String.Empty

        oAbstractSubmissionInstructions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeInstructions")
        oAbstractSubmissionInstructions.Filter.Add("InstructionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, InstructionTypeCode)
        oAbstractSubmissionInstructions.Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractCallCode)
        oAbstractSubmissionInstructions.Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)
        oAbstractSubmissionInstructions.Fill()
        If oAbstractSubmissionInstructions IsNot Nothing AndAlso oAbstractSubmissionInstructions.Count > 0 AndAlso oAbstractSubmissionInstructions(0) IsNot Nothing Then
            instruction = oAbstractSubmissionInstructions(0).InstructionText
        End If

        Return instruction
    End Function


    Public Function GetSubmissionAuthors(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors

        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors



        oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors")
        oAbstractSubmissions.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
        oAbstractSubmissions.Fill()

        Return oAbstractSubmissions
    End Function

    Public Function GetSubmission(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmission

        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions

        oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")
        oAbstractSubmissions.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
        oAbstractSubmissions.Fill()
        If oAbstractSubmissions IsNot Nothing AndAlso oAbstractSubmissions(0) IsNot Nothing Then
            Return oAbstractSubmissions(0)
        End If

        Return Nothing
    End Function

    Public Function GetSubmissionTextBlocks(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlocks

        Dim oAbstractSubmissionTextBlocks As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlocks

        oAbstractSubmissionTextBlocks = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionTextBlocks")
        oAbstractSubmissionTextBlocks.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
        oAbstractSubmissionTextBlocks.Fill()

        oAbstractSubmissionTextBlocks.Sort("BlockSequence", ComponentModel.ListSortDirection.Ascending)

        Return oAbstractSubmissionTextBlocks

    End Function

    Public Function GetSubmissionAttachments(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles

        Dim oAbstractSubmissionAttachments As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles



        oAbstractSubmissionAttachments = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionFiles")
        oAbstractSubmissionAttachments.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
        oAbstractSubmissionAttachments.Fill()

        Return oAbstractSubmissionAttachments

    End Function

    Public Function GetSubmissionDisclosures(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionDisclosures

        Dim oAbstractSubmissionDisclosures As TIMSS.API.AbstractInfo.IAbstractSubmissionDisclosures

        oAbstractSubmissionDisclosures = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionDisclosures")
        oAbstractSubmissionDisclosures.Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
        oAbstractSubmissionDisclosures.Fill()


        Return oAbstractSubmissionDisclosures
    End Function

    Public Function GetAbstractSubmission(ByVal PortalId As Integer, ByVal SubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissions
        Dim oAbstractSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions


        oAbstractSubmissions = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")
        oAbstractSubmissions.Filter.Add("AbstractSubmissionid", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionId)
        oAbstractSubmissions.Fill()

        Return oAbstractSubmissions
    End Function

    Public Sub RemoveAttachment(ByVal PortalId As Integer, ByVal AbstractsubmissionId As Integer, ByVal AbstractSubmissionFileId As Integer)


        Dim oAbstractSubmissionAttachments As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractSubmissionFile = Nothing

        oAbstractSubmissionAttachments = GetSubmissionAttachments(PortalId, AbstractsubmissionId)

        For Each oAbstractSubmissionAttachment As TIMSS.API.AbstractInfo.IAbstractSubmissionFile In oAbstractSubmissionAttachments
            If oAbstractSubmissionAttachment.AbstractSubmissionFileId = AbstractSubmissionFileId Then
                objToDelete = oAbstractSubmissionAttachment
            End If
        Next
        If objToDelete IsNot Nothing Then

            Dim filename As String = objToDelete.FileName
            Dim AdditionalPathExtension As String = String.Concat(objToDelete.AbstractSubmissionInfo.AbstractCallCode, "\", objToDelete.AbstractSubmissionInfo.SubmissionTypeCode, "\", AbstractsubmissionId)

            oAbstractSubmissionAttachments.Remove(objToDelete)
            oAbstractSubmissionAttachments.Save()

            TIMSS.ThirdPartyInterfaces.FileOperation.DeleteFile(TIMSS.Server.BusinessMessages.FileUploadDownload.UploadResourceType.AbstractFiles, filename, AdditionalPathExtension)
        End If
    End Sub

    Public Function GetAuthorHistory(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal subCustomerId As Integer) As DataTable


        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")
        searchObj.EnforceLimits = False

        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("Title")
        oParm.UseInQuery = False
        oParm.ShowInResults = True        
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionAuthors.MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionAuthors.SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = subCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.AbstractSubmissionActivityId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.NewAssignmentStatusCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.NewExternalStatusCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.NewInternalStatusCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.PreviousExternalStatusCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.PreviousInternalStatusCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.ReviewerMasterCustomerId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.ReviewProcessEventCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionActivities.ReviewProcessEventDate")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        Return searchObj.Results.Table

    End Function


    Public Function GetAuthorReviews(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal subCustomerId As Integer) As DataTable


        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")
        searchObj.EnforceLimits = False

        Dim oParm As TIMSS.API.Core.SearchProperty

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionAuthors.MasterCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = MasterCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionAuthors.SubCustomerId")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = subCustomerId
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.AbstractSubmissionReviewerId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.CommentsFromReviewer")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.AbstractCallSubmissionTypeReviewerInfo.CustomerInfo.LabelName")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)


        oParm = New TIMSS.API.Core.SearchProperty("AbstractSubmissionReviewers.AbstractSubmissionInfo.Title")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        Return searchObj.Results.Table

    End Function

    Public Function GetAuthors(ByVal PortalId As Integer _
, ByVal FirstName As String _
, ByVal LastName As String _
, ByVal CompanyInstitutionName As String _
, ByVal NameCredentials As String _
, ByVal EmailAddress As String _
, ByVal Phone As String _
, ByVal City As String _
, ByVal State As String _
) As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors


        Dim AbstractSubmissionAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        AbstractSubmissionAuthors = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors")
        With AbstractSubmissionAuthors
            If FirstName IsNot Nothing AndAlso FirstName.Length > 0 Then .Filter.Add("FirstName", TIMSS.Enumerations.QueryOperatorEnum.StartsWith, FirstName)
            If LastName IsNot Nothing AndAlso LastName.Length > 0 Then .Filter.Add("LastName", TIMSS.Enumerations.QueryOperatorEnum.StartsWith, LastName)
            If CompanyInstitutionName IsNot Nothing AndAlso CompanyInstitutionName.Length > 0 Then .Filter.Add("CompanyInstitutionName", TIMSS.Enumerations.QueryOperatorEnum.StartsWith, CompanyInstitutionName)
            If NameCredentials IsNot Nothing AndAlso NameCredentials.Length > 0 Then .Filter.Add("NameCredentials", TIMSS.Enumerations.QueryOperatorEnum.Equals, NameCredentials)
            If EmailAddress IsNot Nothing AndAlso EmailAddress.Length > 0 Then .Filter.Add("EmailAddress", TIMSS.Enumerations.QueryOperatorEnum.StartsWith, EmailAddress)
            If Phone IsNot Nothing AndAlso Phone.Length > 0 Then .Filter.Add("Phone", TIMSS.Enumerations.QueryOperatorEnum.Contains, Phone)
            If City IsNot Nothing AndAlso City.Length > 0 Then .Filter.Add("City", TIMSS.Enumerations.QueryOperatorEnum.StartsWith, City)
            If State IsNot Nothing AndAlso State.Length > 0 Then .Filter.Add("State", TIMSS.Enumerations.QueryOperatorEnum.StartsWith, State)
            .Fill()
        End With

        Return AbstractSubmissionAuthors
    End Function

    Public Function GetAuthor(ByVal PortalId As Integer, ByVal AuthorId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor


        Dim AbstractSubmissionAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        AbstractSubmissionAuthors = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors")
        With AbstractSubmissionAuthors
            .Filter.Add("AbstractSubmissionAuthorId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AuthorId)
            .Fill()
        End With

        If AbstractSubmissionAuthors IsNot Nothing AndAlso AbstractSubmissionAuthors.Count > 0 Then
            Return AbstractSubmissionAuthors(0)
        Else
            Return Nothing
        End If
    End Function

    Public Function GetAuthors(ByVal PortalId As Integer, ByVal AbstractSubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors


        Dim AbstractSubmissionAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        AbstractSubmissionAuthors = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionAuthors")
        With AbstractSubmissionAuthors
            .Filter.Add("AbstractSubmissionId", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractSubmissionId)
            .Fill()
        End With

        If AbstractSubmissionAuthors IsNot Nothing AndAlso AbstractSubmissionAuthors.Count > 0 Then
            Return AbstractSubmissionAuthors
        Else
            Return Nothing
        End If
    End Function

    Public Function GetAbstractCallSubmissionTypeFileTypeControls(ByVal PortalId As Integer, ByVal AbstractCallCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeFileTypeControls

        Dim oAbstractCallSubmissionTypeFileTypeControls As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeFileTypeControls
        oAbstractCallSubmissionTypeFileTypeControls = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeFileTypeControls")
        With oAbstractCallSubmissionTypeFileTypeControls
            .Filter.Add("AbstractCallCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, AbstractCallCode)
            .Filter.Add("SubmissionTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubmissionTypeCode)
            .Fill()
        End With

        If oAbstractCallSubmissionTypeFileTypeControls IsNot Nothing AndAlso oAbstractCallSubmissionTypeFileTypeControls.Count > 0 Then
            Return oAbstractCallSubmissionTypeFileTypeControls
        Else
            Return Nothing
        End If
    End Function


    Public Function GetCustomer(ByVal PortalId As Integer, ByVal CreateNewCustomer As Boolean, ByVal FirstName As String, ByVal LastName As String, ByVal Email As String, ByVal CountryCode As String, ByVal City As String, ByVal State As String, ByVal Address1 As String, ByVal Address2 As String, ByVal ZipCode As String) As TIMSS.API.CustomerInfo.ICustomers

        Dim ocps As New OneClickDonationParameters
        With ocps
            .AddrLine1 = Address1
            .AddrLine2 = Address2
            .AddrLine3 = ""
            .AddrLine4 = ""
            .City = City
            .EMail = Email
            .FirstName = FirstName
            .LastName = LastName
            .State = State
            .ZipCode = ZipCode
            .AddrCountryCode = CountryCode
            .AddressTypeCode = "HOME"
            .MCID = ""
        End With
        Dim clsAM As OrderCheckOutProcessHelper
        clsAM = New OrderCheckOutProcessHelper(OrganizationId, OrganizationUnitId)
        Return clsAM.GetOneClickCustomer(ocps, CreateNewCustomer)
    End Function
#End Region

#Region "Create Web Class Type"

    Public Function Helper_Create_TextBlock_Class(ByVal CallCode As String, ByVal CallSubType As String, ByVal blockTypeCode As String, ByVal seq As Integer, ByVal heading As String, ByVal visibilityCode As Boolean, ByVal maxWordCount As Integer, ByVal text As String) As WEB_SUBMISSIONTEXTBLOCK

        Dim item As New WEB_SUBMISSIONTEXTBLOCK
        item.Call_Code = CallCode
        item.SubmissionTypeCode = CallSubType
        item.BlockType = blockTypeCode
        item.BlockSeq = seq
        item.Heading = heading
        item.MaxWordCount = maxWordCount
        item.VisiblityCode = visibilityCode
        item.InstructionText = text
        Return item

    End Function

#End Region

#Region "Product functions"

    Public Function CallMeetingProducts_Get(ByVal PortalId As Integer) As TIMSS.API.ProductInfo.IProducts


        Dim oMeetingProducts As TIMSS.API.ProductInfo.IProducts
        Dim strIN As New System.Text.StringBuilder


        Dim strCacheKey As String

        strCacheKey = "CallMeetingProductsInfo"

        oMeetingProducts = CType(PersonifyDataCache.Fetch(strCacheKey), TIMSS.API.ProductInfo.IProducts)
        'oMeetingProducts(0).ShortName
        'oMeetingProducts(0).ProductCode
        If oMeetingProducts Is Nothing Then

            oMeetingProducts = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")

            oMeetingProducts.Filter.Add("Subsystem", "MTG")

            oMeetingProducts.Filter.Add(New FilterItem("PARENT_PRODUCT = Product_Code"))
            oMeetingProducts.Filter.Add("Subsystem", "MTG")
            oMeetingProducts.Filter.Add("ProductStatusCode", "A")

            oMeetingProducts.Fill()
            oMeetingProducts.Sort("ShortName", ComponentModel.ListSortDirection.Ascending)

            PersonifyDataCache.Store(strCacheKey, oMeetingProducts, PersonifyDataCache.CacheExpirationInterval)
        End If

        Return oMeetingProducts





        'Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        'searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")
        'searchObj.EnforceLimits = False
        ''need to find why out this parameter is added by default: product id
        'searchObj.Parameters(0).UseInQuery = False
        'searchObj.Parameters(0).ShowInResults = True

        'Dim oParm As TIMSS.API.Core.SearchProperty
        'Dim t As TIMSS.API.ProductInfo.IProduct
        ''t.ParentProduct

        'oParm = New TIMSS.API.Core.SearchProperty("ShortName")
        'oParm.UseInQuery = False
        'oParm.ShowInResults = True
        'searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("ProductCode")
        'oParm.UseInQuery = False
        'oParm.ShowInResults = True
        'searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("ParentProduct")
        'oParm.UseInQuery = False
        'oParm.ShowInResults = True
        'searchObj.Parameters.Add(oParm)

        ''oParm = New TIMSS.API.Core.SearchProperty("WebControl.ActiveFlag")
        ''oParm.UseInQuery = True
        ''oParm.ShowInResults = False
        ''oParm.Value = "Y"
        ''searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("MasterProductFlag")
        'oParm.UseInQuery = True
        'oParm.ShowInResults = False
        'oParm.Value = "Y"
        'searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("Subsystem")
        'oParm.UseInQuery = True
        'oParm.ShowInResults = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.Contains
        'oParm.Value = "MTG"
        'searchObj.Parameters.Add(oParm)



        'oParm = New TIMSS.API.Core.SearchProperty("WebControl.EcommerceBeginDate")
        'oParm.UseInQuery = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.LessThanOrEqual
        'oParm.ShowInResults = True
        'oParm.Value = TIMSS.Common.Functions.ShortDate(TIMSS.Global.App.ServerDateTime.Date)
        'searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("WebControl.EcommerceEndDate")
        'oParm.UseInQuery = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual
        'oParm.ShowInResults = True
        'oParm.Value = TIMSS.Common.Functions.ShortDate(TIMSS.Global.App.ServerDateTime.Date)
        'searchObj.Parameters.Add(oParm)


        'oParm = New TIMSS.API.Core.SearchProperty("WebControl.EcommerceEndDate")
        'oParm.UseInQuery = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.IsNull
        'oParm.ShowInResults = True
        'searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("MeetingProduct.LastRegistrationDate")
        'oParm.UseInQuery = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual
        'oParm.ShowInResults = True
        'oParm.Value = TIMSS.Common.Functions.ShortDate(TIMSS.Global.App.ServerDateTime.Date)
        'searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("MeetingProduct.LastRegistrationDate")
        'oParm.UseInQuery = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.IsNull
        'oParm.ShowInResults = True
        'searchObj.Parameters.Add(oParm)






        'searchObj.Search()

        'Return searchObj.Results.Table
    End Function


    Public Function isInAbstractSubmissionProductLink(ByVal PortalId As Integer, ByVal ProductId As Integer) As Boolean


        Dim Products As TIMSS.API.AbstractInfo.IAbstractSubmissionProductLinks = _
        TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionProductLinks")
        Products.Filter.Add("ProductId", TIMSS.Enumerations.QueryOperatorEnum.Equals, ProductId)
        Products.Fill()
        If Products IsNot Nothing AndAlso Products.Count = 1 AndAlso Products(0).ProductId = ProductId Then
            Return True
        Else
            Return False
        End If
    End Function


#End Region

#Region "ABSSubmissionType AbstractCallSubmissionType Staffs"
    'Get Abstract Call SubmissionType All Staff Information
    Public Function ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Get(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs


        Dim oAbstractCallSubmissionTypeStaffs As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs
        oAbstractCallSubmissionTypeStaffs = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeStaffs")
        oAbstractCallSubmissionTypeStaffs.Filter.Add("AbstractCallCode", ABSCALLCode)
        oAbstractCallSubmissionTypeStaffs.Filter.Add("SubmissionTypeCode", SubmissionTypeCode)
        oAbstractCallSubmissionTypeStaffs.Fill()

        Return oAbstractCallSubmissionTypeStaffs
    End Function

    'Get Abstract Call SubmissionType Single Staff Information
    Public Function ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Get(ByVal portalId As Integer, ByVal intCallSubmissionTypeStaffID As Integer) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs


        Dim oAbstractCallSubmissionTypeStaffs As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs
        oAbstractCallSubmissionTypeStaffs = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeStaffs")
        oAbstractCallSubmissionTypeStaffs.Filter.Add("AbstractCallSubmissionTypeStaffId", intCallSubmissionTypeStaffID)
        oAbstractCallSubmissionTypeStaffs.Fill()

        Return oAbstractCallSubmissionTypeStaffs
    End Function

    'Get Abstract Call SubmissionType Single Staff Information
    Public Function ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Exists(ByVal portalId As Integer, ByVal ABSCALLCode As String, ByVal SubmissionTypeCode As String, _
                                                                                        ByVal strMasterCustomerID As String, ByVal intSubCustomerID As Integer, _
                                                                                            ByVal strRoleCode As String) As Boolean

        Dim blnStaffExists As Boolean
        Dim oAbstractCallSubmissionTypeStaffs As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs
        oAbstractCallSubmissionTypeStaffs = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeStaffs")
        oAbstractCallSubmissionTypeStaffs.Filter.Add("AbstractCallCode", ABSCALLCode)
        oAbstractCallSubmissionTypeStaffs.Filter.Add("SubmissionTypeCode", SubmissionTypeCode)
        oAbstractCallSubmissionTypeStaffs.Filter.Add("MasterCustomerId", strMasterCustomerID)
        oAbstractCallSubmissionTypeStaffs.Filter.Add("SubCustomerId", intSubCustomerID)
        oAbstractCallSubmissionTypeStaffs.Filter.Add("StaffRoleCode", strRoleCode)
        oAbstractCallSubmissionTypeStaffs.Fill()

        If oAbstractCallSubmissionTypeStaffs.Count > 0 Then
            blnStaffExists = True
        End If
        Return blnStaffExists
    End Function

    'Update Abstract Call SubmissionType Staff Information
    Public Function ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Insert(ByVal portalId As Integer, ByVal oAbstractCallSubmissionTypeStaffs As ArrayList) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim oSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim oStaff As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaff
        Dim Item As SubmissionTypeStaff
        oSubmissionTypes = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypes")

        With oSubmissionTypes
            .Filter.Add("AbstractCallCode", oAbstractCallSubmissionTypeStaffs(0).AbstractCallCode)
            .Filter.Add("SubmissionTypeCode", oAbstractCallSubmissionTypeStaffs(0).SubmissionTypeCode)
            .Fill()
        End With

        For Each Item In oAbstractCallSubmissionTypeStaffs
            'Check if the Staff already exists
            If Not ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Exists(portalId, oSubmissionTypes(0).AbstractCallCode, oSubmissionTypes(0).SubmissionTypeCode.Code, _
                                                                        Item.MasterCustomerID, Item.SubCustomerID, Item.StaffRoleCode) Then
                oStaff = oSubmissionTypes(0).AbstractCallSubmissionTypeStaffs.AddNew()
                oStaff.MasterCustomerId = Item.MasterCustomerID
                oStaff.SubCustomerId = Item.SubCustomerID
                oStaff.StaffRoleCode.Code = Item.StaffRoleCode
                oStaff.EmailAddress = Item.EmailAddress
                oStaff.ActiveFlag = True
                If Item.StaffRoleCode = "ADMINISTRATOR" Then
                    oStaff.AdministratorFlag = True
                End If
            End If
        Next Item

        oSubmissionTypes.Save()

        Return oSubmissionTypes.ValidationIssues
    End Function

    'Update Abstract Call SubmissionType Staff Information
    Public Function ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Update(ByVal portalId As Integer, ByVal intCallSubmissionTypeStaffId As Integer, _
                                                ByVal strEmail As String, ByVal strRoleCode As String) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oStaffs As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs

        oStaffs = ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Get(portalId, intCallSubmissionTypeStaffId)
        If oStaffs.Count > 0 Then
            oStaffs(0).StaffRoleCode.Code = strRoleCode
            oStaffs(0).EmailAddress = strEmail
        End If

        oStaffs.Save()

        Return oStaffs.ValidationIssues
    End Function

    'Update Abstract Call SubmissionType Staff Information
    Public Function ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Delete(ByVal portalId As Integer, ByVal intCallSubmissionTypeStaffId As Integer) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim oStaffs As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeStaffs

        oStaffs = ABSSubmissionType_AbstractCallSubmissionTypeStaffs_Get(portalId, intCallSubmissionTypeStaffId)

        If oStaffs.Count > 0 Then
            oStaffs.Remove(oStaffs(0))
        End If

        oStaffs.Save()

        Return oStaffs.ValidationIssues
    End Function
    'Customer Search to assign the Staff
    Public Function ABSSubmissionTypeStaff_Search(ByVal portalID As Integer, ByVal strFirstName As String, _
                                                ByVal strLastName As String) As DataTable
        'ByVal strRole As String

        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAbstractStaffRoles")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty

        'Show only active Staff
        oParm = New TIMSS.API.Core.SearchProperty("ActiveFlag")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.DefaultValue = "Y"
        searchObj.Parameters.Add(oParm)

        'Show only active Customers
        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.CustomerStatusCode")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.DefaultValue = "ACTIVE"
        searchObj.Parameters.Add(oParm)

        'Show only Individuals
        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.RecordType")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        oParm.Value = "I"
        searchObj.Parameters.Add(oParm)

        'Show only Primary Address
        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.AddressDetails.PrioritySeq")
        oParm.UseInQuery = True
        oParm.ShowInResults = True
        oParm.Value = 0
        searchObj.Parameters.Add(oParm)

        If Not String.IsNullOrEmpty(strFirstName) Then
            oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.FirstName")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.StartsWith
            oParm.Value = strFirstName
            searchObj.Parameters.Add(oParm)
        End If
        If Not String.IsNullOrEmpty(strLastName) Then
            oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.LastName")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.StartsWith
            oParm.Value = strLastName
            searchObj.Parameters.Add(oParm)
        End If
        'oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.AddressDetails.Address.Address1")
        'oParm.UseInQuery = False
        'oParm.ShowInResults = True
        'oParm.Value = strCity
        'searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("StaffRoleCode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        'oParm.Value = strRole
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.AddressDetails.Address.City")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.StartsWith
        'oParm.Value = strCity
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.AddressDetails.Address.State")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        'oParm.Operator = TIMSS.Enumerations.QueryOperatorEnum.StartsWith
        'oParm.Value = strState
        searchObj.Parameters.Add(oParm)

        'oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.AddressDetails.Address.PostalCode")
        'oParm.UseInQuery = False
        'oParm.ShowInResults = True
        'searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.LabelName")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("CustomerInfo.PrimaryEmailAddress")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            'Change the E-Mail Column Name
            searchObj.Results.Table.Columns(6).ColumnName = "EMail"

        End If

        Return searchObj.Results.Table

    End Function


#End Region

#Region "Call Topics and Keywords"

    'Get all the Subtopics for the CallTopics or Keywords
    Public Function ABSSubmissionType_TopicsKeywords_Get(ByVal PortalId As Integer, ByVal strTopicOrKeyword As String) As SortedList

        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
        Dim AllSubTopics As New SortedList

        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.ApplicationInfo, "ApplicationSubcodes")
        searchObj.EnforceLimits = False

        'Set up the search fields
        Dim oParm As TIMSS.API.Core.SearchProperty
        oParm = New TIMSS.API.Core.SearchProperty("Type")
        oParm.UseInQuery = True
        oParm.ShowInResults = False
        'Assign the Topic or Keyword
        oParm.Value = strTopicOrKeyword
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("Subcode")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        oParm = New TIMSS.API.Core.SearchProperty("Description")
        oParm.UseInQuery = False
        oParm.ShowInResults = True
        searchObj.Parameters.Add(oParm)

        searchObj.Search()

        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            For Each Row As System.Data.DataRow In searchObj.Results.Table.Rows
                If Not AllSubTopics.Contains(Row.Item(3)) Then
                    AllSubTopics.Add(Row.Item(3), Row.Item(4))
                End If
            Next
        End If

        Return AllSubTopics

    End Function

    'Get all the Existing Topics
    Public Function ABSSubmissionType_ExistingTopics_Get(ByVal PortalId As Integer, ByVal CallCode As String, _
                                                            ByVal SubmissionType As String) As Hashtable

        Dim oExistingTopicHash As New Hashtable
        Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        oAbstractCallSubmissionTypes = ABSSubmissionType_Get(PortalId, CallCode, SubmissionType)

        'If oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics.Count > 0 Then
        For Each Topic As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopic In oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics
            If Not oExistingTopicHash.Contains(Topic.TopicCode) Then
                oExistingTopicHash.Add(Topic.TopicCode, Topic.TopicCode)
            End If
        Next
        'End If

        Return oExistingTopicHash

    End Function

    'Get all the Existing Keywords
    Public Function ABSSubmissionType_ExistingKeywords_Get(ByVal PortalId As Integer, ByVal CallCode As String, _
                                                            ByVal SubmissionType As String) As Hashtable

        Dim oExistingKeywordsHash As New Hashtable
        Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        oAbstractCallSubmissionTypes = ABSSubmissionType_Get(PortalId, CallCode, SubmissionType)

        If oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords.Count > 0 Then
            For Each Keyword As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeKeyword In oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords
                If Not oExistingKeywordsHash.Contains(Keyword.KeywordCode) Then
                    oExistingKeywordsHash.Add(Keyword.KeywordCode, Keyword.KeywordCode)
                End If
            Next
        End If

        Return oExistingKeywordsHash

    End Function

    'Update Abstract Call SubmissionType Staff Information
    Public Function ABSSubmissionType_Topics_Update(ByVal portalId As Integer, ByVal Topics As WEB_SUBMISSIONTYPE) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim blnExists As Boolean

        Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim oSubmissionTypeTopic As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopic
        Dim oNewSubmissionTypeTopic As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeTopic

        Dim oDeleteSubmissionTypeTopics As System.Collections.ArrayList
        oDeleteSubmissionTypeTopics = New System.Collections.ArrayList

        oAbstractCallSubmissionTypes = ABSSubmissionType_Get(portalId, Topics.Call_Code, Topics.SubmissionTypeCode)

        If Topics.ABSCallTopics_Get.Count > 0 Then
            For i As Integer = 0 To Topics.ABSCallTopics_Get.Count - 1
                blnExists = False
                If oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics.Count > 0 Then
                    For Each oSubmissionTypeTopic In oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics
                        'If the Topic already exits
                        If oSubmissionTypeTopic.TopicCode = Topics.ABSCallTopics_Get.Item(i).Code Then
                            'If the Topic is selected again
                            If Topics.ABSCallTopics_Get.Item(i).Selected Then
                                blnExists = True
                                Exit For
                            Else
                                'If the Topic is not selected remove it
                                oDeleteSubmissionTypeTopics.Add(oSubmissionTypeTopic)
                            End If
                        End If
                    Next
                End If

                'If the Topic doesn't exist and is selected now
                If Not blnExists AndAlso Topics.ABSCallTopics_Get.Item(i).Selected Then
                    oNewSubmissionTypeTopic = oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics.AddNew()
                    oNewSubmissionTypeTopic.AbstractCallCode = Topics.Call_Code
                    oNewSubmissionTypeTopic.SubmissionTypeCode = Topics.SubmissionTypeCode
                    oNewSubmissionTypeTopic.TopicCode = Topics.ABSCallTopics_Get.Item(i).Code
                End If
            Next
        End If

        'Delete the Unselected Call Topics
        For i As Integer = 0 To oDeleteSubmissionTypeTopics.Count - 1
            oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics.Remove(oDeleteSubmissionTypeTopics.Item(i))
        Next

        oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics.Save()
        Return oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeTopics.ValidationIssues

    End Function


    'Update Abstract Call SubmissionType Staff Information
    Public Function ABSSubmissionType_Keywords_Update(ByVal portalId As Integer, ByVal Keywords As WEB_SUBMISSIONTYPE) As TIMSS.API.Core.Validation.IIssuesCollection


        Dim blnExists As Boolean

        Dim oAbstractCallSubmissionTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        Dim oSubmissionTypeKeyword As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeKeyword
        Dim oNewSubmissionTypeKeyword As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeKeyword

        Dim oDeleteSubmissionTypeKeywords As System.Collections.ArrayList
        oDeleteSubmissionTypeKeywords = New System.Collections.ArrayList

        oAbstractCallSubmissionTypes = ABSSubmissionType_Get(portalId, Keywords.Call_Code, Keywords.SubmissionTypeCode)

        If Keywords.ABSCallKeywords_Get.Count > 0 Then
            For i As Integer = 0 To Keywords.ABSCallKeywords_Get.Count - 1
                blnExists = False
                If oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords.Count > 0 Then
                    For Each oSubmissionTypeKeyword In oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords
                        'If the Keyword already exits
                        If oSubmissionTypeKeyword.KeywordCode = Keywords.ABSCallKeywords_Get.Item(i).Code Then
                            'If the Keyword is selected again
                            If Keywords.ABSCallKeywords_Get.Item(i).Selected Then
                                blnExists = True
                                Exit For
                            Else
                                'If the Keyword is not selected remove it
                                oDeleteSubmissionTypeKeywords.Add(oSubmissionTypeKeyword)
                            End If
                        End If
                    Next
                End If

                'If the Keyword doesn't exist and is selected now
                If Not blnExists AndAlso Keywords.ABSCallKeywords_Get.Item(i).Selected Then
                    oNewSubmissionTypeKeyword = oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords.AddNew()
                    oNewSubmissionTypeKeyword.AbstractCallCode = Keywords.Call_Code
                    oNewSubmissionTypeKeyword.SubmissionTypeCode = Keywords.SubmissionTypeCode
                    oNewSubmissionTypeKeyword.KeywordCode = Keywords.ABSCallKeywords_Get.Item(i).Code
                End If
            Next
        End If


        'Delete the Unselected Call Keywords
        For i As Integer = 0 To oDeleteSubmissionTypeKeywords.Count - 1
            oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords.Remove(oDeleteSubmissionTypeKeywords.Item(i))
        Next

        oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords.Save()
        Return oAbstractCallSubmissionTypes(0).AbstractCallSubmissionTypeKeywords.ValidationIssues

    End Function

#End Region
End Class
