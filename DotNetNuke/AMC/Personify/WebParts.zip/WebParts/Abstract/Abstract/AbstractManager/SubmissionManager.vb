Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports TIMSS.API.Core

Imports System.Collections.Generic

Public Class SubmissionManagerHelper
    Inherits BaseHelperClass


    Public Sub New(ByVal OrgId As String, ByVal OrgUnitId As String)
        MyBase.New(OrgId, OrgUnitId)
    End Sub

#Region "Submissions"
    'Search parameters passed in as string with format of [PropertyName],[UseInQuery],[ShowInResults],[Operator],[Value];
    Public Function ABS_Submission_Get(ByVal portalid As Integer, ByVal Parameters As List(Of TIMSS.API.Core.SearchProperty)) As System.Data.DataTable


        Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)

        searchObj.Target = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissions")
        searchObj.EnforceLimits = False

        For Each Parameter As TIMSS.API.Core.SearchProperty In Parameters
            searchObj.Parameters.Add(Parameter)
        Next

        searchObj.Search()
        If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
            Return searchObj.Results.Table
        End If
        Return Nothing
    End Function

    Public Function CheckIfRecordExist(ByRef Submissions As List(Of WEB_SUBMISSION), ByVal oSubmission As DataRow) As Boolean
        For Each submission As WEB_SUBMISSION In Submissions
            If submission.AbstractSubmissionId = CType(oSubmission.Item("AbstractSubmissionId"), Integer) Then
                submission = AppendAuthors(submission, oSubmission)
                Return True
            End If
        Next
        Return False
    End Function

    Public Function ABS_Submission_Update(ByVal portalid As Integer, ByVal AbsSubId As Integer, ByVal EventCodeAction As String) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)

        Dim oSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = CallManager.GetAbstractSubmission(portalid, AbsSubId)

        If oSubmissions IsNot Nothing And oSubmissions.Count > 0 Then            
            oSubmissions(0).EventStatusCode = EventCodeAction
            oSubmissions(0).Validate()
            oSubmissions.Save()
            Return oSubmissions.ValidationIssues        
        End If

        Return Nothing
    End Function

    'Public Function ABS_Submission_Update(ByVal portalid As Integer, ByVal AbsSubId As Integer, ByVal ExternalStatus As String, ByVal InternalStatus As String) As TIMSS.API.Core.Validation.IIssuesCollection
    '    Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
    '    Dim oSubmissions As TIMSS.API.AbstractInfo.IAbstractSubmissions = CallManager.GetAbstractSubmission(portalid, AbsSubId)

    '    If oSubmissions IsNot Nothing And oSubmissions.Count > 0 Then
    '        oSubmissions(0).ExternalStatusCode.Code = ExternalStatus
    '        oSubmissions(0).InternalStatusCode.Code = InternalStatus
    '        oSubmissions.Save()
    '        Return oSubmissions.ValidationIssues

    '    End If
    '    Return Nothing
    'End Function

    Public Function AppendAuthors(ByVal Submission As WEB_SUBMISSION, ByVal NewSubmission As DataRow) As WEB_SUBMISSION
        If Submission.AbstractSubmissionAuthors Is Nothing Then
            Submission.AbstractSubmissionAuthors = String.Concat(Submission.AbstractSubmissionAuthors, NewSubmission.Item("AbstractSubmissionAuthors.FirstName").ToString, " ", NewSubmission.Item("AbstractSubmissionAuthors.LastName").ToString)
        Else
            Submission.AbstractSubmissionAuthors = String.Concat(Submission.AbstractSubmissionAuthors, ", ", NewSubmission.Item("AbstractSubmissionAuthors.FirstName").ToString, " ", NewSubmission.Item("AbstractSubmissionAuthors.LastName").ToString)
        End If

        Return Submission
    End Function

    Public Function ABS_Submission_AuthorDisclosureControl_Get(ByVal portalId As Integer, ByVal AbsSubmissionAuthorDisclosureId As Integer) As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControl


        Dim oAuthorDisclosureQuestions As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeAuthorDisclosureControls = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractCallSubmissionTypeAuthorDisclosureControls")

        oAuthorDisclosureQuestions.Filter.Add("ABS_CALL_SUBMISSION_TYPE_AUTHOR_DISCLOSURE_CONTROL_ID", AbsSubmissionAuthorDisclosureId)
        oAuthorDisclosureQuestions.Fill()

        If oAuthorDisclosureQuestions.Count > 0 Then
            Return oAuthorDisclosureQuestions(0)
        End If

        Return Nothing
    End Function

    Public Function ABS_Submission_Author_Delete(ByVal portalId As Integer, ByVal SubmissionId As Integer, ByVal SubmissionAuthorId As Integer) As TIMSS.API.Core.Validation.IIssuesCollection
        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
        Dim oAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors = CallManager.GetSubmission(portalId, SubmissionId).AbstractSubmissionAuthors
        Dim objToDelete As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypeScoringControl = Nothing

        If oAuthors IsNot Nothing Then

            For Each oAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAuthors
                If SubmissionAuthorId = oAuthor.AbstractSubmissionAuthorId Then
                    oAuthors.Remove(oAuthor)
                    Exit For
                End If
            Next

            oAuthors.Save()

            Return oAuthors.ValidationIssues
        End If

        Return Nothing
    End Function

    Public Function GetCustomer(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As String) As TIMSS.API.CustomerInfo.ICustomer

        Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

        oCustomers = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
        With oCustomers
            .Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
            .Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
            .Fill()
        End With
        Return oCustomers(0)
    End Function

    Public Function ABSSubmissionReviwer_Update(ByVal PortalId As Integer, ByVal SubmissionId As Long, ByVal WebSubmissionReviewer As WEB_SUBMISSIONREVIEWER) As TIMSS.API.Core.Validation.IIssuesCollection



        Dim oSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers
        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
        oSubmissionReviewers = CallManager.GetSubmission(PortalId, SubmissionId).AbstractSubmissionReviewers

        If oSubmissionReviewers IsNot Nothing AndAlso oSubmissionReviewers.Count > 0 Then
            For Each oSubmissionReviewer As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewer In oSubmissionReviewers
                If oSubmissionReviewer.AbstractSubmissionReviewerId = WebSubmissionReviewer.AbstractSubmissionReviewerId Then
                    oSubmissionReviewer.AssignmentStatusCode = oSubmissionReviewer.AssignmentStatusCode.List(WebSubmissionReviewer.AssignmentStatusCodeDescription).ToCodeObject
                    oSubmissionReviewer.CommentsToReviewer = WebSubmissionReviewer.CommentsToReviewer
                    oSubmissionReviewer.ReviewDueDate = WebSubmissionReviewer.ReviewDueDate
                    Exit For
                End If
            Next

            oSubmissionReviewers.Save()

            Return oSubmissionReviewers.ValidationIssues
        End If

        Return Nothing

    End Function
#End Region
#Region "Submission Topic"

#End Region

#Region "Submission Product Link"


    Public Function ABS_Submission_ProductLinks_Get(ByVal portalId As Integer, ByVal SubmissionId As Integer) As TIMSS.API.AbstractInfo.IAbstractSubmissionProductLinks

        Dim oSubmissionProudctLinks As TIMSS.API.AbstractInfo.IAbstractSubmissionProductLinks
        oSubmissionProudctLinks = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.AbstractInfo, "AbstractSubmissionProductLinks")

        With oSubmissionProudctLinks
            .Filter.Add("AbstractSubmissionId", SubmissionId)
            .Fill()
        End With

        If oSubmissionProudctLinks IsNot Nothing AndAlso oSubmissionProudctLinks.Count > 0 Then
            Return oSubmissionProudctLinks
        End If

        Return Nothing
    End Function


#End Region


End Class
