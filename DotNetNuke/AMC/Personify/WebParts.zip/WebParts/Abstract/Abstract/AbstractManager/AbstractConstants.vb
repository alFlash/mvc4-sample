Public Class Constants

    Public Const Const_Not_Applicable As String = "N/A"
    Public Const Const_Validation_None As String = "NONE"
    Public Const Const_Validation_SystemCode As String = "SYSTEM_LIST"
    Public Const Const_Validation_Custom As String = "SUBMISSION_TYPE_LIST"

    Public Const Const_Submission_Keyword_Type As String = "SUBMISSION_KEYWORD"
    Public Const Const_Submission_Topic_Type As String = "SUBMISSION_TOPIC"

    Public Const Const_InstructionType_Author As String = "AUTHOR_CREATE_SUBMISSION"
    Public Const Const_InstructionType_Attachment As String = "SUBMISSION_ATTACHMENTS"
    Public Const Const_InstructionType_Material As String = "MATERIAL_SUBMISSION"
    Public Const Const_InstructionType_ThankYou As String = "SUBMISSION_THANK_YOU"
    Public Const Const_InstructionType_Assignment As String = "REVIEWER_ASSIGNMENT"
    Public Const Const_InstructionType_Socring As String = "REVIEWER_SCORING"
    Public Const Const_InstructionType_Override As String = "WEB_SUBMITTAL_OVERRIDE"


    Public Const Const_ReviewRule_Single As String = "SINGLE_BLIND"
    Public Const Const_ReviewRule_Double As String = "DOUBLE_BLIND"
    Public Const Const_ReviewRule_Open As String = "OPEN"

    Public Const Const_ReviewBy_Reviewer As String = "REVIEWER"
    Public Const Const_ReviewBy_Board As String = "REVIEW_BOARD"
    Public Const Const_ReviewBy_Chair As String = "REVIEW_BD_CHAIR_SCORES"

    Public Const Const_RelationshipType_Employment As String = "Employment"

    'Public Const Const_Web_Submittal_Override As String = "REVIEWER"
    'Public Const Const_Web_Submittal_Override As String = "WEB_SUBMITTAL_OVERRIDE"
    'Public Const Const_Web_Submittal_Override As String = "WEB_SUBMITTAL_OVERRIDE"

    'Public Const Const_ExternalCode_Returned As String = "RETURNED"
    'Public Const Const_ExternalCode_Accepted As String = "ACCEPTED"
    'Public Const Const_ExternalCode_Declined As String = "DECLINED"

    Public Const Const_InternalCode_NeedAuthorChanges As String = "NEED_AUTHOR_CHANGES"

    Public Const Const_AssignToReviewer As String = "AssignToReviewer"
    Public Const Const_AssignToSession As String = "AssignToSession"

    Public Const Const_EmailListSessionName As String = "EmailList"

    Public Const Const_AssignmentStatus_Invited As String = "INVITED"
    Public Const Const_AssignmentStatus_UnderReview As String = "UNDER_REVIEW"
    Public Const Const_AssignmentStatus_Completed As String = "COMPLETED"
    Public Const Const_AssignmentStatus_Declined As String = "DECLINED"
    Public Const Const_AssignmentStatus_Withdraw As String = "WITHDREW"
    Public Const Const_AssignmentStatus_Cancelled As String = "CANCELLED"
    Public Const Const_AssignmentStatus_ReturnReview As String = "RETURN_REVIEW"

    Public Const Const_EventCode_ACCEPTED_AS_FINALIST As String = "ACCEPTED_AS_FINALIST"
    Public Const Const_EventCode_ACCEPTED_FOR_REVIEW As String = "ACCEPTED_FOR_REVIEW"
    Public Const Const_EventCode_DRAFT_SAVED As String = "DRAFT_SAVED"
    Public Const Const_EventCode_NOT_ACCEPTED_FOR_REVIEW As String = "NOT_ACCEPTED_FOR_REVIEW"
    Public Const Const_EventCode_REVIEWER_ACCEPTS As String = "REVIEWER_ACCEPTS"
    Public Const Const_EventCode_REVIEWER_DECLINES As String = "REVIEWER_DECLINES"
    Public Const Const_EventCode_REVIEWER_INVITED As String = "REVIEWER_INVITED"
    Public Const Const_EventCode_REVIEWER_WITHDRAWS As String = "REVIEWER_WITHDRAWS"
    Public Const Const_EventCode_RVWR_REVIEW_COMPLETED As String = "RVWR_REVIEW_COMPLETED"
    Public Const Const_EventCode_RVWR_REVIEW_RETURNED As String = "RVWR_REVIEW_RETURNED"
    Public Const Const_EventCode_SUBMISSION_ACCEPTED As String = "SUBMISSION_ACCEPTED"
    Public Const Const_EventCode_SUBMISSION_DECLINED As String = "SUBMISSION_DECLINED"
    Public Const Const_EventCode_SUBMISSION_SUBMITTED As String = "SUBMISSION_SUBMITTED"
   
    Public Const Const_InternalStatus_Final_Decision As String = "FINAL_DECISION"

#Region "Messages"

    Public Const Const_Save_Message As String = "Changes saved successfully"
    Public Const Const_SubmissionTypeReviewer_Added As String = "Submission type reviewer(s) added"
    Public Const Const_SubmissionTypeReviewerError_Added As String = "Addubg submission type reviewer(s) encounter an error - please make sure your reviewer(s) are valid"
    Public Const Primary_Author_Error_Message As String = "Primary author do not meet the requirements"
    Public Const Const_PageError_Meesage As String = "Please enter required field(s)"
    Public Const Const_PageError_AuthorRequirement As String = "Please create at least one author disclosure question"
    Public Const Const_ContentPageError As String = "You have exceeded the word count. Please check your content."
    Public Const Const_FileTypeError As String = "File types are required"
#End Region

End Class


