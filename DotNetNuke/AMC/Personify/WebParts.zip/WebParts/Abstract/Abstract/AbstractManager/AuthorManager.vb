Imports TIMSS.API.Core
Imports Personify.ApplicationManager.Commons
Imports TIMSS.SQLObjects
Imports personify.ApplicationManager.Codes
Imports Personify.ApplicationManager.DataTransfer
Imports Personify.WebUtility.SessionManager

Public Class AuthorManager
#Region " Author Functions "

#End Region
End Class
