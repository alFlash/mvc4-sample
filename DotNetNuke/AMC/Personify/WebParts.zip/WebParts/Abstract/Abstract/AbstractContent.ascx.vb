Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports TIMSS.API.Core.ValidationIssues
Imports TIMSS.API.Core.Validation
Imports Personify.ApplicationManager.PersonifyEnumerations

Namespace Personify.DNN.Modules.Abstract

    Public MustInherit Class AbstractContent
        Inherits AbstractScreenBase
        'Inherits Entities.Modules.PortalModuleBase
        'Implements Entities.Modules.IActionable
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        'Protected WithEvents PanelContent As Panel
        Protected WithEvents ajaxPanel As Telerik.Web.UI.RadAjaxPanel
        Protected WithEvents RadLoadingPanel As Telerik.Web.UI.RadAjaxLoadingPanel

#End Region


#Region "Variables / Properties"

            
#End Region

#Region "Screens"

        Private Function IsQueryParametersValid() As Boolean
            If Request("s") IsNot Nothing Then
                Return True
            End If
            Return False
        End Function

        Private Sub InitScreen()
            Dim controlName As String
            Dim control As System.Web.UI.Control
            Dim controlLoadValid As Boolean
            Dim controlAccessType As ScreenController.ABS_Security_Role
            'If IsQueryParametersValid() Then            
            controlName = ScreenController.Screen_GetName(Request("s"))

            If controlName IsNot Nothing Then
                controlAccessType = ScreenController.Screen_RequiredAccessCheck(Request("s"))
                Select Case controlAccessType
                    Case ScreenController.ABS_Security_Role.Admin
                        controlLoadValid = HasAdminAccess
                    Case ScreenController.ABS_Security_Role.SubTypeStaff_General
                        controlLoadValid = HasSubmissionTypeAccess(ScreenController.ABS_Security_Role.SubTypeStaff_General)
                    Case ScreenController.ABS_Security_Role.SubTypeStaff_Specific                        
                        controlLoadValid = HasSubmissionTypeAccess(ScreenController.ABS_Security_Role.SubTypeStaff_Specific)
                    Case ScreenController.ABS_Security_Role.ALL
                        controlLoadValid = True
                End Select

                If controlLoadValid Then
                    control = LoadControl(controlName)                  
                    ajaxPanel.Controls.Add(control)
                End If
            End If
        End Sub

        Private Function AllowAccess(ByVal ScreenName As ScreenController.AbstractScreen) As Boolean

            Select Case ScreenName
                Case ScreenController.AbstractScreen.Admin_AuthorDetails

                Case ScreenController.AbstractScreen.Admin_AuthorRequirements
                Case ScreenController.AbstractScreen.Admin_DefineCallParticipation
                Case ScreenController.AbstractScreen.Admin_DisclosureDetails

            End Select

        End Function
        'Private Sub SetupControl()
        '    If Not Page.IsPostBack Then


        '        PanelBarList.LoadContentFile("DesktopModules\Personify - Abstract\Controls\Menu\ABSPanelBarMenu.xml")

        '        For Each item As Telerik.Web.UI.RadPanelItem In PanelBarList.Items
        '            If Not String.IsNullOrEmpty(item.NavigateUrl) Then
        '                'item.NavigateUrl must equals S=XXX
        '                item.NavigateUrl = item.NavigateUrl.Replace("[AMPS]", "&")
        '                item.NavigateUrl = NavigateURL("", item.NavigateUrl)
        '            End If
        '            If item.Items.Count > 0 Then
        '                For Each childItem As Telerik.Web.UI.RadPanelItem In item.Items
        '                    If Not String.IsNullOrEmpty(childItem.NavigateUrl) Then
        '                        'item.NavigateUrl must equals S=XXX
        '                        childItem.NavigateUrl = childItem.NavigateUrl.Replace("[AMPS]", "&")
        '                        childItem.NavigateUrl = NavigateURL("", childItem.NavigateUrl)
        '                    End If
        '                Next
        '            End If
        '        Next

        '    End If
        'End Sub


#End Region

#Region "Event Handlers"

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            If Framework.AJAX.IsInstalled Then
                DotNetNuke.Framework.AJAX.RegisterScriptManager()
            End If

            If Not IsPersonifyWebUserLoggedIn Then
                Dim role As String = GetUserRole(UserInfo)
                If Not (role = "host" OrElse role = "admin" OrElse role = "personifyadmin") Then
                    RedirectToLogin()
                End If
            End If
            RadLoadingPanel.BackgroundPosition = Telerik.Web.UI.AjaxLoadingPanelBackgroundPosition.Center
            RadLoadingPanel.EnableSkinTransparency = True
            InitScreen()

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'Decide which menu to use
                'If Not IsPostBack Then
                '    PanelMenu.FullPath = "DesktopModules\Personify - Abstract\Controls\Menu\ABSPanelBarMenu.xml"
                'End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region "Optional Interfaces"

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object


#End Region



#Region "Helper functions"

        Public Sub RedirectToLogin()
            Dim LoginURLBuilder As New System.Text.StringBuilder
            LoginURLBuilder.Append("~/Default.aspx?tabid=")
            LoginURLBuilder.Append(PortalSettings.LoginTabId)
            LoginURLBuilder.Append("&returnurl=")
            LoginURLBuilder.Append(HttpUtility.UrlEncode(Request.Url.AbsoluteUri))
            Me.Response.Redirect(LoginURLBuilder.ToString, True)
        End Sub

        Private Function GetMessageIcon(ByVal iconType As IssueSeverityEnum) As String

            Select Case iconType
                Case IssueSeverityEnum.Information
                    Return "~/DefaultPersonifyImages/timss-info-green.gif"
                Case IssueSeverityEnum.Question
                    Return "~/DefaultPersonifyImages/timss-question-blue.gif"
                Case IssueSeverityEnum.Warning
                    Return "~/DefaultPersonifyImages/timss-warning-yellow.gif"
                Case IssueSeverityEnum.Error
                    Return "~/DefaultPersonifyImages/timss-error-red.gif"
            End Select

            Return ""
        End Function



#End Region


    End Class

End Namespace
