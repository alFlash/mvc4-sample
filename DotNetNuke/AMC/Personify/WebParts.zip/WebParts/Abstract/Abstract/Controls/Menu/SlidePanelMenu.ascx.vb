Imports Telerik.Web.UI

Namespace Personify.DNN.Modules.Abstract
    Partial Class SlidePanelMenu
        Inherits System.Web.UI.UserControl

#Region "Controls"

#End Region


#Region "Public functions"
        Public Sub AddContent(ByVal control As Control)
            'pnlMenuContent.Controls.Add(control)

        End Sub
#End Region




    End Class

End Namespace
