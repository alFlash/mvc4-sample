﻿Imports Microsoft.VisualBasic
Imports System.Collections
Imports System.ComponentModel

Public Class ReviewerInbox

#Region "Properties"

    Public ReadOnly Property OrganizationId(ByVal PortalId As Integer) As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId(ByVal PortalId As Integer) As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

#End Region

    Public Sub New()

    End Sub

    Public Function GetData(ByVal PortalId As String, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal isCOMPLETED As Boolean, ByVal NextScreen As Integer, ByVal isReadOnly As Boolean) As ICollection

        Dim list As ArrayList = New ArrayList()

        Dim oAbstractSubmissionReviewers As TIMSS.API.AbstractInfo.IAbstractSubmissionReviewers

        'oAbstractSubmissions(0).AssignmentStatusCodeString
        Dim CallManager As New CallManagerHelper(OrganizationId(PortalId), OrganizationUnitId(PortalId))
        oAbstractSubmissionReviewers = CallManager.GetReviewerInbox(PortalId, MasterCustomerId, SubCustomerId, isCOMPLETED)

        If oAbstractSubmissionReviewers IsNot Nothing AndAlso oAbstractSubmissionReviewers.Count > 0 Then

            For i As Integer = 0 To oAbstractSubmissionReviewers.Count - 1
                Dim row As ReviewerInboxData = New ReviewerInboxData()

                row.AbstractCallTitle = oAbstractSubmissionReviewers(i).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title
                row.SubmissionTypeCode = oAbstractSubmissionReviewers(i).AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCode.Description
                'row.Status = oAbstractSubmissionReviewers(0).AbstractSubmissionInfo.ExternalStatusCode.Description
                row.Title = oAbstractSubmissionReviewers(i).AbstractSubmissionInfo.Title

                
                row.LinkText = "View Details"
                Select Case oAbstractSubmissionReviewers(i).AssignmentStatusCodeString
                    Case Constants.Const_AssignmentStatus_Invited
                        row.FirstColumn = "Invitation to do a Review"

                    Case Constants.Const_AssignmentStatus_UnderReview
                        row.LinkText = "Work on Review"
                        row.FirstColumn = "Pending Review"

                    Case Constants.Const_AssignmentStatus_Completed
                        row.FirstColumn = "Completed Review"

                    Case Constants.Const_AssignmentStatus_Declined
                        row.FirstColumn = "Declinded Review"
                End Select
                


                row.AbstractSubmissionId = oAbstractSubmissionReviewers(i).AbstractSubmissionInfo.AbstractSubmissionId
                row.AbstractSubmissionReviewerId = oAbstractSubmissionReviewers(i).AbstractSubmissionReviewerId

                row.Link = ScreenController.AbstractScreen.Reviewer_Invitation

                If oAbstractSubmissionReviewers(i).AssignmentStatusCodeString = "INVITED" And isReadOnly = False Then
                    row.Link = NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_Invitation & "&srid=" & row.AbstractSubmissionReviewerId.ToString)
                Else
                    row.Link = NavigateURL("", "s=" & ScreenController.AbstractScreen.Reviewer_ReviewSubmission & "&srid=" & row.AbstractSubmissionReviewerId.ToString)
                End If

                If Not PersonifyWebCommon.isNullDate(oAbstractSubmissionReviewers(i).ReviewDueDate) Then
                    row.DueDate = oAbstractSubmissionReviewers(i).ReviewDueDate.ToShortDateString
                Else
                    row.DueDate = "N/A"
                End If


                list.Add(row)

            Next

        End If

        Return list
    End Function



End Class