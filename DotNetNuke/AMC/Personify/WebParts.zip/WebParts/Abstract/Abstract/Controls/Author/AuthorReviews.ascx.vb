Imports Telerik.Web.UI
Imports System.Collections.Generic

Public Class AuthorReviews
    Inherits System.Web.UI.UserControl

#Region "Constants"
    Private Const single_blind_type As String = "SINGLE_BLIND"
    Private Const double_blind_type As String = "DOUBLE_BLIND"
    Private Const open_type As String = "OPEN"

#End Region
#Region "Properties"
    Public Property MasterCustomerId() As String
        Get
            Return _masterCustomerId
        End Get
        Set(ByVal value As String)
            _masterCustomerId = value
        End Set
    End Property

    Public Property SubCustomerId() As Integer
        Get
            Return _subCustomerId
        End Get
        Set(ByVal value As Integer)
            _subCustomerId = value
        End Set
    End Property

    Public ReadOnly Property OrganizationId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

    Public Property PortalId() As Integer
        Get
            Return _portalId
        End Get
        Set(ByVal value As Integer)
            _portalId = value
        End Set
    End Property

    Public Property CallCode() As String
        Get
            Return _callCode
        End Get
        Set(ByVal value As String)
            _callCode = value
        End Set
    End Property
    Public Property SubTypeCode() As String
        Get
            Return _subTypeCode
        End Get
        Set(ByVal value As String)
            _subTypeCode = value
        End Set
    End Property

#End Region

#Region "Controls"

    Protected WithEvents RadGridAuthorReviews As RadGrid

    Private _masterCustomerId As String
    Private _subCustomerId As Integer
    Private _portalId As Integer

    Private _callCode As String
    Private _subTypeCode As String

#End Region
#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub

    Protected Sub RadGridAuthorReviews_NeedDataSource(ByVal [source] As Object, _
   ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()

        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)

        Dim oCallSubTypes As TIMSS.API.AbstractInfo.IAbstractCallSubmissionTypes
        oCallSubTypes = CallManager.ABSSubmissionType_Get(PortalId, CallCode, SubTypeCode)

        If oCallSubTypes IsNot Nothing AndAlso oCallSubTypes.Count > 0 Then
            If oCallSubTypes(0).ReviewBlindRuleCodeString = open_type Then
                Dim oAuthorReviews As DataTable
                oAuthorReviews = CallManager.GetAuthorReviews(PortalId, MasterCustomerId, SubCustomerId)

                For Each oAuthorReview As DataRow In oAuthorReviews.Rows
                    Dim oAuthorReviewTemp As New AuthorReview()
                    With oAuthorReviewTemp
                        If oAuthorReview("AbstractSubmissionReviewers.CommentsFromReviewer") IsNot System.DBNull.Value Then
                            .CommentsFromReviewer = CType(oAuthorReview("AbstractSubmissionReviewers.CommentsFromReviewer"), String)
                        End If
                        If oAuthorReview("AbstractSubmissionReviewers.AbstractCallSubmissionTypeReviewerInfo.CustomerInfo.LabelName") IsNot System.DBNull.Value Then
                            .ReviewerName = CType(oAuthorReview("AbstractSubmissionReviewers.AbstractCallSubmissionTypeReviewerInfo.CustomerInfo.LabelName"), String)
                        End If

                        If oAuthorReview("AbstractSubmissionReviewers.AbstractSubmissionInfo.Title") IsNot System.DBNull.Value Then
                            .SubmissionTitle = CType(oAuthorReview("AbstractSubmissionReviewers.AbstractSubmissionInfo.Title"), String)
                        End If
                        If oAuthorReview("AbstractSubmissionReviewers.AbstractSubmissionReviewerId") IsNot System.DBNull.Value Then
                            .AbstractSubmissionReviewerId = CType(oAuthorReview("AbstractSubmissionReviewers.AbstractSubmissionReviewerId"), String)
                        End If
                    End With
                    list.Add(oAuthorReviewTemp)
                Next

            End If
        End If
        RadGridAuthorReviews.DataSource = list
    End Sub
#End Region

#Region "Helper functions"

    

#End Region
#Region "Public functions"


#End Region



End Class
