Imports Telerik.Web.UI

Public Class ReviewerInboxControl
    Inherits System.Web.UI.UserControl



#Region "Properties"
    Public Property MasterCustomerId() As String
        Get
            Return _masterCustomerId
        End Get
        Set(ByVal value As String)
            _masterCustomerId = value
        End Set
    End Property

    Public Property SubCustomerId() As Integer
        Get
            Return _subCustomerId
        End Get
        Set(ByVal value As Integer)
            _subCustomerId = value
        End Set
    End Property

    Public Property PortalId() As Integer
        Get
            Return PortalId
        End Get
        Set(ByVal value As Integer)
            _portalId = value
        End Set
    End Property

    Private _Link As String = Nothing
    Public Property Link() As String
        Get
            Return _Link
        End Get
        Set(ByVal value As String)
            _Link = value
        End Set
    End Property

    'Private _WebThemeName As String = Nothing
    'Public Property WebThemeName() As String
    '    Get
    '        Return _WebThemeName
    '    End Get
    '    Set(ByVal value As String)
    '        _WebThemeName = value
    '        'pnlReviewerInbox.CssClass = WebThemeName + "_pnlReviewerInbox"
    '    End Set
    'End Property

    Private _isCOMPLETED As Boolean
    Public Property isCOMPLETED() As Boolean
        Get
            Return _isCOMPLETED
        End Get
        Set(ByVal value As Boolean)
            _isCOMPLETED = value
        End Set
    End Property

    Private _isReadOnly As Boolean
    Public Property isReadOnly() As Boolean
        Get
            Return _isReadOnly
        End Get
        Set(ByVal value As Boolean)
            _isReadOnly = value
        End Set
    End Property

#End Region

#Region "Controls"
    Protected WithEvents RadGrid1 As Telerik.Web.UI.RadGrid
    
    'Protected WithEvents RadGridAuthorSubmission As Telerik.Web.UI.RadGrid
    Private _masterCustomerId As String
    Private _subCustomerId As Integer
    Private _portalId As Integer
#End Region

#Region "Public functions"


#End Region


    Private Sub RadGrid1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGrid1.NeedDataSource
        Dim ri As New ReviewerInbox()
        RadGrid1.DataSource = ri.GetData(PortalId, MasterCustomerId, SubCustomerId, isCOMPLETED, Link, isReadOnly)

    End Sub

End Class
