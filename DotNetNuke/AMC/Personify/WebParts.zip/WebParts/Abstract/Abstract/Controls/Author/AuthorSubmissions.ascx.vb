Imports Telerik.Web.UI

Public Class AuthorSubmissions
    Inherits System.Web.UI.UserControl


#Region "Properties"
    Public Property MasterCustomerId() As String
        Get
            Return _masterCustomerId
        End Get
        Set(ByVal value As String)
            _masterCustomerId = value
        End Set
    End Property

    Public Property SubCustomerId() As Integer
        Get
            Return _subCustomerId
        End Get
        Set(ByVal value As Integer)
            _subCustomerId = value
        End Set
    End Property

    Public Property PortalId() As Integer
        Get
            Return _portalId
        End Get
        Set(ByVal value As Integer)
            _portalId = value
        End Set
    End Property

    Public Property GetArgs() As String
        Get
            Return _GetArgs
        End Get
        Set(ByVal value As String)
            _GetArgs = value
        End Set
    End Property

    Public Property GetSubType() As String
        Get
            Return _GetSubType
        End Get
        Set(ByVal value As String)
            _GetSubType = value
        End Set
    End Property

    Public Property IsClosed() As Boolean
        Get
            Return _isClosed
        End Get
        Set(ByVal value As Boolean)
            _isClosed = value
        End Set
    End Property


    Public ReadOnly Property OrganizationId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

#End Region

#Region "Controls"

    Protected WithEvents RadGridAuthorSubmissions As Telerik.Web.UI.RadGrid

    Private _masterCustomerId As String
    Private _subCustomerId As Integer
    Private _portalId As Integer
    Private _isClosed As Boolean

    Private _GetArgs As String
    Private _GetSubType As String

    Private _DatasourceList As Generic.List(Of AuthorSubmission)

#End Region

#Region "Event"
    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SetupControls()
    End Sub
#End Region

#Region "Private"

    Private Sub SetupControls()

        _DatasourceList = New Generic.List(Of AuthorSubmission)

        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
        Dim oAbstractAuthors As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthors
        oAbstractAuthors = CallManager.GetAuthorSubmissions(PortalId, MasterCustomerId, SubCustomerId)

        For Each oAbstractSubmissionAuthor As TIMSS.API.AbstractInfo.IAbstractSubmissionAuthor In oAbstractAuthors
            Dim navigateURL As String = String.Empty

            With oAbstractSubmissionAuthor

                'If .AbstractSubmissionInfo.ExternalStatusCodeString = "DRAFT" Or .AbstractSubmissionInfo.InternalStatusCodeString = "NEED_AUTHOR_CHANGES" Then
                'navigateURL = GetNextPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryGeneralInformation, GetArgs, CInt(.AbstractSubmissionId), GetSubType)
                'Else

                navigateURL = GetNextPageURL(ScreenController.AbstractScreen.Author_SubmissionEntryConfirmation, .AbstractSubmissionInfo.AbstractCallCode, CType(.AbstractSubmissionId, Long), .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCode.Code, "View")

                Dim oAbstractSubmissionTemp As New AuthorSubmission(.AbstractSubmissionId, .AbstractSubmissionInfo.Title, .AuthorRoleCode.Description, .AbstractSubmissionInfo.ExternalStatusCode.Description, navigateURL, .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeCode.Description, .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.AbstractCallInfo.Title)
                If IsClosed Then
                    If .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeEndDate < Date.Now Then
                        _DatasourceList.Add(oAbstractSubmissionTemp)
                    End If
                Else
                    Dim submissionTypeEndDate As Date
                    submissionTypeEndDate = .AbstractSubmissionInfo.AbstractCallSubmissionTypeInfo.SubmissionTypeEndDate

                    If PersonifyWebCommon.isNullDate(submissionTypeEndDate) OrElse submissionTypeEndDate >= Date.Now Then
                        _DatasourceList.Add(oAbstractSubmissionTemp)
                    End If
                End If
            End With

        Next

    End Sub

#End Region

#Region "Public functions"
    Protected Sub RadGridAuthorSubmissions_NeedDataSource(ByVal [source] As Object, _
   ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
     
        RadGridAuthorSubmissions.DataSource = _DatasourceList
    End Sub




    Public Function GetNextPageURL(ByVal screenId As ScreenController.AbstractScreen, ByVal args As String, ByVal SubmissionId As Long, Optional ByVal type As String = Nothing, Optional ByVal mode As String = Nothing) As String

        Dim strURLBuilder As New System.Text.StringBuilder
        strURLBuilder.Append("s=")
        strURLBuilder.Append(screenId)
        If SubmissionId > 0 Then
            strURLBuilder.Append("&sid=")
            strURLBuilder.Append(SubmissionId)
        End If
        If Not String.IsNullOrEmpty(args) Then
            strURLBuilder.Append("&args=")
            strURLBuilder.Append(args)
        End If
        If type IsNot Nothing AndAlso Not String.IsNullOrEmpty(type) Then
            strURLBuilder.Append("&type=")
            strURLBuilder.Append(type)
        End If
        If mode IsNot Nothing AndAlso Not String.IsNullOrEmpty(mode) Then
            strURLBuilder.Append("&mode=")
            strURLBuilder.Append(mode)
        End If

        Return NavigateURL("", strURLBuilder.ToString)
    End Function
#End Region




End Class
