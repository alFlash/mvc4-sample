Imports Telerik.Web.UI
Imports System.Collections.Generic


Public Class AuthorHistory
    Inherits System.Web.UI.UserControl


#Region "Properties"
    Public Property MasterCustomerId() As String
        Get
            Return _masterCustomerId
        End Get
        Set(ByVal value As String)
            _masterCustomerId = value
        End Set
    End Property

    Public Property SubCustomerId() As Integer
        Get
            Return _subCustomerId
        End Get
        Set(ByVal value As Integer)
            _subCustomerId = value
        End Set
    End Property

    Public Property PortalId() As Integer
        Get
            Return _portalId
        End Get
        Set(ByVal value As Integer)
            _portalId = value
        End Set
    End Property


    Public ReadOnly Property OrganizationId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

#End Region

#Region "Controls"

    Protected WithEvents RadGridActivities As RadGrid

    Private _masterCustomerId As String
    Private _subCustomerId As Integer
    Private _portalId As Integer
#End Region

#Region "Variables"
    Private oWebActivities As List(Of WEB_ACTIVITY)
#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetupControls()
    End Sub

#End Region

#Region "Helper functions"

    Private Sub SetupControls()

        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)

        Dim oActivities As DataTable = CallManager.GetAuthorHistory(PortalId, MasterCustomerId, SubCustomerId)

        oWebActivities = New List(Of WEB_ACTIVITY)

        For Each oActivity As DataRow In oActivities.Rows
            Dim oWebActivity As WEB_ACTIVITY = New WEB_ACTIVITY
            With oWebActivity
                .SubmissionTitle = oActivity("Title")
                If oActivity("AbstractSubmissionActivities.AbstractSubmissionActivityId") IsNot System.DBNull.Value Then
                    .AbstractSubmissionActivityId = CType(oActivity("AbstractSubmissionActivities.AbstractSubmissionActivityId"), Integer)
                End If
                If oActivity("AbstractSubmissionActivities.NewAssignmentStatusCode") IsNot System.DBNull.Value Then
                    .NewAssignmentStatusCodeString = CType(oActivity("AbstractSubmissionActivities.NewAssignmentStatusCode"), String)
                End If
                If oActivity("AbstractSubmissionActivities.NewInternalStatusCode") IsNot System.DBNull.Value Then
                    .NewInternalStatusCodeString = CType(oActivity("AbstractSubmissionActivities.NewInternalStatusCode"), String)
                End If
                If oActivity("AbstractSubmissionActivities.PreviousExternalStatusCode") IsNot System.DBNull.Value Then
                    .PreviousExternalStatusCodeString = CType(oActivity("AbstractSubmissionActivities.PreviousExternalStatusCode"), String)
                End If
                If oActivity("AbstractSubmissionActivities.PreviousInternalStatusCode") IsNot System.DBNull.Value Then
                    .PreviousInternalStatusCodeString = CType(oActivity("AbstractSubmissionActivities.PreviousInternalStatusCode"), String)
                End If
                If oActivity("AbstractSubmissionActivities.ReviewerMasterCustomerId") IsNot System.DBNull.Value Then
                    If Not CType(oActivity("AbstractSubmissionActivities.ReviewerMasterCustomerId"), String) = "" Then
                        Dim SubmissionManager As New SubmissionManagerHelper(OrganizationId, OrganizationUnitId)
                        Dim Customer As TIMSS.API.CustomerInfo.ICustomer = SubmissionManager.GetCustomer(PortalId, MasterCustomerId, SubCustomerId)
                        If Customer IsNot Nothing Then
                            .ReviewerName = Customer.LastFirstName
                        Else
                            .ReviewerName = ""
                        End If
                    Else
                        .ReviewerName = ""
                    End If
                End If
                If oActivity("AbstractSubmissionActivities.ReviewProcessEventCode") IsNot System.DBNull.Value Then
                    .ReviewProcessEventCodeString = CType(oActivity("AbstractSubmissionActivities.ReviewProcessEventCode"), String)
                End If
                If oActivity("AbstractSubmissionActivities.ReviewProcessEventDate") IsNot System.DBNull.Value Then
                    .ReviewProcessEventDate = CType(oActivity("AbstractSubmissionActivities.ReviewProcessEventDate"), DateTime)
                End If

            End With
            oWebActivities.Add(oWebActivity)
        Next



    End Sub

#End Region

#Region "Public functions"
    

#End Region



    Private Sub RadGridActivities_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RadGridActivities.NeedDataSource
        RadGridActivities.DataSource = oWebActivities
    End Sub
End Class
