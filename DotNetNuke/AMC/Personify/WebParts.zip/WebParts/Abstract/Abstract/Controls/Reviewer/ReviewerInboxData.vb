﻿Imports Microsoft.VisualBasic
Imports System.ComponentModel

Public Class ReviewerInboxData

    Private _AbstractCallTitle As String = Nothing
    Public Property AbstractCallTitle() As String
        Get
            Return _AbstractCallTitle
        End Get
        Set(ByVal value As String)
            _AbstractCallTitle = value
        End Set
    End Property

    Private _SubmissionTypeCode As String = Nothing
    Public Property SubmissionTypeCode() As String
        Get
            Return _SubmissionTypeCode
        End Get
        Set(ByVal value As String)
            _SubmissionTypeCode = value
        End Set
    End Property

    'Private _Status As String = Nothing
    'Public Property Status() As String
    '    Get
    '        Return _Status
    '    End Get
    '    Set(ByVal value As String)
    '        _Status = value
    '    End Set
    'End Property

    Private _Title As String = Nothing
    Public Property Title() As String
        Get
            Return _Title
        End Get
        Set(ByVal value As String)
            _Title = value
        End Set
    End Property

    Private _AbstractSubmissionId As Integer = 0
    Public Property AbstractSubmissionId() As Integer
        Get
            Return _AbstractSubmissionId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionId = value
        End Set
    End Property

    Private _AbstractSubmissionReviewerId As Integer = 0
    Public Property AbstractSubmissionReviewerId() As Integer
        Get
            Return _AbstractSubmissionReviewerId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionReviewerId = value
        End Set
    End Property

    Private _LinkText As String = Nothing
    Public Property LinkText() As String
        Get
            Return _LinkText
        End Get
        Set(ByVal value As String)
            _LinkText = value
        End Set
    End Property

    Private _Link As String = Nothing
    Public Property Link() As String
        Get
            Return _Link
        End Get
        Set(ByVal value As String)
            _Link = value
        End Set
    End Property

    Private _DueDate As String
    Public Property DueDate() As String
        Get
            Return _DueDate
        End Get
        Set(ByVal value As String)
            _DueDate = value
        End Set
    End Property

    Private _FirstColumn As String = Nothing
    Public Property FirstColumn() As String
        Get
            Return _FirstColumn
        End Get
        Set(ByVal value As String)
            _FirstColumn = value
        End Set
    End Property
End Class
