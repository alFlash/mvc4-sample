Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System.Xml
Imports System.Xml.XPath
Imports ScreenController.AbstractScreen
Imports Telerik.Web.UI
Imports PersonifyWebCommon
Imports System.IO


Public Class PanelMenu
    Inherits AbstractScreenBase

    'System.Web.UI.UserControl

    'AbstractScreenBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Controls & Variables"

    Protected WithEvents PanelBarList As RadPanelBar
    Private _IsAbstractAdmin As Boolean
    Private _IsAbstractSubmissionTypeStaff As Boolean

    Private _FullPath As String
#End Region

#Region "Properties"

    Public Property FullPath() As String
        Get
            Return _FullPath
        End Get
        Set(ByVal value As String)
            _FullPath = value
        End Set
    End Property

#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            SetupControls()
        End If
    End Sub



#End Region


#Region "Helper functions"

    Public Function GetFileContents(ByVal FullPath As String, _
           Optional ByRef ErrInfo As String = "") As String

        Dim strContents As String
        Dim objReader As StreamReader
        Try

            objReader = New StreamReader(FullPath)
            strContents = objReader.ReadToEnd()
            objReader.Close()
            Return strContents
        Catch Ex As Exception
            ErrInfo = Ex.Message
        End Try

        Return Nothing
    End Function


    Private Sub SetupControls()

        If Not Page.IsPostBack AndAlso _FullPath IsNot Nothing Then

            If GetSessionObject(SessionKeys.PersonifyAbstractMenuXML) Is Nothing Then
                AddSessionObject(SessionKeys.PersonifyAbstractMenuXML, GetPanelMenuXML)
            End If
            
            PanelBarList.LoadXml(GetSessionObject(SessionKeys.PersonifyAbstractMenuXML))

            'For Each item As Telerik.Web.UI.RadPanelItem In PanelBarList.Items
            '    If Not String.IsNullOrEmpty(item.NavigateUrl) Then
            '        'item.NavigateUrl must equals S=XXX
            '        item.NavigateUrl = item.NavigateUrl.Replace("[AMPS]", "&")
            '        item.NavigateUrl = NavigateURL("", item.NavigateUrl)
            '    End If
            '    If item.Items.Count > 0 Then
            '        For Each childItem As Telerik.Web.UI.RadPanelItem In item.Items
            '            If Not String.IsNullOrEmpty(childItem.NavigateUrl) Then
            '                'item.NavigateUrl must equals S=XXX
            '                childItem.NavigateUrl = childItem.NavigateUrl.Replace("[AMPS]", "&")
            '                childItem.NavigateUrl = NavigateURL("", childItem.NavigateUrl)
            '            End If
            '        Next
            '    End If
            'Next

        End If
    End Sub


    Private Function GetPanelMenuXML() As String

        Dim strCacheKey As String
        Dim xmlDoc As XmlDocument
        Dim fileInputXML As String

        strCacheKey = "AbstractMenu"
        fileInputXML = CType(PersonifyDataCache.Fetch(strCacheKey), String)
        xmlDoc = New XmlDocument()

        If String.IsNullOrEmpty(fileInputXML) Then
            Dim fullPath As String = Server.MapPath(_FullPath)            
            xmlDoc.Load(fullPath)
            PersonifyDataCache.Store(strCacheKey, xmlDoc.OuterXml, PersonifyDataCache.CacheExpirationInterval)
        Else
            xmlDoc.LoadXml(fileInputXML)
        End If


        Dim resultList As XmlNodeList
        Dim strBuilder As New System.Text.StringBuilder


        strBuilder.Append("<?xml version=""1.0"" encoding=""utf-8"" ?>")
        strBuilder.Append("<PanelBar>")

        resultList = xmlDoc.SelectNodes("//Item[@Type='ALL']")
        strBuilder.Append(TransformXML(resultList, False))

        _IsAbstractAdmin = ABS_AcessControl_IsStaff(MasterCustomerId, SubCustomerId)
        _IsAbstractSubmissionTypeStaff = ABS_AcessControl_IsSubmissionTypeStaff(MasterCustomerId, SubCustomerId, Nothing, Nothing)

        If _IsAbstractAdmin OrElse _IsAbstractSubmissionTypeStaff Then
            resultList = xmlDoc.SelectNodes("//Item[@Type='ADMIN']")
            strBuilder.Append(TransformXML(resultList, True))
        End If

        If Me.ABS_AcessControl_IsReviewer(MasterCustomerId, SubCustomerId) Then
            resultList = xmlDoc.SelectNodes("//Item[@Type='REVIEWER']")
            strBuilder.Append(TransformXML(resultList, False))
        End If

        If Me.ABS_AcessControl_IsAuthor(MasterCustomerId, SubCustomerId) Then
            resultList = xmlDoc.SelectNodes("//Item[@Type='AUTHOR']")
            strBuilder.Append(TransformXML(resultList, False))
        End If


        strBuilder.Append("</PanelBar>")

        Return strBuilder.ToString
    End Function


    Private Function TransformXML(ByVal xmlNodeList As XmlNodeList, ByVal CheckForAdminAccess As Boolean) As String
        Dim value As String
        Dim strBuilder As New System.Text.StringBuilder
        Dim AddToListFlag As Boolean = True



        For Each node As XmlNode In xmlNodeList

            If node.Attributes("NavigateUrl") IsNot Nothing Then
                value = node.Attributes("NavigateUrl").Value.Replace("[AMPS]", "&")
                node.Attributes("NavigateUrl").Value = NavigateURL("", value)
            End If
            Dim toDeletedList As New Generic.List(Of XmlNode)
            For Each childNode As XmlNode In node.ChildNodes
                Dim childDeleted As Boolean = False
                If CheckForAdminAccess AndAlso Not _IsAbstractAdmin AndAlso _IsAbstractSubmissionTypeStaff Then
                    If childNode.Attributes("AdminAccess") IsNot Nothing AndAlso childNode.Attributes("AdminAccess").Value = "Y" Then                        
                        toDeletedList.Add(childNode)
                        childDeleted = True
                    End If
                End If
                If childDeleted = False Then
                    If childNode.Attributes("NavigateUrl") IsNot Nothing Then
                        value = childNode.Attributes("NavigateUrl").Value.Replace("[AMPS]", "&")
                        childNode.Attributes("NavigateUrl").Value = NavigateURL("", value)
                    End If
                End If
            Next
            If toDeletedList.Count > 0 Then
                For Each tmpChild As XmlNode In toDeletedList
                    node.RemoveChild(tmpChild)
                Next
            End If

            strBuilder.Append(node.OuterXml)

        Next

        Return strBuilder.ToString

    End Function

#End Region






End Class
