Imports Telerik.Web.UI
Imports PersonifyWebCommon

Public Class SubmissionTextBlocks
    Inherits System.Web.UI.UserControl


#Region "Properties"
    Public Property AbstractSubmissionId() As Integer
        Get
            Return _AbstractSubmissionId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionId = value
        End Set
    End Property

    Public Property PortalId() As Integer
        Get
            Return _portalId
        End Get
        Set(ByVal value As Integer)
            _portalId = value
        End Set
    End Property

    Public Property IsEdit() As Boolean
        Get
            Return _isEdit
        End Get
        Set(ByVal value As Boolean)
            _isEdit = value
        End Set
    End Property

    Public Property EditNavigateURL() As String
        Get
            Return _EditNavigateURL
        End Get
        Set(ByVal value As String)
            _EditNavigateURL = value
        End Set
    End Property


    Public ReadOnly Property OrganizationId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property

    Public Property ShowInstruction() As Boolean
        Get
            Return _ShowInstruction
        End Get
        Set(ByVal value As Boolean)
            _ShowInstruction = value
        End Set
    End Property

#End Region

#Region "Controls"

    Protected WithEvents RadGridSubmissionTextBlocks As Telerik.Web.UI.RadGrid
    Protected WithEvents butReviewerReport As Button
    Protected WithEvents butStaffReport As Button
    Protected WithEvents pnlReporting As Panel

    Private _editNavigateURL As String
    Private _abstractSubmissionId As Integer
    Private _portalId As Integer
    Private _isEdit As Boolean
    Private _ShowInstruction As Boolean = False 'Change back to false since it is not required by default


#End Region

#Region "Public functions"

    Protected Sub RadGridSubmissionTextBlocks_NeedDataSource(ByVal [source] As Object, _
   ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()
        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
        Dim oAbstractSubmissionTextBlocks As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlocks
        oAbstractSubmissionTextBlocks = CallManager.GetSubmissionTextBlocks(PortalId, AbstractSubmissionId)

        For Each oAbstractSubmissionTextBlock As TIMSS.API.AbstractInfo.IAbstractSubmissionTextBlock In oAbstractSubmissionTextBlocks
            Dim oAbstractSubmissionTemp As New SubmissionTextBlock(oAbstractSubmissionTextBlock.AbstractSubmissionTextBlockId, oAbstractSubmissionTextBlock.BlockText, oAbstractSubmissionTextBlock.BlockSequence, oAbstractSubmissionTextBlock.AbstractCallSubmissionTypeTextBlockControlInfo.InstructionCaptionText, oAbstractSubmissionTextBlock.AbstractCallSubmissionTypeTextBlockControlInfo.InstructionText, oAbstractSubmissionTextBlock.AbstractCallSubmissionTypeTextBlockControlInfo.Heading)
            list.Add(oAbstractSubmissionTemp)
        Next
        RadGridSubmissionTextBlocks.DataSource = list
    End Sub

#End Region

#Region "Event"

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HideReportButton()
    End Sub

    Private Sub butReviewerReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butReviewerReport.Click
        Dim strReleaseURL As String
        Dim strReportURL As String
        strReportURL = Report_GetAbstractSubmission(PortalId, Me.OrganizationId, Me.OrganizationUnitId, "ABS1008_Reviewers", Me.AbstractSubmissionId, strReleaseURL)
        If Not String.IsNullOrEmpty(strReportURL) AndAlso Not String.IsNullOrEmpty(strReleaseURL) Then
            'Register the Java script
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "winOpen", Report_BuildNewWindow_JavaScript(strReportURL, strReleaseURL), True)
        End If
    End Sub

    Private Sub butStaffReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butStaffReport.Click
        Dim strReleaseURL As String
        Dim strReportURL As String
        strReportURL = Report_GetAbstractSubmission(PortalId, Me.OrganizationId, Me.OrganizationUnitId, "ABS1008_Admin", Me.AbstractSubmissionId, strReleaseURL)
        If Not String.IsNullOrEmpty(strReportURL) AndAlso Not String.IsNullOrEmpty(strReleaseURL) Then
            'Register the Java script
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "winOpen", Report_BuildNewWindow_JavaScript(strReportURL, strReleaseURL), True)
        End If
    End Sub

#End Region

#Region "Helper functions"

    Private Sub HideReportButton()
        If Request("s") Is Nothing Then
            Exit Sub
        End If

        Dim screenName As ScreenController.AbstractScreen
        screenName = CInt(Request("s"))

        Select Case screenName
            Case ScreenController.AbstractScreen.Reviewer_ReviewSubmission
                pnlReporting.Visible = True
                butReviewerReport.Visible = True
                butStaffReport.Visible = False
            Case ScreenController.AbstractScreen.Admin_SubmissionDetails
                pnlReporting.Visible = True
                butReviewerReport.Visible = False
                butStaffReport.Visible = True
            Case Else
                pnlReporting.Visible = False
                butReviewerReport.Visible = False
                butStaffReport.Visible = False
        End Select

    End Sub

#End Region

End Class
