
Imports Telerik.Web.UI

Partial Class CollapseContentCtrl
    Inherits System.Web.UI.UserControl


#Region "Controls"

    Protected WithEvents dockAbstractContent As RadDock
    Protected WithEvents pnlContent As Panel

#End Region


#Region "Properties"

    Public Property ContentTitle() As String
        Get
            Return dockAbstractContent.Title
        End Get
        Set(ByVal value As String)
            dockAbstractContent.Title = value
        End Set
    End Property

    Public Sub AddContent(ByVal control As Control)
        pnlContent.Controls.Add(control)
    End Sub

#End Region

End Class
