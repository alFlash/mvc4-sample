Imports Telerik.Web.UI
Imports System.IO

Public Class SubmissionAttachments
    Inherits System.Web.UI.UserControl


#Region "Properties"
    Public Property AbstractSubmissionId() As Integer
        Get
            Return _AbstractSubmissionId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionId = value
        End Set
    End Property

    Public Property PortalId() As Integer
        Get
            Return _portalId
        End Get
        Set(ByVal value As Integer)
            _portalId = value
        End Set
    End Property
    'IsEdit
    Public Property IsEdit() As Boolean
        Get
            Return _isEdit
        End Get
        Set(ByVal value As Boolean)
            _isEdit = value
        End Set
    End Property
    Public Property AdditionalPathExtension() As String
        Get
            Return _AdditionalPathExtension
        End Get
        Set(ByVal value As String)
            _AdditionalPathExtension = value
        End Set
    End Property


    Public ReadOnly Property OrganizationId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgId
        End Get
    End Property

    Public ReadOnly Property OrganizationUnitId() As String
        Get
            Return Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).OrgUnitId
        End Get
    End Property


#End Region

#Region "Controls"

    Protected WithEvents RadGridSubmissionAttachments As Telerik.Web.UI.RadGrid

    Private _abstractSubmissionId As Integer
    Private _portalId As Integer
    Private _isEdit As Boolean
    Private _AdditionalPathExtension As String
#End Region

#Region "Functions"
    Protected Sub RadGridSubmissionAttachments_NeedDataSource(ByVal [source] As Object, _
   ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim list As ArrayList = New ArrayList()
        Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
        Dim oAbstractSubmissionAttachments As TIMSS.API.AbstractInfo.IAbstractSubmissionFiles
        oAbstractSubmissionAttachments = CallManager.GetSubmissionAttachments(PortalId, AbstractSubmissionId)

        For Each oAbstractSubmissionAttachment As TIMSS.API.AbstractInfo.IAbstractSubmissionFile In oAbstractSubmissionAttachments
            Dim oFormatedFileSize As String = String.Concat(String.Format("{0:0.##}", oAbstractSubmissionAttachment.FileSizeMB / (1024 * 1204)), " MB")

            Dim oAbstractSubmissionTemp As New SubmissionAttachment(oAbstractSubmissionAttachment.AbstractSubmissionFileId, oAbstractSubmissionAttachment.FileName, oAbstractSubmissionAttachment.Description, oFormatedFileSize)
            list.Add(oAbstractSubmissionTemp)
        Next
        RadGridSubmissionAttachments.DataSource = list
    End Sub

    Private Sub RadGridSubmissionAttachments_ItemCommand(ByVal source As Object, ByVal e As GridCommandEventArgs) Handles RadGridSubmissionAttachments.ItemCommand
        If e.CommandName = "Remove" Then
            Dim CallManager As New CallManagerHelper(OrganizationId, OrganizationUnitId)
            Dim AbstractsubmissionFileId As Integer = CInt(e.Item.OwnerTableView.DataKeyValues(e.Item.ItemIndex)("AbstractSubmissionFileId"))
            CallManager.RemoveAttachment(PortalId, AbstractSubmissionId, AbstractsubmissionFileId)

            e.Item.OwnerTableView.Rebind()
        End If

        If e.CommandName = "Download" Then
            Dim dataItem As GridDataItem = CType(e.Item, GridDataItem)
            Dim FileName As String = dataItem("FileName").Text.ToString()
            Dim errorMessage As String = String.Empty
            DownloadFile(FileName, errorMessage)
        End If

      
    End Sub

    Public Sub Reload()
        RadGridSubmissionAttachments.Rebind()
    End Sub



    Public Function DownloadFile(ByVal FileName As String, ByRef errorMessage As String) As Boolean

        Dim dataToRead As Long



        Dim iStream As System.IO.Stream
        ' Buffer to read 10K bytes in chunk:
        Dim buffer(10000) As Byte

        ' Length of the file:
        Dim length As Integer

        Try
            Dim filebytes() As Byte = TIMSS.ThirdPartyInterfaces.FileOperation.DownLoadFile(TIMSS.Server.BusinessMessages.FileUploadDownload.UploadResourceType.AbstractFiles, FileName, AdditionalPathExtension)

            iStream = New MemoryStream(filebytes)

            Dim oHttpContext As System.Web.HttpContext = System.Web.HttpContext.Current

            '**Get the IP Address of the user downloading the file
            ' _UserIPAddress = oHttpContext.Request.UserHostAddress()
            oHttpContext.Response.Clear()
            oHttpContext.Response.ClearHeaders()
            oHttpContext.Response.ClearContent()
            oHttpContext.Response.Buffer = True
            oHttpContext.Response.ContentType = "application/octet-stream"
            oHttpContext.Response.AddHeader("Content-Disposition", "attachment; filename=" & FileName)

            ' oHttpContext.Response.OutputStream.Write(filebytes, 0, filebytes.Length - 1)

            'Read the bytes.
            dataToRead = iStream.Length
            While dataToRead > 0
                'Verify that the client is connected.
                If oHttpContext.Response.IsClientConnected Then
                    'Read the data in buffer
                    length = iStream.Read(buffer, 0, 10000)

                    'Write the data to the current output stream.
                    oHttpContext.Response.OutputStream.Write(buffer, 0, length)

                    'Flush the data to the HTML output.
                    oHttpContext.Response.Flush()

                    ReDim buffer(10000) ' Clear the buffer
                    dataToRead = dataToRead - length
                Else
                    'prevent infinite loop if user disconnects
                    dataToRead = -1
                End If
            End While

            If dataToRead <> -1 Then
                oHttpContext.Response.Flush()
                Return True
            End If

            Return False
        Catch ex As Exception
            errorMessage = "File may be expired or does not exist - please contact customer service"
            Return False
        End Try




    End Function



#End Region



End Class
