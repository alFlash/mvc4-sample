
Public Class AuthorSubmission
    Private _SubmissionId As Integer
    Private _Title As String
    Private _Type As String
    Private _Status As String
    Private _NavigateURL As String
    Private _SubmissionType As String
    Private _CallTitle As String

    Public Property SubmissionId() As Integer
        Get
            Return _SubmissionId
        End Get
        Set(ByVal value As Integer)
            _SubmissionId = value
        End Set
    End Property

    Public Property Title() As String
        Get
            Return _Title
        End Get
        Set(ByVal value As String)
            _Title = value
        End Set
    End Property


    Public Property Type() As String
        Get
            Return _Type
        End Get
        Set(ByVal value As String)
            _Type = value
        End Set
    End Property


    Public Property Status() As String
        Get
            Return _Status
        End Get
        Set(ByVal value As String)
            _Status = value
        End Set
    End Property

    Public Property NavigateURL() As String
        Get
            Return _NavigateURL
        End Get
        Set(ByVal value As String)
            _NavigateURL = value
        End Set
    End Property

    Public Property SubmissionType() As String
        Get
            Return _SubmissionType
        End Get
        Set(ByVal value As String)
            _SubmissionType = value
        End Set
    End Property
    Public Property CallTitle() As String
        Get
            Return _CallTitle
        End Get
        Set(ByVal value As String)
            _CallTitle = value
        End Set
    End Property




    Public Sub New(ByVal submissionId As String, ByVal title As String, ByVal type As String, ByVal status As String, ByVal NavigateURL As String, ByVal oSubmissionType As String, ByVal oCallTitle As String)
        Me.SubmissionId = submissionId
        Me.Title = title
        Me.Type = type
        Me.Status = status
        Me.NavigateURL = NavigateURL
        Me.SubmissionType = oSubmissionType
        Me.CallTitle = oCallTitle
    End Sub
End Class


Public Class SubmissionTextBlock
    Private _AbstractSubmissionTextBlockId As Integer
    Private _BlockText As String
    Private _BlockSeq As Integer
    Private _InstructionCaptionText As String
    Private _InstructionText As String
    Private _HeadingText As String

    Public Property AbstractSubmissionTextBlockId() As Integer
        Get
            Return _AbstractSubmissionTextBlockId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionTextBlockId = value
        End Set
    End Property

    Public Property BlockText() As String
        Get
            Return _BlockText
        End Get
        Set(ByVal value As String)
            _BlockText = value
        End Set
    End Property


    Public Property BlockSeq() As Integer
        Get
            Return _BlockSeq
        End Get
        Set(ByVal value As Integer)
            _BlockSeq = value
        End Set
    End Property


    Public Property InstructionCaptionText() As String
        Get
            Return _InstructionCaptionText
        End Get
        Set(ByVal value As String)
            _InstructionCaptionText = value
        End Set
    End Property


    Public Property InstructionText() As String
        Get
            Return _InstructionText
        End Get
        Set(ByVal value As String)
            _InstructionText = value
        End Set
    End Property

    Public Property HeadingText() As String
        Get
            Return _HeadingText
        End Get
        Set(ByVal value As String)
            _HeadingText = value
        End Set
    End Property


    Public Sub New(ByVal AbstractSubmissionTextBlockId As Integer, ByVal BlockText As String, ByVal BlockSeq As String, ByVal InstructionCaptionText As String, ByVal InstructionText As String, ByVal HeadingText As String)
        Me.AbstractSubmissionTextBlockId = AbstractSubmissionTextBlockId
        Me.BlockText = BlockText
        Me.BlockSeq = BlockSeq
        Me.InstructionCaptionText = InstructionCaptionText
        Me.InstructionText = InstructionText
        Me.HeadingText = HeadingText
    End Sub
End Class


Public Class SubmissionAttachment
    Private _AbstractSubmissionFileId As Integer
    Private _FileName As String
    Private _Description As String
    Private _FileSizeMB As String
    Private _FilePath As String

    Public Property AbstractSubmissionFileId() As Integer
        Get
            Return _AbstractSubmissionFileId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionFileId = value
        End Set
    End Property

    Public Property FileName() As String
        Get
            Return _FileName
        End Get
        Set(ByVal value As String)
            _FileName = value
        End Set
    End Property


    Public Property Description() As String
        Get
            If String.IsNullOrEmpty(_Description) Then
                Return FileName()
            Else
                Return _Description
            End If
        End Get
        Set(ByVal value As String)
            _Description = value
        End Set
    End Property

    Public Property FileSizeMB() As String
        Get
            Return _FileSizeMB
        End Get
        Set(ByVal value As String)
            _FileSizeMB = value
        End Set
    End Property

    Public Sub New(ByVal AbstractSubmissionFileId As Integer, ByVal FileName As String, ByVal Description As String, ByVal FileSizeMB As String)
        Me.AbstractSubmissionFileId = AbstractSubmissionFileId
        Me.FileName = FileName
        Me.Description = Description
        Me.FileSizeMB = FileSizeMB
    End Sub
End Class


Public Class AuthorReview
    Private _AbstractSubmissionReviewerId As Integer
    Private _CommentsFromReviewer As String
    Private _ReviewerName As String
    Private _ReviewerMasterCustomerId As String
    Private _ReviewerSubCustomerId As Integer
    Private _SubmissionTitle As String

 
    Public Property AbstractSubmissionReviewerId() As Integer
        Get
            Return _AbstractSubmissionReviewerId
        End Get
        Set(ByVal value As Integer)
            _AbstractSubmissionReviewerId = value
        End Set
    End Property

    Public Property CommentsFromReviewer() As String
        Get
            Return _CommentsFromReviewer
        End Get
        Set(ByVal value As String)
            _CommentsFromReviewer = value
        End Set
    End Property
    Public Property ReviewerName() As String
        Get
            Return _ReviewerName
        End Get
        Set(ByVal value As String)
            _ReviewerName = value
        End Set
    End Property
    Public Property ReviewerMasterCustomerId() As String
        Get
            Return _ReviewerMasterCustomerId
        End Get
        Set(ByVal value As String)
            _ReviewerMasterCustomerId = value
        End Set
    End Property
    Public Property ReviewerSubCustomerId() As Integer
        Get
            Return _ReviewerSubCustomerId
        End Get
        Set(ByVal value As Integer)
            _ReviewerSubCustomerId = value
        End Set
    End Property
    Public Property SubmissionTitle() As String
        Get
            Return _SubmissionTitle
        End Get
        Set(ByVal value As String)
            _SubmissionTitle = value
        End Set
    End Property


    'Public Sub New(ByVal AbstractSubmissionTextBlockId As Integer, ByVal BlockText As String, ByVal BlockSeq As String, ByVal InstructionCaptionText As String)
    '    Me.AbstractSubmissionTextBlockId = AbstractSubmissionTextBlockId
    '    Me.BlockText = BlockText
    '    Me.BlockSeq = BlockSeq
    '    Me.InstructionCaptionText = InstructionCaptionText
    'End Sub
End Class