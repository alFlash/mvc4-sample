Imports Telerik.Web.UI

Partial Class TabMenu
    Inherits System.Web.UI.UserControl

#Region "Controls"

    Protected WithEvents RadPageView4 As RadPageView
    Protected WithEvents radTabMenu As TabMenu

#End Region

#Region "Public functions"
    Public Sub AddContent(ByVal control As Control)
        'pnlContent.Controls.Add(control)
        RadPageView4.Controls.Add(control)
    End Sub
#End Region

#Region "Properties"

    Public Property Orientation() As Telerik.Web.UI.TabStripOrientation
        Get
            Return radTabMenu.Orientation
        End Get
        Set(ByVal value As Telerik.Web.UI.TabStripOrientation)
            radTabMenu.Orientation = value
        End Set
    End Property

#End Region

End Class
