

Namespace Personify.DNN.Modules.OrderPayment

    Public Class ModuleSettingsNames



        Public Const AdvanceShippingUrl As String = "AdvanceShippingUrl"
        Public Const AdvanceShippingUrlType As String = "AdvanceShippingUrlType"
        Public Const SamePageCheckoutEnabled As String = "SamePageCheckoutEnabled"
        Public Const ECheckEnabled As String = "ECheckEnabled"

        Public Const ChangeBillShipAddressURL As String = "ChangeBillShipAddressURL"
        Public Const ChangeBillShipAddressURLType As String = "ChangeBillShipAddressURLType"


        Public Const TemplateName As String = "TemplateName"
        Public Const CreditCard_TemplateName As String = "CreditCard_TemplateName"
        Public Const ECheck_TemplateName As String = "ECheck_TemplateName"
        Public Const EnableAdvanceShipping As String = "EnableAdvanceShipping"
        Public Const EnableCouponFeature As String = "EnableCouponFeature"
        Public Const PromotionCodeAtLineOrOrderLevel As String = "PromotionCodeAtLineOrOrderLevel"
        Public Const EnableBillMeFeature As String = "EnableBillMeFeature"


        Public Const ProcessOrder_RedirectToLoginURL As String = "ProcessOrder_RedirectToLoginURL"
        Public Const ProcessOrder_RedirectToLoginURLType As String = "ProcessOrder_RedirectToLoginURLType"
        Public Const ProcessOrder_RedirectToOrderSummaryURL As String = "ProcessOrder_RedirectToOrderSummaryURL"
        Public Const ProcessOrder_RedirectToOrderSummaryURLType As String = "ProcessOrder_RedirectToOrderSummaryURLType"

        Public Const C_TEMPLATEFOLDERNAME As String = "Templates"
        Public Const C_FILEPATTERN As String = "*.?s*" '*.xsl

    End Class

    Public Class ReceiptTypeCodes
        Public ReceiptCodeValue As String
        Public ReceiptCodeDescrip As String
    End Class

    Public Class CheckType
        Public CheckTypeValue As String
        Public CheckTypeDescrip As String
    End Class
End Namespace
