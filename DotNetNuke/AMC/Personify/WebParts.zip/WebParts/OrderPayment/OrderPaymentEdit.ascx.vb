Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.OrderPayment.Business

Namespace Personify.DNN.Modules.OrderPayment

    Public MustInherit Class OrderPaymentEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents ctlAdvanceShippingURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlChangeBillShipAddressURL As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents ctlRedirectToLoginPageURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlRedirectToOrderSummaryPageURL As DotNetNuke.UI.UserControls.UrlControl


        Protected WithEvents cboPromoCodeOptions As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboEnableCoupons As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboEnableBillMe As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSelectTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSelectCCTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSelectECKTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboEnableAdvanceShipping As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkSamePageCheckOut As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkECheck As System.Web.UI.WebControls.CheckBox

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'Dim objCtlPersonify As New OrderPaymentController
                'Dim objPersonify As New OrderPaymentInfo

                '' Determine ItemId
                'If Not (Request.Params("ItemId") Is Nothing) Then
                '    itemId = Int32.Parse(Request.Params("ItemId"))
                'Else
                '    itemId = Null.NullInteger()
                'End If

                If Not Page.IsPostBack Then
                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")


                    'Advance Shipping
                    'By Default Display FALSE
                    If Not Settings(ModuleSettingsNames.EnableAdvanceShipping) Is Nothing Then
                        cboEnableAdvanceShipping.SelectedValue = Settings(ModuleSettingsNames.EnableAdvanceShipping).ToString
                    Else
                        cboEnableAdvanceShipping.SelectedValue = "N"
                    End If


                    ctlAdvanceShippingURL.UrlType = CType(Settings(ModuleSettingsNames.AdvanceShippingUrlType), String)
                    ctlAdvanceShippingURL.Url = CType(Settings(ModuleSettingsNames.AdvanceShippingUrl), String)

                    'Bill Ship Address change url
                    ctlChangeBillShipAddressURL.UrlType = CType(Settings(ModuleSettingsNames.ChangeBillShipAddressURLType), String)
                    ctlChangeBillShipAddressURL.Url = CType(Settings(ModuleSettingsNames.ChangeBillShipAddressURL), String)

                    'Redirect to Login Page URL
                    ctlRedirectToLoginPageURL.UrlType = CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToLoginURLType), String)
                    ctlRedirectToLoginPageURL.Url = CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToLoginURL), String)

                    'Redirect to Order Summary URL
                    ctlRedirectToOrderSummaryPageURL.UrlType = CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToOrderSummaryURLType), String)
                    ctlRedirectToOrderSummaryPageURL.Url = CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToOrderSummaryURL), String)


                    'Display Promotional Code Settings - If nothing is set, set it to order level
                    'Display Disabled Address 

                    If Not Settings(ModuleSettingsNames.PromotionCodeAtLineOrOrderLevel) Is Nothing Then
                        cboPromoCodeOptions.SelectedValue = Settings(ModuleSettingsNames.PromotionCodeAtLineOrOrderLevel).ToString
                    Else
                        cboPromoCodeOptions.SelectedValue = "ORDER"
                    End If

                    'Accept Coupons - By Default Display FALSE
                    If Not Settings(ModuleSettingsNames.EnableCouponFeature) Is Nothing Then
                        cboEnableCoupons.SelectedValue = Settings(ModuleSettingsNames.EnableCouponFeature).ToString
                    Else
                        cboEnableCoupons.SelectedValue = "N"
                    End If

                    'Enable Bill Me - By Default Display FALSE
                    If Not Settings(ModuleSettingsNames.EnableBillMeFeature) Is Nothing Then
                        cboEnableBillMe.SelectedValue = Settings(ModuleSettingsNames.EnableBillMeFeature).ToString
                    Else
                        cboEnableBillMe.SelectedValue = "N"
                    End If

                    'Load Templates
                    If Not cboSelectTemplate.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            cboSelectTemplate.Items.Add(li)
                        Next
                        cboSelectTemplate.SelectedIndex = cboSelectTemplate.Items.IndexOf(cboSelectTemplate.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.TemplateName))))
                    End If

                    'Credit Card Template
                    If Not cboSelectCCTemplate.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            cboSelectCCTemplate.Items.Add(li)
                        Next
                        cboSelectCCTemplate.SelectedIndex = cboSelectCCTemplate.Items.IndexOf(cboSelectCCTemplate.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.CreditCard_TemplateName))))
                    End If

                    'ECheck Template
                    If Not cboSelectECKTemplate.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            cboSelectECKTemplate.Items.Add(li)
                        Next
                        cboSelectECKTemplate.SelectedIndex = cboSelectECKTemplate.Items.IndexOf(cboSelectECKTemplate.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.ECheck_TemplateName))))
                    End If

                    'Same Page Cgecjout
                    If CStr(Settings(ModuleSettingsNames.SamePageCheckoutEnabled)) = "Y" Then
                        chkSamePageCheckOut.Checked = True
                    Else
                        chkSamePageCheckOut.Checked = False
                    End If

                    If Settings(ModuleSettingsNames.ECheckEnabled) IsNot Nothing Then
                        If CStr(Settings(ModuleSettingsNames.ECheckEnabled)) = "Y" Then
                            chkECheck.Checked = True
                        Else
                            chkECheck.Checked = False
                        End If
                    End If

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem

                ' Create a reference to the current directory.
                Dim dInfo As New System.IO.DirectoryInfo(Me.MapPathSecure((ModulePath & ModuleSettingsNames.C_TEMPLATEFOLDERNAME)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As System.IO.FileInfo() = dInfo.GetFiles(ModuleSettingsNames.C_FILEPATTERN)
                Dim fiTemp As System.IO.FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function



        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    Dim objPersonify As New OrderPaymentInfo
                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting(ModuleSettingsNames.EnableAdvanceShipping, cboEnableAdvanceShipping.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.AdvanceShippingUrl, ctlAdvanceShippingURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.AdvanceShippingUrlType, ctlAdvanceShippingURL.UrlType)

                    UpdateModuleSetting(ModuleSettingsNames.ChangeBillShipAddressURL, ctlChangeBillShipAddressURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.ChangeBillShipAddressURLType, ctlChangeBillShipAddressURL.UrlType)


                    UpdateModuleSetting(ModuleSettingsNames.PromotionCodeAtLineOrOrderLevel, cboPromoCodeOptions.SelectedValue)


                    UpdateModuleSetting(ModuleSettingsNames.EnableCouponFeature, cboEnableCoupons.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.TemplateName, cboSelectTemplate.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.CreditCard_TemplateName, cboSelectCCTemplate.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.ECheck_TemplateName, cboSelectECKTemplate.SelectedValue)

                    UpdateModuleSetting(ModuleSettingsNames.EnableBillMeFeature, cboEnableBillMe.SelectedValue)

                    'Update Prodcess Order URLS
                    UpdateModuleSetting(ModuleSettingsNames.ProcessOrder_RedirectToLoginURL, ctlRedirectToLoginPageURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.ProcessOrder_RedirectToLoginURLType, ctlRedirectToLoginPageURL.UrlType)


                    'Update Prodcess Order URLS
                    UpdateModuleSetting(ModuleSettingsNames.ProcessOrder_RedirectToOrderSummaryURL, ctlRedirectToOrderSummaryPageURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.ProcessOrder_RedirectToOrderSummaryURLType, ctlRedirectToOrderSummaryPageURL.UrlType)

                    'Update Same Page Checkout
                    UpdateModuleSetting(ModuleSettingsNames.SamePageCheckoutEnabled, CStr(IIf(chkSamePageCheckOut.Checked, "Y", "N")))

                    'Enable Echeck
                    UpdateModuleSetting(ModuleSettingsNames.ECheckEnabled, CStr(IIf(chkECheck.Checked, "Y", "N")))
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                If Not Null.IsNull(itemId) Then
                    Dim objCtlPersonify As New OrderPaymentController
                    objCtlPersonify.Delete(itemId)
                End If

                ' Redirect back to the portal home page

                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
