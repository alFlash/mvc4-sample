
function getElementByPartialId(id) {
	if (document.forms[0].elements != null)
		for (i=0; i<document.forms[0].elements.length-1;i++ )
			if (document.forms[0].elements[i].name.indexOf(id)>0) {
				return document.forms[0].elements[i];
			}
}


function FillCustomerCreditCardInfo(checked,cctypeid,cctype,ccnumberid,ccnumber,expmonth,expmonthid,expyear,expyearid,nameoncardid,nameoncard,remembercardid)
{
//	When the user check use preferred card, set the values here expyear expmonth
	
		if (checked==true) 
			{
		var occtype=getElementByPartialId(cctypeid)
	    occtype.value =cctype;
		occtype.disabled=true;
		
		var occno = getElementByPartialId(ccnumberid)
	    occno.value =ccnumber;
		occno.disabled=true;
		//alert(Date.parse(expdate));
		//alert(expdate);	
		
	var oexpmonth = getElementByPartialId(expmonthid)
	var tempstr = expmonth.substring(0, 1)
        if (tempstr == "0")
        {
            expmonth = expmonth.substring(1, 2);
        }
		oexpmonth.value =expmonth;
		//oexpmonth.disabled=true;
		
var oexpyear = getElementByPartialId(expyearid)
		oexpyear.value =expyear;
		//oexpyear.disabled=true;
		
		
		var onameoncard = getElementByPartialId(nameoncardid)
		onameoncard.value =nameoncard;
		//onameoncard.disabled=true;
		
		var oremembercardid = getElementByPartialId(remembercardid)
		oremembercardid.checked = false;
		oremembercardid.disabled = true;
		
			}
		else
			{
	  	var occtype=getElementByPartialId(cctypeid)
	    
		occtype.disabled=false;
		//occtype.value = '';
		
		var occno = getElementByPartialId(ccnumberid)
	    occno.value ='';
		occno.disabled=false;
		
		var oexpmonth = getElementByPartialId(expmonthid)
		oexpmonth.disabled=false;
		
		var oexpyear = getElementByPartialId(expyearid)
		
		oexpyear.disabled=false;
		
		var onameoncard = getElementByPartialId(nameoncardid)
		//onameoncard.value='';
		
		onameoncard.disabled=false;
		
        var oremembercardid = getElementByPartialId(remembercardid)
		oremembercardid.checked = false;
		oremembercardid.disabled = false;
		
			}

}
