Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Collections.Generic
Imports Personify.DNN.Modules.OrderPayment.Business

Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PersonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports Personify.ShoppingCartManager.Business

Imports Telerik.Web.UI



Namespace Personify.DNN.Modules.OrderPayment

    Public MustInherit Class OrderPayment
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable
        Implements Entities.Modules.Communications.IModuleCommunicator



#Region "To be Deleted Code "
        'Private Function LoadClassOrderHeader() As OrderHeader()

        '    Dim ohd(0) As OrderHeader

        '    ohd(0) = New OrderHeader

        '    'Should come from localization
        '    ohd(0).hdProductCode = OrderHeader_ProductCode
        '    ohd(0).hdProductDescription = OrderHeader_ProductDescription

        '    ohd(0).hdRate = OrderHeader_Rate
        '    ohd(0).hdQuantity = OrderHeader_Quantity


        '    ohd(0).hdUnitAmount = OrderHeader_UnitAmount
        '    ohd(0).hdUnitDiscount = OrderHeader_UnitDiscount
        '    ohd(0).hdBaseTotalAmount = OrderHeader_BaseTotalAmount
        '    Return ohd
        'End Function

        'Private Function LoadClassBillShipAddressHeader() As BillShipAddressHeader()

        '    Dim ohd(0) As BillShipAddressHeader

        '    ohd(0) = New BillShipAddressHeader

        '    'Should come from localization
        '    ohd(0).hdBillTo = Localization.GetString("hdBillTo.Text", LocalResourceFile)
        '    ohd(0).hdShipTo = Localization.GetString("hdShipto.Text", LocalResourceFile)

        '    Return ohd
        'End Function


        'Private ReadOnly Property OrderHeader_ProductCode() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdProductCode.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Product Code"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property OrderHeader_ProductDescription() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdProductDescription.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Title"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property OrderHeader_Rate() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdRate.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Rate"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property OrderHeader_Quantity() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdQuantity.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Quantity"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property OrderHeader_BaseTotalAmount() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdBaseTotalAmount.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Total Amount"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property OrderHeader_UnitAmount() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdUnitAmount.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Unit Amount"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property OrderHeader_UnitDiscount() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("hdUnitDiscount.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Unit Discount"
        '        End If

        '        Return strRet

        '    End Get

        'End Property

        'Private ReadOnly Property Text_BillPrimaryEmployer() As String
        '    Get
        '        Dim strRet As String

        '        strRet = Localization.GetString("BillPrimaryEmployer.Text", LocalResourceFile)

        '        If strRet Is Nothing OrElse strRet.Length = 0 Then
        '            strRet = "Bill Primary Employer"
        '        End If

        '        Return strRet
        '    End Get
        'End Property

        'Public Class OrderHeader
        '    Public hdProductCode As String
        '    Public hdProductDescription As String
        '    Public hdRate As String
        '    Public hdQuantity As String
        '    Public hdUnitAmount As String
        '    Public hdUnitDiscount As String
        '    Public hdBaseTotalAmount As String
        'End Class

        'Public Class BillShipAddressHeader
        '    Public hdBillTo As String
        '    Public hdShipTo As String
        'End Class

#End Region

#Region "Controls"

        Protected OrderPaymentTemplate As Personify.WebControls.XslTemplate
        Protected CreditCardTemplate As Personify.WebControls.XslTemplate
        Protected OnlyCreditCardTemplate As Personify.WebControls.XslTemplate
        Protected ECheckTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents RadTabStrip1 As Telerik.Web.UI.RadTabStrip
        Protected WithEvents RadMultiPage1 As Telerik.Web.UI.RadMultiPage
        Protected WithEvents oMessageControl As WebControls.MessageControl
        Protected WithEvents oFARMessageControl As WebControls.MessageControl
        Protected WithEvents btnProcessOrderBillEmployer As Button
        Protected WithEvents btnCancelOrder As Button
#End Region

#Region "Private Variables"
        Private DisplayCreditCardTemplate As Boolean

        Private _ShowStatus As Boolean = False
        Private ECheckCodes As List(Of String)

        Private TotalAmount As String
        Private _ShowInvalidCardMsg As Boolean = False
#End Region

#Region "Event Handlers"

        Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Error

        End Sub

        Private Function IsRenewalOrder(ByVal pOrderMaster As TIMSS.API.OrderInfo.IOrderMaster) As Boolean

            Return pOrderMaster.OriginalOrderNumber.Length > 0

        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)

                'Register Java Scripts
                RegisterJSScripts("js\CreditCard.js", "CreditCard")
                RegisterJSScripts("js\Echeck.js", "Echeck")

                Dim strEventTarget As String


                If Me.IsPersonifyWebUserLoggedIn Or role = "personifyuser" Or role = "personifyadmin" Then
                    If Me.IsPersonifyWebUserLoggedIn Then
                    Else
                        ClearSessionObject(SessionKeys.PersonifyOrder)

                    End If
                    If EditSetting_ECheckEnabled Then
                        RadMultiPage1.Visible = True
                        RadTabStrip1.Visible = True
                        OnlyCreditCardTemplate.Visible = False
                    Else
                        RadMultiPage1.Visible = False
                        RadTabStrip1.Visible = False
                        OnlyCreditCardTemplate.Visible = True
                    End If

                    ECheckCodes = get_clsOrderCheckOutProcessHelper.GetECheckCodeList()

                    If Not IsPostBack Then
                        Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

                        oOM = GetOrderFromSessionObject()


                        If oMessageControl IsNot Nothing Then
                            oMessageControl.Clear()

                        End If
                        If oFARMessageControl IsNot Nothing Then
                            oFARMessageControl.Clear()
                        End If
                    End If

                    If IsPostBack Then
                        'Code for ship Via
                        If Request("__EVENTTARGET").IndexOf(String.Concat("ddlShipViaCode_", ModuleId.ToString)) > 0 Then
                            'strEventTarget = Request("__EVENTTARGET")

                            SetSelectedShipViaCode(ccControlValue("ddlShipViaCode"))
                        End If

                        'Code for Apply Discounts
                        If CheckIfPostbackByButton("btnUpdateCart_" + ModuleId.ToString) Then
                            ApplyOrderLevelPromoCode()
                        End If

                        'Code For Setting/reseting Primary Employer
                        If Request("__EVENTTARGET").IndexOf(BillPrimaryEmployerCheckBoxId + "_" + ModuleId.ToString) > 0 Then
                            CodeForSetResetBillPrimaryEmployer(BillPrimaryEmployerCheckBox)

                        End If

                        'Code If the Process Order Button Is Clicked
                        If CheckIfPostbackByButton("btnProcessOrder") Or CheckIfPostbackByButton("btnAuthorize") Or CheckIfPostbackByButton("btnProcessOrderBillEmployer") Then
                            If Not CheckIfPostbackByButton("btnProcessOrderBillEmployer") Then
                                If ValidateTemplateFields() Then
                                    ProcessOrder()
                                End If
                            Else
                                ProcessOrder()
                            End If
                        End If


                        'Code for resetting order to use default shipping
                        If Request("__EVENTTARGET").IndexOf("btnSwitchToDefaultShipping_" + ModuleId.ToString) > 0 Then
                            SwitchOrderToUseDefaultShipping()
                        End If
                        'Apply Line coupon
                        If Request("__EVENTTARGET").IndexOf("btnApplyCoupon_") > 0 Then
                            strEventTarget = Request("__EVENTTARGET")

                            ApplyLineLevelCoupons(GetOrderFromSessionObject(0).OrderNumber, strEventTarget.Split("_")(strEventTarget.Split("_").Length - 1))
                        End If
                        'Remove Coupin
                        If Request("__EVENTTARGET").IndexOf("btnRemoveCoupon_") > 0 Then
                            strEventTarget = Request("__EVENTTARGET")
                            RemoveLineLevelCoupons(strEventTarget.Split("_")(strEventTarget.Split("_").Length - 1))

                        End If

                        'Apply Line Promo
                        If Request("__EVENTTARGET").IndexOf("btnApplyPromo_") > 0 Then
                            strEventTarget = Request("__EVENTTARGET")

                            ApplyLineLevelPromoCodes(GetOrderFromSessionObject(0).OrderNumber, strEventTarget.Split("_")(strEventTarget.Split("_").Length - 1))
                        End If
                        'Remove Line Promo
                        If Request("__EVENTTARGET").IndexOf("btnRemovePromo_") > 0 Then
                            strEventTarget = Request("__EVENTTARGET")
                            RemoveLineLevelPromoCode(strEventTarget.Split("_")(strEventTarget.Split("_").Length - 1))

                        End If

                        'Apply Bill Me Flag to the Order Line
                        If Request("__EVENTTARGET").IndexOf("chkBillMeLater_") > 0 Then
                            strEventTarget = Request("__EVENTTARGET")
                            BillMeLaterFlagToggle(strEventTarget.Split("_")(strEventTarget.Split("_").Length - 1))
                        End If
                    End If

                    LoadOrderPaymentTemplate()

                    If DisplayCreditCardTemplate Then
                        LoadPaymentTemplate()

                        If Me.EditSetting_ECheckEnabled Then
                            DisableValidateRequiredFields()
                        End If
                        btnProcessOrderBillEmployer.Visible = False
                        btnProcessOrderBillEmployer.Enabled = False
                    Else
                        RadMultiPage1.Visible = False
                        RadTabStrip1.Visible = False
                        btnProcessOrderBillEmployer.Visible = True
                        btnProcessOrderBillEmployer.Enabled = True
                    End If

                Else
                    RadMultiPage1.Visible = False
                    RadTabStrip1.Visible = False

                    DisplayUserAccessMessage(role)
                End If



            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Edit Setting Properties"

        Private ReadOnly Property EditSetting_TemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.TemplateName), String)

                If strFileName Is Nothing OrElse strFileName.Length = 0 Then
                    strFileName = "OrderPayments.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property

        Private ReadOnly Property EditSetting_CreditCardTemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.CreditCard_TemplateName), String)

                If strFileName Is Nothing OrElse strFileName.Length = 0 Then
                    strFileName = "CreditCardWithCVV2.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property

        Private ReadOnly Property EditSetting_ECheckTemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.ECheck_TemplateName), String)

                If strFileName Is Nothing OrElse strFileName.Length = 0 Then
                    strFileName = "ECheck.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property


        Private ReadOnly Property EditSetting_EnableAdvanceShippingFeature() As Boolean
            Get
                Dim strReturn As String
                strReturn = CType(Settings(ModuleSettingsNames.EnableAdvanceShipping), String)

                If Not strReturn Is Nothing AndAlso strReturn.Length = 0 Then
                    Return False
                Else
                    If strReturn = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                End If
            End Get
        End Property

        Private ReadOnly Property EditSetting_AdvanceShippingURL() As String
            Get
                Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.AdvanceShippingUrl), String)

            End Get
        End Property

        Private ReadOnly Property EditSetting_ChangeBillShipAddressURL() As String
            Get
                Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ChangeBillShipAddressURL), String)

            End Get
        End Property

        Private ReadOnly Property EditSetting_EnableCouponFeature() As Boolean
            Get
                Dim strReturn As String
                strReturn = CType(Settings(ModuleSettingsNames.EnableCouponFeature), String)

                If Not strReturn Is Nothing AndAlso strReturn.Length = 0 Then
                    Return False
                Else
                    If strReturn = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                End If
            End Get
        End Property

        Private ReadOnly Property EditSetting_EnableBillMeFeature() As Boolean
            Get
                Dim strReturn As String
                strReturn = CType(Settings(ModuleSettingsNames.EnableBillMeFeature), String)

                If Not strReturn Is Nothing AndAlso strReturn.Length = 0 Then
                    Return False
                Else
                    If strReturn = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                End If
            End Get
        End Property

        Private Property ShowStatus() As Boolean
            Get
                Return _ShowStatus
            End Get
            Set(ByVal value As Boolean)
                _ShowStatus = value
            End Set
        End Property

        Private ReadOnly Property EditSetting_PromotionCodeAtLineOrOrderLevel() As String
            Get
                Dim strReturn As String
                strReturn = CType(Settings(ModuleSettingsNames.PromotionCodeAtLineOrOrderLevel), String)

                If Not strReturn Is Nothing AndAlso strReturn.Length = 0 Then
                    Return "ORDER"
                Else
                    Return strReturn
                End If
            End Get

        End Property

        Private ReadOnly Property EditSetting_ProcessOrder_RedirectToLoginURL() As String
            Get
                Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToLoginURL), String)

            End Get
        End Property

        Private ReadOnly Property EditSetting_ProcessOrder_RedirectToOrderSummaryURL() As String
            Get
                Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ProcessOrder_RedirectToOrderSummaryURL), String)

            End Get
        End Property


        Private ReadOnly Property EditSetting_SamePageCheckoutEnabled() As Boolean
            Get
                Try
                    If CType(Settings(ModuleSettingsNames.SamePageCheckoutEnabled), String) = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    Return False
                End Try
            End Get
        End Property

        Private ReadOnly Property EditSetting_ECheckEnabled() As Boolean
            Get
                Try
                    If CType(Settings(ModuleSettingsNames.ECheckEnabled), String) = "Y" Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    Return False
                End Try
            End Get
        End Property
#End Region

#Region "The Id's for Controls"

        Public Const ChangeBillAddressHyperLinkId As String = "hlnkChangeBillAddressId"
        Public Const ChangeShipAddressHyperLinkId As String = "hlnkChangeShipAddressId"
        Public Const AdvanceShippingHyperLinkId As String = "hlnkAdvanceShipping"

        Public Const BillPrimaryEmployerCheckBoxId As String = "BillPrimaryEmployer"

        Public Const ccTypeId As String = "ddlCCType"
        Public Const ccNumberId As String = "txtCCNumber"
        Public Const ccCVV2Id As String = "txtCVV2"
        Public Const ccMonthId As String = "txtccMonth"
        Public Const ccYearId As String = "txtccYear"
        Public Const ccNameonCardId As String = "txtccNameOnCard"
        Public Const ccUseCCOnFileId As String = "chkUseCreditCardOnFile"
        Public Const ccRememberMyInfoId As String = "chkRememberMyCreditCard"

        Public Const eckTypeId As String = "ddlEckType"
        Public Const eckRoutingNumberId As String = "txtRoutingNumber"
        Public Const eckAccountNumberId As String = "txtAccountNumber"
        Public Const eckCheckNumberId As String = "txtCheckNumber"
        Public Const eckAccountNameId As String = "txtAccountName"
        Public Const eckDriversLicenseId As String = "txtDriversLicense"
        Public Const eckAdditionalIDInfo As String = "txtAdditionalIDInfo"
        Public Const eckCheckTypeId As String = "ddlEckCheckType"
#End Region

#Region "Constants for Field Prefixes"
        'We dynamically create id's for some of the controls defined in the XSL. the prefixes for these id's neeed to be defined here. 

        Public Const ShipViaRadioButtonIdPrefix As String = "ShipviaRadioButton"
        Public Const AdvanceShippingHyperlinkIdPrefix As String = "AdvanceShipHyperlink"

#End Region

#Region "Data Classes"
        Public Class Months
            Public MonthName As String
            Public MonthNumber As String
        End Class

        Public Class Years
            Public Year As String
        End Class

        Public Class CreditCardInformation


            Public CreditCardType As String
            Public CreditCardNumber As String
            Public CVV2 As String
            Public ExpirationMonth As Integer
            Public ExpirationYear As Integer
            Public NameOnCard As String

            Public UseCreditCardOnFile As Boolean
            Public RememberMyCard As Boolean

        End Class
#End Region


#Region " Control Values"


        Private ReadOnly Property BillPrimaryEmployerCheckBox() As Boolean
            Get
                Dim controlId As String = ""
                Dim bReturn As Boolean = False
                controlId = BillPrimaryEmployerCheckBoxId + "_" + ModuleId.ToString

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(controlId) Then
                        If Page.Request.Form(Page.Request.Form.Keys(i)).ToLower = "on" Then
                            bReturn = True
                            Exit For
                        End If

                    End If
                Next

                Return bReturn
            End Get
        End Property


        Private ReadOnly Property BillMeLaterCheckBox(ByVal OrderNumber As String, ByVal OrderLineNumber As Integer) As Boolean
            Get
                Dim controlId As String = ""
                Dim bReturn As Boolean = False
                controlId = "chkBillMeLater" + "_" + OrderNumber + "_" + OrderLineNumber.ToString

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(controlId) Then
                        If Page.Request.Form(Page.Request.Form.Keys(i)).ToLower = "on" Then
                            bReturn = True
                            Exit For
                        End If

                    End If
                Next

                Return bReturn
            End Get
        End Property


#End Region

#Region "Credit CArd Control Values"

        Private ReadOnly Property ccControlValue(ByVal ControlId As String) As String
            Get
                Dim ocontrolId As String = ""
                Dim strReturn As String = ""
                ocontrolId = ControlId + "_" + ModuleId.ToString

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ocontrolId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

        Private ReadOnly Property PostBackValue(ByVal ControlId As String) As String
            Get
                Dim strReturn As String = ""

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ControlId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

#End Region

#Region "Manage Order from Session"

        'Private Sub GetOrderMastersObject()
        '    'TODO - the order master collection should come from session object. For testing, fetching a new order from database

        '    ''Personify.ApplicationManager.Orders.m
        '    'Dim oOrderDetails As TIMSS.API.OrderInfo.IOrderDetails

        '    'oOrderDetails = Personify.ApplicationManager.Orders.GetOrderDetails(PortalId, "1000005847")


        '    'Return oOrderDetails

        '    Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters = Nothing

        '    Dim oParams(2) As Personify.ApplicationManager.DataTransfer.OrderEntryParameters
        '    oParams(0) = New Personify.ApplicationManager.DataTransfer.OrderEntryParameters
        '    oParams(0).ProductId = 97
        '    oParams(0).Quantity = 1

        '    oParams(1) = New Personify.ApplicationManager.DataTransfer.OrderEntryParameters
        '    oParams(1).ProductId = 97
        '    oParams(1).Quantity = 1

        '    oParams(2) = New Personify.ApplicationManager.DataTransfer.OrderEntryParameters
        '    oParams(2).ProductId = 97
        '    oParams(2).Quantity = 1

        '    'oParams(2) = New Personify.ApplicationManager.DataTransfer.OrderEntryParameters
        '    'oParams(2).ProductId = 260
        '    'oParams(2).Quantity = 1

        '    'oOrderMasters = Personify.ApplicationManager.Orders.CreateOrders(PortalId, "000000003133", 0, oParams)
        '    'oOrderMasters(0).Details(0).ShipViaCode = oOrderMasters(0).Details(0).ShipViaCode.List("FEDEX").ToCodeObject

        '    'SessionManager.AddSessionObject(WebUtility.SessionKeys.PersonifyOrder, oOrderMasters)


        'End Sub

        Private Function GetOrderFromSessionObject() As TIMSS.API.OrderInfo.IOrderMasters

            'TODO -- Comment the following



            If Not GetSessionObject(SessionKeys.PersonifyOrder) Is Nothing Then
                Return CType(GetSessionObject(SessionKeys.PersonifyOrder), TIMSS.API.OrderInfo.IOrderMasters)
            Else
                'GetOrderMastersObject()
                Return CType(GetSessionObject(SessionKeys.PersonifyOrder), TIMSS.API.OrderInfo.IOrderMasters)

                Return Nothing
            End If

        End Function



        Private Function RedirectToLoginPageIfUserNotLoggedIn() As Boolean

            Dim bReturn As Boolean = False

            If MasterCustomerId.Length = 0 Then
                bReturn = True
                Response.Redirect(EditSetting_ProcessOrder_RedirectToLoginURL)

            End If

            Return bReturn
        End Function

        Private Sub RaiseEventRespondToValidationIssues()
            'This is only for 1 page check out
            'Aseem Changes
            Dim e As New DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs

            RaiseEvent ModuleCommunication(PersonifyCheckOut_ModuleCommunicationKeys.RespondToValidationIssues, e)

        End Sub

        Private Sub ClearSession()
            ClearSessionObject(SessionKeys.PersonifyOrdersViewList)
            ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.BOTH.ToString)
            ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.SHIP.ToString)
            ClearSessionObject(SessionKeys.PersonifyWebOrderMaster, MasterCustomerId + SubCustomerId.ToString + CustomerMode.BILL.ToString)
            ClearSessionObject(SessionKeys.PersonifyMembershipRenewalsViewList)
            ClearSessionObject(0, SessionKeys.PersonifyOrderMaster, MasterCustomerId)
            ClearSessionObject(SessionKeys.PersonifyPayOrderIds)
        End Sub

        Private Sub ProcessOrder()

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters
            Dim OrderNumber As String
            Dim RxVI As TIMSS.API.Core.Validation.IssuesCollection = Nothing
            Dim isEcheck As Boolean = False

            If RedirectToLoginPageIfUserNotLoggedIn() Then
                Exit Sub
            End If



            Try
                If EditSetting_SamePageCheckoutEnabled = True Then
                    'RaiseEvent ModuleCommunication()
                    oOM = GetOrderFromSessionObject()
                    If oOM Is Nothing Then
                        Dim args As New DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs
                        RaiseEvent ModuleCommunication(PersonifyCheckOut_ModuleCommunicationKeys.CreateOrderFromProductIds, args)
                        'start 3246-5875068
                        If args.Type IsNot Nothing AndAlso args.Type.ToUpper() = "ERROR" Then
                            Exit Sub
                        End If
                        'end 3246-5875068
                    End If
                End If

                oOM = GetOrderFromSessionObject()

                If oOM Is Nothing Then
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderForCheckOut", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    Exit Sub
                End If
                'an cuna meeting fix
                If DoesOrderHaveABadAddress("BILL") Then
                    Skins.Skin.AddModuleMessage(Me, "Please enter a valid Billing Address", Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If
                If DoesOrderHaveABadAddress("SHIP") Then
                    Skins.Skin.AddModuleMessage(Me, "Please enter a valid Shipping Address", Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If

                OrderNumber = oOM(0).OrderNumber

                'Aseem Changes
                'This is only for 1 page check out
                RaiseEventRespondToValidationIssues()


                Dim strUsePreferredCard As String
                Dim strccNo As String = ""
                Dim strccMonth As String = ""
                Dim strccYear As String = ""
                Dim strccType As String = ""
                Dim strccName As String = ""
                Dim strccCvv2 As String = ""
                Dim strRememberMYCard As String = ""

                Dim bRemembeMyCard As Boolean
                Dim bUsePreferredCard As Boolean = False

                Dim streckType As String = ""
                Dim streckCheckType As String = ""
                Dim streckRoutingNumber As String = ""
                Dim streckAccountNumber As String = ""
                Dim streckCheckNumber As String = ""
                Dim streckAccountName As String = ""
                Dim streckDriversLicense As String = ""
                Dim streckAdditionalIDInfo As String = ""
                Dim streckFederalTaxId As String = ""
                Dim streckDateOfBirth As String = ""
                Dim strIdType As String = ""

                strUsePreferredCard = ccControlValue(ccUseCCOnFileId)
                bUsePreferredCard = strUsePreferredCard.Length > 0

                If Me.EditSetting_ECheckEnabled Then
                    For i As Integer = 0 To RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls.Count - 1
                        If RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "CreditCardTemplate" Then
                            isEcheck = False
                        ElseIf RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "ECheckTemplate" Then
                            isEcheck = True
                        End If
                    Next
                Else
                    isEcheck = False
                End If

                If bUsePreferredCard = True Then
                    'strccCvv2 = ccControlValue(ccCVV2Id)
                    'strccMonth = ccControlValue(ccMonthId)
                    'If strccMonth.Length = 0 Then
                    '    strccMonth = "0"
                    'End If
                    'strccYear = ccControlValue(ccYearId)
                    'If strccYear.Length = 0 Then
                    '    strccYear = "0"
                    'End If
                    'strRememberMYCard = ccControlValue(ccRememberMyInfoId)
                    'bRemembeMyCard = strRememberMYCard.Length > 0

                    Dim oCCInfo As TIMSS.API.CustomerInfo.ICustomerCreditCards
                    oCCInfo = get_clsOrderCheckOutProcessHelper.GetCustomerCreditCardOnRecord(MasterCustomerId, SubCustomerId)

                    strccName = ccControlValue(ccNameonCardId)
                    strccNo = oCCInfo(0).CCReferenceDecrypted
                    strccType = oCCInfo(0).ReceiptTypeCodeString

                    strccCvv2 = oCCInfo(0).Cvv2Number
                    'strccMonth = oCCInfo(0).CCExpirationDate.Month
                    'strccYear = oCCInfo(0).CCExpirationDate.Year

                    strccMonth = ccControlValue(ccMonthId)
                    If strccMonth.Length = 0 Then
                        strccMonth = "0"
                    End If

                    strccYear = ccControlValue(ccYearId)
                    If strccYear.Length = 0 Then
                        strccYear = "0"
                    End If

                    strccName = ccControlValue(ccNameonCardId)

                    oCCInfo = Nothing
                Else
                    strccNo = ccControlValue(ccNumberId)
                    strccType = ccControlValue(ccTypeId)

                    strccMonth = ccControlValue(ccMonthId)
                    If strccMonth.Length = 0 Then
                        strccMonth = "0"
                    End If
                    strccYear = ccControlValue(ccYearId)
                    If strccYear.Length = 0 Then
                        strccYear = "0"
                    End If
                    strccName = ccControlValue(ccNameonCardId)
                    strccCvv2 = ccControlValue(ccCVV2Id)
                    strRememberMYCard = ccControlValue(ccRememberMyInfoId)
                    bRemembeMyCard = strRememberMYCard.Length > 0
                End If

                If isEcheck Then
                    streckType = ccControlValue(eckTypeId)
                    streckCheckType = ccControlValue(eckCheckTypeId)
                    streckRoutingNumber = ccControlValue(eckRoutingNumberId)
                    streckAccountNumber = ccControlValue(eckAccountNumberId)
                    streckCheckNumber = ccControlValue(eckCheckNumberId)
                    streckAccountName = ccControlValue(eckAccountNameId)
                    strIdType = ccControlValue("IDType")
                    If ccControlValue("IDType") = "DL" Then
                        streckDriversLicense = ccControlValue(eckDriversLicenseId)
                        streckAdditionalIDInfo = ccControlValue(eckAdditionalIDInfo)
                    Else
                        streckFederalTaxId = ccControlValue(eckDriversLicenseId)
                        streckDateOfBirth = ccControlValue(eckAdditionalIDInfo)
                    End If
                End If

                'In case of Bill Me, Get the Purchase Order number if entered

                Dim strPurchaseOrderNo As String = ccControlValue("txtPurchaseOrderNumber")

                'ccMonthId , ccYearId , ccTypeId ,ccNameonCardId , ccRememberMyInfoId

                If BillPrimaryEmployerCheckBox Then

                    If get_clsOrderCheckOutProcessHelper.SaveOrder(oOM, strPurchaseOrderNo) Then

                        ClearSessionObject(SessionKeys.PersonifyOrder)
                        ClearSessionObject(0, SessionKeys.PersonifyOrderMaster, MasterCustomerId)
                        If oMessageControl IsNot Nothing Then
                            oMessageControl.Clear()
                        End If
                        If oFARMessageControl IsNot Nothing Then
                            oFARMessageControl.Clear()
                        End If


                        ClearSession()

                        EmptyShoppingCartAfterSave()

                        Response.Redirect(EditSetting_ProcessOrder_RedirectToOrderSummaryURL & "&ORDERNUMBER=" + OrderNumber)

                    Else
                        'Handle Validation Issues
                        If Not EditSetting_SamePageCheckoutEnabled Then
                            ShowValidationIssues(oOM.ValidationIssues)
                        End If

                    End If
                Else
                    If bRemembeMyCard Then
                        bUsePreferredCard = False
                    End If

                    Dim SaveOrderResult As Boolean
                    If isEcheck Then
                        SaveOrderResult = get_clsOrderCheckOutProcessHelper.SaveOrder(streckType, streckAccountName, streckRoutingNumber, streckAccountNumber, streckCheckNumber, streckCheckType, streckDriversLicense, streckAdditionalIDInfo, streckFederalTaxId, streckDateOfBirth, strIdType, oOM, RxVI, strPurchaseOrderNo)
                    Else
                        SaveOrderResult = get_clsOrderCheckOutProcessHelper.SaveOrder(oOM, strccNo, strccType, CInt(strccMonth), CInt(strccYear), strccCvv2, strccName, bRemembeMyCard, RxVI, bUsePreferredCard, strPurchaseOrderNo)
                    End If

                    If SaveOrderResult Then

                        ClearSessionObject(SessionKeys.PersonifyOrder)
                        ClearSessionObject(0, SessionKeys.PersonifyOrderMaster, MasterCustomerId)
                        If oMessageControl IsNot Nothing Then
                            oMessageControl.Clear()
                        End If
                        If oFARMessageControl IsNot Nothing Then
                            oFARMessageControl.Clear()
                        End If

                        EmptyShoppingCartAfterSave()

                        ClearSession()
                        strccNo = Nothing
                        streckRoutingNumber = Nothing
                        streckAccountNumber = Nothing

                        Response.Redirect(EditSetting_ProcessOrder_RedirectToOrderSummaryURL & "&ORDERNUMBER=" + OrderNumber)

                    Else
                        'Handle Validation Issues
                        Dim bRedirect As Boolean = True
                        If Not EditSetting_SamePageCheckoutEnabled Then


                            If oOM(0).ValidationIssues.Count > 0 Then
                                ShowValidationIssues(oOM.ValidationIssues)
                            End If

                            If RxVI IsNot Nothing AndAlso RxVI.Count > 0 Then
                                oFARMessageControl.Show(RxVI)
                                'ShowValidationIssues(RxVI)
                            ElseIf Not (oOM(0).ValidationIssues.Count > 0) Then
                                Skins.Skin.AddModuleMessage(Me, Localization.GetString("CannotSaveOrder", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            End If
                        Else
                            'Show validation issues if they are payment related. The rest will be taken care by the create order web part
                            If RxVI IsNot Nothing AndAlso RxVI.Count > 0 Then
                                'ShowValidationIssues(RxVI)
                                oFARMessageControl.Show(RxVI)
                                bRedirect = False
                            Else
                                ' if same page checkout is enabled, the order create page takes care of the VI's
                                If Not EditSetting_SamePageCheckoutEnabled Then
                                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("CannotSaveOrder", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                End If


                            End If

                        End If
                        If bRedirect Then
                            strccNo = Nothing
                            streckRoutingNumber = Nothing
                            streckAccountNumber = Nothing
                            NavigateURL(TabId)
                            'Response.Redirect("")
                        End If

                    End If
                End If
                strccNo = Nothing
                streckRoutingNumber = Nothing
                streckAccountNumber = Nothing

            Catch ex As Exception

                Skins.Skin.AddModuleMessage(Me, Localization.GetString("CannotSaveOrder", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End Try

        End Sub
        Private Sub ShowValidationIssues(ByVal ValidationIssues As TIMSS.API.Core.Validation.IssuesCollection)

            Dim bDisplayVI As Boolean = False
            'Show validation issues only if an un responded validation issue exists
            For Each issue As TIMSS.API.Core.Validation.IIssue In ValidationIssues


                Select Case issue.Severity
                    Case TIMSS.API.Core.Validation.IssueSeverityEnum.Error, TIMSS.API.Core.Validation.IssueSeverityEnum.Information
                        bDisplayVI = True
                    Case TIMSS.API.Core.Validation.IssueSeverityEnum.Question
                        If issue.ResponseRequired = True Then
                            If issue.Responded = False Then
                                bDisplayVI = True
                            End If
                        End If
                End Select

            Next
            If bDisplayVI Then
                oMessageControl.Show(ValidationIssues)
            End If

        End Sub

        Private Sub EmptyShoppingCartAfterSave()

            If EditSetting_SamePageCheckoutEnabled = False Then
                Dim oController As New ShoppingCartController
                oController.DeleteCart(MasterCustomerId, SubCustomerId, PortalId)
                oController = Nothing
            End If


        End Sub

        Private Function CheckIfPostbackByButton(ByVal ButtonName As String) As Boolean

            'Dim strControlName As String = "btnUpdateCart_" + ModuleId.ToString

            'strControlName = ButtonName + "_" + ModuleId.ToString
            Dim bReturn As Boolean = False

            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(ButtonName) > 0 Then
                    bReturn = True
                    Exit For
                End If

            Next

            Return bReturn

        End Function

        Private Sub ApplyOrderLevelPromoCode()

            Dim strPromoCode As String = ""
            Dim strDiscountTextBoxID As String = "txtPromoCodeAtOrderLevel"

            If Me.EditSetting_PromotionCodeAtLineOrOrderLevel = "ORDER" Then
                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(strDiscountTextBoxID) Then
                        strPromoCode = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                'If strPromoCode.Length > 0 Then
                SerOrderLevelPromoCode(strPromoCode)
                'End If
                'Apply strPromoCode
            End If


        End Sub

        Private Sub ApplyLineLevelPromoCodes(ByVal OrderNumber As String, ByVal OrderLineNumber As Integer)

            Dim strDiscountTextBoxID As String = ""
            Dim strPromoCode As String = ""
            Dim strOrderLineNumber As String = ""

            If Not Me.EditSetting_PromotionCodeAtLineOrOrderLevel = "LINE" Then
                Exit Sub
            End If

            strDiscountTextBoxID = "txtPromoCode" + "_" + OrderNumber + "_" + OrderLineNumber.ToString

            If Me.EditSetting_EnableCouponFeature = True Then
                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(strDiscountTextBoxID) Then
                        strPromoCode = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                If strPromoCode.Length > 0 Then
                    SetOrderLineLevelPromoCode(OrderLineNumber, strPromoCode)
                End If
            End If


        End Sub

        Private Sub RemoveLineLevelPromoCode(ByVal OrderLineNumber As Integer)

            Dim strDiscountTextBoxID As String = ""

            'Dim htLineLevelPromoCodes As New System.Collections.Specialized.NameValueCollection
            strDiscountTextBoxID = "txtCouponCode"

            If Me.EditSetting_EnableCouponFeature = True Then
                SetOrderLineLevelPromoCode(OrderLineNumber, "")
            End If
        End Sub

        Private Sub BillMeLaterFlagToggle(ByVal OrderLineNumber As Integer)

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters
            Dim BillMeLaterFlag As Boolean
            oOM = GetOrderFromSessionObject()


            BillMeLaterFlag = BillMeLaterCheckBox(oOM(0).OrderNumber, OrderLineNumber)

            If Me.EditSetting_EnableBillMeFeature = True Then
                oOM = get_clsOrderCheckOutProcessHelper.SetBillMeLaterFlagAtOrderLineLevel(oOM(0).OrderNumber, OrderLineNumber, BillMeLaterFlag, oOM)

            End If


            AddSessionObject(SessionKeys.PersonifyOrder, oOM)


        End Sub

        Private Sub ApplyLineLevelCoupons(ByVal OrderNumber As String, ByVal OrderLineNumber As Integer)

            Dim strDiscountTextBoxID As String = ""
            Dim strCouponCode As String = ""
            Dim strOrderLineNumber As String = ""
            'Dim htLineLevelPromoCodes As New System.Collections.Specialized.NameValueCollection
            strDiscountTextBoxID = "txtCouponCode" + "_" + OrderNumber + "_" + OrderLineNumber.ToString

            If Me.EditSetting_EnableCouponFeature = True Then
                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(strDiscountTextBoxID) Then

                        strCouponCode = Page.Request.Form(Page.Request.Form.Keys(i))

                        'strOrderLineNumber = Page.Request.Form.Keys(i).Split("_")(Page.Request.Form.Keys(i).Split("_").Length - 1)
                        'If strOrderLineNumber = OrderLineNumber.ToString Then
                        '    htLineLevelPromoCodes.Add(strOrderLineNumber, strCouponCode)
                        'End If
                        Exit For
                    End If
                Next


                If strCouponCode.Length > 0 Then
                    SetOrderLineLevelCouponCode(OrderLineNumber, strCouponCode)
                End If
            End If


        End Sub

        Private Sub RemoveLineLevelCoupons(ByVal OrderLineNumber As Integer)

            Dim strDiscountTextBoxID As String = ""

            'Dim htLineLevelPromoCodes As New System.Collections.Specialized.NameValueCollection
            strDiscountTextBoxID = "txtCouponCode"

            If Me.EditSetting_EnableCouponFeature = True Then
                SetOrderLineLevelCouponCode(OrderLineNumber, "")

            End If
        End Sub

        Private Sub SetOrderLineLevelPromoCode(ByVal OrderLineNumber As Integer, ByVal PromoCode As String)

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetMarketCodeAtOrderLineLevel(oOM(0).OrderNumber, OrderLineNumber, PromoCode, oOM)

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

        End Sub

        Private Sub SetOrderLineLevelCouponCode(ByVal OrderLineNumber As Integer, ByVal CouponCode As String)

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetCouponCodeAtOrderLineLevel(oOM(0).OrderNumber, OrderLineNumber, CouponCode, oOM)

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

        End Sub

        Private Sub SerOrderLevelPromoCode(ByVal Promocode As String)

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetMarketCodeAtOrderLevel(Promocode, oOM)

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

        End Sub

        Private Sub SetSelectedShipViaCode(ByVal ShipViaCode As String)

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetShipViaCodeForOrder(ShipViaCode, oOM)

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

        End Sub

        Private Sub CodeForSetResetBillPrimaryEmployer(ByVal BillPrimaryEmployer As Boolean)


            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetResetBillPrimaryEmployer(BillPrimaryEmployer, oOM)

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)
        End Sub

        Private Sub SwitchOrderToUseDefaultShipping()

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetDefaultShipViaForEntireOrder(oOM)

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

        End Sub

#End Region

        Private Sub DisableValidateRequiredFields()
            Dim enable As Boolean = False
            For i As Integer = 0 To RadTabStrip1.Tabs.Count - 1
                If RadTabStrip1.Tabs(i).Selected Then
                    enable = True
                Else
                    enable = False
                End If
                For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                    If RadMultiPage1.PageViews(i).Controls(j).GetType.Name = "XslTemplate" Then
                        For k As Integer = 0 To RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls.Count - 1
                            If RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls(k).GetType.Name = "RequiredFieldValidator" Then
                                CType(RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls(k), System.Web.UI.WebControls.RequiredFieldValidator).Enabled = enable
                            End If
                        Next
                    End If
                Next
            Next
        End Sub

        Private Function ValidateTemplateFields() As Boolean

            If Me.EditSetting_ECheckEnabled Then
                'For i As Integer = 0 To RadTabStrip1.Tabs.Count - 1
                '    If RadTabStrip1.Tabs(i).Selected Then
                '        For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                '            If RadMultiPage1.PageViews(i).Controls(j).GetType.Name = "XslTemplate" Then
                '                For k As Integer = 0 To RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls.Count - 1
                '                    If RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls(k).GetType.Name = "RequiredFieldValidator" Then
                '                        If PostBackValue(CType(RadMultiPage1.PageViews(i).Controls(j).Controls(0).Controls(k), System.Web.UI.WebControls.RequiredFieldValidator).ControlToValidate) = "" Then
                '                            Return False
                '                        End If
                '                    End If
                '                Next
                '            End If
                '        Next
                '    End If
                'Next
                Dim isECheck As Boolean = False
                For i As Integer = 0 To RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls.Count - 1
                    If RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "CreditCardTemplate" Then
                        isECheck = False
                    ElseIf RadMultiPage1.PageViews(RadMultiPage1.SelectedIndex).Controls(i).ID = "ECheckTemplate" Then
                        isECheck = True
                    End If
                Next

                If Not isECheck Then
                    If Not ccControlValue(ccUseCCOnFileId).ToLower = "on" Then
                        If ccControlValue(ccTypeId) = "" Then
                            Return False
                        End If

                        Dim ccNumbervalue As String = ccControlValue(ccNumberId)
                        If ccNumbervalue = "" Then
                            Return False
                        ElseIf DoesContainCharacter(ccNumbervalue) Then
                            _ShowInvalidCardMsg = True
                            Return False
                        End If
                    End If

                    If ccControlValue(ccMonthId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccYearId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccNameonCardId) = "" Then
                        Return False
                    End If
                Else
                    If ccControlValue(eckTypeId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckCheckTypeId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckRoutingNumberId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckAccountNumberId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckCheckNumberId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckAccountNameId) = "" Then
                        Return False
                    End If

                    If ccControlValue(eckDriversLicenseId) = "" Then
                        Return False
                    End If

                    If ccControlValue("IDType") = "SSN" Then
                        If ccControlValue(eckAdditionalIDInfo) = "" OrElse Not IsDate(ccControlValue(eckAdditionalIDInfo)) Then
                            Return False
                        End If
                    Else
                        If ccControlValue(eckAdditionalIDInfo) = "" Then
                            Return False
                        End If
                    End If
                End If
                Return True
            Else
                If OnlyCreditCardTemplate IsNot Nothing Then
                    If Not ccControlValue(ccUseCCOnFileId).ToLower = "on" Then


                        If ccControlValue(ccTypeId) = "" Then
                            Return False
                        End If

                        Dim ccNumbervalue As String = ccControlValue(ccNumberId)
                        If ccNumbervalue = "" Then
                            Return False
                        ElseIf DoesContainCharacter(ccNumbervalue) Then
                            _ShowInvalidCardMsg = True
                            Return False
                        End If
                    End If
                    If ccControlValue(ccMonthId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccYearId) = "" Then
                        Return False
                    End If

                    If ccControlValue(ccNameonCardId) = "" Then
                        Return False
                    End If
                    'For k As Integer = 0 To OnlyCreditCardTemplate.Controls(0).Controls.Count - 1
                    '    If OnlyCreditCardTemplate.Controls(0).Controls(k).GetType.Name = "RequiredFieldValidator" Then
                    '        If PostBackValue(CType(OnlyCreditCardTemplate.Controls(0).Controls(k), System.Web.UI.WebControls.RequiredFieldValidator).ControlToValidate) = "" Then
                    '            Return False
                    '        End If
                    '    End If
                    'Next
                    Return True
                Else
                    Return False
                End If
            End If
        End Function

        Private Function LoadMonths() As Months()

            Dim oMonths(12) As Months

            For i As Integer = 0 To 12
                oMonths(i) = New Months
            Next
            oMonths(0).MonthName = " "
            oMonths(0).MonthNumber = " "
            oMonths(1).MonthName = "January"
            oMonths(1).MonthNumber = "1"
            oMonths(2).MonthName = "February"
            oMonths(2).MonthNumber = "2"
            oMonths(3).MonthName = "March"
            oMonths(3).MonthNumber = "3"

            oMonths(4).MonthName = "April"
            oMonths(4).MonthNumber = "4"
            oMonths(5).MonthName = "May"
            oMonths(5).MonthNumber = "5"

            oMonths(6).MonthName = "June"
            oMonths(6).MonthNumber = "6"

            oMonths(7).MonthName = "July"
            oMonths(7).MonthNumber = "7"

            oMonths(8).MonthName = "August"
            oMonths(8).MonthNumber = "8"

            oMonths(9).MonthName = "September"
            oMonths(9).MonthNumber = "9"

            oMonths(10).MonthName = "October"
            oMonths(10).MonthNumber = "10"

            oMonths(11).MonthName = "November"
            oMonths(11).MonthNumber = "11"

            oMonths(12).MonthName = "December"
            oMonths(12).MonthNumber = "12"



            Return oMonths

        End Function

        Private Function LoadYears() As Years()

            '3246-6880268
            Dim oYears(10) As Years

            Dim i As Integer = 1
            Dim StartDate As Date = Date.Now.AddYears(-1)
            oYears(0) = New Years
            oYears(0).Year = " "
            '3246-6880268
            For i = 1 To 10
                oYears(i) = New Years
                oYears(i).Year = StartDate.AddYears(i).Year
            Next

            Return oYears

        End Function

        Private Sub LoadPaymentTemplate()
            For i As Integer = 0 To RadMultiPage1.PageViews.Count - 1
                For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                    CreditCardTemplate = RadMultiPage1.PageViews(i).Controls(j).FindControl("CreditCardTemplate")
                    If CreditCardTemplate IsNot Nothing Then
                        Exit For
                    End If
                Next
                If CreditCardTemplate IsNot Nothing Then
                    Exit For
                End If
            Next

            If EditSetting_ECheckEnabled Then
                LoadCreditCardTemplate(CreditCardTemplate)
                For i As Integer = 0 To RadMultiPage1.PageViews.Count - 1
                    For j As Integer = 0 To RadMultiPage1.PageViews(i).Controls.Count - 1
                        ECheckTemplate = RadMultiPage1.PageViews(i).Controls(j).FindControl("ECheckTemplate")
                        If ECheckTemplate IsNot Nothing Then
                            Exit For
                        End If
                    Next
                    If ECheckTemplate IsNot Nothing Then
                        Exit For
                    End If
                Next

                LoadECheckTemplate()
            Else
                LoadCreditCardTemplate(OnlyCreditCardTemplate)
            End If
        End Sub

        Private Sub LoadCreditCardTemplate(ByVal TempCreditCardTemplate As Personify.WebControls.XslTemplate)



            'Do Not Display Template if No Items in CART
            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            'Get OrderMaster object ./... this comes from session object ... Shopping Cart Creates the order and stores it in the session
            oOM = GetOrderFromSessionObject()

            If EditSetting_SamePageCheckoutEnabled = True Then

            Else
                If oOM Is Nothing Then
                    'Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderForCheckOut", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    'btnProcessOrder.Visible = False
                    Exit Sub
                End If
            End If



            ' Valid Receipt Type Codes for Current E-Commerce Batch 
            Dim oVs() As ValidReceiptCodes
            Dim strError As String = ""
            oVs = get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError)

            If strError.Length > 0 Then

                Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile)

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile) + "</br>" + strError, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)


                TempCreditCardTemplate.Visible = False
                RadMultiPage1.Visible = False
                RadTabStrip1.Visible = False
                ClearSessionObject(SessionKeys.PersonifyOrder)
                ClearSessionObject(0, SessionKeys.PersonifyOrderMaster, MasterCustomerId)
            Else


                Dim oCCInfo As TIMSS.API.CustomerInfo.ICustomerCreditCards
                Dim CCOnFileExists As Boolean
                'CCOnFileExists = get_clsOrderCheckOutProcessHelper.CheckIfThePayorHAsCreditCardOfRecord(MasterCustomerId, SubCustomerId)

                TempCreditCardTemplate.Visible = True
                TempCreditCardTemplate.XSLfile = Server.MapPath(EditSetting_CreditCardTemplateFile)

                oCCInfo = get_clsOrderCheckOutProcessHelper.GetCustomerCreditCardOnRecord(MasterCustomerId, SubCustomerId, oVs)

                CCOnFileExists = oCCInfo.Count > 0 AndAlso oCCInfo(0).CCExpirationDate >= TIMSS.Global.App.ServerDateTime.Date
                'If cc on file exists, then store the credit card type. This is used for creating receipts before the order is saved

                'Constants to be loaded in CC Template

                If oOM IsNot Nothing Then
                    'Dim oEntireOrderSummary As New EntireOrderSummary(OrganizationId, OrganizationUnitId, oOM, Me.BaseCurrency, Me.PortalCurrency, FetchOnDemand)

                    TempCreditCardTemplate.AddObject("BillToName", String.Concat(oOM(0).BillToCustomer.FirstName, IIf(String.IsNullOrEmpty(oOM(0).BillToCustomer.MiddleName), " ", String.Concat(" ", oOM(0).BillToCustomer.MiddleName, " ")), oOM(0).BillToCustomer.LastName))
                Else
                    'An Met Cuna Fix
                    If Me.IsPersonifyWebUserLoggedIn Then
                        TempCreditCardTemplate.AddObject("BillToName", UserInfo.DisplayName)
                    End If

                End If


                TempCreditCardTemplate.AddObject("ModuleId", ModuleId)
                TempCreditCardTemplate.AddObject("CCOnFileExists", CCOnFileExists)

                TempCreditCardTemplate.AddObject("ccTypeId", ccTypeId)
                TempCreditCardTemplate.AddObject("ccNumberId", ccNumberId)
                TempCreditCardTemplate.AddObject("ccCVV2Id", ccCVV2Id)
                TempCreditCardTemplate.AddObject("ccMonthId", ccMonthId)
                TempCreditCardTemplate.AddObject("ccYearId", ccYearId)
                TempCreditCardTemplate.AddObject("ccNameonCardId", ccNameonCardId)
                TempCreditCardTemplate.AddObject("ccUseCCOnFileId", ccUseCCOnFileId)
                TempCreditCardTemplate.AddObject("ccRememberMyInfoId", ccRememberMyInfoId)

                TempCreditCardTemplate.AddObject("ccInvalidCard", _ShowInvalidCardMsg)

                If CCOnFileExists Then
                    TempCreditCardTemplate.AddObject("ccOnFileExpMonth", oCCInfo(0).CCExpirationDate.Month)
                    TempCreditCardTemplate.AddObject("ccOnFileExpYear", oCCInfo(0).CCExpirationDate.Year)
                    TempCreditCardTemplate.AddObject("ccOnFilePayorName", oCCInfo(0).CCName)

                End If

                Dim oAppStates As TIMSS.API.ApplicationInfo.IApplicationStates
                oAppStates = get_clsOrderCheckOutProcessHelper.GetApplicationStates("USA")

                If Not oAppStates.Count = 0 Then
                    TempCreditCardTemplate.AddObject("", oAppStates)
                End If
                '
                'Load Credit Card Template

                'Customers Preferred Credit Card
                TempCreditCardTemplate.AddObject("", oCCInfo)

                'Months of the year
                TempCreditCardTemplate.AddObject("", LoadMonths)

                'Years -- Current Year + 5
                TempCreditCardTemplate.AddObject("", LoadYears)


                Dim ReceiptTypeCodeList(oVs.Length - ECheckCodes.Count) As ReceiptTypeCodes
                Dim IfAdd As Boolean = True
                Dim i As Integer = 0
                For Each ReceiptCode As ValidReceiptCodes In oVs
                    IfAdd = True
                    For Each ECheckCode As String In ECheckCodes
                        If ReceiptCode.ReceiptCode.ToString = ECheckCode Then
                            IfAdd = False
                        End If
                    Next
                    If IfAdd Then
                        ReceiptTypeCodeList(i) = New ReceiptTypeCodes
                        ReceiptTypeCodeList(i).ReceiptCodeValue = ReceiptCode.ReceiptCode.ToString
                        ReceiptTypeCodeList(i).ReceiptCodeDescrip = ReceiptCode.ReceiptDescription.ToString

                        i = i + 1
                    End If
                Next

                TempCreditCardTemplate.AddObject("ReceiptTypeCodeList", ReceiptTypeCodeList)
                TempCreditCardTemplate.Display()

            End If
        End Sub

        Private Sub LoadECheckTemplate()



            'Do Not Display Template if No Items in CART
            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            'Get OrderMaster object ./... this comes from session object ... Shopping Cart Creates the order and stores it in the session
            oOM = GetOrderFromSessionObject()

            If EditSetting_SamePageCheckoutEnabled = True Then

            Else
                If oOM Is Nothing Then
                    'Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderForCheckOut", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    'btnProcessOrder.Visible = False
                    Exit Sub
                End If
            End If



            ' Valid Receipt Type Codes for Current E-Commerce Batch 
            Dim oVs() As ValidReceiptCodes
            Dim strError As String = ""
            oVs = get_clsOrderCheckOutProcessHelper.GetValidReceiptsForECommerceBatch(strError)

            If strError.Length > 0 Then
                Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile)

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoBatchOpenErrorMessage", LocalResourceFile) + "</br>" + strError, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)

                RadMultiPage1.Visible = False
                RadTabStrip1.Visible = False

                ClearSessionObject(SessionKeys.PersonifyOrder)

            Else
                'Dim oCCInfo As TIMSS.API.CustomerInfo.ICustomerCreditCards
                'Dim CCOnFileExists As Boolean
                'CCOnFileExists = Personify.ApplicationManager.OrderCheckOut.CheckIfThePayorHAsCreditCardOfRecord(PortalId, MasterCustomerId, SubCustomerId)

                ECheckTemplate.Visible = True
                ECheckTemplate.XSLfile = Server.MapPath(EditSetting_ECheckTemplateFile)

                'oCCInfo = Personify.ApplicationManager.Customer.GetCustomerCreditCardOnRecord(PortalId, MasterCustomerId, SubCustomerId)


                'If cc on file exists, then store the credit card type. This is used for creating receipts before the order is saved

                'Constants to be loaded in CC Template

                If oOM IsNot Nothing Then
                    'Dim oEntireOrderSummary As New EntireOrderSummary(OrganizationId, OrganizationUnitId, oOM, CurrencySymbol, FetchOnDemand)

                    ECheckTemplate.AddObject("BillToName", String.Concat(oOM(0).BillToCustomer.FirstName, IIf(String.IsNullOrEmpty(oOM(0).BillToCustomer.MiddleName), " ", String.Concat(" ", oOM(0).BillToCustomer.MiddleName, " ")), oOM(0).BillToCustomer.LastName))
                End If


                ECheckTemplate.AddObject("ModuleId", ModuleId)
                'ECheckTemplate.AddObject("CCOnFileExists", CCOnFileExists)

                ECheckTemplate.AddObject("eckTypeId", eckTypeId)
                ECheckTemplate.AddObject("eckRoutingNumberId", eckRoutingNumberId)
                ECheckTemplate.AddObject("eckAccountNumberId", eckAccountNumberId)
                ECheckTemplate.AddObject("eckCheckNumberId", eckCheckNumberId)
                ECheckTemplate.AddObject("eckAccountNameId", eckAccountNameId)
                ECheckTemplate.AddObject("eckDriversLicenseId", eckDriversLicenseId)
                ECheckTemplate.AddObject("eckAdditionalIDInfo", eckAdditionalIDInfo)
                ECheckTemplate.AddObject("eckCheckTypeId", eckCheckTypeId)

                'If CCOnFileExists Then
                '    ECheckTemplate.AddObject("ccOnFileExpMonth", oCCInfo(0).CCExpirationDate.Month)
                '    ECheckTemplate.AddObject("ccOnFileExpYear", oCCInfo(0).CCExpirationDate.Year)
                '    ECheckTemplate.AddObject("ccOnFilePayorName", oCCInfo(0).CCName)

                'End If

                Dim oAppStates As TIMSS.API.ApplicationInfo.IApplicationStates
                oAppStates = get_clsOrderCheckOutProcessHelper.GetApplicationStates("USA")

                If Not oAppStates.Count = 0 Then
                    ECheckTemplate.AddObject("", oAppStates)
                End If
                '
                'Load Credit Card Template

                'Customers Preferred Credit Card
                'ECheckTemplate.AddObject("", oCCInfo)
                Dim ReceiptTypeCodeList(oVs.Length - ECheckCodes.Count) As ReceiptTypeCodes
                Dim i As Integer = 0

                For Each ReceiptCode As ValidReceiptCodes In oVs
                    For Each ECheckCode As String In ECheckCodes
                        If ReceiptCode.ReceiptCode.ToString = ECheckCode Then
                            ReceiptTypeCodeList(i) = New ReceiptTypeCodes
                            ReceiptTypeCodeList(i).ReceiptCodeValue = ReceiptCode.ReceiptCode.ToString
                            ReceiptTypeCodeList(i).ReceiptCodeDescrip = ReceiptCode.ReceiptDescription.ToString

                            i = i + 1
                        End If
                    Next
                Next

                ECheckTemplate.AddObject("ReceiptTypeCodeList", ReceiptTypeCodeList)

                Dim CheckTypeList As Personify.ApplicationManager.PersonifyDataObjects.CheckType() = get_clsOrderCheckOutProcessHelper.GetCheckType()

                If CheckTypeList.Length > 0 Then
                    ECheckTemplate.AddObject("CheckTypeList", CheckTypeList)
                End If

                ECheckTemplate.Display()

                Dim ddl As DropDownList = CType(FindControl(String.Concat("IDType_", ModuleId)), DropDownList)
                Dim lblPersID As Label = FindControl("lblECPersonalId")
                Dim lblAddtlInfo As Label = FindControl("lblAdditionalIDInfo")
                If ddl IsNot Nothing AndAlso lblPersID IsNot Nothing AndAlso lblAddtlInfo IsNot Nothing Then
                    ddl.Attributes.Add("onChange", String.Format("SetChangeLabel(this,'{0}','{1}')", lblPersID.ClientID, lblAddtlInfo.ClientID))
                End If

                Dim txtRequiredAuthorizationVerbiage As Label
                txtRequiredAuthorizationVerbiage = CType(FindControl("txtRequiredAuthorizationVerbiage"), Label)

                If txtRequiredAuthorizationVerbiage IsNot Nothing Then
                    txtRequiredAuthorizationVerbiage.Text = Localization.GetString("txtRequiredAuthorizationVerbiage", Me.LocalResourceFile)
                    If EditSetting_SamePageCheckoutEnabled = False Then
                        txtRequiredAuthorizationVerbiage.Text = txtRequiredAuthorizationVerbiage.Text.Replace("[Amount]", TotalAmount.ToString)
                    Else
                        txtRequiredAuthorizationVerbiage.Text = txtRequiredAuthorizationVerbiage.Text.Replace("of [Amount]", "shown above")
                    End If
                End If

                Dim imgTeleCheckLogo As Image
                imgTeleCheckLogo = CType(FindControl("imgTeleCheckLogo"), Image)

                If imgTeleCheckLogo IsNot Nothing Then
                    imgTeleCheckLogo.ImageUrl = String.Concat("~/", SiteImagesFolder, "/official_logo.gif")
                End If
                LoadToolTips(eckRoutingNumberId)
                LoadToolTips(eckAccountNumberId)
                'LoadToolTips(Localization.GetString("AccountNumberRepeatName", Me.LocalResourceFile))
            End If



        End Sub


        Private Sub LoadToolTips(ByVal Name As String)
            Dim tempPlaceHolder As New PlaceHolder
            Dim tempTextboxPlaceHolder As New PlaceHolder
            Dim tempToolTip As New RadToolTip
            Dim tempTextbox As New TextBox

            tempTextbox.ID = String.Concat(Name, "_", ModuleId.ToString)
            tempTextbox.Width = "200"
            With tempToolTip
                .ID = String.Concat(Name, "ToolTip_", ModuleId.ToString)
                .Height = "200"
                .Width = "380"
                .TargetControlID = tempTextbox.ID
                .IsClientID = False
                .OffsetY = "4"
                .Sticky = True
                .Animation = ToolTipAnimation.Fade
                .Position = ToolTipPosition.MiddleRight
                .RelativeTo = ToolTipRelativeDisplay.Element
                .Skin = Localization.GetString("ECKToolTipSkin", Me.LocalResourceFile)
                .ShowEvent = ToolTipShowEvent.OnFocus
                .ManualClose = False
                .HideDelay = 500
                Dim tempImage As New Image
                tempImage.ID = String.Concat(Name, "Image_", ModuleId.ToString)
                tempImage.ImageUrl = ResolveUrl(String.Concat("~/", SiteImagesFolder, "/", Localization.GetString(String.Concat(Name, "Image"), Me.LocalResourceFile)))
                .Controls.Add(tempImage)
            End With

            For i As Integer = 0 To Me.Controls.Count - 1
                For j As Integer = 0 To Me.Controls(i).Controls.Count - 1
                    For k As Integer = 0 To Me.Controls(i).Controls(j).Controls.Count - 1
                        tempTextboxPlaceHolder = Me.Controls(i).Controls(j).Controls(k).FindControl(String.Concat(Name, "TextboxPlaceHolder_", ModuleId.ToString))
                        tempPlaceHolder = Me.Controls(i).Controls(j).Controls(k).FindControl(String.Concat(Name, "PlaceHolder_", ModuleId.ToString))
                        If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                            Exit For
                        End If
                    Next
                    If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                        Exit For
                    End If
                Next
                If tempTextboxPlaceHolder IsNot Nothing And tempPlaceHolder IsNot Nothing Then
                    Exit For
                End If
            Next

            If tempTextboxPlaceHolder IsNot Nothing Then
                tempTextboxPlaceHolder.Controls.Add(tempTextbox)
            End If

            If (tempPlaceHolder IsNot Nothing) Then
                tempPlaceHolder.Controls.Add(tempToolTip)
            End If
        End Sub

        Private Sub LoadOrderPaymentTemplate()

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            OrderPaymentTemplate.Visible = True
            OrderPaymentTemplate.XSLfile = Server.MapPath(EditSetting_TemplateFile)

            '3246-5774803
            Dim SubordinateArrowImageURL As String = GetSubordinateArrowImageURL()
            OrderPaymentTemplate.AddObject("SubordinateArrowImageURL", SubordinateArrowImageURL)
            'end 3246-5774803

            'Get OrderMaster object ./... this comes from session object ... Shopping Cart Creates the order and stores it in the session
            oOM = GetOrderFromSessionObject()

            'AN change
            If EditSetting_SamePageCheckoutEnabled = True Then
                DisplayCreditCardTemplate = True
                Exit Sub
            Else

                If oOM Is Nothing Then
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderForCheckOut", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    RadMultiPage1.Visible = False
                    RadTabStrip1.Visible = False
                    Exit Sub
                End If
            End If

            For i As Integer = 0 To oOM.Count - 1
                For j As Integer = 0 To oOM(i).PreservedOrderDetails.Count - 1
                    If Not oOM(i).Details(j) Is Nothing Then
                        If (oOM(i).Details(j).LineStatusCodeString = "W") OrElse (oOM(i).Details(j).LineStatusCodeString = "B") Then
                            ShowStatus = True
                        End If
                    End If
                Next
            Next

            Dim oEntireOrderSummary As New EntireOrderSummary(OrganizationId, OrganizationUnitId, oOM, Me.BaseCurrency, Me.PortalCurrency, FetchOnDemand)



            'Add object to the template
            'Dim oODClass() As OrderDetails
            ' oODClass = LoadClassOrderDetails(PortalId, oOM)
            OrderPaymentTemplate.AddObject("", oEntireOrderSummary.OrderDetails)

            TotalAmount = oEntireOrderSummary.FormattedTotalWebBillMeNowOrderAmount
            'List of Bill/Ship Addresses
            'Dim oAddrClass() As BillToShipToAddress
            'oAddrClass = LoadClassBillToShipToAddress(PortalId, oOM)

            'If oEntireOrderSummary.BillToShipToAddress.Length > 0 Then
            '    DisplayCreditCardTemplate = oEntireOrderSummary.BillToShipToAddress(0).BillToCustomerIsPrimaryEmployer
            'End If
            OrderPaymentTemplate.AddObject("", oEntireOrderSummary.BillToShipToAddress)

            'List of Shipping Methods
            'Dim oShipVia() As ShippingDetails
            'oShipVia = LoadClassShippingDetails(PortalId, oOM)

            'If oEntireOrderSummary.ShippingDetails IsNot Nothing AndAlso oEntireOrderSummary.ShippingDetails.Length > 0 Then
            '    OrderPaymentTemplate.AddObject("", oEntireOrderSummary.ShippingDetails)
            'End If



            'Check if the order has advance shipping
            'Dim OrderHasMultipleShipMethods As Boolean
            'OrderHasMultipleShipMethods = DoesOrderHaveMultipleShippingMethods(PortalId, oOM)
            OrderPaymentTemplate.AddObject("OrderHasMultipleShipMethods", oEntireOrderSummary.OrderHasMultipleShipMethods)

            'Order Totals
            'Dim oOrderTotals() As OrderTotals
            'oOrderTotals = LoadClassOrderTotals(PortalId, oOM)
            OrderPaymentTemplate.AddObject("", oEntireOrderSummary.OrderTotals)

            'Load Total Payment amount
            OrderPaymentTemplate.AddObject("FormattedTotalWebBillMeNowOrderAmount", oEntireOrderSummary.FormattedTotalWebBillMeNowOrderAmount)

            OrderPaymentTemplate.AddObject("DoesOrderHaveBillMeLines", oEntireOrderSummary.DoesOrderHaveBillMeLines)


            OrderPaymentTemplate.AddObject("IsRenewalOrder", IsRenewalOrder(oOM(0)))

            Dim RenewLinkURL As String = TIMSS.API.CachedApplicationData.ApplicationDataCache.PWFParameter("RENEWMEMBERSHIPURL").ParameterValue

            OrderPaymentTemplate.AddObject("RenewalLink", RenewLinkURL)

            LoadGlobalVariablesInXSLTemplate()
            'Console.WriteLine(OrderPaymentTemplate.XMLString)
            'Credit Card Template Display
            If oEntireOrderSummary.TotalWebBillMeNowOrderAmount = 0 Then
                DisplayCreditCardTemplate = False
            Else
                DisplayCreditCardTemplate = True
            End If

            OrderPaymentTemplate.Display()

            'Determine ship via code by first non-empty ship-via code from order details
            Dim ddlShipViaCode As DropDownList = FindControl(String.Concat("ddlShipViaCode_", ModuleId))
            If ddlShipViaCode IsNot Nothing Then
                ddlShipViaCode.DataTextField = "Description"
                ddlShipViaCode.DataValueField = "Code"
                ddlShipViaCode.DataSource = GetApplicationCodes("ORD", "SHIP_VIA", True)
                ddlShipViaCode.DataBind()
                Dim shipViaCode As String = ""
                Dim oDetails As TIMSS.API.OrderInfo.IOrderDetails
                oDetails = oOM(0).Details
                For i As Integer = 0 To oDetails.Count - 1
                    If oDetails(i).ShipViaCodeString.Trim <> "" Then
                        shipViaCode = oDetails(i).ShipViaCodeString
                        Exit For
                    End If
                Next
                If Not String.IsNullOrEmpty(shipViaCode) Then
                    ddlShipViaCode.SelectedValue = shipViaCode
                End If
            End If

            'CodeForShippingRadioButtons(shipViaCode)
            CodeForAdvanceShippingHyperLink()
            CodeForChangeBillToShiptoAddressHyperLink()



        End Sub


        Private Sub LoadGlobalVariablesInXSLTemplate()
            'Global Variables
            'Module Id
            Dim strModuleId As String = ModuleId.ToString
            OrderPaymentTemplate.AddObject("ModuleId", strModuleId)
            'ID for BillAddressChange HyperLink
            OrderPaymentTemplate.AddObject("ChangeBillAddressHyperLinkId", ChangeBillAddressHyperLinkId)
            'ID for ShipAddressChange HyperLink
            OrderPaymentTemplate.AddObject("ChangeShipAddressHyperLinkId", ChangeShipAddressHyperLinkId)
            'Id for AdvanceShipping HyperLink
            OrderPaymentTemplate.AddObject("AdvanceShippingHyperLinkId", AdvanceShippingHyperLinkId)

            'Setting for Enable coupon feature
            OrderPaymentTemplate.AddObject("EditSetting_EnableCouponFeature", EditSetting_EnableCouponFeature)

            'Setting for Enable coupon feature
            OrderPaymentTemplate.AddObject("EditSetting_EnableBillMeFeature", EditSetting_EnableBillMeFeature)

            'Setting for Enable coupon feature
            OrderPaymentTemplate.AddObject("EditSetting_PromotionCodeAtLineOrOrderLevel", EditSetting_PromotionCodeAtLineOrOrderLevel)

            'Setting for enabling Advance Shipping Feature
            OrderPaymentTemplate.AddObject("EditSetting_EnableAdvanceShippingFeature", EditSetting_EnableAdvanceShippingFeature)

            OrderPaymentTemplate.AddObject("ShowStatus", ShowStatus)

        End Sub
        '3246-5774803
        Private Function GetSubordinateArrowImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/timss-arrow-subordinate.gif")
        End Function
        'END 3246-5774803

        'Private Sub CodeForShippingRadioButtons(ByVal SelectedShipVia As String)
        '    Dim strcontrolname As String
        '    'Set the Radio button of the selected Ship Via To TRUE
        '    strcontrolname = "ShipviaRadioButton_" + ModuleId.ToString + "_" + SelectedShipVia

        '    If Not Me.FindControl(strcontrolname) Is Nothing Then
        '        CType(Me.FindControl(strcontrolname), RadioButton).Checked = True

        '        'Add handler for button


        '    End If
        'End Sub

        Private Sub CodeForAdvanceShippingHyperLink()
            Dim oControl As System.Web.UI.WebControls.HyperLink

            Dim strcontrolName As String = AdvanceShippingHyperLinkId + "_" + ModuleId.ToString
            If Not Me.FindControl(strcontrolName) Is Nothing Then

                oControl = CType(Me.FindControl(strcontrolName), System.Web.UI.WebControls.HyperLink)
                oControl.NavigateUrl = EditSetting_AdvanceShippingURL
            End If

        End Sub

        Private Sub CodeForChangeBillToShiptoAddressHyperLink()
            Dim oControl As System.Web.UI.WebControls.HyperLink

            'For ship to
            Dim strcontrolName As String = ChangeShipAddressHyperLinkId + "_" + ModuleId.ToString
            If Not Me.FindControl(strcontrolName) Is Nothing Then

                oControl = CType(Me.FindControl(strcontrolName), System.Web.UI.WebControls.HyperLink)
                oControl.NavigateUrl = EditSetting_ChangeBillShipAddressURL + "&CHANGEADDRESSTYPE=SHIP"

            End If

            'For bill to
            strcontrolName = ChangeBillAddressHyperLinkId + "_" + ModuleId.ToString
            If Not Me.FindControl(strcontrolName) Is Nothing Then

                oControl = CType(Me.FindControl(strcontrolName), System.Web.UI.WebControls.HyperLink)
                oControl.NavigateUrl = EditSetting_ChangeBillShipAddressURL + "&CHANGEADDRESSTYPE=BILL"
            End If

        End Sub




#Region "Register Java Scripts"

        Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
            Dim ScriptPath As String = ResolveUrl(path)
            If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
                Dim script As System.Text.StringBuilder = New System.Text.StringBuilder
                script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
                script = Nothing
            End If
        End Sub

#End Region

        Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters
            oOM = GetOrderFromSessionObject()

            If oOM Is Nothing Then
                If Not oMessageControl Is Nothing Then
                    oMessageControl.Clear()
                End If
                If Not oFARMessageControl Is Nothing Then
                    oFARMessageControl.Clear()
                End If
            End If


        End Sub

        Public Event ModuleCommunication(ByVal sender As Object, ByVal e As DotNetNuke.Entities.Modules.Communications.ModuleCommunicationEventArgs) Implements DotNetNuke.Entities.Modules.Communications.IModuleCommunicator.ModuleCommunication


        Private Function DoesOrderHaveABadAddress(ByVal Mode As String) As Boolean

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters
            oOM = GetOrderFromSessionObject()


            If Mode = "BILL" Then
                If oOM(0).BillAddressInfo.AddressStatusCodeString = "BAD" Then
                    Return True
                End If
            End If
            If Mode = "SHIP" Then
                For i As Integer = 0 To oOM(0).Details.Count - 1
                    If oOM(0).Details(i).ShipAddress.AddressStatusCodeString = "BAD" Then
                        Return True
                    End If
                Next
            End If
            Return False

        End Function

        Private Sub btnCancelOrder_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelOrder.Click
            ClearSessionObject(SessionKeys.PersonifyOrder)
        End Sub


#Region "Helper function"

        Private Function DoesContainCharacter(ByVal value As String) As Boolean
            Try
                Dim compare As Long
                compare = CType(value, Long)
            Catch ex As Exception
                Return True
            End Try

            Return False
        End Function

#End Region


    End Class


End Namespace
