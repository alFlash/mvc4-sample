Imports System
Imports System.Data

Namespace Personify.DNN.Modules.OrderPayment.Business

    Public Class OrderPaymentInfo
        '---------------------------------------------------------------------
        ' TODO Declare BLL Class Info fields and property accessors
        ' You can use CodeSmith templates to generate this code
        '---------------------------------------------------------------------

#Region "Private Members"
        Private _ItemId As Integer
        Private _ModuleId As Integer
        Private _Field1 As String
#End Region

#Region "Constructors"
        Public Sub New()
        End Sub
#End Region

#Region "Public Properties"
        Public Property ItemId() As Integer
            Get
                Return _ItemId
            End Get
            Set(ByVal Value As Integer)
                _ItemId = Value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal Value As Integer)
                _ModuleId = Value
            End Set
        End Property
        Public Property Field1() As String
            Get
                Return _Field1
            End Get
            Set(ByVal Value As String)
                _Field1 = Value
            End Set
        End Property
#End Region

    End Class

End Namespace
