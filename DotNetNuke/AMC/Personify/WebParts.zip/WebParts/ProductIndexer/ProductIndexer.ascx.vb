Imports System
Imports System.Web.UI.WebControls
Imports System.IO
Imports DotNetNuke
Imports System.Enum
Imports System.Object
Imports Personify.DNN.Modules.ProductIndexer.Business
Imports System.Text.RegularExpressions
Imports Personify
Imports DotNetNuke.Services.Localization

Namespace Personify.DNN.Modules.ProductIndexer

    Public Class ProductIndexer
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase
        'Implements Entities.Modules.IActionable
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"

#End Region

#Region "Private Methods"

#End Region

#Region "Public Methods"

#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

            Catch exc As Exception
                'ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '#Region "Optional Interfaces"
        '        Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        '            Get
        '                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
        '                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
        '                Return Actions
        '            End Get
        '        End Property

        '        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
        '            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        '            Return Nothing
        '        End Function

        '        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
        '            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        '        End Sub

        '        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
        '            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        '            Return Nothing
        '        End Function

        '#End Region
    End Class

End Namespace


