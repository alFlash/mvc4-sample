Imports System
Imports System.Web.Caching
Imports System.Reflection
Imports DotNetNuke

Namespace Personify.DNN.Modules.ProductIndexer.Data

    Public MustInherit Class DataProvider

#Region "Shared/Static Methods"
        ' singleton reference to the instantiated object 
        Private Shared objProvider As DataProvider = Nothing

        ' constructor
        Shared Sub New()
            CreateProvider()
        End Sub

        ' dynamically create provider
        Private Shared Sub CreateProvider()
            objProvider = CType(Framework.Reflection.CreateObject("data", "Personify.DNN.Modules.ProductIndexer.Data", "Personify.DNN.Modules.ProductIndexer"), DataProvider)
        End Sub

        ' return the provider
        Public Shared Shadows Function Instance() As DataProvider
            Return objProvider
        End Function
#End Region

#Region "Abstract Methods"
        '---------------------------------------------------------------------
        ' TODO Declare DAL methods. Should be implemented in each DAL DataProvider
        ' Use CodeSmith templates to generate this code
        '---------------------------------------------------------------------
        Public MustOverride Function GetModuleId(ByVal Subsystem As String) As IDataReader

#End Region

    End Class

End Namespace
