Option Strict Off

Imports DotNetNuke
Imports DotNetNuke.Services.Search
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports System
Imports System.Data
Imports Personify
Imports Personify.DNN.Modules.ProductIndexer.Data

Namespace Personify.DNN.Modules.ProductIndexer.Business

    Public Class ProductIndexerController
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Implements DotNetNuke.Entities.Modules.ISearchable

#Region "Public Methods"
        Public Function GetModuleId(ByVal Subsystem As String) As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().GetModuleId(Subsystem), GetType(ProductIndexerInfo))
        End Function

        Private Function GlobalProductDetail() As Integer
            Dim oAList As ArrayList
            oAList = GetModuleId("ALL")
            If Not oAList Is Nothing Then
                For i As Integer = 0 To oAList.Count - 1
                    Return CType(oAList.Item(i), ProductIndexerInfo).ModuleId
                Next
            Else
                Return -1
            End If
        End Function

#End Region

#Region "Optional Interfaces"
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As DotNetNuke.Services.Search.SearchItemInfoCollection Implements DotNetNuke.Entities.Modules.ISearchable.GetSearchItems

            Dim oSearchProducts As TIMSS.API.WebInfo.ITmarWebSearchproductViewList
            oSearchProducts = GetSearchableAttributesForProducts()

            Dim GlobalModuleId As Integer = GlobalProductDetail()
            Dim SearchItemCollection As New SearchItemInfoCollection
            Dim ProductDetailModuleId As Integer = -1
            Dim SearchItem As SearchItemInfo
            Dim Content As New System.Text.StringBuilder
            Dim strSeperator As String = " "
            ' Loop through all the products and try to index them
            For Each oProduct As TIMSS.API.WebInfo.ITmarWebSearchproductView In oSearchProducts
                Dim oProductIndexerInfo As ArrayList
                ' Get the moduleId of the ProductDetail Web Part
                ' for this product's subsystem
                oProductIndexerInfo = GetModuleId(oProduct.Subsystem)
                If Not oProductIndexerInfo Is Nothing Then
                    For i As Integer = 0 To oProductIndexerInfo.Count - 1
                        ProductDetailModuleId = CType(oProductIndexerInfo.Item(i), ProductIndexerInfo).ModuleId
                    Next

                    If ProductDetailModuleId = -1 Then
                        ProductDetailModuleId = GlobalModuleId
                    End If

                    ' Index the product ONLY if there is an 
                    ' available Product Detail Web Part to show it
                    If ProductDetailModuleId <> -1 Then
                        With oProduct
                            If Content.Length > 0 Then
                                Content.Remove(0, Content.Length)
                            End If
                            Content.Append(.Subsystem)
                            Content.Append(strSeperator)
                            Content.Append(.ProductClassCodeString)
                            Content.Append(strSeperator)
                            Content.Append(.ProductTypeCodeString)
                            Content.Append(strSeperator)
                            Content.Append(.KeywordList)
                            Content.Append(strSeperator)
                            Content.Append(.CategoryList)
                            Content.Append(strSeperator)

                            If .WebShortDescription.Length > 0 Then
                                Content.Append(HtmlUtils.StripTags(HtmlUtils.Shorten(.WebShortDescription, 255, "..."), True))
                            Else
                                Content.Append(.LongName)
                            End If

                            Content.Append(strSeperator)
                            Content.Append(.ProductCode)
                            Content.Append(strSeperator)
                            Content.Append(.ShortName)

                            ' In case there is not description then set the
                            ' search description to the Product's LongName

                            'SearchItem = New SearchItemInfo(.ShortName, Content.ToString, 1, .AvailableDate, ProductDetailModuleId, .ProductId.ToString, Content.ToString, "ProductId=" & .ProductId.ToString & "&Subsystem=" & .Subsystem & "&ProductCode=" & .ProductCode)
                            SearchItem = New SearchItemInfo(.ShortName, .LongName, 1, .AvailableDate, ProductDetailModuleId, .ProductId.ToString, Content.ToString, "ProductId=" & .ProductId.ToString & "&Subsystem=" & .Subsystem & "&ProductCode=" & .ProductCode)
                            SearchItemCollection.Add(SearchItem)

                        End With
                    End If
                End If
            Next
            Return SearchItemCollection
        End Function
#End Region

        Private Function GetSearchableAttributesForProducts() As TIMSS.API.WebInfo.ITmarWebSearchproductViewList



            Dim oSearchProducts As TIMSS.API.WebInfo.ITmarWebSearchproductViewList
            Dim oDistinctSearchProducts As TIMSS.API.WebInfo.ITmarWebSearchproductViewList

          
            Dim strCacheKey As String


            strCacheKey = OrganizationId & OrganizationUnitId & "SearchAttributesForProducts"


            oSearchProducts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebSearchproductViewList")
            oSearchProducts.Fill()
            oDistinctSearchProducts = CreateDistinctListOfSearchProducts(oSearchProducts)
            Return oDistinctSearchProducts



        End Function

        Private Function CreateDistinctListOfSearchProducts(ByVal poSearchProducts As TIMSS.API.WebInfo.ITmarWebSearchproductViewList) As TIMSS.API.WebInfo.ITmarWebSearchproductViewList
            Dim oDistinctSearchProducts As TIMSS.API.WebInfo.ITmarWebSearchproductViewList
            Dim oDistinctSearchProduct As TIMSS.API.WebInfo.ITmarWebSearchproductView
            Dim oFindCriteria As New System.Collections.Specialized.ListDictionary




            oDistinctSearchProducts = Me.PErsonifyGetCollection( TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebSearchproductViewList")

            For Each oSearchProduct As TIMSS.API.WebInfo.ITmarWebSearchproductView In poSearchProducts
                oFindCriteria.Clear()
                oFindCriteria.Add("ProductId", oSearchProduct.ProductId)
                oDistinctSearchProduct = DirectCast(oDistinctSearchProducts.FindObject(oFindCriteria), TIMSS.API.WebInfo.ITmarWebSearchproductView)
                If oDistinctSearchProduct Is Nothing Then
                    oSearchProduct.KeywordList = oSearchProduct.Keyword
                    oSearchProduct.CategoryList = oSearchProduct.Category.Code
                    oDistinctSearchProducts.Add(oSearchProduct)
                Else
                    'Append Product Category and Product Keyword
                    If Not oDistinctSearchProduct.KeywordList.Contains(oSearchProduct.Keyword) Then
                        oDistinctSearchProduct.KeywordList = oDistinctSearchProduct.KeywordList & " " & oSearchProduct.Keyword
                    End If
                    If Not oDistinctSearchProduct.CategoryList.Contains(oSearchProduct.Category.Code) Then
                        oDistinctSearchProduct.CategoryList = oDistinctSearchProduct.CategoryList & " " & oSearchProduct.Category.Code
                    End If

                End If
            Next


            Return oDistinctSearchProducts




        End Function


    End Class

End Namespace
