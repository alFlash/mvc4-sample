Imports System
Imports System.Data

Namespace Personify.DNN.Modules.ProductIndexer.Business

    Public Class ProductIndexerInfo

#Region "Private Members"
        Private _ItemId As Integer
        Private _ModuleId As Integer
        Private _ProductDetailPage As Integer
#End Region

#Region "Constructors"
        Public Sub New()
        End Sub
#End Region

#Region "Public Properties"
        Public Property ItemId() As Integer
            Get
                Return _ItemId
            End Get
            Set(ByVal Value As Integer)
                _ItemId = Value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal Value As Integer)
                _ModuleId = Value
            End Set
        End Property
        Public Property ProductDetailPage() As Integer
            Get
                Return _ProductDetailPage
            End Get
            Set(ByVal Value As Integer)
                _ProductDetailPage = Value
            End Set
        End Property

#End Region

    End Class

End Namespace
