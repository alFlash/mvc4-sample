Imports System
Imports Personify
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports DotNetNuke.Services.Exceptions.Exceptions
Imports DotNetNuke.Common.Globals

Namespace Personify.DNN.Modules.ProductIndexer

    Public MustInherit Class ProductIndexerEdit
        Inherits Entities.Modules.PortalModuleBase

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents rbtCanPurchaseMemberOnlyProducts As RadioButtonList
        Protected WithEvents txtMasterCustomerId As TextBox
        Protected WithEvents txtSubCustomerId As TextBox
#End Region

#Region "Private Members"
        Private itemId As Integer

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub Pre_Render(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            Dim oModules As New Entities.Modules.ModuleController
            With oModules
                txtMasterCustomerId.Text = .GetModuleSettings(ModuleId).Item("HostMasterCustomerId").ToString
                txtSubCustomerId.Text = .GetModuleSettings(ModuleId).Item("HostSubCustomerId").ToString
                rbtCanPurchaseMemberOnlyProducts.SelectedValue = .GetModuleSettings(ModuleId).Item("HostCanPurchaseMemberOnlyProducts").ToString
            End With
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                Dim oModules As New Entities.Modules.ModuleController
                With oModules
                    .UpdateModuleSetting(ModuleId, "HostMasterCustomerId", txtMasterCustomerId.Text)
                    .UpdateModuleSetting(ModuleId, "HostSubCustomerId", txtSubCustomerId.Text)
                    .UpdateModuleSetting(ModuleId, "HostCanPurchaseMemberOnlyProducts", rbtCanPurchaseMemberOnlyProducts.SelectedValue)
                End With

                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
