
Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify


Namespace Personify.DNN.Modules.EmergencyContacts

    Public MustInherit Class EmergencyContacts
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

        'Private strMCID As String
        'Private strSCID As String
        Protected WithEvents xslEmergencyContacts As WebControls.XslTemplate
        Protected WithEvents lblEmergencyContacts As System.Web.UI.WebControls.Label
        Protected WithEvents lblNoEmergencyContacts As System.Web.UI.WebControls.Label
        Protected WithEvents hlAddEmergencyContact As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblNoEmeContacts As System.Web.UI.WebControls.Label
        Protected WithEvents tblLegend As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents imgArrowDown As Image
        Protected WithEvents imgArrowUp As Image
        Protected WithEvents imgAddNew As Image
        Protected WithEvents btnSave As Button
        Protected WithEvents btnCancel As Button

        Protected WithEvents oMessageControl As WebControls.MessageControl

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)

                If (Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin") Then
                    LoadImages()
                    ShowLabels(True)
                    AddTemplate()
                    hlAddEmergencyContact.NavigateUrl = NavigateURL(TabId, "", "MODE=ADD", "ModuleId=" & ModuleId)
                Else
                    ShowLabels(False)
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NeedLogin", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region "Optional Interfaces"
      
       
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub ShowLabels(ByVal blnShowHide As Boolean)
            lblEmergencyContacts.Visible = blnShowHide
            lblNoEmergencyContacts.Visible = blnShowHide
            hlAddEmergencyContact.Visible = blnShowHide
            imgAddNew.Visible = blnShowHide
        End Sub

        Private Sub LoadImages()
            imgAddNew.ImageUrl = "~/" & SiteImagesFolder & "/addnewred_11x11.gif"
            'imgArrowDown.ImageUrl = "~/" & imagesFolder & "/arrow_down.gif"
            'imgArrowUp.ImageUrl = "~/" & imagesFolder & "/arrow_up.gif"
        End Sub

        Private Function GetArrowDownURL() As String

            Return "~/" & SiteImagesFolder & "/arrow_down.gif"
        End Function

        Private Function GetArrowUpURL() As String

            Return "~/" & SiteImagesFolder & "/arrow_up.gif"
        End Function

        Private Sub AddTemplate()

            Dim SavePostBack As Boolean = False
            Dim intSeqNo As Integer
            Dim oEditEmergencyContact As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            For Each key As String In Request.Params.AllKeys
                If key.IndexOf("btnSave") >= 0 Then
                    SavePostBack = True
                End If

                If key.IndexOf("btnDown") >= 0 Or key.IndexOf("btnUp") >= 0 Then
                    If Not ChangePriority(key) Then
                        Exit Sub
                    Else
                        Exit For
                    End If
                End If
            Next

            'sets the template file 
            If Not Settings("EmergencyContactsTemplate") Is Nothing Then
                xslEmergencyContacts.XSLfile = Server.MapPath(ModulePath + "/Templates/" & CStr(Settings("EmergencyContactsTemplate")))
            Else
                xslEmergencyContacts.XSLfile = Server.MapPath(ModulePath + "/Templates/EmergencyContactsTemplate.xsl")
            End If

            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            If Request.QueryString("ModuleId") IsNot Nothing Then
                globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
            Else
                globalVariables.ModuleId = 0
            End If
            globalVariables.EmergencyContacts = "EmergencyContacts"
            xslEmergencyContacts.AddObject("", globalVariables)

            If Request.QueryString("MODE") Is Nothing Or Request.QueryString("MODE") = "DELETE" Then

                'Delete the Emergency Contact
                If Request.QueryString("MODE") = "DELETE" Then
                    If Not Request.QueryString("SEQNO") Is Nothing Then
                        intSeqNo = CInt(Request.QueryString("SEQNO").ToString.ToUpper)
                        If Not df_DeleteEmergencyContact(MasterCustomerId, SubCustomerId, intSeqNo) Then
                            Exit Sub
                        End If
                    End If
                End If

                Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts
                oEmergencyContacts = df_GetEmergencyContacts(MasterCustomerId, SubCustomerId)

                If oEmergencyContacts.Count = 0 Then
                    lblNoEmergencyContacts.Visible = True
                Else
                    lblNoEmergencyContacts.Visible = False
                    'Fixed :3246-8310369: The xslEmergencyContacts.Display should be called only when
                    'the emergency contacts exist
                    Dim EmergencyContacts(oEmergencyContacts.Count - 1) As aEmergencyContact
                    For x As Integer = 0 To EmergencyContacts.Length - 1
                        EmergencyContacts(x) = New aEmergencyContact
                        With oEmergencyContacts(x)
                            EmergencyContacts(x).Priority = .Priority
                            EmergencyContacts(x).EmergencyContactName = .EmergencyContactName
                            EmergencyContacts(x).EmergencyContactRelationship = .EmergencyContactRelationship
                            EmergencyContacts(x).PhoneTypeCode = .PhoneTypeCode.Description
                            EmergencyContacts(x).PhoneNumber = .PhoneNumber
                            EmergencyContacts(x).SeqNo = .CustomerCommunicationEmergencyContactId
                            EmergencyContacts(x).Edit = NavigateURL(TabId, "", "MODE=EDIT", "ModuleId=" & ModuleId, "SEQNO=" & .CustomerCommunicationEmergencyContactId)
                            EmergencyContacts(x).Delete = NavigateURL(TabId, "", "MODE=DELETE", "ModuleId=" & ModuleId, "SEQNO=" & .CustomerCommunicationEmergencyContactId)
                        End With
                    Next

                    xslEmergencyContacts.AddObject("", EmergencyContacts)
                    Dim ArrowDownURL As String = GetArrowDownURL()
                    xslEmergencyContacts.AddObject("ArrowDownURL", ArrowDownURL)
                    Dim ArrowUpURL As String = GetArrowUpURL()
                    xslEmergencyContacts.AddObject("ArrowUpURL", ArrowUpURL)
                    xslEmergencyContacts.Display()
                End If

                btnSave.Visible = False
                btnSave.Visible = False

                Dim pnlView As Panel = CType(FindControl("pnlView"), Panel)
                Dim pnlEdit As Panel = CType(FindControl("pnlEdit"), Panel)
                If pnlView IsNot Nothing Then
                    pnlView.Visible = True
                    pnlEdit.Visible = False
                End If

            ElseIf Request.QueryString("MODE").ToString.ToUpper = "EDIT" Or Request.QueryString("MODE").ToString.ToUpper = "ADD" Then

                lblNoEmergencyContacts.Visible = False

                'Display the template
                xslEmergencyContacts.Display()
                If Not SavePostBack Then


                    If Not Request.QueryString("SEQNO") Is Nothing Then
                        intSeqNo = CInt(Request.QueryString("SEQNO").ToString.ToUpper)
                        oEditEmergencyContact = df_GetSingleEmergencyContact(MasterCustomerId, SubCustomerId, intSeqNo)
                    End If


                    Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts
                    oEmergencyContacts = df_GetEmptyEmergencyContactCollection()

                    For Each oProperty As TIMSS.API.Core.PropertyInfo In oEmergencyContacts(0).Schema.ValueProperties
                        Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.EmergencyContacts & "_" & oProperty.Name)
                        Dim value As String
                        value = ""

                        If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                            If oEditEmergencyContact(0).Schema(oProperty.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                value = CType(CType(oEditEmergencyContact(0), TIMSS.API.Core.BusinessObject).GetPropertyValue(oProperty.Name), TIMSS.API.Core.ICode).Code
                            Else
                                value = CType(oEditEmergencyContact(0), TIMSS.API.Core.BusinessObject).GetPropertyValue(oProperty.Name)
                            End If
                        End If

                        If ctl IsNot Nothing Then
                            If ctl.GetType Is GetType(TextBox) Then
                                CType(ctl, TextBox).Text = value
                            End If

                            If ctl.GetType Is GetType(DropDownList) Then
                                CType(ctl, DropDownList).DataTextField = "Description"
                                CType(ctl, DropDownList).DataValueField = "Code"
                                CType(ctl, DropDownList).DataSource = GetApplicationCodes("CUS", "PHONE_TYPE", True)
                                CType(ctl, DropDownList).DataBind()
                                CType(ctl, DropDownList).CssClass = "tmar_cucm_input"
                                CType(ctl, DropDownList).SelectedValue = value
                            End If

                        End If
                    Next

                    btnSave.Visible = True
                    btnCancel.Visible = True

                    Dim pnlView As Panel = CType(FindControl("pnlView"), Panel)
                    Dim pnlEdit As Panel = CType(FindControl("pnlEdit"), Panel)
                    If pnlView IsNot Nothing Then
                        pnlView.Visible = False
                        pnlEdit.Visible = True
                    End If
                End If

            End If

        End Sub

        Private Function SaveEmergencyContact() As Boolean

            Try
                Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
                If Request.QueryString("ModuleId") IsNot Nothing Then
                    globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
                Else
                    globalVariables.ModuleId = 0
                End If
                globalVariables.EmergencyContacts = "EmergencyContacts"

                Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts
                If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                    oEmergencyContacts = df_GetSingleEmergencyContact(MasterCustomerId, SubCustomerId, CInt(Request.QueryString("SEQNO").ToString.ToUpper))
                Else
                    oEmergencyContacts = df_GetEmptyEmergencyContactCollection()
                    'oEmergencyContacts = TIMSS.Global.App.GetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunicationEmergencyContacts")
                    oEmergencyContacts(0).MasterCustomerId = MasterCustomerId
                    oEmergencyContacts(0).SubCustomerId = SubCustomerId
                End If

                Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oEmergencyContacts(0))
                For Each oProperty As TIMSS.API.Core.PropertyInfo In oEmergencyContacts.Schema.ValueProperties
                    Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.EmergencyContacts & "_" & oProperty.Name)

                    If ctl IsNot Nothing Then
                        If ctl.GetType Is GetType(TextBox) Then
                            CType(oEmergencyContacts(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(oProperty.Name), CType(ctl, TextBox).Text)
                        ElseIf ctl.GetType Is GetType(DropDownList) Then
                            oEmergencyContacts(0).SetPropertyValue(SetPropertyInfo(oProperty.Name), CType(ctl, DropDownList).SelectedValue)
                        End If
                    End If
                Next

                Return df_SaveEmergencyContact(oEmergencyContacts)

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
                Return False
            End Try

        End Function

        Private Function ChangePriority(ByVal strKey As String) As Boolean

            Try
                Dim intSeqNo, intPriority As Integer

                Dim IDs() As String = strKey.Split("_")
                intSeqNo = CInt(IDs(1))
                intPriority = CInt(IDs(2))

                If IDs(0).IndexOf("Up") > 0 Then
                    Return df_MovePriority(MasterCustomerId, SubCustomerId, intSeqNo, "UP")
                ElseIf IDs(0).IndexOf("Down") > 0 Then
                    Return df_MovePriority(MasterCustomerId, SubCustomerId, intSeqNo, "DOWN")
                End If

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
                Return False
            End Try

        End Function

        Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
            'Save the record
            If SaveEmergencyContact() Then
                Response.Redirect(NavigateURL)
            End If
        End Sub

        Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            Response.Redirect(NavigateURL)
        End Sub
        Private Function SetPropertyInfo(ByVal Name As String) As TIMSS.API.Core.PropertyInfo

            Dim APIPropertyInfo As TIMSS.API.Core.PropertyInfo = New TIMSS.API.Core.PropertyInfo

            APIPropertyInfo.Name = Name
            APIPropertyInfo.PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup

            Return APIPropertyInfo
        End Function

        Public Class aEmergencyContact
            Public EmergencyContactName As String
            Public EmergencyContactRelationship As String
            Public PhoneTypeCode As String
            Public Priority As Integer
            Public PhoneNumber As String
            Public SeqNo As Integer
            Public Edit As String
            Public Delete As String
        End Class

        Public Class XSLFileGlobalVariables
            Public ModuleId As Integer
            Public EmergencyContacts As String
        End Class


#Region "Personify Data"

        Private Function df_GetEmergencyContacts(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As String) As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            oEmergencyContacts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunicationEmergencyContacts")

            With oEmergencyContacts.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
            End With

            oEmergencyContacts.Sort("Priority")
            oEmergencyContacts.Fill()

            Return oEmergencyContacts

        End Function

        Private Function df_GetSingleEmergencyContact(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As String, _
            ByVal intEmergencyID As Integer) As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            oEmergencyContacts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunicationEmergencyContacts")

            With oEmergencyContacts.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
                .Add("CustomerCommunicationEmergencyContactId", TIMSS.Enumerations.QueryOperatorEnum.Equals, intEmergencyID)
            End With

            oEmergencyContacts.Sort("Priority")
            oEmergencyContacts.Fill()

            Return oEmergencyContacts

        End Function

        Private Function df_GetEmptyEmergencyContactCollection() _
                                                As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts

            oEmergencyContacts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunicationEmergencyContacts")
            oEmergencyContacts.AddNew()

            Return oEmergencyContacts

        End Function

        Private Function df_SaveEmergencyContact(ByVal oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts) As Boolean

            Return oEmergencyContacts.Save()

        End Function

        Private Function df_DeleteEmergencyContact(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer, ByVal intEmergencyID As Integer) As Boolean

            Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts
            Dim i As Integer

            oEmergencyContacts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunicationEmergencyContacts")

            With oEmergencyContacts.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
            End With

            oEmergencyContacts.Sort("Priority")
            oEmergencyContacts.Fill()

            For i = 0 To oEmergencyContacts.Count - 1
                If oEmergencyContacts(i).CustomerCommunicationEmergencyContactId = intEmergencyID Then
                    oEmergencyContacts.Remove(oEmergencyContacts(i))
                    Exit For
                End If
            Next

            Return oEmergencyContacts.Save()

        End Function

        Private Function df_MovePriority(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer, _
                                            ByVal intEmergencyID As Integer, ByVal Direction As String) As Boolean

            Dim oEmergencyContacts As TIMSS.API.CustomerInfo.ICustomerCommunicationEmergencyContacts
            Dim i As Integer

            oEmergencyContacts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunicationEmergencyContacts")

            With oEmergencyContacts.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
            End With

            oEmergencyContacts.Fill()

            For i = 0 To oEmergencyContacts.Count
                If oEmergencyContacts(i).CustomerCommunicationEmergencyContactId = intEmergencyID Then
                    If Direction = "UP" Then
                        oEmergencyContacts(i).MovePriorityUp()
                    ElseIf Direction = "DOWN" Then
                        oEmergencyContacts(i).MovePriorityDown()
                    End If
                    Exit For
                End If
            Next

            Return oEmergencyContacts.Save()

        End Function
#End Region
    End Class

End Namespace
