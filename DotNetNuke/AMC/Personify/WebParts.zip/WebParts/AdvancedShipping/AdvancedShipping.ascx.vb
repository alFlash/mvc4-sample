Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PersonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Namespace Personify.DNN.Modules.AdvancedShipping

    Public MustInherit Class AdvancedShipping
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"

        Protected AdvancedShippingTemplate As Personify.WebControls.XslTemplate
        Protected ContinueLink As HyperLink

#End Region

        Private Const C_ADDADDRESSEURL As String = "AddAddress_Url"
        Private Const C_NEXTPAGEURL As String = "NextPage_Url"
        Private Const C_AdvancedSHIPPINGTEMPLATE As String = "AdvancedShipping_Template"

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'Sample code to get data
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If Settings(C_NEXTPAGEURL) Is Nothing Then
                        'BadgeMessageControl.ShowMessage(Localization.GetString("NoLayoutSelected.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.RedError)
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        ContinueLink.Visible = False

                    Else

                        ContinueLink.NavigateUrl = NavigateURL(Convert.ToInt32(Settings(C_NEXTPAGEURL)))

                        LoadWebpartTemplate()

                        Dim strEventTarget As String

                        If IsPostBack Then
                            If Request("__EVENTTARGET").IndexOf("ShipToMethodDD" + ModuleId.ToString + "_") > 0 Then
                                strEventTarget = Request("__EVENTTARGET")

                                'strEventTarget.Split("_", StringSplitOptions.RemoveEmptyEntries)
                                SetShipToMethod(strEventTarget.Split(New Char() {"_"c})(strEventTarget.Split(New Char() {"_"c}).Length - 1))
                            End If

                            If Request("__EVENTTARGET").IndexOf("ShipToAddressDD" + ModuleId.ToString + "_") > 0 Then
                                strEventTarget = Request("__EVENTTARGET")

                                'strEventTarget.Split("_", StringSplitOptions.RemoveEmptyEntries)
                                SetShipFormattedAddress(strEventTarget.Split(New Char() {"_"c})(strEventTarget.Split(New Char() {"_"c}).Length - 1))
                            End If

                        End If
                    End If
                Else
                    ContinueLink.Visible = False
                    DisplayUserAccessMessage(role)
                      
                End If


                

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region

        Private Sub SetShipToMethod(ByVal OrderLineNumber As String)

            Dim ShipViaCode As String = Request("ShipToMethodDD" + ModuleId.ToString)

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetShipViaCodeForOrder(ShipViaCode, oOM, Convert.ToInt32(OrderLineNumber))

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

            RedirectOnChange()

        End Sub

        Private Sub SetShipFormattedAddress(ByVal OrderLineNumber As String)



            Dim ShipAddressID As Integer = Convert.ToInt32(Request("ShipFormattedAddressDD" + ModuleId.ToString))

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            oOM = GetOrderFromSessionObject()

            oOM = get_clsOrderCheckOutProcessHelper.SetShipAddressIDForOrder(ShipAddressID, oOM, Convert.ToInt32(OrderLineNumber))

            AddSessionObject(SessionKeys.PersonifyOrder, oOM)

            RedirectOnChange()

        End Sub


        Private Sub RedirectOnChange()
            Dim url As String = NavigateURL()
            Response.Redirect(url, True)
        End Sub



        Private Sub LoadWebpartTemplate()

            Dim oOM As TIMSS.API.OrderInfo.IOrderMasters

            AdvancedShippingTemplate.Visible = True
            AdvancedShippingTemplate.XSLfile = Server.MapPath(ModulePath + "Templates/AdvancedShipping.xsl")

            oOM = GetOrderFromSessionObject()

            If oOM IsNot Nothing Then

                Dim oEntireOrderSummary As New EntireOrderSummary(Me.OrganizationId, OrganizationUnitId, oOM, Me.BaseCurrency, Me.PortalCurrency, FetchOnDemand)

                Dim oODClass() As OrderDetails
                oODClass = oEntireOrderSummary.OrderDetails
                AdvancedShippingTemplate.AddObject("", oODClass)

                Dim oOrderTotals() As OrderTotals
                oOrderTotals = oEntireOrderSummary.OrderTotals
                AdvancedShippingTemplate.AddObject("", oOrderTotals)

                AdvancedShippingTemplate.AddObject("ModuleId", ModuleId)

                AdvancedShippingTemplate.Display()

                If oODClass IsNot Nothing AndAlso oODClass.Length > 0 Then

                    Dim oShipVia As TIMSS.API.ApplicationInfo.IApplicationCodes
                    oShipVia = GetApplicationCodes("ORD", "SHIP_VIA", True)

                    For i As Integer = 0 To oODClass.Length - 1
                        Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList


                        oAddresses = GetAllActiveCustomerAddresses(oODClass(i).ShipMasterCustomerId, oODClass(i).ShipSubCustomerId)

                        Dim tempC As New Control

                        Dim tempid As String = "ShipToMethodDD" + ModuleId.ToString + "_" + oODClass(i).OrderLineNumber.ToString
                        tempC = Me.FindControl(tempid)
                        If (tempC IsNot Nothing) Then

                            Dim tempDD As New DropDownList
                            tempDD = CType(tempC, DropDownList)
                            If tempDD.Items.Count < 1 Then
                                For x As Integer = 0 To oShipVia.Count - 1
                                    tempDD.Items.Add(New ListItem(oShipVia(x).Description.ToString, oShipVia(x).Code.ToString))
                                Next
                                tempDD.SelectedValue = oODClass(i).ShipViaCode
                                tempDD.Attributes.Add("onchange", "javascript: document.forms[0].ShipToMethodDD" + ModuleId.ToString + ".value = this.options[this.selectedIndex].value; ")
                            End If
                        End If

                        tempC = Me.FindControl("ShipToAddressDD" + ModuleId.ToString + "_" + oODClass(i).OrderLineNumber.ToString)
                        If (tempC IsNot Nothing) Then
                            Dim tempDD As New DropDownList
                            tempDD = CType(tempC, DropDownList)
                            If tempDD.Items.Count < 1 Then
                                'AN Change - This should be oAddresses.Count - 1 NOT oShipVia.Count - 1

                                For x As Integer = 0 To oAddresses.Count - 1
                                    tempDD.Items.Add(New ListItem(oAddresses(x).FormattedAddress.ToString, oAddresses(x).CustomerAddressId.ToString))
                                Next
                                tempDD.SelectedValue = oODClass(i).ShipAddressId
                                tempDD.Attributes.Add("onchange", "javascript: document.forms[0].ShipFormattedAddressDD" + ModuleId.ToString + ".value = this.options[this.selectedIndex].value; ")
                            End If
                        End If

                    Next
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoAvailable.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If


        End Sub

        Private Function GetOrderFromSessionObject() As TIMSS.API.OrderInfo.IOrderMasters

            'TODO -- Comment the following

            If Not GetSessionObject(SessionKeys.PersonifyOrder) Is Nothing Then
                Return CType(GetSessionObject(SessionKeys.PersonifyOrder), TIMSS.API.OrderInfo.IOrderMasters)
            Else
                Return Nothing
            End If


        End Function



#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Personify DAta"
        Private Function GetAllActiveCustomerAddresses(ByVal MasterCustomerId As String, _
    ByVal SubCustomerId As String) As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList



            oAddresses = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")

            With oAddresses.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
                .Add("AddressStatusCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, "GOOD")

            End With
            oAddresses.Sort("PrioritySeq", ComponentModel.ListSortDirection.Ascending)
            oAddresses.Fill()

            Return oAddresses

        End Function


#End Region
    End Class

End Namespace
