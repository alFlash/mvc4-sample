Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO

Namespace Personify.DNN.Modules.AdvancedShipping

	Public MustInherit Class AdvancedShippingEdit

        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
		Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
#End Region

		Private Const C_ADDADDRESSEURL As String = "AddAddress_Url"
		Private Const C_NEXTPAGEURL As String = "NextPage_Url"
		Private Const C_AdvancedSHIPPINGTEMPLATE As String = "AdvancedShipping_Template"
		Private Const C_TEMPLATES As String = "Templates"
		Private Const C_FILEPATTERN As String = "*.?s*"	'*.xsl

		Protected WithEvents Urlcontrol_NextPageUrl As DotNetNuke.UI.UserControls.UrlControl
		Protected WithEvents Urlcontrol_AddAddressUrl As DotNetNuke.UI.UserControls.UrlControl
		Protected WithEvents DropDownListAdvancedShippingTemplate As DropDownList

#Region "Private Members"
		Private itemId As Integer
#End Region

#Region "Event Handlers"
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

				Dim NextPageURL As String = String.Empty
				Dim AddAddressURL As String = String.Empty
				Dim NextPageTemplate As String = String.Empty

				Dim objMS As Hashtable
				Dim objMC As New DotNetNuke.Entities.Modules.ModuleController
				objMS = objMC.GetModuleSettings(ModuleId)

				If objMS(C_NEXTPAGEURL) IsNot Nothing Then
					NextPageURL = CType(objMS(C_NEXTPAGEURL), String)
				End If
				Urlcontrol_NextPageUrl.Url = NextPageURL

				If objMS(C_ADDADDRESSEURL) IsNot Nothing Then
					AddAddressURL = CType(objMS(C_ADDADDRESSEURL), String)
				End If
				Urlcontrol_AddAddressUrl.Url = AddAddressURL

				If objMS(C_AdvancedSHIPPINGTEMPLATE) IsNot Nothing Then
					NextPageTemplate = CType(objMS(C_AdvancedSHIPPINGTEMPLATE), String)
				End If

				Dim li As ListItem
				For Each li In GetTemplates()
					DropDownListAdvancedShippingTemplate.Items.Add(li)
				Next

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub


		Private Function GetTemplates() As ListItemCollection
			Try
				Dim lic As New ListItemCollection
				Dim ListItem As ListItem
				' Create a reference to the current directory.
				Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
				' Create an array representing the files in the current directory.
				Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
				Dim fiTemp As FileInfo
				For Each fiTemp In fInfo
					ListItem = New ListItem
					ListItem.Text = fiTemp.Name
					ListItem.Value = fiTemp.Name
					lic.Add(ListItem)
				Next fiTemp
				Return lic

			Catch ex As Exception
				Throw ex
			End Try
		End Function

		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try
				' Only Update if the Entered Data is Valid
				If Page.IsValid = True Then



                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting(C_NEXTPAGEURL, CType(Urlcontrol_NextPageUrl.Url, String))
                    UpdateModuleSetting(C_ADDADDRESSEURL, CType(Urlcontrol_AddAddressUrl.Url, String))
                    UpdateModuleSetting(C_AdvancedSHIPPINGTEMPLATE, CType(DropDownListAdvancedShippingTemplate.SelectedValue, String))

					' Redirect back to the portal home page
					Response.Redirect(NavigateURL(), True)
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try

				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
