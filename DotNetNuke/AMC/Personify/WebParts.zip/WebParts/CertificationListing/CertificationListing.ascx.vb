Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Namespace Personify.DNN.Modules.CertificationListing

    Public MustInherit Class CertificationListing
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected CertificationsXslTemplate As Personify.WebControls.XslTemplate
        Protected lblNothing As Label

        Const C_TEMPLATES As String = "Templates"
        Const C_CUSTOMER_TYPE As String = "CustomerType"
        Const C_CERTIFICATION_TYPE As String = "CertificationType"
        Const C_DETAILS_ACTION As String = "DetailsActionURL"
        Const C_REGISTER_ACTION As String = "RegisterActionURL"

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If Not Settings(C_TEMPLATES) Is Nothing Then

                        Dim Certifications As TIMSS.API.CertificationInfo.ICertifications = Nothing

                        Dim CertificationTypeCode() As String = Nothing

                        Dim codes As TIMSS.API.ApplicationInfo.IApplicationCodes
                        codes = GetApplicationCodes("CRT", "Certification_Type", True)

                        If codes IsNot Nothing AndAlso codes.Count > 0 Then
                            Dim arrCertificationTypeCode As New ArrayList
                            For i As Integer = 0 To codes.Count - 1
                                Dim key As String = C_CERTIFICATION_TYPE + codes(i).Code
                                If Settings(key) IsNot Nothing AndAlso Convert.ToBoolean(Settings(key)) = True Then
                                    arrCertificationTypeCode.Add(codes(i).Code)
                                End If
                            Next
                            If arrCertificationTypeCode.Count > 0 Then
                                Dim CertificationTypeCodeTemp(arrCertificationTypeCode.Count - 1) As String
                                arrCertificationTypeCode.CopyTo(CertificationTypeCodeTemp)
                                CertificationTypeCode = CertificationTypeCodeTemp
                            End If
                        End If

                        Dim CustomerTypeCode() As String = Nothing

                        codes = GetApplicationCodes("CUS", "CUSTOMER_TYPE", True)

                        If codes IsNot Nothing AndAlso codes.Count > 0 Then
                            Dim arrCustomerTypeCode As New ArrayList
                            For i As Integer = 0 To codes.Count - 1
                                Dim key As String = C_CUSTOMER_TYPE + codes(i).Code
                                If Settings(key) IsNot Nothing AndAlso Convert.ToBoolean(Settings(key)) = True Then
                                    arrCustomerTypeCode.Add(codes(i).Code)
                                End If
                            Next
                            If arrCustomerTypeCode.Count > 0 Then
                                Dim CustomerTypeCodeTemp(arrCustomerTypeCode.Count - 1) As String
                                arrCustomerTypeCode.CopyTo(CustomerTypeCodeTemp)
                                CustomerTypeCode = CustomerTypeCodeTemp
                            End If
                        End If


                        'CertificationTypeCode(0) = "CERTIFICATION"
                        'CertificationTypeCode(1) = "RECERTIFICATION"

                        'CustomerTypeCode(0) = "I"

                        Certifications = GetCertificationsList(False, CertificationTypeCode, CustomerTypeCode)

                        Dim templatefile As String = ""
                        'templatefile = ModulePath + "Templates\Certifications.xsl"
                        templatefile = ModulePath + "Templates\" + Settings(C_TEMPLATES).ToString

                        CertificationsXslTemplate.XSLfile = Server.MapPath(templatefile)

                        CertificationsXslTemplate.AddObject("", Certifications)
                        CertificationsXslTemplate.AddObject("ModuleId", ModuleId)


                        CertificationsXslTemplate.Display()


                        If Certifications IsNot Nothing AndAlso Certifications.Count > 0 Then
                            For i As Integer = 0 To Certifications.Count - 1
                                Dim hypDetail As HyperLink
                                hypDetail = CType(Me.FindControl("hypDetail" + ModuleId.ToString + "_" + Certifications(i).Guid), HyperLink)
                                If hypDetail IsNot Nothing Then
                                    Dim aNavigateURL As String = NavigateURL(CType(Settings(C_DETAILS_ACTION), Integer))
                                    If aNavigateURL.IndexOf("?") > 0 Then
                                        aNavigateURL += "&"
                                    Else
                                        aNavigateURL += "?"
                                    End If
                                    hypDetail.NavigateUrl = aNavigateURL + "C=" + Certifications(i).CertificationCode
                                End If
                            Next

                            For i As Integer = 0 To Certifications.Count - 1
                                Dim hypRegister As HyperLink
                                hypRegister = CType(Me.FindControl("hypRegister" + ModuleId.ToString + "_" + Certifications(i).Guid), HyperLink)
                                If hypRegister IsNot Nothing Then
                                    Dim aNavigateURL As String = NavigateURL(CType(Settings(C_REGISTER_ACTION), Integer))
                                    If aNavigateURL.IndexOf("?") > 0 Then
                                        aNavigateURL += "&"
                                    Else
                                        aNavigateURL += "?"
                                    End If
                                    hypRegister.NavigateUrl = aNavigateURL + "C=" + Certifications(i).CertificationCode
                                End If
                            Next

                        Else
                            lblNothing.Visible = True
                        End If

                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    End If
                Else
                   DisplayUserAccessMessage(role)
                End If
                
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region



#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Personify"
        Private Function GetCertificationsList(ByVal MembersOnly As Boolean, ByVal CertificationTypeCode As String(), ByVal CustomerTypeCode As String()) As TIMSS.API.CertificationInfo.ICertifications

            Dim oCertifications As TIMSS.API.CertificationInfo.ICertifications



            oCertifications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CertificationInfo, "Certifications")
            'oCertifications.Filter.Add("Web_Start_Date", TIMSS.Enumerations.QueryOperatorEnum.LessThanOrEqual, DateTime.Now)
            oCertifications.Filter.Add(New Timss.API.Core.FilterItem("Web_Start_Date is null or Web_Start_Date <= '" & DateTime.Now.ToString & "'"))

            'oCertifications.Filter.Add("Web_End_Date", TIMSS.Enumerations.QueryOperatorEnum.GreaterThanOrEqual, DateTime.Now)
            oCertifications.Filter.Add(New Timss.API.Core.FilterItem("Web_End_Date is null or Web_End_Date >= '" & DateTime.Now.ToString & "'"))

            oCertifications.Filter.Add(New Timss.API.Core.FilterItem("Enrollment_Expiration_Date is null or Enrollment_Expiration_Date >= '" & DateTime.Now.ToString & "'"))

            oCertifications.Filter.Add("Allow_Web_Registration_Flag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")

            If MembersOnly = True Then
                oCertifications.Filter.Add("membersOnlyFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
            End If
            If CertificationTypeCode IsNot Nothing AndAlso CertificationTypeCode.Length > 0 Then

                Dim strIN As New System.Text.StringBuilder
                For i As Integer = 0 To CertificationTypeCode.Length - 1
                    If i > 0 Then strIN.Append(",")
                    strIN.Append("'" + CertificationTypeCode(i) + "'")
                Next

                oCertifications.Filter.Add(New Timss.API.Core.FilterItem("Certification_Type_Code In ( " & strIN.ToString & " ) "))
            End If

            If CustomerTypeCode IsNot Nothing AndAlso CustomerTypeCode.Length > 0 Then

                Dim strIN As New System.Text.StringBuilder
                For i As Integer = 0 To CustomerTypeCode.Length - 1
                    If i > 0 Then strIN.Append(",")
                    strIN.Append("'" + CustomerTypeCode(i) + "'")
                Next

                oCertifications.Filter.Add(New Timss.API.Core.FilterItem("Customer_Type_Code In ( " & strIN.ToString & " ) "))
            End If

            oCertifications.Fill()
            Return oCertifications

        End Function


#End Region
    End Class

End Namespace
