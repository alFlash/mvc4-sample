Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO

Namespace Personify.DNN.Modules.CertificationListing

    Public MustInherit Class CertificationListingEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ListBox_CustomerType As System.Web.UI.WebControls.ListBox
        Protected WithEvents ListBox_CertificationType As System.Web.UI.WebControls.ListBox
        Protected WithEvents drpDetailAction As System.Web.UI.WebControls.DropDownList
        Protected WithEvents drpRegisterAction As System.Web.UI.WebControls.DropDownList


        Const C_TEMPLATES As String = "Templates"
        Const C_CUSTOMER_TYPE As String = "CustomerType"
        Const C_CERTIFICATION_TYPE As String = "CertificationType"
        Const C_DETAILS_ACTION As String = "DetailsActionURL"
        Const C_REGISTER_ACTION As String = "RegisterActionURL"

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                Dim _portalSettings As Entities.Portals.PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), Entities.Portals.PortalSettings)

                If Not select_Template.Items.Count > 0 Then
                    Dim li As ListItem
                    For Each li In GetTemplates()
                        If li.Text = "MyTranscripts.xsl" Then
                            li.Selected = True
                        End If
                        select_Template.Items.Add(li)
                    Next
                    select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings(C_TEMPLATES))))
                End If

                If Not Page.IsPostBack Then

                    '**Get a list of tabs in the portal
                    Dim arrTabs As ArrayList = GetPortalTabs(_portalSettings.DesktopTabs, True, True)

                    '**Bind the RenewAll dropdown list
                    With drpDetailAction
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    With drpRegisterAction
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    With ListBox_CustomerType
                        .DataSource = GetApplicationCodes("CUS", "CUSTOMER_TYPE", True)
                        .DataValueField = "Code"
                        .DataTextField = "Description"
                        .DataBind()
                    End With


                    With ListBox_CertificationType
                        .DataSource = GetApplicationCodes("CRT", "Certification_Type", True)
                        .DataValueField = "Code"
                        .DataTextField = "Description"
                        .DataBind()
                    End With

                    '**Details Action URL
                    If Not Settings(C_DETAILS_ACTION) Is Nothing Then
                        If Not Me.drpDetailAction.Items.FindByValue(Settings(C_DETAILS_ACTION).ToString) Is Nothing Then
                            Me.drpDetailAction.Items.FindByValue(Settings(C_DETAILS_ACTION).ToString).Selected = True
                        Else
                            Me.drpDetailAction.Items(0).Selected = True
                        End If
                    End If

                    If Not Settings(C_REGISTER_ACTION) Is Nothing Then
                        If Not Me.drpRegisterAction.Items.FindByValue(Settings(C_REGISTER_ACTION).ToString) Is Nothing Then
                            Me.drpRegisterAction.Items.FindByValue(Settings(C_REGISTER_ACTION).ToString).Selected = True
                        Else
                            Me.drpRegisterAction.Items(0).Selected = True
                        End If
                    End If

                    If ListBox_CustomerType IsNot Nothing AndAlso ListBox_CustomerType.Items.Count > 0 Then
                        For i As Integer = 0 To ListBox_CustomerType.Items.Count - 1
                            Dim key As String = C_CUSTOMER_TYPE + ListBox_CustomerType.Items(i).Value.ToString
                            If Settings(key) IsNot Nothing AndAlso Convert.ToBoolean(Settings(key)) = True Then
                                If Me.ListBox_CustomerType.Items.FindByValue(ListBox_CustomerType.Items(i).Value) IsNot Nothing Then
                                    Me.ListBox_CustomerType.Items.FindByValue(ListBox_CustomerType.Items(i).Value).Selected = True
                                End If
                            End If
                        Next
                    End If

                    If ListBox_CertificationType IsNot Nothing AndAlso ListBox_CertificationType.Items.Count > 0 Then
                        For i As Integer = 0 To ListBox_CertificationType.Items.Count - 1
                            Dim key As String = C_CERTIFICATION_TYPE + ListBox_CertificationType.Items(i).Value.ToString
                            If Settings(key) IsNot Nothing AndAlso Convert.ToBoolean(Settings(key)) = True Then
                                If Me.ListBox_CertificationType.Items.FindByValue(ListBox_CertificationType.Items(i).Value) IsNot Nothing Then
                                    Me.ListBox_CertificationType.Items.FindByValue(ListBox_CertificationType.Items(i).Value).Selected = True
                                End If
                            End If
                        Next
                    End If

                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function


        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                   UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)


                    UpdateModuleSetting( C_TEMPLATES, select_Template.SelectedValue)

                    If ListBox_CustomerType IsNot Nothing AndAlso ListBox_CustomerType.Items.Count > 0 Then
                        For i As Integer = 0 To ListBox_CustomerType.Items.Count - 1
                           UpdateModuleSetting( C_CUSTOMER_TYPE + ListBox_CustomerType.Items(i).Value.ToString, ListBox_CustomerType.Items(i).Selected.ToString)
                        Next
                    End If

                    If ListBox_CertificationType IsNot Nothing AndAlso ListBox_CertificationType.Items.Count > 0 Then
                        For i As Integer = 0 To ListBox_CertificationType.Items.Count - 1
                            UpdateModuleSetting( C_CERTIFICATION_TYPE + ListBox_CertificationType.Items(i).Value.ToString, ListBox_CertificationType.Items(i).Selected.ToString)
                        Next
                    End If

                 UpdateModuleSetting( C_DETAILS_ACTION, drpDetailAction.SelectedValue)
                  UpdateModuleSetting(C_REGISTER_ACTION, drpRegisterAction.SelectedValue)




                    'clean up






                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                'If Not Null.IsNull(itemId) Then
                '    Dim objCtlCertificationListing As New CertificationListingController
                '    objCtlCertificationListing.Delete(itemId)
                'End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
