Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.CustomerPreferences
Imports System.IO

Namespace Personify.DNN.Modules.CustomerPreferences

    Public MustInherit Class CustomerPreferencesEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkAllowPrefix As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowFirstName As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowMiddleName As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowLastName As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowSuffix As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowCredentials As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowCredentialsEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowPublishFlag As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowSSN As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowSSNEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowGender As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowGenderEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowBirthDate As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowBirthDateEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowEthnicity As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowEthnicityEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowAnnualIncomeRange As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowAnnualIncomeRangeEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowJobFunction As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowJobFunctionEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowRevenueRange As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowRevenueRangeEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkPrimaryJobTitle As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllowPrimaryJobTitleEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents update As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents cancel As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents allowCredentialsEdit As System.Web.UI.WebControls.Label
        Protected WithEvents chkAllowHintQuestionEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowHintQuestion As System.Web.UI.WebControls.CheckBox
        'Protected WithEvents selectTemplate As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents selectTemplate1 As System.Web.UI.HtmlControls.HtmlGenericControl
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            update.InnerHtml = DotNetNuke.Services.Localization.Localization.GetString("update", LocalResourceFile)
            cancel.InnerHtml = DotNetNuke.Services.Localization.Localization.GetString("cancel", LocalResourceFile)
            'selectTemplate.InnerHtml = Localization.GetString("selectTemplate", LocalResourceFile)
            Try
                Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
                If Not Page.IsPostBack Then

                    If Not select_Template.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            If li.Text = "CustomerPreferencesTemplate.xsl" Then
                                li.Selected = True
                            End If
                            select_Template.Items.Add(li)
                        Next
                        select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                    End If
                    chkAllowCredentialsEdit.Visible = False
                    allowCredentialsEdit.Visible = False
                    LoadSettings()
                    If Not DotNetNuke.Common.Utilities.Null.IsNull(itemId) Then
                    Else ' security violation attempt to access item not related to this Module
                        Response.Redirect(NavigateURL(), True)
                    End If
                    
                End If
                
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub LoadSettings()
            Try
                chkAllowPrefix.Checked = CType(Settings("allowPrefix"), Boolean)
                chkAllowFirstName.Checked = CType(Settings("allowFirstName"), Boolean)
                chkAllowMiddleName.Checked = CType(Settings("allowMiddleName"), Boolean)
                chkAllowLastName.Checked = CType(Settings("allowLastName"), Boolean)
                chkAllowSuffix.Checked = CType(Settings("allowSuffix"), Boolean)
                chkShowCredentials.Checked = CType(Settings("showCredentials"), Boolean)
                chkAllowCredentialsEdit.Checked = CType(Settings("allowCredentialsEdit"), Boolean)
                chkShowPublishFlag.Checked = CType(Settings("showPublishFlag"), Boolean)

                If (Settings("ShowSSN") IsNot Nothing) Then
                    chkShowSSN.Checked = CType(Settings("ShowSSN"), Boolean)
                End If

                If (Settings("AllowSSNEdit") IsNot Nothing) Then
                    chkAllowSSNEdit.Checked = CType(Settings("AllowSSNEdit"), Boolean)
                End If

                If (Settings("ShowGender") IsNot Nothing) Then
                    chkShowGender.Checked = CType(Settings("ShowGender"), Boolean)
                End If

                If (Settings("AllowGenderEdit") IsNot Nothing) Then
                    chkAllowGenderEdit.Checked = CType(Settings("AllowGenderEdit"), Boolean)
                End If

                If (Settings("ShowBirthDate") IsNot Nothing) Then
                    chkShowBirthDate.Checked = CType(Settings("ShowBirthDate"), Boolean)
                End If

                If (Settings("AllowBirthDateEdit") IsNot Nothing) Then
                    chkAllowBirthDateEdit.Checked = CType(Settings("AllowBirthDateEdit"), Boolean)
                End If

                If (Settings("ShowEthnicity") IsNot Nothing) Then
                    chkShowEthnicity.Checked = CType(Settings("ShowEthnicity"), Boolean)
                End If

                If (Settings("AllowEthnicityEdit") IsNot Nothing) Then
                    chkAllowEthnicityEdit.Checked = CType(Settings("AllowEthnicityEdit"), Boolean)
                End If

                If (Settings("ShowAnnualIncomeRange") IsNot Nothing) Then
                    chkShowAnnualIncomeRange.Checked = CType(Settings("ShowAnnualIncomeRange"), Boolean)
                End If

                If (Settings("AllowAnnualIncomeRangeEdit") IsNot Nothing) Then
                    chkAllowAnnualIncomeRangeEdit.Checked = CType(Settings("AllowAnnualIncomeRangeEdit"), Boolean)
                End If

                If (Settings("ShowJobFunction") IsNot Nothing) Then
                    chkShowJobFunction.Checked = CType(Settings("ShowJobFunction"), Boolean)
                End If

                If (Settings("AllowJobFunctionEdit") IsNot Nothing) Then
                    chkAllowJobFunctionEdit.Checked = CType(Settings("AllowJobFunctionEdit"), Boolean)
                End If

                If (Settings("ShowRevenueRange") IsNot Nothing) Then
                    chkShowRevenueRange.Checked = CType(Settings("ShowRevenueRange"), Boolean)
                End If

                If (Settings("AllowRevenueRangeEdit") IsNot Nothing) Then
                    chkAllowRevenueRangeEdit.Checked = CType(Settings("AllowRevenueRangeEdit"), Boolean)
                End If

                If (Settings("ShowPrimaryJobTitle") IsNot Nothing) Then
                    chkPrimaryJobTitle.Checked = CType(Settings("ShowPrimaryJobTitle"), Boolean)
                End If

                If (Settings("AllowPrimaryJobTitleEdit") IsNot Nothing) Then
                    chkAllowPrimaryJobTitleEdit.Checked = CType(Settings("AllowPrimaryJobTitleEdit"), Boolean)
                End If

                If (Settings("ShowHintQuestion") IsNot Nothing) Then
                    chkShowHintQuestion.Checked = CType(Settings("ShowHintQuestion"), Boolean)
                End If

                If (Settings("AllowHintQuestionEdit") IsNot Nothing) Then
                    chkAllowHintQuestionEdit.Checked = CType(Settings("AllowHintQuestionEdit"), Boolean)
                End If

                If chkShowCredentials.Checked = True Then
                    chkAllowCredentialsEdit.Visible = True
                    allowCredentialsEdit.Visible = True
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub UpdateSettings()
            Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
            objModules.UpdateModuleSetting(ModuleId, "Layout", select_Template.SelectedValue)
            objModules.UpdateModuleSetting(ModuleId, "allowPrefix", CType(chkAllowPrefix.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "allowFirstName", CType(chkAllowFirstName.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "allowMiddleName", CType(chkAllowMiddleName.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "allowLastName", CType(chkAllowLastName.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "allowSuffix", CType(chkAllowSuffix.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "showCredentials", CType(chkShowCredentials.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "allowCredentialsEdit", CType(chkAllowCredentialsEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "showPublishFlag", CType(chkShowPublishFlag.Checked, String))

            objModules.UpdateModuleSetting(ModuleId, "ShowSSN", CType(chkShowSSN.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowSSNEdit", CType(chkAllowSSNEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowGender", CType(chkShowGender.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowGenderEdit", CType(chkAllowGenderEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowBirthDate", CType(chkShowBirthDate.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowBirthDateEdit", CType(chkAllowBirthDateEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowEthnicity", CType(chkShowEthnicity.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowEthnicityEdit", CType(chkAllowEthnicityEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowAnnualIncomeRange", CType(chkShowAnnualIncomeRange.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowAnnualIncomeRangeEdit", CType(chkAllowAnnualIncomeRangeEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowJobFunction", CType(chkShowJobFunction.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowJobFunctionEdit", CType(chkAllowJobFunctionEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowRevenueRange", CType(chkShowRevenueRange.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowRevenueRangeEdit", CType(chkAllowRevenueRangeEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowPrimaryJobTitle", CType(chkPrimaryJobTitle.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowPrimaryJobTitleEdit", CType(chkAllowPrimaryJobTitleEdit.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "ShowHintQuestion", CType(chkShowHintQuestion.Checked, String))
            objModules.UpdateModuleSetting(ModuleId, "AllowHintQuestionEdit", CType(chkAllowHintQuestionEdit.Checked, String))
            'objModules.UpdateModuleSetting(ModuleId, "displayLogin", CType(display_Login.Checked, String))
        End Sub

        Public Sub chkCredentials_Click(ByVal sender As Object, ByVal e As EventArgs) Handles chkShowCredentials.CheckedChanged

            If chkShowCredentials.Checked = True Then
                chkAllowCredentialsEdit.Visible = True
                allowCredentialsEdit.Visible = True
            Else
                chkAllowCredentialsEdit.Visible = False
                allowCredentialsEdit.Visible = False
            End If
        End Sub
        Public Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                If Page.IsValid = True Then
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Else
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
