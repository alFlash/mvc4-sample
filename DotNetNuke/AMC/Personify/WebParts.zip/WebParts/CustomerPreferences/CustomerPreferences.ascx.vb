Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports TIMSS.API.CustomerInfo
Imports TIMSS.API.Core
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Entities.Modules
Imports Personify.ApplicationManager


Namespace Personify.DNN.Modules.CustomerPreferences

    Public MustInherit Class CustomerPreferences
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        'Dim mcid As String = ""
        'Dim scid As String = ""
        Private show As Boolean = True
        Private IsRecordCompany As Boolean = False


#Region " Controls"
        Protected WithEvents txtFirstName As New TextBox
        Protected WithEvents txtMiddleName As New TextBox
        Protected WithEvents txtLastName As New TextBox
        Protected WithEvents chkEmail As New CheckBox
        Protected WithEvents chkFax As New CheckBox
        Protected WithEvents chkPostalMail As New CheckBox
        Protected WithEvents chkPhone As New CheckBox
        Protected WithEvents chkPartners As New CheckBox
        Protected WithEvents chkPublishDirectory As CheckBox
        Protected WithEvents ddlNamePrefix As Personify.WebControls.ApplicationCodeDropDownList
        'Protected WithEvents ddlNamePrefix As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlNameSuffix As Personify.WebControls.ApplicationCodeDropDownList
        'Protected WithEvents ddlNameSuffix As System.Web.UI.WebControls.DropDownList
        'Protected WithEvents ddlPreferredCommunicationMethod As WebControls.ApplicationCodeDropDownList
        Protected WithEvents ddlPreferredCommunicationMethod As New System.Web.UI.WebControls.DropDownList
        Protected WithEvents PreferredCommMethod As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected prefTemplate As Personify.WebControls.XslTemplate
        Protected WithEvents lstCredentialsAvailable As New System.Web.UI.WebControls.ListBox
        Protected WithEvents lstCredentialsAssigned As New System.Web.UI.WebControls.ListBox
        Protected WithEvents lnkMoveRight As New System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkMoveLeft As New System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkAllRight As New System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkAllLeft As New System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblNamePrefix As New System.Web.UI.WebControls.Label
        Protected WithEvents lblNameSuffix As New System.Web.UI.WebControls.Label
        Protected WithEvents lblFirstName As New System.Web.UI.WebControls.Label
        Protected WithEvents lblLastName As New System.Web.UI.WebControls.Label
        Protected WithEvents lblMiddleName As New System.Web.UI.WebControls.Label
        Protected WithEvents lblNameCredentials As New System.Web.UI.WebControls.Label
        Protected WithEvents lblCredentialsAvailable As New System.Web.UI.WebControls.Label
        Protected WithEvents lblCredentialsAssigned As New System.Web.UI.WebControls.Label
        Protected WithEvents CredentialsAvailableLabel As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents CredentialsActionsLabel As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents CredentailsAvailableList As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents CredentailsActionsList As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents nprefix As New System.Web.UI.WebControls.Label
        Protected WithEvents nsufix As New System.Web.UI.WebControls.Label
        Protected WithEvents fname As New System.Web.UI.WebControls.Label
        Protected WithEvents mname As New System.Web.UI.WebControls.Label
        Protected WithEvents lname As New System.Web.UI.WebControls.Label
        Protected WithEvents btnSave As New System.Web.UI.WebControls.Button
        Protected WithEvents btnCancel As New System.Web.UI.WebControls.Button
        Protected WithEvents cred As New System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents prefix As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents suffix As New System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents lblPublishDirectory As New System.Web.UI.WebControls.Label
        Protected WithEvents oMessageControl As New WebControls.MessageControl
        Protected WithEvents pnlPreferences As New System.Web.UI.WebControls.Panel
        'Demographics
        Protected WithEvents txtSSN As TextBox
        Protected WithEvents lblSSN As Label
        Protected WithEvents ddlGender As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblGender As Label
        'Private cclBirthDate As Personify.UserControls.CalendarCtrl
        Private cclBirthDate As Telerik.Web.UI.RadDatePicker
        Protected WithEvents lblBirthDate As Label
        Protected WithEvents ddlEthnicity As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblEthnicity As Label
        Protected WithEvents ddlAnnualIncomeRange As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblAnnualIncomeRange As Label
        Protected WithEvents ddlJobFunction As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblJobFunction As Label
        Protected WithEvents ddlRevenueRange As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblRevenueRange As Label
        Protected WithEvents txtPrimaryJobTitle As TextBox
        Protected WithEvents lblPrimaryJobTitle As Label
        Protected WithEvents Gender As HtmlTableCell
        Protected WithEvents Ethnicity As HtmlTableCell
        Protected WithEvents AnnualIncomeRange As HtmlTableCell
        Protected WithEvents JobFunction As HtmlTableCell
        Protected WithEvents RevenueRange As HtmlTableCell
        Protected WithEvents BirthDate As HtmlTableCell

        Protected WithEvents lblSSNTitle As Label
        Protected WithEvents lblGenderTitle As Label
        Protected WithEvents lblBirthDateTitle As Label
        Protected WithEvents lblEthnicityTitle As Label
        Protected WithEvents lblAnnualIncomeRangeTitle As Label
        Protected WithEvents lblJobFunctionTitle As Label
        Protected WithEvents lblRevenueRangeTitle As Label
        Protected WithEvents lblPrimaryJobTitleTitle As Label

        'Hint Question
        Protected WithEvents lblHintQuestion As Label
        Protected WithEvents ddlHintQuestion As Personify.WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblAnswer As Label
        Protected WithEvents txtAnswer As TextBox
        Protected WithEvents HintQuestion As HtmlTableCell

        Protected WithEvents lblHintQuestionTitle As Label
        Protected WithEvents lblAnswerTitle As Label
        Protected WithEvents lblHintQuestionInfo As Label

        'Notification Flag Fields
        Protected WithEvents lblNotifications As Label
        Protected WithEvents ChkNotifications As CheckBox
#End Region

#Region " Page Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If show Then
                LoadPostbackValue()
            End If

        End Sub

#End Region

#Region " Credentials related action buttons "
        Protected Sub lnkMoveRight_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkMoveRight.Click
            Try
                Dim selectedValue As String = lstCredentialsAvailable.SelectedValue
                Dim selectedText As String = ""

                If Not String.Compare(selectedValue, String.Empty) = 0 Then
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("CUS", "CREDENTIALS", True)
                    Dim appcode As TIMSS.API.ApplicationInfo.IApplicationCode
                    For Each appcode In appCodes
                        If selectedValue = appcode.Code Then
                            selectedText = appcode.Description
                        End If
                    Next

                    lstCredentialsAssigned.Items.Add(New ListItem(selectedText, selectedValue))
                    lstCredentialsAvailable.Items.Remove(New ListItem(selectedText, selectedValue))
                End If

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub lnkMoveLeft_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkMoveLeft.Click
            Try
                Dim selectedValue As String = lstCredentialsAssigned.SelectedValue
                Dim selectedText As String = ""

                If Not String.Compare(selectedValue, String.Empty) = 0 Then

                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("CUS", "CREDENTIALS", True)
                    Dim appcode As TIMSS.API.ApplicationInfo.IApplicationCode
                    For Each appcode In appCodes
                        If selectedValue = appcode.Code Then
                            selectedText = appcode.Description
                        End If
                    Next

                    lstCredentialsAvailable.Items.Add(New ListItem(selectedText, selectedValue))
                    lstCredentialsAssigned.Items.Remove(New ListItem(selectedText, selectedValue))
                End If

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub lnkAllRight_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkAllRight.Click
            Try

                Dim selectedItem As ListItem
                For Each selectedItem In lstCredentialsAvailable.Items
                    lstCredentialsAssigned.Items.Add(selectedItem)
                Next
                lstCredentialsAvailable.Items.Clear()

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

        Protected Sub lnkAllLeft_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkAllLeft.Click
            Try

                Dim selectedItem As ListItem
                For Each selectedItem In lstCredentialsAssigned.Items
                    lstCredentialsAvailable.Items.Add(selectedItem)
                Next
                lstCredentialsAssigned.Items.Clear()

            Catch ex As Threading.ThreadAbortException

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub
#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            Dim role As String
            role = Me.GetUserRole(UserInfo)
            If role = "personifyuser" Or role = "personifyadmin" Then
                InitializeComponent()
                LoadPage()
            Else
                show = False
                btnSave.Visible = False
                btnCancel.Visible = False

                DisplayUserAccessMessage(role)
            End If

        End Sub

#End Region

#Region " Control Events "

        Private Sub LoadPostbackValue()
            ddlGender.DefaultValue = ddlGender.SelectedValue
            ddlEthnicity.DefaultValue = ddlEthnicity.SelectedValue
            ddlAnnualIncomeRange.DefaultValue = ddlAnnualIncomeRange.SelectedValue
            ddlJobFunction.DefaultValue = ddlJobFunction.SelectedValue
            ddlRevenueRange.DefaultValue = ddlRevenueRange.SelectedValue
            ddlNamePrefix.DefaultValue = ddlNamePrefix.SelectedValue
            ddlNameSuffix.DefaultValue = ddlNameSuffix.SelectedValue
            ddlHintQuestion.DefaultValue = ddlHintQuestion.SelectedValue
        End Sub

        Private Sub LoadPage()
            If Settings("allowPrefix") Is Nothing Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                show = False
                btnSave.Visible = False
                btnCancel.Visible = False
                Exit Sub
            End If
            ddlNamePrefix = New Personify.WebControls.ApplicationCodeDropDownList
            ddlNameSuffix = New Personify.WebControls.ApplicationCodeDropDownList
            ddlNamePrefix.ApplicationType = "NAME_PREFIX"
            ddlNamePrefix.Subsystem = "CUS"
            ddlNameSuffix.ApplicationType = "NAME_SUFFIX"
            ddlNameSuffix.Subsystem = "CUS"
            nprefix.Visible = False
            nsufix.Visible = False
            fname.Visible = False
            lname.Visible = False
            mname.Visible = False

            'Demographics
            ddlGender = New Personify.WebControls.ApplicationCodeDropDownList
            ddlGender.ApplicationType = "Gender"
            ddlGender.Subsystem = "CUS"
            ddlGender.EnableViewState = True

            ddlEthnicity = New Personify.WebControls.ApplicationCodeDropDownList
            ddlEthnicity.ApplicationType = "Ethnicity"
            ddlEthnicity.Subsystem = "CUS"
            ddlEthnicity.EnableViewState = True

            ddlAnnualIncomeRange = New Personify.WebControls.ApplicationCodeDropDownList
            ddlAnnualIncomeRange.ApplicationType = "Annual_Income_Range"
            ddlAnnualIncomeRange.Subsystem = "CUS"
            ddlAnnualIncomeRange.EnableViewState = True

            ddlJobFunction = New Personify.WebControls.ApplicationCodeDropDownList
            ddlJobFunction.ApplicationType = "Job_Function"
            ddlJobFunction.Subsystem = "CUS"
            ddlJobFunction.EnableViewState = True

            ddlRevenueRange = New Personify.WebControls.ApplicationCodeDropDownList
            ddlRevenueRange.ApplicationType = "Revenue_Range"
            ddlRevenueRange.Subsystem = "CUS"
            ddlRevenueRange.EnableViewState = True

            'cclBirthDate = CType(LoadControl("~\controls\CalendarCtrl.ascx"), UserControls.CalendarCtrl)
            cclBirthDate = New Telerik.Web.UI.RadDatePicker
            'cclBirthDate.RequiredErrorMessage = "Invalid Date"
            cclBirthDate.EnableViewState = True
            cclBirthDate.MinDate = "1/1/1900"

            'Hint Question
            ddlHintQuestion = New Personify.WebControls.ApplicationCodeDropDownList
            ddlHintQuestion.Width = 250
            ddlHintQuestion.ApplicationType = "Hint_Question"
            ddlHintQuestion.Subsystem = "CUS"
            ddlHintQuestion.EnableViewState = True
            Try
                ' Check if the Personify user has logged in, if not switch to DNN Account Info
                If Not Me.IsPersonifyWebUserLoggedIn() Then
                    SwitchToDNNAccountInfo()
                Else
                    If Not Page.IsPostBack Then
                        BindControls()
                        prefix.Controls.Add(ddlNamePrefix)
                        suffix.Controls.Add(ddlNameSuffix)
                        'Demographics
                        Gender.Controls.Add(ddlGender)
                        Ethnicity.Controls.Add(ddlEthnicity)
                        AnnualIncomeRange.Controls.Add(ddlAnnualIncomeRange)
                        JobFunction.Controls.Add(ddlJobFunction)
                        RevenueRange.Controls.Add(ddlRevenueRange)
                        BirthDate.Controls.Add(cclBirthDate)
                        'Hint Question
                        HintQuestion.Controls.Add(ddlHintQuestion)

                        If Settings("allowPrefix") IsNot Nothing AndAlso Settings("allowPrefix").ToString = "False" Then
                            ddlNamePrefix.Visible = False
                            'lblNamePrefix.Visible = False
                            nprefix.Visible = True
                        Else
                            nprefix.Visible = False
                        End If
                        If Settings("allowSuffix") IsNot Nothing AndAlso Settings("allowSuffix").ToString = "False" Then
                            ddlNameSuffix.Visible = False
                            'lblNameSuffix.Visible = False
                            nsufix.Visible = True
                        Else
                            nsufix.Visible = False
                        End If
                        If Settings("allowFirstName") IsNot Nothing AndAlso Settings("allowFirstName").ToString = "False" Then
                            txtFirstName.Visible = False
                            'lblFirstName.Visible = False
                            fname.Visible = True
                        Else
                            fname.Visible = False
                        End If
                        If Settings("allowLastName") IsNot Nothing AndAlso Settings("allowLastName").ToString = "False" Then
                            txtLastName.Visible = False
                            'lblLastName.Visible = False
                            lname.Visible = True
                        Else
                            lname.Visible = False
                        End If
                        If Settings("allowMiddleName") IsNot Nothing AndAlso Settings("allowMiddleName").ToString = "False" Then
                            txtMiddleName.Visible = False
                            'lblMiddleName.Visible = False
                            mname.Visible = True
                        Else
                            mname.Visible = False
                        End If
                        If Settings("showCredentials") IsNot Nothing AndAlso Settings("showCredentials").ToString = "False" Then
                            lblNameCredentials.Visible = False
                            cred.Visible = False
                        End If
                        If Settings("allowCredentialsEdit") IsNot Nothing AndAlso Settings("allowCredentialsEdit").ToString = "False" Then
                            lnkMoveRight.Visible = False
                            lnkMoveLeft.Visible = False
                            lnkAllLeft.Visible = False
                            lnkAllRight.Visible = False

                            lstCredentialsAvailable.Visible = False
                            lblCredentialsAvailable.Visible = False
                            CredentialsAvailableLabel.Visible = False
                            CredentialsActionsLabel.Visible = False
                            CredentailsAvailableList.Visible = False
                            CredentailsActionsList.Visible = False
                            lblCredentialsAssigned.Visible = False
                        End If
                        If Settings("showPublishFlag") IsNot Nothing AndAlso Settings("showPublishFlag").ToString = "False" Then
                            chkPublishDirectory.Visible = False
                            lblPublishDirectory.Visible = False
                        End If

                        If (IsRecordCompany) Then
                            PreferredCommMethod.Visible = False
                            ddlPreferredCommunicationMethod.Visible = False
                        End If

                        'Demographics
                        If Settings("ShowSSN") IsNot Nothing AndAlso Settings("ShowSSN").ToString = "False" Or (IsRecordCompany) Then
                            lblSSNTitle.Visible = False
                            txtSSN.Visible = False
                            lblSSN.Visible = False
                        Else
                            If Settings("AllowSSNEdit") IsNot Nothing AndAlso Settings("AllowSSNEdit").ToString = "False" Then
                                txtSSN.Visible = False
                                lblSSN.Visible = True
                            Else
                                lblSSN.Visible = False
                                txtSSN.Visible = True
                            End If
                        End If


                        If Settings("ShowGender") IsNot Nothing AndAlso Settings("ShowGender").ToString = "False" Or (IsRecordCompany) Then
                            lblGenderTitle.Visible = False
                            ddlGender.Visible = False
                            lblGender.Visible = False
                        Else
                            If Settings("AllowGenderEdit") IsNot Nothing AndAlso Settings("AllowGenderEdit").ToString = "False" Then
                                ddlGender.Visible = False
                                lblGender.Visible = True
                            Else
                                lblGender.Visible = False
                                ddlGender.Visible = True
                            End If
                        End If

                        If Settings("ShowBirthDate") IsNot Nothing AndAlso Settings("ShowBirthDate").ToString = "False" Or (IsRecordCompany) Then
                            lblBirthDateTitle.Visible = False
                            lblBirthDate.Visible = False
                            cclBirthDate.Visible = False
                        Else
                            If Settings("AllowBirthDateEdit") IsNot Nothing AndAlso Settings("AllowBirthDateEdit").ToString = "False" Then
                                cclBirthDate.Visible = False
                                lblBirthDate.Visible = True
                            Else
                                lblBirthDate.Visible = False
                                cclBirthDate.Visible = True
                            End If
                        End If

                        If Settings("ShowEthnicity") IsNot Nothing AndAlso Settings("ShowEthnicity").ToString = "False" Or (IsRecordCompany) Then
                            lblEthnicityTitle.Visible = False
                            ddlEthnicity.Visible = False
                            lblEthnicity.Visible = False
                        Else
                            If Settings("AllowEthnicityEdit") IsNot Nothing AndAlso Settings("AllowEthnicityEdit").ToString = "False" Then
                                ddlEthnicity.Visible = False
                                lblEthnicity.Visible = True
                            Else
                                lblEthnicity.Visible = False
                                ddlEthnicity.Visible = True
                            End If
                        End If

                        If Settings("ShowAnnualIncomeRange") IsNot Nothing AndAlso Settings("ShowAnnualIncomeRange").ToString = "False" Then
                            lblAnnualIncomeRangeTitle.Visible = False
                            ddlAnnualIncomeRange.Visible = False
                            lblAnnualIncomeRange.Visible = False
                        Else
                            If Settings("AllowAnnualIncomeRangeEdit") IsNot Nothing AndAlso Settings("AllowAnnualIncomeRangeEdit").ToString = "False" Then
                                ddlAnnualIncomeRange.Visible = False
                                lblAnnualIncomeRange.Visible = True
                            Else
                                lblAnnualIncomeRange.Visible = False
                                ddlAnnualIncomeRange.Visible = True
                            End If
                        End If

                        If Settings("ShowJobFunction") IsNot Nothing AndAlso Settings("ShowJobFunction").ToString = "False" Or (IsRecordCompany) Then
                            lblJobFunctionTitle.Visible = False
                            ddlJobFunction.Visible = False
                            lblJobFunction.Visible = False
                        Else
                            If Settings("AllowJobFunctionEdit") IsNot Nothing AndAlso Settings("AllowJobFunctionEdit").ToString = "False" Then
                                ddlJobFunction.Visible = False
                                lblJobFunction.Visible = True
                            Else
                                lblJobFunction.Visible = False
                                ddlJobFunction.Visible = True
                            End If
                        End If

                        If (Settings("ShowRevenueRange") IsNot Nothing AndAlso Settings("ShowRevenueRange").ToString = "False") Or (Not IsRecordCompany) Then
                            lblRevenueRangeTitle.Visible = False
                            ddlRevenueRange.Visible = False
                            lblRevenueRange.Visible = False
                        Else
                            If Settings("AllowRevenueRangeEdit") IsNot Nothing AndAlso Settings("AllowRevenueRangeEdit").ToString = "False" Then
                                ddlRevenueRange.Visible = False
                                lblRevenueRange.Visible = True
                            Else
                                lblRevenueRange.Visible = False
                                ddlRevenueRange.Visible = True
                            End If
                        End If

                        If Settings("ShowPrimaryJobTitle") IsNot Nothing AndAlso Settings("ShowPrimaryJobTitle").ToString = "False" Then
                            lblPrimaryJobTitleTitle.Visible = False
                            txtPrimaryJobTitle.Visible = False
                            lblPrimaryJobTitle.Visible = False
                        Else
                            If Settings("AllowPrimaryJobTitleEdit") IsNot Nothing AndAlso Settings("AllowPrimaryJobTitleEdit").ToString = "False" Then
                                txtPrimaryJobTitle.Visible = False
                                lblPrimaryJobTitle.Visible = True
                            Else
                                lblPrimaryJobTitle.Visible = False
                                txtPrimaryJobTitle.Visible = True
                            End If
                        End If

                        'Hint Question
                        If Settings("ShowHintQuestion") IsNot Nothing AndAlso Settings("ShowHintQuestion").ToString = "False" Then
                            lblHintQuestion.Visible = False
                            ddlHintQuestion.Visible = False
                            lblHintQuestionTitle.Visible = False

                            lblAnswer.Visible = False
                            txtAnswer.Visible = False
                            lblAnswerTitle.Visible = False

                            lblHintQuestionInfo.Visible = False
                        Else
                            If Settings("AllowHintQuestionEdit") IsNot Nothing AndAlso Settings("AllowHintQuestionEdit").ToString = "False" Then
                                ddlHintQuestion.Visible = False
                                lblHintQuestion.Visible = True

                                txtAnswer.Visible = False
                                lblAnswer.Visible = True
                            Else
                                lblHintQuestion.Visible = False
                                ddlHintQuestion.Visible = True

                                lblAnswer.Visible = False
                                txtAnswer.Visible = True
                            End If
                        End If
                    Else
                        BindControls()
                        prefix.Controls.Add(ddlNamePrefix)
                        suffix.Controls.Add(ddlNameSuffix)

                        'Demographics
                        Gender.Controls.Add(ddlGender)
                        Ethnicity.Controls.Add(ddlEthnicity)
                        AnnualIncomeRange.Controls.Add(ddlAnnualIncomeRange)
                        JobFunction.Controls.Add(ddlJobFunction)
                        RevenueRange.Controls.Add(ddlRevenueRange)
                        BirthDate.Controls.Add(cclBirthDate)
                        HintQuestion.Controls.Add(ddlHintQuestion)

                        If ddlNamePrefix.SelectedValue.Length > 0 Then
                            ddlNamePrefix.SelectedValue = ddlNamePrefix.SelectedValue
                        End If

                        If ddlNameSuffix.SelectedValue.Length > 0 Then
                            ddlNameSuffix.SelectedValue = ddlNameSuffix.SelectedValue
                        End If
                    End If
                End If
            Catch exc As Threading.ThreadAbortException
                'Ignore this one..
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub AbortPage(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            Try

                Response.Redirect(NavigateURL(), True)

            Catch ex As Threading.ThreadAbortException
                'ignore this exception
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click

            If Me.IsPersonifyWebUserLoggedIn() Then
                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

                oCustomers = df_GetCustomer(MasterCustomerId, SubCustomerId)

                If oCustomers.Count > 0 Then
                    With oCustomers(0)
                        .FirstName = txtFirstName.Text
                        .MiddleName = txtMiddleName.Text
                        .LastName = txtLastName.Text
                        .NamePrefix.Code = ddlNamePrefix.SelectedValue
                        .NameSuffix.Code = ddlNameSuffix.SelectedValue
                        .NameCredentials = FormattedCredentials()
                        ' Update the Allow Solication flag. Removal date is being added by the API
                        ' when the AllowSolication flag is set to False
                        If (Not chkEmail.Checked) And (Not chkFax.Checked) And _
                            (Not chkPostalMail.Checked) And (Not chkPhone.Checked) And _
                            (Not chkPartners.Checked) Then
                            If .AllowSolicitationFlag Then
                                .AllowSolicitationFlag = False
                            End If
                        Else
                            .AllowSolicitationFlag = True
                        End If
                        ' Update Solicitation flags
                        .AllowEmailFlag = chkEmail.Checked
                        .AllowFaxFlag = chkFax.Checked
                        .AllowInternalMailFlag = chkPostalMail.Checked
                        .AllowPhoneFlag = chkPhone.Checked
                        .AllowLabelSalesFlag = chkPartners.Checked
                        .IncludeInDirectoryFlag = chkPublishDirectory.Checked
                        .PreferredCommMethodCode = ddlPreferredCommunicationMethod.SelectedValue

                        'Notification Flag
                        .AllowSystemNotificationFlag = ChkNotifications.Checked

                        'Demographics
                        If txtSSN.Visible Then
                            Dim spliter As String = "-"
                            Dim temp() As String = txtSSN.Text.Split(spliter.ToCharArray)
                            Dim ssn As String = ""
                            For i As Integer = 0 To temp.Length - 1
                                ssn = ssn + temp(i)
                            Next
                            .Ssn = ssn
                        End If

                        If ddlGender.Visible Then
                            .GenderCode.Code = ddlGender.SelectedValue
                        End If

                        If cclBirthDate.Visible Then
                            If Not cclBirthDate.IsEmpty AndAlso Not String.IsNullOrEmpty(cclBirthDate.SelectedDate) Then
                                .BirthDate = CType(cclBirthDate.SelectedDate, DateTime)
                            Else
                                .BirthDate = Nothing
                            End If
                        End If

                        If ddlEthnicity.Visible Then
                            .EthnicityCode.Code = ddlEthnicity.SelectedValue
                        End If

                        If ddlAnnualIncomeRange.Visible Then
                            .AnnualIncomeRangeCode.Code = ddlAnnualIncomeRange.SelectedValue
                        End If

                        If ddlJobFunction.Visible Then
                            .JobFunctionCode.Code = ddlJobFunction.SelectedValue
                        End If

                        If ddlRevenueRange.Visible Then
                            .RevenueRangeCode.Code = ddlRevenueRange.SelectedValue
                        End If

                        If txtPrimaryJobTitle.Visible Then
                            .PrimaryJobTitle = txtPrimaryJobTitle.Text
                        End If

                    End With

                    'Save the Preferences
                    oCustomers.Save()



                    If Not oMessageControl.ValidationIssues Is Nothing Then
                        oMessageControl.Clear()
                    End If

                    If oCustomers.ValidationIssues.Count > 0 Then
                        oMessageControl.Show(CType(oCustomers.ValidationIssues, Validation.IssuesCollection))
                    Else
                        ' Display a message to the user
                        'Skins.Skin.AddModuleMessage(Me, Localization.GetString("SaveSuccess", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                        If ddlHintQuestion.Visible Then
                            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers

                            oWebUsers = df_GetWebUser(MasterCustomerId, SubCustomerId)
                            If oWebUsers.Count > 0 Then
                                With oWebUsers(0)
                                    .HintQuestionCode.Code = ddlHintQuestion.SelectedValue
                                    .HintAnswer = txtAnswer.Text
                                End With

                                oWebUsers.Save()
                            End If


                            If Not oMessageControl.ValidationIssues Is Nothing Then
                                oMessageControl.Clear()
                            End If

                            If oCustomers.ValidationIssues.Count > 0 Then
                                oMessageControl.Show(CType(oWebUsers.ValidationIssues, Validation.IssuesCollection))
                            Else
                                AbortPage(Nothing, Nothing)
                            End If
                        Else
                            AbortPage(Nothing, Nothing)
                        End If
                    End If
                End If
            Else
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("NeedLogin", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If

        End Sub

        Private Sub ddlNamePrefix_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlNamePrefix.PreRender
            If Me.IsPersonifyWebUserLoggedIn() Then
                Dim oListItem As New ListItem
                Dim strlocalizedPrefixLabel As String
                Dim strPrefixLabelFormat As String
                strPrefixLabelFormat = Localization.GetString("DefaultListItem", LocalResourceFile)
                If strPrefixLabelFormat = String.Empty Then
                    strPrefixLabelFormat = "-- Select {0} --"
                End If
                strlocalizedPrefixLabel = Localization.GetString("lblNamePrefix", LocalResourceFile)
                If strlocalizedPrefixLabel = String.Empty Then
                    strlocalizedPrefixLabel = "Prefix"
                End If


                oListItem.Text = String.Format(strPrefixLabelFormat, strlocalizedPrefixLabel)
                oListItem.Value = "-1"

                ddlNamePrefix.Items.Insert(0, oListItem)
                oListItem = Nothing
            End If
        End Sub

        Private Sub ddlNameSuffix_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlNameSuffix.PreRender
            If Me.IsPersonifyWebUserLoggedIn() Then
                Dim oListItem As New ListItem
                Dim strlocalizedSuffixLabel As String
                Dim strSuffixLabelFormat As String
                strSuffixLabelFormat = Localization.GetString("DefaultListItem", LocalResourceFile)
                If strSuffixLabelFormat = String.Empty Then
                    strSuffixLabelFormat = "-- Select {0} --"
                End If
                strlocalizedSuffixLabel = Localization.GetString("lblNameSuffix", LocalResourceFile)
                If strlocalizedSuffixLabel = String.Empty Then
                    strlocalizedSuffixLabel = "Suffix"
                End If


                oListItem.Text = String.Format(strSuffixLabelFormat, strlocalizedSuffixLabel)
                oListItem.Value = "-1"

                ddlNameSuffix.Items.Insert(0, oListItem)
                oListItem = Nothing
            End If
        End Sub

#End Region

#Region " Properties "
        'Formats multiple credentials by separating them with a ";"
        Private ReadOnly Property FormattedCredentials() As String
            Get
                If lstCredentialsAssigned.Items.Count > 0 Then
                    Dim i As Integer
                    Dim strAssignedCredentials As String = ""
                    For i = 0 To lstCredentialsAssigned.Items.Count - 1
                        strAssignedCredentials = String.Concat(strAssignedCredentials, lstCredentialsAssigned.Items(i).Value, ";")
                    Next
                    'Remove the trailing ";" and return the formatted credentials
                    strAssignedCredentials = strAssignedCredentials.Remove(strAssignedCredentials.Length - 1, 1)
                    Return strAssignedCredentials
                Else
                    'Return empty string
                    Return ""
                End If
            End Get
        End Property
#End Region

#Region " Helper functions"
        '
        Private Sub BindControls()
            Try

                If Me.IsPersonifyWebUserLoggedIn() Then

                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

                    oCustomers = df_GetCustomer(MasterCustomerId, SubCustomerId)
                    Dim templatefile As String = ""
                    If Settings("Layout") Is Nothing Then
                        templatefile = ModulePath + "Templates\CustomerPreferencesTemplate.xsl"
                    Else
                        templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
                    End If

                    If System.IO.File.Exists(Server.MapPath(templatefile)) = False Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoFileSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    Else

                        prefTemplate.XSLfile = Server.MapPath(templatefile)
                        ' tableTCMSXslTemplate.AddObject("", oMyOrdersFiltered)
                        prefTemplate.AddObject("", oCustomers(0))
                        prefTemplate.Display()

                        txtFirstName = (CType(Me.FindControl("txtFirstName".ToString), TextBox))
                        txtMiddleName = (CType(Me.FindControl("txtMiddleName".ToString), TextBox))
                        txtLastName = (CType(Me.FindControl("txtLastName".ToString), TextBox))
                        chkEmail = (CType(Me.FindControl("chkEmail".ToString), CheckBox))
                        chkFax = (CType(Me.FindControl("chkFax".ToString), CheckBox))
                        chkPostalMail = (CType(Me.FindControl("chkPostalMail".ToString), CheckBox))
                        chkPhone = (CType(Me.FindControl("chkPhone".ToString), CheckBox))
                        chkPartners = (CType(Me.FindControl("chkPartners".ToString), CheckBox))
                        chkPublishDirectory = (CType(Me.FindControl("chkPublishDirectory".ToString), CheckBox))
                        'ddlNamePrefix = (CType(Me.FindControl("ddlNamePrefix".ToString), Personify.WebControls.ApplicationCodeDropDownList))
                        'Protected WithEvents ddlNamePrefix As System.Web.UI.WebControls.DropDownList
                        'ddlNameSuffix = (CType(Me.FindControl("ddlNameSuffix".ToString), Personify.WebControls.ApplicationCodeDropDownList))
                        'Protected WithEvents ddlNameSuffix As System.Web.UI.WebControls.DropDownList
                        'Protected WithEvents ddlPreferredCommunicationMethod As WebControls.ApplicationCodeDropDownList
                        ddlPreferredCommunicationMethod = (CType(Me.FindControl("ddlPreferredCommunicationMethod".ToString), System.Web.UI.WebControls.DropDownList))
                        PreferredCommMethod = (CType(Me.FindControl("PreferredCommMethod".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        lstCredentialsAvailable = (CType(Me.FindControl("lstCredentialsAvailable".ToString), System.Web.UI.WebControls.ListBox))
                        lstCredentialsAssigned = (CType(Me.FindControl("lstCredentialsAssigned".ToString), System.Web.UI.WebControls.ListBox))
                        CredentialsAvailableLabel = (CType(Me.FindControl("CredentialsAvailableLabel".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        CredentialsActionsLabel = (CType(Me.FindControl("CredentialsActionsLabel".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        CredentailsAvailableList = (CType(Me.FindControl("CredentailsAvailableList".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        CredentailsActionsList = (CType(Me.FindControl("CredentailsActionsList".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        lnkMoveRight = (CType(Me.FindControl("lnkMoveRight".ToString), System.Web.UI.WebControls.LinkButton))
                        lnkMoveLeft = (CType(Me.FindControl("lnkMoveLeft".ToString), System.Web.UI.WebControls.LinkButton))
                        lnkAllRight = (CType(Me.FindControl("lnkAllRight".ToString), System.Web.UI.WebControls.LinkButton))
                        lnkAllLeft = (CType(Me.FindControl("lnkAllLeft".ToString), System.Web.UI.WebControls.LinkButton))
                        lblNamePrefix = (CType(Me.FindControl("lblNamePrefix".ToString), System.Web.UI.WebControls.Label))
                        lblNameSuffix = (CType(Me.FindControl("lblNameSuffix".ToString), System.Web.UI.WebControls.Label))
                        lblFirstName = (CType(Me.FindControl("lblFirstName".ToString), System.Web.UI.WebControls.Label))
                        lblLastName = (CType(Me.FindControl("lblLastName".ToString), System.Web.UI.WebControls.Label))
                        lblMiddleName = (CType(Me.FindControl("lblMiddleName".ToString), System.Web.UI.WebControls.Label))
                        lblNameCredentials = (CType(Me.FindControl("lblNameCredentials".ToString), System.Web.UI.WebControls.Label))
                        lblCredentialsAvailable = (CType(Me.FindControl("lblCredentialsAvailable".ToString), System.Web.UI.WebControls.Label))
                        lblCredentialsAssigned = (CType(Me.FindControl("lblCredentialsAssigned".ToString), System.Web.UI.WebControls.Label))
                        nprefix = (CType(Me.FindControl("nprefix".ToString), System.Web.UI.WebControls.Label))
                        nsufix = (CType(Me.FindControl("nsufix".ToString), System.Web.UI.WebControls.Label))
                        fname = (CType(Me.FindControl("fname".ToString), System.Web.UI.WebControls.Label))
                        mname = (CType(Me.FindControl("mname".ToString), System.Web.UI.WebControls.Label))
                        lname = (CType(Me.FindControl("lname".ToString), System.Web.UI.WebControls.Label))

                        cred = (CType(Me.FindControl("cred".ToString), System.Web.UI.HtmlControls.HtmlTable))
                        prefix = (CType(Me.FindControl("prefix".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        suffix = (CType(Me.FindControl("suffix".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        lblPublishDirectory = (CType(Me.FindControl("lblPublishDirectory".ToString), System.Web.UI.WebControls.Label))

                        'Demographices
                        txtSSN = (CType(Me.FindControl("txtSSN".ToString), System.Web.UI.WebControls.TextBox))
                        lblSSN = (CType(Me.FindControl("lblSSN".ToString), System.Web.UI.WebControls.Label))
                        lblGender = (CType(Me.FindControl("lblGender".ToString), System.Web.UI.WebControls.Label))
                        lblBirthDate = (CType(Me.FindControl("lblBirthDate".ToString), System.Web.UI.WebControls.Label))
                        lblEthnicity = (CType(Me.FindControl("lblEthnicity".ToString), System.Web.UI.WebControls.Label))
                        lblAnnualIncomeRange = (CType(Me.FindControl("lblAnnualIncomeRange".ToString), System.Web.UI.WebControls.Label))
                        lblJobFunction = (CType(Me.FindControl("lblJobFunction".ToString), System.Web.UI.WebControls.Label))
                        lblRevenueRange = (CType(Me.FindControl("lblRevenueRange".ToString), System.Web.UI.WebControls.Label))
                        txtPrimaryJobTitle = (CType(Me.FindControl("txtPrimaryJobTitle".ToString), System.Web.UI.WebControls.TextBox))
                        lblPrimaryJobTitle = (CType(Me.FindControl("lblPrimaryJobTitle".ToString), System.Web.UI.WebControls.Label))
                        Gender = (CType(Me.FindControl("Gender".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        Ethnicity = (CType(Me.FindControl("Ethnicity".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        AnnualIncomeRange = (CType(Me.FindControl("AnnualIncomeRange".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        JobFunction = (CType(Me.FindControl("JobFunction".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        RevenueRange = (CType(Me.FindControl("RevenueRange".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        BirthDate = (CType(Me.FindControl("BirthDate".ToString), System.Web.UI.HtmlControls.HtmlTableCell))

                        lblSSNTitle = (CType(Me.FindControl("lblSSNTitle".ToString), System.Web.UI.WebControls.Label))
                        lblGenderTitle = (CType(Me.FindControl("lblGenderTitle".ToString), System.Web.UI.WebControls.Label))
                        lblBirthDateTitle = (CType(Me.FindControl("lblBirthDateTitle".ToString), System.Web.UI.WebControls.Label))
                        lblEthnicityTitle = (CType(Me.FindControl("lblEthnicityTitle".ToString), System.Web.UI.WebControls.Label))
                        lblAnnualIncomeRangeTitle = (CType(Me.FindControl("lblAnnualIncomeRangeTitle".ToString), System.Web.UI.WebControls.Label))
                        lblJobFunctionTitle = (CType(Me.FindControl("lblJobFunctionTitle".ToString), System.Web.UI.WebControls.Label))
                        lblRevenueRangeTitle = (CType(Me.FindControl("lblRevenueRangeTitle".ToString), System.Web.UI.WebControls.Label))
                        lblPrimaryJobTitleTitle = (CType(Me.FindControl("lblPrimaryJobTitleTitle".ToString), System.Web.UI.WebControls.Label))

                        'Hint Question
                        lblHintQuestionTitle = (CType(Me.FindControl("lblHintQuestionTitle".ToString), System.Web.UI.WebControls.Label))
                        lblAnswerTitle = (CType(Me.FindControl("lblAnswerTitle".ToString), System.Web.UI.WebControls.Label))
                        lblHintQuestionInfo = (CType(Me.FindControl("lblHintQuestionInfo".ToString), System.Web.UI.WebControls.Label))

                        lblHintQuestion = (CType(Me.FindControl("lblHintQuestion".ToString), System.Web.UI.WebControls.Label))
                        HintQuestion = (CType(Me.FindControl("HintQuestion".ToString), System.Web.UI.HtmlControls.HtmlTableCell))
                        lblAnswer = (CType(Me.FindControl("lblAnswer".ToString), System.Web.UI.WebControls.Label))
                        txtAnswer = (CType(Me.FindControl("txtAnswer".ToString), System.Web.UI.WebControls.TextBox))

                        'Added Notification Flag 
                        lblNotifications = (CType(Me.FindControl("lblNotifications".ToString), System.Web.UI.WebControls.Label))
                        ChkNotifications = (CType(Me.FindControl("chkNotifications".ToString), CheckBox))

                    End If

                    If oCustomers.Count > 0 Then
                        Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers

                        oWebUsers = df_GetWebUser(MasterCustomerId, SubCustomerId)
                        If oWebUsers.Count > 0 Then
                            With oCustomers(0)
                                txtFirstName.Text = .FirstName
                                txtMiddleName.Text = .MiddleName
                                txtLastName.Text = .LastName
                                ddlNamePrefix.SelectedValue = .NamePrefix.Code.ToString
                                ddlNameSuffix.SelectedValue = .NameSuffix.Code.ToString
                                nprefix.Text = .NamePrefix.Code.ToString
                                nsufix.Text = .NameSuffix.Code.ToString
                                lname.Text = .LastName
                                fname.Text = .FirstName
                                mname.Text = .MiddleName
                                'chkPublishDirectory.Checked = oCustomer(0). Need to bind to include in Directory flag not 
                                'currently available in the API
                                chkPublishDirectory.Checked = .IncludeInDirectoryFlag
                                chkEmail.Checked = .AllowEmailFlag
                                chkFax.Checked = .AllowFaxFlag
                                chkPostalMail.Checked = .AllowInternalMailFlag
                                chkPhone.Checked = .AllowPhoneFlag
                                chkPartners.Checked = .AllowLabelSalesFlag


                                'Notification Flag
                                ChkNotifications.Checked = .AllowSystemNotificationFlag

                                'Demographics
                                txtSSN.Text = .Ssn.ToString
                                lblSSN.Text = .Ssn.ToString

                                lblGender.Text = .GenderCodeString
                                If (.GenderCode.Code.ToString = "") OrElse Page.IsPostBack Then
                                    ddlGender.AddInitLine = True
                                    ddlGender.InitLine = Localization.GetString("InitLine", LocalResourceFile)
                                Else
                                    ddlGender.SelectedValue = .GenderCode.Code.ToString
                                End If

                                If oCustomers(0).RecordType = "I" Then
                                    lblBirthDate.Text = .BirthDate.ToString
                                    If Not (.BirthDate.ToString = "12:00:00 AM" OrElse .BirthDate.ToString = "1/1/0001 12:00:00 AM") Then
                                        cclBirthDate.SelectedDate = .BirthDate
                                    End If
                                    IsRecordCompany = False
                                Else
                                    IsRecordCompany = True
                                End If

                                lblEthnicity.Text = .EthnicityCodeString
                                If (.EthnicityCode.Code.ToString = "") OrElse Page.IsPostBack Then
                                    ddlEthnicity.AddInitLine = True
                                    ddlEthnicity.InitLine = Localization.GetString("InitLine", LocalResourceFile)
                                Else
                                    ddlEthnicity.SelectedValue = .EthnicityCode.Code.ToString
                                End If

                                lblAnnualIncomeRange.Text = .AnnualIncomeRangeCodeString
                                If (.AnnualIncomeRangeCode.Code.ToString = "") OrElse Page.IsPostBack Then
                                    ddlAnnualIncomeRange.AddInitLine = True
                                    ddlAnnualIncomeRange.InitLine = Localization.GetString("InitLine", LocalResourceFile)
                                Else
                                    ddlAnnualIncomeRange.SelectedValue = .AnnualIncomeRangeCode.Code.ToString
                                End If

                                lblJobFunction.Text = .JobFunctionCodeString
                                If (.JobFunctionCode.Code.ToString = "") OrElse Page.IsPostBack Then
                                    ddlJobFunction.AddInitLine = True
                                    ddlJobFunction.InitLine = Localization.GetString("InitLine", LocalResourceFile)
                                Else
                                    ddlJobFunction.SelectedValue = .JobFunctionCode.Code.ToString
                                End If

                                If oCustomers(0).RecordType = "C" Then
                                    lblRevenueRange.Text = .RevenueRangeCodeString
                                    If (.RevenueRangeCode.Code.ToString = "") OrElse Page.IsPostBack Then
                                        ddlRevenueRange.AddInitLine = True
                                        ddlRevenueRange.InitLine = Localization.GetString("InitLine", LocalResourceFile)
                                    Else
                                        ddlRevenueRange.SelectedValue = .RevenueRangeCode.Code.ToString
                                    End If
                                    IsRecordCompany = True
                                Else
                                    IsRecordCompany = False
                                End If

                                lblPrimaryJobTitle.Text = .PrimaryJobTitle.ToString
                                txtPrimaryJobTitle.Text = .PrimaryJobTitle.ToString

                                'Hint Question
                                lblHintQuestion.Text = oWebUsers(0).HintQuestionCode.Description
                                If (oWebUsers(0).HintQuestionCode.Code.ToString = "") OrElse Page.IsPostBack Then
                                    ddlHintQuestion.AddInitLine = True
                                    ddlHintQuestion.InitLine = Localization.GetString("InitLine", LocalResourceFile)
                                Else
                                    ddlHintQuestion.SelectedValue = oWebUsers(0).HintQuestionCode.Code.ToString
                                End If

                                lblAnswer.Text = oWebUsers(0).HintAnswer.ToString
                                txtAnswer.Text = oWebUsers(0).HintAnswer.ToString

                                If Not Page.IsPostBack Then
                                    With lstCredentialsAvailable
                                        'sets the Available Credentials  listbox
                                        .DataSource = GetApplicationCodes("CUS", "CREDENTIALS", True)
                                        .DataTextField = "DESCRIPTION"
                                        .DataValueField = "CODE"
                                        .DataBind()
                                    End With
                                    If .NameCredentials.Length > 0 Then
                                        Dim CredentialItemsValue() As String = Split(.NameCredentials, ";")
                                        Dim i As Integer
                                        If CredentialItemsValue.Length <> lstCredentialsAssigned.Items.Count Then
                                            For i = 0 To CredentialItemsValue.Length - 1
                                                If Not lstCredentialsAvailable.Items.FindByValue(CredentialItemsValue(i)) Is Nothing Then
                                                    lstCredentialsAssigned.Items.Add(New ListItem(lstCredentialsAvailable.Items.FindByValue(CredentialItemsValue(i)).Text, CredentialItemsValue(i)))
                                                    lstCredentialsAvailable.Items.Remove(New ListItem(lstCredentialsAvailable.Items.FindByValue(CredentialItemsValue(i)).Text, CredentialItemsValue(i)))
                                                End If
                                            Next
                                        End If

                                    End If
                                End If

                            End With

                            ' Preferred Communications
                            If oCustomers(0).RecordType = "I" Then
                                With ddlPreferredCommunicationMethod
                                    .DataSource = oCustomers(0).PreferredCommMethodCodeList
                                    .DataTextField = "DESCRIPTION"
                                    .DataValueField = "CODE"
                                    .DataBind()
                                    .SelectedValue = oCustomers(0).PreferredCommMethodCode.ToString

                                    ' Add default item using localization
                                    Dim oListItem As New ListItem
                                    Dim strlocalizedLabel As String
                                    Dim strLabelFormat As String
                                    strLabelFormat = Localization.GetString("DefaultListItem", LocalResourceFile)
                                    If strLabelFormat = String.Empty Then
                                        strLabelFormat = "-- Select {0} --"
                                    End If
                                    strlocalizedLabel = Localization.GetString("lblPreferredCommunicationMethod", LocalResourceFile)
                                    If strlocalizedLabel = String.Empty Then
                                        strlocalizedLabel = "Preferred Communication Method"
                                    End If


                                    oListItem.Text = String.Format(strLabelFormat, strlocalizedLabel)
                                    oListItem.Value = "-1"

                                    .Items.Insert(0, oListItem)
                                    oListItem = Nothing
                                End With
                                IsRecordCompany = False
                            Else
                                IsRecordCompany = True
                            End If

                        End If
                    End If


                Else
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NeedLogin", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ' Checks if the Personify user is logged in, if not redirects the user to the DNN Account Info tab 
        Private Sub SwitchToDNNAccountInfo()
            If Not Me.IsPersonifyWebUserLoggedIn() Then
                Dim objUserInfo As DotNetNuke.Entities.Users.UserInfo = DotNetNuke.Entities.Users.UserController.GetCurrentUserInfo

                ' Check if this is a valid user
                If objUserInfo.UserID <> -1 Then
                    If objUserInfo.IsSuperUser Then
                        ' Hide the Control from the super user
                        pnlPreferences.Visible = False
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AdminModeMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    Else
                        Response.Redirect(NavigateURL(PortalSettings.ActiveTab.TabID, "Profile", "UserID=" + objUserInfo.UserID.ToString))
                    End If
                Else
                    pnlPreferences.Visible = False
                End If
            Else
                pnlPreferences.Visible = True
            End If
        End Sub

#End Region

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        End Sub


#Region "Personify Data"

        Private Function df_GetCustomer(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers


            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
                .Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
                .Fill()
            End With

            Return oCustomers

        End Function
        Private Function df_GetWebUser(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer) As TIMSS.API.WebInfo.IWebUsers

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers


            oWebUsers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

            oWebUsers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
            oWebUsers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
            oWebUsers.Fill()
            Return oWebUsers


        End Function

#End Region
    End Class

End Namespace