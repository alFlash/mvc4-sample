Option Strict Off

Imports System
Imports System.Web.UI.WebControls
Imports Personify

Namespace Personify.DNN.Modules.MySubscriptionInfo

    Public MustInherit Class MySubscriptionInfo
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


        

#Region " Properties "
        Dim _datasource As DataTable
        Private _RenewalWindowInDays As Integer
        Private _DisplayAllSubscriptions As Boolean
        Private _RenewActionURL As String
        Private _ViewAllActionURL As String
        Private _ExpirationInDays As Integer

        Friend Property ExpirationInDays() As Integer
            Get
                Return _ExpirationInDays
            End Get
            Set(ByVal Value As Integer)
                _ExpirationInDays = Value
            End Set
        End Property


        Private Property DataSource() As DataTable
            Get
                Return _datasource
            End Get
            Set(ByVal Value As DataTable)
                _datasource = Value
            End Set
        End Property

        Private Property RenewalWindowInDays() As Integer
            Get
                Return _RenewalWindowInDays
            End Get
            Set(ByVal Value As Integer)
                _RenewalWindowInDays = Value
            End Set
        End Property

        Private Property DisplayAllSubscriptions() As Boolean
            Get
                Return _DisplayAllSubscriptions
            End Get
            Set(ByVal Value As Boolean)
                _DisplayAllSubscriptions = Value
            End Set
        End Property

        Private Property RenewActionURL() As String
            Get
                Return _RenewActionURL
            End Get
            Set(ByVal Value As String)
                _RenewActionURL = Value
            End Set
        End Property


        Private Property ViewAllActionURL() As String
            Get
                Return _ViewAllActionURL
            End Get
            Set(ByVal Value As String)
                _ViewAllActionURL = Value
            End Set
        End Property

#End Region

#Region " Variables declaration "
        Dim oContext As Content
        Private Const C_EXPIRATION As String = "ExpirationInDays"
        Private Const C_RENEWAL_WINDOW As String = "RenewalWindowInDays"
        Private Const C_DISPLAYALL As String = "DisplayAllSubscriptions"
        Private Const C_RENEW_ACTION As String = "RenewActionURL"
        Private Const C_VIEWALL_ACTION As String = "ViewAllActionURL"
        'Dim SubscriptionInfoModule As New DotNetNuke.Entities.Tabs.TabController
#End Region

#Region " Controls "
        Protected WithEvents dlstAllSubscriptions As System.Web.UI.WebControls.DataList
        Protected WithEvents pnlSubscriptionInfo As System.Web.UI.WebControls.Panel
        Public WithEvents lblNoSubscriptionsMessage As System.Web.UI.WebControls.Label
        Public WithEvents lblShowing As System.Web.UI.WebControls.Label
        Protected WithEvents hypSubRenew As System.Web.UI.WebControls.HyperLink
        Protected WithEvents divButton As System.Web.UI.WebControls.Panel
        Protected WithEvents hypViewAll As System.Web.UI.WebControls.HyperLink
        Private dtRenewalDate As Date
        Protected SubscriptionTemplate As Personify.WebControls.XslTemplate
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
           
            Try
               
                Dim role As String
                role = Me.GetUserRole(UserInfo)


                If Personify.ApplicationManager.AffiliateManagementSessionHelper.IsManagingAffiliate(PortalId) OrElse (Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin") Then

                    If Not Page.IsPostBack Then
                        Try


                            If MasterCustomerId <> "" Then
                                ReadWebPartSettings()
                                BindSubscriptionData()
                                '3246-5774803
                                LoadImages()
                                'END 3246-5774803
                            Else
                                pnlSubscriptionInfo.Visible = False
                                DisplayUserAccessMessage(role)
                            End If

                        Catch ex As Exception
                            DisplayUserAccessMessage(role)
                        End Try
                    End If
                Else
                    pnlSubscriptionInfo.Visible = False
                    DisplayUserAccessMessage(role)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Sub BindSubscriptionData()

            Dim intTotalCount As Integer
            'Dim intTotalCount, intCurrentCount As Integer
            Dim oSubscriptionInfo As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoViewList = DF_GetMySubscriptions(MasterCustomerId, CInt(SubCustomerId), 2, ExpirationInDays, intTotalCount)

            Dim SubscriptionList(oSubscriptionInfo.Count - 1) As SubscriptionsObject

            dtRenewalDate = Date.op_Addition(Now.Date, TimeSpan.FromDays(RenewalWindowInDays))
            Dim counter As Integer = 0
            For Each item As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoView In oSubscriptionInfo
                Dim mySubscriptionsObject As New SubscriptionsObject
                mySubscriptionsObject.ShortName = item.ShortName
                mySubscriptionsObject.GraceDate = FormatDateTime(item.GraceDate)
                mySubscriptionsObject.increment = counter
                '3246-5774803
                mySubscriptionsObject.DocumentPlainImageURL = ResolveUrl(GetDocumentPlainImageURL())
                'end 3246-5774803

                If Not FormatDateTime(item.GraceDate) Is Nothing Then
                    If dtRenewalDate >= item.GraceDate Then
                        mySubscriptionsObject.Url = RenewActionURL
                        mySubscriptionsObject.UrlVisible = "true"
                    End If
                Else
                    mySubscriptionsObject.UrlVisible = "false"
                End If
                SubscriptionList(counter) = mySubscriptionsObject
                counter = counter + 1
            Next


            Dim intCurrent, intTotal As Integer
            intTotal = oSubscriptionInfo.Count
            Dim templatefile As String = ""
            ' If Settings("Layout") Is Nothing Then
            templatefile = ModulePath + "Templates\MySubscriptionsTemplate.xsl"
            ' Else
            ' templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
            ' End If
            SubscriptionTemplate.XSLfile = Server.MapPath(templatefile)
            Dim lblShowing As Label
            Dim hypViewAll As HyperLink

            If Not SubscriptionList Is Nothing AndAlso SubscriptionList.Length > 0 Then
                If Not DisplayAllSubscriptions Then
                    intCurrent = 2
                    If SubscriptionList.Length > 2 Then
                        Array.Clear(SubscriptionList, 2, SubscriptionList.Length - 2)
                        SubscriptionTemplate.AddObject("", SubscriptionList)
                        'dlstAllMeetings.DataSource = GetTopRows(2)  'Get only the top 2 rows
                    Else
                        SubscriptionTemplate.AddObject("", SubscriptionList)
                        'dlstAllMeetings.DataSource = DataSource
                    End If
                    'intCurrent = DirectCast(dlstAllMeetings.DataSource, DataTable).Rows.Count
                Else
                    intCurrent = SubscriptionList.Length
                    '**Display all data
                    SubscriptionTemplate.AddObject("", SubscriptionList)
                    'dlstAllMeetings.DataSource = DataSource
                    'intCurrent = DirectCast(dlstAllMeetings.DataSource, DataTable).Rows.Count
                End If


                'dlstAllMeetings.DataBind()
                Try
                    SubscriptionTemplate.Display()
                Catch ex As Exception

                End Try

                hypViewAll = CType(Me.FindControl("hypViewAll".ToString), HyperLink)
                lblShowing = CType(Me.FindControl("lblShowing".ToString), Label)

                Try
                    lblShowing.Text = Localization.GetString("showing", LocalResourceFile) & " " & intCurrent.ToString & " " & Localization.GetString("of", LocalResourceFile) & " " & intTotal.ToString
                    'lblShowing.Text = "Showing " & intCurrent.ToString & " of " & intTotal.ToString
                Catch ex As Exception

                End Try

                If Not SubscriptionList Is Nothing AndAlso SubscriptionList.Length > 0 Then
                    lblNoSubscriptionsMessage.Visible = False
                End If
                If Not DisplayAllSubscriptions Then
                    hypViewAll.NavigateUrl = ViewAllActionURL
                Else
                    hypViewAll.Visible = False   'Hide the button if all rows have been displayed
                End If
                If SubscriptionList.Length <= 2 Then
                    hypViewAll.Visible = False   'Hide the button if there is no more than 2 rows of data
                End If
            Else
                '    hypViewAll.Visible = False
                lblNoSubscriptionsMessage.Visible = True
            End If
        End Sub

        Function GetTopRows(ByVal intRowCount As Integer) As DataTable
            If Not DataSource Is Nothing Then
                If DataSource.Rows.Count > 2 Then
                    Dim odtCopy As DataTable
                    Dim _StartIndex As Integer = 0
                    odtCopy = DataSource.Clone
                    For index As Integer = _StartIndex To _StartIndex + intRowCount - 1
                        odtCopy.ImportRow(DataSource.Rows(index))
                    Next
                    Return odtCopy
                End If
            End If
            Return Nothing
        End Function

        Private Sub ReadWebPartSettings()
            Dim strActionURL As String
            Dim intRenewActionTab As Integer
            Dim intViewAllActionTab As Integer

            If Not Settings(C_EXPIRATION) Is Nothing Then
                ExpirationInDays = CInt(Settings(C_EXPIRATION))
            End If

            If Not Settings(C_RENEWAL_WINDOW) Is Nothing Then
                RenewalWindowInDays = CInt(Settings(C_RENEWAL_WINDOW))
            End If

            If Not Settings(C_DISPLAYALL) Is Nothing Then
                DisplayAllSubscriptions = CBool(Settings(C_DISPLAYALL))
            End If

            If Not Settings(C_RENEW_ACTION) Is Nothing Then
                intRenewActionTab = CInt(Settings(C_RENEW_ACTION))
            End If

            strActionURL = NavigateURL(CType(Settings(C_RENEW_ACTION), Integer))
            RenewActionURL = strActionURL

            If Not Settings(C_VIEWALL_ACTION) Is Nothing Then
                intViewAllActionTab = CInt(Settings(C_VIEWALL_ACTION))
            End If

            strActionURL = NavigateURL(CType(Settings(C_VIEWALL_ACTION), Integer))
            ViewAllActionURL = strActionURL

        End Sub

        Public Function DF_GetMySubscriptions(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoViewList


            Dim oWebSubscriptions As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoViewList

            oWebSubscriptions = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebCustomerSubscriptionInfoViewList")

            oWebSubscriptions.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            oWebSubscriptions.Filter.Add("ShipSubCustomerId", SubCustomerId)

            oWebSubscriptions.Sort("ExpirationDate", "ShortName")

            oWebSubscriptions.Fill()

            Return oWebSubscriptions


        End Function


        Private Function DF_GetMySubscriptions(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, _
        ByVal NoOfSubscriptionsToFetch As Integer, ByVal NoOfDaysSinceSubscriptionExpired As Integer, _
        ByRef TotalNoOfSubscriptions As Integer) As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoViewList
            'NoOfSubscriptionsToFetch = 0 - Fetches all Subscriptions
            'NoOfDaysSinceSubscriptionExpired = 0 - Fetches Only The Current Subscriptions
            Dim oAllWebSubscriptions As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoViewList
            Dim oReturnSubscriptions As TIMSS.API.WebInfo.IWebCustomerSubscriptionInfoViewList
            'ApplicationManager.Commons.GetMyApplicationObject(PortalId)

            Dim i As Integer = 0

            oAllWebSubscriptions = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebCustomerSubscriptionInfoViewList")

            oAllWebSubscriptions.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            oAllWebSubscriptions.Filter.Add("ShipSubCustomerId", SubCustomerId)

            oAllWebSubscriptions.Sort("ExpirationDate", "ShortName")

            oAllWebSubscriptions.Fill()


            oReturnSubscriptions = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebCustomerSubscriptionInfoViewList")

            TotalNoOfSubscriptions = oAllWebSubscriptions.Count

            If NoOfSubscriptionsToFetch = 0 Then
                oReturnSubscriptions = oAllWebSubscriptions
            Else
                For i = 0 To oAllWebSubscriptions.Count - 1
                    If Date.op_Subtraction(Now.Date, TimeSpan.FromDays(NoOfDaysSinceSubscriptionExpired)) <= oAllWebSubscriptions(i).Expirationdate Then
                        oReturnSubscriptions.Add(oAllWebSubscriptions(i))
                    End If
                Next
            End If
            TotalNoOfSubscriptions = oReturnSubscriptions.Count
            Return oReturnSubscriptions
        End Function

        '3246-5774803
        Private Sub LoadImages()

            If FindControl("imgIconBlank") IsNot Nothing Then
                Dim imgIconBlank As Image = CType(FindControl("imgIconBlank"), Image)
                imgIconBlank.ImageUrl = "~/" & SiteImagesFolder & "/icon_blank.gif"
            End If


        End Sub

        Private Function GetDocumentPlainImageURL() As String

            Return "~/" & SiteImagesFolder & "/document_plain.gif"
        End Function
        'end 3246-5774803
#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class
    Public Class SubscriptionsObject
        Public increment As Integer
        Public Url As String
        Public ShortName As String
        Public GraceDate As String
        Public UrlVisible As String
        Public DocumentPlainImageURL As String
    End Class
End Namespace
