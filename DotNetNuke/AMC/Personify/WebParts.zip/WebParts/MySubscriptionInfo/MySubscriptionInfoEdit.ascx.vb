Imports System
Imports System.IO
Imports System.Web.UI.WebControls
Imports DotNetNuke


Namespace Personify.DNN.Modules.MySubscriptionInfo

    Public MustInherit Class MySubscriptionInfoEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtExpirationDays As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkExpandedView As System.Web.UI.WebControls.CheckBox
        Protected WithEvents drpRenewAction As System.Web.UI.WebControls.DropDownList
        Protected WithEvents drpViewAllAction As System.Web.UI.WebControls.DropDownList
        Protected WithEvents rvExpirationDays As System.Web.UI.WebControls.RangeValidator
        Protected WithEvents rfExpirationInDays As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents rvRenewalWindowInDays As System.Web.UI.WebControls.RangeValidator
        Protected WithEvents rfRenewalWindowInDays As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtRenewalWindowInDays As System.Web.UI.WebControls.TextBox

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region " Variables "
        Const C_EXPIRATION As String = "ExpirationInDays"
        Const C_RENEWAL_WINDOW As String = "RenewalWindowInDays"
        Const C_DISPLAYALL As String = "DisplayAllSubscriptions"
        Const C_RENEW_ACTION As String = "RenewActionURL"
        Const C_VIEWALL_ACTION As String = "ViewAllActionURL"
#End Region


#Region "Event Handlers"
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not select_Template.Items.Count > 0 Then
                    Dim li As ListItem
                    For Each li In GetTemplates()
                        If li.Text = "MySubscriptionsTemplate.xsl" Then
                            li.Selected = True
                        End If
                        select_Template.Items.Add(li)
                    Next
                    select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                End If
                'Dim objMySubscriptionInfo As New MySubscriptionInfoInfo

                If Not Page.IsPostBack Then
                    Dim _portalSettings As Entities.Portals.PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), Entities.Portals.PortalSettings)

                    '**Get a list of tabs in the portal
                    Dim arrTabs As ArrayList = GetPortalTabs(_portalSettings.DesktopTabs, True, True)

                    '**Bind the RenewAll dropdown list
                    With drpRenewAction
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    '**Bind the ViewAll dropdown list
                    With drpViewAllAction
                        .DataSource = arrTabs
                        .DataValueField = "TabId"
                        .DataTextField = "TabName"
                        .DataBind()
                    End With

                    '**Expiration Days
                    If Not Settings(C_EXPIRATION) Is Nothing Then
                        txtExpirationDays.Text = Settings(C_EXPIRATION).ToString
                    End If

                    '**Renewal Window in Days
                    If Not Settings(C_RENEWAL_WINDOW) Is Nothing Then
                        txtRenewalWindowInDays.Text = Settings(C_RENEWAL_WINDOW).ToString
                    End If

                    '**Display All Subscriptions
                    If Not Settings(C_DISPLAYALL) Is Nothing Then
                        chkExpandedView.Checked = CBool(Settings(C_DISPLAYALL))
                    End If

                    '**Renew Action URL
                    If Not Settings(C_RENEW_ACTION) Is Nothing Then
                        If Not Me.drpRenewAction.Items.FindByValue(Settings(C_RENEW_ACTION).ToString) Is Nothing Then
                            Me.drpRenewAction.Items.FindByValue(Settings(C_RENEW_ACTION).ToString).Selected = True
                        Else
                            Me.drpRenewAction.Items(0).Selected = True
                        End If
                    End If

                    '**View All Action URL
                    If Not Settings(C_VIEWALL_ACTION) Is Nothing Then
                        If Not Me.drpViewAllAction.Items.FindByValue(Settings(C_VIEWALL_ACTION).ToString) Is Nothing Then
                            Me.drpViewAllAction.Items.FindByValue(Settings(C_VIEWALL_ACTION).ToString).Selected = True
                        Else
                            Me.drpViewAllAction.Items(0).Selected = True
                        End If
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then



                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting(C_EXPIRATION, txtExpirationDays.Text)
                    UpdateModuleSetting(C_RENEWAL_WINDOW, txtRenewalWindowInDays.Text)
                    UpdateModuleSetting("Layout", select_Template.SelectedValue)
                    UpdateModuleSetting(C_DISPLAYALL, CStr(chkExpandedView.Checked))
                    UpdateModuleSetting(C_RENEW_ACTION, drpRenewAction.SelectedValue)
                    UpdateModuleSetting(C_VIEWALL_ACTION, drpViewAllAction.SelectedValue)
                 
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
