Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports TIMSS.API.OrderInfo
Imports System.Collections.Generic
'Imports Personify.ApplicationManager


Namespace Personify.DNN.Modules.CustomerDCDFiles

    Public MustInherit Class CustomerDCDFiles
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Optional Interfaces"

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
            Return Nothing
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
            Return Nothing
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Controls"
        Protected WithEvents gvDCDFileList As GridView        
        Protected WithEvents ddlFilter As DropDownList
        Protected WithEvents PanelFilter As Panel

#End Region

#Region "CONST & Variables"
        Private Const DownloadCommandValue As String = "DownloadFile"
        Private Const SubsystemConst As String = "ECD"
        Private Const OrderNumberParameter As String = "OrderNo"
        Private Const OrderLineParameter As String = "OrderLine"
        Private Const FileIdParameter As String = "FileId"
        Private Const AutoDownloadParameter As String = "A"

        Private _DCDDownloadParamters As Personify.ApplicationManager.PersonifyDataObjects.DCDDownloadParameters

        'Private _MasterCustomerId As String
        'Private _SubCustomerId As Integer


#End Region

#Region "Properties"

        Public ReadOnly Property LoadAllDCDProductFlag() As Boolean
            Get
                Select Case ddlFilter.SelectedValue.ToUpper
                    Case "A" 'Available download only
                        Return False
                    Case "ALL" 'All download including expired
                        Return True
                End Select
            End Get          
        End Property



#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If (DotNetNuke.Framework.AJAX.IsInstalled()) Then
                    DotNetNuke.Framework.AJAX.RegisterScriptManager()
                End If

                If Me.IsPersonifyWebUserLoggedIn() AndAlso Not Page.IsPostBack Then
                    If Not ProcessAutoDownloadIfValid() Then 'only if querystring/post contain DCD download info
                        LoadUserInterface()
                    End If
                Else
                    'show login screen
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub gvDCDFileList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvDCDFileList.PageIndexChanging
            gvDCDFileList.PageIndex = e.NewPageIndex
            LoadUserInterface()
        End Sub

        Private Sub gvDCDFileList_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvDCDFileList.RowDataBound

            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.RowState = DataControlRowState.Normal Or e.Row.RowState = DataControlRowState.Alternate Then
                    With e.Row

                        Dim lblOrderNo As Label = .FindControl("lblOrderNo")
                        Dim lblOrderLineNo As Label = .FindControl("lblOrderLineNo")
                        Dim lblFileId As Label = .FindControl("lblFileId")
                        Dim lblFileName As Label = .FindControl("lblFileName")
                        Dim lblDownloadConfirm As Label = .FindControl("lblDownloadConfirm")
                        '##Filename##

                        lblOrderNo.Text = CType(e.Row.DataItem, DataRowView).Item("OrderNo")
                        lblOrderLineNo.Text = CType(e.Row.DataItem, DataRowView).Item("OrderLineNo")
                        lblFileId.Text = CType(e.Row.DataItem, DataRowView).Item("FileId")
                        lblFileName.Text = CType(e.Row.DataItem, DataRowView).Item("FileName")

                        Dim imgDownload As ImageButton
                        Dim strCommandValue As New System.Text.StringBuilder

                        imgDownload = .FindControl("imgDownload")


                        If CType(CType(e.Row.DataItem, DataRowView).Item("isCanDownload"), Boolean) Then
                            imgDownload.ImageUrl = String.Concat("~/", String.Concat(SiteImagesFolder, "/files_down_32.gif"))
                        Else
                            imgDownload.ImageUrl = String.Concat("~/", String.Concat(SiteImagesFolder, "/files_down_no_32.gif"))
                            imgDownload.Enabled = False
                        End If

                        lblDownloadConfirm.Text = Localization.GetString("lblDownloadConfirm", Me.LocalResourceFile)
                        lblDownloadConfirm.Text = lblDownloadConfirm.Text.Replace("##Filename##", lblFileName.Text)

                        imgDownload.CommandName = DownloadCommandValue
                        strCommandValue.Append(CType(e.Row.DataItem, DataRowView).Item("OrderNo"))
                        strCommandValue.Append(";")
                        strCommandValue.Append(CType(e.Row.DataItem, DataRowView).Item("OrderLineNo"))
                        strCommandValue.Append(";")
                        strCommandValue.Append(CType(e.Row.DataItem, DataRowView).Item("FileId"))                        
                        imgDownload.CommandArgument = strCommandValue.ToString

                    End With
                End If
            End If

        End Sub

        Private Sub ddlFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFilter.SelectedIndexChanged

            Me.LoadUserInterface()
        End Sub

        Private Sub gvDCDFileList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvDCDFileList.RowCommand
            If e.CommandName = DownloadCommandValue Then

                Dim args() As String = CStr(e.CommandArgument).Split(";")
                Dim errorMessage As String = ""
                '0 order no
                '1 order line
                '2 file id 
                '3 file name
                If args.Length = 3 Then
                    _DCDDownloadParamters = New Personify.ApplicationManager.PersonifyDataObjects.DCDDownloadParameters
               
                    With _DCDDownloadParamters
                        .OrderNumber = args(0)
                        .OrderLine = args(1)
                        .FileId = args(2)
                    End With

                    If Not DownloadDCDFile(_DCDDownloadParamters) AndAlso Not DoesQueryStringParametersExists() Then
                        Dim currentIndex As Integer = gvDCDFileList.PageIndex
                        With _DCDDownloadParamters
                            LoadUserInterface(.OrderNumber, .OrderLine, .FileId)
                        End With

                        gvDCDFileList.PageIndex = currentIndex
                    End If

                End If

            End If
        End Sub

#End Region

#Region "Helper function"


        Private Function DoesQueryStringParametersExists() As Boolean

            If Request(OrderNumberParameter) IsNot Nothing AndAlso Request(OrderLineParameter) IsNot Nothing _
                AndAlso Request(FileIdParameter) IsNot Nothing Then
                Return True
            End If
            Return False

        End Function
        Private Function ProcessAutoDownloadIfValid() As Boolean

            'to do: need more conditions & check if the person has right to access this file
            If DoesQueryStringParametersExists() Then
                _DCDDownloadParamters = New Personify.ApplicationManager.PersonifyDataObjects.DCDDownloadParameters
                With _DCDDownloadParamters
                    .OrderNumber = TIMSSURLEncryption(Request(OrderNumberParameter), True)
                    .OrderLine = Request(OrderLineParameter)
                    .FileId = Request(FileIdParameter)

                    Dim oDCDInfoList As TIMSS.API.OrderInfo.IOrderDetailECDInfoList
                    oDCDInfoList = df_GetOrderDetailDCDInfoList(PortalId, _DCDDownloadParamters.OrderNumber, _DCDDownloadParamters.OrderLine, _DCDDownloadParamters.FileId)
                    If oDCDInfoList IsNot Nothing AndAlso oDCDInfoList.Count > 0 Then
                        LoadUserInterface(oDCDInfoList(0))
                    End If


                    Return True

                End With
            End If

            Return False
        End Function

        Private Sub LoadUserInterface()

            Dim gridTable As DataTable = PopulateDCDFileListFromOrder()
            If gridTable IsNot Nothing AndAlso gridTable.Rows.Count > 0 Then
                gvDCDFileList.DataSource = gridTable
                gvDCDFileList.DataBind()
                gvDCDFileList.Visible = True
            Else
                DisplayMessage(Localization.GetString("DCDProductEmpty", Me.LocalResourceFile))
                gvDCDFileList.Visible = False
            End If
            
        End Sub

        Private Sub LoadUserInterface(ByVal ordernumber As String, ByVal orderline As String, ByVal fileId As String)

            Dim gridTable As DataTable = PopulateDCDFileListFromOrder(ordernumber, orderline, fileId)
            If gridTable IsNot Nothing AndAlso gridTable.Rows.Count > 0 Then
                gvDCDFileList.DataSource = gridTable
                gvDCDFileList.DataBind()
                gvDCDFileList.Visible = True
            Else
                DisplayMessage(Localization.GetString("DCDProductEmpty", Me.LocalResourceFile))
                gvDCDFileList.Visible = False
            End If

        End Sub

        Private Sub LoadUserInterface(ByVal DCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo)

            Dim gridTable As DataTable = PopulateDCDFileListFromOrder(DCDInfo)
            If gridTable IsNot Nothing AndAlso gridTable.Rows.Count > 0 Then
                PanelFilter.Visible = False 'Disable filter
                gvDCDFileList.DataSource = gridTable
                gvDCDFileList.DataBind()
                gvDCDFileList.Visible = True
            Else
                DisplayMessage(Localization.GetString("DCDProductEmpty", Me.LocalResourceFile))
                gvDCDFileList.Visible = False
            End If

        End Sub

      
        Private Sub RedirectBack(ByVal errorMessage As String)

            If Request.UrlReferrer IsNot Nothing Then
                If Request.UrlReferrer.ToString.Contains("&") Then
                    Response.Redirect(Request.UrlReferrer.ToString & "&=" & errorMessage)
                Else
                    Response.Redirect(Request.UrlReferrer.ToString & "?=" & errorMessage)
                End If

            End If
        End Sub

        Private Function PopulateDCDFileListFromOrder() As DataTable

            Dim oDCDOrderDetails As System.Collections.Generic.List(Of TIMSS.API.OrderInfo.IOrderDetail) = Nothing
            Dim gridTable As DataTable = Nothing

            oDCDOrderDetails = df_GetMyOrderDetailsBySubsystem(MasterCustomerId, SubCustomerId, True, SubsystemConst)
            If oDCDOrderDetails IsNot Nothing AndAlso oDCDOrderDetails.Count > 0 Then
                gridTable = CreateDCDTable()
                For Each oDetail As TIMSS.API.OrderInfo.IOrderDetail In oDCDOrderDetails

                    Dim oDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo = Nothing
                    For Each oDCDInfo In oDetail.DCDInfoList
                        If oDCDInfo.DCDFileDetails(0) IsNot Nothing Then
                            Dim isProductValid As Boolean = IsProductFileAvailable(oDCDInfo)

                            If Not LoadAllDCDProductFlag AndAlso Not isProductValid Then
                                Continue For
                            End If

                            Dim row As DataRow = gridTable.NewRow
                            row("Product") = oDetail.Product.ShortName
                            row("Document") = oDCDInfo.DCDFileDetails(0).DocumentTitle
                            If oDCDInfo.DCDFileDetails(0).LimitedDownloadsFlag Then
                                row("Available") = oDCDInfo.DCDFileDetails(0).DownloadsAllowed - oDCDInfo.DownloadCount
                            Else
                                row("Available") = "Available"
                            End If
                            row("Downloaded") = oDCDInfo.DownloadCount
                            row("Expire") = GetExpireFileDate(oDCDInfo)
                            row("OrderNo") = oDCDInfo.OrderNumber
                            row("OrderLineNo") = oDCDInfo.OrderLineNumber
                            row("ProductId") = oDetail.ProductId
                            row("FileId") = oDCDInfo.FileId
                            row("FileName") = oDCDInfo.DCDFileDetails(0).FileName
                            row("isCanDownload") = isProductValid
                            Dim t As String = oDCDInfo.DCDFileDetails(0).FileName
                            gridTable.Rows.Add(row)
                        End If
                    Next
                Next
            End If

            Return gridTable
        End Function

        Private Function PopulateDCDFileListFromOrder(ByVal orderNumber As String, ByVal orderline As String, ByVal fileId As String) As DataTable

            Dim oDCDOrderDetails As System.Collections.Generic.List(Of TIMSS.API.OrderInfo.IOrderDetail) = Nothing
            Dim gridTable As DataTable = Nothing

            oDCDOrderDetails = df_GetMyOrderDetailsBySubsystem(MasterCustomerId, SubCustomerId, True, SubsystemConst)
            If oDCDOrderDetails IsNot Nothing AndAlso oDCDOrderDetails.Count > 0 Then
                gridTable = CreateDCDTable()
                For Each oDetail As TIMSS.API.OrderInfo.IOrderDetail In oDCDOrderDetails

                    Dim oDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo = Nothing
                    For Each oDCDInfo In oDetail.DCDInfoList
                        Dim isProductValid As Boolean = IsProductFileAvailable(oDCDInfo)

                        If Not LoadAllDCDProductFlag AndAlso Not isProductValid AndAlso _
                            Not (oDetail.OrderNumber = orderNumber AndAlso _
                            oDetail.OrderLineNumber.ToString = orderline AndAlso _
                            oDCDInfo.FileId.ToString = fileId) Then
                            Exit For
                        End If

                        Dim row As DataRow = gridTable.NewRow
                        row("Product") = oDetail.Product.ShortName
                        row("Document") = oDCDInfo.DCDFileDetails(0).DocumentTitle
                        If oDCDInfo.DCDFileDetails(0).LimitedDownloadsFlag Then
                            row("Available") = oDCDInfo.DCDFileDetails(0).DownloadsAllowed - oDCDInfo.DownloadCount
                        Else
                            row("Available") = "Available"
                        End If
                        row("Downloaded") = oDCDInfo.DownloadCount
                        row("Expire") = GetExpireFileDate(oDCDInfo)
                        row("OrderNo") = oDCDInfo.OrderNumber
                        row("OrderLineNo") = oDCDInfo.OrderLineNumber
                        row("ProductId") = oDetail.ProductId
                        row("FileId") = oDCDInfo.FileId
                        row("FileName") = oDCDInfo.DCDFileDetails(0).FileName
                        row("isCanDownload") = isProductValid
                        Dim t As String = oDCDInfo.DCDFileDetails(0).FileName
                        gridTable.Rows.Add(row)
                    Next
                Next
            End If

            Return gridTable
        End Function

        Private Function PopulateDCDFileListFromOrder(ByVal SourceDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo) As DataTable

            ''START: Test code         
            'For i As Integer = 0 To 20
            '    Dim row As DataRow = gridTable.NewRow
            '    row("Product") = "My DCD product"
            '    row("Document") = "Top Secret" & (i + 2000).ToString
            '    row("Available") = "92"
            '    row("Downloaded") = i.ToString
            '    row("Expire") = "6/10/2009"
            '    row("OrderNo") = "222"
            '    row("OrderLineNo") = "3"
            '    row("ProductId") = "11"
            '    row("FileId") = "88"
            '    row("FileName") = "test.txt"
            '    row("isCanDownload") = True
            '    gridTable.Rows.Add(row)
            'Next
            ''END: Test code

            Dim gridTable As DataTable = Nothing

            gridTable = CreateDCDTable()

            Dim row As DataRow = gridTable.NewRow
            Dim oDetail As TIMSS.API.OrderInfo.IOrderDetail = SourceDCDInfo.OrderDetail

            row("Product") = oDetail.Product.ShortName
            row("Document") = SourceDCDInfo.DCDFileDetails(0).DocumentTitle
            If SourceDCDInfo.DCDFileDetails(0).LimitedDownloadsFlag Then
                row("Available") = SourceDCDInfo.DCDFileDetails(0).DownloadsAllowed - SourceDCDInfo.DownloadCount
            Else
                row("Available") = "Available"
            End If
            row("Downloaded") = SourceDCDInfo.DownloadCount
            row("Expire") = GetExpireFileDate(SourceDCDInfo)
            row("OrderNo") = SourceDCDInfo.OrderNumber
            row("OrderLineNo") = SourceDCDInfo.OrderLineNumber
            row("ProductId") = oDetail.ProductId
            row("FileId") = SourceDCDInfo.FileId
            row("FileName") = ""
            row("isCanDownload") = IsProductFileAvailable(SourceDCDInfo)
            Dim t As String = SourceDCDInfo.DCDFileDetails(0).FileName
            gridTable.Rows.Add(row)




            Return gridTable
        End Function

        Private Function IsProductFileAvailable(ByVal oDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo) As Boolean
            Dim result As Boolean = True

            'check valid date for DCD product
            'download count
            'product is not web_enable
            With oDCDInfo.DCDFileDetails(0)

                If .LimitedDownloadsFlag Then
                    If (.DownloadsAllowed - oDCDInfo.DownloadCount) <= 0 Then
                        Return False
                    End If
                End If
                If .AllowedTimeToDownload > 0 Then
                    'if greater than 0 - must check if allow time is valid
                    Dim expireDate As String = GetExpireFileDate(oDCDInfo)
                    If expireDate <> "" Then
                        Dim maxDate As Date = CDate(expireDate)
                        If maxDate < Today Then
                            Return False
                        End If
                    End If

                ElseIf Not isDateWithinRange(.ValidFrom, .ValidTo) Then
                    Return False
                End If

                If Not (oDCDInfo.OrderDetail.OrderMaster.BillMasterCustomerId.ToUpper = Me.MasterCustomerId.ToUpper AndAlso _
                    oDCDInfo.OrderDetail.OrderMaster.BillSubCustomerId = Me.SubCustomerId) AndAlso _
                    Not (oDCDInfo.OrderDetail.OrderMaster.ShipMasterCustomerId.ToUpper = Me.MasterCustomerId.ToUpper AndAlso _
                    oDCDInfo.OrderDetail.OrderMaster.ShipSubCustomerId = Me.SubCustomerId) Then
                    'Does not belong to bill or ship to customer ids
                    Return False
                End If

            End With

            Return result
        End Function

        Private Function GetExpireFileDate(ByVal oDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo) As String
            Dim maxDate As Date
            With oDCDInfo.DCDFileDetails(0)
                If .AllowedTimeToDownload > 0 Then
                    Dim orderDate As Date = oDCDInfo.OrderDetail.OrderDate
                    If .TimeToDownloadUnitCodeString.ToUpper = "DAY" Then
                        maxDate = orderDate.AddDays(.AllowedTimeToDownload)
                    ElseIf .TimeToDownloadUnitCodeString.ToUpper = "MONTH" Then
                        maxDate = orderDate.AddMonths(.AllowedTimeToDownload)
                    ElseIf .TimeToDownloadUnitCodeString.ToUpper = "YEAR" Then
                        maxDate = orderDate.AddYears(.AllowedTimeToDownload)
                    Else
                        'default to day if it's not set
                        maxDate = orderDate.AddDays(.AllowedTimeToDownload)
                    End If
                    Return maxDate.ToShortDateString
                End If
            End With

            Return ""

        End Function

        Private Function CreateDCDTable() As DataTable
            Dim gridTable As New DataTable
            gridTable.Columns.Add(New DataColumn("Product", GetType(String)))
            gridTable.Columns.Add(New DataColumn("Document", GetType(String)))
            gridTable.Columns.Add(New DataColumn("Available", GetType(String)))
            gridTable.Columns.Add(New DataColumn("Downloaded", GetType(String)))
            gridTable.Columns.Add(New DataColumn("Expire", GetType(String)))
            gridTable.Columns.Add(New DataColumn("OrderNo", GetType(String)))
            gridTable.Columns.Add(New DataColumn("OrderLineNo", GetType(String)))
            gridTable.Columns.Add(New DataColumn("ProductId", GetType(String)))
            gridTable.Columns.Add(New DataColumn("FileId", GetType(String)))
            gridTable.Columns.Add(New DataColumn("FileName", GetType(String)))
            gridTable.Columns.Add(New DataColumn("isCanDownload", GetType(Boolean)))
            
            Return gridTable
        End Function

        Private Function DownloadDCDFile(ByVal downloadParameters As Personify.ApplicationManager.PersonifyDataObjects.DCDDownloadParameters) As Boolean

            Dim isFileDownloaded As Boolean
            Dim oStartFileTime As Date

            'need to get document title 
            Dim oDCDInfoList As TIMSS.API.OrderInfo.IOrderDetailECDInfoList
            oDCDInfoList = df_GetOrderDetailDCDInfoList(PortalId, downloadParameters.OrderNumber, downloadParameters.OrderLine, downloadParameters.FileId)

            If Not IsProductFileAvailable(oDCDInfoList(0)) Then
                Me.DisplayErrorMessage(Localization.GetString("DCDProductInvalid", Me.LocalResourceFile))
                Return False
            End If

            Dim oDownload As New Personify.ApplicationManager.DCDDownload
            Dim oDownloadLog As New Personify.ApplicationManager.PersonifyDataObjects.DCDDownloadLog

            With oDownload
                .FileName = oDCDInfoList(0).DCDFileDetails(0).FileName
                .FileId = downloadParameters.FileId
                .ECDProductId = oDCDInfoList(0).DCDFileDetails(0).ProductId
                .ImpersonateUser = False
            End With



            oStartFileTime = Date.Now

            isFileDownloaded = oDownload.DownloadFile("")

            If isFileDownloaded Then

                With oDownloadLog
                    .FileSize = oDownload.FileSize
                    .StartTime = oStartFileTime
                    .RemoteIP = oDownload.UserIPAddress
                    .EndTime = Date.Now
                    .OrderNo = downloadParameters.OrderNumber
                    .OrderLine = downloadParameters.OrderLine
                    .FileId = downloadParameters.FileId
                    .FileToSend = downloadParameters.FileName
                    .DocumentTitle = oDCDInfoList(0).DCDFileDetails(0).DocumentTitle
                    .FileToSend = oDCDInfoList(0).DCDFileDetails(0).FileName
                    .MasterCustomerId = MasterCustomerId
                    .SubCustomerId = SubCustomerId
                    .ProductId = oDCDInfoList(0).DCDFileDetails(0).ProductId
                    'to do: more columns to assign
                End With

                If oDCDInfoList IsNot Nothing AndAlso oDCDInfoList.Count > 0 Then
                    oDCDInfoList(0).DownloadCount += 1
                    oDCDInfoList.Save()
                End If
                df_SaveDCDSENDLog(oDownloadLog) 'Create DCD log
                Me.DisplayErrorMessage(Localization.GetString("DCDProductError", Me.LocalResourceFile))
                Response.End()
            Else
                'file is not download
                Me.DisplayErrorMessage(Localization.GetString("DCDProductError", Me.LocalResourceFile))
            End If





        End Function


        'Private Function IsPersonifyUserLoggedIn() As Boolean
        '    If UserInfo.Profile.GetPropertyValue("MasterCustomerId") IsNot Nothing AndAlso UserInfo.Profile.GetPropertyValue("MasterCustomerId") <> String.Empty AndAlso UserInfo.Profile.GetPropertyValue("SubCustomerId") IsNot Nothing AndAlso UserInfo.Profile.GetPropertyValue("SubCustomerId") <> String.Empty Then
        '        _MasterCustomerId = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
        '        _SubCustomerId = UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString
        '        Return True
        '    End If
        'End Function

        Private Sub UpdateFileDownloadCount(ByVal downloadLog As Personify.ApplicationManager.PersonifyDataObjects.DCDDownloadLog)
            'to do: update orderdetail.DCD download count
            'Get DCDinfo
            Dim oDCDInfoList As TIMSS.API.OrderInfo.IOrderDetailECDInfoList
            oDCDInfoList = df_GetOrderDetailDCDInfoList(PortalId, downloadLog.OrderNo, downloadLog.OrderLine, downloadLog.FileId)

            If oDCDInfoList IsNot Nothing AndAlso oDCDInfoList.Count > 0 Then
                oDCDInfoList(0).DownloadCount += 1
                oDCDInfoList.Save()
            End If

        End Sub

        Private Sub BuildResultQueryString(ByRef strParameters As System.Text.StringBuilder, ByVal key As String, ByVal value As String)

            'Do not build the result if value is empty
            If value Is Nothing OrElse value = "" Then
                Exit Sub
            End If

            strParameters.Append("&")
            strParameters.Append(key)
            strParameters.Append("=")
            strParameters.Append(Replace(Server.UrlEncode(value), "", "+"))

        End Sub

        Private Sub DisplayErrorMessage(ByVal message As String)
            Skins.Skin.AddModuleMessage(Me, message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError) '3246-6116989
        End Sub

        Private Sub DisplayMessage(ByVal message As String)
            Skins.Skin.AddModuleMessage(Me, message, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning) '3246-6116989
        End Sub


        Private Function TIMSSURLEncryption(ByVal value As String, Optional ByVal decrypt As Boolean = False) As String
            Dim result As String = ""

            If Not decrypt Then
                result = TIMSS.Common.Encryption.Encrypt(value)
                result = Replace(Server.UrlEncode(result), "", "+")
            Else
                result = TIMSS.Common.Encryption.Decrypt(value)
            End If

            Return result
        End Function

#End Region


#Region "Personify Data"

        Private Function df_GetOrderDetailDCDInfoList(ByVal PortalId As Integer, ByVal OrderNumber As String, ByVal OrderLine As Integer, ByVal FileId As Integer) As TIMSS.API.OrderInfo.IOrderDetailECDInfoList

            Dim oDCDInfoList As TIMSS.API.OrderInfo.IOrderDetailECDInfoList
            oDCDInfoList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetailECDInfoList")
            oDCDInfoList.Fill(OrderNumber, OrderLine, FileId)

            Return oDCDInfoList

        End Function

        Private Function df_GetMyOrderDetailsBySubsystem(ByVal MasterCustomerId As String, ByVal SubCustomerID As Integer, ByVal IsLineActiveOnly As Boolean, ByVal Subsystem As String) As List(Of TIMSS.API.OrderInfo.IOrderDetail)

            Dim oArrayOrderDetails As List(Of TIMSS.API.OrderInfo.IOrderDetail) = Nothing

            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters

            oOrderMasters = df_GetMyOrderMasters(MasterCustomerId, SubCustomerID)

            If oOrderMasters IsNot Nothing AndAlso oOrderMasters.Count > 0 Then
                oArrayOrderDetails = New List(Of TIMSS.API.OrderInfo.IOrderDetail)

                For Each oOrderMaster As TIMSS.API.OrderInfo.IOrderMaster In oOrderMasters
                    For Each oDetail As TIMSS.API.OrderInfo.IOrderDetail In oOrderMaster.Details
                        Dim canBeAdded As Boolean = False
                        If oDetail.Subsystem = Subsystem Then
                            If IsLineActiveOnly Then
                                If oDetail.LineStatusCodeString = "A" Then
                                    canBeAdded = True
                                End If
                            Else
                                canBeAdded = True
                            End If
                        End If
                        If canBeAdded Then
                            oArrayOrderDetails.Add(oDetail)
                        End If
                    Next
                Next
            End If

            Return oArrayOrderDetails

        End Function


        Private Function df_GetMyOrderMasters(ByVal MasterCustomerId As String, ByVal SubcustomerId As Integer) As TIMSS.API.OrderInfo.IOrderMasters

            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters

            oOrderMasters = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderMasters")

            'if both, first of all we get the shipto orders
            'oOrderMasters.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            'oOrderMasters.Filter.Add("ShipSubCustomerId", SubCustomerId)
            oOrderMasters.Filter.Add(New TIMSS.API.Core.FilterItem("((Ship_Master_Customer_Id =  '" + MasterCustomerId.ToString + "' ) and (Ship_Sub_Customer_Id = " + SubcustomerId.ToString + " )) or ((Bill_Master_Customer_Id =  '" + MasterCustomerId.ToString + "' ) and (Bill_Sub_Customer_Id = " + SubcustomerId.ToString + " ))"))


            oOrderMasters.Fill()
            Return oOrderMasters

        End Function

        Private Function df_SaveDCDSENDLog(ByVal oDCDDownloadLog As ApplicationManager.PersonifyDataObjects.DCDDownloadLog) As Boolean

            Dim oDCDSendLogList As TIMSS.API.DigitalContentDeliveryInfo.IDigitalContentDeliverySendLogs
            Dim oDCDSendLog As TIMSS.API.DigitalContentDeliveryInfo.IDigitalContentDeliverySendLog
            oDCDSendLogList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.DigitalContentDeliveryInfo, "DigitalContentDeliverySendLogs")

            oDCDSendLog = oDCDSendLogList.CreateNew()
            With oDCDDownloadLog
                oDCDSendLog.FileId = .FileId
                oDCDSendLog.DocumentTitle = .DocumentTitle
                oDCDSendLog.FileToSend = .FileToSend
                oDCDSendLog.ProductId = .ProductId
                oDCDSendLog.StartTime = .StartTime
                oDCDSendLog.EndTime = .EndTime
                oDCDSendLog.FileSize = .FileSize
                oDCDSendLog.BytesSent = .FileSize 'need to change
                oDCDSendLog.Status = "Completed" 'need to change
                oDCDSendLog.StatusDate = Date.Now
                oDCDSendLog.ProductId = .ProductId
                oDCDSendLog.RemoteIp = .RemoteIP
                oDCDSendLog.OrderNumber = .OrderNo
                oDCDSendLog.MasterCustomerId = .MasterCustomerId
                oDCDSendLog.SubCustomerId = .SubCustomerId
                oDCDSendLog.FileToSend = .FileToSend
            End With
            oDCDSendLogList.Add(oDCDSendLog)
            oDCDSendLogList.Save()

            If oDCDSendLogList.ValidationIssues.ErrorCount = 0 Then
                Return True
            End If

            Return False
        End Function


#End Region


     

     
   
    End Class





End Namespace
