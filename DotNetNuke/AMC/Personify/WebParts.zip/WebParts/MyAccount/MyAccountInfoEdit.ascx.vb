Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.MyAccountInfo
Imports System.IO

Namespace Personify.DNN.Modules.MyAccountInfo

    Public MustInherit Class MyAccountInfoEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings


#Region "Controls"
        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl
        Protected WithEvents display_Login As System.Web.UI.WebControls.CheckBox
        Protected WithEvents display_Type As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents select_Template As System.Web.UI.WebControls.DropDownList
        Protected WithEvents update As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents cancel As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents selectTemplate As System.Web.UI.HtmlControls.HtmlGenericControl
        'Protected WithEvents selectTemplate1 As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents chkMemberDirectoryDetail As CheckBox
        Protected WithEvents pnlEmailURL As Panel

        Protected WithEvents pnlEnableEmailURL As Panel
        Protected WithEvents chkEnableEmail As CheckBox

        Protected WithEvents urlEmailPage As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents chkEnableVcard As CheckBox
        Protected WithEvents PanelVcardURL As Panel
        Protected WithEvents UrlVcardPage As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents chkDisplaySubCustomerID As CheckBox

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Private Sub SetTypeToDisplay()
            Try

                display_Type.Items.Add("Day")
                display_Type.Items.Add("Week")
                display_Type.Items.Add("Month")

            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            update.InnerHtml = Localization.GetString("update", LocalResourceFile)
            cancel.InnerHtml = Localization.GetString("cancel", LocalResourceFile)
            'selectTemplate.InnerHtml = Localization.GetString("selectTemplate", LocalResourceFile)
            Try
                Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
                If Not Page.IsPostBack Then

                    If Not select_Template.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            If li.Text = "template.xsl" Then
                                li.Selected = True
                            End If
                            select_Template.Items.Add(li)
                        Next
                        select_Template.SelectedIndex = select_Template.Items.IndexOf(select_Template.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                    End If
                    SetTypeToDisplay()
                    LoadSettings()

                    If Not Null.IsNull(itemId) Then
                    Else ' security violation attempt to access item not related to this Module
                        Response.Redirect(NavigateURL(), True)
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub LoadSettings()
            Try
                display_Login.Checked = CType(Settings("displayLogin"), Boolean)
                Dim i As Integer
                For i = 0 To 2
                    If display_Type.Items(i).ToString = CType(Settings("displayType"), String) Then
                        display_Type.Items(i).Selected = True
                    End If
                Next i

                chkMemberDirectoryDetail.Checked = CType(Settings("DisplayMemberDirectory"), Boolean)

                If Settings("EmailURLValue") = String.Empty Then
                    chkEnableEmail.Checked = False
                Else
                    chkEnableEmail.Checked = CType(Settings("EmailURLValue"), Boolean)
                End If

                '3246-5772733: Implement Send Email Feature from My Account Module
                If chkMemberDirectoryDetail.Checked Then
                    pnlEnableEmailURL.Visible = True
                    If Me.chkEnableEmail.Checked Then
                        urlEmailPage.Url = CStr(Settings("EmailURLValue"))
                        pnlEmailURL.Visible = True
                    Else
                        pnlEmailURL.Visible = False
                    End If
                Else
                    pnlEnableEmailURL.Visible = False
                End If

                chkEnableVcard.Checked = CType(Settings("AllowVcardDownload"), Boolean)

                If Settings("ShowVcardURL") IsNot Nothing Then
                    If CStr(Settings("ShowVcardURL")) = "Y" Then
                        chkEnableVcard.Checked = True
                        PanelVcardURL.Visible = True
                        If Settings("VcardURLValue") IsNot Nothing Then
                            If CStr(Settings("VcardURLValue")) <> String.Empty Then
                                UrlVcardPage.Url = CStr(Settings("VcardURLValue"))
                            End If
                        End If
                    Else
                        chkEnableVcard.Checked = False
                        PanelVcardURL.Visible = False
                    End If
                Else
                    chkEnableVcard.Checked = False
                    PanelVcardURL.Visible = False
                End If

                'Enhancement Show/Hide Sub CustomerID
                If Settings("ShowSubCustomerID") IsNot Nothing Then
                    If CStr(Settings("ShowSubCustomerID")) = "TRUE" Then
                        chkDisplaySubCustomerID.Checked = True
                    Else
                        chkDisplaySubCustomerID.Checked = False
                    End If
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub UpdateSettings()

            UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

            UpdateModuleSetting("Layout", select_Template.SelectedValue)
            UpdateModuleSetting("displayLogin", CType(display_Login.Checked, String))
            UpdateModuleSetting("displayType", CType(display_Type.SelectedValue, String))

            UpdateModuleSetting("DisplayMemberDirectory", CType(chkMemberDirectoryDetail.Checked, String))

            UpdateModuleSetting("AllowVcardDownload", CType(chkEnableVcard.Checked, String))

            UpdateModuleSetting("ShowVcardURL", CStr(IIf(Me.chkEnableVcard.Checked, "Y", "N")))
            If chkEnableVcard.Checked Then
                UpdateModuleSetting("VcardURLValue", UrlVcardPage.Url)
            End If

            '3246-5772733: Implement Send Email Feature from My Account Module
            If chkMemberDirectoryDetail.Checked Then
                UpdateModuleSetting("UseEmailURLValue", CType(Me.chkEnableEmail.Checked, String))
                If chkEnableEmail.Checked Then
                    UpdateModuleSetting("EmailURLValue", urlEmailPage.Url)
                End If
            Else
                UpdateModuleSetting("UseEmailURLValue", "FALSE")
            End If

            'Enhancement Show/Hide Sub CustomerID
            If chkDisplaySubCustomerID.Checked Then
                UpdateModuleSetting("ShowSubCustomerID", "TRUE")
            Else
                UpdateModuleSetting("ShowSubCustomerID", "FALSE")
            End If

        End Sub

        Public Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                If Page.IsValid = True Then
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Else
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Protected Sub display_Login_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles display_Login.CheckedChanged
            Return
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
            display_Type.Enabled = display_Login.Checked
        End Sub


#End Region


        Private Sub chkEnableVcard_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkEnableVcard.CheckedChanged      
            PanelVcardURL.Visible = chkEnableVcard.Checked
        End Sub
        '3246-5772733: Implement Send Email Feature from My Account Module
        Private Sub chkMemberDirectoryDetail_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkMemberDirectoryDetail.CheckedChanged
            
            pnlEnableEmailURL.Visible = chkMemberDirectoryDetail.Checked
        End Sub

        Private Sub chkEnableEmail_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkEnableEmail.CheckedChanged

            pnlEmailURL.Visible = chkEnableEmail.Checked

        End Sub
    End Class

End Namespace
