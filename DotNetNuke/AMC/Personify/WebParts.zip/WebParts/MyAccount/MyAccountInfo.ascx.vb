Option Strict Off

Imports System
Imports System.IO
Imports System.Web
Imports Personify
Imports InspectorIT.WebControls2.VirtualEarth
'Imports Personify.ApplicationManager.Commons

Namespace Personify.DNN.Modules.MyAccountInfo
    <CLSCompliant(False)> _
    Public MustInherit Class MyAccountInfo

        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"
        'Protected WithEvents lblOrganizationUnitID As System.Web.UI.WebControls.Label
        'Protected WithEvents lblName As System.Web.UI.WebControls.Label
        'Protected WithEvents lblFormattedAddrDetail As System.Web.UI.WebControls.Label
        'Protected WithEvents lblFormattedAddrExternal As System.Web.UI.WebControls.Label
        'Protected WithEvents lblPhoneLocation As System.Web.UI.WebControls.Label
        'Protected WithEvents lblPhoneNumber As System.Web.UI.WebControls.Label
        'Protected WithEvents lblFaxLocation As System.Web.UI.WebControls.Label
        'Protected WithEvents lblFaxNumber As System.Web.UI.WebControls.Label
        'Protected WithEvents lblEmailLocation As System.Web.UI.WebControls.Label
        'Protected WithEvents lblEmailAddress As System.Web.UI.WebControls.Label
        'Protected WithEvents lblUrl As System.Web.UI.WebControls.Label
        'Protected WithEvents lblChangeOn As System.Web.UI.WebControls.Label
        'Protected WithEvents lblCustomerId As System.Web.UI.WebControls.Label
        Protected WithEvents ChangeOnVisible As System.String
        Protected WithEvents VirtualEarthMap As InspectorIT.WebControls2.VirtualEarth.VEMap


        'Protected WithEvents hlReturn As HyperLink
        Protected AccountTemplate As Personify.WebControls.XslTemplate

#End Region

#Region "Private Variables"
        Private strMCID As String
        Private strSCID As String
        Private _oAddress As DataTable
        Public Property oAddress() As DataTable
            Get
                Return _oAddress
            End Get
            Set(ByVal value As DataTable)
                _oAddress = value
            End Set
        End Property

#End Region

#Region "Event Handlers"

        Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Error

            If 1 = 1 Then

            End If
        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim lblPhoneNumber As New Label
            Dim lblFaxNumber As New Label
            Dim lblEmailAddress As New Label
            Dim lblChangeOn As New Label
            Dim hlReturn As New HyperLink
            Dim divButton As New Panel
            Dim role As String

            Dim boolUserLoggedIn As Boolean = False
            role = Me.GetUserRole(UserInfo)


            Try

                Dim visibles As Boolean = False
                ChangeOnVisible = "False"
                'Dim affInfo As Personify.WebUtility.AffiliateManagement.AffiliateInfo
                ' We will need the User Profile properties for MasterCustomerId and SubCustomerId in order
                ' to retrieve the data
                'If Request.QueryString("mcid") IsNot Nothing AndAlso Request.QueryString("scid") IsNot Nothing AndAlso Request.QueryString("where") IsNot Nothing Then
                If Request.QueryString("mcid") IsNot Nothing AndAlso Request.QueryString("scid") IsNot Nothing Then
                    'Updated: changed to encrypted paramter
                    strMCID = TIMSS.Common.Encryption.Decrypt(Request.QueryString("mcid"))
                    strSCID = TIMSS.Common.Encryption.Decrypt(Request.QueryString("scid"))
                    boolUserLoggedIn = True
                    visibles = True
                Else
                    strMCID = MasterCustomerId
                    strSCID = SubCustomerId.ToString
                    boolUserLoggedIn = Me.IsPersonifyWebUserLoggedIn
                End If



                'If strMCID <> String.Empty AndAlso strSCID <> String.Empty Then
                If boolUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin" Then

                    ChangeOnVisible = "True"

                    oAddress = (df_GetCustomerAccountInfo(strMCID, CInt(strSCID)))


                    Dim MyAccountObject As AccountObject = New AccountObject
                    Try
                        'AMR - this maynot be needed, it depends on EDit Settings

                        MyAccountObject.ChangeOn = SetLastLogin()
                    Catch ex As Exception
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("NoUserLoggedIn.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End Try
                    MyAccountObject.ChangeVisible = ChangeOnVisible
                    MyAccountObject.email = CStr(IIf(oAddress.Rows(0).Item("PrimaryEmailAddress") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryEmailAddress")))
                    MyAccountObject.fax = CStr(IIf(oAddress.Rows(0).Item("PrimaryFax") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryFax")))
                    MyAccountObject.Phone = CStr(IIf(oAddress.Rows(0).Item("PrimaryPhone") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryPhone")))
                    Dim templatefile As String = ""
                    If Settings("Layout") Is Nothing Then
                        templatefile = ModulePath + "Templates\MyAccountTemplate.xsl"
                    Else
                        templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
                    End If

                    If File.Exists(Server.MapPath(templatefile)) = False Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    Else

                        AccountTemplate.XSLfile = Server.MapPath(templatefile)
                        ' tableTCMSXslTemplate.AddObject("", oMyOrdersFiltered)
                        AccountTemplate.AddObject("", MyAccountObject)
                        AccountTemplate.Display()
                        lblPhoneNumber = CType(Me.FindControl("lblPhoneNumber".ToString), Label)
                        lblFaxNumber = CType(Me.FindControl("lblFaxNumber".ToString), Label)
                        lblEmailAddress = CType(Me.FindControl("lblEmailAddress".ToString), Label)
                        lblChangeOn = CType(Me.FindControl("lblChangeOn".ToString), Label)
                        hlReturn = CType(Me.FindControl("hlReturn".ToString), HyperLink)
                        divButton = CType(Me.FindControl("divButton".ToString), Panel)

                        If visibles Then
                            hlReturn.Visible = True
                            If divButton IsNot Nothing Then divButton.Visible = True
                            If Request.QueryString("where") IsNot Nothing Then
                                hlReturn.NavigateUrl = NavigateURL(CType(Request.QueryString("where"), Integer), "", FormatSearchInfo())
                            End If

                            lblChangeOn.Visible = False

                        End If
                        LoadMyAccountInfo(strMCID, CInt(strSCID))
                        '3246-5774803
                        LoadImages()
                        'END 3246-5774803
                    End If
                    'If Convert.ToString(Settings("displayLogin")) = "True" Or Settings("displayLogin") Is Nothing Then 
                    'chuang : took second condition out, because this logic doesn't make sense if it shows how many days since last login even if the setting of it doesn't exist.
                    'Especially when the default value in edit page is not checked.  Which kind of mean default we don't show it.
                    If Convert.ToString(Settings("displayLogin")) = "True" Then
                        lblChangeOn.Visible = True
                        If Settings("displayType") Is Nothing Then
                            lblChangeOn.Visible = False
                        Else
                            lblChangeOn.Text = SetLastLogin()
                        End If
                    Else
                        lblChangeOn.Visible = False
                    End If

                Else
                    DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        'added by chuang on 10/27/2006
        'setup back button
        Private Function FormatSearchInfo() As String
            Dim SearchInfo As String = ""
            Dim First As Boolean = True

            SearchInfo = SearchInfo + FormatSearchInfoHelper("FirstName", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("LastName", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("City", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("Zip", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("Country", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("State", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("Distance", First)
            SearchInfo = SearchInfo + FormatSearchInfoHelper("PostalCode", First)
            If Not First Then
                SearchInfo = SearchInfo + "&IfSearch=T"
            End If

            Return SearchInfo
        End Function

        'added by chuang on 10/27/2006
        'setup back button
        Private Function FormatSearchInfoHelper(ByVal ID As String, ByRef First As Boolean) As String
            Dim value As String
            If Request.QueryString(ID) IsNot Nothing Then
                value = Request.QueryString(ID).ToString
                If Not First Then
                    If ID = "State" Then
                        ID = "St"
                    End If
                    Return "&" & ID & "=" & value
                Else
                    If ID = "State" Then
                        ID = "St"
                    End If
                    First = False
                    Return ID & "=" & value
                End If
            Else
                Return ""
            End If
        End Function

        Private Sub LoadMyAccountInfo(ByVal pMCID As String, ByVal pSCID As Integer)
            Dim lblName As New Label
            Dim lblOrganizationUnitID As New Label
            Dim lblCustomerId As New Label
            Dim lblFormattedAddrDetail As New Label
            Dim lblFormattedAddrExternal As New Label
            Dim lblPhoneLocation As New Label
            Dim lblPhoneNumber As New Label
            Dim lblFaxLocation As New Label
            Dim lblFaxNumber As New Label
            Dim lblEmailLocation As New Label
            Dim lblEmailAddress As New Label
            Dim lnkEmailAddress As New HyperLink
            Dim lblUrl As New Label
            Dim lblChangeOn As New Label
            Dim lblwwwText As New Label
            Dim lblPhoneText As New Label
            Dim lblFaxText As New Label
            Dim lblEmailText As New Label
            Dim PanelCustomerInfo As Panel
            Dim lnkVard As HyperLink
            Dim PanelVcardDownload As Panel


            lblName = CType(Me.FindControl("lblName".ToString), Label)
            lblOrganizationUnitID = CType(Me.FindControl("lblOrganizationUnitID".ToString), Label)
            lblCustomerId = CType(Me.FindControl("lblCustomerId".ToString), Label)
            lblFormattedAddrDetail = CType(Me.FindControl("lblFormattedAddrDetail".ToString), Label)
            lblFormattedAddrExternal = CType(Me.FindControl("lblFormattedAddrExternal".ToString), Label)
            lblPhoneLocation = CType(Me.FindControl("lblPhoneLocation".ToString), Label)
            lblPhoneNumber = CType(Me.FindControl("lblPhoneNumber".ToString), Label)
            lblFaxLocation = CType(Me.FindControl("lblFaxLocation".ToString), Label)
            lblFaxNumber = CType(Me.FindControl("lblFaxNumber".ToString), Label)
            lblEmailLocation = CType(Me.FindControl("lblEmailLocation".ToString), Label)
            lblEmailAddress = CType(Me.FindControl("lblEmailAddress".ToString), Label)
            lnkEmailAddress = CType(Me.FindControl("lnkEmailAddress".ToString), HyperLink)
            lblUrl = CType(Me.FindControl("lblUrl".ToString), Label)
            lblChangeOn = CType(Me.FindControl("lblChangeOn".ToString), Label)
            lblwwwText = CType(Me.FindControl("lblwwwText".ToString), Label)
            lblPhoneText = CType(Me.FindControl("lblPhoneText".ToString), Label)
            lblFaxText = CType(Me.FindControl("lblFaxText".ToString), Label)
            lblEmailText = CType(Me.FindControl("lblEmailText".ToString), Label)
            PanelCustomerInfo = CType(Me.FindControl("PanelCustomerInfo".ToString), Panel)
            lnkVard = CType(Me.FindControl("lnkVard".ToString), HyperLink)
            PanelVcardDownload = CType(Me.FindControl("PanelVcardDownload".ToString), Panel)
            Try
                Dim GeoAddress As New Text.StringBuilder
                Dim PinAddress As New Text.StringBuilder

                'If MBR directory detail - disable customer id info
                Dim HideCustomerInfo As Boolean = CBool(Settings("DisplayMemberDirectory"))
                PanelCustomerInfo.Visible = Not HideCustomerInfo

                'Workaround - should change customer_formatted_vw, instead of query the data again
                'Purpose: Publish flag check for primary address
                Dim publishAddressFlag As Boolean = False
                If HideCustomerInfo Then
                    Dim tmpPrimaryAddress As TIMSS.API.CustomerInfo.ICustomerAddressViewList
                    tmpPrimaryAddress = df_GetPrimaryAddress(pMCID, CStr(pSCID))
                    'START 3246-6378495
                    If tmpPrimaryAddress IsNot Nothing AndAlso tmpPrimaryAddress.Count > 0 Then
                        publishAddressFlag = tmpPrimaryAddress(0).DirectoryFlag
                    End If
                    'END 3246-6378495
                    tmpPrimaryAddress = Nothing
                End If
                'end workaround

                If oAddress.Rows.Count > 0 Then
                    'With oAddress(0)

                    lblOrganizationUnitID.Text = OrganizationId

                    '3246-6473941 - Add Option to Hide SubCustomer Id
                    If Settings("ShowSubCustomerID") IsNot Nothing Then
                        If Settings("ShowSubCustomerID").ToString = "TRUE" Then
                            lblCustomerId.Text = String.Concat(oAddress.Rows(0).Item("MasterCustomerId"), "-", oAddress.Rows(0).Item("SubCustomerId"))
                        Else
                            lblCustomerId.Text = String.Concat(oAddress.Rows(0).Item("MasterCustomerId"))
                        End If
                    End If
                    '3246-6473941 - Add Option to Hide SubCustomer Id

                    lblName.Text = oAddress.Rows(0).Item("LabelName")
                    lblFormattedAddrDetail.Text = oAddress.Rows(0).Item("FormattedDetaildirexternal")
                    lblFormattedAddrDetail.Text = lblFormattedAddrDetail.Text.Replace(vbCrLf, "<br>")

                    If Not HideCustomerInfo OrElse (HideCustomerInfo AndAlso publishAddressFlag = True) Then
                        lblFormattedAddrExternal.Text = oAddress.Rows(0).Item("FormattedAddressexternal")
                        lblFormattedAddrExternal.Text = lblFormattedAddrExternal.Text.Replace(vbCrLf, "<br>")
                    End If

                    If oAddress.Rows(0).Item("PrimaryPhone") Is System.DBNull.Value OrElse oAddress.Rows(0).Item("PrimaryPhone") Is "" OrElse _
                        (HideCustomerInfo AndAlso oAddress.Rows(0).Item("PublishPrimaryPhoneFlag") = "N") Then

                        If lblPhoneLocation IsNot Nothing Then lblPhoneLocation.Visible = False
                        If lblPhoneText IsNot Nothing Then lblPhoneText.Visible = False
                        If lblPhoneNumber IsNot Nothing Then lblPhoneNumber.Visible = False
                    Else
                        If lblPhoneLocation IsNot Nothing Then lblPhoneLocation.Text = oAddress.Rows(0).Item("PrimaryPhoneLocationCode")
                        If lblPhoneNumber IsNot Nothing Then lblPhoneNumber.Text = CStr(IIf(oAddress.Rows(0).Item("PrimaryPhone") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryPhone")))
                    End If


                    If oAddress.Rows(0).Item("PrimaryFax") Is System.DBNull.Value OrElse oAddress.Rows(0).Item("PrimaryFax") Is "" OrElse _
                        (HideCustomerInfo AndAlso oAddress.Rows(0).Item("PublishPrimaryFaxFlag") = "N") Then

                        If lblFaxLocation IsNot Nothing Then lblFaxLocation.Visible = False
                        If lblFaxText IsNot Nothing Then lblFaxText.Visible = False
                        If lblFaxNumber IsNot Nothing Then lblFaxNumber.Visible = False
                    Else
                        If lblFaxLocation IsNot Nothing Then lblFaxLocation.Text = oAddress.Rows(0).Item("PrimaryFaxLocationCode")
                        If lblFaxNumber IsNot Nothing Then lblFaxNumber.Text = CStr(IIf(oAddress.Rows(0).Item("PrimaryFax") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryFax")))
                    End If


                    If oAddress.Rows(0).Item("PrimaryEmailAddress") Is System.DBNull.Value OrElse oAddress.Rows(0).Item("PrimaryEmailAddress") Is "" OrElse _
                        (oAddress.Rows(0).Item("PublishPrimaryEmailFlag") = "N") Then

                        If lblEmailLocation IsNot Nothing Then lblEmailLocation.Visible = False
                        If lblEmailText IsNot Nothing Then lblEmailText.Visible = False
                        If lblEmailAddress IsNot Nothing Then lblEmailAddress.Visible = False
                    Else
                        If HideCustomerInfo Then
                            '3246-5772733: Implement Send Email Feature from My Account Module
                            If lblEmailAddress IsNot Nothing Then lblEmailAddress.Visible = False
                            If Settings("UseEmailURLValue") IsNot Nothing AndAlso CStr(Settings("UseEmailURLValue")).ToUpper = "TRUE" Then
                                lnkEmailAddress.NavigateUrl = NavigateURL(CInt(Settings("EmailURLValue")), "", "EmailAddresses=" & oAddress.Rows(0).Item("PrimaryEmailAddress"))
                            Else
                                lnkEmailAddress.NavigateUrl = "mailto:" & oAddress.Rows(0).Item("PrimaryEmailAddress")
                            End If
                            lnkEmailAddress.Text = CStr(IIf(oAddress.Rows(0).Item("PrimaryEmailAddress") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryEmailAddress")))
                        Else
                            If lblEmailLocation IsNot Nothing Then lblEmailLocation.Text = oAddress.Rows(0).Item("PrimaryEmailLocationCode")
                            If lblEmailAddress IsNot Nothing Then lblEmailAddress.Text = CStr(IIf(oAddress.Rows(0).Item("PrimaryEmailAddress") Is System.DBNull.Value, String.Empty, oAddress.Rows(0).Item("PrimaryEmailAddress")))
                        End If
                    End If

                    'to do: API missing publishing property for URL 
                    If oAddress.Rows(0).Item("PrimaryUrl") Is System.DBNull.Value OrElse oAddress.Rows(0).Item("PrimaryUrl") Is "" Then
                        If lblwwwText IsNot Nothing Then lblwwwText.Visible = False
                        If lblUrl IsNot Nothing Then lblUrl.Visible = False
                    Else
                        'START 3246-6147808
                        If lblUrl IsNot Nothing Then
                            If oAddress.Rows(0).Item("PrimaryUrl").ToString.StartsWith("http") Then
                                lblUrl.Text = CStr(IIf(oAddress.Rows(0).Item("PrimaryUrl") Is "", "n/a", "<a href=" & oAddress.Rows(0).Item("PrimaryUrl") & ">" & oAddress.Rows(0).Item("PrimaryUrl") & "</a>"))
                            Else
                                lblUrl.Text = CStr(IIf(oAddress.Rows(0).Item("PrimaryUrl") Is "", "n/a", "<a href=""http://" & oAddress.Rows(0).Item("PrimaryUrl") & """>" & oAddress.Rows(0).Item("PrimaryUrl") & "</a>"))
                            End If
                        End If
                        'END 3246-6147808
                    End If

                    Dim LastLogin As Date '= df_GetLastLogin(UserInfo.Username)
                    If Not LastLogin = Nothing Then
                        If lblChangeOn IsNot Nothing Then lblChangeOn.Text = SetLastLogin()
                    Else
                        If lblChangeOn IsNot Nothing Then lblChangeOn.Text = SetLastLogin()
                    End If

                    'START 3246-7620233  
                    ' I need to construct the address structure in this way so
                    ' that the GeoCoder web services can fetch the latitude and longitude
                    GeoAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("Address1")) <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("Address1")) & ",", ""))
                    GeoAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("City")) <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("City")) & ",", ""))
                    GeoAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("State")) <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("State")) & ",", ""))
                    GeoAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("PostalCode")) <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("PostalCode")) & "", ""))

                    ' I have to format my own address instead of using FormattedAddress
                    ' This is because the is junk in the FormattedAddress that brakes the 
                    ' Javascript for the Virtual Earth Map functionality
                    PinAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("Address1")).ToString <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("Address1")) & "<br>", ""))
                    PinAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("Address2")).ToString <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("Address2")) & "<br>", ""))
                    PinAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("City")).ToString <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("City")) & ", ", ""))
                    PinAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("State")).ToString <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("State")) & ", ", ""))
                    PinAddress.Append(IIf(GetAddressFields(oAddress.Rows(0).Item("PostalCode")).ToString <> String.Empty, GetAddressFields(oAddress.Rows(0).Item("PostalCode")) & "", ""))
                    'END 3246-7620233  

                    VirtualEarthMap.VEMapJSInclude = "http://dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=6.2"
                    If CBool(Settings("Personify_My_Account_ShowMap")) Then
                        GetCoordsFromAddress(GeoAddress.ToString)

                        ' If there is no latitude or longitude then there
                        ' is not need to load the map
                        If lat <> 0 AndAlso lon <> 0 Then
                            With VirtualEarthMap                                
                                .Pushpins.Add(New VEPushpin("_" & ModuleId.ToString, New VELatLong(lat, lon), Nothing, oAddress.Rows(0).Item("LabelName").ToString, PinAddress.ToString))

                                .Visible = True
                                .Longitude = lon
                                .Latitude = lat
                                .Zoom = 15
                            End With
                        End If
                    End If


                    '"&MCID=000000003123&SCID=0"
                    'Vcard Download
                    If Settings("ShowVcardURL") IsNot Nothing AndAlso CStr(Settings("ShowVcardURL")) = "Y" Then
                        PanelVcardDownload.Visible = True
                        Dim encryptedMasterId As String = TIMSS.Common.Encryption.Encrypt(Me.strMCID)
                        Dim encryptedSubId As String = TIMSS.Common.Encryption.Encrypt(Me.strSCID)

                        encryptedMasterId = Replace(Server.UrlEncode(encryptedMasterId), "", "+")
                        encryptedSubId = Replace(Server.UrlEncode(encryptedSubId), "", "+")

                        Dim urlArguments As String = "&MCID=" & encryptedMasterId & "&SCID=" & encryptedSubId
                        Dim vCardNavigateUrl As String = NavigateURL(CType(Settings("VcardURLValue"), Integer), "", urlArguments)
                        Dim vCardIcon As String = ResolveUrl(GetVCARDURL())
                        'lnkVard.Text = "<a id=""" & Me.UniqueID & """ href=""" & vCardNavigateUrl & """><img src=""" & vCardIcon & """ width=""16"" height=""16""></a>"
                        lnkVard.ImageUrl = ResolveUrl(GetVCARDURL())
                        lnkVard.NavigateUrl = vCardNavigateUrl
                    Else
                        PanelVcardDownload.Visible = False
                    End If

                    PinAddress = Nothing
                    GeoAddress = Nothing
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MemberNotFound", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        'START 3246-7620233  
        Private Function GetAddressFields(ByVal field As Object) As String
            If IsDBNull(field) Then
                Return ""
            Else
                Return field
            End If
        End Function
        'END 3246-7620233  

        Private LastLogin As Date
        Private Function SetLastLogin() As String
            Dim lblChangeOn As New Label
            lblChangeOn = CType(Me.FindControl("lblChangeOn".ToString), Label)

            If Settings("displayLogin") = "False" Then
                Return ""
            End If

            If LastLogin = Date.MinValue Then
                LastLogin = df_GetLastLogin(UserInfo.Username)
            End If



            If Not LastLogin = Nothing AndAlso LastLogin.ToString <> "12:00:00 AM" AndAlso Settings("displayType") IsNot Nothing Then
                Select Case (CType(Settings("displayType"), String)).ToUpper
                    Case "DAY"
                        Return String.Format(Localization.GetString("lblChangeOnDay", LocalResourceFile), CStr(DateDiff(DateInterval.Day, LastLogin, DateTime.Now())))
                    Case "WEEK"
                        Return String.Format(Localization.GetString("lblChangeOnWeek", LocalResourceFile), CStr(DateDiff(DateInterval.Weekday, LastLogin, DateTime.Now())))
                    Case "MONTH"
                        Return String.Format(Localization.GetString("lblChangeOnMonth", LocalResourceFile), CStr(DateDiff(DateInterval.Month, LastLogin, DateTime.Now())))
                End Select
            Else
                Return String.Format(Localization.GetString("lblChangeOn", LocalResourceFile), "?")
            End If
            Return Nothing
        End Function

        Private lat As Double = 0
        Private lon As Double = 0

        Private Sub GetCoordsFromAddress(ByVal Address As String)
            Try
                Dim geoCodeService As GeoCoder.GeoCode_Service
                Dim geoAddressResult As GeoCoder.GeocoderAddressResult
                Dim strAddress As String
                strAddress = Address
                If strAddress <> String.Empty OrElse strAddress.Length <> 0 Then
                    geoCodeService = New GeoCoder.GeoCode_Service
                    geoAddressResult = geoCodeService.geocode_address(strAddress)(0)
                    lat = geoAddressResult.lat
                    lon = geoAddressResult.long
                    geoCodeService = Nothing
                End If

            Catch exc As Exception
                'ProcessModuleLoadException(Me, exc)
                'There must have been an error getting the coordinates
                'We are going to skip writing the error back to the client
            End Try
        End Sub

        '3246-5774803
        Private Sub LoadImages()
            If FindControl("imgUser1") IsNot Nothing Then

                Dim imgUser1 As System.Web.UI.WebControls.Image = CType(FindControl("imgUser1"), System.Web.UI.WebControls.Image)
                imgUser1.ImageUrl = "~/" & SiteImagesFolder & "/user1.gif"
            End If
        End Sub

        Private Function GetVCARDURL() As String
            Return "~/" & SiteImagesFolder & "/icon_vcard.gif"
        End Function
        'end 3246-5774803
#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Personify Data"

        Private Function df_GetLastLogin(ByVal Username As String) As Date

            Dim WebUsers As TIMSS.API.WebInfo.IWebUsers
            If Username <> String.Empty AndAlso Username <> String.Empty Then

                WebUsers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

                WebUsers.Filter.Add("UserId", TIMSS.Enumerations.QueryOperatorEnum.Equals, Username)
                'oWebUsers.Filter.Add("Password", TIMSS.Enumerations.QueryOperatorEnum.Equals, [Password])
                'oWebUsers.Filter.Add("DisableLoginFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "N")
                WebUsers.Fill()

                If WebUsers.Count > 0 Then
                    Return WebUsers(0).LastLoginDate
                End If
            End If

            Return Nothing

        End Function


        Private Function df_GetCustomerAccountInfo(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer) As DataTable



            'Dim oCFAVw As TIMSS.API.CustomerInfo.ICustomerFormattedAddressViewList
            'oCFAVw = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerFormattedAddressViewList")
            'With oCFAVw.Filter
            '    .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
            '    .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
            'End With

            'oCFAVw.Fill()

            Dim searchObj As New TIMSS.API.Core.SearchObject(Me.OrganizationId, Me.OrganizationUnitId)

            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerFormattedAddressViewList")
            searchObj.EnforceLimits = False

            searchObj.Parameters.Add(SearchProperty("MasterCustomerId", True, True, pMasterCustomerId))
            searchObj.Parameters.Add(SearchProperty("SubCustomerId", True, True, pSubCustomerId))

            searchObj.Parameters.Add(SearchProperty("PrimaryEmailAddress", False, True))
            searchObj.Parameters.Add(SearchProperty("PrimaryFax", False, True))
            searchObj.Parameters.Add(SearchProperty("PrimaryPhone", False, True))
            searchObj.Parameters.Add(SearchProperty("FormattedDetaildirexternal", False, True))
            searchObj.Parameters.Add(SearchProperty("FormattedAddressexternal", False, True))
            searchObj.Parameters.Add(SearchProperty("LabelName", False, True))
            searchObj.Parameters.Add(SearchProperty("PublishPrimaryPhoneFlag", False, True))
            searchObj.Parameters.Add(SearchProperty("PrimaryPhoneLocationCode", False, True))
            searchObj.Parameters.Add(SearchProperty("PublishPrimaryFaxFlag", False, True))
            searchObj.Parameters.Add(SearchProperty("PrimaryFaxLocationCode", False, True))
            searchObj.Parameters.Add(SearchProperty("PublishPrimaryEmailFlag", False, True))
            searchObj.Parameters.Add(SearchProperty("PrimaryEmailLocationCode", False, True))
            searchObj.Parameters.Add(SearchProperty("PrimaryUrl", False, True))
            searchObj.Parameters.Add(SearchProperty("Address1", False, True))
            searchObj.Parameters.Add(SearchProperty("Address2", False, True))
            searchObj.Parameters.Add(SearchProperty("City", False, True))
            searchObj.Parameters.Add(SearchProperty("State", False, True))
            searchObj.Parameters.Add(SearchProperty("PostalCode", False, True))
            searchObj.Parameters.Add(SearchProperty("CountryCode", False, True))
            searchObj.Parameters.Add(SearchProperty("CountryDescription", False, True))


            searchObj.Search()
            Return searchObj.Results.Table

        End Function

        Private Function SearchProperty(ByVal PropertyName As String, ByVal UseInQuery As Boolean, ByVal ShowInResults As Boolean, Optional ByVal PropertyValue As String = "") As TIMSS.API.Core.SearchProperty

            Dim oParm As TIMSS.API.Core.SearchProperty
            oParm = New TIMSS.API.Core.SearchProperty(PropertyName)
            oParm.UseInQuery = UseInQuery
            oParm.ShowInResults = ShowInResults
            oParm.Value = PropertyValue

            Return oParm
        End Function
        Private Function df_GetPrimaryAddress(ByVal pMasterCustomerId As String, _
           ByVal pSubCustomerId As String) As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            oAddresses = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")


            With oAddresses.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
                .Add("PrioritySeq", 0)
            End With

            oAddresses.Fill()

            Return oAddresses

        End Function


#End Region

    End Class
    Public Class AccountObject
        Public ChangeOn As String
        Public ChangeVisible As String
        Public Phone As String
        Public fax As String
        Public email As String
    End Class


End Namespace
