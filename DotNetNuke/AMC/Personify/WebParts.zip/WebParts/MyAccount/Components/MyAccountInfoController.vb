Imports System
Imports System.Data
'Imports TMA_Resources.DNN.Modules.TIMSSCMS.MyAccountInfo.Data

Namespace Personify.DNN.Modules.MyAccountInfo.Business

    Public Class MyAccountInfoController
        'Implements Entities.Modules.ISearchable
        'Implements Entities.Modules.IPortable

#Region "Pulic Methods"
        '---------------------------------------------------------------------
        ' TODO Implement BLL methods
        ' You can use CodeSmith templates to generate this code
        ''---------------------------------------------------------------------
        'Public Function List() As ArrayList
        '    Return CBO.FillCollection(DataProvider.Instance().ListTIMSSCMS.MyAccountInfo(), GetType(TIMSSCMS.MyAccountInfoInfo))
        'End Function

        'Public Function GetByModules(ByVal ModuleId As Integer) As ArrayList
        '    Return CBO.FillCollection(DataProvider.Instance().GetTIMSSCMS.MyAccountInfoByModules(ModuleId), GetType(TIMSSCMS.MyAccountInfoInfo))
        'End Function

        'Public Function [Get](ByVal ItemID As Integer, ByVal ModuleId As Integer) As TIMSSCMS.MyAccountInfoInfo
        '    Return CType(CBO.FillObject(DataProvider.Instance().GetTIMSSCMS.MyAccountInfo(ItemID, ModuleId), GetType(TIMSSCMS.MyAccountInfoInfo)), TIMSSCMS.MyAccountInfoInfo)
        'End Function

        'Public Function Add(ByVal objTIMSSCMS.MyAccountInfo As TIMSSCMS.MyAccountInfoInfo) as integer
        '    Return CType(DataProvider.Instance().AddTIMSSCMS.MyAccountInfo(objTIMSSCMS.MyAccountInfo.ModuleId, objTIMSSCMS.MyAccountInfo.Field1), Integer)
        'End Function

        'Public Sub Update(ByVal objTIMSSCMS.MyAccountInfo As TIMSSCMS.MyAccountInfoInfo)
        '    DataProvider.Instance().UpdateTIMSSCMS.MyAccountInfo(objTIMSSCMS.MyAccountInfo.ItemId, objTIMSSCMS.MyAccountInfo.Field1)
        'End Sub

        'Public Sub Delete(ByVal ItemID As Integer)
        '    DataProvider.Instance().DeleteTIMSSCMS.MyAccountInfo(ItemID)
        'End Sub
#End Region

#Region "Optional Interfaces"
        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

        'End Function

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

        'End Sub
#End Region

    End Class

End Namespace
