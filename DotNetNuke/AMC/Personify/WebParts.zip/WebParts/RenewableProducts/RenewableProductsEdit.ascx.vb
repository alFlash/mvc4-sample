Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.RenewableProducts.Business


Namespace Personify.DNN.Modules.RenewableProducts

    Public MustInherit Class RenewableProductsEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents lnkUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblSegmentActionURLForBrowse As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpSegmentActionURLForBrowse As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblPayRenewActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpPayRenewActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents txtNumberOfOrdersToProcess As System.Web.UI.WebControls.TextBox
        Protected WithEvents valNumberOfOrdersToProcess As System.Web.UI.WebControls.RegularExpressionValidator
        Protected WithEvents txtIntervalInMonths As System.Web.UI.WebControls.TextBox
        Protected WithEvents valIntervalInMonths As System.Web.UI.WebControls.RegularExpressionValidator
        Protected WithEvents txtOrderMethodCode As System.Web.UI.WebControls.TextBox

        Protected WithEvents xslProducts As WebControls.XslTemplate
#End Region

#Region "Constants"
        Private Const C_Segment_Action_URL_For_Browse As String = "SegmentActionURLForBrowse"
        Private Const C_Pay_Renew_Action_URL As String = "PayRenewActionURL"
        Private Const C_Number_Of_Orders_To_Process As String = "NumberOfOrdersToProcess"
        Private Const C_Interval_In_Months As String = "IntervalInMonths"
        Private Const C_ORDER_METHOD_CODE As String = "OrderMethodCode"
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                
                ' Determine ItemId
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Null.NullInteger()
                End If

                If Not Page.IsPostBack Then
                    LoadSettings()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub lnkUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkUpdate.Click
            If Page.IsValid Then
                Try
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub

        Private Sub lnkCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region " Helper functions"

        Private Sub LoadSettings()

            valNumberOfOrdersToProcess.ErrorMessage = "*" & Localization.GetString("NotANumberError", LocalResourceFile)
            valIntervalInMonths.ErrorMessage = "*" & Localization.GetString("NotANumberError", LocalResourceFile)

            If Not Settings(C_ORDER_METHOD_CODE) Is Nothing Then
                txtOrderMethodCode.Text = CStr(Settings(C_ORDER_METHOD_CODE))
            End If
            If Not Settings(C_Number_Of_Orders_To_Process) Is Nothing Then
                txtNumberOfOrdersToProcess.Text = CStr(Settings(C_Number_Of_Orders_To_Process))
            End If
            If Not Settings(C_Interval_In_Months) Is Nothing Then
                txtIntervalInMonths.Text = CStr(Settings(C_Interval_In_Months))
            End If

            '"Browse" Action URL's Setting
            If Not Settings(C_Segment_Action_URL_For_Browse) Is Nothing Then
                drpSegmentActionURLForBrowse.Url = CStr(Settings(C_Segment_Action_URL_For_Browse))
            End If

            If Not Settings(C_Pay_Renew_Action_URL) Is Nothing Then
                drpPayRenewActionURL.Url = CStr(Settings(C_Pay_Renew_Action_URL))
            End If

            Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList
            Dim subsystem As String = "'MBR','SUB'"
            oWebProducts = GetWebProducts(subsystem, True)

            Dim products(oWebProducts.Count - 1) As ProductsInfo

            Dim i As Integer = 0
            For Each oWebProduct As TIMSS.API.WebInfo.ITmarWebProductView In oWebProducts
                products(i) = New ProductsInfo
                products(i).ProductId = oWebProduct.ProductId
                products(i).ShortName = oWebProduct.ShortName

                If Not Settings("ProductId" & oWebProduct.ProductId) Is Nothing AndAlso CStr(Settings("ProductId" & oWebProduct.ProductId)) = "Y" Then
                    products(i).checked = True
                Else
                    products(i).checked = False
                End If
                i = i + 1
            Next

            'build list of products
            With xslProducts

                .XSLfile = Server.MapPath(ModulePath + "/Templates/RenewableProductsEditTemplate.xsl")
                .AddObject("", products)
                .Display()
            End With


        End Sub

        Private Sub UpdateSettings()

            Dim objModules As New Entities.Modules.ModuleController

            objModules.UpdateModuleSetting(Me.ModuleId, C_ORDER_METHOD_CODE, txtOrderMethodCode.Text)
            objModules.UpdateModuleSetting(Me.ModuleId, C_Number_Of_Orders_To_Process, txtNumberOfOrdersToProcess.Text)
            objModules.UpdateModuleSetting(Me.ModuleId, C_Interval_In_Months, txtIntervalInMonths.Text)


            '"Browse" Action URL's Setting
            objModules.UpdateModuleSetting(Me.ModuleId, C_Segment_Action_URL_For_Browse, drpSegmentActionURLForBrowse.Url)

            objModules.UpdateModuleSetting(Me.ModuleId, C_Pay_Renew_Action_URL, drpPayRenewActionURL.Url)

            Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList
            Dim subsystem As String = "'MBR','SUB'"
            oWebProducts = GetWebProducts(subsystem, True)


            Dim i As Integer = 0
            For Each oWebProduct As TIMSS.API.WebInfo.ITmarWebProductView In oWebProducts
                'If Not CType(FindControl("chkProductId" & CStr(oWebProduct.ProductId)), CheckBox) Is Nothing Then
                'If CType(FindControl("chkProductId" & CStr(oWebProduct.ProductId)), CheckBox).Checked Then
                'objModules.UpdateModuleSetting(Me.ModuleId, "ProductId" & CStr(oWebProduct.ProductId), "Y")
                'Else
                'objModules.UpdateModuleSetting(Me.ModuleId, "ProductId" & CStr(oWebProduct.ProductId), "N")
                'End If
                'Else
                'objModules.UpdateModuleSetting(Me.ModuleId, "ProductId" & CStr(oWebProduct.ProductId), "N")
                'End If

                Dim setted As Boolean = False
                For Each ctl As String In Request.Params.AllKeys
                    If ctl.IndexOf("chkProductId" & CStr(oWebProduct.ProductId)) >= 0 Then
                        objModules.UpdateModuleSetting(Me.ModuleId, "ProductId" & CStr(oWebProduct.ProductId), "Y")
                        setted = True
                    End If
                Next
                If Not setted Then
                    objModules.UpdateModuleSetting(Me.ModuleId, "ProductId" & CStr(oWebProduct.ProductId), "N")
                End If

            Next

        End Sub

#End Region
        Private Function GetWebProducts(ByVal [Subsystem] As String, _
                    ByVal RenewableFlag As Boolean) As TIMSS.API.WebInfo.ITmarWebProductViewList

            Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList

            oWebProducts = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebProductViewList")


            With oWebProducts.Filter
                .Add("Subsystem", TIMSS.Enumerations.QueryOperatorEnum.IsIn, Subsystem)
                If RenewableFlag Then
                    .Add("RenewableFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
                Else
                    .Add("RenewableFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "N")
                End If

            End With
            oWebProducts.Fill()

            Return oWebProducts



        End Function

    End Class

End Namespace
