Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.RenewableProducts.Business
Imports TIMSS.SqlObjects



Namespace Personify.DNN.Modules.RenewableProducts

    Public MustInherit Class RenewableProducts
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected WithEvents pnlMain As System.Web.UI.WebControls.Panel
        Protected WithEvents xslProducts As WebControls.XslTemplate

        Private strMasterCustomerId As String
        Private strSubCustomerId As String

        Dim SegmentType As String = String.Empty
        Dim qualifier1 As String = String.Empty
        Dim qualifier2 As String = String.Empty
        Dim segmentinfo As AffiliateManagementSessionHelper.SegmentInfo
        Dim OrderMethodCode As String = "RETAIN"
        Dim months As Integer = 3
        Private m_EventArgument As String

        Protected WithEvents oMessageControl As WebControls.MessageControl

#End Region

#Region "Properties"
        Public Property EventArgument() As String
            Get
                If (m_EventArgument Is Nothing) Then
                    Return String.Empty
                Else
                    Return m_EventArgument
                End If
            End Get
            Set(ByVal Value As String)
                m_EventArgument = Value
            End Set
        End Property
#End Region
#Region "Constants"
        Private Const C_Segment_Action_URL_For_Browse As String = "SegmentActionURLForBrowse"
        Private Const C_Pay_Renew_Action_URL As String = "PayRenewActionURL"

        Private Const C_Number_Of_Orders_To_Process As String = "NumberOfOrdersToProcess"
        Private Const C_Interval_In_Months As String = "IntervalInMonths"
        Private Const C_ORDER_METHOD_CODE As String = "OrderMethodCode"

        Private Const C_SEGMENT_EMPLOYEE As String = "EMPLOYEE"
        Private Const C_SEGMENT_MEMBERSHIP As String = "MEMBERSHIP"
        Private Const C_SEGMENT_GEOGRAPHIC As String = "GEOGRAPHY"
        Private Const C_SEGMENT_COMMITTEE As String = "COMMITTEE"
        Private Const C_SEGMENT_MISCELLANEOUS As String = "MISCELLANEOUS"


#End Region
#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If (Settings(C_Segment_Action_URL_For_Browse) Is Nothing) Or (Settings(C_Number_Of_Orders_To_Process) Is Nothing) Or (Settings(C_Interval_In_Months) Is Nothing) Or (Settings(C_Pay_Renew_Action_URL) Is Nothing) Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        pnlMain.Visible = False
                        Exit Sub
                    End If
                    strMasterCustomerId = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
                    strSubCustomerId = UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString

                    InitializeControl()
                Else
                    pnlMain.Visible = False
                    DisplayUserAccessMessage(role)
                End If
                

            Catch ex As Threading.ThreadAbortException
                'Ignore this one because the Redirect causes this

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


    
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "Helper Functions"
        Private Sub InitializeControl()
            EventArgument = Page.Request("__EVENTARGUMENT")
            'get current segment information
            segmentinfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
            qualifier1 = segmentinfo.SegmentQualifier1
            qualifier2 = segmentinfo.SegmentQualifier2
            SegmentType = segmentinfo.SegmentType

            'read OrderMethodCode from Settings
            If Not Settings(C_ORDER_METHOD_CODE) Is Nothing AndAlso Settings(C_ORDER_METHOD_CODE).ToString <> "" Then
                OrderMethodCode = CStr(Settings(C_ORDER_METHOD_CODE))
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                Exit Sub
            End If
            'read IntervalInMonths from Settings
            If Not Settings(C_Interval_In_Months) Is Nothing AndAlso Settings(C_Interval_In_Months).ToString <> "" Then
                months = CInt(Settings(C_Interval_In_Months))
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                Exit Sub
            End If


            If Page.IsPostBack Then
                If (EventArgument.IndexOf("RenewSelected") >= 0) Then
                    'Renew Selected button was clicked
                    RenewOrders()
                End If
                If (EventArgument.IndexOf("RenewCancel") >= 0) Then
                    'Cancel button was clicked
                    Dim navigate As Integer = 0
                    If Request.QueryString("ShipCustomerId") IsNot Nothing Then
                        'coming from Affiliate List individual Renew menu
                        navigate = segmentinfo.AffiliateListTabId
                    Else
                        'coming from Affiliate Segment List - Renew All link
                        navigate = segmentinfo.SegmentListTabId
                    End If
                    Response.Redirect(NavigateURL(navigate))
                End If
                If (EventArgument.IndexOf("BrowseMembers") >= 0) Then
                    'Browse Members link was clicked
                    If Not Settings(C_Segment_Action_URL_For_Browse) Is Nothing Then
                        Response.Redirect(NavigateURL(CType(Settings(C_Segment_Action_URL_For_Browse), Integer)))
                    End If
                End If
            End If

            Dim btnCancel As ButtonCancelInfo = New ButtonCancelInfo
            Dim btnConfirmAction As ButtonConfirmActionInfo = New ButtonConfirmActionInfo
            Dim btnBrowseMembers As ButtonBrowseMembers = New ButtonBrowseMembers
            Dim actionMessage As String = Localization.GetString("ActionMessage", LocalResourceFile)
            With btnConfirmAction
                .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "RenewSelected")
                .Text = Localization.GetString("btnConfirmAction", LocalResourceFile)
            End With
            With btnCancel
                .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "RenewCancel")
                .Text = Localization.GetString("btnCancel", LocalResourceFile)
            End With
            With btnBrowseMembers
                .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "BrowseMembers")
                .Text1 = Localization.GetString("btnBrowseMembersText1", LocalResourceFile)
                .Text2 = Localization.GetString("btnBrowseMembersText2", LocalResourceFile)
            End With
            Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList
            Dim subsystem As String = "'MBR','SUB'"
            oWebProducts = GetWebProducts(subsystem, True)


            Dim products(oWebProducts.Count - 1) As ProductsInfo

            Dim i As Integer = 0
            For Each oWebProduct As TIMSS.API.WebInfo.ITmarWebProductView In oWebProducts
                If Not Settings("ProductId" & oWebProduct.ProductId) Is Nothing AndAlso CStr(Settings("ProductId" & oWebProduct.ProductId)) = "Y" Then
                    products(i) = New ProductsInfo
                    products(i).ProductId = oWebProduct.ProductId
                    products(i).ShortName = oWebProduct.ShortName
                    products(i).checked = False
                    i = i + 1
                End If
            Next

            'build list of products
            With xslProducts
                .XSLfile = Server.MapPath(ModulePath + "/Templates/RenewableProductsTemplate.xsl")
                .AddObject("", products)
                .AddObject("actionMessage", actionMessage)
                .AddObject("", btnConfirmAction)
                .AddObject("", btnCancel)
                .AddObject("", btnBrowseMembers)
                .Display()
            End With

        End Sub

        Private Sub RenewOrders()
            'Renew based on current segment type
            Select Case SegmentType
                Case C_SEGMENT_EMPLOYEE
                    RenewEmployeeSegmentAffiliateList()
                Case C_SEGMENT_MEMBERSHIP
                    RenewMembershipProductSegmentAffiliateList()
                Case C_SEGMENT_GEOGRAPHIC
                    RenewGeographySegmentAffiliateList()
                Case C_SEGMENT_COMMITTEE
                    RenewCommitteeSegmentAffiliateList()
                Case C_SEGMENT_MISCELLANEOUS
                    RenewMiscellaneousSegmentAffiliateList()
            End Select
        End Sub

        Private Sub RenewEmployeeSegmentAffiliateList()
            Try

                Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = Nothing
                Dim arrGroupActionInfo As New ArrayList

                Dim strQueryString As String = Request.Url.Query
                Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                Dim strQueryParam As String

                'if comming from AffiliateList ContextMenu the unique CustomerId is read from QueryString
                Dim shipCustomerId As String = String.Empty
                For Each strQueryParam In arrQueryString
                    If strQueryParam.IndexOf("ShipCustomerId") <> -1 Then
                        shipCustomerId = strQueryParam.Replace("ShipCustomerId=", "")
                    End If
                Next

                'read the selected products into an comma separated string of ProductIds
                Dim products As String = ""
                For Each ctrl As String In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("ProductId") >= 0 Then
                        products = products & ctrl.Substring(ctrl.IndexOf("ProductId") + 9) & ","
                    End If
                Next
                If products = String.Empty Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoProductSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If
                'build an array of ProductIds
                Dim strProductIds() As String = products.Split(CChar(","))
                Dim productIds(strProductIds.Length - 2) As Integer
                For i As Integer = 0 To strProductIds.Length - 2
                    productIds(i) = CInt(strProductIds(i))
                Next

                'if comming from AffiliateSegmentList - Renew All link 
                If shipCustomerId = String.Empty Then
                    Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList

                    'get the items of current segment
                    oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2)

                    If oMembers.Count > 0 Then

                        Dim shipCustomerIds(oMembers.Count - 1) As String
                        Dim index As Integer = 0
                        For i As Integer = 0 To oMembers.Count - 1
                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                            With strucGroupActionInfo
                                .AffiliateCustomerId.MasterCustomerId = oMembers(i).MasterCustomerId
                                .AffiliateCustomerId.SubCustomerId = oMembers(i).SubCustomerId
                                .AffiliateLabelName = oMembers(i).LabelName
                                .CustomerIdKey = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                .EmailAddress = oMembers(i).PrimaryEmailAddress()
                            End With
                            arrGroupActionInfo.Add(strucGroupActionInfo)

                            Dim replicate As Boolean = False
                            'search if CustomerId already exists
                            For j As Integer = 0 To i - 1
                                If shipCustomerIds(j) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId Then
                                    replicate = True
                                    Exit For
                                End If
                            Next
                            'if customer does not exists add to the array
                            If Not replicate Then
                                shipCustomerIds(index) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                index = index + 1
                            End If
                        Next


                        Dim dsOrders As DataSet = Nothing

                        'obtain the Order to Renew for specified Customers and specified Products
                        dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                        If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                            If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                                Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                                Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                                Dim dr As DataRow
                                For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                    dr = dsOrders.Tables(0).Rows(i)
                                    orderNo(i) = CStr(dr("ORDER_NO"))
                                    If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                        orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                    Else
                                        orderLineNoToRenew(i) = 0
                                    End If

                                Next
                                Dim oQueryResult As IQueryResult

                                'for each of the order call Renew procedure
                                oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)


                                If oQueryResult.ValidationMessages.Count > 0 Then
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Else
                                    Dim arrTempGroupActionInfo(arrGroupActionInfo.Count - 1) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                    For i As Integer = 0 To arrGroupActionInfo.Count - 1
                                        arrTempGroupActionInfo(i) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                        arrTempGroupActionInfo(i) = CType(arrGroupActionInfo.Item(i), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                    Next
                                    'save AffiliateGroupActionInfo
                                    AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)
                                    Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCustomerSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                Else
                    'comming from AffiliateList ContextMenu 
                    Dim dsOrders As DataSet = Nothing
                    Dim shipCustomerIds(1) As String
                    shipCustomerIds(0) = shipCustomerId

                    'obtain the orders for Customers and Products selected
                    dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                    If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                        If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                            Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                            Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                            Dim dr As DataRow
                            For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                dr = dsOrders.Tables(0).Rows(i)
                                orderNo(i) = CStr(dr("ORDER_NO"))
                                If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                    orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                Else
                                    orderLineNoToRenew(i) = 0
                                End If

                            Next
                            Dim oQueryResult As IQueryResult
                            'for each order acll the Renew procedure
                            oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)


                            If oQueryResult.ValidationMessages.Count > 0 Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Else

                                Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList
                                'D00031547 - shipCustomerId must be sent as '000000001376-0' 
                                If shipCustomerId.LastIndexOf("-") = shipCustomerId.IndexOf("-") Then
                                    oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, shipCustomerId)
                                Else
                                    oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, "'" & shipCustomerId & "'")
                                End If


                                strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                With strucGroupActionInfo
                                    .AffiliateCustomerId.MasterCustomerId = oMembers(0).MasterCustomerId
                                    .AffiliateCustomerId.SubCustomerId = oMembers(0).SubCustomerId
                                    .AffiliateLabelName = oMembers(0).LabelName
                                    .CustomerIdKey = oMembers(0).MasterCustomerId & "-" & oMembers(0).SubCustomerId
                                    .EmailAddress = oMembers(0).PrimaryEmailAddress()
                                End With
                                arrGroupActionInfo.Add(strucGroupActionInfo)

                                Dim arrTempGroupActionInfo(0) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = CType(arrGroupActionInfo.Item(0), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                'save to AffiliateGroupActionInfo
                                AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))

                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If



            Catch ex As Exception
                Throw ex
            Finally

            End Try

        End Sub

        Private Sub RenewCommitteeSegmentAffiliateList()
            Try
                Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = Nothing
                Dim arrGroupActionInfo As New ArrayList

                Dim strQueryString As String = Request.Url.Query
                Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                Dim strQueryParam As String

                'if comming from AffiliateList ContextMenu Renew - the customer will be specified in QueryString
                Dim shipCustomerId As String = String.Empty
                For Each strQueryParam In arrQueryString
                    If strQueryParam.IndexOf("ShipCustomerId") <> -1 Then
                        shipCustomerId = strQueryParam.Replace("ShipCustomerId=", "")
                    End If
                Next

                Dim products As String = ""
                'get the list of selected products
                For Each ctrl As String In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("ProductId") >= 0 Then
                        products = products & ctrl.Substring(ctrl.IndexOf("ProductId") + 9) & ","
                    End If
                Next
                If products = String.Empty Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoProductSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If
                'build an array of selected products
                Dim strProductIds() As String = products.Split(CChar(","))
                Dim productIds(strProductIds.Length - 2) As Integer
                For i As Integer = 0 To strProductIds.Length - 2
                    productIds(i) = CInt(strProductIds(i))
                Next

                If shipCustomerId = String.Empty Then
                    'if comming from AffiliateSegmentList Renew All link
                    Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList

                    'get the items of the current segment
                    oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2)

                    If oMembers.Count > 0 Then
                        Dim shipCustomerIds(oMembers.Count - 1) As String
                        Dim index As Integer = 0
                        For i As Integer = 0 To oMembers.Count - 1
                            'create a list of GroupActionAffiliateinfo objects
                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                            With strucGroupActionInfo
                                .AffiliateCustomerId.MasterCustomerId = oMembers(i).MasterCustomerId
                                .AffiliateCustomerId.SubCustomerId = oMembers(i).SubCustomerId
                                .AffiliateLabelName = oMembers(i).LabelName
                                .CustomerIdKey = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                .EmailAddress = oMembers(i).PrimaryEmailAddress()
                            End With
                            arrGroupActionInfo.Add(strucGroupActionInfo)

                            'check if the customer exists already saved
                            Dim replicate As Boolean = False
                            For j As Integer = 0 To i - 1
                                If shipCustomerIds(j) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId Then
                                    replicate = True
                                    Exit For
                                End If
                            Next
                            If Not replicate Then
                                shipCustomerIds(index) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                index = index + 1
                            End If
                        Next

                        Dim dsOrders As DataSet = Nothing

                        'get orders for customers and products
                        dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                        If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                            If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                                Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                                Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                                Dim dr As DataRow
                                For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                    dr = dsOrders.Tables(0).Rows(i)
                                    orderNo(i) = CStr(dr("ORDER_NO"))
                                    If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                        orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                    Else
                                        orderLineNoToRenew(i) = 0
                                    End If

                                Next
                                Dim oQueryResult As IQueryResult
                                'for each order call Renew
                                oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)

                                If oQueryResult.ValidationMessages.Count > 0 Then
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Else
                                    Dim arrTempGroupActionInfo(arrGroupActionInfo.Count - 1) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                    For i As Integer = 0 To arrGroupActionInfo.Count - 1
                                        arrTempGroupActionInfo(i) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                        arrTempGroupActionInfo(i) = CType(arrGroupActionInfo.Item(i), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                    Next
                                    'save GroupActionAffiliateListInfo
                                    AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                    Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCustomerSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                Else
                    'if comming from AffiliateList ContextMenu Renew 

                    'create a list of customers with only one member (ContextMenu Renew works for only one item)
                    Dim shipCustomerIds(1) As String
                    shipCustomerIds(0) = shipCustomerId

                    Dim dsOrders As DataSet = Nothing
                    'get the orders for Customer and Products
                    dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                    If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                        If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                            Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                            Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                            Dim dr As DataRow
                            For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                dr = dsOrders.Tables(0).Rows(i)
                                orderNo(i) = CStr(dr("ORDER_NO"))
                                If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                    orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                Else
                                    orderLineNoToRenew(i) = 0
                                End If

                            Next
                            Dim oQueryResult As IQueryResult
                            'for each order call the Renew procedure
                            oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)

                            If oQueryResult.ValidationMessages.Count > 0 Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Else

                                Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList
                                'get Info for the list of Customers (in this case only one)
                                'D00031547 - shipCustomerId must be sent as '000000001376-0' 
                                If shipCustomerId.LastIndexOf("-") = shipCustomerId.IndexOf("-") Then
                                    oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, shipCustomerId)
                                Else
                                    oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, "'" & shipCustomerId & "'")
                                End If

                                strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                With strucGroupActionInfo
                                    .AffiliateCustomerId.MasterCustomerId = oMembers(0).MasterCustomerId
                                    .AffiliateCustomerId.SubCustomerId = oMembers(0).SubCustomerId
                                    .AffiliateLabelName = oMembers(0).LabelName
                                    .CustomerIdKey = oMembers(0).MasterCustomerId & "-" & oMembers(0).SubCustomerId
                                    .EmailAddress = oMembers(0).PrimaryEmailAddress()
                                End With
                                arrGroupActionInfo.Add(strucGroupActionInfo)

                                Dim arrTempGroupActionInfo(0) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = CType(arrGroupActionInfo.Item(0), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                'save AffiliateGroupActionInfo
                                AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If
            Catch ex As Exception
                Throw ex
            Finally

            End Try

        End Sub

        Private Sub RenewMiscellaneousSegmentAffiliateList()
            Try
                Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = Nothing
                Dim arrGroupActionInfo As New ArrayList

                Dim strQueryString As String = Request.Url.Query
                Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                Dim strQueryParam As String

                'if comming from AffiliateList ContextMenu Renew the customerId will be taken from QueryString
                Dim shipCustomerId As String = String.Empty
                For Each strQueryParam In arrQueryString
                    If strQueryParam.IndexOf("ShipCustomerId") <> -1 Then
                        shipCustomerId = strQueryParam.Replace("ShipCustomerId=", "")
                    End If
                Next

                'get the comma separated list of ProductId
                Dim products As String = ""
                For Each ctrl As String In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("ProductId") >= 0 Then
                        products = products & ctrl.Substring(ctrl.IndexOf("ProductId") + 9) & ","
                    End If
                Next
                If products = String.Empty Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoProductSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If
                'get an array of PrductIds
                Dim strProductIds() As String = products.Split(CChar(","))
                Dim productIds(strProductIds.Length - 2) As Integer
                For i As Integer = 0 To strProductIds.Length - 2
                    productIds(i) = CInt(strProductIds(i))
                Next

                If shipCustomerId = String.Empty Then
                    'if comming from AffiliateSegmentList RenewAll link
                    Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList
                    'get all the items of current segment
                    oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2)

                    If oMembers.Count > 0 Then
                        Dim shipCustomerIds(oMembers.Count - 1) As String
                        Dim index As Integer = 0
                        For i As Integer = 0 To oMembers.Count - 1
                            'create an arraylist of GroupActionInfo containing current segment items
                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                            With strucGroupActionInfo
                                .AffiliateCustomerId.MasterCustomerId = oMembers(i).MasterCustomerId
                                .AffiliateCustomerId.SubCustomerId = oMembers(i).SubCustomerId
                                .AffiliateLabelName = oMembers(i).LabelName
                                .CustomerIdKey = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                .EmailAddress = oMembers(i).PrimaryEmailAddress()
                            End With
                            arrGroupActionInfo.Add(strucGroupActionInfo)

                            Dim replicate As Boolean = False
                            'check if the customer already exists in the list
                            For j As Integer = 0 To i - 1
                                If shipCustomerIds(j) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId Then
                                    replicate = True
                                    Exit For
                                End If
                            Next
                            If Not replicate Then
                                'add another item to the array
                                shipCustomerIds(index) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                index = index + 1
                            End If
                        Next



                        Dim dsOrders As DataSet = Nothing
                        'get orders for specified CustomerIds and ProductIds
                        dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                        If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                            If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                                Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                                Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                                Dim dr As DataRow
                                For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                    dr = dsOrders.Tables(0).Rows(i)
                                    orderNo(i) = CStr(dr("ORDER_NO"))
                                    If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                        orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                    Else
                                        orderLineNoToRenew(i) = 0
                                    End If

                                Next
                                Dim oQueryResult As IQueryResult
                                'for each order call Renew procedure
                                oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)

                                If oQueryResult.ValidationMessages.Count > 0 Then
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Else
                                    Dim arrTempGroupActionInfo(arrGroupActionInfo.Count - 1) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                    For i As Integer = 0 To arrGroupActionInfo.Count - 1
                                        arrTempGroupActionInfo(i) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                        arrTempGroupActionInfo(i) = CType(arrGroupActionInfo.Item(i), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                    Next
                                    'save AffiliateGroupActionInfo
                                    AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                    Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCustomerSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If

                Else
                    'if comming from AffiliateList ContextMenu -Renew
                    'create an array of only one item to store CustomerId of the selected Customer
                    Dim shipCustomerIds(1) As String
                    shipCustomerIds(0) = shipCustomerId

                    Dim dsOrders As DataSet = Nothing
                    'get orders for the specified customerIds(only one in this case) and ProductIds
                    dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                    If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                        If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                            Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                            Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                            Dim dr As DataRow
                            For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                dr = dsOrders.Tables(0).Rows(i)
                                orderNo(i) = CStr(dr("ORDER_NO"))
                                If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                    orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                Else
                                    orderLineNoToRenew(i) = 0
                                End If

                            Next
                            Dim oQueryResult As IQueryResult
                            'for each order call Renew procedure
                            oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)


                            If oQueryResult.ValidationMessages.Count > 0 Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Else
                                Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList
                                'D00031547 - shipCustomerId must be sent as '000000001376-0'
                                If shipCustomerId.LastIndexOf("-") = shipCustomerId.IndexOf("-") Then
                                    oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, shipCustomerId)
                                Else
                                    oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, "'" & shipCustomerId & "'")
                                End If


                                strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                With strucGroupActionInfo
                                    .AffiliateCustomerId.MasterCustomerId = oMembers(0).MasterCustomerId
                                    .AffiliateCustomerId.SubCustomerId = oMembers(0).SubCustomerId
                                    .AffiliateLabelName = oMembers(0).LabelName
                                    .CustomerIdKey = oMembers(0).MasterCustomerId & "-" & oMembers(0).SubCustomerId
                                    .EmailAddress = oMembers(0).PrimaryEmailAddress()
                                End With
                                arrGroupActionInfo.Add(strucGroupActionInfo)

                                Dim arrTempGroupActionInfo(0) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = CType(arrGroupActionInfo.Item(0), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                'save AffiliateGroupActionInfo
                                AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If


            Catch ex As Exception
                Throw ex
            Finally

            End Try

        End Sub

        Private Sub RenewGeographySegmentAffiliateList()
            Try
                Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = Nothing
                Dim arrGroupActionInfo As New ArrayList

                Dim strQueryString As String = Request.Url.Query
                Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                Dim strQueryParam As String

                Dim shipCustomerId As String = String.Empty
                'if comming from AffiliateList ContextMenu - Renew hte selected customerId is read from QueryString
                For Each strQueryParam In arrQueryString
                    If strQueryParam.IndexOf("ShipCustomerId") <> -1 Then
                        shipCustomerId = strQueryParam.Replace("ShipCustomerId=", "")
                    End If
                Next

                'get the selected products into an comma separated list
                Dim products As String = ""
                For Each ctrl As String In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("ProductId") >= 0 Then
                        products = products & ctrl.Substring(ctrl.IndexOf("ProductId") + 9) & ","
                    End If
                Next
                If products = String.Empty Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoProductSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If
                'create a list of selected ProductId
                Dim strProductIds() As String = products.Split(CChar(","))
                Dim productIds(strProductIds.Length - 2) As Integer
                For i As Integer = 0 To strProductIds.Length - 2
                    productIds(i) = CInt(strProductIds(i))
                Next

                If shipCustomerId = String.Empty Then
                    'if comming from AffiliateSegmentList - RenewAll link
                    Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
                    'get all items of current segment
                    oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2)

                    If oMembers.Count > 0 Then
                        Dim shipCustomerIds(oMembers.Count - 1) As String
                        Dim index As Integer = 0
                        'create an array of GroupActionAffiliateInfo items
                        For i As Integer = 0 To oMembers.Count - 1
                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                            With strucGroupActionInfo
                                .AffiliateCustomerId.MasterCustomerId = oMembers(i).MasterCustomerId
                                .AffiliateCustomerId.SubCustomerId = oMembers(i).SubCustomerId
                                .AffiliateLabelName = oMembers(i).LabelName
                                .CustomerIdKey = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                .EmailAddress = oMembers(i).PrimaryEmailAddress()
                            End With
                            arrGroupActionInfo.Add(strucGroupActionInfo)

                            Dim replicate As Boolean = False
                            'check if the customer already exists in the list
                            For j As Integer = 0 To i - 1
                                If shipCustomerIds(j) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId Then
                                    replicate = True
                                    Exit For
                                End If
                            Next
                            If Not replicate Then                                
                                shipCustomerIds(index) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                index = index + 1
                            End If
                        Next



                        Dim dsOrders As DataSet = Nothing
                        'get the orders for specified CustomerIds and ProductIds
                        dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                        If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                            If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                                Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                                Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                                Dim dr As DataRow
                                For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                    dr = dsOrders.Tables(0).Rows(i)
                                    orderNo(i) = CStr(dr("ORDER_NO"))
                                    If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                        orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                    Else
                                        orderLineNoToRenew(i) = 0
                                    End If

                                Next
                                Dim oQueryResult As IQueryResult
                                'for each order call Renew procedure
                                oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)


                                If oQueryResult.ValidationMessages.Count > 0 Then
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Else
                                    Dim arrTempGroupActionInfo(arrGroupActionInfo.Count - 1) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                    For i As Integer = 0 To arrGroupActionInfo.Count - 1
                                        arrTempGroupActionInfo(i) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                        arrTempGroupActionInfo(i) = CType(arrGroupActionInfo.Item(i), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                    Next
                                    'save AffiliateGroupActionInfo
                                    AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                    Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCustomerSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                Else
                    'comming from Affiliatelist - ContextMenu -Renew
                    'create an array of only one CustomerId
                    Dim shipCustomerIds(1) As String
                    shipCustomerIds(0) = shipCustomerId
                    Dim dsOrders As DataSet = Nothing
                    'get orders for the specified CustomerId(only one in array in this case) and ProductIds
                    dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                    If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                        If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                            Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                            Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                            Dim dr As DataRow
                            For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                dr = dsOrders.Tables(0).Rows(i)
                                orderNo(i) = CStr(dr("ORDER_NO"))
                                If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                    orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                Else
                                    orderLineNoToRenew(i) = 0
                                End If

                            Next
                            Dim oQueryResult As IQueryResult
                            'for each order call Renew procedure
                            oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)

                            If oQueryResult.ValidationMessages.Count > 0 Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Else
                                Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
                                'D00031547 - shipCustomerId must be sent as '000000001376-0'
                                If shipCustomerId.LastIndexOf("-") = shipCustomerId.IndexOf("-") Then
                                    oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, shipCustomerId)
                                Else
                                    oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, "'" & shipCustomerId & "'")
                                End If


                                strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                With strucGroupActionInfo
                                    .AffiliateCustomerId.MasterCustomerId = oMembers(0).MasterCustomerId
                                    .AffiliateCustomerId.SubCustomerId = oMembers(0).SubCustomerId
                                    .AffiliateLabelName = oMembers(0).LabelName
                                    .CustomerIdKey = oMembers(0).MasterCustomerId & "-" & oMembers(0).SubCustomerId
                                    .EmailAddress = oMembers(0).PrimaryEmailAddress()
                                End With
                                arrGroupActionInfo.Add(strucGroupActionInfo)

                                Dim arrTempGroupActionInfo(0) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = CType(arrGroupActionInfo.Item(0), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                'save AffiliateGroupActionInfo
                                AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If
            Catch ex As Exception
                Throw ex
            Finally

            End Try

        End Sub

        Private Sub RenewMembershipProductSegmentAffiliateList()
            Try
                Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = Nothing
                Dim arrGroupActionInfo As New ArrayList

                Dim strQueryString As String = Request.Url.Query
                Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                Dim strQueryParam As String

                'if comming from AffiliateList - ContextMenu - Renew the selected customer is taken from QueryString
                Dim shipCustomerId As String = String.Empty
                For Each strQueryParam In arrQueryString
                    If strQueryParam.IndexOf("ShipCustomerId") <> -1 Then
                        shipCustomerId = strQueryParam.Replace("ShipCustomerId=", "")
                    End If
                Next

                'get a comma separated list of selected products
                Dim products As String = ""
                For Each ctrl As String In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("ProductId") >= 0 Then
                        products = products & ctrl.Substring(ctrl.IndexOf("ProductId") + 9) & ","
                    End If
                Next
                If products = String.Empty Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoProductSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If
                'build an array of selected products
                Dim strProductIds() As String = products.Split(CChar(","))
                Dim productIds(strProductIds.Length - 2) As Integer
                For i As Integer = 0 To strProductIds.Length - 2
                    productIds(i) = CInt(strProductIds(i))
                Next

                If shipCustomerId = String.Empty Then
                    'if comming from AffiliateSegmentlist - RenewAll link
                    Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
                    'get all the items for the current segment
                    oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2)

                    If oMembers.Count > 0 Then
                        Dim shipCustomerIds(oMembers.Count - 1) As String
                        Dim index As Integer = 0
                        For i As Integer = 0 To oMembers.Count - 1
                            'create an array of GroupActionAffiliateInfo items
                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                            With strucGroupActionInfo
                                .AffiliateCustomerId.MasterCustomerId = oMembers(i).MasterCustomerId
                                .AffiliateCustomerId.SubCustomerId = oMembers(i).SubCustomerId
                                .AffiliateLabelName = oMembers(i).LabelName
                                .CustomerIdKey = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                .EmailAddress = oMembers(i).PrimaryEmailAddress()
                            End With
                            arrGroupActionInfo.Add(strucGroupActionInfo)

                            Dim replicate As Boolean = False
                            'check if customer already exists in the array
                            For j As Integer = 0 To i - 1
                                If shipCustomerIds(j) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId Then
                                    replicate = True
                                    Exit For
                                End If
                            Next
                            If Not replicate Then
                                shipCustomerIds(index) = oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId
                                index = index + 1
                            End If
                        Next



                        Dim dsOrders As DataSet = Nothing
                        'get orders for specified CustomerIds and ProductIds
                        dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                        If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                            If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                                Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                                Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                                Dim dr As DataRow
                                For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                    dr = dsOrders.Tables(0).Rows(i)
                                    orderNo(i) = CStr(dr("ORDER_NO"))
                                    If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                        orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                    Else
                                        orderLineNoToRenew(i) = 0
                                    End If

                                Next
                                Dim oQueryResult As IQueryResult
                                'for each order call Renew procedure
                                oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)


                                If oQueryResult.ValidationMessages.Count > 0 Then
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Else
                                    Dim arrTempGroupActionInfo(arrGroupActionInfo.Count - 1) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                    For i As Integer = 0 To arrGroupActionInfo.Count - 1
                                        arrTempGroupActionInfo(i) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                        arrTempGroupActionInfo(i) = CType(arrGroupActionInfo.Item(i), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                    Next
                                    'save AffiliateGroupActionInfo
                                    AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                    Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoCustomerSelectedMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                Else
                    'comming from AffiliateList - contextMenu - Renew
                    'create an array of only one customerId - the selected customer
                    Dim shipCustomerIds(1) As String
                    shipCustomerIds(0) = shipCustomerId

                    Dim dsOrders As DataSet = Nothing
                    'get the orders for specified CustomerIds(in this case only one) and ProductIds
                    dsOrders = GetWebActiveSubMbrOrders(shipCustomerIds, productIds, months)

                    If Not dsOrders Is Nothing AndAlso dsOrders.Tables(0).Rows.Count > 0 Then
                        If dsOrders.Tables(0).Rows.Count <= CType(Settings(C_Number_Of_Orders_To_Process), Integer) Then
                            Dim orderNo(dsOrders.Tables(0).Rows.Count - 1) As String
                            Dim orderLineNoToRenew(dsOrders.Tables(0).Rows.Count - 1) As Integer

                            Dim dr As DataRow
                            For i As Integer = 0 To dsOrders.Tables(0).Rows.Count - 1
                                dr = dsOrders.Tables(0).Rows(i)
                                orderNo(i) = CStr(dr("ORDER_NO"))
                                If Not IsDBNull(dr("ORDER_LINE_NO")) Then
                                    orderLineNoToRenew(i) = CInt(dr("ORDER_LINE_NO"))
                                Else
                                    orderLineNoToRenew(i) = 0
                                End If

                            Next
                            Dim oQueryResult As IQueryResult
                            'for each order call Renew procedure
                            'NSSWP and NSSWP does not apply here. In application manager
                            ' we have written code to over ride these values
                            oQueryResult = GetExecRequestRenewals(Date.Now, OrderMethodCode, orderNo, orderLineNoToRenew, months)


                            If oQueryResult.ValidationMessages.Count > 0 Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oQueryResult.ValidationMessages(0), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Else
                                Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
                                'get all info for CustomerId
                                'D00031547 - shipCustomerId must be sent as '000000001376-0' 
                                If shipCustomerId.LastIndexOf("-") = shipCustomerId.IndexOf("-") Then
                                    oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, shipCustomerId)
                                Else
                                    oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, "'" & shipCustomerId & "'")
                                End If


                                strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                With strucGroupActionInfo
                                    .AffiliateCustomerId.MasterCustomerId = oMembers(0).MasterCustomerId
                                    .AffiliateCustomerId.SubCustomerId = oMembers(0).SubCustomerId
                                    .AffiliateLabelName = oMembers(0).LabelName
                                    .CustomerIdKey = oMembers(0).MasterCustomerId & "-" & oMembers(0).SubCustomerId
                                    .EmailAddress = oMembers(0).PrimaryEmailAddress()
                                End With
                                arrGroupActionInfo.Add(strucGroupActionInfo)

                                Dim arrTempGroupActionInfo(0) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                arrTempGroupActionInfo(0) = CType(arrGroupActionInfo.Item(0), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                                'save AffiliateGroupActionInfo
                                AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                                Response.Redirect(NavigateURL(CType(Settings(C_Pay_Renew_Action_URL), Integer)))
                            End If
                        Else
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("TooManyOrdersMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoOrderMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If


            Catch ex As Exception
                Throw ex
            Finally

            End Try

        End Sub
#End Region

#Region "Personify"


        Private Function GetWebActiveSubMbrOrders(ByVal ShipCustomerIds() As String, ByVal ProductIDs() As Integer, ByVal Months As Integer) As DataSet
            Try

          
                Dim oQueryResult As IQueryResult
                Dim oParameters As New Hashtable
                oParameters.Add("P_RENEWAL_CREATED_FLAG", "N")
                oParameters.Add("P_cycle_end_date1", Date.Now)
                oParameters.Add("P_cycle_end_date2", Date.Now.AddMonths(Months))

                Dim strParameterName As String = ""

                For Each strShipCustomerId As String In ShipCustomerIds
                    If Not strShipCustomerId Is Nothing Then
                        strParameterName = "ShipCustomerId_" & strShipCustomerId.Replace("-", "_")
                        oParameters.Add(strParameterName, strShipCustomerId)
                    End If
                Next
                strParameterName = ""

                For Each strProductId As String In ProductIDs
                    If Not strProductId Is Nothing Then
                        strParameterName = "product_id_" & strProductId
                        oParameters.Add(strParameterName, strProductId)
                    End If
                Next


                oQueryResult = Me.PersonifyExecuteQueryRequest(GetSelectRequest_GetWebActiveSubMbrOrders(ShipCustomerIds, ProductIDs, Months), oParameters)

                If oQueryResult.Success Then
                    Return oQueryResult.DataSet
                End If

                Return Nothing

            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Private Function GetSelectRequest_GetWebActiveSubMbrOrders(ByVal ShipCustomerIds() As String, ByVal ProductIDs() As Integer, ByVal Months As Integer) As IBaseRequest

            Dim request As ISelectRequest = New SelectRequest("Select")

            Dim tblWeb As ISelectTable = New SelectTable("WEB_ACTIVE_MBR_SUB_ORDERS", "web")
            request.Distinct = True

            tblWeb.ResultColumns.Add("order_no", "order_no")
            tblWeb.ResultColumns.Add("order_line_no", "order_line_no")
            tblWeb.ResultColumns.Add("product_id", "product_id")
            tblWeb.ResultColumns.Add("ship_master_customer_id", "ship_master_customer_id")
            tblWeb.ResultColumns.Add("ship_sub_customer_id", "ship_sub_customer_id")
            tblWeb.ResultColumns.Add("cycle_begin_date", "cycle_begin_date")
            tblWeb.ResultColumns.Add("cycle_end_date", "cycle_end_date")
            tblWeb.ResultColumns.Add("RENEWAL_CREATED_FLAG", "RENEWAL_CREATED_FLAG")
            tblWeb.ResultColumns.Add("fulfill_status_code", "fulfill_status_code")
            tblWeb.ResultColumns.Add("line_status_code", "line_status_code")
            tblWeb.ResultColumns.Add("ShipCustomerId", "ShipCustomerId")

            request.Tables.Add(tblWeb)

            request.Parameters.Add("web", "RENEWAL_CREATED_FLAG", "P_RENEWAL_CREATED_FLAG", "N", ParameterDirection.Input, QueryOperatorType.Equals)
            request.Parameters.Add("web", "cycle_end_date", "P_cycle_end_date1", Date.Now, ParameterDirection.Input, QueryOperatorType.GreaterThanorEqual)
            request.Parameters.Add("web", "cycle_end_date", "P_cycle_end_date2", Date.Now.AddMonths(Months), ParameterDirection.Input, QueryOperatorType.LessThanorEqual)

            Dim ocolShipCustomerId As ISelectedColumn = New SelectedColumn("web", "ShipCustomerId")


            Dim isIn As IsInExpression = New IsInExpression(ocolShipCustomerId)
            Dim strParameterName As String = ""
            Dim P1 As IParameterItem


            For Each strShipCustomerId As String In ShipCustomerIds
                If Not strShipCustomerId Is Nothing Then
                    strParameterName = "ShipCustomerId_" & strShipCustomerId.Replace("-", "_")
                    P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strShipCustomerId)
                    isIn.Items.Add(P1.ConstructParameterExpression)
                    request.Parameters.Add(P1)
                End If
            Next
            request.WhereExpressions.Add(isIn)

            Dim ocolProductId As ISelectedColumn = New SelectedColumn("web", "product_id")


            isIn = New IsInExpression(ocolProductId)
            strParameterName = ""

            For Each strProductId As String In ProductIDs
                If Not strProductId Is Nothing Then
                    strParameterName = "product_id_" & strProductId
                    P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strProductId)
                    isIn.Items.Add(P1.ConstructParameterExpression)
                    request.Parameters.Add(P1)
                End If

            Next
            request.WhereExpressions.Add(isIn)


            Return request

        End Function

        Private Function GetExecRequestRenewals( _
          ByVal EndDateForRenewal As DateTime, _
          ByVal OrderMethodCode As String, _
          ByVal OrderNumber() As String, _
          ByVal OrderLineNoToRenew() As Integer, _
          ByVal Months As Integer _
          ) As IQueryResult
            'NOTE: Org Id and Org Unit Id should not be passed from the web module.
            'Removed the Org Id and Org Unit Id from the parameter and replace it with the values from timss context
            Try



                Dim oQueryResult As IQueryResult
                Dim query As IQueryRequest = GetExecRequest_T_Renewals(OrganizationId, OrganizationUnitId, EndDateForRenewal, OrderMethodCode, OrderNumber, OrderLineNoToRenew, Months)
                oQueryResult = Me.PersonifyExecuteQueryRequest(query)

                If oQueryResult.Success Then
                    Return oQueryResult
                End If

                Return Nothing

            Catch ex As Exception
                Throw ex
            End Try
        End Function



        Private Function GetExecRequest_T_Renewals(ByVal OrganizationId As String, _
          ByVal OrganizationUnitId As String, _
          ByVal _EndDateForRenewal As DateTime, _
          ByVal OrderMethodCode As String, _
          ByVal OrderNumber() As String, _
          ByVal OrderLineNoToRenew() As Integer, _
          ByVal Months As Integer _
          ) As IQueryRequest

            Dim nullString As String = Nothing
            Dim RenewalStoredProcedureRequest As IStoredProcedureRequest = New StoredProcedureRequest("ORD650_Process_SP")

            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_trs_job_id", 0, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_called_from", "ORD001", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_run_mode", "PROD", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_org_id", OrganizationId, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_org_unit_id", OrganizationUnitId, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_parent_product", nullString, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_product_code", nullString, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_end_date_from", _EndDateForRenewal, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_end_date_to", _EndDateForRenewal.AddMonths(Months), ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_market_code", "RETAIN", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_order_method_code", OrderMethodCode, ParameterDirection.Input)) ' OrderMethodCode.Code, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_cc_on_file", "BOTH", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_renew_proforma_orders", "N", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_create_invoiced_order", "N", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_activate_complementary_orders", "N", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_use_rate_structure_default", "N", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_renew_by_billto", "N", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_refresh_ziplink", "Y", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_add_donation_line", "N", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_donation_parent_product", nullString, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_donation_parent_code", nullString, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_donation_rate_structure", nullString, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_donation_rate_code", nullString, ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_donation_override_amount", 0, ParameterDirection.Input))

            Dim filter_criteria As String = String.Empty
            For i As Integer = 0 To OrderNumber.Length - 1
                If i > 0 Then
                    If OrderLineNoToRenew(i) = 0 Then
                        filter_criteria = filter_criteria & "or (ORDER_DETAIL.ORDER_NO ='" & OrderNumber(i) & "')"
                    Else
                        filter_criteria = filter_criteria & "or (ORDER_DETAIL.ORDER_NO ='" & OrderNumber(i) & "' and ORDER_DETAIL.ORDER_LINE_NO =" & OrderLineNoToRenew(i) & ")"
                    End If

                Else
                    If OrderLineNoToRenew(i) = 0 Then
                        filter_criteria = filter_criteria & "(ORDER_DETAIL.ORDER_NO ='" & OrderNumber(i) & "')"
                    Else
                        filter_criteria = filter_criteria & "(ORDER_DETAIL.ORDER_NO ='" & OrderNumber(i) & "' and ORDER_DETAIL.ORDER_LINE_NO =" & OrderLineNoToRenew(i) & ")"
                    End If
                End If
            Next
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_filter_criteria", filter_criteria, ParameterDirection.Input))


            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("ip_invoice_on_start_date", "Y", ParameterDirection.Input))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("op_ErrorNo", "", ParameterDirection.Output))
            RenewalStoredProcedureRequest.InvocationParameters.Add(New StoredProcedureParameterItem("op_ErrorMessage", "", ParameterDirection.Output))

            Return New QueryRequest(RenewalStoredProcedureRequest)
        End Function

        Private Function GetWebProducts(ByVal [Subsystem] As String, _
             ByVal RenewableFlag As Boolean) As TIMSS.API.WebInfo.ITmarWebProductViewList

            Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList

            oWebProducts = Me.PErsonifyGetCollection( TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebProductViewList")


            With oWebProducts.Filter
                .Add("Subsystem", TIMSS.Enumerations.QueryOperatorEnum.IsIn, Subsystem)
                If RenewableFlag Then
                    .Add("RenewableFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
                Else
                    .Add("RenewableFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "N")
                End If

            End With
            oWebProducts.Fill()

            Return oWebProducts



        End Function
#End Region

    End Class
#Region "Button  Continue Action"
    ' This class will be used to store information about Renew Selected Button
    Public Class ButtonConfirmActionInfo
        Public Text As String
        Public NavigateURL As String
    End Class
#End Region

#Region "Button Cancel Action"
    ' This class will be used to store information about Cancel Button 
    Public Class ButtonCancelInfo
        Public Text As String
        Public NavigateURL As String
    End Class
#End Region

#Region "Button  Browse Members"
    ' This class will be used to store information about Browse Members Link
    Public Class ButtonBrowseMembers
        Public Text1 As String
        Public Text2 As String
        Public NavigateURL As String
    End Class
#End Region

#Region "ProductsInfo"
    'class used with template file
    Public Class ProductsInfo
        Public ShortName As String
        Public ProductId As Long
        Public checked As Boolean
    End Class
#End Region
End Namespace
