Option Strict Off

Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects



Imports System
Imports System.Web.UI.WebControls
Imports personify
Imports personify.DNN.Modules.ProductDirectory.Business
Imports System.Threading

Imports TIMSS.SqlObjects



Namespace Personify.DNN.Modules.ProductDirectory

    Public MustInherit Class ProductDirectoryEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings


#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents txtMaxCols As System.Web.UI.WebControls.TextBox
        Protected WithEvents SetDirection As System.Web.UI.WebControls.DropDownList

        Protected plNavigation As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents optNavigation As System.Web.UI.WebControls.RadioButtonList
        Protected plSource As DotNetNuke.UI.UserControls.LabelControl
        Protected lblColumns As DotNetNuke.UI.UserControls.LabelControl
        Protected lblRepeat As DotNetNuke.UI.UserControls.LabelControl
        Protected plSubsystem As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents optSource As System.Web.UI.WebControls.RadioButtonList
        Protected plDetails As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents optDetails As System.Web.UI.WebControls.RadioButtonList
        Protected ctlURL As DotNetNuke.UI.UserControls.UrlControl
        Public WithEvents ListBoxBaseSubsystem As WebControls.ListBoxBase
        Protected WithEvents pnlSubsystem As System.Web.UI.WebControls.Panel

        Protected WithEvents dgAvailable As System.Web.UI.WebControls.DataGrid
        Protected WithEvents btnAddNewItems As System.Web.UI.WebControls.Button

        'Public chkSelectAll As System.Web.UI.WebControls.CheckBox
        Protected chkSelectAllAddNewItem As New System.Web.UI.WebControls.CheckBox
        Protected chkSelectAllSubMenuItems As New System.Web.UI.WebControls.CheckBox

#End Region

#Region "Private Members"
        Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
        Dim oCodes, oCodesTemp As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
        Public AreAllItemChecked, AreAllSubMenuChecked As Boolean
        'Delcare the array equal to the to store the sort order (3246-6119570)
        Dim arrNextAvailableSort() As Boolean
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim i As Integer
            Try

                If Page.IsPostBack Then
                    With objModules
                        ' Update TabModuleSettings
                        .UpdateTabModuleSetting(TabModuleId, "Navigation", optNavigation.SelectedItem.Value)
                        .UpdateTabModuleSetting(TabModuleId, "Source", optSource.SelectedItem.Value.ToString)
                        .UpdateTabModuleSetting(TabModuleId, "ProductSubsystem", GetSybsystemFromListBox())
                        .UpdateTabModuleSetting(TabModuleId, "maxCols", txtMaxCols.Text)
                        .UpdateTabModuleSetting(TabModuleId, "Direction", CStr(SetDirection.SelectedIndex))
                        .UpdateTabModuleSetting(TabModuleId, "Url", ctlURL.Url)
                        .UpdateTabModuleSetting(TabModuleId, "UrlType", ctlURL.UrlType)
                    End With
                Else
                    ListBoxBaseSubsystem.DataSource = df_GetProductRelatedActiveSubsystemList()
                    ListBoxBaseSubsystem.DataTextField = "SubsystemName"
                    ListBoxBaseSubsystem.DataValueField = "Subsystem"
                    ListBoxBaseSubsystem.DataBind()
                End If

                SetPage()

                If CType(Settings("Source"), String) = "Y" Then
                    dgAvailable.Visible = True
                    pnlSubsystem.Visible = False
                    oCodesTemp = df_GetListOfProductCategoryCodes("ORD")
                    'Redim the array equal to the codes (3246-6119570)
                    ReDim arrNextAvailableSort(oCodesTemp.Count + 1)
                    DeleteandSetSortSettings(oCodesTemp)

                    i = 0
                    While i < oCodesTemp.Count
                        oCodes.AddNewCode()
                        oCodes(i).Code = oCodesTemp(i).Code
                        'Update the avialble sort array order if it is inluded (3246-6119570)
                        If Not Settings(oCodes(i).Code) Is Nothing Then
                            arrNextAvailableSort(CType(Settings(oCodesTemp(i).Code + "_SortOrder"), Integer)) = False
                        End If

                        If CType(Settings(oCodesTemp(i).Code + "_DESCR"), String) <> "" Then
                            oCodes(i).Description = CType(Settings(oCodesTemp(i).Code + "_DESCR"), String)
                        Else
                            oCodes(i).Description = oCodesTemp(i).Description
                        End If
                        i += 1
                    End While
                Else
                    pnlSubsystem.Visible = True
                    dgAvailable.Visible = True
                    If CType(Settings("ProductSubsystem"), String) <> "" Then
                        oCodesTemp = df_GetListOfProductClassCodes(CType(Settings("ProductSubsystem"), String))
                        'Redim the Array to store the sort settings
                        ReDim arrNextAvailableSort(oCodesTemp.Count + 1)
                        DeleteandSetSortSettings(oCodesTemp)
                    Else
                        oCodesTemp = df_GetListOfProductClassCodes("")
                        dgAvailable.Visible = False
                    End If
                    i = 0
                    While i < oCodesTemp.Count
                        oCodes.AddNewCode()
                        oCodes(i).Code = oCodesTemp(i).Code
                        If Not Settings(oCodes(i).Code) Is Nothing Then
                            arrNextAvailableSort(CType(Settings(oCodesTemp(i).Code + "_SortOrder"), Integer)) = False
                        End If
                        If CType(Settings(oCodesTemp(i).Code + "_DESCR"), String) <> "" Then
                            oCodes(i).Description = CType(Settings(oCodesTemp(i).Code + "_DESCR"), String)
                        Else
                            oCodes(i).Description = oCodesTemp(i).Description
                        End If
                        i += 1
                    End While
                End If

                AreAllItemChecked = True
                AreAllSubMenuChecked = True

                If Not (Request.Params("__EVENTTARGET") Is Nothing) Then
                    If Request.Params("__EVENTTARGET").IndexOf("cmdUpdate") >= 0 Then
                        UpDateItemCodes()
                    Else
                        dgAvailable.DataSource = oCodes
                        dgAvailable.DataBind()
                        UpDateItemCodes()
                    End If
                Else
                    dgAvailable.DataSource = oCodes
                    dgAvailable.DataBind()
                    UpDateItemCodes()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try


        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' Project	 : ProductDirectory
        ''' Class	 : DNN.Modules.ProductDirectory.ProductDirectoryEdit
        ''' 
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vcolac]	4/17/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSybsystemFromListBox() As String
            Dim strSubsystem As String = String.Empty
            Dim iFirst As Integer = 0
            Dim iLoopCounter As Integer

            If ListBoxBaseSubsystem.SelectedIndex > -1 Then
                For iLoopCounter = 0 To ListBoxBaseSubsystem.Items.Count - 1
                    If ListBoxBaseSubsystem.Items(iLoopCounter).Selected = True Then
                        Dim strTemp As String
                        strTemp = ListBoxBaseSubsystem.Items(iLoopCounter).Value
                        If iFirst = 0 Then
                            strSubsystem = strSubsystem & strTemp
                            iFirst = 1
                        Else
                            strSubsystem = strSubsystem & "," & strTemp
                        End If
                    End If
                Next
            End If
            Return strSubsystem
        End Function

        Private Sub SetPage()
            If CType(Settings("maxCols"), String) <> "" Then
                txtMaxCols.Text = CType(Settings("maxCols"), String)
            Else
                txtMaxCols.Text = "2"
            End If

            If CType(Settings("Direction"), Integer) <> 0 Then
                setDirection.SelectedIndex = CType(Settings("Direction"), Integer)
            Else
                setDirection.SelectedIndex = 0  'Horizontal
            End If

            If CType(Settings("Navigation"), String) <> "" Then
                optNavigation.Items.FindByValue(CType(Settings("Navigation"), String)).Selected = True
                If CType(Settings("Navigation"), String) = "D" Then
                    txtMaxCols.Visible = True         ' Directory
                    lblColumns.Visible = True
                    lblRepeat.Visible = True
                    SetDirection.Visible = True
                Else
                    txtMaxCols.Visible = False        'Menu or TreeView
                    lblColumns.Visible = False
                    lblRepeat.Visible = False
                    SetDirection.Visible = False
                End If
            Else
                optNavigation.SelectedIndex = 0       ' Directory
                txtMaxCols.Visible = True
                lblColumns.Visible = True
                lblRepeat.Visible = True
                SetDirection.Visible = True
            End If

            If CType(Settings("Source"), String) <> "" Then
                optSource.Items.FindByValue(CType(Settings("Source"), String)).Selected = True
            Else
                optSource.SelectedIndex = 0          ' Product Class
            End If

            If CType(Settings("ProductSubsystem"), String) <> "" Then
                Dim strSubsystem As String = String.Empty
                Dim iLoopCounter As Integer
                Dim str() As String = Split(CType(Settings("ProductSubsystem"), String), ",")
                For iLoopCounter = 0 To str.Length - 1
                    ListBoxBaseSubsystem.Items.FindByValue(str(iLoopCounter)).Selected = True
                Next
            Else
                ListBoxBaseSubsystem.SelectedIndex = 0
            End If

            ctlURL.Url = CType(Settings("Url"), String)
            ctlURL.UrlType = CType(Settings("UrlType"), String)

        End Sub
        Protected Sub UpdateSelectedItems(ByVal sender As Object, ByVal e As CommandEventArgs)
            Try
                ' Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    objModules.UpdateTabModuleSetting(TabModuleId, "ProductSubsystem", GetSybsystemFromListBox())
                    objModules.UpdateTabModuleSetting(TabModuleId, "Source", optSource.SelectedItem.Value.ToString)

                    SetPage()

                    'Commented this code out as it is updating the module settings twice (3246-6119570)
                    'dgAvailable.DataSource = oCodes
                    'dgAvailable.DataBind()

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Sub UpDateItemCodes()
            Dim dgdItem As DataGridItem
            Dim ochkProduct, chkShowSubCats As CheckBox
            Dim flgNewData As Boolean = False
            Dim lblCode As Label
            ResetCodesModuleSettings()
            For Each dgdItem In Me.dgAvailable.Items
                lblCode = CType(dgdItem.FindControl("lblNewItemCode"), Label)
                ochkProduct = CType(dgdItem.FindControl("chkAddNewItem"), CheckBox)
                Dim txtDescr As TextBox = CType(dgdItem.FindControl("txtNewItemDescr"), TextBox)
                chkShowSubCats = CType(dgdItem.FindControl("chkViewSubMenu"), CheckBox)
                If ochkProduct.Checked Then
                    If chkShowSubCats.Checked Then
                        objModules.UpdateTabModuleSetting(TabModuleId, lblCode.Text, "YY")
                    Else
                        objModules.UpdateTabModuleSetting(TabModuleId, lblCode.Text, "NY")
                    End If
                End If
                If txtDescr.Text <> ocodes(dgdItem.ItemIndex).Description Then
                    objModules.UpdateTabModuleSetting(TabModuleId, lblCode.Text + "_DESCR", txtDescr.Text)
                End If

                Dim drpSortOrder As DropDownList = CType(dgdItem.FindControl("drpSortOrder"), DropDownList)
                If drpSortOrder IsNot Nothing Then
                    If ochkProduct.Checked Then
                        'Update or Delete the sort order only if it is inluded (3246-6119570)
                        objModules.UpdateTabModuleSetting(TabModuleId, lblCode.Text & "_SortOrder", drpSortOrder.SelectedValue)
                    Else
                        objModules.DeleteModuleSetting(TabModuleId, lblCode.Text & "_SortOrder")
                    End If
                End If
                Dim txtIconImageURL As TextBox = CType(dgdItem.FindControl("txtIconImageURL"), TextBox)
                If txtIconImageURL IsNot Nothing Then
                    objModules.UpdateTabModuleSetting(TabModuleId, lblCode.Text & "_IconImageURL", txtIconImageURL.Text)
                End If
            Next
        End Sub

        Sub ResetCodesModuleSettings()
            Dim TabModuleSettings As Hashtable = objModules.GetTabModuleSettings(TabModuleId)
            Dim CountTabModuleSettings As Integer = TabModuleSettings.Count
            Dim Values(CountTabModuleSettings) As String
            Dim Keys(CountTabModuleSettings) As String
            Dim i As Integer
            TabModuleSettings.Values.CopyTo(Values, 0)
            TabModuleSettings.Keys.CopyTo(Keys, 0)
            For i = 0 To CountTabModuleSettings
                If Values(i) = "YY" Or Values(i) = "NY" Then    'If Values(i) = "YY" Or Values(i) = "NY" Then
                    objModules.UpdateTabModuleSetting(TabModuleId, Keys(i), "NN")   'objModules.UpdateTabModuleSetting(TabModuleId, Keys(i), "NN")
                End If
            Next
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

        Private Sub dgAvailable_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgAvailable.ItemDataBound

            Dim ochkProduct As CheckBox = CType(e.Item.FindControl("chkAddNewItem"), CheckBox)
            Dim chkShowSubCats As CheckBox = CType(e.Item.FindControl("chkViewSubMenu"), CheckBox)


            Dim flgNewData As Boolean = False
            Dim lblCode As Label

            If CType(Settings("Source"), String) = "S" Then
                e.Item.Cells(2).Visible = False
            End If

            lblCode = CType(e.Item.FindControl("lblNewItemCode"), Label)

            If e.Item.ItemType = ListItemType.Header Then
                chkSelectAllAddNewItem = CType(e.Item.FindControl("chkSelectAllAddNewItem"), CheckBox)
                chkSelectAllSubMenuItems = CType(e.Item.FindControl("chkSelectAllSubMenuItems"), CheckBox)
            End If
            Dim drpSortOrder As DropDownList = CType(e.Item.FindControl("drpSortOrder"), DropDownList)
            If drpSortOrder IsNot Nothing Then
                With drpSortOrder
                    .Items.Clear()
                    For i As Integer = 1 To CType(dgAvailable.DataSource, ApplicationManager.PersonifyDataObjects.ApplicationCodes).Count
                        .Items.Add(New ListItem(CStr(i), CStr(i)))
                    Next
                    If Not Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_SortOrder") Is Nothing Then
                        .SelectedValue = CType(Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_SortOrder"), String)
                    Else
                        'If it doesn't have a sort order get the next availabe sort (3246-6119570)
                        .SelectedValue = CType(GetNextAvailableSort(), String)
                    End If
                    .Attributes.Add("onChange", "javascript: sortChanged(""" & drpSortOrder.ClientID & """, " & CType(dgAvailable.DataSource, ApplicationManager.PersonifyDataObjects.ApplicationCodes).Count & ");")
                End With
            End If
            Dim txtIconImageURL As TextBox = CType(e.Item.FindControl("txtIconImageURL"), TextBox)
            If txtIconImageURL IsNot Nothing Then
                With txtIconImageURL
                    If Not Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_IconImageURL") Is Nothing Then
                        .Text = CType(Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_IconImageURL"), String)
                    Else
                        .Text = "http://"
                    End If
                End With
            End If


            lblCode = CType(e.Item.FindControl("lblNewItemCode"), Label)
            If (e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem) Then
                'If IsPostBack Then
                Select Case CType(Settings(lblCode.Text), String)
                    Case "YY"
                        ochkProduct.Checked = True
                        chkShowSubCats.Checked = True
                    Case "NY"
                        ochkProduct.Checked = True
                        chkShowSubCats.Checked = False
                        AreAllSubMenuChecked = False
                    Case "NN"
                        ochkProduct.Checked = False
                        chkShowSubCats.Checked = False
                        AreAllItemChecked = False
                        AreAllSubMenuChecked = False
                    Case Nothing
                        ochkProduct.Checked = False
                        chkShowSubCats.Checked = False
                        AreAllItemChecked = False
                        AreAllSubMenuChecked = False
                End Select
            End If
            If e.Item.ItemType = ListItemType.Footer Then
                If AreAllItemChecked Then
                    chkSelectAllAddNewItem.Checked = True
                Else
                    chkSelectAllAddNewItem.Checked = False
                End If
                If AreAllSubMenuChecked Then
                    chkSelectAllSubMenuItems.Checked = True
                Else
                    chkSelectAllSubMenuItems.Checked = False
                End If
            End If

        End Sub

        'Added to Fix the sorting issues (3246-6119570)
        Public Function GetNextAvailableSort() As Integer
            Dim iNextAvailableSort As Integer
            For iNextAvailableSort = 1 To arrNextAvailableSort.Length - 1
                If arrNextAvailableSort(iNextAvailableSort) = True Then
                    arrNextAvailableSort(iNextAvailableSort) = False
                    Return iNextAvailableSort
                End If
            Next
        End Function
        'Added to Fix the sorting issues (3246-6119570)
        'Set Sort Settings from Module Settings and set available sort settings 
        Public Sub DeleteandSetSortSettings(ByRef oAailableCodes As ApplicationManager.PersonifyDataObjects.ApplicationCodes)
            Dim TabModuleSettings As Hashtable = objModules.GetTabModuleSettings(TabModuleId)
            Dim CountTabModuleSettings As Integer = TabModuleSettings.Count
            Dim Values(CountTabModuleSettings) As String
            Dim Keys(CountTabModuleSettings) As String
            Dim i, k As Integer
            Dim isCodeAvailable As Boolean

            'Initialize the Array
            'Make all the sorts available for the start
            For k = 0 To arrNextAvailableSort.Length - 1
                arrNextAvailableSort(k) = True
            Next

            TabModuleSettings.Keys.CopyTo(Keys, 0)
            TabModuleSettings.Values.CopyTo(Values, 0)

            'Delete all the previous sort settings
            'If the code is not available now

            For k = 0 To CountTabModuleSettings
                isCodeAvailable = False
                If Not Keys(k) Is Nothing Then
                    'If the Sort order exists for that code
                    If Keys(k).ToString.IndexOf("_SortOrder") > 0 Then
                        i = 0
                        While i < oAailableCodes.Count
                            'If the Code is included 
                            If Keys(k).ToString.IndexOf(oAailableCodes(i).Code.ToString) > 0 Then
                                isCodeAvailable = True
                                Exit While
                            End If
                            i += 1
                        End While
                        'If the Code is not included delete it from module settings
                        If isCodeAvailable = False Then
                            objModules.DeleteTabModuleSetting(TabModuleId, Keys(k))
                        End If
                    End If
                End If
            Next

        End Sub


#Region "Personify Data"

        Private Function df_GetProductRelatedActiveSubsystemList() As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            Dim oAllSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems
            Dim oActiveSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            oAllSubsystems = TIMSS.API.CachedApplicationData.ApplicationDataCache.SubSystems

            oActiveSubsystems = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ApplicationInfo, "ApplicationSubsystems")

            For i As Integer = 0 To oAllSubsystems.Count - 1
                If oAllSubsystems(i).ActiveFlag = True AndAlso oAllSubsystems(i).ProductFlag = True Then
                    oActiveSubsystems.Add(oAllSubsystems(i))
                End If
            Next

            Return oActiveSubsystems

        End Function

        Private Function df_GetListOfProductCategoryCodes(ByVal Subsystems As String) As ApplicationManager.PersonifyDataObjects.ApplicationCodes
            'Function Expects a comma separated string of subsystems

            Dim strCacheKey As String = PortalId & Subsystems & "ProductCategoryList"

            Dim oParameters As New TIMSS.SqlObjects.RequestParameters
            Dim oQueryResult As QueryResultCollection = Nothing

            Dim arraySubsystems() As String
            Dim strParameterName As String = ""

            Dim oAppCodes As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim oAppCode As ApplicationManager.PersonifyDataObjects.ApplicationCode

            Dim CodeRequests As TIMSS.SqlObjects.QueryRequestCollection = Nothing

            If PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then

                arraySubsystems = Subsystems.Split(",")
                For Each strSub As String In arraySubsystems
                    strParameterName = "SUBSYSTEM" & strSub
                    oParameters.Add(New RequestParameter(strParameterName, strSub))
                Next

                oParameters.Add(New RequestParameter("P_WEBFLAG", "Y"))
                oParameters.Add(New RequestParameter("P_ACTIVE", "Y"))
                oParameters.Add(New RequestParameter("P_TYPE", "PRODUCT_CATEGORY"))

                CodeRequests = New TIMSS.SqlObjects.QueryRequestCollection

                CodeRequests.Add(New QueryRequest(GetSelectRequest_GetDistinctProductCategoryList(Subsystems), oParameters))
                CodeRequests.Add(New QueryRequest(GetSelectRequest_GetDistinctProductSubCategoryList(Subsystems), oParameters))

                oQueryResult = Me.PersonifyExecuteQueryRequest(CodeRequests)

                For Each oRow As DataRow In oQueryResult(0).DataSet.Tables(0).Rows
                    oAppCode = oAppCodes.AddNewCode
                    oAppCode.Code = oRow.Item("code")
                    oAppCode.Description = oRow.Item("descr")

                    oAppCode.SubCodes = df_ReturnSubCodesForProductCategory(oRow.Item("code"), oQueryResult(1).DataSet)

                Next
                PersonifyDataCache.Store(strCacheKey, oAppCodes, PersonifyDataCache.CacheExpirationInterval)
            Else
                oAppCodes = CType(PersonifyDataCache.Fetch(strCacheKey), ApplicationManager.PersonifyDataObjects.ApplicationCodes)
            End If

            Return oAppCodes

        End Function


        Private Function GetSelectRequest_GetDistinctProductCategoryList(ByVal Subsystems As String) As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("DistinctProductCategoryCodes")

            Dim ocolSubsystems As ISelectedColumn = New SelectedColumn("AC", "SUBSYSTEM")

            request.Distinct = True

            Dim tblAppCode As SelectTable = New SelectTable("APP_CODE", "AC")
            tblAppCode.ResultColumns.Add("code")
            tblAppCode.ResultColumns.Add("descr")
            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblAppCode)

            request.Parameters.Add("AC", "AVAILABLE_TO_WEB_FLAG", "P_WEBFLAG", "Y")
            request.Parameters.Add("AC", "ACTIVE_FLAG", "P_ACTIVE", "Y")
            request.Parameters.Add("AC", "TYPE", "P_TYPE", "PRODUCT_CATEGORY")
            Dim isIn As IsInExpression = New IsInExpression(ocolSubsystems)
            Dim arraySubsystems() As String
            Dim strParameterName As String = ""
            Dim P1 As IParameterItem


            arraySubsystems = Subsystems.Split(",")
            For Each strSub As String In arraySubsystems
                strParameterName = "SUBSYSTEM" & strSub
                P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strSub)
                isIn.Items.Add(P1.ConstructParameterExpression)
                request.Parameters.Add(P1)
            Next

            request.WhereExpressions.Add(isIn)

            Return request
        End Function

        Private Function GetSelectRequest_GetDistinctProductSubCategoryList(ByVal Subsystems As String) As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("DistinctProductSubCategoryCodes")

            Dim ocolSubsystems As ISelectedColumn = New SelectedColumn("ASC", "SUBSYSTEM")

            request.Distinct = True

            Dim tblAppCode As SelectTable = New SelectTable("APP_SUBCODE", "ASC")
            tblAppCode.ResultColumns.Add("code")
            tblAppCode.ResultColumns.Add("subcode")
            tblAppCode.ResultColumns.Add("descr")
            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblAppCode)

            request.Parameters.Add("ASC", "ACTIVE_FLAG", "P_ACTIVE", "Y")
            request.Parameters.Add("ASC", "TYPE", "P_TYPE", "PRODUCT_CATEGORY")
            Dim isIn As IsInExpression = New IsInExpression(ocolSubsystems)
            Dim arraySubsystems() As String
            Dim strParameterName As String = ""
            Dim P1 As IParameterItem


            arraySubsystems = Subsystems.Split(",")
            For Each strSub As String In arraySubsystems
                strParameterName = "SUBSYSTEM" & strSub
                P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strSub)
                isIn.Items.Add(P1.ConstructParameterExpression)
                request.Parameters.Add(P1)
            Next

            request.WhereExpressions.Add(isIn)

            Return request
        End Function

        Private Function df_ReturnSubCodesForProductCategory(ByVal Code As String, ByVal pDataSet As DataSet) As ApplicationManager.PersonifyDataObjects.ApplicationSubCodes

            Dim oAppSubCodes As ApplicationManager.PersonifyDataObjects.ApplicationSubCodes = Nothing
            Dim oAppSubCode As ApplicationManager.PersonifyDataObjects.ApplicationSubCode

            For Each oRow As DataRow In pDataSet.Tables(0).Select("code = " & TIMSS.Common.Functions.QuoteString(Code))

                If oAppSubCodes Is Nothing Then
                    oAppSubCodes = New ApplicationManager.PersonifyDataObjects.ApplicationSubCodes
                End If

                oAppSubCode = oAppSubCodes.AddNewSubCode

                oAppSubCode.Code = oRow.Item("code")
                oAppSubCode.SubCode = oRow.Item("subcode")
                oAppSubCode.Description = oRow.Item("descr")
            Next

            Return oAppSubCodes

        End Function

        Private Function df_GetListOfProductClassCodes(ByVal Subsystems As String) As ApplicationManager.PersonifyDataObjects.ApplicationCodes
            'Function Expects a comma separated string of subsystems

            Dim strCacheKey As String = PortalId & Subsystems & "ProductClassList"
            Dim oParameters As New Hashtable
            Dim oQueryResult As IQueryResult

            Dim arraySubsystems() As String
            Dim strParameterName As String = ""
            Dim oAppCodes As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim oAppCode As ApplicationManager.PersonifyDataObjects.ApplicationCode

            If PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then

                arraySubsystems = Subsystems.Split(",")
                For Each strSub As String In arraySubsystems
                    strParameterName = "SUBSYSTEM" & strSub
                    oParameters.Add(strParameterName, strSub)
                Next

                oParameters.Add("P_WEBFLAG", "Y")
                oParameters.Add("P_ACTIVE", "Y")
                oParameters.Add("P_TYPE", "PRODUCT_CLASS")
                oQueryResult = Me.PersonifyExecuteQueryRequest(GetSelectRequest_GetDistinctProductClassList(Subsystems), oParameters)


                For Each oRow As DataRow In oQueryResult.DataSet.Tables(0).Rows
                    oAppCode = oAppCodes.AddNewCode
                    oAppCode.Code = oRow.Item("code")
                    oAppCode.Description = oRow.Item("descr")
                Next

                PersonifyDataCache.Store(strCacheKey, oAppCodes, PersonifyDataCache.CacheExpirationInterval)
            Else
                oAppCodes = CType(PersonifyDataCache.Fetch(strCacheKey), ApplicationManager.PersonifyDataObjects.ApplicationCodes)
            End If

            Return oAppCodes


        End Function

        Private Function GetSelectRequest_GetDistinctProductClassList(ByVal Subsystems As String) As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("DistinctProductClassCodes")

            Dim ocolSubsystems As ISelectedColumn = New SelectedColumn("AC", "SUBSYSTEM")

            request.Distinct = True

            Dim tblAppCode As SelectTable = New SelectTable("APP_CODE", "AC")
            tblAppCode.ResultColumns.Add("code")
            tblAppCode.ResultColumns.Add("descr")
            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblAppCode)

            request.Parameters.Add("AC", "AVAILABLE_TO_WEB_FLAG", "P_WEBFLAG", "Y")
            request.Parameters.Add("AC", "ACTIVE_FLAG", "P_ACTIVE", "Y")
            request.Parameters.Add("AC", "TYPE", "P_TYPE", "PRODUCT_CLASS")
            Dim isIn As IsInExpression = New IsInExpression(ocolSubsystems)
            Dim arraySubsystems() As String
            Dim strParameterName As String = ""
            Dim P1 As IParameterItem


            arraySubsystems = Subsystems.Split(",")
            For Each strSub As String In arraySubsystems
                strParameterName = "SUBSYSTEM" & strSub
                P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strSub)
                isIn.Items.Add(P1.ConstructParameterExpression)
                request.Parameters.Add(P1)
            Next

            request.WhereExpressions.Add(isIn)

            Return request
        End Function
#End Region
    End Class

End Namespace
