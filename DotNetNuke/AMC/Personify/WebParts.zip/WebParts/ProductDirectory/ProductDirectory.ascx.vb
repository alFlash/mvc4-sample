Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects



Imports System
Imports System.Web.UI.WebControls
Imports DotNetNuke.Entities.Tabs
Imports Personify
Imports TIMSS.SqlObjects




Namespace Personify.DNN.Modules.ProductDirectory
    ''' -----------------------------------------------------------------------------
    ''' Project	 : ProductDirectory
    ''' Class	 : DNN.Modules.ProductDirectory.ProductDirectory
    ''' 
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[vcolac]	4/17/2006	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------


    Public MustInherit Class ProductDirectory
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


#Region "Controls"

        Protected WithEvents pnlDirectory As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlCodes As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlSubCodes As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlTreeView As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMenu As System.Web.UI.WebControls.Panel
        Protected WithEvents ProductTreeView As System.Web.UI.WebControls.TreeView
        Protected WithEvents mnuProduct As System.Web.UI.WebControls.Menu
        Protected WithEvents lstProducts As System.Web.UI.WebControls.DataList
        Protected WithEvents Label1 As System.Web.UI.WebControls.Label
        Protected WithEvents HyperLinkBack As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblColumns As System.Web.UI.WebControls.Label
        Protected WithEvents ProdCodesList As System.Web.UI.WebControls.DataList
        Protected WithEvents ProdSubCodesList As System.Web.UI.WebControls.DataList
        Protected WithEvents tvwProduct As System.Web.UI.WebControls.TreeView
        Protected WithEvents Hyperlink1 As System.Web.UI.WebControls.LinkButton

#End Region

        Public strSubsystem As String = String.Empty
        Shared iIndexCategory As Integer
        Public ProdId As String
        'Dim oProdListingID As New DotNetNuke.Entities.Tabs.TabController
        Dim oProductCodes As ApplicationManager.PersonifyDataObjects.ApplicationCodes
        Dim oAppSubCodes As ApplicationManager.PersonifyDataObjects.ApplicationSubCodes

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            
            Try
                'Subsystem filter
                strSubsystem = CType(Settings("ProductSubsystem"), String)
                Try
                    'ProdId = oProdListingID.GetTabByName("ProductListings", 0).TabID.ToString()
                    ProdId = CType(Settings("Url"), String)

                    'get the products Class or Category codes 
                    If strSubsystem <> "" Then
                        oProductCodes = GetAppCodes(strSubsystem)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("LabelNoProducts.Text", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        oProductCodes = GetAppCodes("")
                    End If

                Catch exc As Exception
                    'error message: The ProductListing module it hasn't been installed
                    'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("LabelNoProductsModule.Text", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try
                
                If CType(Settings("Navigation"), String) <> "" Then
                    Select Case CType(Settings("Navigation"), String)
                        Case "D"
                            Directory()
                            pnlDirectory.Visible = True
                            pnlMenu.Visible = False
                            pnlTreeView.Visible = False
                        Case "M"
                            pnlDirectory.Visible = False
                            Menu()
                            pnlMenu.Visible = True
                            pnlTreeView.Visible = False
                        Case "T"
                            pnlDirectory.Visible = False
                            pnlMenu.Visible = False
                            TreeView()
                            pnlTreeView.Visible = True
                    End Select
                Else
                    pnlDirectory.Visible = True
                    pnlMenu.Visible = False
                    pnlTreeView.Visible = False
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub
        Private Sub ProdCodesList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles ProdCodesList.ItemDataBound
            Dim imgIconImageURL As Image = CType(e.Item.FindControl("imgIcon1"), Image)
            If imgIconImageURL IsNot Nothing Then
                With imgIconImageURL
                    If Not Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_IconImageURL") Is Nothing AndAlso CType(Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_IconImageURL"), String) <> String.Empty Then
                        .ImageUrl = CType(Settings(CType(e.Item.DataItem, ApplicationManager.PersonifyDataObjects.ApplicationCode).Code & "_IconImageURL"), String)
                    Else
                        '3246-5848465
                        .ImageUrl = GetFolderImageURL()
                        'end 3246-5848465
                    End If
                End With
            End If
        End Sub
        ''' -----------------------------------------------------------------------------
        ''' Project	 : ProductDirectory
        ''' Class	 : DNN.Modules.ProductDirectory.ProductDirectory
        ''' 
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetoAppCodes
        ''' </summary>
        ''' <remarks>
        ''' "YY"= means that both "Show SubMenu Items" and "Include" are checked 
        ''' "NY"= means that "Show SubMenu Items" is unchecked and "Include" is checked 
        ''' "NN"= means that both "Show SubMenu Items" and "Include" are unchecked 
        ''' </remarks>
        ''' <history>
        ''' 	[vcolac]	4/17/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------

        Private Function GetAppCodes(ByVal strSubsystem As String) As ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim oAppCodes, oAppCodesTemp As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim StringClassInclude As String = String.Empty
            Dim StringCode() As String
            Dim j, i As Integer

            If CType(Settings("Source"), String) = "S" Then

                'returns All ClassCodes which have products
                StringClassInclude = GetStringClassInclude()
                StringCode = StringClassInclude.Split(CChar(","))
                oAppCodesTemp = df_GetProductClassCodesForAllWebProducts(StringCode)
                j = 0
                i = 0
                'load just included ClassCodes 
                While j < oAppCodesTemp.Count
                    If StringClassInclude.Contains(oAppCodesTemp(j).Code.ToString) Then
                        oAppCodes.AddNewCode()
                        oAppCodes(i).Code = oAppCodesTemp(j).Code
                        If CType(Settings(oAppCodesTemp(j).Code + "_DESCR"), String) <> "" Then
                            oAppCodes(i).Description = CType(Settings(oAppCodesTemp(j).Code + "_DESCR"), String)
                        Else
                            oAppCodes(i).Description = oAppCodesTemp(j).Description
                        End If
                        i += 1
                    End If
                    j += 1
                End While
            Else
                'return CategoryCodes
                StringClassInclude = GetStringClassInclude()
                StringCode = StringClassInclude.Split(CChar(","))

                oAppCodesTemp = df_GetProductCategoryAndSubCategoriesForAllWebProducts(StringCode)
                j = 0
                i = 0

                'load just included CategoryCodes
                While j < oAppCodesTemp.Count
                    If StringClassInclude.Contains(oAppCodesTemp(j).Code.ToString) Then
                        If CType(Settings(oAppCodesTemp(j).Code), String) = "YY" Then
                            oAppCodes.AddNewCode()
                            oAppCodes(i).Code = oAppCodesTemp(j).Code
                            If CType(Settings(oAppCodesTemp(j).Code + "_DESCR"), String) <> "" Then
                                oAppCodes(i).Description = CType(Settings(oAppCodesTemp(j).Code + "_DESCR"), String)
                            Else
                                oAppCodes(i).Description = oAppCodesTemp(j).Description
                            End If
                            oAppCodes(i).SubCodes = oAppCodesTemp(j).SubCodes
                        Else
                            oAppCodes.AddNewCode()
                            oAppCodes(i).Code = oAppCodesTemp(j).Code
                            If CType(Settings(oAppCodesTemp(j).Code + "_DESCR"), String) <> "" Then
                                oAppCodes(i).Description = CType(Settings(oAppCodesTemp(j).Code + "_DESCR"), String)
                            Else
                                oAppCodes(i).Description = oAppCodesTemp(j).Description
                            End If
                        End If
                        i += 1
                    End If
                    j += 1
                End While
            End If
            Return oAppCodes
        End Function

        Function GetStringClassInclude() As String
            Dim StringClassInclude As String = String.Empty
            Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
            Dim TabModuleSettings As Hashtable = objModules.GetTabModuleSettings(TabModuleId)
            Dim CountTabModuleSettings As Integer = TabModuleSettings.Count
            Dim Values(CountTabModuleSettings) As String
            Dim Keys(CountTabModuleSettings) As String

            TabModuleSettings.Keys.CopyTo(Keys, 0)
            TabModuleSettings.Values.CopyTo(Values, 0)

            Dim i As Integer
            For i = 0 To CountTabModuleSettings
                If Values(i) = "YY" Or Values(i) = "NY" Then
                    If i > 0 And StringClassInclude <> "" Then
                        StringClassInclude += ","
                    End If
                    StringClassInclude += Keys(i)
                End If
            Next
            Return StringClassInclude
        End Function


        Private Sub Directory()
            Try

                Dim oSProducts As Hashtable = SortProducts(oProductCodes)
                Dim oSortedProducts As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
                Dim keys(oSProducts.Keys.Count) As Integer
                oSProducts.Keys.CopyTo(keys, 0)
                For key As Integer = 1 To max(keys)
                    If oSProducts.ContainsKey(key) Then
                        oSortedProducts.Add(CType(oSProducts(key), ApplicationManager.PersonifyDataObjects.ApplicationCode))
                    End If
                Next
                ProdCodesList.DataSource = oSortedProducts
                ProdCodesList.DataBind()

                If CType(Settings("Source"), String) = "Y" Then
                    If Not (Page.Request.Url Is Nothing) And Request.QueryString("category") IsNot Nothing Then
                        Dim strTest As String = String.Empty
                        Dim iIndex As Integer = -1

                        For Each oProducts As ApplicationManager.PersonifyDataObjects.ApplicationCode In oSortedProducts
                            iIndex += 1
                            If oProducts.Code = Request.QueryString("category") Then
                                pnlSubCodes.Visible = True
                                pnlCodes.Visible = False
                                ProdSubCodesList.DataSource = oProductCodes.Item(iIndex).SubCodes
                                HyperLinkBack.Text = oProductCodes.Item(iIndex).Description & " categorie" & " (" & Services.Localization.Localization.GetString("HyperLinkBack.Text", Me.LocalResourceFile) & ")"
                                HyperLinkBack.NavigateUrl = Me.Request.UrlReferrer.OriginalString
                                ProdSubCodesList.DataBind()

                                If ProdSubCodesList.Items.Count = 0 Then
                                    Response.Redirect(NavigateURL(CInt(ProdId), "", "category=" & oProductCodes.Item(iIndexCategory).Code))
                                End If

                            End If

                        Next

                    End If
                End If


            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

            If CType(Settings("maxCols"), String) <> "" Then
                ProdCodesList.RepeatColumns = Convert.ToInt32(CType(Settings("maxCols"), String))
            Else
                ProdCodesList.RepeatColumns = 1
            End If

            If CType(Settings("Direction"), Integer) = 0 Then
                ProdCodesList.RepeatDirection = RepeatDirection.Horizontal
            Else
                ProdCodesList.RepeatDirection = RepeatDirection.Vertical
            End If

        End Sub

        Private Sub Menu()
            Dim iItem As Integer = 0
            Dim oSortedProducts As Hashtable = SortProducts(oProductCodes)
            Dim keys(oSortedProducts.Keys.Count) As Integer
            oSortedProducts.Keys.CopyTo(keys, 0)
            For key As Integer = 1 To max(keys)
                If oSortedProducts.ContainsKey(key) Then
                    Dim oProducts As ApplicationManager.PersonifyDataObjects.ApplicationCode = CType(oSortedProducts(key), ApplicationManager.PersonifyDataObjects.ApplicationCode)
                    Dim icon As String
                    If Settings(oProducts.Code & "_IconImageURL") IsNot Nothing Then
                        icon = CType(Settings(oProducts.Code & "_IconImageURL"), String)
                    Else
                        '3246-5774803
                        icon = GetFolderImageURL()
                        'end 3246-5774803
                    End If
                    Dim newItem As MenuItem = New MenuItem(Trim(oProducts.Description), Trim(oProducts.Description), icon)
                    If CType(Settings("Source"), String) = "Y" Then
                        If oProductCodes.Item(iItem).SubCodes IsNot Nothing Then
                            For Each oProductsubcodes As ApplicationManager.PersonifyDataObjects.ApplicationSubCode In oProductCodes.Item(iItem).SubCodes
                                Dim newChildMenu As MenuItem = New MenuItem(oProductsubcodes.Description)
                                newItem.ChildItems.Add(newChildMenu)
                                If oProductsubcodes.SubCode = "ALL" Then
                                    newChildMenu.NavigateUrl = NavigateURL(CInt(ProdId), "", "Category=" & oProducts.Code)
                                Else
                                    newChildMenu.NavigateUrl = NavigateURL(CInt(ProdId), "", "Category=" & oProducts.Code & "&Subcategory=" & oProductsubcodes.SubCode)
                                End If
                            Next
                        Else
                            newItem.NavigateUrl = NavigateURL(CInt(ProdId), "", "Category=" & oProducts.Code)
                        End If

                    Else
                        newItem.NavigateUrl = NavigateURL(CInt(ProdId), "", "Class=" & oProducts.Code)
                    End If
                    mnuProduct.Items.Add(newItem)
                    mnuProduct.Visible = True
                    iItem += 1
                End If
            Next
            pnlMenu.HorizontalAlign = HorizontalAlign.Left
            pnlMenu.Controls.Add(mnuProduct)
            pnlMenu.DataBind()
        End Sub

        Private Sub TreeView()
            Dim NodeRootRow As Integer = -1

            Dim iItem As Integer = 0
            Dim ParentNode As String = Nothing
            Dim ChildNode As String = Nothing
            Dim LastNodeSet As String = Nothing

            tvwProduct.Nodes.Clear()

            Dim oSortedProducts As Hashtable = SortProducts(oProductCodes)
            Dim keys(oSortedProducts.Keys.Count) As Integer
            oSortedProducts.Keys.CopyTo(keys, 0)
            For key As Integer = 1 To max(keys)
                If oSortedProducts.ContainsKey(key) Then
                    Dim ProductClass As ApplicationManager.PersonifyDataObjects.ApplicationCode = CType(oSortedProducts(key), ApplicationManager.PersonifyDataObjects.ApplicationCode)

                    Dim icon As String
                    If Settings(ProductClass.Code & "_IconImageURL") IsNot Nothing Then
                        icon = CType(Settings(ProductClass.Code & "_IconImageURL"), String)
                    Else
                        '3246-5774803
                        icon = GetFolderImageURL()
                        'end 3246-5774803
                    End If
                    Dim newNode As New TreeNode(ProductClass.Description, ProductClass.Description, icon)
                    newNode.SelectAction = TreeNodeSelectAction.Expand
                    newNode.Expanded = False
                    If CType(Settings("Source"), String) = "Y" Then
                        If oProductCodes.Item(iItem).SubCodes IsNot Nothing Then
                            For Each oProductsubcodes As ApplicationManager.PersonifyDataObjects.ApplicationSubCode In oProductCodes.Item(iItem).SubCodes
                                '3246-5774803
                                Dim newChildNode As New TreeNode(oProductsubcodes.Description, oProductsubcodes.Description, GetFolderImageURL())
                                'end 3246-5774803
                                newChildNode.SelectAction = TreeNodeSelectAction.Select
                                If oProductsubcodes.SubCode = "ALL" Then
                                    newChildNode.NavigateUrl = NavigateURL(CInt(ProdId), "", "Category=" & ProductClass.Code)
                                Else
                                    newChildNode.NavigateUrl = NavigateURL(CInt(ProdId), "", "Category=" & ProductClass.Code & "&SubCategory=" & oProductsubcodes.SubCode)
                                End If
                                newNode.ChildNodes.Add(newChildNode)
                            Next
                        Else
                            newNode.NavigateUrl = NavigateURL(CInt(ProdId), "", "Category=" & ProductClass.Code)
                        End If
                    Else
                        newNode.NavigateUrl = NavigateURL(CInt(ProdId), "", "Class=" & ProductClass.Code)
                    End If
                    tvwProduct.Nodes.Add(newNode)
                    iItem += 1
                End If
            Next
            pnlTreeView.Controls.Add(tvwProduct)
            pnlTreeView.DataBind()
        End Sub

        Public Sub GetCategory(ByVal Src As Object, ByVal Args As DataListCommandEventArgs)
            iIndexCategory = Args.Item.ItemIndex

            If CType(Settings("Source"), String) = "Y" Then
                Response.Redirect(NavigateURL(CInt(TabId), "", "Category=" & oProductCodes.Item(iIndexCategory).Code))
            Else
                Response.Redirect(NavigateURL(CInt(ProdId), "", "Class=" & oProductCodes.Item(iIndexCategory).Code))
            End If
        End Sub

        Sub GetSubCategory(ByVal Src As Object, ByVal Args As DataListCommandEventArgs)
            If oProductCodes.Item(iIndexCategory).SubCodes.Item(Args.Item.ItemIndex).SubCode = "ALL" Then
                Response.Redirect(NavigateURL(CInt(ProdId), "", "Category=" & oProductCodes.Item(iIndexCategory).Code))
            Else
                Response.Redirect(NavigateURL(CInt(ProdId), "", "Category=" & oProductCodes.Item(iIndexCategory).Code & "&subcategory=" & oProductCodes.Item(iIndexCategory).SubCodes.Item(Args.Item.ItemIndex).SubCode))
            End If
        End Sub

        Function SortProducts(ByVal oProducts As ApplicationManager.PersonifyDataObjects.ApplicationCodes) As Hashtable
            Dim oTempProducts As New Hashtable
            For Each oProduct As ApplicationManager.PersonifyDataObjects.ApplicationCode In oProducts
                oTempProducts(CType(Settings(oProduct.Code & "_SortOrder"), Integer)) = oProduct
            Next
            Return oTempProducts

        End Function
        Function max(ByVal keys() As Integer) As Integer
            max = keys(0)
            For i As Integer = 0 To keys.Length - 1
                If max < keys(i) Then
                    max = keys(i)
                End If
            Next
        End Function

#End Region
#Region "Image Functions"
        '3246-5774803       
        Private Function GetFolderImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/folder.gif")
        End Function
        'END 3246-5774803
#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "Personify data"

        Private Function df_GetProductClassCodesForAllWebProducts(ByVal ProductClassCodes() As String) As ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim strCacheKey As String = PortalId & "ProductDirectory_ClassCodes"

            For Each Item As String In ProductClassCodes
                If Item.Length > 0 Then
                    strCacheKey = strCacheKey & Item.Substring(0, 1)
                End If
            Next

            Dim strParameterName As String
            Dim oParameters As New Hashtable
            Dim oQueryResult As IQueryResult
            Dim oAppCodes As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim oAppCode As ApplicationManager.PersonifyDataObjects.ApplicationCode

            If PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then

                For Each strSub As String In ProductClassCodes
                    strParameterName = "PRODUCTCLASSCODES" & strSub
                    If oParameters.Item(strParameterName) Is Nothing Then
                        oParameters.Add(strParameterName, strSub)
                    End If
                Next

                oParameters.Add("P_AppType", "PRODUCT_CLASS")

                oQueryResult = Me.PersonifyExecuteQueryRequest(GetSelectRequest_GetProductClassCodesForAllWebProducts(ProductClassCodes), oParameters)


                For Each oRow As DataRow In oQueryResult.DataSet.Tables(0).Rows
                    oAppCode = oAppCodes.AddNewCode
                    oAppCode.Code = oRow.Item("product_class_code")
                    oAppCode.Description = oRow.Item("descr")
                Next

                PersonifyDataCache.Store(strCacheKey, oAppCodes, PersonifyDataCache.CacheExpirationInterval)
            Else
                oAppCodes = CType(PersonifyDataCache.Fetch(strCacheKey), ApplicationManager.PersonifyDataObjects.ApplicationCodes)
            End If

            Return oAppCodes

        End Function

        Private Function GetSelectRequest_GetProductClassCodesForAllWebProducts(ByVal ProductClassCodes() As String) As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("DistinctProductClassCodes")

            Dim tblWeb As ISelectTable = New SelectTable("tmar_web_product_vw", "web")
            Dim tblAppCode As ISelectTable = New SelectTable("APP_CODE", "AC")


            Dim ocolProductClassCode As ISelectedColumn = New SelectedColumn("web", "PRODUCT_CLASS_CODE")

            request.Distinct = True


            tblWeb.ResultColumns.Add("product_class_code")
            tblAppCode.ResultColumns.Add("descr")
            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblWeb)
            request.Tables.Add(tblAppCode)

            Dim tableJoin As TableJoin = New TableJoin("Normal join", tblWeb, tblAppCode, JoinType.Normal)
            tableJoin.ColumnJoins.Add(New ColumnJoin("PRODUCT_CLASS_CODE", "CODE"))
            tableJoin.ColumnJoins.Add(New ColumnJoin("SUBSYSTEM", "SUBSYSTEM"))

            request.TableJoins.Add(tableJoin)

            request.Parameters.Add("AC", "TYPE", "P_AppType", "PRODUCT_CLASS")

            Dim isIn As IsInExpression = New IsInExpression(ocolProductClassCode)

            Dim strParameterName As String = ""
            Dim P1 As IParameterItem

            For Each strSub As String In ProductClassCodes
                strParameterName = "PRODUCTCLASSCODES" & strSub
                If request.Parameters.Item(strParameterName) Is Nothing Then
                    P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strSub)
                    isIn.Items.Add(P1.ConstructParameterExpression)
                    request.Parameters.Add(P1)
                End If
            Next

            request.WhereExpressions.Add(isIn)

            Return request
        End Function

        Private Function GetSelectRequest_GetProductCategoryAndSubCategoriesForAllWebProducts(ByVal ProductCategories() As String) As IBaseRequest


            'Expected Query -------------------------------------------------------------------------------
            'select             distinct  pc.CATEGORY, psc.SUB_CATEGORY , a.descr ,b.descr
            'from               TMAR_WEB_PRODUCT_VW t 
            'left outer join    product_category pc     on t.product_id = pc.product_id
            'left outer join    product_sub_category psc on pc.PRODUCT_CATEGORY_ID = psc.        PRODUCT_CATEGORY_ID
            'inner join app_code a on pc.CATEGORY = a.code and a.subsystem = 'ORD' and a.type = 'PRODUCT_CATEGORY'	
            'left outer join app_subcode b on psc.SUB_CATEGORY = b.SUBCODE and b.subsystem = 'ORD' and 
            '			b.type = 'PRODUCT_CATEGORY'						
            'where 	pc.category in ( 'VIDEO' , 'AUDIO' , 'ABC','BOOKS' )
            '----------------------------------------------------------------------------------------------
            Dim request As ISelectRequest = New SelectRequest("DistinctProductCategoryCodes")

            Dim tblWeb As ISelectTable = New SelectTable("tmar_web_product_vw", "web")
            Dim tblProductCategory As ISelectTable = New SelectTable("product_category", "pc")
            Dim tblProductSubCategory As ISelectTable = New SelectTable("product_sub_category", "psc")
            Dim tblAppCode As ISelectTable = New SelectTable("app_code", "ac")
            Dim tblAppSubCode As ISelectTable = New SelectTable("app_subcode", "asc")

            'Set distinct
            request.Distinct = True
            '
            'Expected Results in Dataset


            tblProductCategory.ResultColumns.Add("category", "category")
            tblProductSubCategory.ResultColumns.Add("sub_category", "subcategory")
            tblAppCode.ResultColumns.Add("descr", "categorydescr")
            tblAppSubCode.ResultColumns.Add("descr", "subcategorydescr")

            'Add tables to Request Object
            request.Tables.Add(tblWeb)
            request.Tables.Add(tblProductCategory)
            request.Tables.Add(tblProductSubCategory)
            request.Tables.Add(tblAppCode)
            request.Tables.Add(tblAppSubCode)

            'left outer join product_category pc  on t.product_id = pc.product_id
            Dim tblOuterJoin_web_pc As TableJoin = New TableJoin("tblOuterJoin_web_pc", tblWeb, tblProductCategory, JoinType.LeftOuterJoin)
            tblOuterJoin_web_pc.ColumnJoins.Add(New ColumnJoin("product_id", "product_id"))
            request.TableJoins.Add(tblOuterJoin_web_pc)

            'left outer join PRODUCT_SUB_CATEGORY psc on pc.PRODUCT_CATEGORY_ID = psc.PRODUCT_CATEGORY_ID
            Dim tblOuterJoin_pc_psc As TableJoin = New TableJoin("tblOuterJoin_pc_psc", tblProductCategory, tblProductSubCategory, JoinType.LeftOuterJoin)
            tblOuterJoin_pc_psc.ColumnJoins.Add(New ColumnJoin("product_category_id", "product_category_id"))

            request.TableJoins.Add(tblOuterJoin_pc_psc)

            'left outer join app_subcode b on psc.SUB_CATEGORY = b.SUBCODE and b.subsystem = 'ORD' and b.type = 'PRODUCT_CATEGORY'		
            Dim tblOuterJoin_psc_asc As TableJoin = New TableJoin("tblOuterJoin_psc_asc", tblProductSubCategory, tblAppSubCode, JoinType.LeftOuterJoin)
            tblOuterJoin_psc_asc.ColumnJoins.Add(New ColumnJoin("sub_category", "subcode"))

            tblOuterJoin_psc_asc.ColumnJoins.Add(New ColumnJoin(New Column("asc", "code"), New Column("pc", "category")))

            request.TableJoins.Add(tblOuterJoin_psc_asc)


            'inner join app_code a on pc.CATEGORY = a.code and a.subsystem = 'ORD' and a.type = 'PRODUCT_CATEGORY'	
            Dim tblInnerJoin_pc_ac As TableJoin = New TableJoin("tblInnerJoin_pc_ac", tblProductCategory, tblAppCode, JoinType.InnerJoin)


            tblInnerJoin_pc_ac.ColumnJoins.Add(New ColumnJoin("category", "code"))

            request.TableJoins.Add(tblInnerJoin_pc_ac)





            'request.Parameters.Add("ac", "type", "p_ac_type", "PRODUCT_CATEGORY")
            'request.Parameters.Add("ac", "subsystem", "p_ac_subsystem", "ORD")

            'request.Parameters.Add("asc", "type", "p_asc_type", "PRODUCT_CATEGORY")
            'request.Parameters.Add("asc", "subsystem", "p_asc_subsystem", "ORD")


            Dim ocolProductCategory As ISelectedColumn = New SelectedColumn("pc", "category")

            Dim isIn As IsInExpression = New IsInExpression(ocolProductCategory)

            Dim strParameterName As String = ""
            Dim P1 As IParameterItem
            'Dim int as Integer = 0
            For Each strSub As String In ProductCategories
                strParameterName = "PRODUCTCATEGORYCODES" & strSub
                If request.Parameters.Item(strParameterName) Is Nothing Then
                    P1 = New ParameterItem(String.Empty, String.Empty, strParameterName, strSub)
                    isIn.Items.Add(P1.ConstructParameterExpression)
                    request.Parameters.Add(P1)
                End If
            Next

            request.WhereExpressions.Add(isIn)

            Return request
        End Function

        Private Function df_GetProductCategoryAndSubCategoriesForAllWebProducts(ByVal ProductCategories() As String) As ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim strCacheKey As String = PortalId & "ProductDirectory_ProductCategories"

            For Each Item As String In ProductCategories
                If Item.Length > 0 Then
                    strCacheKey = strCacheKey & Item.Substring(0, 1)
                End If
            Next

            Dim strParameterName As String
            Dim oParameters As New Hashtable
            Dim oQueryResult As IQueryResult
            Dim oAppCodes As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
            'Dim oAppCode As ApplicationCode


            If PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then

                For Each strSub As String In ProductCategories
                    strParameterName = "PRODUCTCATEGORYCODES" & strSub
                    If oParameters.Item(strParameterName) Is Nothing Then
                        oParameters.Add(strParameterName, strSub)
                    End If
                Next

                'oParameters.Add("p_ac_type", "PRODUCT_CATEGORY")
                'oParameters.Add("p_ac_subsystem", "ORD")
                'oParameters.Add("p_asc_type", "PRODUCT_CATEGORY")
                'oParameters.Add("p_asc_subsystem", "ORD")

                oQueryResult = Me.PersonifyExecuteQueryRequest(GetSelectRequest_GetProductCategoryAndSubCategoriesForAllWebProducts(ProductCategories), oParameters)

                oAppCodes = ConstructDistinctListOfCategoryAndSubCategory(oQueryResult.DataSet)

                PersonifyDataCache.Store(strCacheKey, oAppCodes, PersonifyDataCache.CacheExpirationInterval)
            Else
                oAppCodes = CType(PersonifyDataCache.Fetch(strCacheKey), ApplicationManager.PersonifyDataObjects.ApplicationCodes)
            End If

            Return oAppCodes



        End Function

        Private Function ConstructDistinctListOfCategoryAndSubCategory(ByVal DS As DataSet) As ApplicationManager.PersonifyDataObjects.ApplicationCodes
            ' Dataset has 1 table and columns names - category,subcategory,categorydescr,subcategorydescr

            Dim oAppCodes As New ApplicationManager.PersonifyDataObjects.ApplicationCodes
            Dim oAppCode As ApplicationManager.PersonifyDataObjects.ApplicationCode

            'Create Distinct List Of Category from the dataset
            For Each oRow As DataRow In DS.Tables(0).Rows
                If Not CheckIfCategoryExistsInCollection(oRow.Item("category"), oAppCodes) Then
                    oAppCode = oAppCodes.AddNewCode
                    oAppCode.Code = oRow.Item("category")
                    oAppCode.Description = oRow.Item("categorydescr")
                End If
            Next

            'For each category, create a distinct list of Sub Categories ... In addition create one more sub category called ALL
            Dim oAppSubCode As ApplicationManager.PersonifyDataObjects.ApplicationSubCode
            Dim oAppSubCodes As New ApplicationManager.PersonifyDataObjects.ApplicationSubCodes
            For Each oAppCode In oAppCodes
                oAppSubCodes = New ApplicationManager.PersonifyDataObjects.ApplicationSubCodes
                For Each oRow1 As DataRow In DS.Tables(0).Select("category = '" & oAppCode.Code & "'")
                    If Not oRow1.Item("subcategory") Is System.DBNull.Value Then
                        oAppSubCode = oAppSubCodes.AddNewSubCode
                        oAppSubCode.Code = oAppCode.Code
                        oAppSubCode.Description = oRow1.Item("subcategorydescr")
                        oAppSubCode.SubCode = oRow1.Item("subcategory")
                    End If
                Next
                oAppSubCode = oAppSubCodes.AddNewSubCode
                oAppSubCode.Code = oAppCode.Code
                oAppSubCode.SubCode = "ALL"
                oAppSubCode.Description = "All Sub Categories"

                oAppCode.SubCodes = oAppSubCodes
            Next

            Return oAppCodes
        End Function

        Private Function CheckIfCategoryExistsInCollection(ByVal Category As String, ByVal AppCodes As ApplicationManager.PersonifyDataObjects.ApplicationCodes) As Boolean

            Dim oComparer As New CaseInsensitiveComparer
            Dim bReturn As Boolean = False

            For Each Code As ApplicationManager.PersonifyDataObjects.ApplicationCode In AppCodes
                If oComparer.Compare(Code.Code, Category) = 0 Then
                    bReturn = True
                End If
            Next

            Return bReturn

        End Function


#End Region
    End Class

End Namespace