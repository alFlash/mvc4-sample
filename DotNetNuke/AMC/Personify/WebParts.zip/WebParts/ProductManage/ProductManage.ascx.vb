Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Imports TIMSS.API.core

Namespace Personify.DNN.Modules.ProductManage

    Public MustInherit Class ProductManage
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable


#Region "Controls"
        Protected WithEvents PLDataPager As WebControls.DataPager
        Protected WithEvents TestLabel As System.Web.UI.WebControls.Label
        'Protected WithEvents tdContent As System.Web.UI.HtmlControls.HtmlTableCell
        Protected PLXslTemplate As WebControls.XslTemplate

        Protected WithEvents GridWebControlListing As New System.Web.UI.WebControls.GridView
        Protected WithEvents butSave As System.Web.UI.WebControls.Button

        Protected WithEvents lblError As New Label
        Protected WithEvents lblSubSystem As New Label
        Protected WithEvents lblProductDescr As New Label

        Protected WithEvents chkActive As New CheckBox
        Protected WithEvents chkFeatured As New CheckBox
        Protected WithEvents chkPromo As New CheckBox

        Protected WithEvents txtDescription As New TextBox
        Protected WithEvents butSearch As New Button
        Protected WithEvents ddlSubsystem As New DropDownList
        'Protected WithEvents fvWebControlDetail As FormView

        Protected WithEvents teContent As DotNetNuke.UI.UserControls.TextEditor
        Protected WithEvents butSaveDescription As Button
        Protected WithEvents btnBack As LinkButton
        Protected WithEvents btnUpload As Button

        Protected WithEvents PanelDisplayControls As Panel
        Protected WithEvents PanelTxtManage As Panel
        Protected WithEvents lblProductId As Label
        Protected WithEvents rblImageType As RadioButtonList
        Protected WithEvents rbltextOption As RadioButtonList

        'Protected WithEvents txtFilepath As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents fileUploadImages As FileUpload

        Protected WithEvents File1 As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents lblErrUpload As Label

        Private _WebProductControls As TIMSS.API.ProductInfo.IProductWebControls
        Private _globalVariables As XSLFileGlobalVariables

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'If Not (UserInfo.IsSuperUser OrElse isHostOrAdminLogged()) Then

                If Not isHostOrAdminLogged() Then
                    PanelDisplayControls.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("UnauthorizedAccess.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End If



                'Using global variables to determine the control name
                _globalVariables = GetGlobalVariables()
                If Settings("Layout") IsNot Nothing Then
                    AddTemplate()
                    If Not IsPostBack() Then
                        SetupControls()
                    End If
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoLayoutSelected.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Sub butSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butSave.Click


            Dim strProductIds As System.Text.StringBuilder

            strProductIds = GetCurrentProductIds()

            _WebProductControls = df_GetWebProductControls("", WebProductAttributeEnum.None, False, strProductIds.ToString)

            If _WebProductControls IsNot Nothing AndAlso _WebProductControls.Count > 0 Then

                Dim item As System.Web.UI.WebControls.GridViewRow
                For Each item In GridWebControlListing.Rows

                    Dim ctlProducutId As Label = item.FindControl("lblProductId")

                    For Each oProductWebControl As TIMSS.API.ProductInfo.IProductWebControl In Me._WebProductControls

                        If oProductWebControl.ProductId = ctlProducutId.Text Then
                            'Save all possible fields(not child collection) under product web control object
                            UpdateRow(item, oProductWebControl)
                        End If
                    Next

                Next
                _WebProductControls.Save()
            End If


        End Sub


        Private Sub butSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butSearch.Click

            If ddlSubsystem.SelectedIndex = 0 And Me.txtDescription.Text.Trim = "" Then
                lblError.Visible = True
                lblError.Attributes.Add("resourcekey", "lblError_MissingCriteria")

                GridWebControlListing.Visible = False
                Exit Sub
            End If

            GetData()
            Dim searchSize As Integer = 50
            If Settings("SearchSize") IsNot Nothing AndAlso CStr(Settings("SearchSize")).Trim <> "" Then
                searchSize = CInt(Settings("SearchSize").ToString)
            End If
            'Fixed if there are no search results found
            'added Me._WebProductControls IsNot Nothing Check if there are no records returned
            If Me._WebProductControls IsNot Nothing AndAlso Me._WebProductControls.Count > searchSize Then
                lblError.Visible = True
                Dim errorMessage As String = Localization.GetString("lblError_SearchSize.Text", LocalResourceFile)
                'lblError.Attributes.Add("resourcekey", "lblError_SearchSize")
                lblError.Text = errorMessage & " " & searchSize.ToString
                GridWebControlListing.Visible = False
            Else
                GridWebControlListing.Visible = True
                GridWebControlListing.PageIndex = 0

                BindData()
            End If
           
        End Sub

        Private Sub GridWebControlListing_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridWebControlListing.PageIndexChanging
            GridWebControlListing.PageIndex = e.NewPageIndex
            GetData()
            '_WebProductControls = ViewState("PersonifyProductControls")
            BindData()
        End Sub

        Private Sub GridWebControlListing_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridWebControlListing.RowCommand
            If e.CommandName = "ShowDetail" Then

                Dim productId As String = e.CommandArgument

                DisplayTextImageSection(productId)

            End If

        End Sub

        Private Sub GridWebControlListing_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridWebControlListing.RowDataBound


            If e.Row.RowType = DataControlRowType.DataRow Then

                If e.Row.RowState = DataControlRowState.Normal Or e.Row.RowState = DataControlRowState.Alternate Then

                    With e.Row
                        Dim oWebProductControl As TIMSS.API.ProductInfo.IProductWebControl

                        oWebProductControl = e.Row.DataItem

                        Dim lblShortName As Label
                        Dim lblProductCode As Label
                        Dim lblProductID As Label
                        Dim butManage As Button
                        lblShortName = .FindControl("lblShortName")
                        lblProductCode = .FindControl("lblProductCode")
                        lblProductID = .FindControl("lblProductID")
                        butManage = .FindControl("butManage")

                        lblShortName.Text = oWebProductControl.Product.ShortName
                        lblProductCode.Text = oWebProductControl.Product.ProductCode
                        lblProductID.Text = oWebProductControl.ProductId
                        butManage.CommandArgument = oWebProductControl.ProductId
                        Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oWebProductControl)
                        For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                            Dim ctl As Control = .FindControl("ctl_" & _globalVariables.ModuleId & "_" & _globalVariables.ProductWebControl & "_" & pd.Name)

                            If ctl IsNot Nothing Then

                                Dim valueObject As Object = oWebProductControl.GetPropertyValue(pd.Name)
                                Select Case ctl.GetType.Name.ToUpper
                                    Case "CHECKBOX"
                                        Dim tmpCheckBox As CheckBox = CType(ctl, CheckBox)
                                        tmpCheckBox.Checked = GetPersonifyPropertyValue(valueObject)
                                    Case "TEXTBOX"
                                        Dim tmpTextbox As TextBox = CType(ctl, TextBox)
                                        tmpTextbox.Text = GetPersonifyPropertyValue(valueObject)
                                    Case "LABEL"
                                        Dim tmpLabel As Label = CType(ctl, Label)
                                        tmpLabel.Text = GetPersonifyPropertyValue(valueObject)
                                    Case "DROPDOWNLIST"
                                        'to do?
                                End Select
                            End If
                        Next

                    End With
                End If
            End If
        End Sub

        Private Sub UpdateRow(ByVal item As GridViewRow, ByRef oProductWebControl As TIMSS.API.ProductInfo.IProductWebControl)

            Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oProductWebControl)


            For Each pd As ComponentModel.PropertyDescriptor In cPropDesc

                Dim ctl As Control = item.FindControl("ctl_" & _globalVariables.ModuleId & "_" & _globalVariables.ProductWebControl & "_" & pd.Name)

                If ctl IsNot Nothing Then

                    Dim valueObject As Object = oProductWebControl.GetPropertyValue(pd.Name)
                    Dim propertyInfo As TIMSS.API.Core.IPropertyInfo
                    propertyInfo = CType(oProductWebControl.Schema(pd.Name), TIMSS.API.Core.IPropertyInfo)

                    Dim coreObject As TIMSS.API.Core.BusinessObject
                    coreObject = CType(oProductWebControl, TIMSS.API.Core.BusinessObject)

                    Select Case ctl.GetType.Name.ToUpper
                        Case "CHECKBOX"
                            Dim tmpCheckBox As CheckBox = CType(ctl, CheckBox)
                            coreObject.SetPropertyValue(propertyInfo, ConvertBooleanType(tmpCheckBox.Checked))

                        Case "TEXTBOX"
                            Dim tmpTextbox As TextBox = CType(ctl, TextBox)
                            coreObject.SetPropertyValue(propertyInfo, tmpTextbox.Text)

                        Case "DROPDOWNLIST"
                            Dim tmpDropdown As DropDownList = CType(ctl, DropDownList)
                            coreObject.SetPropertyValue(propertyInfo, tmpDropdown.SelectedValue)
                    End Select
                End If


            Next

        End Sub


        Private Sub butSaveDescription_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butSaveDescription.Click

            Select Case rbltextOption.SelectedValue

                Case "1"
                    'Short text
                    df_UpdateWebProductTextList(lblProductId.Text, "EN-US", "WEB_SHORT", teContent.RichText.Text)

                Case "2"
                    'Long text
                    df_UpdateWebProductTextList(lblProductId.Text, "EN-US", "WEB_LONG", teContent.RichText.Text)

            End Select

        End Sub

        Private Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
            PanelDisplayControls.Visible = True
            PanelTxtManage.Visible = False
        End Sub

      

        Private Sub rbltextOption_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbltextOption.SelectedIndexChanged

            Dim oWebProductTextList As TIMSS.API.ProductInfo.IProductTextList
            Dim oWebproductText As TIMSS.API.ProductInfo.IProductText
            Dim productId As String = lblProductId.Text
            Select Case rbltextOption.SelectedValue
                Case "1"
                    'short text
                    oWebProductTextList = df_GetWebProductTextList(productId, "EN-US", "WEB_SHORT")
                    If oWebProductTextList IsNot Nothing AndAlso oWebProductTextList.Count > 0 Then
                        oWebproductText = oWebProductTextList(0)
                        Me.teContent.Text = oWebproductText.Text
                    End If
                Case "2"
                    'long text
                    oWebProductTextList = df_GetWebProductTextList(productId, "EN-US", "WEB_LONG")
                    If oWebProductTextList IsNot Nothing AndAlso oWebProductTextList.Count > 0 Then
                        oWebproductText = oWebProductTextList(0)
                        Me.teContent.Text = oWebproductText.Text
                    End If
            End Select
        End Sub

        Private Sub btnUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpload.Click

            lblErrUpload.Visible = False
            If Page.IsValid Then
                lblErrUpload.Visible = True
                If UploadImageFileToWebserver(lblProductId.Text, rblImageType.SelectedIndex) Then
                    lblErrUpload.Text = Localization.GetString("lblErrUpload_Success.Text", LocalResourceFile)
                Else
                    lblErrUpload.Text = Localization.GetString("lblErrUpload_Fail.Text", LocalResourceFile)
                End If
            End If


        End Sub

#End Region

#Region "Helper function"


        Private Function isHostOrAdminLogged() As Boolean

            Dim isAdmin As Boolean = False
            

            If UserInfo.IsInRole("Administrators") OrElse UserInfo.IsInRole("Host") Then
                isAdmin = True
            End If

            Return isAdmin
   
        End Function
        Private Sub SetupControls()

            Dim oSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems = df_GetProductRelatedActiveSubsystemList()

            If oSubsystems IsNot Nothing Then
                Me.ddlSubsystem.DataSource = oSubsystems
                Me.ddlSubsystem.DataValueField = "Subsystem"
                Me.ddlSubsystem.DataTextField = "SubsystemName"
                ddlSubsystem.DataBind()
                ddlSubsystem.Items.Insert(0, New ListItem("", ""))
            End If

        End Sub
        Private Sub GetData()


            Dim strProductIds As New System.Text.StringBuilder

            'Get the product ids related to description [ShortName],[LongName]
            If Me.txtDescription.Text.Trim <> "" Then
                Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList
                oWebProducts = df_GetWebProducts(Me.ddlSubsystem.SelectedValue, txtDescription.Text.Trim, txtDescription.Text.Trim)
                If oWebProducts IsNot Nothing And oWebProducts.Count > 0 Then
                    For Each oWebProduct As TIMSS.API.WebInfo.ITmarWebProductView In oWebProducts
                        If strProductIds.ToString <> "" Then
                            strProductIds.Append(",")
                            strProductIds.Append(oWebProduct.ProductId)
                        Else
                            strProductIds.Append(oWebProduct.ProductId)
                        End If
                    Next
                Else
                    'empty result
                    _WebProductControls = Nothing
                    Exit Sub
                End If
            End If

            Dim isActiveCheckEnabled As Boolean = False
            isActiveCheckEnabled = chkActive.Checked

            If Not chkFeatured.Checked AndAlso Not chkPromo.Checked Then
                _WebProductControls = df_GetWebProductControls(Me.ddlSubsystem.SelectedValue, WebProductAttributeEnum.None, isActiveCheckEnabled, strProductIds.ToString)
            ElseIf chkFeatured.Checked AndAlso chkPromo.Checked Then
                _WebProductControls = df_GetWebProductControls(Me.ddlSubsystem.SelectedValue, WebProductAttributeEnum.Both, isActiveCheckEnabled, strProductIds.ToString)
            ElseIf chkFeatured.Checked Then
                _WebProductControls = df_GetWebProductControls(Me.ddlSubsystem.SelectedValue, WebProductAttributeEnum.Featured, isActiveCheckEnabled, strProductIds.ToString)
            ElseIf chkPromo.Checked Then
                _WebProductControls = df_GetWebProductControls(Me.ddlSubsystem.SelectedValue, WebProductAttributeEnum.Promotional, isActiveCheckEnabled, strProductIds.ToString)
            End If

        End Sub

        Private Sub BindData()

            If _WebProductControls IsNot Nothing AndAlso _WebProductControls.Count > 0 Then
                'LoadDataPager(oWebProductControls)
                butSave.Visible = True
                lblError.Visible = False
                GridWebControlListing.DataSource = _WebProductControls

                GridWebControlListing.PageSize = 15
                If Settings("GridPageSize") IsNot Nothing AndAlso CStr(Settings("GridPageSize")).Trim <> "" Then
                    GridWebControlListing.PageSize = CInt(Settings("GridPageSize").ToString)
                End If
                GridWebControlListing.DataBind()
            Else
                lblError.Visible = True
                lblError.Attributes.Add("resourcekey", "lblError_EmptyResult")
                GridWebControlListing.Visible = False
                butSave.Visible = False
            End If

        End Sub

        Private Sub AddTemplate()


            'Load template
            Dim templatefile As String = ""
            Try
                templatefile = ModulePath + "Templates\" + Settings("Layout").ToString()
            Catch ex As Exception
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End Try
            PLXslTemplate.XSLfile = Server.MapPath(templatefile)

            PLXslTemplate.AddObject("", _globalVariables)

            PLXslTemplate.Display()

            'Init each required control
            lblError = (CType(Me.FindControl("lblError".ToString), Label))
            lblSubSystem = (CType(Me.FindControl("lblSubSystem".ToString), Label))
            lblProductDescr = (CType(Me.FindControl("lblProductDescr".ToString), Label))

            chkActive = (CType(Me.FindControl("chkActive".ToString), CheckBox))
            chkFeatured = (CType(Me.FindControl("chkFeatured".ToString), CheckBox))
            chkPromo = (CType(Me.FindControl("chkPromo".ToString), CheckBox))

            txtDescription = (CType(Me.FindControl("txtDescription".ToString), TextBox))
            butSearch = (CType(Me.FindControl("butSearch".ToString), Button))
            ddlSubsystem = (CType(Me.FindControl("ddlSubsystem".ToString), DropDownList))

            GridWebControlListing = (CType(Me.FindControl("GridWebControlListing".ToString), GridView))


        End Sub

        Private Function GetPersonifyPropertyValue(ByVal PropertyObject As Object) As Object


            Select Case PropertyObject.GetType.Name.ToUpper
                'Case "STRING"
                'Case "BOOLEAN"
                'Case "INT32"
                'Case "INT64" 'Product id
                Case "DATETIME"
                    If CDate(PropertyObject) = "#12:00:00 AM#" Then
                        PropertyObject = ""
                    Else
                        PropertyObject = CDate(PropertyObject).ToString("MM/dd/yyyy")
                    End If

            End Select

            Return PropertyObject

        End Function

        Private Sub DisplayTextImageSection(ByVal productId As String)

            Dim oWebProductControls As TIMSS.API.ProductInfo.IProductWebControls
            oWebProductControls = df_GetWebProductControls("", WebProductAttributeEnum.None, False, productId)

            'Me.fvWebControlDetail.DataSource = oWebProductControls
            'fvWebControlDetail.DataBind()

            Dim oWebProductControl As TIMSS.API.ProductInfo.IProductWebControl
            oWebProductControl = oWebProductControls(0)
            Dim lblProductId As Label = Me.FindControl("lblProductId")
            lblProductId.Text = productId

            'Get Image setting
            If rblImageType.SelectedItem IsNot Nothing Then
                rblImageType.SelectedItem.Selected = False
            End If
            rblImageType.Items(0).Selected = True

            'Get Product text description
            Dim oWebProductTextList As TIMSS.API.ProductInfo.IProductTextList
            Dim oWebproductText As TIMSS.API.ProductInfo.IProductText

            oWebProductTextList = df_GetWebProductTextList(oWebProductControl.ProductId, "EN-US", "WEB_SHORT")
            If oWebProductTextList IsNot Nothing AndAlso oWebProductTextList.Count > 0 Then
                oWebproductText = oWebProductTextList(0)
                Me.teContent.Text = oWebproductText.Text
            Else
                Me.teContent.Text = " " 'Needs a space since it wont work for String.Empty
            End If
            If rbltextOption.SelectedItem IsNot Nothing Then
                rbltextOption.SelectedItem.Selected = False
            End If
            Me.rbltextOption.Items(0).Selected = True
            PanelDisplayControls.Visible = False

            PanelTxtManage.Visible = True

        End Sub

        Public Function GetGlobalVariables() As XSLFileGlobalVariables
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            globalVariables.ModuleId = ModuleId
            globalVariables.ProductWebControl = "ProductWebControl"

            Return globalVariables

        End Function

        ''' <summary>
        ''' ConvertBoolean value to Personify boolean value 
        ''' </summary>
        Private Function ConvertBooleanType(ByVal status As Boolean) As String
            If status Then
                Return "Y"
            End If
            Return "N"
        End Function

        Private Function GetCurrentProductIds() As System.Text.StringBuilder

            Dim strBuilder As New System.Text.StringBuilder

            For Each item As System.Web.UI.WebControls.GridViewRow In GridWebControlListing.Rows
                Dim ctlProducutId As Label = item.FindControl("lblProductId")
                If strBuilder.ToString <> "" Then
                    strBuilder.Append(",")
                    strBuilder.Append(ctlProducutId.Text.Trim)
                Else
                    strBuilder.Append(ctlProducutId.Text.Trim)
                End If
            Next

            Return strBuilder
        End Function

        Private Function UploadImageFileToWebserver(ByVal productId As String, ByVal typeImage As Integer) As Boolean

            Dim IsUploadSuccessful As Boolean = True
            Dim fileName As String = ""
            Dim directoryPath As String = ""
            Dim status As Boolean = False

            Try
                'check to see if any file is been selected   
                If fileUploadImages.HasFile Then

                    'fileName = fileUploadImages.FileName
                    'directoryPath = System.IO.Path.GetDirectoryName(fileUploadImages.PostedFile.FileName)
                    status = df_UploadProductImages(CInt(productId), fileUploadImages.PostedFile.FileName, typeImage)
                    Return status

                End If
            Catch ex As Exception

            End Try

            Return False


        End Function



#End Region

#Region "Optional Interfaces"


        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
            Return Nothing
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable

        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
            Return Nothing
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
            '3246-6770248
            If Framework.AJAX.IsInstalled Then
                Framework.AJAX.RegisterPostBackControl(butSaveDescription)
                DotNetNuke.Framework.AJAX.RegisterScriptManager()
            End If
            'END 3246-6770248
        End Sub

#End Region

#Region "Helper class"

        Public Class XSLFileGlobalVariables
            Public ModuleId As Integer
            Public ProductWebControl As String

        End Class

#End Region


#Region "Personify Data"
        Private Function df_GetWebProductControls(ByVal [Subsystem] As String, ByVal FeaturePromoEnum As WebProductAttributeEnum, Optional ByVal CheckActiveFlag As Boolean = False, Optional ByVal ProductIds As String = Nothing) As TIMSS.API.ProductInfo.IProductWebControls
            Dim oWebProductControls As TIMSS.API.ProductInfo.IProductWebControls

            oWebProductControls = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ProductInfo, "ProductWebControls")

            With oWebProductControls.Filter

                If CheckActiveFlag Then
                    .Add("ActiveFlag", "Y")
                End If

                .Add("EcommerceBeginDate", TIMSS.Enumerations.QueryOperatorEnum.LessThanOrEqual, Date.Today.ToString)

                Dim strSQLCondition As New System.Text.StringBuilder
                strSQLCondition.Append("( (Ecommerce_End_Date >= '")
                strSQLCondition.Append(TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day))
                strSQLCondition.Append("') or (Ecommerce_End_Date is NULL)) and product_id in(select p.product_id from product as p where Org_Id = '")
                strSQLCondition.Append(OrganizationId)
                strSQLCondition.Append("' and Org_Unit_Id = '")
                strSQLCondition.Append(OrganizationUnitId)
                If Subsystem <> "" Then
                    strSQLCondition.Append("' and p.subsystem = '")
                    strSQLCondition.Append([Subsystem])
                End If
                strSQLCondition.Append("' and p.product_id = product_id)")

                .Add(New TIMSS.API.Core.FilterItem(strSQLCondition.ToString))
                If ProductIds IsNot Nothing AndAlso ProductIds.Trim <> "" Then
                    .Add(New TIMSS.API.Core.FilterItem(" Product_ID in (" & ProductIds & " )"))
                End If

                Select Case FeaturePromoEnum

                    Case WebProductAttributeEnum.Both
                        'Feature
                        .Add("SpecialFeatureFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
                        .Add(New FilterItem("(Special_Feature_Begin_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Feature_Begin_Date IS NULL)"))
                        .Add(New FilterItem("( Special_Feature_End_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Feature_End_Date IS NULL)"))
                        'Promo 
                        .Add("SpecialPromoFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
                        .Add(New FilterItem("(Special_Promo_Begin_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Promo_Begin_Date IS NULL)"))
                        .Add(New FilterItem("(Special_Promo_End_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Promo_End_Date IS NULL)"))

                    Case WebProductAttributeEnum.Featured
                        .Add("SpecialFeatureFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
                        .Add(New FilterItem("(Special_Feature_Begin_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Feature_Begin_Date IS NULL)"))
                        .Add(New FilterItem("( Special_Feature_End_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Feature_End_Date IS NULL)"))

                    Case WebProductAttributeEnum.Promotional
                        .Add("SpecialPromoFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
                        .Add(New FilterItem("(Special_Promo_Begin_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Promo_Begin_Date IS NULL)"))
                        .Add(New FilterItem("(Special_Promo_End_Date >= " & TIMSS.Common.Functions.InvariantDateFormat(Date.Today.Year, Date.Today.Month, Date.Today.Day) & ") or (Special_Promo_End_Date IS NULL)"))

                    Case WebProductAttributeEnum.None
                        'No filter
                End Select


                oWebProductControls.Fill()

            End With

            Return oWebProductControls


        End Function


        Private Sub df_UpdateWebProductTextList(ByVal ProductId As Integer, ByVal Language As String, ByVal TextTypeCode As String, ByVal Text As String)

            Dim oProductTextList As TIMSS.API.ProductInfo.IProductTextList
            Dim oProductText As TIMSS.API.ProductInfo.IProductText

            oProductTextList = df_GetWebProductTextList(ProductId, Language, TextTypeCode)

            If oProductTextList IsNot Nothing And oProductTextList.Count > 0 Then

                oProductText = oProductTextList(0)
                oProductText.Text = Text

            Else
                oProductTextList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ProductInfo, "ProductTextList")
                oProductText = oProductTextList.AddNew()

                With oProductText
                    .ProductId = ProductId

                    Dim languageCode As TIMSS.API.Core.ICode
                    languageCode = CType(oProductText, TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oProductText.Schema("Language"), TIMSS.API.Core.ICodePropertyInfo))
                    .Language = .Language.List(Language).ToCodeObject
                    .TextTypeCode = .TextTypeCode.List(TextTypeCode).ToCodeObject
                    .Text = Text
                End With
            End If
            oProductTextList.Save()


        End Sub

        Private Function df_GetWebProductTextList(ByVal ProductId As Integer, ByVal Language As String, ByVal TextTypecode As String) As TIMSS.API.ProductInfo.IProductTextList

            Dim oProductTextList As TIMSS.API.ProductInfo.IProductTextList


            oProductTextList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ProductInfo, "ProductTextList")

            With oProductTextList.Filter

                .Add("Product_Id", TIMSS.Enumerations.QueryOperatorEnum.Equals, ProductId)
                .Add("language", TIMSS.Enumerations.QueryOperatorEnum.Equals, Language)
                .Add("TextTypeCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, TextTypecode)

                oProductTextList.Fill()
            End With

            Return oProductTextList

        End Function

        Private Function df_GetProductRelatedActiveSubsystemList() As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            Dim oAllSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems
            Dim oActiveSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            oAllSubsystems = TIMSS.API.CachedApplicationData.ApplicationDataCache.SubSystems

            oActiveSubsystems = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ApplicationInfo, "ApplicationSubsystems")

            For i As Integer = 0 To oAllSubsystems.Count - 1
                If oAllSubsystems(i).ActiveFlag = True AndAlso oAllSubsystems(i).ProductFlag = True Then
                    oActiveSubsystems.Add(oAllSubsystems(i))
                End If
            Next

            Return oActiveSubsystems

        End Function

        Private Function df_GetWebProducts(ByVal [Subsystem] As String, _
                   ByVal ShortName As String, ByVal LongName As String) As TIMSS.API.WebInfo.ITmarWebProductViewList

            Dim oWebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList


            oWebProducts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebProductViewList")

            With oWebProducts.Filter
                If [Subsystem].Trim <> "" Then
                    .Add("Subsystem", TIMSS.Enumerations.QueryOperatorEnum.Equals, Subsystem)
                End If
                If ShortName.Trim <> "" AndAlso LongName.Trim <> "" Then
                    Dim sqlCondition As New System.Text.StringBuilder
                    sqlCondition.Append("( Short_Name like '%")
                    sqlCondition.Append(ShortName)
                    sqlCondition.Append("%' OR Long_Name like '%")
                    sqlCondition.Append(LongName)
                    sqlCondition.Append("%' )")
                    .Add(New TIMSS.API.Core.FilterItem(sqlCondition.ToString))
                ElseIf LongName.Trim <> "" Then
                    .Add("LongName", TIMSS.Enumerations.QueryOperatorEnum.Contains, LongName)
                ElseIf ShortName.Trim <> "" Then
                    .Add("ShortName", TIMSS.Enumerations.QueryOperatorEnum.Contains, ShortName)
                End If

            End With

            oWebProducts.Fill()

            Return oWebProducts


        End Function

        Private Function df_UploadProductImages(ByVal ProductId As Integer, ByVal fileName As String, ByVal typeImage As Integer) As Boolean




            Dim status As String = ""
            Try
                status = TIMSS.ThirdPartyInterfaces.FileOperation.UploadFile(TIMSS.Server.BusinessMessages.FileUploadDownload.UploadResourceType.ProductImages, fileName)

                If status.Length > 1 Then

                    Dim aProducts As TIMSS.API.ProductInfo.IProducts
                    aProducts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ProductInfo, "Products")
                    aProducts.Filter.Add("ProductId", ProductId.ToString)
                    aProducts.Fill()


                    If aProducts IsNot Nothing AndAlso aProducts.Count > 0 Then

                        Dim oProduct As TIMSS.API.ProductInfo.IProduct
                        oProduct = aProducts(0)
                        If typeImage = 0 Then
                            'small image
                            oProduct.WebControl.SmallImageFileName = System.IO.Path.GetFileName(fileName)
                        ElseIf typeImage = 1 Then
                            'large image
                            oProduct.WebControl.LargeImageFileName = System.IO.Path.GetFileName(fileName)
                        End If
                        aProducts.Save()

                    End If

                End If

            Catch ex As Exception
                Return False
            End Try
            Return True

        End Function


#End Region

     
    End Class

End Namespace
