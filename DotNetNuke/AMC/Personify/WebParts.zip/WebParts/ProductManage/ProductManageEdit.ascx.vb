Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.io

Namespace Personify.DNN.Modules.ProductManage

    Public MustInherit Class ProductManageEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"

        Private Const C_TEMPLATES As String = "Templates"
        Private Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents DropDownList_Layout As DropDownList
        Protected WithEvents txtGridSize As TextBox
        Protected WithEvents txtSearchSize As TextBox

#End Region



#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try


                If Not IsPostBack Then

                    If Not DropDownList_Layout.Items.Count > 0 Then
                        Dim li As ListItem
                        DropDownList_Layout.Items.Add(New ListItem("   ", ""))
                        For Each li In GetTemplates()
                            DropDownList_Layout.Items.Add(li)
                        Next
                        DropDownList_Layout.SelectedIndex = DropDownList_Layout.Items.IndexOf(DropDownList_Layout.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                    End If

                    If Settings("SearchSize") IsNot Nothing Then
                        txtSearchSize.Text = Settings("SearchSize")
                    End If

                    If Settings("GridPageSize") IsNot Nothing Then
                        txtGridSize.Text = Settings("GridPageSize")
                    End If

                End If
               

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

                    UpdateModuleSetting("Layout", DropDownList_Layout.SelectedValue)
                    UpdateModuleSetting("SearchSize", txtSearchSize.Text)
                    UpdateModuleSetting("GridPageSize", txtGridSize.Text)
                  
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
            
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "helper function"

        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem
                ' Create a reference to the current directory.
                Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
                Dim fiTemp As FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function
#End Region
    End Class

End Namespace
