Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects



Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.MyOrderBalance.Business
Imports TIMSS.SqlObjects


Namespace Personify.DNN.Modules.MyOrderBalance

    Public MustInherit Class MyOrderBalance
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm



#Region "Controls"
        Protected WithEvents xslOrderBalance As WebControls.XslTemplate

        'Protected WithEvents lblOrderBalance As System.Web.UI.WebControls.Label
        Protected WithEvents hlnkPayNow As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents lblOutStandingBalanceText As System.Web.UI.WebControls.Label
        Protected WithEvents divButton As System.Web.UI.WebControls.Panel

#End Region
      
#Region "Event Handlers"
        
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try

                Dim role As String
                role = Me.GetUserRole(UserInfo)

                If Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin" Then
                    '3246-7278052
                    'If Not Page.IsPostBack Then
                    'If strMCID <> "" Then
                    If Me.IsPersonifyWebUserLoggedIn = True Then
                        LoadOrderBalance()
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    End If

                    'End If
                Else
                lblMessage.Visible = False
                divButton.Visible = False
                lblOutStandingBalanceText.Visible = False
                Me.DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub



        Private Sub LoadOrderBalance()

            Dim OrderBalance As Decimal
            OrderBalance = DF_GetMyOrderBalance(PortalId, MasterCustomerId, SubCustomerId)

            xslOrderBalance.XSLfile = Server.MapPath(ModulePath + "/Templates/MyOrderBalanceTemplate.xsl")
            Dim strOrderBalance As String = FormatNumber(OrderBalance, 2, TriState.True, TriState.True, TriState.True)


            If OrderBalance = 0 OrElse UserInfo.IsSuperUser Then
                divButton.Visible = False
                hlnkPayNow.Visible = False
                lblMessage.Visible = True
                'lblOrderBalance.Visible = False
                lblOutStandingBalanceText.Visible = False
            Else
                hlnkPayNow.NavigateUrl = NavigateURL(CInt(Settings(ModuleSettingsNames.MyOrderBalancePayUrl)))
                hlnkPayNow.Visible = True
                divButton.Visible = True
                lblMessage.Visible = False
                'ANMC
                Dim Symbol As String = Me.PortalCurrency.Symbol

                xslOrderBalance.AddObject("Symbol", Symbol)
                xslOrderBalance.AddObject("OrderBalance", strOrderBalance)
                xslOrderBalance.Display()
            End If

        End Sub


        Private Function DF_GetMyOrderBalance(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer) As Decimal


            Dim strCacheKey As String = ""
            Dim nAmount As Decimal = 0

            Dim oQueryResult As TIMSS.SqlObjects.IQueryResult
            Dim oParameters As New Hashtable
            oParameters.Add("P_BILL_MCID", MasterCustomerId)
            oParameters.Add("P_BILL_SCID", SubCustomerId)
            oParameters.Add("P_CurrencyCode", PortalCurrency.Code)

            oQueryResult = PersonifyExecuteQueryRequest(GetSelectRequest_GetOrderBalance, oParameters)

            If oQueryResult.Success Then
                If oQueryResult.DataSet.Tables(0).Rows.Count > 0 Then
                    If Not oQueryResult.DataSet.Tables(0).Rows(0).Item(0) Is System.DBNull.Value Then
                        nAmount = oQueryResult.DataSet.Tables(0).Rows(0).Item(0)
                    End If

                End If
            End If

            'ANMC - Multi Currency Changes
            'The order balance amount is in base currency, this needs to be converted to the portal currency



            Return ConvertPriceFromBaseToPortalCurrency(nAmount)

        End Function
       
        Private Function GetSelectRequest_GetOrderBalance() As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("GetOrderBalance")

            Dim tblObv As SelectTable = New SelectTable("order_balance_vw", "obv")


            Dim oColBalance As ISelectedColumn = New SelectedColumn("obv", "base_balance_amount")
            request.SelectExpressions.Add(New InvokeFunctionExpression("sum", "sum", oColBalance))

            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblObv)
            request.Parameters.Add("obv", "bill_master_customer_id", "P_BILL_MCID", String.Empty)
            request.Parameters.Add("obv", "bill_sub_customer_id", "P_BILL_SCID", String.Empty)
            request.Parameters.Add("obv", "currency_code", "P_CurrencyCode", String.Empty)

            Return request
        End Function

    End Class

    

End Namespace
