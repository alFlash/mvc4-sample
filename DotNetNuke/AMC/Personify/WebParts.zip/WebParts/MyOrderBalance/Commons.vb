Namespace Personify.DNN.Modules.MyOrderBalance

    Public Class ModuleSettingsNames
        Public Const MyOrderBalancePayUrl As String = "MyOrderBalancePayUrl"
        Public Const MyOrderBalancePayUrlType As String = "MyOrderBalancePayUrlType"
    End Class

End Namespace