Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml
Imports System.Xml.XPath
Imports System.IO

Imports TIMSS.API.Core
Imports TIMSS.DataAccess
Imports TIMSS.SqlObjects
Imports TIMSS.Interfaces



Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports Telerik.Web.UI


Namespace Personify.DNN.Modules.AdvanceMeeting


    Public MustInherit Class AdvanceMeetingMenu
        Inherits AdvanceMeetingBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

        Protected WithEvents PanelBarList As RadPanelBar
        Protected WithEvents lblDaysLeft As Label
        Protected WithEvents butRegisterNow As Button
        Protected WithEvents LinkForLinkedIn As System.Web.UI.HtmlControls.HtmlAnchor
        Protected WithEvents imgSmallImage As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents pnlSocial As Panel


        Protected WithEvents butUpdateNow As Button
        Private _AssignedAgendaSessions As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

#End Region

#Region "Properties"
        Public ReadOnly Property AssignedAgendaSessions() As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
            Get
                If _AssignedAgendaSessions Is Nothing Then
                    _AssignedAgendaSessions = AdvanceMeetingManager.MyMeetingAgenda_Get(Me.MasterCustomerId, Me.SubCustomerId, GetMeetingId)
                End If
                Return _AssignedAgendaSessions
            End Get
        End Property

#End Region

#Region "Event Handlers"

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
            If Framework.AJAX.IsInstalled Then
                DotNetNuke.Framework.AJAX.RegisterScriptManager()
            End If

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            SetupControls()
        End Sub

        Private Sub butRegisterNow_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butRegisterNow.Click
            'http://localhost/Personify/ShoppingCart/OrderCreate/tabid/135/MODE/AGENDA/AGENDAMEETINGID/329/Default.aspx

            'Dim strURLBuilder As New System.Text.StringBuilder
            'strURLBuilder.Append("s=")
            'strURLBuilder.Append(screenId)
            'If SubmissionId > 0 Then
            '    strURLBuilder.Append("&sid=")
            '    strURLBuilder.Append(SubmissionId)
            'End If
            'If AuthorId > 0 Then
            '    strURLBuilder.Append("&aid=")
            '    strURLBuilder.Append(AuthorId)
            'End If
            'If Not String.IsNullOrEmpty(args) Then
            '    strURLBuilder.Append("&args=")
            '    strURLBuilder.Append(args)
            'End If
            'If Type IsNot Nothing AndAlso Not String.IsNullOrEmpty(Type) Then
            '    strURLBuilder.Append("&type=")
            '    strURLBuilder.Append(Type)
            'End If
            'If IsAdd = True Then
            '    strURLBuilder.Append("&mode=ADD")
            'End If
            ' Response.Redirect(NavigateURL(135, "&MODE=AGENDA&AGENDAMEETINGID=" & Me.GetMeetingId), True)

            

            Dim url As String '= "http://localhost/PersonifyTAUG/ShoppingCart/OrderCreate/tabid/135/MODE/AGENDA/AGENDAMEETINGID/{0}/Default.aspx"
            ' url = url.Replace("{0}", GetMeetingId)
            url = String.Format("~/Default.aspx?tabid={0}&AGENDAMEETINGID={1}", CType(Settings("OrderCreateURL"), String), GetMeetingId)

            Dim key As String
            key = String.Concat(GetSessionCustomerRegisteredMeetingSessionKey, "_MasterProductOrderNumber")
            Session(key) = Nothing
            key = String.Concat(GetSessionCustomerRegisteredMeetingSessionKey, "_MasterProductOrderLine")
            Session(key) = Nothing
            Session(GetSessionCustomerRegisteredMeetingSessionKey) = Nothing
            ClearSessionObject(SessionKeys.PersonifyOrder)
            Response.Redirect(url)

        End Sub


        Private Sub butUpdateNow_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butUpdateNow.Click

            Dim strProductIds As New System.Text.StringBuilder
            Dim oRegisterMeeting As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
            oRegisterMeeting = GetMyRegisteredMeetings

            For i As Integer = 0 To AssignedAgendaSessions.Count - 1
                Dim oAssignAgendaSession As TIMSS.API.CustomerInfo.ICustomerMeetingAgenda
                oAssignAgendaSession = AssignedAgendaSessions(i)
                If oAssignAgendaSession.AppointmentTypeCode.Code = "MEETING" AndAlso oAssignAgendaSession.AvailableToOrders Then
                    If oRegisterMeeting IsNot Nothing AndAlso _
                                           oRegisterMeeting.Table.Select(String.Concat("PRODUCT_ID =", oAssignAgendaSession.SessionProductId)).Length > 0 Then
                        'skip always
                    ElseIf String.IsNullOrEmpty(strProductIds.ToString) Then
                        strProductIds.Append(oAssignAgendaSession.SessionProductId)
                    Else
                        strProductIds.Append(",")
                        strProductIds.Append(oAssignAgendaSession.SessionProductId)
                    End If
                End If
            Next

            If Not String.IsNullOrEmpty(strProductIds.ToString) Then
                Dim url As String
                url = String.Format("~/Default.aspx?tabid={0}&MODE={1}&AGENDAMEETINGID={2}&ORDERNUMBER={3}&ORDERLINENUMBER={4}&PRODUCTID={5}", CType(Settings("OrderCreateURL"), String), "EDITORDER", GetMeetingId, Me.RegisteredOrderNumber, RegisteredOrderLineNumberForMeeting, strProductIds.ToString)
                'reset order master on session
                Session(GetSessionCustomerRegisteredMeetingSessionKey) = Nothing
                Response.Redirect(url)
            End If
            
        End Sub

#End Region

#Region "Optional Interfaces"
        Public Overrides ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection
            Get
                'Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                'Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)

                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.EditContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.EditContent, "", "", EditUrl("EditAgendaMenu"), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)

                Return Actions
            End Get
        End Property
        

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
            Return Nothing
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable        
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
            Return Nothing
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object


#End Region

#Region "Helper functions"

        Public Function GetFileContents(ByVal FullPath As String, _
               Optional ByRef ErrInfo As String = "") As String

            Dim strContents As String
            Dim objReader As StreamReader
            Try

                objReader = New StreamReader(FullPath)
                strContents = objReader.ReadToEnd()
                objReader.Close()
                Return strContents
            Catch Ex As Exception
                ErrInfo = Ex.Message
            End Try

            Return Nothing
        End Function


        Private Sub SetupControls()

            If Not Page.IsPostBack Then
              
                If Not IsScreenQueryParametersValid() Then
                    Me.Visible = False
                    Exit Sub
                End If


                Dim oWebProduct As TIMSS.API.WebInfo.ITmarWebProductView
                If Not String.IsNullOrEmpty(GetMeetingId) Then

                    oWebProduct = Meeting_Product_Get(GetMeetingId)
                    If oWebProduct Is Nothing Then
                        Me.Visible = False
                        Exit Sub
                    End If

                    If Date.Now.Date > oWebProduct.MeetingProducts(0).LastRegistrationDate Then
                        butRegisterNow.Visible = False
                        lblDaysLeft.Visible = False
                        butUpdateNow.Visible = False
                        pnlSocial.Visible = False
                    ElseIf Not String.IsNullOrEmpty(RegisteredOrderNumber) Then 'User already registered
                        butRegisterNow.Visible = False
                        lblDaysLeft.Visible = False
                        butUpdateNow.Visible = True
                    Else
                        butRegisterNow.Visible = True
                        lblDaysLeft.Visible = True
                        butUpdateNow.Visible = False
                    End If


                    Dim lastDate As Date
                    Dim daysLeft As TimeSpan
                    lastDate = oWebProduct.MeetingProducts(0).LastRegistrationDate

                    Dim dateDifference As New DateTime(lastDate.Year, lastDate.Month, lastDate.Day)
                    daysLeft = dateDifference.Subtract(DateTime.Today)
                    lblDaysLeft.Text = lblDaysLeft.Text.Replace("{0}", daysLeft.TotalDays)

                    Dim urlString As String
                    urlString = "http://www.linkedin.com/shareArticle?mini=true&url={0}&title={1}&summary={2}&source={3}"
                    urlString = urlString.Replace("{0}", Request.Url.AbsoluteUri)
                    urlString = urlString.Replace("{1}", oWebProduct.ShortName)
                    urlString = urlString.Replace("{2}", Server.UrlEncode(oWebProduct.WebShortDescription))
                    urlString = urlString.Replace("{3}", Request.Url.AbsoluteUri)
                    LinkForLinkedIn.HRef = urlString

                    If Not String.IsNullOrEmpty(oWebProduct.SmallImageFileName) Then
                        imgSmallImage.Src = String.Concat(Me.ProductImagesFolder, oWebProduct.SmallImageFileName)
                    Else
                        imgSmallImage.Visible = False
                    End If


                End If

                Dim key As String = "AdvanceMenu_" & Me.GetMeetingId
                If PersonifyDataCache.Fetch(key) Is Nothing Then
                    Dim fullPath As String = Server.MapPath("DesktopModules\Personify - AdvanceMeeting\Base\AdvanceMeetingMenu.xml")

                    Dim content As String = GetFileContents(fullPath)
                    PersonifyDataCache.Store(key, content)
                    'PanelBarList.LoadContentFile("DesktopModules\Personify - Abstract\Controls\Menu\ABSPanelBarMenu.xml")               
                End If
                PanelBarList.LoadXml(PersonifyDataCache.Fetch(key))

                For Each item As Telerik.Web.UI.RadPanelItem In PanelBarList.Items
                    If Not String.IsNullOrEmpty(item.NavigateUrl) Then
                        'item.NavigateUrl must equals S=XXX
                        item.NavigateUrl = item.NavigateUrl.Replace("[AMPS]", "&")
                        If item.Attributes("External") Is Nothing OrElse item.Attributes("External") <> "Y" Then
                            item.NavigateUrl = NavigateURL("", String.Concat(item.NavigateUrl, "&mpid=", Me.GetMeetingId))
                        End If
                        If item.Attributes("TYPE") IsNot Nothing Then

                            Select Case item.Attributes("TYPE")
                                Case "SP"
                                    item.Visible = False
                                Case "ST"
                                    If Not Me.AdvanceMeetingManager.DoesTrackExistForGivenMeeting(Me.GetMeetingId) Then
                                        item.Visible = False
                                    End If
                            End Select
                        End If
                    End If
                    'If item.Items.Count > 0 Then
                    '    For Each childItem As Telerik.Web.UI.RadPanelItem In item.Items
                    '        If Not String.IsNullOrEmpty(childItem.NavigateUrl) Then
                    '            'item.NavigateUrl must equals S=XXX
                    '            childItem.NavigateUrl = childItem.NavigateUrl.Replace("[AMPS]", "&")
                    '            childItem.NavigateUrl = NavigateURL("", childItem.NavigateUrl)
                    '        End If
                    '    Next
                    'End If
                Next

            End If

      
        End Sub

#End Region




    End Class
End Namespace


