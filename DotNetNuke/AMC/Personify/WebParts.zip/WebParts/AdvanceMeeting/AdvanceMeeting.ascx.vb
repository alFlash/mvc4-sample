Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Namespace Personify.DNN.Modules.AdvanceMeeting

    Public MustInherit Class AdvanceMeeting
        Inherits AdvanceMeetingBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected WithEvents ajaxPanel As Telerik.Web.UI.RadAjaxPanel
        Protected WithEvents RadLoadingPanel As Telerik.Web.UI.RadAjaxLoadingPanel
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'Sample code to get data
                'Dim objDefaultModule As New DefaultModuleController
                'Dim list As ArrayList

                ' If Not Page.IsPostBack Then
                'list = objDefaultModule.GetByModules(ModuleId)
                'End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region "Optional Interfaces"
        Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            If Framework.AJAX.IsInstalled Then
                DotNetNuke.Framework.AJAX.RegisterScriptManager()
            End If
            InitScreen()
        End Sub

#End Region

#Region "Helper functions"
    
        Private Sub InitScreen()
            Dim controlName As String
            'Dim control As System.Web.UI.Control

            If Not IsScreenQueryParametersValid() Then
                Me.Visible = False
                Exit Sub
            End If

            If Meeting_Product_Get(Request("mpid")) Is Nothing Then
                Me.Visible = False
                Exit Sub           
            End If

            controlName = ScreenController.Screen_GetName(Request("s"))

            'If controlName IsNot Nothing Then
            '    controlAccessType = ScreenController.Screen_RequiredAccessCheck(Request("s"))
            '    Select Case controlAccessType
            '        Case ScreenController.ABS_Security_Role.Admin
            '            controlLoadValid = HasAdminAccess
            '        Case ScreenController.ABS_Security_Role.SubTypeStaff_General
            '            controlLoadValid = HasSubmissionTypeAccess(ScreenController.ABS_Security_Role.SubTypeStaff_General)
            '        Case ScreenController.ABS_Security_Role.SubTypeStaff_Specific
            '            controlLoadValid = HasSubmissionTypeAccess(ScreenController.ABS_Security_Role.SubTypeStaff_Specific)
            '        Case ScreenController.ABS_Security_Role.ALL
            '            controlLoadValid = True
            '    End Select

            '    If controlLoadValid Then
            '    End If

            If Request("s") IsNot Nothing AndAlso CType(Request("s"), ScreenController.AdvanceMeetingScreen) = ScreenController.AdvanceMeetingScreen.MyAgenda Then
                ajaxPanel.EnableAJAX = False
            End If

            If Not String.IsNullOrEmpty(controlName) Then
                Dim oBasePage As AdvanceMeetingBase = LoadControl(controlName)
                oBasePage.CustomModuleId = Me.ModuleId
                'control = LoadControl(controlName)
                ajaxPanel.Controls.Add(oBasePage)
            End If
            'End If
        End Sub
#End Region
    End Class

End Namespace
