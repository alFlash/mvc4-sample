Imports TIMSS.API.Core
Imports TIMSS.DataAccess
Imports TIMSS.SqlObjects
Imports TIMSS.Interfaces

Public Class AdvanceMeetingHelper
    Inherits Personify.ApplicationManager.BaseHelperClass

    Public Sub New(ByVal OrgId As String, ByVal OrgUnitId As String)
        MyBase.New(OrgId, OrgUnitId)
    End Sub
    Public Sub New(ByVal OrgId As String, ByVal OrgUnitId As String, ByVal EnableOnDemandDataLoad As Boolean)
        MyBase.New(OrgId, OrgUnitId, EnableOnDemandDataLoad)
    End Sub

#Region "CUS AGENDA"

    Public Function MyMeetingAgenda_Get(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer) As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")
        oCusMTGAgendas.Filter.Add("MasterCustomerId", MasterCustomerId)
        oCusMTGAgendas.Filter.Add("SubCustomerId", SubCustomerId)
        oCusMTGAgendas.Filter.Add("MeetingProductId", ProductId)
        oCusMTGAgendas.SortProperties.Add("AppointmentStartDateTime", TIMSS.Enumerations.SortDirection.Ascending)
        oCusMTGAgendas.Fill()

        Return oCusMTGAgendas

    End Function

    Public Function MyMeetingAgenda_Delete(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal AppointmentId As Long) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")
        oCusMTGAgendas.Filter.Add("MasterCustomerId", MasterCustomerId)
        oCusMTGAgendas.Filter.Add("SubCustomerId", SubCustomerId)
        oCusMTGAgendas.Filter.Add("AppointmentId", AppointmentId)
        oCusMTGAgendas.Fill()
        If oCusMTGAgendas IsNot Nothing AndAlso oCusMTGAgendas.Count = 1 Then
            oCusMTGAgendas.RemoveAt(0)
        End If
        oCusMTGAgendas.Save()

        Return oCusMTGAgendas.ValidationIssues

    End Function

    Public Function MyMeetingAgenda_ProductId_Delete(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal SessionProductId As Long) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")
        oCusMTGAgendas.Filter.Add("MasterCustomerId", MasterCustomerId)
        oCusMTGAgendas.Filter.Add("SubCustomerId", SubCustomerId)
        oCusMTGAgendas.Filter.Add("SessionProductId", SessionProductId)
        oCusMTGAgendas.Fill()

        If oCusMTGAgendas IsNot Nothing Then
            oCusMTGAgendas.RemoveAll()
        End If
        oCusMTGAgendas.Save()

        Return oCusMTGAgendas.ValidationIssues

    End Function


    Public Function MyMeetingAgenda_Add(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ParentProductId As Long, ByVal webProduct As TIMSS.API.WebInfo.ITmarWebProductView _
                                         , ByVal SpeakerNames As String, ByVal SessionTrack As String) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        Dim oCusMTGAgenda As TIMSS.API.CustomerInfo.ICustomerMeetingAgenda

        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")
        oCusMTGAgenda = oCusMTGAgendas.AddNew

        With webProduct
            oCusMTGAgenda.MasterCustomerId = MasterCustomerId
            oCusMTGAgenda.SubCustomerId = SubCustomerId
            oCusMTGAgenda.SessionProductId = .ProductId
            oCusMTGAgenda.MeetingProductId = ParentProductId
            oCusMTGAgenda.SessionProductCode = .ProductCode
            oCusMTGAgenda.MeetingProductCode = .ParentProduct
            oCusMTGAgenda.MeetingParentProductCode = .ParentProduct

            oCusMTGAgenda.SessionLocation = .FacilityName
            oCusMTGAgenda.SpeakerName = SpeakerNames
            oCusMTGAgenda.SessionTrackCode = SessionTrack
            oCusMTGAgenda.SessionTypeCode = .ProductClassCode.Description

            oCusMTGAgenda.AppointmentDescription = .WebShortDescription
            oCusMTGAgenda.AppointmentTitle = .ShortName
            oCusMTGAgenda.AppointmentStartDateTime = .MeetingStartDate
            oCusMTGAgenda.AppointmentEndDateTime = .MeetingEndDate
            oCusMTGAgenda.AppointmentTypeCode.Code = "MEETING"

            oCusMTGAgenda.AvailableToOrders = .AvailableToOrdersFlag
            oCusMTGAgenda.SessionFee = .ListPrice


        End With

        oCusMTGAgendas.Save()

        Return oCusMTGAgendas.ValidationIssues

    End Function


    Public Function MyMeetingAgendaPersonal_Add(ByVal MeetingId As Long, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal StartDate As DateTime, ByVal EndDate As DateTime, ByVal Title As String, ByVal Description As String) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        Dim oCusMTGAgenda As TIMSS.API.CustomerInfo.ICustomerMeetingAgenda

        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")
        oCusMTGAgenda = oCusMTGAgendas.AddNew

        With oCusMTGAgenda
            oCusMTGAgenda.MasterCustomerId = MasterCustomerId
            oCusMTGAgenda.SubCustomerId = SubCustomerId

            oCusMTGAgenda.AppointmentDescription = Description
            oCusMTGAgenda.AppointmentTitle = Title
            oCusMTGAgenda.MeetingProductId = MeetingId
            oCusMTGAgenda.AppointmentStartDateTime = StartDate
            oCusMTGAgenda.AppointmentEndDateTime = EndDate
            oCusMTGAgenda.AppointmentTypeCode.Code = "PERSONAL"
            oCusMTGAgenda.AvailableToOrders = False
        End With

        oCusMTGAgendas.Save()

        Return oCusMTGAgendas.ValidationIssues

    End Function

    Public Function MyMeetingAgendaByTracks_Add(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal MeetingProductId As String, ByVal SessionTrack As String, ByVal SessionTracksSource As DataTable) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")

        oCusMTGAgendas.Filter.Add("MasterCustomerId", MasterCustomerId)
        oCusMTGAgendas.Filter.Add("SubCustomerId", SubCustomerId)
        oCusMTGAgendas.Filter.Add("MeetingProductId", MeetingProductId)
        oCusMTGAgendas.Filter.Add("SessionTrackCode", SessionTrack)

        oCusMTGAgendas.Fill()


        Dim oCusMTGAgenda As TIMSS.API.CustomerInfo.ICustomerMeetingAgenda

        For Each oRow As DataRow In SessionTracksSource.Rows
            If Not CheckIfRowExistsInAgenda(oCusMTGAgendas, oRow("Product_Id")) Then

                'insert into My Agenda
                oCusMTGAgenda = oCusMTGAgendas.AddNew
                oCusMTGAgenda.MasterCustomerId = MasterCustomerId
                oCusMTGAgenda.SubCustomerId = SubCustomerId

                oCusMTGAgenda.SessionProductId = oRow("Product_Id")
                oCusMTGAgenda.MeetingProductId = MeetingProductId
                'oCusMTGAgenda.SessionProductCode = .ProductCode
                'CusMTGAgenda.MeetingProductCode = .ParentProduct
                'oCusMTGAgenda.MeetingParentProductCode = .ParentProduct
                'oCusMTGAgenda.SpeakerName = "Richard"

                oCusMTGAgenda.SessionLocation = IIf(oRow("FacilityName") Is System.DBNull.Value, "", oRow("FacilityName"))

                oCusMTGAgenda.SessionTrackCode = oRow("session_track_code")

                oCusMTGAgenda.AppointmentDescription = IIf(oRow("long_name") Is System.DBNull.Value, "", oRow("long_name"))
                oCusMTGAgenda.AppointmentTitle = IIf(oRow("short_name") Is System.DBNull.Value, "", oRow("short_name"))
                oCusMTGAgenda.AppointmentStartDateTime = IIf(oRow("start_date") Is System.DBNull.Value, "", oRow("start_date"))
                oCusMTGAgenda.AppointmentEndDateTime = IIf(oRow("end_date") Is System.DBNull.Value, "", oRow("end_date"))
                oCusMTGAgenda.AppointmentTypeCode.Code = "MEETING"
                If oRow("AVAILABLE_TO_ORDERS_FLAG") IsNot System.DBNull.Value AndAlso oRow("AVAILABLE_TO_ORDERS_FLAG") = "Y" Then
                    oCusMTGAgenda.AvailableToOrders = True
                Else
                    oCusMTGAgenda.AvailableToOrders = False
                End If
                'Need to include list / member / your price
                'If Not IsDBNull(oRow("ListPrice")) Then
                '    oCusMTGAgenda.SessionFee = oRow("ListPrice")
                'End If
            End If
        Next
        oCusMTGAgendas.Save()

        Return oCusMTGAgendas.ValidationIssues

    End Function


    Public Function MyMeetingAgendaByTracks_Delete(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal MeetingProductId As String, ByVal SessionsPerTrack As DataTable) As TIMSS.API.Core.Validation.IIssuesCollection

        Dim oCusMTGAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

        oCusMTGAgendas = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerMeetingAgendas")

        oCusMTGAgendas.Filter.Add("MasterCustomerId", MasterCustomerId)
        oCusMTGAgendas.Filter.Add("SubCustomerId", SubCustomerId)
        oCusMTGAgendas.Filter.Add("MeetingProductId", MeetingProductId)
        oCusMTGAgendas.Fill()

        For i As Integer = oCusMTGAgendas.Count - 1 To 0 Step -1
            If SessionsPerTrack.Select(String.Concat("product_id =", oCusMTGAgendas(i).SessionProductId)).Length > 0 Then
                oCusMTGAgendas.RemoveAt(i)
            End If
        Next

        oCusMTGAgendas.Save()
        Return oCusMTGAgendas.ValidationIssues

    End Function

#End Region

#Region "Session"

    Public Function DoesTrackExistForGivenMeeting(ByVal meetingId As Long) As Boolean

        Dim oMeetingTracks As TIMSS.API.MeetingInfo.IMeetingParentProductTracks

        oMeetingTracks = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.MeetingInfo, "MeetingParentProductTracks")
        oMeetingTracks.Filter.Add("ProductId", meetingId)
        oMeetingTracks.Fill()

        If oMeetingTracks IsNot Nothing AndAlso oMeetingTracks.Count > 0 Then
            Return True
        End If

        Return False
    End Function

    Public Function DistinctSessionTracks_Get(ByVal ParentProductCode As String) As DataSet

        Dim oSelectRequest As SimpleRequest
        Dim oRequest As TIMSS.DataAccess.RequestSet = Nothing
        Dim oResultSet As TIMSS.Interfaces.IResultSet = Nothing

        Dim oDS As DataSet
        Dim strSQL As New System.Text.StringBuilder
        With strSQL
            .Append("select distinct isnull(tmp.Session_Track_Code, '') as Session_Track_Code, isnull(tmp.Session_Summary, '') as Session_Summary from tmar_web_product_vw t ")
            .Append("left outer join (select m.product_id as parent_product_id, s.product_id, m.session_track_code, m.SESSION_SUMMARY  from MTG_PARENT_PRODUCT_TRACK m, MTG_SESSION_PRODUCT_TRACK s where m.product_id = s.parent_product_id and m.session_track_code = s.session_track_code) tmp on ")
            .Append(String.Format("t.product_id = tmp.product_id where t.parent_product = '{0}' and t.parent_product <> t.product_code and tmp.Session_Track_Code is not null", ParentProductCode))
        End With

        oSelectRequest = New SimpleRequest("GetSessions", strSQL.ToString)
        oRequest = New TIMSS.DataAccess.RequestSet

        oResultSet = TIMSS.[Global].App.GetData(oSelectRequest)

        oDS = oResultSet.Unpack()

        Return oDS

    End Function

    Public Function AllSessions_Get(ByVal ParentProductCode As String) As DataTable

        Dim oSelectRequest As SimpleRequest
        Dim oRequest As TIMSS.DataAccess.RequestSet = Nothing
        Dim oResultSet As TIMSS.Interfaces.IResultSet = Nothing

        Dim oDS As DataSet
        'TODO - USe API's

        Dim strSQL As New System.Text.StringBuilder

        With strSQL
            .Append("select t.product_id, isnull(tmp.Session_Track_Code, '') as Session_Track_Code ")
            .Append(", t.short_name , t.long_name,t.FacilityName , t.start_date ,t.end_date, t.AVAILABLE_TO_ORDERS_FLAG ")
            .Append("from tmar_web_product_vw t ")
            .Append("left outer join (select m.product_id as parent_product_id, s.product_id, m.session_track_code, m.SESSION_SUMMARY  from ")
            .Append("MTG_PARENT_PRODUCT_TRACK m, MTG_SESSION_PRODUCT_TRACK s where m.product_id = s.parent_product_id and m.session_track_code = s.session_track_code) tmp on ")
            .Append(String.Format("t.product_id = tmp.product_id where t.parent_product = '{0}' and t.parent_product <> t.product_code", ParentProductCode))
        End With

        oSelectRequest = New SimpleRequest("GetSessions", strSQL.ToString)

        oRequest = New TIMSS.DataAccess.RequestSet

        oResultSet = TIMSS.[Global].App.GetData(oSelectRequest)

        oDS = oResultSet.Unpack()

        Return oDS.Tables(0)

    End Function

    Public Function SessionsByTrack_Get(ByVal TrackName As String, ByVal AllSessionsSource As DataTable) As DataTable
        Dim oTable As New System.Data.DataTable
        Dim odr() As DataRow


        oTable.Columns.Add(New System.Data.DataColumn("session_track_code", GetType(String)))
        oTable.Columns.Add(New System.Data.DataColumn("short_name", GetType(String)))
        oTable.Columns.Add(New System.Data.DataColumn("long_name", GetType(String)))
        oTable.Columns.Add(New System.Data.DataColumn("product_id", GetType(String)))
        oTable.Columns.Add(New System.Data.DataColumn("FacilityName", GetType(String)))
        oTable.Columns.Add(New System.Data.DataColumn("start_date", GetType(DateTime)))
        oTable.Columns.Add(New System.Data.DataColumn("end_date", GetType(DateTime)))
        'oTable.Columns.Add(New System.Data.DataColumn("ListPrice", GetType(Decimal)))
        oTable.Columns.Add(New System.Data.DataColumn("AVAILABLE_TO_ORDERS_FLAG", GetType(String)))

        odr = AllSessionsSource.Select("session_track_code = '" + TrackName + "'")

        For i As Int16 = 0 To odr.Length - 1
            oTable.Rows.Add(odr(i)("session_track_code"), odr(i)("short_name"), odr(i)("long_name"), odr(i)("product_id"), odr(i)("FacilityName"), odr(i)("start_date"), odr(i)("end_date"), odr(i)("AVAILABLE_TO_ORDERS_FLAG"))
        Next

        Return oTable


    End Function
#End Region

#Region "Helper functions"




    'Private Function CheckIfTrackExistsInAgenda(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal MeetingProductId As String, ByVal SessionTrackCode As String) As Boolean

    '    Dim oSelectRequest As SimpleRequest
    '    Dim oRequest As TIMSS.DataAccess.RequestSet = Nothing
    '    Dim oResultSet As TIMSS.Interfaces.IResultSet = Nothing

    '    Dim oDS As DataSet

    '    Dim strSQL As New System.Text.StringBuilder

    '    'Build the Update Request to set the Internal Status Code and External Status Codes
    '    'on the Abstract
    '    'TODO - cache all countes
    '    With strSQL
    '        .Append("select count(*) ")
    '        .Append("  from cus_mtg_agenda ")
    '        .Append(String.Format("  where master_customer_id =  '{0}'", MasterCustomerId))
    '        .Append(String.Format("  and sub_customer_id =  '{0}'", SubCustomerId))
    '        .Append((String.Format("  and MEETING_PRODUCT_ID =  '{0}'", MeetingProductId)))
    '        .Append((String.Format("  and session_track_code =  '{0}'", SessionTrackCode)))


    '    End With
    '    'End If
    '    oSelectRequest = New SimpleRequest("GetSessions", strSQL.ToString)

    '    oRequest = New TIMSS.DataAccess.RequestSet

    '    oResultSet = TIMSS.[Global].App.GetData(oSelectRequest)

    '    oDS = oResultSet.Unpack()

    '    Return Convert.ToInt16(oDS.Tables(0).Rows(0).Item(0)) > 0

    'End Function

    Private Function CheckIfRowExistsInAgenda(ByVal CusMtgAgendas As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas, ByVal ProductId As Decimal) As Boolean

        Return CusMtgAgendas.FindObject("SessionProductId", ProductId) IsNot Nothing

    End Function

#End Region

End Class
