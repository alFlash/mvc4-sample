Imports TIMSS.API.Core.Validation
Imports TIMSS.API.Core.ValidationIssues
Imports Constants

Imports Personify.ApplicationManager

Public Class AdvanceMeetingBase
    Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


    Private _ParentProductCode As String
    Private _AdvanceMeetingManager As AdvanceMeetingHelper
    Private _RegisteredOrderNumber As String
    Private _RegisteredOrderLineNumberForMeeting As String
    Private _RegisteredMeetingsView As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
    Private _CustomModuleId As Long



#Region "Parameters"
    Public Property CustomModuleId() As Long
        Get
            Return _CustomModuleId
        End Get
        Set(ByVal value As Long)
            _CustomModuleId = value
        End Set
    End Property


    Public ReadOnly Property GetSessionCustomerRegisteredMeetingSessionKey() As String
        Get
            Return String.Concat("CustomerRegisteredMeetingSession_", GetMeetingId, MasterCustomerId, SubCustomerId)
        End Get
    End Property
    Public ReadOnly Property GetMeetingId() As String
        Get
            If Request("mpid") IsNot Nothing Then
                Return Request("mpid")
            End If
            Return ""
        End Get
    End Property

    Public Function IsScreenQueryParametersValid() As Boolean
        If Request("mpid") IsNot Nothing Then
            Return True
        End If
        Return False
    End Function

    Public ReadOnly Property ParentProductCode() As String
        Get
            If String.IsNullOrEmpty(_ParentProductCode) Then
                _ParentProductCode = Meeting_ProductParentCode_Get(GetMeetingId)
            End If
            Return _ParentProductCode
        End Get
    End Property

    Public ReadOnly Property AdvanceMeetingManager() As AdvanceMeetingHelper
        Get
            If _AdvanceMeetingManager Is Nothing Then
                _AdvanceMeetingManager = New AdvanceMeetingHelper(Me.OrganizationId, Me.OrganizationUnitId)
            End If
            Return _AdvanceMeetingManager
        End Get
    End Property

    Public ReadOnly Property RegisteredOrderLineNumberForMeeting() As String
        Get
            If String.IsNullOrEmpty(_RegisteredOrderLineNumberForMeeting) Then
                'Read it from session
                Dim key As String = String.Concat(GetSessionCustomerRegisteredMeetingSessionKey, "_MasterProductOrderLine")
                If Session(key) Is Nothing Then
                    Dim webRegistrationViewList As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
                    webRegistrationViewList = DF_GetCustomerRegisteredMeetingOrderNumber(MasterCustomerId, SubCustomerId, GetMeetingId)
                    If webRegistrationViewList.Count > 0 Then
                        _RegisteredOrderLineNumberForMeeting = webRegistrationViewList(0).OrderLineNumber
                    End If
                    Session(key) = webRegistrationViewList(0)
                Else
                    _RegisteredOrderLineNumberForMeeting = CType(Session(key), TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsView).OrderLineNumber
                End If
            End If
            Return _RegisteredOrderLineNumberForMeeting

        End Get
    End Property
    Public ReadOnly Property RegisteredOrderNumber() As String
        Get
            If String.IsNullOrEmpty(_RegisteredOrderNumber) Then
                'Read it from session
                Dim key As String = String.Concat(GetSessionCustomerRegisteredMeetingSessionKey, "_MasterProductOrderNumber")
                If Session(key) Is Nothing Then
                    Dim webRegistrationViewList As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
                    webRegistrationViewList = DF_GetCustomerRegisteredMeetingOrderNumber(MasterCustomerId, SubCustomerId, GetMeetingId)
                    If webRegistrationViewList.Count > 0 Then
                        _RegisteredOrderNumber = webRegistrationViewList(0).OrderNumber
                    End If
                    Session(key) = webRegistrationViewList(0)
                Else
                    _RegisteredOrderNumber = CType(Session(key), TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsView).OrderNumber
                End If
            End If
            Return _RegisteredOrderNumber
        End Get
    End Property

    Public ReadOnly Property GetMyRegisteredMeetings() As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
        Get
            If String.IsNullOrEmpty(RegisteredOrderNumber) Then
                Return Nothing
            End If
            Dim key As String = GetSessionCustomerRegisteredMeetingSessionKey

            If Session(GetSessionCustomerRegisteredMeetingSessionKey) Is Nothing Then
                _RegisteredMeetingsView = DF_GetCustomerRegisteredMeeting(MasterCustomerId, SubCustomerId, RegisteredOrderNumber)
                Session(GetSessionCustomerRegisteredMeetingSessionKey) = _RegisteredMeetingsView
            Else
                _RegisteredMeetingsView = Session(GetSessionCustomerRegisteredMeetingSessionKey)
            End If

            Return _RegisteredMeetingsView
        End Get
    End Property


#End Region

#Region "Common functions"

    Public Function Meeting_Product_Get(ByVal productId As Long) As TIMSS.API.WebInfo.ITmarWebProductView

        Dim oMTGProduct As TIMSS.API.WebInfo.ITmarWebProductView = Nothing
        Dim oMTGProducts As TIMSS.API.WebInfo.ITmarWebProductViewList

        oMTGProducts = get_clsProductHelper.GetWebProductInfo(productId)
        If oMTGProducts IsNot Nothing AndAlso oMTGProducts.Count > 0 Then
            oMTGProduct = oMTGProducts(0)
        End If

        Return oMTGProduct
    End Function

    Public Function Meeting_ProductParentCode_Get(ByVal productId As Long) As String

        Dim oMTGProduct As TIMSS.API.WebInfo.ITmarWebProductView = Nothing
        Dim oMTGProducts As TIMSS.API.WebInfo.ITmarWebProductViewList

        oMTGProducts = get_clsProductHelper.GetWebProductInfo(productId)
        If oMTGProducts IsNot Nothing AndAlso oMTGProducts.Count > 0 Then
            oMTGProduct = oMTGProducts(0)
            Return oMTGProduct.ParentProduct
        End If

        Return String.Empty
    End Function

    'Public Function Sessions_Product_Tracks_Get(ByVal ParentProductId As Long) As TIMSS.API.MeetingInfo.IMeetingSessionProductTracks


    'Dim oReturn As New ArrayList

    'Dim oWebProducts As WebInfo.ITmarWebProductViewList
    'Dim oSubProducts As WebInfo.ITmarWebProductViewList
    'Dim strCacheKey As String


    'strCacheKey = String.Concat(ProductId.ToString, "SubProducts")

    'oSubProducts = CType(PersonifyDataCache.Fetch(strCacheKey), TIMSS.API.WebInfo.ITmarWebProductViewList)

    'If oSubProducts Is Nothing Then
    '    oWebProducts = GetWebProductInfo(ProductId)

    '    If Not oWebProducts Is Nothing AndAlso oWebProducts.Count > 0 Then
    '        oSubProducts = oWebProducts(0).SubProducts
    '    Else

    '    End If
    '    If oSubProducts IsNot Nothing Then
    '        PersonifyDataCache.Store(strCacheKey, oSubProducts, PersonifyDataCache.CacheExpirationInterval)
    '    End If

    'End If

    'If oSubProducts Is Nothing OrElse oSubProducts.Count = 0 Then
    '    Return Nothing
    'Else
    '    If SubProductClassFilter Is Nothing OrElse SubProductClassFilter.Length = 0 Then
    '        Return oSubProducts
    '    Else
    '        For Each strClass As String In SubProductClassFilter
    '            For i As Integer = 0 To oSubProducts.Count - 1
    '                If oSubProducts(i).ProductTypeCodeString.ToString = strClass Then
    '                    oReturn.Add(oSubProducts(i))
    '                End If

    '            Next
    '        Next
    '    End If
    'End If

    'Dim oSubProductsReturn As WebInfo.ITmarWebProductViewList

    'oSubProductsReturn = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebProductViewList")

    'If oReturn.Count > 0 Then
    '    For i As Integer = 0 To oReturn.Count - 1
    '        oSubProductsReturn.Add(CType(oReturn(i), WebInfo.ITmarWebProductView))
    '    Next
    'End If


    'Return oSubProductsReturn


    'End Function


    Public Sub RedirectToLogin()
        Dim LoginURLBuilder As New System.Text.StringBuilder
        LoginURLBuilder.Append("~/Default.aspx?tabid=")
        LoginURLBuilder.Append(PortalSettings.LoginTabId)
        LoginURLBuilder.Append("&returnurl=")
        LoginURLBuilder.Append(HttpUtility.UrlEncode(Request.Url.AbsoluteUri))
        Me.Response.Redirect(LoginURLBuilder.ToString, True)
    End Sub

#End Region

#Region "Message"

    Public Sub ShowPopupMessage(ByVal validationIssues As TIMSS.API.Core.Validation.IIssuesCollection)

        If validationIssues Is Nothing OrElse validationIssues.ErrorCount = 0 Then
            Exit Sub
        End If

        Dim popupMessage As New Telerik.Web.UI.RadToolTip
        Dim width As Integer = 75
        Me.Controls.Add(popupMessage)

        With popupMessage
            '.Position = Telerik.Web.UI.ToolTipPosition.BottomRight
            '.RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
            .Position = Telerik.Web.UI.ToolTipPosition.Center
            .RelativeTo = Telerik.Web.UI.ToolTipRelativeDisplay.BrowserWindow
            .Animation = Telerik.Web.UI.ToolTipAnimation.Fade
            '.Animation = Telerik.Web.UI.ToolTipAnimation.None
            .Title = "Message"
            .Width = 300
            .Height = width * validationIssues.ErrorCount
            .Show()
            .RenderInPageRoot = True
            '.VisibleOnPageLoad = True
            .HideEvent = Telerik.Web.UI.ToolTipHideEvent.ManualClose
        End With


        popupMessage.Controls.Add(CreateValidationContent(validationIssues))

    End Sub

    Private Function CreateValidationContent(ByVal validationIssues As TIMSS.API.Core.Validation.IIssuesCollection) As Table
        Dim aTable As New Table
        aTable.CellSpacing = 0
        aTable.CellPadding = 3
        aTable.Height = New System.Web.UI.WebControls.Unit(100, UnitType.Percentage)
        aTable.Width = New System.Web.UI.WebControls.Unit(100, UnitType.Percentage)
        For i As Integer = 0 To validationIssues.Count - 1
            If validationIssues(i).Severity = IssueSeverityEnum.Error Then
                Dim tablecellA As New TableCell
                tablecellA.HorizontalAlign = HorizontalAlign.Center
                tablecellA.VerticalAlign = VerticalAlign.Middle
                Dim aImage As New System.Web.UI.WebControls.Image
                aImage.ImageUrl = GetMessageIcon(validationIssues(i).Severity)
                tablecellA.Controls.Add(aImage)

                Dim tablecellB As New TableCell
                tablecellB.HorizontalAlign = HorizontalAlign.Left
                tablecellB.VerticalAlign = VerticalAlign.Middle
                Dim aLabel As New Label
                aLabel.Text = validationIssues(i).Message
                tablecellB.Controls.Add(aLabel)

                Dim aRow As New TableRow
                aRow.Cells.Add(tablecellA)
                aRow.Cells.Add(tablecellB)
                aTable.Rows.Add(aRow)
            End If
        Next
        Dim btnOk As New Button
        Dim aEndRow As New TableRow
        Dim aEndCell As New TableCell
        Dim lbl As New Label
        lbl.Text = "<br/><br/>"
        btnOk.Text = "Ok"
        btnOk.Width = "50"
        aEndCell.HorizontalAlign = HorizontalAlign.Right
        aEndCell.ColumnSpan = 2
        aEndCell.Controls.Add(lbl)
        aEndCell.Controls.Add(btnOk)
        aEndRow.Cells.Add(aEndCell)
        aTable.Rows.Add(aEndRow)

        Return aTable
    End Function

    Private Function GetMessageIcon(ByVal iconType As IssueSeverityEnum) As String

        Select Case iconType
            Case IssueSeverityEnum.Information
                Return "~/DefaultPersonifyImages/timss-info-green.gif"
            Case IssueSeverityEnum.Question
                Return "~/DefaultPersonifyImages/timss-question-blue.gif"
            Case IssueSeverityEnum.Warning
                Return "~/DefaultPersonifyImages/timss-warning-yellow.gif"
            Case IssueSeverityEnum.Error
                Return "~/DefaultPersonifyImages/timss-error-red.gif"
        End Select

        Return ""
    End Function

#End Region

#Region "Helper functions"

    Private Function DF_GetCustomerRegisteredMeetingOrderNumber(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Long) As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList

        Dim oMeetings As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
        oMeetings = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebCurrMeetingRegistrationsViewList")
        'oMeetings.GetSubProductsForAMeeting()
        With oMeetings
            .Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            .Filter.Add("ShipSubCustomerId", SubCustomerId.ToString)
            '.Filter.Add("OrderNumber", ProductId)
            .Filter.Add("ProductId", ProductId)
            .Fill()
        End With


        Return oMeetings
    End Function

    Private Function DF_GetCustomerRegisteredMeeting(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal OrderNumber As String) As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
        Dim oMeetings As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
        oMeetings = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebCurrMeetingRegistrationsViewList")
        'oMeetings.GetSubProductsForAMeeting()
        With oMeetings
            .Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            .Filter.Add("ShipSubCustomerId", SubCustomerId.ToString)
            .Filter.Add("OrderNumber", OrderNumber)
            .Fill()
        End With
        Return oMeetings
    End Function

#End Region

End Class
