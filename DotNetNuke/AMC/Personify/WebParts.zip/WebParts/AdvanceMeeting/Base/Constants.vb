Public Class Constants

#Region "Variables"

    Public Const Const_RegisteredButtonMessage As String = "Registered"
    Public Const Const_WaitlistedButtonMessage As String = "Waitlisted"

#End Region


#Region "Edit Setting Constants"

    Public Const Const_EditMyAgendaTextKey As String = "AgendaText"
    Public Const Const_EditMyAgendaBuilderTextKey As String = "AgendaBuilderText"

#End Region

End Class
