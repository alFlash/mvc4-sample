Public Class ScreenController

#Region "Screen Name"

    Public Shared Function Screen_GetName(ByVal ScreenId As String) As String

        Dim controlName As String = Nothing
        Dim NameId As Integer

        NameId = CInt(ScreenId) 'todo: need to catch this exception and either ignore or present error page

        Select Case NameId
            'Administrator
            Case AdvanceMeetingScreen.Homepage
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/Home.ascx"

            Case AdvanceMeetingScreen.AgendaBuilder
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/AgendaBuilder.ascx"

            Case AdvanceMeetingScreen.Brochure
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/ConferenceBrochure.ascx"

            Case AdvanceMeetingScreen.ContactUs
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/ContactUs.ascx"

            Case AdvanceMeetingScreen.General_Schedule
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/GeneralSchedule.ascx"

            Case AdvanceMeetingScreen.Hotel
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/HotelReservations.ascx"

            Case AdvanceMeetingScreen.MyAgenda
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/MyAgenda.ascx"

            Case AdvanceMeetingScreen.Overview
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/Overview.ascx"

            Case AdvanceMeetingScreen.Speakers
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/Speakers.ascx"

            Case AdvanceMeetingScreen.Sponsor
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/Sponsors.ascx"

            Case AdvanceMeetingScreen.Tracks
                controlName = "~/DesktopModules/Personify - AdvanceMeeting/Screens/Tracks.ascx"

            Case Else
                controlName = ""
        End Select

        Return controlName

    End Function

    Public Shared Function Screen_GetName(ByVal ScreenId As AdvanceMeetingScreen) As String

        Dim controlName As String = Nothing
        Dim NameId As Integer = CInt(ScreenId) 'todo: need to catch this exception and either ignore or present error page

        Return Screen_GetName(NameId.ToString)

    End Function


 

    Public Enum AdvanceMeetingScreen
        Homepage = 0
        Overview = 1
        General_Schedule = 2
        Tracks = 3
        Brochure = 4       
        AgendaBuilder = 6
        MyAgenda = 7
        Speakers = 8
        Hotel = 9
        Sponsor = 10
        ContactUs = 11
    End Enum


#End Region

End Class





