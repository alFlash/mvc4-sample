

Imports Personify.ApplicationManager
Imports Telerik.Web.UI
Imports Constants


Public Class AgendaBuilder
    Inherits AdvanceMeetingBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Controls & Variables"

    Protected WithEvents gridAgendaBuilderSource As RadGrid

    Protected WithEvents rdDay As CheckBox
    Protected WithEvents rdSessionType As CheckBox
    Protected WithEvents rdNone As CheckBox
    Protected WithEvents rdTrack As CheckBox

    Protected WithEvents ddlFilterDay As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlEventType As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlFilterTrack As Telerik.Web.UI.RadComboBox

    Protected WithEvents tdMeetingTrackLabel As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdMeetingTrack As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents lblAgendaText As Label

    Private _WebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList
    Private _WebProductsArray As System.Collections.Generic.List(Of TIMSS.API.WebInfo.ITmarWebProductView)
    Private _SwitchDataSource As Boolean
    Private _AssignedAgendaSessions As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas


#End Region

#Region "Properties'"


    Public ReadOnly Property AssignedAgendaSessions() As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        Get            
            If _AssignedAgendaSessions Is Nothing Then
                _AssignedAgendaSessions = AdvanceMeetingManager.MyMeetingAgenda_Get(Me.MasterCustomerId, Me.SubCustomerId, GetMeetingId)
            End If
            Return _AssignedAgendaSessions
        End Get
    End Property

    Public ReadOnly Property SubWebProducts() As TIMSS.API.WebInfo.ITmarWebProductViewList
        Get
            If _WebProducts Is Nothing Then
                _WebProducts = Me.get_clsProductHelper.GetSubProducts(Convert.ToInt32(GetMeetingId()), Nothing)
            End If
            Return _WebProducts
        End Get
    End Property

    Public WriteOnly Property SetVisibilityForTrackFields() As Boolean
        Set(ByVal value As Boolean)
            tdMeetingTrackLabel.Visible = value
            tdMeetingTrack.Visible = value
        End Set
    End Property


#End Region



#Region "Helper functions"

    Private Function GroupBy(ByVal i_sGroupByColumn As String, ByVal i_dSourceTable As DataTable, ByVal appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes) As DataTable
        'getting distinct values for group column
        Dim dv As New DataView(i_dSourceTable)
        Dim dtGroup As DataTable = dv.ToTable(True, New String() {i_sGroupByColumn})

        dtGroup.Columns.Add("Description", GetType(String))

        For Each row As DataRow In dtGroup.Rows
            If appCodes IsNot Nothing Then
                If appCodes.Table.Select(String.Concat("CODE='", row.Item(0), "'")).Length > 0 Then
                    row.Item(1) = appCodes.Table.Select(String.Concat("CODE='", row.Item(0), "'"))(0).Item("DESCR")
                End If
            End If

        Next

        Return dtGroup
    End Function



    Private Sub SetupControls()

        Dim tblSource As DataTable
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes

        If Me.SubWebProducts IsNot Nothing Then
            appCodes = GetApplicationCodes("MTG", "PRODUCT_CLASS", False)
            tblSource = Me.GroupBy("PRODUCT_CLASS_CODE", Me.SubWebProducts.Table, appCodes)
            ddlEventType.DataSource = tblSource
            ddlEventType.DataTextField = "Description"
            ddlEventType.DataValueField = "PRODUCT_CLASS_CODE"
            ddlEventType.DataBind()
            ddlEventType.Items.Insert(0, New RadComboBoxItem(""))

            'START Tracks
            appCodes = GetApplicationCodes("MTG", "SESSION_TRACK", False)
            Dim trackTable As DataTable = AdvanceMeetingManager.DistinctSessionTracks_Get(SubWebProducts(0).ParentProduct).Tables(0)
            If trackTable.Rows.Count > 0 AndAlso Not String.IsNullOrEmpty(trackTable.Rows(0).Item(0)) Then 'first row might be "" 
                tblSource = Me.GroupBy("SESSION_TRACK_CODE", trackTable, appCodes)
                ddlFilterTrack.DataSource = tblSource
                ddlFilterTrack.DataTextField = "Description"
                ddlFilterTrack.DataValueField = "SESSION_TRACK_CODE"
                ddlFilterTrack.DataBind()
                ddlFilterTrack.Items.Insert(0, New RadComboBoxItem(""))
            Else
                SetVisibilityForTrackFields = False
            End If
            'END Tracks

            'WebProducts(0).mee
            tblSource = Me.GroupBy("START_DATE", Me.SubWebProducts.Table, Nothing)
            Dim dateSource As New System.Collections.Specialized.NameValueCollection
            For Each row As DataRow In tblSource.Rows
                dateSource.Add(CDate(row(0)).ToString("D"), CDate(row(0)).ToShortDateString)
            Next

            For Each key As String In dateSource.Keys
                ddlFilterDay.Items.Add(New RadComboBoxItem(key, key))
            Next
            ddlFilterDay.Items.Insert(0, New RadComboBoxItem(""))

            Dim oModuleSettingHash As Hashtable = DotNetNuke.Entities.Portals.PortalSettings.GetModuleSettings(Me.CustomModuleId)
            If oModuleSettingHash IsNot Nothing AndAlso Not String.IsNullOrEmpty(oModuleSettingHash.Item(Const_EditMyAgendaBuilderTextKey)) Then
                lblAgendaText.Visible = True
                lblAgendaText.Text = oModuleSettingHash.Item(Const_EditMyAgendaBuilderTextKey)
            End If

        Else
            Me.Visible = False
        End If
       
        'Load Intro Text

       

    End Sub


    Private Sub SetGridGroupByExpression()

        Dim expression As GridGroupByExpression = New GridGroupByExpression
        Dim gridGroupByField As GridGroupByField = New GridGroupByField

        gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Clear()

        If rdDay.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "StartDate"
            gridGroupByField.HeaderText = "Start Date"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "StartDate"
            expression.GroupByFields.Add(gridGroupByField)
            gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdTrack.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "MeetingSessionTrackCode"
            gridGroupByField.HeaderText = "Track"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "MeetingSessionTrackCode"
            expression.GroupByFields.Add(gridGroupByField)
            gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdSessionType.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "ProductClassCodeString"
            gridGroupByField.HeaderText = "Event"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "ProductClassCodeString"
            expression.GroupByFields.Add(gridGroupByField)
            gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdNone.Checked Then
            'Add date column
            'Sort by date
        End If


    End Sub


    Private Sub GetConditionDataSource()

        Dim hasParameters As Boolean
        Dim parameters As New System.Collections.Specialized.ListDictionary
        Dim oSubProduct As TIMSS.API.WebInfo.ITmarWebProductView

        If Me.ddlFilterDay.SelectedIndex > 0 OrElse Me.ddlFilterTrack.SelectedIndex > 0 OrElse Me.ddlEventType.SelectedIndex > 0 Then
            hasParameters = True
        End If


        _SwitchDataSource = False
        If hasParameters Then
            _WebProductsArray = New System.Collections.Generic.List(Of TIMSS.API.WebInfo.ITmarWebProductView)
            _SwitchDataSource = True

            For i As Integer = 0 To SubWebProducts.Count - 1
                oSubProduct = SubWebProducts(i)

                If Me.ddlFilterDay.SelectedIndex > 0 Then
                    If oSubProduct.StartDate <> CDate(ddlFilterDay.SelectedValue) Then
                        Continue For
                    End If
                End If

                If Me.ddlFilterTrack.SelectedIndex > 0 Then
                    Dim objBusinessCollection() As TIMSS.API.Core.IBusinessObject

                    objBusinessCollection = oSubProduct.MeetingSessionProductTracks.FindAll("SessionTrackCode", ddlFilterTrack.SelectedValue)
                    If objBusinessCollection.Length = 0 Then
                        Continue For
                    End If
                End If

                If Me.ddlEventType.SelectedIndex > 0 Then
                    If oSubProduct.ProductClassCode.Code <> ddlEventType.SelectedValue Then
                        Continue For
                    End If
                End If

                'If reach here - that means it reached the filter critera and adding to collection now              
                _WebProductsArray.Add(oSubProduct)
            Next


        End If

    End Sub


#End Region

#Region "Events"

    Private Sub gridAgendaBuilderSource_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridAgendaBuilderSource.PreRender

        If gridAgendaBuilderSource IsNot Nothing AndAlso gridAgendaBuilderSource.Items.Count > 0 Then

            If AssignedAgendaSessions Is Nothing Then
                Exit Sub
            End If

            Dim oRegisteredSessions As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
            oRegisteredSessions = GetMyRegisteredMeetings

            For Each gridItem As Telerik.Web.UI.GridDataItem In gridAgendaBuilderSource.Items

                Dim actionButton As Button
                Dim productId As Long = gridAgendaBuilderSource.Items(gridItem.ItemIndex)("ProductId").Text

                actionButton = CType(gridItem.Item("Column").Controls(0), Button)
                actionButton.Width = New System.Web.UI.WebControls.Unit(70, UnitType.Pixel)

                If AssignedAgendaSessions.Table.Select(String.Concat("SESSION_PRODUCT_ID =", productId)).Length > 0 Then
                    actionButton.Text = "Remove"
                    actionButton.CommandName = "REMOVE"
                    'Already registerd so can not remove it from Agenda anymore
                    If oRegisteredSessions IsNot Nothing AndAlso oRegisteredSessions.Count > 0 AndAlso _
                        oRegisteredSessions.Table.Select(String.Concat("PRODUCT_ID =", productId)).Length > 0 Then
                        actionButton.Enabled = False
                        If oRegisteredSessions.Table.Select(String.Concat("PRODUCT_ID =", productId))(0).Item("LINE_STATUS_CODE") = "W" Then
                            actionButton.Text = Const_WaitlistedButtonMessage
                        Else
                            actionButton.Text = Const_RegisteredButtonMessage
                        End If
                    End If
                Else
                    actionButton.Text = "Add"
                    actionButton.CommandName = "ADD"

                End If

            Next
        End If


    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPersonifyWebUserLoggedIn Then
            Dim role As String = GetUserRole(UserInfo)
            If Not (role = "host" OrElse role = "admin" OrElse role = "personifyadmin") Then
                RedirectToLogin()
            End If
        End If

        If Not IsPostBack Then
            SetupControls()
        End If

    End Sub

    Private Sub gridAgendaBuilderSource_ItemCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles gridAgendaBuilderSource.ItemCommand

        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection = Nothing

        Select Case e.CommandName

            Case "ADD"
                Dim productId As Long = gridAgendaBuilderSource.Items(e.Item.ItemIndex)("ProductId").Text
                Dim lblSpeaker As Label
                Dim lblSessionTrack As Label
                lblSpeaker = CType(e.Item.FindControl("lblSpeaker"), Label)
                lblSessionTrack = CType(e.Item.FindControl("lblSessionTrack"), Label)
                Dim oWebProduct As TIMSS.API.WebInfo.ITmarWebProductView

                oWebProduct = Me.Meeting_Product_Get(productId) ' _WebProducts.FindObject("ProductId", productId)
                If oWebProduct IsNot Nothing Then
                    oIssues = AdvanceMeetingManager.MyMeetingAgenda_Add(Me.MasterCustomerId, Me.SubCustomerId, GetMeetingId, oWebProduct, lblSpeaker.Text, lblSessionTrack.Text)
                    If oIssues.ErrorCount = 0 Then
                        _AssignedAgendaSessions = Nothing
                        gridAgendaBuilderSource.Rebind()
                    Else
                        e.Canceled = True
                    End If
                End If
            Case "REMOVE"
                Dim productId As Long = gridAgendaBuilderSource.Items(e.Item.ItemIndex)("ProductId").Text
                oIssues = AdvanceMeetingManager.MyMeetingAgenda_ProductId_Delete(Me.MasterCustomerId, Me.SubCustomerId, productId)

                If oIssues.ErrorCount = 0 Then
                    _AssignedAgendaSessions = Nothing
                    gridAgendaBuilderSource.Rebind()
                Else
                    e.Canceled = True
                End If
        End Select

        If oIssues IsNot Nothing AndAlso oIssues.ErrorCount > 0 Then
            Me.ShowPopupMessage(oIssues)
        End If

    End Sub

    Private Sub gridAgendaBuilderSource_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles gridAgendaBuilderSource.ItemDataBound
        If TypeOf e.Item Is GridGroupHeaderItem Then
            Dim item As GridGroupHeaderItem = CType(e.Item, GridGroupHeaderItem)
            Dim groupDataRow As DataRowView = CType(e.Item.DataItem, DataRowView)

            If rdDay.Checked Then
                item.DataCell.Text = CDate(groupDataRow("StartDate")).ToString("D")
                item.DataCell.Text = String.Concat("<h4>", item.DataCell.Text, "</h4>")
            End If

            If rdTrack.Checked Then
                'Track is not required - hence we need to make null value as empty string
                Dim radItem As RadComboBoxItem = ddlFilterTrack.FindItemByValue(groupDataRow("MeetingSessionTrackCode"))
                If radItem IsNot Nothing Then
                    item.DataCell.Text = String.Concat("<h4>", radItem.Text, "</h4>")
                Else
                    item.DataCell.Text = String.Empty
                End If
            End If

            If rdSessionType.Checked Then
                'Product class code is required - hence not checking for null value
                Dim radItem As RadComboBoxItem = ddlEventType.FindItemByValue(groupDataRow("ProductClassCodeString"))
                If radItem IsNot Nothing Then
                    item.DataCell.Text = String.Concat("<h4>", radItem.Text, "</h4>")
                End If
            End If
        ElseIf TypeOf e.Item Is GridDataItem Then

            Dim lblSpeaker As Label
            Dim pnlSpeaker As Panel
            Dim pnlTrack As Panel
            Dim lblSessionTrack As Label
            Dim dataItem As GridDataItem = DirectCast(e.Item, GridDataItem)
            Dim dataItemSource As TIMSS.API.WebInfo.ITmarWebProductView
            dataItemSource = e.Item.DataItem
            lblSpeaker = CType(dataItem.FindControl("lblSpeaker"), Label)
            pnlSpeaker = CType(dataItem.FindControl("pnlSpeaker"), Panel)
            lblSessionTrack = CType(dataItem.FindControl("lblSessionTrack"), Label)
            pnlTrack = CType(dataItem.FindControl("pnlTrack"), Panel)

            Dim speakerObjects() As TIMSS.API.Core.IBusinessObject
            speakerObjects = dataItemSource.RelatedCustomers.FindAll("CusrelationCode", "SPEAKER")

            If speakerObjects.Length > 0 Then
                For i As Integer = 0 To speakerObjects.Length - 1
                    If String.IsNullOrEmpty(lblSpeaker.Text) Then
                        lblSpeaker.Text = CType(speakerObjects(i), TIMSS.API.ProductInfo.IProductRelatedCustomer).LabelName
                    Else
                        lblSpeaker.Text = String.Concat(lblSpeaker.Text, ", ", CType(speakerObjects(i), TIMSS.API.ProductInfo.IProductRelatedCustomer).LabelName)
                    End If
                Next
            End If

            Dim totalSize As Integer = dataItemSource.MeetingSessionProductTracks.Count - 1
            Dim trackBuilder As New System.Text.StringBuilder
            For i As Integer = 0 To dataItemSource.MeetingSessionProductTracks.Count - 1
                If String.IsNullOrEmpty(trackBuilder.ToString) Then
                    trackBuilder.Append(dataItemSource.MeetingSessionProductTracks(i).SessionTrackCode.Description)
                Else
                    trackBuilder.Append(", ")
                    trackBuilder.Append(dataItemSource.MeetingSessionProductTracks(i).SessionTrackCode.Description)
                End If
            Next

            If String.IsNullOrEmpty(trackBuilder.ToString) Then
                pnlTrack.Visible = False
            Else
                pnlTrack.Visible = True
                lblSessionTrack.Text = trackBuilder.ToString
            End If

            If String.IsNullOrEmpty(lblSpeaker.Text) Then
                pnlSpeaker.Visible = False
            Else
                pnlSpeaker.Visible = True
            End If

            'Dim radItem As Telerik.Web.UI.RadComboBoxItem
            'radItem = ddlFilterTrack.Items.FindItemByValue(dataItemSource.MeetingSessionTrackCode)
            'If radItem IsNot Nothing Then
            '            lblSessionTrack.Text = radItem.Text
            '       End If

        End If


    End Sub

    Private Sub gridAgendaBuilderSource_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles gridAgendaBuilderSource.NeedDataSource

        SetGridGroupByExpression()

        GetConditionDataSource()

        If _SwitchDataSource = False Then
            gridAgendaBuilderSource.DataSource = SubWebProducts
        Else
            gridAgendaBuilderSource.DataSource = _WebProductsArray
        End If


    End Sub

    Private Sub rdDay_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdDay.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub rdNone_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdNone.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub rdSessionType_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdSessionType.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub


    Private Sub rdTrack_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdTrack.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub ddlEventType_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlEventType.SelectedIndexChanged

        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub ddlFilterDay_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlFilterDay.SelectedIndexChanged

        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub ddlFilterTrack_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlFilterTrack.SelectedIndexChanged

        gridAgendaBuilderSource.Rebind()
    End Sub
#End Region












End Class
