
Imports TIMSS.API.Core

Imports TIMSS.Server.ResourceStorage
Imports TIMSS.Server.ResourceStorage.Authentication
Imports TIMSS.Server.ResourceStorage.InstallationDatabase
Imports TIMSS.Server.ResourceStorage.Ping

Imports System.Reflection
Imports System.Text
Imports Constants

Imports TIMSS.DataAccess
Imports TIMSS.SqlObjects
Imports TIMSS.Interfaces

Imports Personify.ApplicationManager
Imports Telerik.Web.UI

Imports AdvanceMeetingHelper

Public Class MyAgenda
    Inherits AdvanceMeetingBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Controls & Variables & Properties"

    Protected WithEvents GridSourceList As Telerik.Web.UI.RadGrid
    Protected WithEvents butDownloadOutlook As Button

    Protected WithEvents rdDay As CheckBox
    Protected WithEvents rdAgendaType As CheckBox
    Protected WithEvents rdNone As CheckBox

    Protected WithEvents ddlFilterDay As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlEventType As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlFilterTrack As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlAgendaType As Telerik.Web.UI.RadComboBox
    Protected WithEvents lblAgendaText As Label

    Private _MyAgendaDatasource As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
    Private _MyAgendaDatasourceList As System.Collections.Generic.List(Of TIMSS.API.CustomerInfo.ICustomerMeetingAgenda)
    Private _SwitchDataSource As Boolean

    Public ReadOnly Property MyAgendaDatasource() As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        Get
            If _MyAgendaDatasource Is Nothing Then
                'Don't cache this               
                _MyAgendaDatasource = AdvanceMeetingManager.MyMeetingAgenda_Get(Me.MasterCustomerId, Me.SubCustomerId, GetMeetingId)
            End If
            Return _MyAgendaDatasource
        End Get
        
    End Property

    Public ReadOnly Property MyAgendaDatasourceList() As System.Collections.Generic.List(Of TIMSS.API.CustomerInfo.ICustomerMeetingAgenda)
        Get
            If _MyAgendaDatasourceList Is Nothing Then
                _MyAgendaDatasourceList = New System.Collections.Generic.List(Of TIMSS.API.CustomerInfo.ICustomerMeetingAgenda)
            End If
            Return _MyAgendaDatasourceList
        End Get
    End Property
#End Region



#Region "Helper functions"


    Private Sub GetConditionDataSource()


        Dim parameters As New System.Collections.Specialized.ListDictionary

        If Me.ddlFilterDay.SelectedIndex > 0 Then
            parameters.Add("AppointmentStartDate", CDate(ddlFilterDay.SelectedValue))
        End If

        If Me.ddlAgendaType.SelectedIndex > 0 Then
            parameters.Add("AppointmentTypeCodeString", ddlAgendaType.SelectedValue)
        End If
        '_MyAgendaDatasource

        'If Me.ddlFilterTrack.SelectedIndex > 0 Then
        '    parameters.Add("MeetingSessionTrackCode", ddlFilterTrack.SelectedValue)

        'End If
        'If Me.ddlEventType.SelectedIndex > 0 Then
        '    parameters.Add("ProductClassCode", ddlEventType.SelectedValue)
        'End If

        _SwitchDataSource = False
        If parameters.Count > 0 Then
            _SwitchDataSource = True
            Dim objBusinessCollection() As TIMSS.API.Core.IBusinessObject
            objBusinessCollection = MyAgendaDatasource.FindAll(parameters)
            For Each objBusiness As TIMSS.API.Core.IBusinessObject In objBusinessCollection
                MyAgendaDatasourceList.Add(objBusiness)
            Next
        End If

    End Sub

    Private Function GroupBy(ByVal i_sGroupByColumn As String, ByVal i_dSourceTable As DataTable, ByVal appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes) As DataTable
        'getting distinct values for group column
        Dim dv As New DataView(i_dSourceTable)
        Dim dtGroup As DataTable = dv.ToTable(True, New String() {i_sGroupByColumn})

        dtGroup.Columns.Add("Description", GetType(String))

        For Each row As DataRow In dtGroup.Rows
            If appCodes IsNot Nothing Then
                If appCodes.Table.Select(String.Concat("CODE='", row.Item(0), "'")).Length > 0 Then
                    row.Item(1) = appCodes.Table.Select(String.Concat("CODE='", row.Item(0), "'"))(0).Item("DESCR")
                End If
            End If
        Next

        Return dtGroup
    End Function


    Private Sub SetupControls()

        Dim tblSource As DataTable
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
        'SESSION_TYPE_CODE

        appCodes = GetApplicationCodes("MTG", "PRODUCT_CLASS", False)
        tblSource = Me.GroupBy("SESSION_TYPE_CODE", MyAgendaDatasource.Table, appCodes)
        ddlEventType.DataSource = tblSource
        ddlEventType.DataTextField = "Description"
        ddlEventType.DataValueField = "SESSION_TYPE_CODE"
        ddlEventType.DataBind()
        ddlEventType.Items.Insert(0, New RadComboBoxItem(""))

        appCodes = GetApplicationCodes("MTG", "APPOINTMENT_TYPE", False)
        tblSource = Me.GroupBy("APPOINTMENT_TYPE_CODE", MyAgendaDatasource.Table, appCodes)
        ddlAgendaType.DataSource = tblSource
        ddlAgendaType.DataTextField = "Description"
        ddlAgendaType.DataValueField = "APPOINTMENT_TYPE_CODE"
        ddlAgendaType.DataBind()
        ddlAgendaType.Items.Insert(0, New RadComboBoxItem(""))

        'START Tracks
        appCodes = GetApplicationCodes("MTG", "SESSION_TRACK", False)        
        tblSource = Me.GroupBy("SESSION_TRACK_CODE", MyAgendaDatasource.Table, appCodes)
        ddlFilterTrack.DataSource = tblSource
        ddlFilterTrack.DataTextField = "Description"
        ddlFilterTrack.DataValueField = "SESSION_TRACK_CODE"
        ddlFilterTrack.DataBind()
        ddlFilterTrack.Items.Insert(0, New RadComboBoxItem(""))
        'END Tracks
        'MyAgendaDatasource(0).AppointmentStartDate
        tblSource = Me.GroupBy("APPOINTMENT_START_DATE_TIME", MyAgendaDatasource.Table, Nothing)
        Dim dateSource As New System.Collections.Specialized.NameValueCollection
        For Each row As DataRow In tblSource.Rows
            dateSource.Add(CDate(row(0)).ToString("D"), CDate(row(0)).ToShortDateString)
        Next

        For Each key As String In dateSource.Keys
            ddlFilterDay.Items.Add(New RadComboBoxItem(key, key))
        Next
        ddlFilterDay.Items.Insert(0, New RadComboBoxItem(""))

        'Load Intro Text

        Dim oModuleSettingHash As Hashtable = DotNetNuke.Entities.Portals.PortalSettings.GetModuleSettings(Me.CustomModuleId)
        If oModuleSettingHash IsNot Nothing AndAlso Not String.IsNullOrEmpty(oModuleSettingHash.Item(Const_EditMyAgendaTextKey)) Then
            lblAgendaText.Visible = True
            lblAgendaText.Text = oModuleSettingHash.Item(Const_EditMyAgendaTextKey)
        End If
    End Sub

    Private Sub SetGridGroupByExpression()

        Dim expression As GridGroupByExpression = New GridGroupByExpression
        Dim gridGroupByField As GridGroupByField = New GridGroupByField

        GridSourceList.MasterTableView.GroupByExpressions.Clear()

        If rdDay.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "AppointmentStartDate"
            gridGroupByField.HeaderText = "Appointment Start Date"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "AppointmentStartDate"
            expression.GroupByFields.Add(gridGroupByField)
            GridSourceList.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdAgendaType.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "AppointmentTypeCodeString"
            gridGroupByField.HeaderText = "Agenda Type"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "AppointmentTypeCodeString"
            expression.GroupByFields.Add(gridGroupByField)
            GridSourceList.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdNone.Checked Then
            'Add date column
            'Sort by date
        End If

    End Sub
#End Region

#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPersonifyWebUserLoggedIn Then
            Dim role As String = GetUserRole(UserInfo)
            If Not (role = "host" OrElse role = "admin" OrElse role = "personifyadmin") Then
                RedirectToLogin()
            End If
        End If

        If Not IsPostBack Then
            SetupControls()
        End If

    End Sub

    Private Sub GridSourceList_DeleteCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridSourceList.DeleteCommand

        Dim agendaID As Long = GridSourceList.Items(e.Item.ItemIndex)("AppointmentId").Text

        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
        oIssues = AdvanceMeetingManager.MyMeetingAgenda_Delete(Me.MasterCustomerId, Me.SubCustomerId, agendaID)

        If oIssues.ErrorCount = 0 Then
            'Display confirmation
        Else
            e.Canceled = True
            'Display error message
        End If
    End Sub

    Private Sub GridSourceList_InsertCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GridSourceList.InsertCommand

        Dim editedItem As Telerik.Web.UI.GridEditableItem = CType(e.Item, Telerik.Web.UI.GridEditableItem)
        Dim newValues As Hashtable = New Hashtable
        'The GridTableView will fill the values from all editable columns in the hash
        e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editedItem)

        Try
            Dim editItem As GridEditFormItem = DirectCast(e.Item, GridEditFormItem)
            Dim radStartDateTime As RadDateTimePicker = DirectCast(editItem.FindControl("radStartDateTime"), RadDateTimePicker)
            Dim radEndDateTime As RadDateTimePicker = DirectCast(editItem.FindControl("radEndDateTime"), RadDateTimePicker)
            Dim txtTitle As RadTextBox = DirectCast(editItem.FindControl("txtTitle"), RadTextBox)
            Dim txtDescription As RadTextBox = DirectCast(editItem.FindControl("txtDescription"), RadTextBox)

            Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection
            oIssues = AdvanceMeetingManager.MyMeetingAgendaPersonal_Add(GetMeetingId(), Me.MasterCustomerId, Me.SubCustomerId, radStartDateTime.SelectedDate, radEndDateTime.SelectedDate, txtTitle.Text, txtDescription.Text)

            If oIssues.ErrorCount > 0 Then
                e.Canceled = True
                Me.ShowPopupMessage(oIssues)
            Else
                GridSourceList.Rebind()
            End If

        Catch ex As Exception
            e.Canceled = True
        End Try
    End Sub

    Private Sub GridSourceList_ItemCreated(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles GridSourceList.ItemCreated
        If TypeOf e.Item Is GridCommandItem Then
            Dim commandItem As GridCommandItem = CType(e.Item, GridCommandItem)
            Dim AddButton As LinkButton
            Dim RebindButton As LinkButton
            Dim RefreshButton As Button
            Dim NewButton As Button
            NewButton = CType(commandItem.FindControl("AddNewRecordButton"), Button)
            NewButton.Visible = True
            AddButton = CType(commandItem.FindControl("InitInsertButton"), LinkButton)
            AddButton.Text = "<b>Add Personal Appointment</b>"
            RebindButton = CType(commandItem.FindControl("RebindGridButton"), LinkButton)
            RebindButton.Visible = False
            RefreshButton = CType(commandItem.FindControl("RefreshButton"), Button)
            RefreshButton.Visible = False
        End If
    End Sub


    Private Sub GridSourceList_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles GridSourceList.ItemDataBound

        If TypeOf e.Item Is GridGroupHeaderItem Then

            If rdDay.Checked Then
                Dim item As GridGroupHeaderItem = CType(e.Item, GridGroupHeaderItem)
                Dim groupDataRow As DataRowView = CType(e.Item.DataItem, DataRowView)
                item.DataCell.Text = CDate(groupDataRow("AppointmentStartDate")).ToString("D")
                item.DataCell.Text = String.Concat("<h4>", item.DataCell.Text, "</h4>")

            ElseIf rdAgendaType.Checked Then
                'Product class code is required - hence not checking for null value
                Dim item As GridGroupHeaderItem = CType(e.Item, GridGroupHeaderItem)
                Dim groupDataRow As DataRowView = CType(e.Item.DataItem, DataRowView)

                Dim radItem As RadComboBoxItem = Me.ddlAgendaType.FindItemByValue(groupDataRow("AppointmentTypeCodeString"))
                If radItem IsNot Nothing Then
                    item.DataCell.Text = String.Concat("<h4>", radItem.Text, "</h4>")
                End If

            End If

        ElseIf TypeOf e.Item Is GridDataItem Then

            Dim lblTrackCode As Label
            Dim dataItem As GridDataItem = DirectCast(e.Item, GridDataItem)
            Dim dataItemSource As TIMSS.API.CustomerInfo.ICustomerMeetingAgenda
            dataItemSource = e.Item.DataItem
            lblTrackCode = CType(dataItem.FindControl("lblTrackCode"), Label)
            lblTrackCode.Text = dataItemSource.SessionTrackCode
            'Dim radItem As Telerik.Web.UI.RadComboBoxItem
            'radItem = ddlFilterTrack.Items.FindItemByValue(dataItemSource.SessionTrackCode)
            'If radItem IsNot Nothing Then
            ' lblTrackCode.Text = radItem.Text
            'End If
        End If

    End Sub

    Private Sub GridSourceList_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GridSourceList.NeedDataSource
        SetGridGroupByExpression()
        GetConditionDataSource()

        If Me._SwitchDataSource = False Then
            GridSourceList.DataSource = MyAgendaDatasource
        Else
            GridSourceList.DataSource = MyAgendaDatasourceList
        End If

        If GridSourceList.DataSource Is Nothing Then
            Me.butDownloadOutlook.Visible = False
        End If
    End Sub

    Private Sub GridSourceList_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridSourceList.PreRender

        If GridSourceList IsNot Nothing AndAlso GridSourceList.Items.Count > 0 AndAlso Not String.IsNullOrEmpty(Me.RegisteredOrderNumber) Then

            Dim oRegisteredSessions As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
            oRegisteredSessions = GetMyRegisteredMeetings
            If oRegisteredSessions Is Nothing OrElse oRegisteredSessions.Count = 0 Then
                Exit Sub
            End If

            For Each gridItem As Telerik.Web.UI.GridDataItem In GridSourceList.Items
                Dim actionButton As Button                
                Dim sessionProductId As Long

                sessionProductId = GridSourceList.Items(gridItem.ItemIndex)("SessionProductId").Text
                actionButton = CType(gridItem.Item("Column").Controls(0), Button)                
                actionButton.Width = New System.Web.UI.WebControls.Unit(70, UnitType.Pixel)
           
                If oRegisteredSessions IsNot Nothing AndAlso oRegisteredSessions.Count > 0 AndAlso _
                        oRegisteredSessions.Table.Select(String.Concat("PRODUCT_ID =", sessionProductId)).Length > 0 Then
                    'Already registered - button should be hidden or disable                    
                    actionButton.Enabled = False
                    If oRegisteredSessions.Table.Select(String.Concat("PRODUCT_ID =", sessionProductId))(0).Item("LINE_STATUS_CODE") = "W" Then
                        actionButton.Text = Const_WaitlistedButtonMessage
                    Else
                        actionButton.Text = Const_RegisteredButtonMessage
                    End If
                End If
            Next


        End If

    End Sub


    Private Sub butDownloadOutlook_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butDownloadOutlook.Click
        DownLoadICSFile()
    End Sub

    Private Sub rdAgendaType_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdAgendaType.CheckedChanged
        GridSourceList.Rebind()
    End Sub

    Private Sub rdDay_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdDay.CheckedChanged
        GridSourceList.Rebind()
    End Sub

    Private Sub rdNone_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdNone.CheckedChanged
        GridSourceList.Rebind()
    End Sub

    Private Sub ddlFilterDay_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlFilterDay.SelectedIndexChanged
        GridSourceList.Rebind()
    End Sub

    Private Sub ddlAgendaType_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlAgendaType.SelectedIndexChanged
        GridSourceList.Rebind()
    End Sub


   
#End Region


#Region "Download files"

    Private Sub DownLoadICSFile()

        Dim odsAgenda As DataSet

        Dim TZUSEastern As String = "US/Eastern"
        Dim TZUSCentral As String = "US/Central"
        Dim TZUSMountain As String = "US/Mountain"
        Dim TZUSPacific As String = "US/Pacific"

        odsAgenda = GetSelectRequest_GetMyAgenda(GetMeetingId, MasterCustomerId, SubCustomerId)

        ' new string builder for ics file
        Dim sbICSFile As StringBuilder = New StringBuilder()
        Dim dtNow As DateTime = DateTime.Now

        'header string
        sbICSFile.AppendLine("BEGIN:VCALENDAR")
        sbICSFile.AppendLine("VERSION:2.0")
        sbICSFile.AppendLine("PRODID:-//AssociationX/CalendarAppointment")
        sbICSFile.AppendLine("CALSCALE:GREGORIAN")



        For Each oRow As DataRow In odsAgenda.Tables(0).Rows

            sbICSFile.AppendLine("BEGIN:VEVENT")
            sbICSFile.AppendLine(ICSFile_AppendTimeZones)

            'Start Date
            sbICSFile.Append("DTSTART;TZID=" + TZUSEastern + ":")
            sbICSFile.Append(GetYearFromDAte(oRow("APPOINTMENT_START_DATE_TIME")))
            sbICSFile.Append(GetMonthFromDAte(oRow("APPOINTMENT_START_DATE_TIME")))
            sbICSFile.Append(GetDayFromDAte(oRow("APPOINTMENT_START_DATE_TIME")))
            sbICSFile.Append("T")
            sbICSFile.AppendLine(GetTimeFromDAte(oRow("APPOINTMENT_START_DATE_TIME")))


            'End Date
            sbICSFile.Append("DTEND;TZID=" + TZUSEastern + ":")
            sbICSFile.Append(GetYearFromDAte(oRow("APPOINTMENT_END_DATE_TIME")))
            sbICSFile.Append(GetMonthFromDAte(oRow("APPOINTMENT_END_DATE_TIME")))
            sbICSFile.Append(GetDayFromDAte(oRow("APPOINTMENT_END_DATE_TIME")))
            sbICSFile.Append("T")
            sbICSFile.AppendLine(GetTimeFromDAte(oRow("APPOINTMENT_END_DATE_TIME")))


            sbICSFile.AppendLine("SUMMARY:" + oRow("APPOINTMENT_TITLE"))
            sbICSFile.AppendLine("DESCRIPTION:" + ConstructSummary(oRow))

            sbICSFile.AppendLine("UID:" + oRow("APPOINTMENT_ID").ToString)
            'sbICSFile.AppendLine(ConstructHTMLSummary(oRow))
            sbICSFile.AppendLine("SEQUENCE:0")

            sbICSFile.Append("DTSTAMP:" + dtNow.Year.ToString())
            sbICSFile.Append(FormatDateTimeValue(dtNow.Month))
            sbICSFile.Append(FormatDateTimeValue(dtNow.Day) + "T")
            sbICSFile.Append(FormatDateTimeValue(dtNow.Hour))
            sbICSFile.AppendLine(FormatDateTimeValue(dtNow.Minute) + "00")

            sbICSFile.AppendLine("END:VEVENT")


        Next


        sbICSFile.AppendLine("END:VCALENDAR")


        Response.ContentType = "text/calendar"

        Response.AddHeader("content-disposition", String.Concat("attachment; filename=", ParentProductCode, ".ics"))

        Response.Write(sbICSFile)
        Response.End()




    End Sub
    Private Function ConstructHTMLSummary(ByVal pRow As DataRow) As String

        Dim sbApptSummary As StringBuilder = New StringBuilder()
        sbApptSummary.AppendLine("X-ALT-DESC;FMTTYPE=text/html:<!DOCTYPE HTML PUBLIC -//W3C//DTD HTML 3.2//EN(>\n<HTML>\n")
        sbApptSummary.Append(pRow("APPOINTMENT_DESCRIPTION"))
        sbApptSummary.Append("</br>")
        If pRow("SESSION_TRACK_CODE") IsNot System.DBNull.Value AndAlso pRow("SESSION_TRACK_CODE").ToString.Length > 0 Then
            sbApptSummary.Append(String.Concat("Track: ", pRow("SESSION_TRACK_CODE")))
            sbApptSummary.Append("</br>")
        End If

        If pRow("SPEAKER_NAME") IsNot System.DBNull.Value AndAlso pRow("SPEAKER_NAME").ToString.Length > 0 Then
            sbApptSummary.Append(String.Concat("Speaker Name: ", pRow("SPEAKER_NAME")))
            sbApptSummary.Append("</br>")
        End If


        sbApptSummary.Append("\n</HTML>")

        If pRow("SESSION_TRACK_CODE") IsNot System.DBNull.Value AndAlso pRow("SESSION_TRACK_CODE").ToString.Length > 0 Then
            sbApptSummary.Append(String.Concat("Track: ", pRow("SESSION_TRACK_CODE")))
            'sbApptSummary.Append("</br>")
        End If

        If pRow("SPEAKER_NAME") IsNot System.DBNull.Value AndAlso pRow("SPEAKER_NAME").ToString.Length > 0 Then
            sbApptSummary.Append(String.Concat("Speaker Name: ", pRow("SPEAKER_NAME")))
            ' sbApptSummary.Append("</br>")
        End If


        Return sbApptSummary.ToString



    End Function
    Private Function ConstructSummary(ByVal pRow As DataRow) As String

        Dim sbApptSummary As StringBuilder = New StringBuilder()


        sbApptSummary.Append(pRow("APPOINTMENT_DESCRIPTION"))

        sbApptSummary.Append("\n")

        If pRow("SESSION_TRACK_CODE") IsNot System.DBNull.Value AndAlso pRow("SESSION_TRACK_CODE").ToString.Length > 0 Then
            sbApptSummary.Append(String.Concat("Track: ", pRow("SESSION_TRACK_CODE")))

        End If
        sbApptSummary.Append("\n")

        If pRow("SPEAKER_NAME") IsNot System.DBNull.Value AndAlso pRow("SPEAKER_NAME").ToString.Length > 0 Then
            sbApptSummary.Append(String.Concat("Speaker Name: ", pRow("SPEAKER_NAME")))
            ' sbApptSummary.Append("</br>")
        End If


        Return sbApptSummary.ToString



    End Function
    Private Function GetYearFromDAte(ByVal pDate As Object) As String
        Return DirectCast(pDate, Date).Year.ToString
    End Function
    Private Function GetMonthFromDAte(ByVal pDate As Object) As String
        Return FormatDateTimeValue(DirectCast(pDate, Date).Month)
    End Function
    Private Function GetDayFromDAte(ByVal pDate As Object) As String
        Return FormatDateTimeValue(DirectCast(pDate, Date).Day)
    End Function
    Private Function GetTimeFromDAte(ByVal pDate As Object) As String
        Return DirectCast(pDate, Date).TimeOfDay.ToString
    End Function


    Private Function FormatDateTimeValue(ByVal DateValue As Int16) As String
        If DateValue < 10 Then
            Return "0" + DateValue.ToString()
        Else
            Return DateValue.ToString()
        End If
    End Function



    Private Function ICSFile_AppendTimeZones() As String

        Dim icsTimeZones As New StringBuilder

        ' Define time zones.
        ' US/Eastern
        icsTimeZones.AppendLine("BEGIN:VTIMEZONE")
        icsTimeZones.AppendLine("TZID:US/Eastern")
        icsTimeZones.AppendLine("BEGIN:STANDARD")
        icsTimeZones.AppendLine("DTSTART:20071104T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=1SU;BYMONTH=11")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0400")
        icsTimeZones.AppendLine("TZOFFSETTO:-0500")
        icsTimeZones.AppendLine("TZNAME:EST")
        icsTimeZones.AppendLine("END:STANDARD")
        icsTimeZones.AppendLine("BEGIN:DAYLIGHT")
        icsTimeZones.AppendLine("DTSTART:20070311T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=2SU;BYMONTH=3")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0500")
        icsTimeZones.AppendLine("TZOFFSETTO:-0400")
        icsTimeZones.AppendLine("TZNAME:EDT")
        icsTimeZones.AppendLine("END:DAYLIGHT")
        icsTimeZones.AppendLine("END:VTIMEZONE")

        ' US/Central
        icsTimeZones.AppendLine("BEGIN:VTIMEZONE")
        icsTimeZones.AppendLine("TZID:US/Central")
        icsTimeZones.AppendLine("BEGIN:STANDARD")
        icsTimeZones.AppendLine("DTSTART:20071104T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=1SU;BYMONTH=11")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0500")
        icsTimeZones.AppendLine("TZOFFSETTO:-0600")
        icsTimeZones.AppendLine("TZNAME:CST")
        icsTimeZones.AppendLine("END:STANDARD")
        icsTimeZones.AppendLine("BEGIN:DAYLIGHT")
        icsTimeZones.AppendLine("DTSTART:20070311T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=2SU;BYMONTH=3")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0600")
        icsTimeZones.AppendLine("TZOFFSETTO:-0500")
        icsTimeZones.AppendLine("TZNAME:CDT")
        icsTimeZones.AppendLine("END:DAYLIGHT")

        icsTimeZones.AppendLine("END:VTIMEZONE")

        ' US/Mountain
        icsTimeZones.AppendLine("BEGIN:VTIMEZONE")
        icsTimeZones.AppendLine("TZID:US/Mountain")
        icsTimeZones.AppendLine("BEGIN:STANDARD")
        icsTimeZones.AppendLine("DTSTART:20071104T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=1SU;BYMONTH=11")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0600")
        icsTimeZones.AppendLine("TZOFFSETTO:-0700")
        icsTimeZones.AppendLine("TZNAME:MST")
        icsTimeZones.AppendLine("END:STANDARD")
        icsTimeZones.AppendLine("BEGIN:DAYLIGHT")
        icsTimeZones.AppendLine("DTSTART:20070311T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=2SU;BYMONTH=3")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0700")
        icsTimeZones.AppendLine("TZOFFSETTO:-0600")
        icsTimeZones.AppendLine("TZNAME:MDT")
        icsTimeZones.AppendLine("END:DAYLIGHT")
        icsTimeZones.AppendLine("END:VTIMEZONE")

        ' US/Pacific
        icsTimeZones.AppendLine("BEGIN:VTIMEZONE")
        icsTimeZones.AppendLine("TZID:US/Pacific")
        icsTimeZones.AppendLine("BEGIN:STANDARD")
        icsTimeZones.AppendLine("DTSTART:20071104T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=1SU;BYMONTH=11")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0700")
        icsTimeZones.AppendLine("TZOFFSETTO:-0800")
        icsTimeZones.AppendLine("TZNAME:PST")
        icsTimeZones.AppendLine("END:STANDARD")
        icsTimeZones.AppendLine("BEGIN:DAYLIGHT")
        icsTimeZones.AppendLine("DTSTART:20070311T020000")
        icsTimeZones.AppendLine("RRULE:FREQ=YEARLY;BYDAY=2SU;BYMONTH=3")
        icsTimeZones.AppendLine("TZOFFSETFROM:-0800")
        icsTimeZones.AppendLine("TZOFFSETTO:-0700")
        icsTimeZones.AppendLine("TZNAME:PDT")
        icsTimeZones.AppendLine("END:DAYLIGHT")
        icsTimeZones.AppendLine("END:VTIMEZONE")


        Return icsTimeZones.ToString


    End Function

    Private Function GetSelectRequest_GetMyAgenda(ByVal ProductId As Integer, ByVal MCID As String, ByVal SCID As Integer) As DataSet

        Dim oSelectRequest As SimpleRequest
        Dim oRequest As TIMSS.DataAccess.RequestSet = Nothing
        Dim oResultSet As TIMSS.Interfaces.IResultSet = Nothing

        Dim oDS As DataSet
        'TODO - USe API's

        Dim strSQL As New System.Text.StringBuilder

        'Build the Update Request to set the Internal Status Code and External Status Codes
        'on the Abstract

        With strSQL
            .Remove(0, .Length)
            .Append("select * from CUS_MTG_AGENDA ")
            .Append(String.Format("where master_customer_id = '{0}'", MCID))
            .Append(String.Format(" and sub_customer_id = '{0}'", SCID))
            .Append(String.Format(" and MEETING_PRODUCT_ID = '{0}'", ProductId))

        End With
        'End If
        oSelectRequest = New SimpleRequest("GetMyAgenda", strSQL.ToString)

        oRequest = New TIMSS.DataAccess.RequestSet

        oResultSet = TIMSS.[Global].App.GetData(oSelectRequest)

        oDS = oResultSet.Unpack()

        Return oDS

    End Function


#End Region

    


End Class
