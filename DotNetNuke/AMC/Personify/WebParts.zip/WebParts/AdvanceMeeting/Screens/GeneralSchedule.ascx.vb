

Imports Personify.ApplicationManager
Imports Telerik.Web.UI


Public Class GeneralSchedule
    Inherits AdvanceMeetingBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


#Region "Controls & Variables"

    Protected WithEvents gridAgendaBuilderSource As RadGrid

    Protected WithEvents rdDay As CheckBox
    Protected WithEvents rdSessionType As CheckBox
    Protected WithEvents rdNone As CheckBox
    Protected WithEvents rdTrack As CheckBox

    Protected WithEvents ddlFilterDay As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlEventType As Telerik.Web.UI.RadComboBox
    Protected WithEvents ddlFilterTrack As Telerik.Web.UI.RadComboBox



    Private _WebProducts As TIMSS.API.WebInfo.ITmarWebProductViewList
    Private _WebProductsArray As System.Collections.Generic.List(Of TIMSS.API.WebInfo.ITmarWebProductView)
    Private _SwitchDataSource As Boolean
    'Private _AssignedAgendaSessions As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas

#End Region


#Region "Helper functions"

    Private Function GroupBy(ByVal i_sGroupByColumn As String, ByVal i_dSourceTable As DataTable, ByVal appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes) As DataTable
        'getting distinct values for group column
        Dim dv As New DataView(i_dSourceTable)
        Dim dtGroup As DataTable = dv.ToTable(True, New String() {i_sGroupByColumn})

        dtGroup.Columns.Add("Description", GetType(String))

        For Each row As DataRow In dtGroup.Rows
            If appCodes IsNot Nothing Then
                If appCodes.Table.Select(String.Concat("CODE='", row.Item(0), "'")).Length > 0 Then
                    row.Item(1) = appCodes.Table.Select(String.Concat("CODE='", row.Item(0), "'"))(0).Item("DESCR")
                End If
            End If

        Next

        Return dtGroup
    End Function


    Private Sub SetAllSessionsForTheMeetingSource()

        If _WebProducts Is Nothing Then
            _WebProducts = Me.get_clsProductHelper.GetSubProducts(Convert.ToInt32(GetMeetingId()), Nothing)            
        End If

        If _WebProducts IsNot Nothing Then
            GetConditionDataSource()
        End If

    End Sub

    Private Sub SetupControls()

        SetAllSessionsForTheMeetingSource()

        Dim tblSource As DataTable
        Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes

        If _WebProducts IsNot Nothing Then
            appCodes = GetApplicationCodes("MTG", "PRODUCT_CLASS", False)
            tblSource = Me.GroupBy("PRODUCT_CLASS_CODE", Me._WebProducts.Table, appCodes)
            ddlEventType.DataSource = tblSource
            ddlEventType.DataTextField = "Description"
            ddlEventType.DataValueField = "PRODUCT_CLASS_CODE"
            ddlEventType.DataBind()
            ddlEventType.Items.Insert(0, New RadComboBoxItem(""))

            appCodes = GetApplicationCodes("MTG", "SESSION_TRACK", False)
            tblSource = Me.GroupBy("SESSION_TRACK_CODE", Me._WebProducts.Table, appCodes)

            ddlFilterTrack.DataSource = tblSource
            ddlFilterTrack.DataTextField = "Description"
            ddlFilterTrack.DataValueField = "SESSION_TRACK_CODE"
            ddlFilterTrack.DataBind()
            ddlFilterTrack.Items.Insert(0, New RadComboBoxItem(""))

            '_WebProducts(0).mee
            tblSource = Me.GroupBy("START_DATE", Me._WebProducts.Table, Nothing)
            Dim dateSource As New System.Collections.Specialized.NameValueCollection
            For Each row As DataRow In tblSource.Rows
                dateSource.Add(CDate(row(0)).ToString("D"), CDate(row(0)).ToShortDateString)
            Next

            For Each key As String In dateSource.Keys
                ddlFilterDay.Items.Add(New RadComboBoxItem(key, key))
            Next
            ddlFilterDay.Items.Insert(0, New RadComboBoxItem(""))
        Else
            Me.Visible = False
        End If
       

    End Sub


    Private Sub SetGridGroupByExpression()

        Dim expression As GridGroupByExpression = New GridGroupByExpression
        Dim gridGroupByField As GridGroupByField = New GridGroupByField

        gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Clear()

        If rdDay.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "StartDate"
            gridGroupByField.HeaderText = "Start Date"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "StartDate"
            expression.GroupByFields.Add(gridGroupByField)
            gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdTrack.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "MeetingSessionTrackCode"
            gridGroupByField.HeaderText = "Track"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "MeetingSessionTrackCode"
            expression.GroupByFields.Add(gridGroupByField)
            gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdSessionType.Checked Then
            'SelectFields values (appear in header)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "ProductClassCodeString"
            gridGroupByField.HeaderText = "Event"
            expression.SelectFields.Add(gridGroupByField)
            'GroupByFields values (group data)
            gridGroupByField = New GridGroupByField
            gridGroupByField.FieldName = "ProductClassCodeString"
            expression.GroupByFields.Add(gridGroupByField)
            gridAgendaBuilderSource.MasterTableView.GroupByExpressions.Add(expression)
        End If

        If rdNone.Checked Then
            'Add date column
            'Sort by date
        End If


    End Sub


    Private Sub GetConditionDataSource()

        Dim parameters As New System.Collections.Specialized.ListDictionary

        If Me.ddlFilterDay.SelectedIndex > 0 Then
            parameters.Add("StartDate", CDate(ddlFilterDay.SelectedValue))
        End If

        If Me.ddlFilterTrack.SelectedIndex > 0 Then
            parameters.Add("MeetingSessionTrackCode", ddlFilterTrack.SelectedValue)
        End If

        If Me.ddlEventType.SelectedIndex > 0 Then
            parameters.Add("ProductClassCode", ddlEventType.SelectedValue)
        End If

        _SwitchDataSource = False
        If parameters.Count > 0 Then
            _SwitchDataSource = True
            Dim objBusinessCollection() As TIMSS.API.Core.IBusinessObject
            objBusinessCollection = _WebProducts.FindAll(parameters)
            _WebProductsArray = New System.Collections.Generic.List(Of TIMSS.API.WebInfo.ITmarWebProductView)
            For Each objBusiness As TIMSS.API.Core.IBusinessObject In objBusinessCollection
                _WebProductsArray.Add(objBusiness)
            Next
        End If

    End Sub
#End Region

#Region "Events"

    Private Sub gridAgendaBuilderSource_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridAgendaBuilderSource.PreRender

        'If gridAgendaBuilderSource IsNot Nothing AndAlso gridAgendaBuilderSource.Items.Count > 0 Then
        '    For Each gridItem As Telerik.Web.UI.GridDataItem In gridAgendaBuilderSource.Items

        '        Dim actionButton As Button
        '        Dim productId As Long = gridAgendaBuilderSource.Items(gridItem.ItemIndex)("ProductId").Text

        '        actionButton = CType(gridItem.Item("Column").Controls(0), Button)
        '        actionButton.Width = New System.Web.UI.WebControls.Unit(70, UnitType.Pixel)
        '        'Display different text / commandname if agenda have been added
        '        If _AssignedAgendaSessions IsNot Nothing AndAlso _AssignedAgendaSessions.Table.Select(String.Concat("SESSION_PRODUCT_ID =", productId)).Length > 0 Then
        '            actionButton.Text = "Remove"
        '            actionButton.CommandName = "REMOVE"
        '        Else
        '            actionButton.Text = "Add"
        '            actionButton.CommandName = "ADD"

        '        End If

        '    Next
        'End If


    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            SetupControls()
        End If

    End Sub

   
    Private Sub gridAgendaBuilderSource_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles gridAgendaBuilderSource.ItemDataBound
        If TypeOf e.Item Is GridGroupHeaderItem Then
            Dim item As GridGroupHeaderItem = CType(e.Item, GridGroupHeaderItem)
            Dim groupDataRow As DataRowView = CType(e.Item.DataItem, DataRowView)

            If rdDay.Checked Then
                item.DataCell.Text = CDate(groupDataRow("StartDate")).ToString("D")
                item.DataCell.Text = String.Concat("<h4>", item.DataCell.Text, "</h4>")
            End If

            If rdTrack.Checked Then
                'Track is not required - hence we need to make null value as empty string
                Dim radItem As RadComboBoxItem = ddlFilterTrack.FindItemByValue(groupDataRow("MeetingSessionTrackCode"))
                If radItem IsNot Nothing Then
                    item.DataCell.Text = String.Concat("<h4>", radItem.Text, "</h4>")
                Else
                    item.DataCell.Text = String.Empty
                End If
            End If

            If rdSessionType.Checked Then
                'Product class code is required - hence not checking for null value
                Dim radItem As RadComboBoxItem = ddlEventType.FindItemByValue(groupDataRow("ProductClassCodeString"))
                If radItem IsNot Nothing Then
                    item.DataCell.Text = String.Concat("<h4>", radItem.Text, "</h4>")
                End If
            End If
        ElseIf TypeOf e.Item Is GridDataItem Then

            Dim lblSpeaker As Label
            Dim pnlSpeaker As Panel
            Dim lblSessionTrack As Label
            Dim dataItem As GridDataItem = DirectCast(e.Item, GridDataItem)
            Dim dataItemSource As TIMSS.API.WebInfo.ITmarWebProductView
            dataItemSource = e.Item.DataItem
            lblSpeaker = CType(dataItem.FindControl("lblSpeaker"), Label)
            pnlSpeaker = CType(dataItem.FindControl("pnlSpeaker"), Panel)
            lblSessionTrack = CType(dataItem.FindControl("lblSessionTrack"), Label)


            '            dataItemSource.RelatedCustomers(0).CusrelationCode
            'dataItemSource.RelatedCustomers(0).LabelName

            Dim speakerObjects() As TIMSS.API.Core.IBusinessObject
            speakerObjects = dataItemSource.RelatedCustomers.FindAll("CusrelationCode", "SPEAKER")

            If speakerObjects.Length > 0 Then
                For i As Integer = 0 To speakerObjects.Length - 1
                    If String.IsNullOrEmpty(lblSpeaker.Text) Then
                        lblSpeaker.Text = CType(speakerObjects(i), TIMSS.API.ProductInfo.IProductRelatedCustomer).LabelName
                    Else
                        lblSpeaker.Text = String.Concat(lblSpeaker.Text, ", ", CType(speakerObjects(i), TIMSS.API.ProductInfo.IProductRelatedCustomer).LabelName)
                    End If
                Next
            End If
            If String.IsNullOrEmpty(lblSpeaker.Text) Then
                pnlSpeaker.Visible = False
            Else
                pnlSpeaker.Visible = True
            End If

            Dim radItem As Telerik.Web.UI.RadComboBoxItem
            radItem = ddlFilterTrack.Items.FindItemByValue(dataItemSource.MeetingSessionTrackCode)
            If radItem IsNot Nothing Then
                lblSessionTrack.Text = radItem.Text
            End If

        End If


    End Sub

    Private Sub gridAgendaBuilderSource_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles gridAgendaBuilderSource.NeedDataSource

        SetGridGroupByExpression()
        SetAllSessionsForTheMeetingSource()

        If _SwitchDataSource = False Then
            gridAgendaBuilderSource.DataSource = _WebProducts
        Else
            gridAgendaBuilderSource.DataSource = _WebProductsArray
        End If


    End Sub

    Private Sub rdDay_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdDay.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub rdNone_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdNone.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub rdSessionType_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdSessionType.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub


    Private Sub rdTrack_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdTrack.CheckedChanged
        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub ddlEventType_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlEventType.SelectedIndexChanged

        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub ddlFilterDay_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlFilterDay.SelectedIndexChanged

        gridAgendaBuilderSource.Rebind()
    End Sub

    Private Sub ddlFilterTrack_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles ddlFilterTrack.SelectedIndexChanged

        gridAgendaBuilderSource.Rebind()
    End Sub
#End Region
End Class
