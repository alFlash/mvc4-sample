Imports TIMSS.API.Core
Imports TIMSS.DataAccess
Imports TIMSS.SqlObjects
Imports TIMSS.Interfaces

Imports Personify.ApplicationManager
Imports Telerik.Web.UI


Public Class Tracks
    Inherits AdvanceMeetingBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

    End Sub

#End Region

    ''Check if the track is already a part of agenda
    'If CheckIfTrackExistsInAgenda(item("session_track_code").Text) Then
    '    btnAdd.Text = strRemove
    'Else
    '    btnAdd.Text = strAdd
    'End If

#Region "Controls & Variables & Properties"

    Protected WithEvents grdSessions As RadGrid
    Private _DistinctSessionTracks As DataSet    
    Private _GetAllSessionInformation As DataTable
    Private _TrackappCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
    Private _AssignedAgendaSessions As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
    Private _RegisteredSessions As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList

    Private ReadOnly Property DistinctSessionTracks() As DataSet
        Get
            If _DistinctSessionTracks Is Nothing Then
                _DistinctSessionTracks = AdvanceMeetingManager.DistinctSessionTracks_Get(ParentProductCode)
            End If
            Return _DistinctSessionTracks
        End Get
    End Property

    Private ReadOnly Property GetAllSessionInformation() As DataTable
        Get
            If _GetAllSessionInformation Is Nothing Then

                _GetAllSessionInformation = AdvanceMeetingManager.AllSessions_Get(ParentProductCode)
            End If

            Return _GetAllSessionInformation
        End Get
    End Property

    Public ReadOnly Property AssignedAgendaSessions() As TIMSS.API.CustomerInfo.ICustomerMeetingAgendas
        Get
            If _AssignedAgendaSessions Is Nothing Then
                _AssignedAgendaSessions = AdvanceMeetingManager.MyMeetingAgenda_Get(Me.MasterCustomerId, Me.SubCustomerId, GetMeetingId)
            End If
            Return _AssignedAgendaSessions
        End Get
    End Property

    Private ReadOnly Property RegisteredSessions() As TIMSS.API.WebInfo.ITmarWebCurrMeetingRegistrationsViewList
        Get
            If _RegisteredSessions Is Nothing Then
                _RegisteredSessions = GetMyRegisteredMeetings
            End If
            Return _RegisteredSessions
        End Get
    End Property


    Private Enum TrackStatusEnum
        AlreadyRegistered
        AddToAgenda
        None
    End Enum

#End Region


#Region "Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            SetupControls()
        End If
    End Sub


    Private Sub grdSessions_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridItemEventArgs) Handles grdSessions.ItemDataBound

        If TypeOf e.Item Is GridGroupHeaderItem Then

            Dim item As GridGroupHeaderItem = CType(e.Item, GridGroupHeaderItem)
            Dim groupDataRow As DataRowView = CType(e.Item.DataItem, DataRowView)

            If _TrackappCodes Is Nothing Then
                _TrackappCodes = GetApplicationCodes("MTG", "SESSION_TRACK", False)
            End If

            Dim dataRow() As DataRow
            Dim desc As String = String.Empty
            dataRow = _TrackappCodes.Table.Select(String.Concat("CODE='", groupDataRow("session_track_code"), "'"))

            If dataRow.Length <> 0 Then
                desc = _TrackappCodes.Table.Select(String.Concat("CODE='", groupDataRow("session_track_code"), "'"))(0).Item("DESCR")
            End If

            item.DataCell.Text = String.Concat("<h4>", desc, "</h4>")

        ElseIf TypeOf e.Item Is GridDataItem Then

            Dim item As GridDataItem = CType(e.Item, GridDataItem)
            Dim btnAdd As Button = CType(item.FindControl("btnAdd"), Button)

            Dim RadGridSessions As RadGrid = CType(item.FindControl("RadGridSessions"), RadGrid)
            RadGridSessions.ID = item("session_track_code").Text

            Dim oTrackStatus As TrackStatusEnum = Me.GetTrackStatus(item("session_track_code").Text)

            Select Case oTrackStatus
                Case TrackStatusEnum.AddToAgenda
                    btnAdd.CommandName = "DELETE"
                    btnAdd.Text = "Remove"

                Case TrackStatusEnum.AlreadyRegistered
                    btnAdd.CommandName = ""
                    btnAdd.Text = "Registered"
                    btnAdd.Enabled = False

                Case TrackStatusEnum.None
                    btnAdd.CommandName = "ADD"
                    btnAdd.Text = "Add"
            End Select

            RadGridSessions.Rebind()
        End If

    End Sub

    Private Sub grdSessions_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdSessions.PreRender

    End Sub

    Protected Sub SessionsGrid_NeedDataSource(ByVal [source] As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)
        Dim grid As RadGrid = DirectCast(source, RadGrid)
        'Hack - during rebind: this needatasource trigger before parent item data bound. therefore id wasnt getting set.
        If grid.ID <> "RadGridSessions" Then
            grid.DataSource = AdvanceMeetingManager.SessionsByTrack_Get(grid.ID, GetAllSessionInformation)
        End If
    End Sub

    Private Sub grdSessions_NeedDataSource(ByVal source As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles grdSessions.NeedDataSource
        grdSessions.DataSource = DistinctSessionTracks.Tables(0)
    End Sub

    Protected Sub AddTrackToAgenda(ByVal sender As Object, ByVal e As EventArgs)

        Dim sessionTrackName As String = DirectCast(sender, Button).CommandArgument
        Dim commandName As String = DirectCast(sender, Button).CommandName
        Dim oIssues As TIMSS.API.Core.Validation.IIssuesCollection = Nothing

        Select Case commandName
            Case "ADD"                
                Dim trackSessionSource As DataTable = AdvanceMeetingManager.SessionsByTrack_Get(sessionTrackName, GetAllSessionInformation)
                oIssues = AdvanceMeetingManager.MyMeetingAgendaByTracks_Add(MasterCustomerId, SubCustomerId, GetMeetingId, sessionTrackName, trackSessionSource)
            Case "DELETE"
                Dim dtTrack As DataTable = AdvanceMeetingManager.SessionsByTrack_Get(sessionTrackName, GetAllSessionInformation)

                oIssues = AdvanceMeetingManager.MyMeetingAgendaByTracks_Delete(MasterCustomerId, SubCustomerId, GetMeetingId, dtTrack)
        End Select

        If oIssues IsNot Nothing AndAlso oIssues.ErrorCount > 0 Then
            Me.ShowPopupMessage(oIssues)
        Else            
            Me.grdSessions.Rebind()
        End If

    End Sub

#End Region


#Region "Helper functions"

    Private Function GetTrackStatus(ByVal trackCode As String) As TrackStatusEnum

        Dim SessionsByTrackTable As DataTable
        Dim oTrackStatus As New TrackStatusEnum

        SessionsByTrackTable = AdvanceMeetingManager.SessionsByTrack_Get(trackCode, GetAllSessionInformation)

        oTrackStatus = TrackStatusEnum.None
        For i As Integer = 0 To SessionsByTrackTable.Rows.Count - 1
            Dim row As DataRow
            row = SessionsByTrackTable.Rows(i)
            If AssignedAgendaSessions.Table.Select(String.Concat("SESSION_PRODUCT_ID =", row("product_id"))).Length > 0 Then
                oTrackStatus = TrackStatusEnum.AddToAgenda
                If RegisteredSessions IsNot Nothing AndAlso RegisteredSessions.Table.Select(String.Concat("PRODUCT_ID =", row("product_id"))).Length > 0 Then
                    oTrackStatus = TrackStatusEnum.AlreadyRegistered
                End If
                Exit For
            End If
        Next
        Return oTrackStatus
    End Function

    Private Sub SetupControls()
    End Sub



#End Region




End Class
