Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.ManagePassword.Business

Namespace Personify.DNN.Modules.ManagePassword

	Public MustInherit Class ManagePasswordEdit
		Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings
#Region "Controls"
        Protected WithEvents rdInterfaceType As System.Web.UI.WebControls.RadioButtonList

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
#End Region
#Region "Constants"
        Public Const C_INTERFACE_TYPE As String = "InterfaceType"
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    LoadSettings()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                UpdateSettings()
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
#Region "Helper Functions"
        Private Sub LoadSettings()
            If Not Settings(C_INTERFACE_TYPE) Is Nothing Then
                Select Case CType(Settings(C_INTERFACE_TYPE), String)
                    Case "CreatePassword"
                        rdInterfaceType.SelectedValue = "CreatePassword"
                    Case "ChangePassword"
                        rdInterfaceType.SelectedValue = "ChangePassword"
                    Case "ChangeSSOPassword"
                        rdInterfaceType.SelectedValue = "ChangeSSOPassword"

                End Select
            Else
                rdInterfaceType.SelectedValue = "ChangePassword"
            End If
        End Sub
        Private Sub UpdateSettings()
            Dim objModules As New Entities.Modules.ModuleController
UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
            UpdateModuleSetting( C_INTERFACE_TYPE, rdInterfaceType.SelectedValue)
        End Sub

#End Region
    End Class

End Namespace
