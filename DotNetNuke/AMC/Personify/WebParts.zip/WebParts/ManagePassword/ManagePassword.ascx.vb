Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.ManagePassword.Business
Imports TIMSS.Server.BusinessMessages.EmailAndFax
Imports System.Threading
Imports System.Web.Mail
Imports System.Xml
Imports System.Xml.XPath
Imports System.Xml.Xsl
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data

Namespace Personify.DNN.Modules.ManagePassword

    Public MustInherit Class ManagePassword
		Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
#Region "Constants"
        Public Const C_INTERFACE_TYPE As String = "InterfaceType"
#End Region

#Region "Controls"
        Protected WithEvents pnlCreatePassword As System.Web.UI.WebControls.Panel
        Protected WithEvents txtNewPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtConfirmPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnUpdateCreatePassword As System.Web.UI.WebControls.Button

        Protected WithEvents pnlChangePassword As System.Web.UI.WebControls.Panel
        Protected WithEvents txtCurrentPasswordChange As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtNewPasswordChange As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtConfirmPasswordChange As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnUpdatePasswordChange As System.Web.UI.WebControls.Button
        Protected WithEvents lblUsernameValue As System.Web.UI.WebControls.Label

        Protected WithEvents PanelUpdateSSOPassword As Panel
        Protected WithEvents btnSSOUpdateCreatePassword As Button
        Protected WithEvents lblSSOUsernameValue As Label
        Protected WithEvents txtSSONewPassword As TextBox
        Protected WithEvents txtSSOConfirmPassword As TextBox


        Private m_InterfaceType As String
        Private m_WebUser As String
#End Region

#Region "Properties"
        Public Property InterfaceType() As String
            Get
                If (m_InterfaceType Is Nothing) Then
                    Return String.Empty
                Else
                    Return m_InterfaceType
                End If
            End Get
            Set(ByVal Value As String)
                m_InterfaceType = Value
            End Set
        End Property

        Public Property WebUser() As String
            Get
                Return CStr(ViewState("WebUser"))
            End Get
            Set(ByVal Value As String)
                ViewState("WebUser") = Value
            End Set
        End Property
        Public Property AdminEmailAddress() As String
            Get
                Return CStr(ViewState("AdminEmailAddress"))
            End Get
            Set(ByVal Value As String)
                ViewState("AdminEmailAddress") = Value
            End Set
        End Property

        Public Property PasswordRegularExpression() As String
            Get
                Return CStr(ViewState("PasswordRegularExpression"))
            End Get
            Set(ByVal Value As String)
                ViewState("PasswordRegularExpression") = Value
            End Set
        End Property

        
#End Region

#Region "Event Handlers"
        Private frmMasterCustomerId As String
        Private frmSubCustomerId As Integer


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim role As String
            role = Me.GetUserRole(UserInfo)


            If (role = "personifyuser" Or role = "personifyadmin") Or _
            (Not Settings(C_INTERFACE_TYPE) Is Nothing AndAlso CType(Settings(C_INTERFACE_TYPE), String) = "CreatePassword") _
            Or (Not Settings(C_INTERFACE_TYPE) Is Nothing AndAlso CType(Settings(C_INTERFACE_TYPE), String) = "ChangePassword") _
            Then

                If Request("mcid") IsNot Nothing AndAlso Convert.ToString(Request("mcid")).Length > 0 Then
                    frmMasterCustomerId = Convert.ToString(Request("mcid"))
                    frmSubCustomerId = Convert.ToString(Request("scid"))
                ElseIf UserInfo.Profile.GetPropertyValue("MasterCustomerId") IsNot Nothing Then
                    frmMasterCustomerId = MasterCustomerId
                    frmSubCustomerId = SubCustomerId
                End If

                If (frmMasterCustomerId Is Nothing OrElse Not frmMasterCustomerId.Length > 0) AndAlso (Not Settings(C_INTERFACE_TYPE) Is Nothing AndAlso Not (CType(Settings(C_INTERFACE_TYPE), String) = "CreatePassword")) Then
                    pnlCreatePassword.Visible = False
                    pnlChangePassword.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("YouCant.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Else
                    Try
                        If Not Page.IsPostBack Then
                            If GetPersonifySiteSettings(PortalId) Then
                                If Not Settings(C_INTERFACE_TYPE) Is Nothing Then
                                    If CType(Settings(C_INTERFACE_TYPE), String) = "CreatePassword" Then
                                        If ValidateApplicationId() Then
                                            Initialize()
                                        Else
                                            pnlCreatePassword.Visible = False
                                            pnlChangePassword.Visible = False
                                            PanelUpdateSSOPassword.Visible = False
                                        End If
                                    Else
                                        Initialize()
                                    End If

                                Else
                                    pnlCreatePassword.Visible = False
                                    pnlChangePassword.Visible = False
                                    PanelUpdateSSOPassword.Visible = False
                                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                                End If
                            Else
                                pnlCreatePassword.Visible = False
                                pnlChangePassword.Visible = False
                                PanelUpdateSSOPassword.Visible = False
                            End If
                        End If
                    Catch exc As Exception
                        ProcessModuleLoadException(Me, exc)
                    End Try
                End If
            Else
                pnlCreatePassword.Visible = False
                pnlChangePassword.Visible = False
                PanelUpdateSSOPassword.Visible = False
                DisplayUserAccessMessage(role)
            End If



        End Sub
        Private Sub btnUpdatePasswordChange_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpdatePasswordChange.Click
            Try
                If FormValidationPasswordChange() Then
                    UpdatePassword()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub btnUpdateCreatePassword_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpdateCreatePassword.Click
            Try
                If FormValidationPasswordCreate() Then
                    CreatePassword()

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub btnSSOUpdateCreatePassword_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSSOUpdateCreatePassword.Click
            Try
                If FormValidationSSOPasswordUpdate() Then
                    UpdateSSOPassword()
                    'SendEmailPasswordChange()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Helper functions"
        Private Sub Initialize()
            Select Case CType(Settings(C_INTERFACE_TYPE), String)
                Case "CreatePassword"
                    pnlCreatePassword.Visible = True
                    pnlChangePassword.Visible = False
                    PanelUpdateSSOPassword.Visible = False
                Case "ChangePassword"
                    If Request("mcid") IsNot Nothing AndAlso Convert.ToString(Request("mcid")).Length > 0 Then
                        pnlCreatePassword.Visible = False
                        pnlChangePassword.Visible = True
                    ElseIf Not UserInfo.Profile.ProfileProperties("MasterCustomerId") Is Nothing AndAlso Not UserInfo.Profile.ProfileProperties("SubCustomerId") Is Nothing Then
                        pnlCreatePassword.Visible = False
                        pnlChangePassword.Visible = True
                    Else
                        pnlCreatePassword.Visible = False
                        pnlChangePassword.Visible = False
                        'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("LoginMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                    PanelUpdateSSOPassword.Visible = False
                Case "ChangeSSOPassword"
                    Dim EnableSSO As String = System.Configuration.ConfigurationManager.AppSettings("EnableSSO")
                    If EnableSSO IsNot Nothing AndAlso EnableSSO.ToUpper = "Y" Then
                        pnlCreatePassword.Visible = False
                        pnlChangePassword.Visible = False
                        Me.PanelUpdateSSOPassword.Visible = True
                        'GET SSO Username via web service
                        lblSSOUsernameValue.Text = SSOLoginManager.GetSSOUserId(Me.GetCustomerToken)
                    Else
                        '//start copy from change password
                        If Request("mcid") IsNot Nothing AndAlso Convert.ToString(Request("mcid")).Length > 0 Then
                            pnlCreatePassword.Visible = False
                            pnlChangePassword.Visible = True
                        ElseIf Not UserInfo.Profile.ProfileProperties("MasterCustomerId") Is Nothing AndAlso Not UserInfo.Profile.ProfileProperties("SubCustomerId") Is Nothing Then
                            pnlCreatePassword.Visible = False
                            pnlChangePassword.Visible = True
                        Else
                            pnlCreatePassword.Visible = False
                            pnlChangePassword.Visible = False
                            'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("LoginMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        End If
                        PanelUpdateSSOPassword.Visible = False
                        '//end copy from change password
                    End If

            End Select
            InterfaceType = CType(Settings(C_INTERFACE_TYPE), String)
        End Sub

        Private Function ValidateApplicationId() As Boolean

            If Request.QueryString("reload") = "yes" Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SuccessChangeMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Return False
            End If
            If Request.QueryString("a") = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RequestPasswordMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            Dim oPasswordAssistanceData As System.Data.SqlClient.SqlDataReader
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            Dim ApplicationId As Guid = New Guid(Request.QueryString("a"))
            oPasswordAssistanceData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(ConnectionString, "dbo." & "" & "GetPersonifyPasswordAssistance", PortalId, ApplicationId), System.Data.SqlClient.SqlDataReader)
            If oPasswordAssistanceData.HasRows Then
                oPasswordAssistanceData.Read()
                WebUser = oPasswordAssistanceData.Item("UserId").ToString
                lblUsernameValue.Text = WebUser
                Dim expirationDate As Date = CType(oPasswordAssistanceData.Item("ExpirationDate").ToString, Date)
                If expirationDate.Date < Date.Today Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RecordExpiredMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If
                Dim activeFlag As Boolean = CType(oPasswordAssistanceData.Item("ActiveFlag").ToString, Boolean)
                If Not activeFlag Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RecordNotActiveMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ApplicationIdNotSetMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            oPasswordAssistanceData.Close()
            oPasswordAssistanceData = Nothing
            Return True
        End Function


        Private Function FormValidationPasswordChange() As Boolean
            Dim intMinPwdLength As Integer = 0
            'current password cannot be empty
            If txtCurrentPasswordChange.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("CurrentPasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'CurrentPassword should match the password WEB_USER table
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers

            oWebList = GetWebUser(frmMasterCustomerId, frmSubCustomerId)
            If oWebList.Count > 1 Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            If Not oWebList(0).Password = txtCurrentPasswordChange.Text Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("CurrentPasswordNotMatchMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            'New password cannot be empty
            If txtNewPasswordChange.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NewPasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'confirm password cannot be empty
            If txtConfirmPasswordChange.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ConfirmPasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'new password cannot be equal to the current password
            If txtCurrentPasswordChange.Text = txtNewPasswordChange.Text Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("CurrentEqualNewMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'new password should be equal to confirm password
            If Not txtConfirmPasswordChange.Text = txtNewPasswordChange.Text Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ConfirmNotEqualNewMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'check password format
            Dim oRegex As New System.Text.RegularExpressions.Regex(PasswordRegularExpression)
            If Not oRegex.IsMatch(txtNewPasswordChange.Text) Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidPasswordFormat", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'Check for minimum password length validation
            intMinPwdLength = DotNetNuke.Security.Membership.MembershipProvider.Instance.MinPasswordLength
            If txtNewPasswordChange.Text.Length < intMinPwdLength Then
                Skins.Skin.AddModuleMessage(Me, String.Format(Localization.GetString("MinimumPasswordLengthRequired", LocalResourceFile), intMinPwdLength.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            Return True
        End Function

        Private Sub SendEmailPasswordChange()
            Try
                If Page.IsValid Then
                    pnlCreatePassword.Visible = False
                    pnlChangePassword.Visible = False
                    Dim oEmail As New TIMSS.EmailManager

                    oEmail.To = GetEmailAddressTo()

                    If oEmail.To = String.Empty Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoEmailError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        Exit Sub
                    End If

                    Dim Subject As String = Services.Localization.Localization.GetString("EmailChangePasswordSubject", Me.LocalResourceFile)
                    oEmail.Subject = Subject

                    'from admin email address
                    Dim FromEmailAddress As String = AdminEmailAddress
                    oEmail.FromEmail = FromEmailAddress
                    oEmail.FromName = Services.Localization.Localization.GetString("EmailAdminName", Me.LocalResourceFile)

                    Dim emailTemplateFile As String = Server.MapPath(ModulePath + "Templates\EmailTemplate.xsl")

                    Dim xml As System.Xml.XmlReader = New System.Xml.XmlTextReader(New System.IO.StringReader("<?xml version='1.0'?><NewPassword></NewPassword>"))
                    Dim document As XmlDocument = New XmlDocument()
                    document.Load(xml)
                    Dim transformer As XslCompiledTransform = New XslCompiledTransform()
                    transformer.Load(emailTemplateFile)
                    Dim output As StringWriter = New StringWriter()
                    transformer.Transform(document, Nothing, output)
                    oEmail.Body = output.ToString
                    output.Close()

                    oEmail.IsBodyHtml = False

                    oEmail.Send()
                End If
            Catch exc As System.Net.Mail.SmtpFailedRecipientException
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("InvalidEmailAddress", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                pnlCreatePassword.Visible = True
                pnlChangePassword.Visible = True
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub


        Private Function FormValidationPasswordCreate() As Boolean

            'New password cannot be empty
            If txtNewPassword.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NewPasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'confirm password cannot be empty
            If txtConfirmPassword.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ConfirmPasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'new password should be equal to confirm password
            If Not txtConfirmPassword.Text = txtNewPassword.Text Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ConfirmNotEqualNewMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'check password format
            Dim oRegex As New System.Text.RegularExpressions.Regex(PasswordRegularExpression)
            If Not oRegex.IsMatch(txtNewPassword.Text) Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidPasswordFormat", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            Return True
        End Function

        Private Function FormValidationSSOPasswordUpdate() As Boolean

            'New password cannot be empty
            If txtSSONewPassword.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SSOUpdatePassword", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'confirm password cannot be empty
            If txtSSOConfirmPassword.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SSOUpdatePasswordConfirm", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'new password should be equal to confirm password
            If Not txtSSOConfirmPassword.Text = txtSSONewPassword.Text Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SSOUpdatePasswordConfirmCompare", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'check password format
            Dim oRegex As New System.Text.RegularExpressions.Regex(PasswordRegularExpression)
            If Not oRegex.IsMatch(txtSSONewPassword.Text) Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidPasswordFormat", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            Return True
        End Function


        Private Sub SendEmailPasswordCreate()
            Try
                If Page.IsValid Then
                    pnlCreatePassword.Visible = False
                    pnlChangePassword.Visible = False
                    Dim oEmail As New SendEmailRequest

                    Dim ToEmailAddress As String = GetEmailAddressForWebUser()

                    Dim toEmail As EmailAddress
                    toEmail = New EmailAddress(ToEmailAddress, ToEmailAddress)
                    oEmail.To.Add(toEmail)

                    Dim Subject As String = Services.Localization.Localization.GetString("EmailChangePasswordSubject", Me.LocalResourceFile)
                    oEmail.Subject = Subject


                    Dim FromEmailAddress As String = AdminEmailAddress
                    oEmail.From.Address = FromEmailAddress
                    oEmail.From.DisplayName = Services.Localization.Localization.GetString("EmailFromName", Me.LocalResourceFile)

                    Dim emailTemplateFile As String = Server.MapPath(ModulePath + "Templates\EmailTemplate.xsl")

                    Dim xml As System.Xml.XmlReader = New System.Xml.XmlTextReader(New System.IO.StringReader("<?xml version='1.0'?><NewPassword></NewPassword>"))
                    Dim document As XmlDocument = New XmlDocument()
                    document.Load(xml)
                    Dim transformer As XslCompiledTransform = New XslCompiledTransform()
                    transformer.Load(emailTemplateFile)
                    Dim output As StringWriter = New StringWriter()
                    transformer.Transform(document, Nothing, output)
                    oEmail.Body = output.ToString
                    output.Close()

                    TIMSS.Global.App.CurrentDeliveryStrategy.ProcessSync(oEmail)
                End If
            Catch exc As System.Net.Mail.SmtpFailedRecipientException
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("InvalidEmailAddress", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                pnlCreatePassword.Visible = True
                pnlChangePassword.Visible = True
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub


        'get the email address for the webuser
        Private Function GetEmailAddressForWebUser() As String
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers
            oWebList = GetWebUser(WebUser)

            'get the email address for the curent user
            oCustomers = GetCustomer(oWebList(0).MasterCustomerId, CStr(oWebList(0).SubCustomerId))
            Return oCustomers(0).PrimaryEmailAddress
        End Function

        'get the email address for the current user
        Private Function GetEmailAddressTo() As String
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            'Dim strMasterCustomerId As String = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
            'Dim strSubCustomerId As String = UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString

            'get the email address for the curent user
            oCustomers = GetCustomer(frmMasterCustomerId, frmSubCustomerId)
            Return oCustomers(0).PrimaryEmailAddress
        End Function


        Function Redirect_AfterLogin() As String


            Dim _RedirectURL As String = ""

            Dim setting As Object = DotNetNuke.Entities.Modules.UserModuleBase.GetSetting(PortalId, "Redirect_AfterLogin")

            If CType(setting, Integer) = Null.NullInteger Then
                If PortalSettings.LoginTabId <> -1 And PortalSettings.HomeTabId <> -1 Then
                    ' redirect to portal home page specified
                    _RedirectURL = NavigateURL(PortalSettings.HomeTabId)
                Else
                    ' redirect to current page 
                    _RedirectURL = NavigateURL(Me.TabId)
                End If
            Else ' redirect to after login page
                _RedirectURL = NavigateURL(CType(setting, Integer))
            End If

            Return _RedirectURL

        End Function

        Private Sub UpdatePassword()
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers
            'Dim MasterCustomerId As String = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
            'Dim SubCustomerId As String = UserInfo.Profile.GetPropertyValue("SubCustomerId").ToString


            oWebList = GetWebUser(frmMasterCustomerId, frmSubCustomerId)
            If oWebList.Count > 1 Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                Dim ValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
                ValidationIssues = UpdateWebUserPassword(oWebList(0).UserId, txtNewPasswordChange.Text)

                If ValidationIssues.Count <= 0 Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SuccessChangeMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    '3246-7079296  - Login Manager constructor has changed
                    Dim oLoginManager As New Personify.LoginManager(frmMasterCustomerId, Convert.ToInt32(frmSubCustomerId))
                    Dim objUser As UserInfo = Nothing
                    Dim loginStatus As Personify.LoginStatus

                    loginStatus = oLoginManager.Login()

                    Dim returnurl As String = ""
                    If Request("returnurl") IsNot Nothing AndAlso Convert.ToString(Request("returnurl")).Length > 0 Then
                        returnurl = Request("returnurl")
                    End If
                    If Not returnurl.Length > 0 Then
                        returnurl = Redirect_AfterLogin()
                    End If
                    SendEmailPasswordChange()
                    Response.Redirect(returnurl, True)

                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oWebList.ValidationIssues(0).Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If
            End If
        End Sub

        Private Sub UpdateSSOPassword()

            Dim strBuilder As New System.Text.StringBuilder
            strBuilder.Append(frmMasterCustomerId)
            strBuilder.Append(TIMSS.Constants.Application.C_KEY_DELIMITER)
            strBuilder.Append(frmSubCustomerId)

            Dim status As Boolean
            status = SSOLoginManager.UpdateSSOUserPassword(GetCustomerToken(), strBuilder.ToString, Me.txtSSONewPassword.Text)
            If status Then
                '3246-6833317 - remove updatepassword function
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SuccessChangeMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        End Sub

        Private Function GetCustomerToken() As String
            If Not Session("customerToken") Is Nothing AndAlso CStr(Session("customerToken")) <> "" Then
                Return CStr(Session("customerToken"))
            ElseIf Not Session("CT") Is Nothing AndAlso CStr(Session("CT")) <> "" Then
                Dim decrypted As String = SSOLoginManager.DecryptCustomerToken(CStr(Session("CT")))

                Return decrypted.Substring(decrypted.IndexOf("|") + 1, decrypted.Length - decrypted.IndexOf("|") - 1)
            End If
            Return Nothing
        End Function

        Private Sub CreatePassword()
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers


            oWebList = GetWebUser(WebUser)
            If oWebList.Count > 1 Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ContactUs", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                Dim ValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection
                ValidationIssues = UpdateWebUserPassword(oWebList(0).UserId, txtNewPassword.Text)

                If ValidationIssues.Count <= 0 Then



                    'ActiveFlag updated to 0
                    Dim sqlParamArr(2) As SqlParameter
                    Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

                    sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
                    sqlParamArr(0).Value = PortalId.ToString
                    sqlParamArr(1) = New SqlParameter("@ApplicationId", SqlDbType.NVarChar, 100)
                    sqlParamArr(1).Value = Request.QueryString("a")
                    sqlParamArr(2) = New SqlParameter("@ActiveFlag", SqlDbType.Bit)
                    sqlParamArr(2).Value = 0
                    Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(ConnectionString, "dbo." & "" & "UpdatePersonifyPasswordAssistance", sqlParamArr(0), sqlParamArr(1), sqlParamArr(2))

                    SendEmailPasswordCreate()

                    'Auto Login
                    Dim loginStatus As Personify.LoginStatus
                    Dim oLoginManager As New Personify.LoginManager(oWebList(0).UserId, txtNewPassword.Text)
                    Dim objUser As UserInfo = Nothing

                    loginStatus = oLoginManager.Login()
                    If loginStatus.loginStatus = DotNetNuke.Security.Membership.UserLoginStatus.LOGIN_SUCCESS Then
                        Response.Redirect(NavigateURL(TabId, "", "&reload=yes"))
                    End If
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, oWebList.ValidationIssues(0).Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If
            End If
        End Sub


        Private Function GetPersonifySiteSettings(ByVal CurrPortalID As Integer) As Boolean
            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(ConnectionString, "dbo." & "" & "GetPersonifySiteSettings", CurrPortalID), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    If (Not oSiteData.Item("AdminEmailAddress") Is Nothing) AndAlso (Not oSiteData.Item("AdminEmailAddress").ToString = "") Then
                        AdminEmailAddress = CType(oSiteData.Item("AdminEmailAddress"), String)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        Return False
                    End If
                    If (Not oSiteData.Item("PasswordRegularExpression") Is Nothing) AndAlso (Not oSiteData.Item("PasswordRegularExpression").ToString = "") Then
                        PasswordRegularExpression = CType(oSiteData.Item("PasswordRegularExpression"), String)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        Return False
                    End If
                End While
            Else
                Return False
            End If
            oSiteData.Close()
            oSiteData = Nothing

            Return True
        End Function

        Private Function GetWebUser(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.WebInfo.IWebUsers

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers


            oWebUsers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")
            oWebUsers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MCID)
            oWebUsers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SCID)
            oWebUsers.Fill()
            Return oWebUsers


        End Function
        Private Function GetWebUser(ByVal ActivationKey As String) As TIMSS.API.WebInfo.IWebUsers

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers



            oWebUsers = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

            oWebUsers.Filter.Add("UserId", TIMSS.Enumerations.QueryOperatorEnum.Equals, ActivationKey)
            oWebUsers.Fill()

            Return oWebUsers

        End Function
        Private Function GetCustomer(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", MCID)
                .Filter.Add("SubCustomerId", SCID)
                .Fill()
            End With

            Return oCustomers

        End Function

        Private Function UpdateWebUserPassword(ByVal UserId As String, ByVal Password As String) As TIMSS.API.Core.Validation.IIssuesCollection

            Dim oWebUsers As TIMSS.API.WebInfo.IWebUsers

          
            oWebUsers =Me.PErsonifyGetCollection( TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")
            oWebUsers.Filter.Add("UserId", TIMSS.Enumerations.QueryOperatorEnum.Equals, UserId)
            oWebUsers.Fill()

            Dim bOrigUserIdReadOnlyUpdate As Boolean
            bOrigUserIdReadOnlyUpdate = oWebUsers.Schema.Item("UserId").IsReadOnly.OnUpdate
            oWebUsers.Schema.Item("UserId").IsReadOnly.OnUpdate = False

            oWebUsers(0).Password = Password

            oWebUsers(0).IsPasswordChangeRequired = False

            oWebUsers.Save()

            ' reset schema to original value
            oWebUsers.Schema.Item("UserId").IsReadOnly.OnUpdate = bOrigUserIdReadOnlyUpdate

            Return oWebUsers.ValidationIssues

        End Function


#End Region


    End Class

End Namespace
