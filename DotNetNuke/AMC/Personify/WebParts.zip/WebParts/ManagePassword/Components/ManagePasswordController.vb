Imports System
Imports System.Data
Imports Personify.DNN.Modules.ManagePassword.Data

Namespace Personify.DNN.Modules.ManagePassword.Business

    Public Class ManagePasswordController
        'Implements Entities.Modules.ISearchable
        'Implements Entities.Modules.IPortable

#Region "Pulic Methods"
        '---------------------------------------------------------------------
        ' TODO Implement BLL methods
        ' You can use CodeSmith templates to generate this code
        '---------------------------------------------------------------------
        Public Function List() As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().ListManagePassword(), GetType(ManagePasswordInfo))
        End Function

        Public Function GetByModules(ByVal ModuleId As Integer) As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().GetManagePasswordByModules(ModuleId), GetType(ManagePasswordInfo))
        End Function
        
        Public Function [Get](ByVal ItemID As Integer, ByVal ModuleId As Integer) As ManagePasswordInfo
            Return CType(CBO.FillObject(DataProvider.Instance().GetManagePassword(ItemId, ModuleId), GetType(ManagePasswordInfo)), ManagePasswordInfo)
        End Function

        Public Function Add(ByVal objManagePassword As ManagePasswordInfo) as integer
            Return CType(DataProvider.Instance().AddManagePassword(objManagePassword.ModuleId, objManagePassword.Field1),Integer)
        End Function
        
        Public Sub Update(ByVal objManagePassword As ManagePasswordInfo)
            DataProvider.Instance().UpdateManagePassword(objManagePassword.ItemId, objManagePassword.Field1)
        End Sub

        Public Sub Delete(ByVal ItemID As Integer)
            DataProvider.Instance().DeleteManagePassword(ItemId)
        End Sub
#End Region

#Region "Optional Interfaces"
        'Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

        'End Function

        'Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

        'End Function

        'Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

        'End Sub
#End Region

    End Class

End Namespace
