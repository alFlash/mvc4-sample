Imports System
Imports System.Web.UI.WebControls
Imports Personify

Namespace Personify.DNN.Modules.CustomerAddress

    Public MustInherit Class CustomerAddressEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cboDisplayLegend As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboLayout As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboColumns As System.Web.UI.WebControls.DropDownList

        Protected WithEvents cboDisplayDisabledAddresses As System.Web.UI.WebControls.DropDownList

        Protected WithEvents cboAllowAddrStatusChange As System.Web.UI.WebControls.DropDownList

        Protected WithEvents cboIsForOrder As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSelectOrderURL As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboDisplayAdvanceShipping As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboAdvanceShipURL As System.Web.UI.WebControls.DropDownList

        Protected WithEvents rwSelectOrderURL As HtmlTableRow
        Protected WithEvents rwDisplayAdvanceShipping As HtmlTableRow
        Protected WithEvents rwAdvanceShipURL As HtmlTableRow

        Protected WithEvents chkUseCompanyLookup As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowGroup1ValidatedMessage As System.Web.UI.WebControls.CheckBox
        Protected WithEvents txtGroup1ValidatedMessage As System.Web.UI.WebControls.TextBox
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region



#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'TCMSWebPartTemplateDropDownList1.TCMSWebPartTemplateFolder = Me.ModulePath
                'Dim objCtlCustomerAddress As New CustomerAddressController
                'Dim objCustomerAddress As New CustomerAddressInfo

                ' Determine ItemId
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Null.NullInteger()
                End If

                If Not Page.IsPostBack Then
                    LoadSettingValues()
                    'cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")
                    'If Not Null.IsNull(itemId) Then
                    '    objCustomerAddress = objCtlCustomerAddress.Get(itemId, ModuleId)
                    '    If Not objCustomerAddress Is Nothing Then
                    '        'Load data

                    '        cmdDelete.Visible = True
                    '    Else ' security violation attempt to access item not related to this Module
                    '        Response.Redirect(NavigateURL(), True)
                    '    End If

                    'End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadSettingValues()

            'Load the dropdown list for URL's
            Dim _portalSettings As DotNetNuke.Entities.Portals.PortalSettings = GetPortalSettings()

            '**Get a list of tabs in the portal
            Dim arrTabs As ArrayList = GetPortalTabs(_portalSettings.DesktopTabs, True, True)

            '**Bind the SelectOrderURL dropdown list
            With cboSelectOrderURL
                .DataSource = arrTabs
                .DataValueField = "TabId"
                .DataTextField = "TabName"
                .DataBind()
            End With

            '**Bind the cboAdvanceShipURL dropdown list
            With cboAdvanceShipURL
                .DataSource = arrTabs
                .DataValueField = "TabId"
                .DataTextField = "TabName"
                .DataBind()
            End With

            'Display Legend Box

            If Not Settings(ModuleSettingsNames.DisplayLegend) Is Nothing Then
                cboDisplayLegend.SelectedValue = Settings(ModuleSettingsNames.DisplayLegend).ToString
            End If

            'Display Layout

            If Not Settings(ModuleSettingsNames.Layout) Is Nothing Then
                cboLayout.SelectedValue = Settings(ModuleSettingsNames.Layout).ToString
            End If

            'Number of Columns

            If Not Settings(ModuleSettingsNames.Columns) Is Nothing Then
                cboColumns.SelectedValue = Settings(ModuleSettingsNames.Columns).ToString
            End If

            'Display Disabled Address 

            If Not Settings(ModuleSettingsNames.DisplayDisabledAddress) Is Nothing Then
                cboDisplayDisabledAddresses.SelectedValue = Settings(ModuleSettingsNames.DisplayDisabledAddress).ToString
            Else
                cboDisplayDisabledAddresses.SelectedValue = "0"
            End If

            'Allow Address Change Option

            If Not Settings(ModuleSettingsNames.AllowAddressStatusChange) Is Nothing Then
                cboAllowAddrStatusChange.SelectedValue = Settings(ModuleSettingsNames.AllowAddressStatusChange).ToString
            Else
                cboAllowAddrStatusChange.SelectedValue = "0"
            End If

            'Is the web part used for order entry process
            If Not Settings(ModuleSettingsNames.OrderAddressSelect) Is Nothing Then
                cboIsForOrder.SelectedValue = Settings(ModuleSettingsNames.OrderAddressSelect).ToString
            Else
                cboIsForOrder.SelectedValue = "0"
            End If

            'Select Order URL
            If Not Settings(ModuleSettingsNames.SelectOrderURL) Is Nothing Then
                cboSelectOrderURL.SelectedValue = Settings(ModuleSettingsNames.SelectOrderURL).ToString
            End If

            'Display Advance Shipping
            If Not Settings(ModuleSettingsNames.DisplayAdvanceShipping) Is Nothing Then
                cboDisplayAdvanceShipping.SelectedValue = Settings(ModuleSettingsNames.DisplayAdvanceShipping).ToString
            Else
                cboDisplayAdvanceShipping.SelectedValue = "0"
            End If


            'Advance Shipping URL
            If Not Settings(ModuleSettingsNames.AdvanceShipURL) Is Nothing Then
                cboAdvanceShipURL.SelectedValue = Settings(ModuleSettingsNames.AdvanceShipURL).ToString
            End If

            'Use company lookup
            If Not Settings(CType(ModuleSettingsNames.UseCompanyLookup, String)) Is Nothing Then
                chkUseCompanyLookup.Checked = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.UseCompanyLookup, String)), String) = "Y", True, False))
            End If

            'Hide Show fields

            HideShowOrderRelatedFields(cboIsForOrder.SelectedValue)

            'Show Group 1 Validation Message
            If Not Settings(CType(ModuleSettingsNames.ShowGroup1ValidatedMessage, String)) Is Nothing Then
                chkShowGroup1ValidatedMessage.Checked = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.ShowGroup1ValidatedMessage, String)), String) = "Y", True, False))
            End If

            'Group 1 Validation Message
            'If Not Settings(CType(ModuleSettingsNames.Group1ValidatedMessage, String)) Is Nothing Then
            '    txtGroup1ValidatedMessage.Text = CType(ModuleSettingsNames.Group1ValidatedMessage, String)
            'End If
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

                    UpdateModuleSetting(ModuleSettingsNames.DisplayLegend, cboDisplayLegend.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.Layout, cboLayout.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.Columns, cboColumns.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.DisplayDisabledAddress, cboDisplayDisabledAddresses.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.AllowAddressStatusChange, cboAllowAddrStatusChange.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.OrderAddressSelect, cboIsForOrder.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.SelectOrderURL, cboSelectOrderURL.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.DisplayAdvanceShipping, cboDisplayAdvanceShipping.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.AdvanceShipURL, cboAdvanceShipURL.SelectedValue)
                    UpdateModuleSetting(ModuleSettingsNames.UseCompanyLookup, CStr(IIf(chkUseCompanyLookup.Checked, "Y", "N")))
                    UpdateModuleSetting(ModuleSettingsNames.ShowGroup1ValidatedMessage, CStr(IIf(chkShowGroup1ValidatedMessage.Checked, "Y", "N")))
                    '.UpdateModuleSetting(ModuleId, ModuleSettingsNames.Group1ValidatedMessage, txtGroup1ValidatedMessage.Text)


                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                'If Not Null.IsNull(itemId) Then
                '    Dim objCtlCustomerAddress As New CustomerAddressController
                '    objCtlCustomerAddress.Delete(itemId)
                'End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub cboIsForOrder_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboIsForOrder.SelectedIndexChanged

            HideShowOrderRelatedFields(cboIsForOrder.SelectedValue)

        End Sub

        Private Sub HideShowOrderRelatedFields(ByVal MakeVisible As String)
            'If MakeVisible = "1" Then
            '    rwAdvanceShipURL.Visible = True
            '    rwDisplayAdvanceShipping.Visible = True
            '    rwSelectOrderURrwAdvanceShipURLL.Visible = True
            'Else
            '    rwAdvanceShipURL.Visible = False
            '    rwDisplayAdvanceShipping.Visible = False
            '    rwSelectOrderURL.Visible = False
            'End If

        End Sub

        Private Sub cboIsForOrder_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboIsForOrder.TextChanged
            HideShowOrderRelatedFields(cboIsForOrder.SelectedValue)

        End Sub
    End Class

End Namespace
