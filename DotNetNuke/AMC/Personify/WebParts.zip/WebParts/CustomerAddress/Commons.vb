
Namespace Personify.DNN.Modules.CustomerAddress
    Public Class ModuleSettingsNames

        Public Const DisplayLegend As String = "DisplayLegend"
        Public Const Layout As String = "Layout"
        Public Const Columns As String = "Columns"

        Public Const DisplayDisabledAddress As String = "DisplayDisabledAddress"
        Public Const AllowAddressStatusChange As String = "AllowAddressStatusChange"

        Public Const OrderAddressSelect As String = "OrderAddressSelect"
        Public Const SelectOrderURL As String = "SelectOrderURL"

        Public Const DisplayAdvanceShipping As String = "DisplayAdvanceShipping"
        Public Const AdvanceShipURL As String = "AdvanceShipURL"
        Public Const UseCompanyLookup As String = "UseCompanyLookup"

        Public Const ShowGroup1ValidatedMessage As String = "ShowGroupOneValidatedMessage"
        Public Const Group1ValidatedMessage As String = "GroupOneValidatedMessage"
    End Class


   
End Namespace

