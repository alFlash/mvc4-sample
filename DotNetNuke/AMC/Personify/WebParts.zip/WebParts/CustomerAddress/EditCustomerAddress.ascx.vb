Option Strict Off
Imports System
Imports System.Web.UI.WebControls
Imports Personify
Imports TIMSS.SqlObjects
Imports Personify.ApplicationManager.PersonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects


Namespace Personify.DNN.Modules.CustomerAddress
    Public MustInherit Class EditCustomerAddress
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Private _CusAddressId As Integer
        Private isEnabled As Boolean

#Region "Controls"

        Protected WithEvents Address1 As WebControls.AddressControl
        Protected WithEvents btnSave As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
        Protected WithEvents btnDisableAddress As System.Web.UI.WebControls.Button
        Protected WithEvents btnEnableAddress As System.Web.UI.WebControls.Button
        Protected WithEvents oMessageControl As WebControls.MessageControl

        Protected WithEvents btnContinue As System.Web.UI.WebControls.LinkButton
        Protected WithEvents pnlAddress As System.Web.UI.WebControls.Panel

        Private m_UseCompanyLookup As Boolean
        Private m_ShowGroup1Message As String
        Private _tblCustomerInfo As DataTable
#End Region 'd
#Region "Properties"
        'Set the UseCompanyLookup based on which the Ajax Company Lookup will be used or not
        Private Property UseCompanyLookup() As Boolean
            Get
                Return m_UseCompanyLookup
            End Get
            Set(ByVal Value As Boolean)
                m_UseCompanyLookup = Value
            End Set
        End Property

        Private Property ShowGroup1Message() As String
            Get
                Return m_ShowGroup1Message
            End Get
            Set(ByVal value As String)
                m_ShowGroup1Message = value
            End Set
        End Property

        Public Property Is_Enabled() As Boolean
            Get
                Return isEnabled
            End Get
            Set(ByVal value As Boolean)
                isEnabled = value
            End Set
        End Property


        Private ReadOnly Property CustomerInfo() As DataTable
            Get
                If _tblCustomerInfo Is Nothing Then
                    _tblCustomerInfo = df_GetCustomerInformation(MasterCustomerId, SubCustomerId)
                End If

                Return _tblCustomerInfo
            End Get

        End Property
#End Region
        Private Function CheckKeyStoreExists() As Boolean

            If Page.Request.Params("__EVENTTARGET") IsNot Nothing AndAlso Page.Request.Params("__EVENTTARGET").IndexOf("txtCompanyName") >= 0 AndAlso Page.Request.Params(Page.Request.Params("__EVENTTARGET")).Length > 0 Then
                Return True
            Else
                Return False
            End If

        End Function
        Private Sub InitializeAddressControl()

            Dim MCID As String = ""
            Dim SCID As String = ""
            Dim Comp As String = ""

            Address1.RecordType = CustomerInfo.Rows(0).Item("RecordType")

            Address1.ServicePath = ApplicationPath & "/PersonifyAjax.asmx"
            Address1.ServiceMethod = "SearchCompanies"
            'If (DotNetNuke.Framework.AJAX.IsInstalled()) Then
            'DotNetNuke.Framework.AJAX.RegisterScriptManager()
            'End If

            If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                'If Request("__EVENTTARGET").IndexOf("btnEditAddress") > 0 Then
                Address1.Mode = "EDIT"
                _CusAddressId = CInt(Request.QueryString("CustomerAddressId"))

                'CQ31435
                Dim FirstTime As Boolean = True

                Try
                    If Address1.CountryCode.Length > 0 Then
                        FirstTime = False
                    End If
                Catch ex As Exception

                End Try
                If FirstTime = True Then GetCustomerAddress(CInt(Request.QueryString("CustomerAddressId")))

                'End If

                If UseCompanyLookup AndAlso CheckKeyStoreExists() Then
                    Comp = Page.Request.Params(Page.Request.Params("__EVENTTARGET"))
                    If Comp.IndexOf(TIMSS.Constants.Application.C_KEY_DELIMITER) > 0 Then
                        ParseCustomerId(Comp, MCID, SCID)

                        Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
                        oAddresses = df_GetCustomerAddress(0, MCID, SCID)

                        GetPrimaryAddressForCustomer(MCID, SCID)

                        If oAddresses.Count > 0 Then
                            Address1.CompanyName = oAddresses(0).LabelName
                            Address1.CompanyMasterCustomerId = oAddresses(0).MasterCustomerId
                            Address1.CompanySubCustomerId = oAddresses(0).SubCustomerId
                        End If
                    End If

                Else
                End If

            Else
                Address1.Mode = "ADD"

                'If Post Back from company select - check for the KeyStore -   

                If UseCompanyLookup AndAlso CheckKeyStoreExists() Then
                    Comp = Page.Request.Params(Page.Request.Params("__EVENTTARGET"))
                    'GetCustomerIdFromCompanyString(Comp, MCID, SCID)
                    If Comp.IndexOf(TIMSS.Constants.Application.C_KEY_DELIMITER) > 0 Then
                        ParseCustomerId(Comp, MCID, SCID)
                        GetPrimaryAddressForCustomer(MCID, SCID)
                    End If
                Else
                    'Address1.AddressStructureCountryCode = "USA"
                    Address1.AddressStructureCountryCode = Me.GetDefaultCountryCodeForOrganization

                    If Request.QueryString("ADDRESSTYPE") Is Nothing Then
                    Else
                        'START #3246-6971449
                        Address1.AddressType = XSS_HTMLEncode(Request.QueryString("ADDRESSTYPE").ToString.ToUpper())
                        'END #3246-6971449
                    End If
                End If

                'Set the Label Name and The Job title
                'CQ31435

                If Not IsPostBack Then InitAddrControlWithLabelName(MasterCustomerId, SubCustomerId)
            End If
            'Fixed ticket #3246-7733227 : Added IsCompanyAddress condition
            If Not Address1.IsCompanyAddress Then
                '3246-7571065 
                Address1.SetAddressVisible()
            End If
        End Sub


        Private Sub InitAddrControlWithLabelName(ByVal strMCID As String, ByVal strSCID As String)

            If CustomerInfo.Rows.Count > 0 Then
                Address1.LabelName = CustomerInfo.Rows(0).Item("LabelName")

                If CustomerInfo.Rows(0).Item("PrimaryJobTitle") IsNot System.DBNull.Value Then
                    Address1.JobTitle = CustomerInfo.Rows(0).Item("PrimaryJobTitle")
                End If

            End If

        End Sub

        Private Sub GetCustomerAddress(ByVal CustomerAddressId As Integer)

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            oAddresses = df_GetCustomerAddress(MasterCustomerId, SubCustomerId, CustomerAddressId)

            If oAddresses.Count > 0 Then
                With oAddresses(0)
                    If .AddressStatusCode.ToString.ToUpper = "BAD" Then
                        Is_Enabled = False
                    Else
                        Is_Enabled = True
                    End If
                    btnDisableAddress = CType(FindControl("btnDisableAddress"), System.Web.UI.WebControls.Button)
                    btnEnableAddress = CType(FindControl("btnEnableAddress"), System.Web.UI.WebControls.Button)
                    If Is_Enabled Then
                        btnEnableAddress.Visible = False
                        btnDisableAddress.Visible = True
                    Else
                        btnEnableAddress.Visible = True
                        btnDisableAddress.Visible = False
                    End If

                    Address1.AddressStructureCountryCode = .CountryCode
                    Address1.AddressType = .AddressTypeCode.Code
                    Address1.LabelName = .LabelName

                    If .MasterCustomerId <> .OwnerMasterCustomer Then
                        Address1.IsCompanyAddress = True
                        Address1.CompanyName = .CompanyName
                        Address1.CompanyMasterCustomerId = .OwnerMasterCustomer
                        Address1.CompanySubCustomerId = .OwnerSubCustomer
                    Else
                        Address1.IsCompanyAddress = False
                        Address1.UseCompanyLookup = False
                        UseCompanyLookup = False
                        Address1.CompanyName = .CompanyName
                        Address1.CompanyMasterCustomerId = .OwnerMasterCustomer
                        Address1.CompanySubCustomerId = .OwnerSubCustomer
                    End If
                    Address1.CompanyAddressLabelValue = .CompanyName & "<br>" & .FormattedAddress.Replace(vbCrLf, "<br>")
                    Address1.CustomerAddressId = .CustomerAddressId
                    Address1.JobTitle = .JobTitle
                    Address1.MailStop = .MailStop
                    Address1.Attention = .AttentionLine
                    Address1.CountryCode = .CountryCode
                    Address1.State = .State
                    Address1.Address1 = .Address1
                    Address1.Address2 = .Address2
                    Address1.Address3 = .Address3
                    Address1.Address4 = .Address4
                    Address1.City = .City
                    Address1.PostalCode = .PostalCode
                    'D00030744 - County not saved/shown correctly
                    Address1.County = .County
                    Address1.BillAddressFlag = .BillToFlag
                    Address1.ShipAddressFlag = .ShipToFlag
                    Address1.ForDirectoryUseFlag = .DirectoryFlag
                    Address1.ConfidentialFlag = .ConfidentialFlag


                    If .PrioritySeq = 0 Then
                        Address1.PrimaryFlag = True
                    Else
                        Address1.PrimaryFlag = False
                    End If
                End With
            Else

            End If



        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            'If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
            '    If Request("__EVENTTARGET").IndexOf("btnEditAddress") > 0 Then
            '        InitializeAddressControl()
            '    End If


            'ElseIf Request.QueryString("MODE").ToString.ToUpper = "ADD" Then

            '    InitializeAddressControl()

            'End If
            InitializeAddressControl()
        End Sub

        Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

            'If not a post back, clear the session obhecty
            'MBR Renewal Change - Begin
            If Me.IsPersonifyWebUserLoggedIn = False Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Dim strReturnURL As String = HttpUtility.UrlEncode(Request.RawUrl.ToString)
                Response.Redirect(NavigateURL(PortalSettings.LoginTabId, "", New String() {"returnUrl=" + strReturnURL}))
            End If
            'MBR Renewal Change - End


            If Address1.RecordType Is Nothing Then
                Address1.RecordType = CustomerInfo.Rows(0).Item("RecordType")
            End If

            If Not Request.QueryString("USECOMPANYLOOKUP") Is Nothing Then
                UseCompanyLookup = CBool(Request.QueryString("USECOMPANYLOOKUP"))
            Else
                UseCompanyLookup = False
            End If

            If Not Request.QueryString("SHOWGROUPONEMESSAGE") Is Nothing Then
                ShowGroup1Message = Request.QueryString("SHOWGROUPONEMESSAGE").ToString
            End If
            Address1.UseCompanyLookup = UseCompanyLookup

            'Dim lg As New Personify.WebUtility.LoginCustomer
            'lg = Personify.WebUtility.User.GetCurrentCustomer(UserId, PortalId, UserInfo.Profile.ProfileProperties)

            'MBR Renewal Change - Begin
            If Me.IsPersonifyWebUserLoggedIn = False Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
            'MBR Renewal Change - End

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            oAddresses = df_GetCustomerAddress(MasterCustomerId, SubCustomerId, CInt(Request.QueryString("CustomerAddressId")))
            If oAddresses.Count > 0 Then
                With oAddresses(0)
                    If .MasterCustomerId = .OwnerMasterCustomer Then
                        Address1.UseCompanyLookup = False
                    End If
                End With
            End If


        End Sub

        Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If
            Session.Remove("CustomerAddress")
            RedirectPage()
        End Sub

        Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
            'Save the record
            'Begin of part of CQ30948, handles whether show address validation message.
            Dim ValidationState As String = "NotValidated"
            If SaveAddress(ValidationState) Then
                If ValidationState = "AutoRespondTriggered" Then
                    If ShowGroup1Message = "N" Then
                        RedirectPage()
                    Else
                        ShowGroup1ValidatedMessage()
                    End If
                ElseIf ValidationState = "NoValidationIssue" Then
                    RedirectPage()
                End If
            End If

        End Sub

        Private Sub ShowGroup1ValidatedMessage()
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Group 1 has validated the address", Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
            btnContinue.Visible = True
            pnlAddress.Visible = False
        End Sub

        Private Sub btnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click
            RedirectPage()
        End Sub

        Private Sub btnDisableAddress_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDisableAddress.Click

            If df_CustomerEnableDisableAddress(False, MasterCustomerId, SubCustomerId, Address1.CustomerAddressId) Then
                'Response.Redirect(Page.Request.Url.ToString)
                RedirectPage()
            End If
        End Sub
        Private Sub btnEnableAddress_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEnableAddress.Click

            If df_CustomerEnableDisableAddress(True, MasterCustomerId, SubCustomerId, Address1.CustomerAddressId) Then
                'Response.Redirect(Page.Request.Url.ToString)
                RedirectPage()
            End If
        End Sub

        'Part of CQ30948, "ByRef AutoRespondTriggered As Boolean" to "ByRef ValidationState As String"
        Private Sub ParseCustomerId(ByVal customerId As String, ByRef MasterCustomerId As String, ByRef SubCustomerId As String)

            Dim aryCustomerId() As String = customerId.Split(TIMSS.Constants.Application.C_KEY_DELIMITER)

            If (aryCustomerId.Length > 1) Then
                MasterCustomerId = aryCustomerId(aryCustomerId.GetUpperBound(0) - 1)
                SubCustomerId = aryCustomerId(aryCustomerId.GetUpperBound(0))
            End If



        End Sub

        Private Function SaveAddress(ByRef ValidationState As String) As Boolean

            Dim TxnMode As ApplicationManager.PersonifyEnumerations.TransactionMode

            Dim oAddressParameters As AddressParameters

            Try


                Dim ValidationIssues As TIMSS.API.Core.Validation.IIssuesCollection

                If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                    TxnMode = ApplicationManager.PersonifyEnumerations.TransactionMode.EDIT
                    'strCommType = _EditCommTypeCode
                    'strCommLocation = _EditCommLocationCode

                Else
                    TxnMode = ApplicationManager.PersonifyEnumerations.TransactionMode.ADD
                    'strCommType = ddlComType.Text
                    'strCommLocation = ddlLocation.Text
                End If

                oAddressParameters = New AddressParameters(MasterCustomerId, SubCustomerId)

                With oAddressParameters
                    If Not Address1.LabelName Is Nothing Then
                        .LabelName = Address1.LabelName
                    End If
                    If Not Address1.Attention Is Nothing Then
                        .Attention = Address1.Attention
                    End If
                    If Not Address1.MailStop Is Nothing Then
                        .MailStop = Address1.MailStop
                    End If
                    If Not Address1.JobTitle Is Nothing Then
                        .JobTitle = Address1.JobTitle
                    End If
                    .Address1 = Address1.Address1
                    .Address2 = Address1.Address2
                    .Address3 = Address1.Address3
                    .Address4 = Address1.Address4

                    .CountryCode = Address1.CountryCode

                    .PostalCode = Address1.PostalCode
                    .CountyCode = Address1.County
                    .AddressType = Address1.AddressType
                    .BillAddressFlag = Address1.BillAddressFlag
                    .City = Address1.City

                    .PrimaryAddressFlag = Address1.PrimaryFlag
                    '.OneTimeAddress = Address1.for

                    .PrimaryAddressFlag = Address1.PrimaryFlag
                    '.SeasonalEndDate = Address1.SeasonalEndDate
                    '.SeasonalStartDate = Address1.date
                    .ShipAddressFlag = Address1.ShipAddressFlag
                    '5926080
                    If Address1.State = "-1" Then
                        .State = ""
                    Else
                        .State = Address1.State
                    End If
                    'End of 5926080
                    .ForDirectoryFlag = Address1.ForDirectoryUseFlag
                    .ConfidentialFlag = Address1.ConfidentialFlag
                    'D00030744 - County not saved/shown correctly
                    .CountyCode = Address1.County
                    'Company Is Set Only In ADD MODE - 
                    If TxnMode = ApplicationManager.PersonifyEnumerations.TransactionMode.ADD Then
                        If UseCompanyLookup Then
                            If Address1.IsCompanyAddress Then
                                .CompanyMasterCustomerId = Address1.CompanyMasterCustomerId
                                .CompanySubCustomerId = Address1.CompanySubCustomerId
                                .CompanyName = Address1.CompanyName
                                .CompanyAddressId = df_GetPrimaryAddressIdForCompany(Address1.CompanyMasterCustomerId, Address1.CompanySubCustomerId.ToString())
                            End If
                        Else
                            If Address1.CompanyName <> String.Empty Then
                                .CompanyName = Address1.CompanyName
                                Dim oCompanyCustomers As System.Data.DataSet
                                oCompanyCustomers = df_GetCompanyLookup(Address1.CompanyName)
                                If oCompanyCustomers.Tables(0) IsNot Nothing AndAlso oCompanyCustomers.Tables(0).Rows.Count > 0 Then
                                    .CompanyMasterCustomerId = CType(oCompanyCustomers.Tables(0).Rows(0).Item("master_customer_id"), String)
                                    '.CompanyMasterCustomerId = .CompanyMasterCustomerId.Substring(1, .CompanyMasterCustomerId.Length - 1).Split(CChar("-"))(0)
                                    ParseCustomerId(.CompanyMasterCustomerId, .CompanyMasterCustomerId, "")
                                    .CompanySubCustomerId = CType(oCompanyCustomers.Tables(0).Rows(0).Item("sub_customer_id"), Integer)
                                    .CompanyAddressId = -1 'ApplicationManager.Customer.GetCustomerAddress(0, .CompanyMasterCustomerId, .CompanySubCustomerId.ToString())(0).CustomerAddressId
                                End If
                            End If

                        End If

                        '.CompanyAddressId = Address1.CompanyAddressId
                        '.CompanyMasterCustomerId = Address1.CompanyMasterCustomerId
                        '.CompanyName = Address1.CompanyName
                        '.CompanySubCustomerId = Address1.CompanySubCustomerId
                    End If

                    If TxnMode = ApplicationManager.PersonifyEnumerations.TransactionMode.EDIT Then
                        '3246-6735998
                        If UseCompanyLookup AndAlso Address1.IsCompanyAddress Then
                            .CompanyMasterCustomerId = Address1.CompanyMasterCustomerId
                            .CompanySubCustomerId = Address1.CompanySubCustomerId
                            .CompanyName = Address1.CompanyName
                            .CompanyAddressId = df_GetPrimaryAddressIdForCompany(Address1.CompanyMasterCustomerId, Address1.CompanySubCustomerId.ToString())
                            'end 3246-6735998
                        Else
                            If Address1.CompanyName <> String.Empty Then
                                .CompanyName = Address1.CompanyName
                                Dim oCompanyCustomers As System.Data.DataSet
                                oCompanyCustomers = df_GetCompanyLookup(Address1.CompanyName)
                                If oCompanyCustomers.Tables(0) IsNot Nothing AndAlso oCompanyCustomers.Tables(0).Rows.Count > 0 Then
                                    .CompanyMasterCustomerId = CType(oCompanyCustomers.Tables(0).Rows(0).Item("master_customer_id"), String)
                                    '.CompanyMasterCustomerId = .CompanyMasterCustomerId.Substring(1, .CompanyMasterCustomerId.Length - 1).Split(CChar("-"))(0)
                                    ParseCustomerId(.CompanyMasterCustomerId, .CompanyMasterCustomerId, "")

                                    .CompanySubCustomerId = CType(oCompanyCustomers.Tables(0).Rows(0).Item("sub_customer_id"), Integer)
                                    .CompanyAddressId = -1 'ApplicationManager.Customer.GetCustomerAddress(0, .CompanyMasterCustomerId, .CompanySubCustomerId.ToString())(0).CustomerAddressId                                    
                                End If

                            End If
                        End If
                        .CustomerAddressId = CInt(Address1.CustomerAddressId)


                    End If
                End With

                '
                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers = Nothing
                If TxnMode = ApplicationManager.PersonifyEnumerations.TransactionMode.ADD Then
                    'Part of CQ30948, change "AutoRespondTriggered" to "ValidationState"
                    oCustomers = CType(Session.Item("CustomerAddress"), TIMSS.API.CustomerInfo.ICustomers)
                End If

                ValidationIssues = df_SaveAddress(TxnMode, oAddressParameters, ValidationState, oMessageControl.ValidationIssues, oCustomers)

                If TxnMode = ApplicationManager.PersonifyEnumerations.TransactionMode.ADD Then
                    Session.Add("CustomerAddress", oCustomers)
                End If


                If Not oMessageControl.ValidationIssues Is Nothing Then

                    oMessageControl.Clear()
                End If
                'Handle Error Type Validation Issues
                'If ValidationIssues.Count > 0 Then
                '    For i As Integer = 0 To ValidationIssues.Count - 1
                '        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ValidationIssues(i).Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '    Next
                '    Return False
                'Else
                '    Return True
                'End If

                'Handle Error Type Validation Issues
                If ValidationIssues.Count > 0 Then
                    oMessageControl.Show(ValidationIssues)
                Else
                    Session.Remove("CustomerAddress")
                    Return True
                End If

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
                Return False
            End Try

        End Function


        Private Sub GetPrimaryAddressForCustomer(ByVal strMCID As String, ByVal strSCID As String)

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            oAddresses = df_GetCustomerAddress(strMCID, strSCID)

            If oAddresses.Count > 0 Then
                With oAddresses(0)

                    Address1.AddressStructureCountryCode = .CountryCode
                    'Address1.AddressType = .AddressTypeCode.Code
                    'Address1.LabelName = .LabelName

                    Address1.CompanyName = .CompanyName
                    Address1.CompanyMasterCustomerId = .OwnerMasterCustomer
                    Address1.CompanySubCustomerId = .OwnerSubCustomer
                    Address1.CompanyAddressId = .CustomerAddressId
                    Address1.CompanyName = .LabelName
                    Address1.CompanyAddressLabelValue = .LabelName & "<br>" & .FormattedAddress.Replace(vbCrLf, "<br>")


                    'Address1.MailStop = .MailStop
                    Address1.CountryCode = .CountryCode
                    Address1.State = .State
                    Address1.Address1 = .Address1
                    Address1.Address2 = .Address2
                    Address1.Address3 = .Address3
                    Address1.Address4 = .Address4
                    Address1.City = .City
                    Address1.PostalCode = .PostalCode
                    'Address1.BillAddressFlag = .BillToFlag
                    'Address1.ShipAddressFlag = .ShipToFlag
                    'Address1.ForDirectoryUseFlag = .DirectoryFlag
                    If .PrioritySeq = 0 Then
                        'Address1.PrimaryFlag = True
                    Else
                        'Address1.PrimaryFlag = False
                    End If
                    Address1.IsCompanyAddress = True
                End With
                'Page.Response.Write("Set company Address")
            End If
        End Sub

#Region "Personify Data"

        Private Function df_CustomerEnableDisableAddress(ByVal EnableAddress As Boolean, ByVal MasterCustomerId As String, _
             ByVal SubCustomerId As Integer, ByVal CustomerAddressId As Integer) As Boolean

            Dim oCusAddresses As TIMSS.API.CustomerInfo.ICustomerAddresses

            oCusAddresses = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddresses")

            With oCusAddresses.Filter
                .Add("CustomerAddressId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CustomerAddressId)
            End With

            oCusAddresses.Fill()
            ''Try
            'oCusAddresses = GetCustomerAddressCollection(PortalId, MasterCustomerId, SubCustomerId, CustomerAddressId)

            If oCusAddresses.Count > 0 Then
                For Each oAddress As TIMSS.API.CustomerInfo.ICustomerAddressDetail In oCusAddresses(0).Details
                    If oAddress.MasterCustomerId = MasterCustomerId And oAddress.SubCustomerId = CInt(SubCustomerId) Then
                        If EnableAddress Then
                            oAddress.AddressStatusCode = oAddress.AddressStatusCode.List("GOOD").ToCodeObject
                        Else
                            oAddress.MakeAddressBad()
                        End If

                    End If
                Next
            End If

            Return oCusAddresses.Save
        End Function

        Private Function df_GetCustomerAddress(ByVal MasterCustomerId As String, _
                    ByVal SubCustomerId As String, Optional ByVal CustomerAddressId As Integer = -1) As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            oAddresses = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")

            With oAddresses.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)

                If CustomerAddressId <> -1 Then
                    .Add("CustomerAddressId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CustomerAddressId)
                End If

            End With

            oAddresses.Fill()

            Return oAddresses

        End Function

        Private Function df_GetCustomerInformation(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer) As DataTable

            'Use this to get customer for login. The API's do not have segmentation, hence use search object.

            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty
            'Customer - MCId, SCID, FirstName, LastNAme
            oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = pMasterCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = pSubCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("RecordType")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("LabelName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("PrimaryJobTitle")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            searchObj.Search()

            Return searchObj.Results.Table

        End Function

        Private Function df_GetPrimaryAddressIdForCompany(ByVal pCompanyMasterCustomerId As String, ByVal pCompanySubCustomerId As Integer) As Integer

            'Use this to get customer for login. The API's do not have segmentation, hence use search object.

            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressDetails")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty
            'Customer - MCId, SCID, FirstName, LastNAme
            oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = pCompanyMasterCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = pCompanySubCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("PrioritySeq")
            oParm.UseInQuery = True
            oParm.ShowInResults = True
            oParm.Value = 0
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("CustomerAddressId")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)


            searchObj.Search()

            If searchObj.Results.Table.Rows.Count > 0 Then
                Return DirectCast(searchObj.Results.Table.Rows(0).Item("CustomerAddressId"), Decimal)
            Else
                Return -1
            End If

        End Function


        Private Function df_GetCompanyLookup(ByVal CompanyName As String) As DataSet

            Dim strCacheKey As String = ""



            Dim oQueryResult As IQueryResult
            'Dim oParameters As New Hashtable
            Dim oParameters As New TIMSS.SqlObjects.RequestParameters

            oParameters.Add(New RequestParameter("P_RECORDTYPE", "C"))
            oParameters.Add(New RequestParameter("P_LABELNAME", CompanyName))


            Dim param1 As RequestParameter
            param1 = New RequestParameter("P_RECORDTYPE", "C")
            param1.Name = "P_RECORDTYPE"


            Dim param2 As RequestParameter
            param2 = New RequestParameter("P_LABELNAME", CompanyName)
            param2.Name = "P_LABELNAME"



            oQueryResult = Me.PersonifyExecuteQueryRequest(df_GetSelectRequest_GetCompanies, "@P_LABELNAME", CompanyName, "@P_RECORDTYPE", "C")

            'Massage the dataset
            With oQueryResult
                If .Success Then
                    For Each oRow As DataRow In .DataSet.Tables(0).Rows
                        'oRow.Item("master_customer_id") = "(" & oRow.Item("master_customer_id") & "-" & oRow.Item("sub_customer_id") & ")"
                        oRow.Item("master_customer_id") = TIMSS.Constants.Application.C_KEY_DELIMITER & oRow.Item("master_customer_id") & TIMSS.Constants.Application.C_KEY_DELIMITER & oRow.Item("sub_customer_id")
                    Next

                End If

            End With


            Return oQueryResult.DataSet

        End Function


        Private Function df_GetSelectRequest_GetCompanies() As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("GetCompanies")

            Dim tblCustomer As SelectTable = New SelectTable("cus_primary_info_vw", "c")

            tblCustomer.ResultColumns.Add("master_customer_id")
            tblCustomer.ResultColumns.Add("sub_customer_id")
            tblCustomer.ResultColumns.Add("customer_label_name")
            tblCustomer.ResultColumns.Add("formatted_address")

            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblCustomer)
            request.Parameters.Add("c", "record_type", "P_RECORDTYPE", String.Empty)
            request.Parameters.Add("c", "customer_label_name", "P_LABELNAME", "a", ParameterDirection.Input, QueryOperatorType.StartsWith)

            Return request
        End Function

        Private Function df_SaveAddress(ByVal Mode As Personify.ApplicationManager.PersonifyEnumerations.TransactionMode, _
            ByVal AddressParameters As AddressParameters, _
            ByRef ValidationState As String, _
              Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing, _
              Optional ByRef oReturnCustomerObject As TIMSS.API.CustomerInfo.ICustomers = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection


            Dim oAddressDetail As TIMSS.API.CustomerInfo.ICustomerAddressDetail = Nothing
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            Dim oPredicates As Specialized.ListDictionary
            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False

            Dim strGUIDSessionKey As String = "GuidKey"
            'Initialize GUID Class. When this is initialized 



            'Clear the GUID Class from the session object if the responded validation issues are nothing

            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifySaveAddressGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifySaveAddressGUIDKeys)
                Else

                End If
            End If

            If GetSessionObject(SessionKeys.PersonifySaveAddressGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New Personify.ApplicationManager.PersonifyDataObjects.BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "Customer"
                    '.GUID = oCustomers(0).Guid
                End With
                'oclsGUID(1) = New BusinessObjectGUIDStorage
                'With oclsGUID(1)
                '    .BusinessObjectName = "CustomerAddress"
                '    '.GUID = oAddress.Guid
                'End With
                'oclsGUID(2) = New BusinessObjectGUIDStorage
                'With oclsGUID(2)
                '    .BusinessObjectName = "CustomerAddressDetail"
                '    '.GUID = oAddressDetail.Guid
                'End With
            Else

                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifySaveAddressGUIDKeys), BusinessObjectGUIDStorage())
            End If

            'Fill Customer Collection

            'If oReturnCustomerObject Is Nothing Then
            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            oCustomers.Fill(AddressParameters.MasterCustomerId, AddressParameters.SubCustomerId)
            'Else
            'oCustomers = oReturnCustomerObject
            'End If

            'if the session object does not have GUID Keys- Fill the GUID class. If it does then set values
            If bGUIDExists Then
                oCustomers(0).Guid = oclsGUID(0).GUID
            Else
                oclsGUID(0).GUID = oCustomers(0).Guid
            End If


            If Mode = TransactionMode.ADD Then
                'If oReturnCustomerObject Is Nothing Then
                '    oAddressDetail = oCustomers(0).CreateDefaultAddress
                'Else
                'For i As Integer = 0 To oCustomers(0).AddressDetails.Count - 1
                '    If oCustomers(0).AddressDetails(i).ObjectState = TIMSS.Enumerations.BusinessObjectState.Added Then
                '        oAddressDetail = oCustomers(0).AddressDetails(i)
                '        Exit For
                '    End If
                'Next
                'If oAddressDetail Is Nothing Then
                oAddressDetail = oCustomers(0).CreateDefaultAddress
                'End If

                'End If
                If bGUIDExists Then
                    oAddressDetail.Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).Guid
                    oAddressDetail.Guid = oCustomers(0).Guid
                End If

                With oAddressDetail
                    '.MasterCustomerId = AddressParameters.MasterCustomerId
                    '.SubCustomerId = AddressParameters.SubCustomerId
                    .AddressTypeCode = .AddressTypeCode.List(AddressParameters.AddressType).ToCodeObject
                    '5785035
                    If Not (AddressParameters.LabelName = "") Or df_CheckIfShowAddressField("I", "LABEL_NAME") Then
                        .LabelName = AddressParameters.LabelName
                    End If
                    .MailStop = AddressParameters.MailStop
                    .AttentionLine = AddressParameters.Attention
                    .JobTitle = AddressParameters.JobTitle
                    .ShipToFlag = AddressParameters.ShipAddressFlag
                    .BillToFlag = AddressParameters.BillAddressFlag
                    .DirectoryFlag = AddressParameters.ForDirectoryFlag
                    .ConfidentialFlag = AddressParameters.ConfidentialFlag
                    '.SeasonalEndDate  = 
                    .AddressStatusCode = .AddressStatusCode.List("GOOD").ToCodeObject
                    If AddressParameters.PrimaryAddressFlag = True Then
                        .MakeAddressPrimary()
                    End If
                    '.SeasonalStartDate
                    '.OneTimeUseFlag = 

                    .CompanyName = AddressParameters.CompanyName
                    .CompanyMasterCustomer = AddressParameters.CompanyMasterCustomerId
                    .CompanySubCustomer = AddressParameters.CompanySubCustomerId
                End With
                If AddressParameters.CompanyMasterCustomerId.Length > 0 AndAlso AddressParameters.CompanyAddressId > 0 Then
                    oAddressDetail.LinkAddress(AddressParameters.CompanyMasterCustomerId, _
                            AddressParameters.SubCustomerId, "C", AddressParameters.CompanyName, _
                            oAddressDetail.AddressStatusCodeString, AddressParameters.CompanyAddressId)
                    'oAddress = oAddressDetail.Address
                    'If Not oAddress Is Nothing Then
                    'If bGUIDExists Then
                    'oAddress.Guid = oclsGUID(1).GUID
                    'Else
                    'oclsGUID(1).GUID = oAddress.Guid
                    'End If

                    'End If


                Else
                    'oAddress = oAddressDetail.Address

                    If bGUIDExists Then
                        oAddressDetail.Address.Guid = oclsGUID(0).GUID
                    Else
                        oclsGUID(0).GUID = oCustomers(0).Guid
                        oAddressDetail.Address.Guid = oCustomers(0).Guid
                    End If


                    With oAddressDetail.Address
                        'Part of CQ30948, move countrycode assignment up to first, because address structure is depending on it.
                        .CountryCode = .CountryCode.List(AddressParameters.CountryCode).ToCodeObject
                        .Address1 = AddressParameters.Address1
                        .Address2 = AddressParameters.Address2
                        .Address3 = AddressParameters.Address3
                        .Address4 = AddressParameters.Address4
                        .AddressStatusCode = .AddressStatusCode.List("GOOD").ToCodeObject
                        .City = AddressParameters.City
                        .State = AddressParameters.State
                        .PostalCode = AddressParameters.PostalCode
                        .County = AddressParameters.CountyCode
                        .OneTimeUseFlag = AddressParameters.OneTimeAddress
                    End With
                End If

            ElseIf Mode = TransactionMode.EDIT Then
                oPredicates = New Specialized.ListDictionary
                oPredicates.Add("MasterCustomerId", CStr(AddressParameters.MasterCustomerId))
                oPredicates.Add("SubCustomerId", CInt(AddressParameters.SubCustomerId))
                oPredicates.Add("CustomerAddressId", CLng(AddressParameters.CustomerAddressId))


                oAddressDetail = oCustomers(0).AddressDetails.FindObject(oPredicates)
                If bGUIDExists Then
                    oAddressDetail.Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).Guid
                    oAddressDetail.Guid = oCustomers(0).Guid
                End If
                With oAddressDetail
                    '5785035
                    If Not (AddressParameters.LabelName = "") Or df_CheckIfShowAddressField("I", "LABEL_NAME") Then
                        .LabelName = AddressParameters.LabelName
                    End If
                    .MailStop = AddressParameters.MailStop
                    .AttentionLine = AddressParameters.Attention
                    .JobTitle = AddressParameters.JobTitle
                    .ShipToFlag = AddressParameters.ShipAddressFlag
                    .BillToFlag = AddressParameters.BillAddressFlag
                    .DirectoryFlag = AddressParameters.ForDirectoryFlag
                    .ConfidentialFlag = AddressParameters.ConfidentialFlag

                    If AddressParameters.PrimaryAddressFlag = True Then
                        '.PrioritySeq = 0
                        .MakeAddressPrimary()
                    End If

                    .CompanyName = AddressParameters.CompanyName
                    If Not oAddressDetail.IsAddressLinked Then
                        .CompanyMasterCustomer = AddressParameters.CompanyMasterCustomerId
                        .CompanySubCustomer = AddressParameters.CompanySubCustomerId
                    End If
                End With
                'If AddressParameters.CompanyMasterCustomerId.Length > 0 Then

                'Else

                'oAddress = oAddressDetail.Address
                If Not oAddressDetail.IsAddressLinked Then
                    With oAddressDetail.Address
                        'Part of CQ30948, move countrycode assignment up to first, because address structure is depending on it.
                        .CountryCode = .CountryCode.List(AddressParameters.CountryCode).ToCodeObject
                        .Address1 = AddressParameters.Address1
                        .Address2 = AddressParameters.Address2
                        .Address3 = AddressParameters.Address3
                        .Address4 = AddressParameters.Address4
                        .City = AddressParameters.City
                        .State = AddressParameters.State
                        .PostalCode = AddressParameters.PostalCode
                        .County = AddressParameters.CountyCode
                        .OneTimeUseFlag = AddressParameters.OneTimeAddress
                    End With
                End If
               
                If Not oAddressDetail.Address Is Nothing Then
                    If bGUIDExists Then
                        oAddressDetail.Address.Guid = oclsGUID(0).GUID
                    Else
                        oclsGUID(0).GUID = oCustomers(0).Guid
                        oAddressDetail.Address.Guid = oCustomers(0).Guid
                    End If
                End If
            End If

            'End If

            AddSessionObject(SessionKeys.PersonifySaveAddressGUIDKeys, oclsGUID)

            'If (oAddressDetail.Address.IsAddressValidated = False) Then
            '    oAddressDetail.Address.ValidateAddress()

            '    If (oCustomers(0).ValidationIssues.Count > 0) Then
            '        'sim strKey as string = oCustomers(0).ValidationIssues.Contains("")
            '        For cnt As Integer = 0 To oCustomers(0).ValidationIssues.Count
            '            If (oCustomers(0).ValidationIssues(cnt).Key.Contains("TIMSS.API.Base.CustomerInfo.AddressValidationIssue")) Then
            '                If (CType(oCustomers(0).ValidationIssues(cnt), TIMSS.API.Base.CustomerInfo.AddressValidationIssue).SystemAddressPostalErrorCode = "") Then
            '                    oAddressDetail.Address.IsAddressValidated = True
            '                    oCustomers(0).ValidationIssues(cnt).Severity = Validation.IssueSeverityEnum.Information
            '                    Return oCustomers.ValidationIssues
            '                End If
            '            End If
            '        Next

            '    End If
            'End If
            If (oAddressDetail.Address.IsAddressValidated = False) Then
                oAddressDetail.Address.ValidateAddress()
                If (oCustomers(0).ValidationIssues.ErrorCount > 0) Then
                    If oAddressDetail.Address.PostalErrorCodeString = "" Then
                        'This is for showing the state of validation for how to process next step
                        'AutoRespondTriggered when no error with question asked for choose the validated address.
                        'Part of CQ30948, change "AutoRespondTriggered = True" to "ValidationState = "AutoRespondTriggered""
                        ValidationState = "AutoRespondTriggered"
                    End If
                    'Part of CQ30948, add else section
                Else
                    ValidationState = "NoValidationIssue"
                End If
            End If

            oAddressDetail.Address.IsAddressValidationAutoRespond = True

            If oCustomers(0).ValidationIssues.ErrorCount = 0 Then
                oCustomers.Save()

            End If

            If oCustomers.ValidationIssues.ErrorCount > 0 Then
                oCustomers.Save()
                If RespondedValidationIssues IsNot Nothing Then
                    RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)
                End If
                oCustomers.Save()
            End If

            ' Clear the cached addresses if there are no validation issues
            If oCustomers.ValidationIssues.ErrorCount = 0 Then
                '3246-7661614
                If ValidationState = "NotValidated" Then
                    ValidationState = "NoValidationIssue"
                End If
                ClearSessionObject(SessionKeys.PersonifySaveAddressGUIDKeys)

            End If

            oReturnCustomerObject = oCustomers
            Return oCustomers.ValidationIssues
            'Finally
            '    System.Threading.Monitor.Exit(objLock)
            'End Try





        End Function


        '5785035
        Private Function df_CheckIfShowAddressField(ByVal RecordType As String, ByVal FieldName As String) As Boolean
            Dim oAddressDetailStructures As TIMSS.API.CustomerInfo.ICustomerAddressDetailStructures
            Dim oAddressDetailStructure As TIMSS.API.CustomerInfo.ICustomerAddressDetailStructure
            oAddressDetailStructures = TIMSS.API.CachedApplicationData.ApplicationDataCache.CustomerAddressDetailStructures(RecordType)
            ' oAddressDetailStructures = Customer.GetCustomerAddressDetailStructures(0, RecordType)
            'oAddressDetailStructures.Sort("LineNumber", ListSortDirection.Ascending)

            For Each oAddressDetailStructure In oAddressDetailStructures
                With oAddressDetailStructure
                    Select Case .FieldName
                        Case FieldName
                            Return True
                    End Select
                End With
            Next

            Return False
        End Function

        Private Sub RedirectPage()
            If Not String.IsNullOrEmpty(Request.QueryString("ReturnURL")) Then
                Response.Redirect(Request.QueryString("ReturnURL"))
            ElseIf String.IsNullOrEmpty(Request.QueryString("CHANGEADDRESSTYPE")) Then
                Response.Redirect(NavigateURL)

            Else
                Response.Redirect(String.Concat(NavigateURL, "?CHANGEADDRESSTYPE=", Request.QueryString("CHANGEADDRESSTYPE")))
            End If
        End Sub

#End Region

    End Class


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    <Serializable()> _
       Public Class AddressParameters

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="pMasterCustomerId"></param>
        ''' <param name="pSubCustomerId"></param>
        ''' <remarks></remarks>
        Public Sub New(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer)
            _MasterCustomerId = pMasterCustomerId
            _SubCustomerId = pSubCustomerId
        End Sub

#Region " Private Variables "

        Private _MasterCustomerId As String
        Private _SubCustomerId As Integer
        Private _LabelName As String = "UNCHANGED"
        Private _MailStop As String = ""
        Private _Attention As String = ""
        Private _JobTitle As String = ""
        Private _CustomerAddressId As Integer = -1
        Private _AddressType As String = ""
        Private _Address1 As String = ""
        Private _Address2 As String = ""
        Private _Address3 As String = ""
        Private _Address4 As String = ""
        Private _City As String = ""
        Private _State As String = ""
        Private _PostalCode As String = ""
        Private _CountryCode As String = ""
        Private _CountyCode As String = ""
        Private _PrimaryAddressFlag As Boolean = False
        Private _ShipAddressFlag As Boolean = False
        Private _BillAddressFlag As Boolean = False
        Private _ForDirectoryFlag As Boolean = False
        Private _ConfidentialFlag As Boolean = False
        Private _CompanyName As String = ""
        Private _CompanyMasterCustomerId As String = ""
        Private _CompanySubCustomerId As Integer = -1
        Private _CompanyAddressId As Integer = -1
        Private _CompanyAddressStatusCode As String = ""
        Private _SeasonalStartDate As String = ""
        Private _SeasonalEndDate As String = ""
        Private _OneTimeAddress As Boolean = False

#End Region

#Region " Properties "

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property MasterCustomerId() As String
            Get
                Return _MasterCustomerId
            End Get
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property SubCustomerId() As Integer
            Get
                Return _SubCustomerId
            End Get
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CustomerAddressId() As Integer
            Get
                Return _CustomerAddressId
            End Get
            Set(ByVal value As Integer)
                _CustomerAddressId = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property LabelName() As String
            Get
                Return _LabelName
            End Get
            Set(ByVal value As String)
                _LabelName = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MailStop() As String
            Get
                Return _MailStop
            End Get
            Set(ByVal value As String)
                _MailStop = value
            End Set
        End Property
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Attention() As String
            Get
                Return _Attention
            End Get
            Set(ByVal value As String)
                _Attention = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property JobTitle() As String
            Get
                Return _JobTitle
            End Get
            Set(ByVal value As String)
                _JobTitle = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property AddressType() As String
            Get
                Return _AddressType
            End Get
            Set(ByVal value As String)
                _AddressType = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Address1() As String
            Get
                Return _Address1
            End Get
            Set(ByVal value As String)
                _Address1 = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Address2() As String
            Get
                Return _Address2
            End Get
            Set(ByVal value As String)
                _Address2 = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Address3() As String
            Get
                Return _Address3
            End Get
            Set(ByVal value As String)
                _Address3 = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Address4() As String
            Get
                Return _Address4
            End Get
            Set(ByVal value As String)
                _Address4 = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property City() As String
            Get
                Return _City
            End Get
            Set(ByVal value As String)
                _City = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property State() As String
            Get
                Return _State
            End Get
            Set(ByVal value As String)
                _State = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PostalCode() As String
            Get
                Return _PostalCode
            End Get
            Set(ByVal value As String)
                _PostalCode = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CountryCode() As String
            Get
                Return _CountryCode
            End Get
            Set(ByVal value As String)
                _CountryCode = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CountyCode() As String
            Get
                Return _CountyCode
            End Get
            Set(ByVal value As String)
                _CountyCode = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PrimaryAddressFlag() As Boolean
            Get
                Return _PrimaryAddressFlag
            End Get
            Set(ByVal value As Boolean)
                _PrimaryAddressFlag = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ShipAddressFlag() As Boolean
            Get
                Return _ShipAddressFlag
            End Get
            Set(ByVal value As Boolean)
                _ShipAddressFlag = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property BillAddressFlag() As Boolean
            Get
                Return _BillAddressFlag
            End Get
            Set(ByVal value As Boolean)
                _BillAddressFlag = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ForDirectoryFlag() As Boolean
            Get
                Return _ForDirectoryFlag
            End Get
            Set(ByVal value As Boolean)
                _ForDirectoryFlag = value
            End Set
        End Property
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ConfidentialFlag() As Boolean
            Get
                Return _ConfidentialFlag
            End Get
            Set(ByVal value As Boolean)
                _ConfidentialFlag = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CompanyName() As String
            Get
                Return _CompanyName
            End Get
            Set(ByVal value As String)
                _CompanyName = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CompanyMasterCustomerId() As String
            Get
                Return _CompanyMasterCustomerId
            End Get
            Set(ByVal value As String)
                _CompanyMasterCustomerId = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CompanySubCustomerId() As Integer
            Get
                Return _CompanySubCustomerId
            End Get
            Set(ByVal value As Integer)
                _CompanySubCustomerId = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SeasonalStartDate() As String
            Get
                Return _SeasonalStartDate
            End Get
            Set(ByVal value As String)
                _SeasonalStartDate = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SeasonalEndDate() As String
            Get
                Return _SeasonalEndDate
            End Get
            Set(ByVal value As String)
                _SeasonalEndDate = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property OneTimeAddress() As Boolean
            Get
                Return _OneTimeAddress
            End Get
            Set(ByVal value As Boolean)
                _OneTimeAddress = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CompanyAddressId() As Integer
            Get
                Return _CompanyAddressId
            End Get
            Set(ByVal value As Integer)
                _CompanyAddressId = value
            End Set
        End Property

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CompanyAddressStatusCode() As String
            Get
                Return _CompanyAddressStatusCode
            End Get
            Set(ByVal value As String)
                _CompanyAddressStatusCode = value
            End Set
        End Property

#End Region

    End Class


End Namespace

