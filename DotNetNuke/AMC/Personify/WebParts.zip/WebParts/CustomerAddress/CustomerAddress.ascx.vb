Imports System
Imports System.Web.UI.WebControls
Imports Personify

Namespace Personify.DNN.Modules.CustomerAddress

    Public MustInherit Class CustomerAddress
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String

                role = Me.GetUserRole(UserInfo)

                If role = "personifyuser" Or role = "personifyadmin" Then
                    Dim UseCompanyLookup As Boolean = False
                    If Not Settings(CType(ModuleSettingsNames.UseCompanyLookup, String)) Is Nothing Then
                        UseCompanyLookup = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.UseCompanyLookup, String)), String) = "Y", True, False))
                    Else
                        UseCompanyLookup = False
                    End If
                    '5801614
                    Dim message As String = "N"
                    If Not Settings(CType(ModuleSettingsNames.ShowGroup1ValidatedMessage, String)) Is Nothing Then
                        If CType(Settings(CType(ModuleSettingsNames.ShowGroup1ValidatedMessage, String)), String) = "Y" Then
                            message = "Y"
                        Else
                            message = "N"
                        End If
                    End If

                    '3246-5774803
                    LoadImages()
                    'END 3246-5774803

                    If Not Page.IsPostBack Then

                    Else

                    End If
                        'Add the URL for AddCommunication Method

                    If String.IsNullOrEmpty(Request.QueryString("CHANGEADDRESSTYPE")) Then
                        hlAddAddress.NavigateUrl = NavigateURL(TabId, "ADDADDRESS", "MODE=ADD", String.Concat("USECOMPANYLOOKUP=", UseCompanyLookup), String.Concat("SHOWGROUPONEMESSAGE=", message))
                    Else
                        hlAddAddress.NavigateUrl = NavigateURL(TabId, "ADDADDRESS", "MODE=ADD", String.Concat("USECOMPANYLOOKUP=", UseCompanyLookup), String.Concat("SHOWGROUPONEMESSAGE=", message), String.Concat("CHANGEADDRESSTYPE=", Request.QueryString("CHANGEADDRESSTYPE")))
                    End If
                    LoadAddresses()
                Else
                    lblAddresses.Visible = False
                    ImgAddNew.Visible = False
                    tblLegend.Visible = False
                    pnlAddresses.Visible = False
                    hlAddAddress.Visible = False
                    DisplayUserAccessMessage(role)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Protected WithEvents ImgAddNew As Image
        Protected WithEvents imgShipTo As Image
        Protected WithEvents imgBillTo As Image
        Protected WithEvents imgPublished As Image
        Protected WithEvents imgConfidential As Image


        Protected WithEvents btnConfidential As System.Web.UI.WebControls.Image
        Protected WithEvents IsBillTo As System.Web.UI.WebControls.Literal
        Protected WithEvents pnlEditAddress As System.Web.UI.WebControls.Panel
        Protected WithEvents AddressCommunicationListing As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents hlAddAddress As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblAddresses As System.Web.UI.WebControls.Label

        Protected WithEvents pnlAddresses As System.Web.UI.WebControls.Panel
        Protected WithEvents lblLegendConfidential As System.Web.UI.WebControls.Label

        Protected WithEvents lblLegendPublished As System.Web.UI.WebControls.Label

        Protected WithEvents lblLegendBillTo As System.Web.UI.WebControls.Label

        Protected WithEvents lblLegendShipTo As System.Web.UI.WebControls.Label

        Protected WithEvents lblPrimary As System.Web.UI.WebControls.Label

        Protected WithEvents lblLegend As System.Web.UI.WebControls.Label
        Protected WithEvents tblLegend As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents AddressList As System.Web.UI.WebControls.DataList

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

        Private Sub LoadAddresses()

         

            If Me.IsPersonifyWebUserLoggedIn = False Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If



            If Not UserInfo.IsSuperUser AndAlso MasterCustomerId IsNot Nothing Then
                'If Not Page.IsPostBack Then
                Dim objModule As Entities.Modules.PortalModuleBase = CType(Me.LoadControl("Addresses.ascx"), DotNetNuke.Entities.Modules.PortalModuleBase)

                If Not objModule Is Nothing Then
                    objModule.ModuleConfiguration = Me.ModuleConfiguration
                    pnlAddresses.Controls.Add(objModule)
                End If

                If Not Settings(ModuleSettingsNames.DisplayLegend) Is Nothing AndAlso Settings(ModuleSettingsNames.DisplayLegend).ToString = "1" Then
                    tblLegend.Visible = True
                Else
                    tblLegend.Visible = False
                End If
                'End If
            Else
                If UserInfo.IsSuperUser Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AdminModeMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If

            End If


        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        End Sub

#Region "Helper Functions"
        '3246-5774803
        Private Sub LoadImages()

            ImgAddNew.ImageUrl = "~/" & SiteImagesFolder & "/addnew_11x11.gif"
            imgShipTo.ImageUrl = "~/" & SiteImagesFolder & "/package_16x16.gif"
            imgBillTo.ImageUrl = "~/" & SiteImagesFolder & "/billto_16x16.gif"
            imgPublished.ImageUrl = "~/" & SiteImagesFolder & "/addressbook_16x16.gif"
            imgConfidential.ImageUrl = "~/" & SiteImagesFolder & "/address_hidden_16x16.gif"
        End Sub
        'END 3246-5774803
#End Region
    End Class

End Namespace
