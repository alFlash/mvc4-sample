Option Strict Off
Imports System
Imports System.Web.UI.WebControls
Imports Personify


Namespace Personify.DNN.Modules.CustomerAddress
    <CLSCompliant(False)> _
    Public MustInherit Class Addresses
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


        Protected WithEvents lblNoAddresses As System.Web.UI.WebControls.Label
        Protected WithEvents AutoCompleteTextBox1 As WebControls.AutoCompleteTextBox


#Region "Controls"
#End Region

#Region "Event Handlers"
        'Protected Sub SearchCompanies(ByVal sender As Object, ByVal e As System.EventArgs)
        '    Try
        '        Response.Write("I changed text")
        '    Catch ex As Exception
        '        TIMSSCMS.WebControls.CallBackHelper.HandleError(ex)
        '    End Try

        'End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                'If strMCID.Length > 0 Then
                If Me.IsPersonifyWebUserLoggedIn = True Then

                    LoadSettings()
                    BindAddresses()

                    'If Not IsPostBack Then

                    'Else
                    If Request.Form("__EVENTTARGET") IsNot Nothing Then
                        If (Request.Form("__EVENTTARGET").IndexOf("CountryDropDownList1")) > 0 Then
                            ChangeCountry(Request.Form(Request.Form("__EVENTTARGET")))
                        Else
                            BindAddresses()
                            If Not Session("dlAddressesIndex") Is Nothing Then
                                SetAddressStructure(GetAddressCountry(CType(Session("dlAddressesIndex"), Integer)), CType(Session("dlAddressesIndex"), Integer))
                            End If
                        End If
                    End If
                End If

                'End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadSettings()

            If Not Settings(ModuleSettingsNames.Layout) Is Nothing Then
                If Settings(ModuleSettingsNames.Layout).ToString = "H" Then
                    dlAddresses.RepeatDirection = RepeatDirection.Horizontal
                ElseIf Settings(ModuleSettingsNames.Layout).ToString = "H" Then
                    dlAddresses.RepeatDirection = RepeatDirection.Vertical
                End If
            Else
                ' Default layout is vertical
                dlAddresses.RepeatDirection = RepeatDirection.Vertical
            End If
            If Not Settings(ModuleSettingsNames.Columns) Is Nothing Then
                dlAddresses.RepeatColumns = CType(Settings(ModuleSettingsNames.Columns).ToString, Integer)
            Else
                ' Default is one column
                dlAddresses.RepeatColumns = 1
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/19/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub BindAddresses()
            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            'Dim oAddressesTemp As TIMSS.API.CustomerInfo.ICustomerAddressViewList
            Dim i As Integer
            Dim FetchAllAddresses As Boolean = False


            i = 0

            'If DisplayDisabledAddresses is Set to FALSE then only GOOD addresses are displayed

            If Not Settings(ModuleSettingsNames.DisplayDisabledAddress) Is Nothing Then
                If Settings(ModuleSettingsNames.DisplayDisabledAddress) = 1 Then
                    FetchAllAddresses = True
                End If
            End If


            oAddresses = DF_GetCustomerAddress(MasterCustomerId, SubCustomerId, FetchAllAddresses)

            For j As Integer = oAddresses.Count - 1 To 0 Step -1
                If oAddresses.Item(j).OneTimeUseFlag = True Then
                    oAddresses.Remove(oAddresses.Item(j))
                End If
            Next j

            'For Each oAddress As TIMSS.API.CustomerInfo.ICustomerAddressView In oAddresses
            '    If oAddress.OneTimeUseFlag = False Then
            '        oAddressesTemp.Add(oAddress)
            '    End If
            'Next
            dlAddresses.DataSource = oAddresses
            dlAddresses.DataBind()

            If dlAddresses.Items.Count = 0 Then
                lblNoAddresses.Visible = True
            End If

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        Protected WithEvents dlAddresses As System.Web.UI.WebControls.DataList
        Protected WithEvents CountryDropDownList2 As WebControls.CountryDropDownList

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

#Region "Address DataList Events"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="Country"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/22/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ChangeCountry(ByVal Country As String)
            ' TODO: Need create a new State control here 
            ' instead of changing the existing one.
            ' Cannot get the chnaged value before hand.
            ' ------------------------------------------------
            Dim cboCountry As WebControls.CountryDropDownList
            'Dim cboState As TIMSSCMS.WebControls.TCMSStateDropDownList
            'Dim AlternateState As Panel

            cboCountry = CType(dlAddresses.Controls(CType(Session("dlAddressesIndex"), Integer)).FindControl("CountryDropDownList1"), WebControls.CountryDropDownList)

            'AlternateState = CType(dlAddresses.Controls(CType(Session("dlAddressesIndex"), Integer)).FindControl("AlternateState"), Panel)
            If Not cboCountry Is Nothing Then
                cboCountry.DefaultValue = Country
                cboCountry.AutoPostBack = True
            End If

            SetAddressStructure(Country, CType(Session("dlAddressesIndex"), Integer))
        End Sub
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This methods sets the right icons legends to the address
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/19/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub dlAddresses_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles dlAddresses.ItemDataBound
            Dim IsBillTo As Literal
            Dim IsShipTo As Literal
            Dim IsConfidential As Literal
            Dim IsPublished As Literal
            Dim IsPrimary As Literal
            Dim ImgBillTo As Image
            Dim ImgShipTo As Image
            Dim ImgConfidential As Image
            Dim ImgPublished As Image
            'Dim ImgPrimary As Image
            Dim Edit As LinkButton
            Dim lnkEnable As LinkButton
            Dim lnkDisable As LinkButton
            Dim AddrStatusCode As Literal
            Dim lnkSelectaddress As LinkButton
            Select Case e.Item.ItemType
                Case ListItemType.Item, ListItemType.AlternatingItem
                    IsBillTo = CType(e.Item.FindControl("IsBillTo"), Literal)
                    IsShipTo = CType(e.Item.FindControl("IsShipTo"), Literal)
                    IsConfidential = CType(e.Item.FindControl("IsConfidential"), Literal)
                    IsPublished = CType(e.Item.FindControl("IsPublished"), Literal)
                    IsPrimary = CType(e.Item.FindControl("IsPrimary"), Literal)
                    ImgBillTo = CType(e.Item.FindControl("ImgBillTo"), Image)
                    ImgShipTo = CType(e.Item.FindControl("ImgShipTo"), Image)
                    ImgConfidential = CType(e.Item.FindControl("ImgConfidential"), Image)
                    ImgPublished = CType(e.Item.FindControl("ImgPublished"), Image)
                    'ImgPrimary = CType(e.Item.FindControl("ImgPrimary"), Image)

                    ImgShipTo.ImageUrl = "~/" & siteimagesFolder & "/package_16x16.gif"
                    ImgBillTo.ImageUrl = "~/" & siteimagesFolder & "/billto_16x16.gif"
                    ImgPublished.ImageUrl = "~/" & siteimagesFolder & "/addressbook_16x16.gif"
                    ImgConfidential.ImageUrl = "~/" & siteimagesFolder & "/address_hidden_16x16.gif"
                    'end 3246-5774803

                    If IsBillTo.Text = "True" Then
                        ImgBillTo.Visible = True                        
                    End If

                    If IsShipTo.Text = "True" Then
                        ImgShipTo.Visible = True
                    End If

                    If IsConfidential.Text = "True" Then
                        ImgConfidential.Visible = True
                    End If

                    If IsPublished.Text = "True" Then
                        ImgPublished.Visible = True
                    End If

                    If IsPrimary.Text = "0" Then
                        'ImgPrimary.Visible = True
                    End If

                    Dim CusAddressID As String = ""


                    Edit = CType(e.Item.Controls(0).FindControl("btnEditAddress"), LinkButton)

                    GetCusAddressIdFromCommangArg(Edit.CommandArgument.ToString, CusAddressID)

                    Dim UseCompanyLookup As Boolean
                    If Not Settings(CType(ModuleSettingsNames.UseCompanyLookup, String)) Is Nothing Then
                        UseCompanyLookup = CBool(IIf(CType(Settings(CType(ModuleSettingsNames.UseCompanyLookup, String)), String) = "Y", True, False))
                    Else
                        UseCompanyLookup = False
                    End If

                    '5801614
                    Dim message As String = "N"
                    If Not Settings(CType(ModuleSettingsNames.ShowGroup1ValidatedMessage, String)) Is Nothing Then
                        If CType(Settings(CType(ModuleSettingsNames.ShowGroup1ValidatedMessage, String)), String) = "Y" Then
                            message = "Y"
                        Else
                            message = "N"
                        End If
                    End If

                    Edit.PostBackUrl = NavigateURL(TabId, "ADDADDRESS", "MODE=EDIT", "USECOMPANYLOOKUP=" & UseCompanyLookup, "CustomerAddressId=" & CusAddressID, "SHOWGROUPONEMESSAGE=" & message)
                    If String.IsNullOrEmpty(Request.QueryString("CHANGEADDRESSTYPE")) Then
                        Edit.PostBackUrl = NavigateURL(TabId, "ADDADDRESS", "MODE=EDIT", String.Concat("USECOMPANYLOOKUP=", UseCompanyLookup), String.Concat("CustomerAddressId=", CusAddressID), String.Concat("SHOWGROUPONEMESSAGE=", message))
                    Else
                        Edit.PostBackUrl = NavigateURL(TabId, "ADDADDRESS", "MODE=EDIT", String.Concat("USECOMPANYLOOKUP=", UseCompanyLookup), String.Concat("CustomerAddressId=", CusAddressID), String.Concat("SHOWGROUPONEMESSAGE=", message), String.Concat("CHANGEADDRESSTYPE=", Request.QueryString("CHANGEADDRESSTYPE")))
                    End If

                    lnkDisable = CType(e.Item.Controls(0).FindControl("btnDisableAddress"), LinkButton)
                    lnkEnable = CType(e.Item.Controls(0).FindControl("btnEnableAddress"), LinkButton)
                    'Disable Enable/Disable Address Features

                    lnkEnable.Visible = False
                    lnkDisable.Visible = False

                    If Not Settings(ModuleSettingsNames.AllowAddressStatusChange) Is Nothing AndAlso Settings(ModuleSettingsNames.AllowAddressStatusChange).ToString = "1" Then
                        'If Address Status is GOOD, display Disable Link
                        'If it is BAD ..display ENABLE LINK
                        AddrStatusCode = CType(e.Item.FindControl("AddressStatusCode"), Literal)
                        If AddrStatusCode.Text.ToUpper = "BAD" Then
                            lnkEnable.Visible = True
                        Else
                            lnkDisable.Visible = True
                        End If
                    End If

                    'Select Order Link should be displayed only if the Setting is set to true
                    lnkSelectaddress = CType(e.Item.Controls(0).FindControl("btnSelectAddress"), LinkButton)
                    lnkSelectaddress.Visible = False
                    If Not Settings(ModuleSettingsNames.OrderAddressSelect) Is Nothing AndAlso Settings(ModuleSettingsNames.OrderAddressSelect).ToString = "1" Then
                        lnkSelectaddress.Visible = True
                        'lnkSelectaddress.PostBackUrl = NavigateURL(CInt(Settings(ModuleSettingsNames.SelectOrderURL)), False, CusAddressID)
                        'lnkSelectaddress.PostBackUrl = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.SelectOrderURL), String) & "&SelectedAddressId=" & CusAddressID
                    End If

            End Select
        End Sub
        Private Sub GetCusAddressIdFromCommangArg(ByVal CommandArgument As String, ByRef CusAddressId As String)

            Dim str() As String
            Dim Comma As String = ","

            str = Split(CommandArgument, ",")
            CusAddressId = str(0)
            'CommType = str(1)

        End Sub
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="source"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/19/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub dlAddresses_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles dlAddresses.ItemCommand
            Select Case e.CommandName.ToUpper
                Case "EDITADDRESS"
                    'dlAddresses.EditItemIndex = e.Item.ItemIndex
                    'BindAddresses()
                    'SetAddressStructure(GetAddressCountry(e.Item.ItemIndex), e.Item.ItemIndex)
                    'Session("dlAddressesIndex") = e.Item.ItemIndex
                Case "CANCEL"
                    Session("dlAddressesIndex") = Nothing
                    dlAddresses.EditItemIndex = -1
                    BindAddresses()
                Case "SAVE"
                    Session("dlAddressesIndex") = Nothing
                    dlAddresses.EditItemIndex = -1

                    BindAddresses()
                Case "ENABLEADDRESS"
                    If df_CustomerEnableDisableAddress(True, MasterCustomerId, SubCustomerId, e.CommandArgument.ToString) Then
                        'Response.Redirect(Page.Request.Url.ToString)
                        If String.IsNullOrEmpty(Request.QueryString("CHANGEADDRESSTYPE")) Then
                            Response.Redirect(NavigateURL)
                        Else
                            Response.Redirect(String.Concat(NavigateURL, "?CHANGEADDRESSTYPE=", Request.QueryString("CHANGEADDRESSTYPE")))
                        End If
                    End If
                Case "DISABLEADDRESS"
                    If df_CustomerEnableDisableAddress(False, MasterCustomerId, SubCustomerId, e.CommandArgument.ToString) Then
                        'Response.Redirect(Page.Request.Url.ToString)
                        If String.IsNullOrEmpty(Request.QueryString("CHANGEADDRESSTYPE")) Then
                            Response.Redirect(NavigateURL)
                        Else
                            Response.Redirect(String.Concat(NavigateURL, "?CHANGEADDRESSTYPE=", Request.QueryString("CHANGEADDRESSTYPE")))
                        End If
                    End If

                Case "SELECTADDRESS"
                    SetAddressIdForTheSelectedOrder(CInt(e.CommandArgument), "")

                    'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Address was updated successfully!", Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
            End Select
        End Sub

        Private Sub SetAddressIdForTheSelectedOrder(ByVal AddressId As Integer, ByVal AddressTypeCode As String)

            Dim oOrderMasters As TIMSS.API.OrderInfo.IOrderMasters
            Dim strURL As String
            Try
                oOrderMasters = GetOrderFromSessionObject()

                If Not oOrderMasters Is Nothing Then
                    If String.Compare(Request.QueryString("CHANGEADDRESSTYPE"), "BILL", True) = 0 Then
                        '3246-7661614
                        oOrderMasters = DF_SetBillAddressIDForOrder(AddressId, oOrderMasters)
                    ElseIf String.Compare(Request.QueryString("CHANGEADDRESSTYPE"), "SHIP", True) = 0 Then
                        oOrderMasters = DF_SetShipAddressIDForOrder(AddressId, oOrderMasters)
                    End If

                    AddSessionObject(Personify.ApplicationManager.PersonifyEnumerations.SessionKeys.PersonifyOrder, oOrderMasters)
                 
                    strURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.SelectOrderURL), String)
                    Try
                        Response.Redirect(strURL)
                    Catch ex As System.Threading.ThreadAbortException
                        'Do Nothing

                    End Try


                Else
                    'Give a message
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoItemsCheckedOut", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    'TODO -should redirect to home page

                End If

            Catch ex As Exception
                Throw ex
            End Try

        End Sub

        Private Function GetOrderFromSessionObject() As TIMSS.API.OrderInfo.IOrderMasters

            If Not GetSessionObject(Personify.ApplicationManager.PersonifyEnumerations.SessionKeys.PersonifyOrder) Is Nothing Then

                Return CType(GetSessionObject(Personify.ApplicationManager.PersonifyEnumerations.SessionKeys.PersonifyOrder), TIMSS.API.OrderInfo.IOrderMasters)

            Else
                Return Nothing
            End If

        End Function

        Private Function GetAddressCountry(ByVal ControlIndex As Integer) As String
            Dim cboCountry As WebControls.CountryDropDownList
            Dim cboState As WebControls.StateDropDownList
            Dim AddressCountry As Literal
            Dim AddressState As Literal
            cboCountry = CType(dlAddresses.Controls(ControlIndex).FindControl("CountryDropDownList1"), WebControls.CountryDropDownList)
            cboState = CType(dlAddresses.Controls(ControlIndex).FindControl("StateDropDownList1"), WebControls.StateDropDownList)
            AddressCountry = CType(dlAddresses.Controls(ControlIndex).FindControl("litAddressCountry"), Literal)
            AddressState = CType(dlAddresses.Controls(ControlIndex).FindControl("litState"), Literal)

            If Not cboCountry Is Nothing Then
                cboCountry.DefaultValue = AddressCountry.Text
                cboCountry.AutoPostBack = True
            End If

            If Not cboState Is Nothing Then
                cboState.CountryCode = AddressCountry.Text
                cboState.DefaultValue = AddressState.Text
            End If

            If Not AddressCountry Is Nothing Then
                Return AddressCountry.Text
            Else
                Return Nothing
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="CountryCode"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/20/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub SetAddressStructure(ByVal CountryCode As String, ByVal ControlIndex As Integer)
            Try
                Dim oAddressStructures As TIMSS.API.CustomerInfo.ICustomerAddressStructures
                Dim oAddressStructure As TIMSS.API.CustomerInfo.ICustomerAddressStructure
                'Get Address Structures from API Cache
                'oAddressStructures = ApplicationManager.Customer.GetCustomerAddressStructures(PortalId, CountryCode)

                oAddressStructures = TIMSS.API.CachedApplicationData.ApplicationDataCache.CustomerAddressStructures(CountryCode)

                Dim RowAddress1 As HtmlTableRow
                Dim RowAddress2 As HtmlTableRow
                Dim RowAddress3 As HtmlTableRow
                Dim RowAddress4 As HtmlTableRow
                Dim RowCity As HtmlTableRow
                Dim RowCounty As HtmlTableRow
                Dim RowPostalCode As HtmlTableRow
                Dim RowState As HtmlTableRow

                ' We need to reset the form
                ' each time we load for a new
                ' or different country
                ' 
                RowAddress1 = CType(dlAddresses.Controls(ControlIndex).FindControl("RowAddress1"), HtmlTableRow)
                If Not RowAddress1 Is Nothing Then
                    RowAddress1.Visible = False
                End If
                RowAddress2 = CType(dlAddresses.Controls(ControlIndex).FindControl("RowAddress2"), HtmlTableRow)
                If Not RowAddress2 Is Nothing Then
                    RowAddress2.Visible = False
                End If
                RowAddress3 = CType(dlAddresses.Controls(ControlIndex).FindControl("RowAddress3"), HtmlTableRow)
                If Not RowAddress3 Is Nothing Then
                    RowAddress3.Visible = False
                End If
                RowAddress4 = CType(dlAddresses.Controls(ControlIndex).FindControl("RowAddress4"), HtmlTableRow)
                If Not RowAddress4 Is Nothing Then
                    RowAddress4.Visible = False
                End If

                RowCity = CType(dlAddresses.Controls(ControlIndex).FindControl("RowCity"), HtmlTableRow)
                If Not RowCity Is Nothing Then
                    RowCity.Visible = False
                End If
                RowCounty = CType(dlAddresses.Controls(ControlIndex).FindControl("RowCounty"), HtmlTableRow)
                If Not RowCounty Is Nothing Then
                    RowCounty.Visible = False
                End If
                RowPostalCode = CType(dlAddresses.Controls(ControlIndex).FindControl("RowPostalCode"), HtmlTableRow)
                If Not RowPostalCode Is Nothing Then
                    RowPostalCode.Visible = False
                End If
                RowState = CType(dlAddresses.Controls(ControlIndex).FindControl("RowState"), HtmlTableRow)

                If Not RowState Is Nothing Then
                    RowState.Visible = False
                End If
                If oAddressStructures.Count > 0 Then
                    For Each oAddressStructure In oAddressStructures
                        With oAddressStructure
                            Select Case oAddressStructure.FieldName
                                Case "ADDRESS_1"
                                    If Not RowAddress1 Is Nothing Then
                                        RowAddress1.Visible = True
                                    End If
                                Case "ADDRESS_2"
                                    If Not RowAddress2 Is Nothing Then
                                        RowAddress2.Visible = True
                                    End If
                                Case "ADDRESS_3"
                                    If Not RowAddress3 Is Nothing Then
                                        RowAddress3.Visible = True
                                    End If
                                Case "ADDRESS_4"

                                    If Not RowAddress4 Is Nothing Then
                                        RowAddress4.Visible = True
                                    End If
                                Case "CITY"
                                    If Not RowCity Is Nothing Then
                                        RowCity.Visible = True
                                    End If
                                Case "COUNTY"
                                    If Not RowCounty Is Nothing Then
                                        RowCounty.Visible = True
                                    End If
                                Case "POSTAL_CODE"
                                    If Not RowPostalCode Is Nothing Then
                                        RowPostalCode.Visible = True
                                    End If
                                Case "STATE"
                                    If Not RowState Is Nothing Then
                                        RowState.Visible = True
                                    End If
                            End Select
                        End With
                    Next
                Else
                    SetAddressStructure("[ALL]", ControlIndex)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try


        End Sub

#End Region
        '

#Region "Personify Data Fetch"

        Private Function DF_GetCustomerAddress(ByVal pMasterCustomerId As String, _
     ByVal pSubCustomerId As Integer, Optional ByVal FetchAllAddresses As Boolean = False) As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            Dim oAddresses As TIMSS.API.CustomerInfo.ICustomerAddressViewList

            oAddresses = Me.personifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddressViewList")

            With oAddresses.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
                If Not FetchAllAddresses Then
                    .Add("AddressStatusCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, "GOOD")
                End If
            End With
            oAddresses.Sort("PrioritySeq", ComponentModel.ListSortDirection.Ascending)
            oAddresses.Fill()

            Return oAddresses

        End Function


        Private Function df_CustomerEnableDisableAddress(ByVal EnableAddress As Boolean, ByVal MasterCustomerId As String, _
                   ByVal SubCustomerId As String, ByVal CustomerAddressId As Integer) As Boolean

            Dim oCusAddresses As TIMSS.API.CustomerInfo.ICustomerAddresses

            oCusAddresses = PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerAddresses")

            With oCusAddresses.Filter
                .Add("CustomerAddressId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CustomerAddressId)
            End With

            oCusAddresses.Fill()
            ''Try
            'oCusAddresses = GetCustomerAddressCollection(PortalId, MasterCustomerId, SubCustomerId, CustomerAddressId)

            If oCusAddresses.Count > 0 Then
                For Each oAddress As TIMSS.API.CustomerInfo.ICustomerAddressDetail In oCusAddresses(0).Details
                    If oAddress.MasterCustomerId = MasterCustomerId And oAddress.SubCustomerId = CInt(SubCustomerId) Then
                        If EnableAddress Then
                            oAddress.AddressStatusCode = oAddress.AddressStatusCode.List("GOOD").ToCodeObject
                        Else
                            oAddress.MakeAddressBad()
                        End If

                    End If
                Next
            End If

            Return oCusAddresses.Save
        End Function

        Private Function DF_SetShipAddressIDForOrder(ByVal ShipAddressID As Integer, ByVal OrderMasters As TIMSS.API.OrderInfo.IOrderMasters, Optional ByVal OrderLineNumber As Integer = -1) As TIMSS.API.OrderInfo.IOrderMasters

            If OrderMasters.Count > 0 Then
                '3246-7661614
                OrderMasters(0).ShipToCustomer.AddressDetails.Fill(False, True)
                OrderMasters(0).ShipToCustomer.Addresses.Fill(False, True)
                For i As Integer = 0 To OrderMasters(0).Details.Count - 1
                    With OrderMasters(0).Details(i)
                        If OrderLineNumber = -1 Then
                            OrderMasters(0).ShipAddressId = ShipAddressID
                        Else
                            If .OrderLineNumber = OrderLineNumber Then
                                OrderMasters(0).Details(i).ShipAddressId = ShipAddressID
                                Exit For
                            End If
                        End If
                    End With
                Next

            End If
            Return OrderMasters
        End Function

        Private Function DF_SetBillAddressIDForOrder(ByVal BillAddressID As Integer, ByVal OrderMasters As TIMSS.API.OrderInfo.IOrderMasters) As TIMSS.API.OrderInfo.IOrderMasters

            If OrderMasters.Count > 0 Then
                '3246-7661614
                OrderMasters(0).BillToCustomer.AddressDetails.Fill(False, True)
                OrderMasters(0).BillToCustomer.Addresses.Fill(False, True)
                OrderMasters(0).BillAddressId = BillAddressID
            End If

            Return OrderMasters
        End Function
       
#End Region
    End Class

End Namespace
