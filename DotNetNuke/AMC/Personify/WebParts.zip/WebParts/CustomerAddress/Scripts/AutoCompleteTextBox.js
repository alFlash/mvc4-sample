function AutoCompleteTextBox(TextBoxId, DivId, KeyStore, FrameId, DivClass)
{
	
	// initialize member variables
	
	var oThis = this;
	var oText = document.getElementById(TextBoxId);
	var oDiv  = document.getElementById(DivId);
	//var oIFrame = document.getElementById(FrameId)
	
	var oKeyStore = document.getElementById(KeyStore);
	
	this.TextBox = oText;
	this.KeyStore=oKeyStore;
	this.Div = oDiv;
	
	
	// CallBackObject + Event Handlers
	this.Cbo = new CallBackObject();

	
	this.Cbo.OnComplete = function(responseText,responseXML,KeyStore){oThis.Cbo_Complete(responseText,responseXML,KeyStore);};
	this.Cbo.OnError    = function(status,statusText,responseText){oThis.Cbo_Error(status,statusText,responseText);};
			
	// attach handlers to the TextBox
	oText.AutoCompleteTextBox = this;
	oText.onkeyup = AutoCompleteTextBox.prototype.OnKeyUp;
	oText.onkeydown = AutoCompleteTextBox.prototype.OnKeyDown;
	oText.onblur  = AutoCompleteTextBox.prototype.OnBlur;

	// align the drop down div
	var c = GetCoords(oText);
	var n = oText.style.pixelHeight;
	if( !n )
	{ 
	  n = 25;
	}
	else
	{
	  n += 2;
	}
	oDiv.style.left = c.x;
	oDiv.style.top = c.y + n;
	oDiv.style.display = 'none';
	oDiv.style.position = 'absolute';
	oDiv.style.zIndex = 1000;

	// Set some default styles
	if( DivClass )
	  oDiv.className = DivClass;
	else
	{
	  oDiv.style.border = '1px';
	  oDiv.style.borderColor = 'WindowFrame';
	  oDiv.style.borderStyle = 'solid';
	  oDiv.style.backgroundColor = 'Window';
	  oDiv.style.padding = '2px';
	}
	
	// Align the iFrame
	//oIFrame.style.left = c.x;
	//oIFrame.style.top = c.y + n;
	//oIFrame.style.display = 'none';
	//oIFrame.style.position = 'absolute';
	//oIFrame.style.zIndex = 999;
	
	// Set some default styles
	//oIFrame.style.borderStyle = 'none';
	//oIFrame.frameBorder = 0;
	//oIFrame.style.backgroundColor = 'Red';
	//this.IFrame = oIFrame;
}

AutoCompleteTextBox.prototype.DoAutoSuggest = false;

AutoCompleteTextBox.prototype.IsNavigating = false;

AutoCompleteTextBox.prototype.NavItem = -1;

AutoCompleteTextBox.prototype.ListItemClass = '';

AutoCompleteTextBox.prototype.ListItemHoverClass = '';

AutoCompleteTextBox.prototype.InputThreshold = 0;

// TextBox OnBlur
AutoCompleteTextBox.prototype.OnBlur = function()
{
	this.AutoCompleteTextBox.TextBox_Blur();
}

AutoCompleteTextBox.prototype.TextBox_Blur = function()
{
	this.Div.style.display='none';
	//this.IFrame.style.display='none';
}

// TextBox OnKeyUp
AutoCompleteTextBox.prototype.OnKeyUp = function(oEvent)
{
  //check for the proper location of the event object
  if (!oEvent) 
  {
    oEvent = window.event;
  }    
  this.AutoCompleteTextBox.TextBox_KeyUp(oEvent);      
}

// TextBox OnKeyDown
AutoCompleteTextBox.prototype.OnKeyDown = function(oEvent)
{
  //check for the proper location of the event object
  if (!oEvent) 
  {
    oEvent = window.event;
  }    
  this.AutoCompleteTextBox.TextBox_KeyDown(oEvent);      
}

AutoCompleteTextBox.prototype.TextBox_KeyDown = function(oEvent)
{
  var iKeyCode = oEvent.keyCode;

  if( iKeyCode == 9 || iKeyCode == 13)	// Tab and Enter
  {
    oEvent.keyCode = 9;
	this.SelectCurrentNavItem();
  }
}

AutoCompleteTextBox.prototype.TextBox_KeyUp = function(oEvent)
{
  var iKeyCode = oEvent.keyCode;

  if( iKeyCode == 8 )	// Backspace
  {
    this.Div.clearAttributes = '';
	  this.Div.style.display = 'none';
	  //this.IFrame.style.display='none';
  }

  else if( iKeyCode == 40)  // Down
  {
	  // Move navigtating position
    this.NavItem++;
    if (this.Div.childNodes.length == this.NavItem)
		this.NavItem = 0;

    // Get the item according to the navigating position
    var item = this.Div.childNodes[this.NavItem];
    
	  // Indicate to the control, that we are navigating
    this.IsNavigating = true;
    
    // Deselect all items
	  UnselectAllElements(this.Div);

    // Draw the control as selected
    HighlightElement(item);
   
    this.DoAutoSuggest = false;
    return;
  }
  else if( iKeyCode == 38)  // Up
  {
	  // Move navigtating position
    this.NavItem--;
    // Get the item according to the navigating position
    if (this.NavItem < 0)
		this.NavItem = this.Div.childNodes.length - 1;
    var item = this.Div.childNodes[this.NavItem];
	  // Indicate to the control, that we are navigating
    this.IsNavigating = true;
    // Deselect all items
	  UnselectAllElements(this.Div);
    // Draw the control as selected
    HighlightElement(item);
    
    this.DoAutoSuggest = false;
	  oEvent.cancelBubble=true;
    return;
  }
  else if (iKeyCode < 32 || (iKeyCode >= 33 && iKeyCode <= 46) || (iKeyCode >= 112 && iKeyCode <= 123)) 
  {
    return;
  }
  else
  {
    //this.DoAutoSuggest = true;
    this.IsNavigating = false;
    this.NavItem = -1;
  }
  
  if (!this.IsNavigating)
  {
	  var txt = this.TextBox.value;
	  
	  if( txt.length > 0 && txt.length >= this.InputThreshold)
	  {
	    this.Cbo.DoCallBack(this.TextBox.name, txt);
	  }
	  else
	  {
	   this.Div.clearAttributes;
		this.Div.style.display = 'none';
	   //this.IFrame.style.display='none';
	    this.Cbo.AbortCallBack();
	  }
  }
}

AutoCompleteTextBox.prototype.Cbo_Complete = function(responseText, responseXML,KeyStore)
{ 
	
  while ( this.Div.hasChildNodes() )
	  this.Div.removeChild(this.Div.firstChild);
			
	// get all the matching strings from the server response
	var aStr = responseText.split('\n');

	// add each string to the popup-div
	var i, n = aStr.length;
	
	if( n > 0 &  aStr[0].length > 0)
	{
	  for ( i = 0; i < n; i++ )
	  {
		  var oDiv = document.createElement('div');
        //var oKeyDiv = document.createElement('div');
		 
		
		  this.Div.appendChild(oDiv);
		  //this.Div.appendChild(oKeyDiv);
		  try
		  {
			  
			  var datakey = aStr[i].split('|')[2];
			  var datatext = aStr[i].split('|')[0];
			  var datadisplaytext = aStr[i].split('|')[0] + ' - ' + aStr[i].split('|')[1] + ' - ' + aStr[i].split('|')[2];
			
		    oDiv.innerHTML = datadisplaytext;
		//oKeyDiv.innerHTML = datakey;
		//oKeyDiv.style.visibility = 'hidden';
		//oKeyDiv.style.display = 'none';
		
			
			
		  }
		  catch(e)
		  {
		    this.Cbo_Error('405','Error','Text returned from Call Back was invalid');
		    return;
		  }
		  oDiv.noWrap       = true;
		  oDiv.style.width  = this.TextBox.offsetWidth - 6; // 6 = 2 * (padding + border)
		  if( this.ListItemClass.length > 0 )
			  oDiv.className = this.ListItemClass;
			else
			{
			  oDiv.style.backgroundColor = 'Window';
			  oDiv.style.color = 'WindowText';
			  oDiv.style.fontSize = 'x-small';
			  oDiv.style.fontFamily = 'Arial';
			}
		  oDiv.onmousedown  = AutoCompleteTextBox.prototype.Div_MouseDown;
		  oDiv.onmouseover  = AutoCompleteTextBox.prototype.Div_MouseOver;
		  oDiv.onmouseout   = AutoCompleteTextBox.prototype.Div_MouseOut;
		  
		  oDiv.AutoCompleteTextBox = this;			
	  }
	  this.Div.style.display = 'block';
	  //this.IFrame.style.display = 'block';
	  //this.IFrame.width = this.Div.offsetWidth;
	  //this.IFrame.height = this.Div.offsetHeight;
	  
	  if( this.DoAutoSuggest == true )
	    this.AutoSuggest( aStr );
	}
	else
	{
	  this.Div.innerHTML = '';
	  this.Div.style.display='none';
  	//this.IFrame.style.display='none';
	}
}

AutoCompleteTextBox.prototype.Cbo_Error = function(status, statusText, responseText)
{
  this.Div.style.display = 'block';
  //this.IFrame.style.display='block';

  this.Div.innerHTML = 'CallBackObject Error: status=' + status + '\nstatusText=' + statusText + '\n' + responseText;
}

AutoCompleteTextBox.prototype.Div_MouseDown = function()
{
		
		this.AutoCompleteTextBox.TextBox.value = this.innerHTML;
		//this.AutoCompleteTextBox.KeyStore.value = item.innerHTML;
		document.getElementById("KeyStore").value=this.innerHTML;
//		this.KeyStore.value=this.innerHTML;
//alert(this.innerHTML);
		document.Form.submit();
		
	//this.AutoCompleteTextBox.TextBox.value = this.innerHTML;

}

AutoCompleteTextBox.prototype.Div_MouseOver = function()
{
	HighlightElement(this);
}

AutoCompleteTextBox.prototype.Div_MouseOut = function()
{
	UnselectElement(this);
}

AutoCompleteTextBox.prototype.AutoSuggest = function(aSuggestions /*:array*/) 
{
  if (aSuggestions.length > 0) 
  {
    this.TypeAhead(aSuggestions[0]);
  }
}

AutoCompleteTextBox.prototype.TypeAhead = function( sSuggestion /*:string*/)
{
  if( this.TextBox.createTextRange || this.TextBox.setSelectionRange)
  {
    var iLen = this.TextBox.value.length; 
    this.TextBox.value = sSuggestion; 
    this.SelectRange(iLen, sSuggestion.length);
  }
}

AutoCompleteTextBox.prototype.SelectRange = function (iStart /*:int*/, iLength /*:int*/) 
{
  //use text ranges for Internet Explorer
  if (this.TextBox.createTextRange) 
  {
    var oRange = this.TextBox.createTextRange(); 
    oRange.moveStart("character", iStart); 
    oRange.moveEnd("character", iLength - this.TextBox.value.length);      
    oRange.select();
   
  //use setSelectionRange() for Mozilla
  } 
  else if (this.TextBox.setSelectionRange) 
  {
      this.TextBox.setSelectionRange(iStart, iLength);
  }     

  //set focus back to the textbox
  this.TextBox.focus();      
}

AutoCompleteTextBox.prototype.SelectCurrentNavItem = function()
{
  if (this.NavItem >= 0)
  {
		var item = this.Div.childNodes[this.NavItem];
		// Assign the selected text to the control
		
		var strdisplay = item.innerHTML.split("|")[2]
		
		this.TextBox.value = item.innerHTML;
		this.KeyStore.value = item.innerHTML;
//alert(this.KeyStore.value);
		document.Form.submit();
		
		// Hide the Div
		this.Div.clearAttributes = '';
		this.Div.style.display='none';
		//this.IFrame.style.display='none';
		this.NavItem = -1;
		var strkey = item.innerHTML.split("|");
		var oText;
		//AG - Change
		//alert(strkey[0]);
		//document.write(strkey[0]);
		return;
	}
}

function HighlightElement(item)
{
  if( item.AutoCompleteTextBox.ListItemHoverClass.length > 0 )
	  item.className = item.AutoCompleteTextBox.ListItemHoverClass;
	else
	{
	  item.style.backgroundColor = 'Highlight';
    item.style.color = 'HighlightText';
	  item.style.fontSize = 'x-small';
	  item.style.fontFamily = 'Arial';
	}
}

function UnselectElement(item)
{
  if( item.AutoCompleteTextBox.ListItemClass.length > 0 )
	  item.className = item.AutoCompleteTextBox.ListItemClass;
	else
	{
	  item.style.backgroundColor = 'Window';
	  item.style.color = 'WindowText';
	  item.style.fontSize = 'x-small';
	  item.style.fontFamily = 'Arial';
	}
}

function UnselectAllElements(div)
{
	for(var i = 0; i < div.childNodes.length; i++)
		UnselectElement(div.childNodes[i]);
}
             
function GetCoords(obj /*:object*/) 
{   
  var newObj = new Object();
  newObj.x = obj.offsetLeft;
  newObj.y = obj.offsetTop;
  theParent = obj.offsetParent;
  while(theParent != null)
  {
    newObj.y += theParent.offsetTop;
    newObj.x += theParent.offsetLeft;
    theParent = theParent.offsetParent;
  }
  
  return newObj;
}