Option Strict Off
Imports System
Imports System.Web.UI.WebControls
Imports Personify

Namespace Personify.DNN.Modules.CommunicationMethods

    Public MustInherit Class CommunicationMethods
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        Protected WithEvents lblNoCommunications As System.Web.UI.WebControls.Label

        Protected WithEvents imgAddNew As Image
        Protected WithEvents imgCheck As Image
        Protected WithEvents imgAddressBook As Image
        Protected WithEvents imgDoNotCall As Image

#Region "Properties"
        Public Property RepeatDirection() As String
            Get
                Return CType(Me.ViewState("_RepeatDirection"), String)
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_RepeatDirection") = Value
            End Set
        End Property
        Public Property RepeatColumns() As Integer
            Get
                Return CType(Me.ViewState("_RepeatColumns"), Integer)
            End Get
            Set(ByVal Value As Integer)
                Me.ViewState("_RepeatColumns") = Value
            End Set
        End Property
#End Region

#Region "Controls"
        'Protected WithEvents dlValicationIssues As System.Web.UI.WebControls.DataList
#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
               role = Me.GetUserRole(UserInfo)
                '3246-5774803
                LoadImages()
                'END 3246-5774803
                '3246-5880543
                If (Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin") And CStr(Settings("TemplateFile")) IsNot Nothing Then
                    'END 3246-5880543
                    LoadSettings()
                    If Not IsPostBack Then
                        BindCommunicationMethods()
                    Else

                    End If
                    'If Not Session("dlCommunicationsIndex") Is Nothing Then
                    'SetVisible(Session("dlCommunicationsType").ToString, CType(Session("dlCommunicationsIndex"), Integer))
                    'End If

                    'Add the URL for AddCommunication Method
                    hlAddCommunication.NavigateUrl = NavigateURL(TabId, "ADDCOM", "MODE=ADD", "ModuleId=" & ModuleId, "TemplateFile=" & CStr(Settings("TemplateFile")))
                Else
                    lblCommunicationMethods.Visible = False
                    imgAddNew.Visible = False
                    hlAddCommunication.Visible = False
                    xslCommunications.Visible = False
                    lblNoCommunications.Visible = False
                    tblLegend.Visible = False

                    DisplayUserAccessMessage(role)

                    '3246-5880543
                    If (CStr(Settings("TemplateFile")) = "") Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    End If
                    'End 3246-5880543
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Function IsApplicationCodeWebEnabled(ByVal Subsystem As String, ByVal Code As String, ByVal oAppCodeList As TIMSS.API.ApplicationInfo.IApplicationCodes) As Boolean

            Dim oAppCode As TIMSS.API.ApplicationInfo.IApplicationCode
            Dim bReturn As Boolean = False

            oAppCode = oAppCodeList.FindObject("Code", Code)

            If oAppCode IsNot Nothing Then
                If oAppCode.AvailableToWebFlag = True Then
                    bReturn = True
                End If
            End If

            Return bReturn
        End Function
        Private Function DF_GetCustomerCommunicationMethod(ByVal pMasterCustomerId As String, ByVal pSubCustomerId As Integer) As TIMSS.API.CustomerInfo.ICustomerCommunications

            Dim oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications
            Dim oWebEnabledCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications
            
            Dim oCommLocationCodes As TIMSS.API.ApplicationInfo.IApplicationCodes
            Dim oCommTypeCodes As TIMSS.API.ApplicationInfo.IApplicationCodes

            oCommLocationCodes = GetApplicationCodes("CUS", "COMM_LOCATION", True)
            oCommTypeCodes = GetApplicationCodes("CUS", "COMM_TYPE", True)

            'oCommLocationCodes = GetApplicationCodes(PortalId, "CUS", "COMM_LOCATION")
            'oCommTypeCodes = GetApplicationCodes(PortalId, "CUS", "COMM_TYPE")


            oCommunications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunications")

            oWebEnabledCommunications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunications")

            With oCommunications.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pMasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, pSubCustomerId)
                .Add("ActiveFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
            End With
           
            oCommunications.Sort("CommLocationCode")
            oCommunications.Fill()

            For Each oComm As TIMSS.API.CustomerInfo.ICustomerCommunication In oCommunications
                If IsApplicationCodeWebEnabled("CUS", oComm.CommTypeCode.Code, oCommTypeCodes) AndAlso IsApplicationCodeWebEnabled("CUS", oComm.CommLocationCode.Code, oCommLocationCodes) Then
                    oWebEnabledCommunications.Add(oComm)
                End If
                'End If
            Next

            Return oWebEnabledCommunications

        End Function


        Private Sub BindCommunicationMethods()
            Dim oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications

            oCommunications = DF_GetCustomerCommunicationMethod(MasterCustomerId, SubCustomerId)

            Dim rowcount As Integer = Convert.ToInt32((oCommunications.Count) / RepeatColumns + 0.5)
            Dim CommunicationMethods(rowcount - 1) As aRow

            For x As Integer = 0 To CommunicationMethods.Length - 1
                CommunicationMethods(x) = New aRow
                Dim row(RepeatColumns - 1) As aCommunicationMethod
                For y As Integer = 0 To RepeatColumns - 1
                    row(y) = New aCommunicationMethod

                    Dim index As Integer
                    If (RepeatDirection = "H") Then
                        index = x * RepeatColumns + y
                    Else
                        index = y * RepeatColumns + x
                    End If

                    If index < oCommunications.Count Then
                        With oCommunications(index)                        
                            row(y).ActiveFlag = .ActiveFlag
                            row(y).Comments = .Comments
                            row(y).CommLocationCode = .CommLocationCode.Description
                            row(y).CommTypeCode = .CommTypeCode.Description
                            row(y).ConcurrencyId = .ConcurrencyId
                            row(y).CountryCode = .CountryCode
                            row(y).FormattedPhoneAddress = .FormattedPhoneAddress
                            row(y).MasterCustomerId = .MasterCustomerId
                            row(y).PhoneAreaCode = .PhoneAreaCode
                            row(y).PhoneCountryCode = .PhoneCountryCode
                            row(y).PhoneExtension = .PhoneExtension
                            row(y).PhoneNumber = .PhoneNumber
                            row(y).PrimaryFlag = .PrimaryFlag
                            row(y).PublishFlag = .PublishFlag
                            row(y).SearchPhoneAddress = .SearchPhoneAddress
                            row(y).SubCustomerId = .SubCustomerId
                            row(y).DoNotCallFlag = .DoNotCallFlag
                            row(y).Edit = NavigateURL(TabId, "ADDCOM", "MODE=EDIT", "COMMTYPE=" & .CommTypeCodeString, "COMMLOCATION=" & .CommLocationCodeString, "ModuleId=" & ModuleId, "TemplateFile=" & CStr(Settings("TemplateFile")))
                        End With
                    End If
                Next
                CommunicationMethods(x).row = row
            Next


            xslCommunications.XSLfile = Server.MapPath(ModulePath + "/Templates/CommunicationMethodsTemplate.xsl")
            '7551613
            If oCommunications IsNot Nothing AndAlso oCommunications.Count > 0 Then
                xslCommunications.AddObject("", CommunicationMethods)
            End If
            '3246-5774803
            Dim PrimaryURL As String = GetPrimaryURL()
            xslCommunications.AddObject("PrimaryURL", PrimaryURL)
            Dim PublishURL As String = GetPublishURL()
            xslCommunications.AddObject("PublishURL", PublishURL)
            Dim DoNotCallURL As String = GetDoNotCallURL()
            xslCommunications.AddObject("DoNotCallURL", DoNotCallURL)
            'END 3246-5774803

            xslCommunications.AddObject("RepeatColumns", RepeatColumns)
            xslCommunications.Display()
            If oCommunications.Count = 0 Then
                lblNoCommunications.Visible = True
            End If

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        'Protected WithEvents dlCommunications As System.Web.UI.WebControls.DataList
        Protected WithEvents xslCommunications As WebControls.XslTemplate
        Protected WithEvents lblType As System.Web.UI.WebControls.Label
        Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents hlAddCommunication As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblCommunicationMethods As System.Web.UI.WebControls.Label
        Protected WithEvents IMG2 As System.Web.UI.HtmlControls.HtmlImage
        'Protected WithEvents lblLegendConfidential As System.Web.UI.WebControls.Label
        Protected WithEvents Image4 As System.Web.UI.WebControls.Image
        Protected WithEvents lblLegendPublished As System.Web.UI.WebControls.Label
        Protected WithEvents Image3 As System.Web.UI.WebControls.Image
        Protected WithEvents lblPrimary As System.Web.UI.WebControls.Label
        Protected WithEvents Image5 As System.Web.UI.WebControls.Image
        Protected WithEvents lblLegend As System.Web.UI.WebControls.Label
        Protected WithEvents tblLegend As System.Web.UI.HtmlControls.HtmlTable

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Helper Methods"
        Private Sub LoadSettings()
            If Not Settings("DisplayLegend") Is Nothing AndAlso Settings("DisplayLegend").ToString = "1" Then
                tblLegend.Visible = True
            Else
                tblLegend.Visible = False
            End If


            If Not Settings("Layout") Is Nothing Then
                If Settings("Layout").ToString = "H" Then
                    RepeatDirection = "H"
                ElseIf Settings("Layout").ToString = "H" Then
                    RepeatDirection = "V"
                End If
            Else
                'Default layout is vertical
                RepeatDirection = "V"
            End If
            If Not Settings("Columns") Is Nothing Then
                RepeatColumns = CType(Settings("Columns").ToString, Integer)
            Else
                'Default is one column
                RepeatColumns = 1
            End If
        End Sub
        Private Sub LoadImages()

            imgAddNew.ImageUrl = "~/" & SiteImagesFolder & "/addnew_11x11.gif"
            imgCheck.ImageUrl = "~/" & SiteImagesFolder & "/check.gif"
            imgAddressBook.ImageUrl = "~/" & SiteImagesFolder & "/addressbook_16x16.gif"
            imgDoNotCall.ImageUrl = "~/" & SiteImagesFolder & "/donotcall_16x16.gif"
        End Sub

        Private Function GetPrimaryURL() As String

            Return "~/" & SiteImagesFolder & "/check.gif"
        End Function
        Private Function GetPublishURL() As String

            Return "~/" & SiteImagesFolder & "/addressbook_16x16.gif"
        End Function
        Private Function GetDoNotCallURL() As String

            Return "~/" & SiteImagesFolder & "/donotcall_16x16.gif"
        End Function
        'END 3246-5774803
#End Region




        Public Class aCommunicationMethod

            Public MasterCustomerId As String
            Public SubCustomerId As Integer
            Public PrimaryFlag As Boolean
            Public ActiveFlag As Boolean
            Public FormattedPhoneAddress As String
            Public PhoneCountryCode As String
            Public PhoneAreaCode As String
            Public PhoneNumber As String
            Public PhoneExtension As String
            Public Comments As String
            Public SearchPhoneAddress As String
            Public CountryCode As String
            Public PublishFlag As Boolean
            Public ConcurrencyId As Long
            Public CommTypeCode As String
            Public CommLocationCode As String
            Public Edit As String
            Public DoNotCallFlag As Boolean
        End Class

        Public Class aRow
            Public row() As aCommunicationMethod
        End Class
    End Class

End Namespace
