Option Strict Off

Imports System
Imports System.Web.UI.WebControls
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports Personify.ApplicationManager.PersonifyEnumerations

Imports Personify

Namespace Personify.DNN.Modules.CommunicationMethods

    Public MustInherit Class EditCommunicationMethods
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IActionable
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable
        'Inherits System.Web.UI.UserControl

        Private option1 As String
        Private _EditCommTypeCode As String
        Private _EditCommLocationCode As String


        Dim _DisplaySaveButtons As Boolean
        Public Property DisplaySaveButtons() As Boolean
            Get
                Return _DisplaySaveButtons
            End Get
            Set(ByVal value As Boolean)
                _DisplaySaveButtons = value
            End Set
        End Property
#Region " Constants "
        Private Const C_DATATEXTFIELD As String = "Description"
        Private Const C_DATAVALUEFIELD As String = "Code"

#End Region
#Region "Controls"
        Protected WithEvents chkPrimary As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkPublish As System.Web.UI.WebControls.CheckBox

        Protected WithEvents lblComType As System.Web.UI.WebControls.Label
        Protected WithEvents lblCommTypeText As System.Web.UI.WebControls.Label

        Protected WithEvents ddlComType As WebControls.ApplicationCodeDropDownList
        'Protected WithEvents ddlComType1 As TIMSSCMS.WebControls.TCMSApplicationCodeDropDownList

        Protected WithEvents lblLocation As System.Web.UI.WebControls.Label
        Protected WithEvents lblLocationText As System.Web.UI.WebControls.Label
        Protected WithEvents ddlLocation As WebControls.ApplicationCodeDropDownList
        Protected WithEvents lblDisplayLocation As Label

        Protected WithEvents lblCountry As System.Web.UI.WebControls.Label
        'Protected WithEvents ddlCountry As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlCountry As WebControls.CountryDropDownList

        Protected WithEvents lblEmail As System.Web.UI.WebControls.Label
        Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents rfvEmail As System.Web.UI.WebControls.TextBox

        Protected WithEvents lblPhoneFax As System.Web.UI.WebControls.Label

        'Protected WithEvents lblPhoneCountryCode As System.Web.UI.WebControls.Label
        Protected WithEvents txtPhoneAreaCode As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPhoneNumber As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPhoneExt As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblExt As Label


        'Protected WithEvents lblPhoneCountry As System.Web.UI.WebControls.Label
        Protected WithEvents lblArea As System.Web.UI.WebControls.Label
        Protected WithEvents lblNumber As System.Web.UI.WebControls.Label

        Protected WithEvents btnSave As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancel As System.Web.UI.WebControls.Button

        Protected WithEvents oMessageControl As WebControls.MessageControl

        Protected WithEvents rwEmail As HtmlTableRow
        Protected WithEvents rwNumber As HtmlTableRow
        Protected WithEvents rwCountry As HtmlTableRow
        Protected WithEvents pnlPrimary As Panel

        Protected WithEvents lblPrimaryText As System.Web.UI.WebControls.Label
        Protected WithEvents lblPublishText As System.Web.UI.WebControls.Label

        Protected WithEvents imgPublished As System.Web.UI.WebControls.Image
        Protected WithEvents imgPrimary As System.Web.UI.WebControls.Image

        Protected WithEvents xslCommunicationMethods As WebControls.XslTemplate

#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

#End Region

#Region "Personify API Calls"

        Private Function DF_GetOption1ValueForCommunicationType(ByVal CommTypeCode As String) As String

            Dim oAppCode As TIMSS.API.ApplicationInfo.IApplicationCode

            oAppCode = TIMSS.API.CachedApplicationData.ApplicationDataCache.ApplicationCode("CUS", "COMM_TYPE", CommTypeCode)

            If oAppCode IsNot Nothing Then
                Return oAppCode.Option1
            Else
                Return "PHONE"
            End If

        End Function

        Private Function DF_GetSingleCustomerCommunicationMethod(ByVal PortalId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As String, _
                ByVal CommType As String, ByVal CommLocation As String) As TIMSS.API.CustomerInfo.ICustomerCommunications


            Dim oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications


            oCommunications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunications")
            With oCommunications.Filter
                .Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
                .Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
                .Add("CommTypeCode", CommType)
                .Add("CommLocationCode", CommLocation)

                .Add("ActiveFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
            End With
            oCommunications.Fill()

            Return oCommunications

        End Function

        Private Function DF_GetEmptyCustomerCommunicationsCollection() _
                                          As TIMSS.API.CustomerInfo.ICustomerCommunications

            Dim oCustomerCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications

            oCustomerCommunications = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerCommunications")
            oCustomerCommunications.AddNew()

            Return oCustomerCommunications

        End Function

        Private Function DF_GetCustomerPhoneStructures(ByVal PortalId As Integer, ByVal Country As String) As TIMSS.API.CustomerInfo.ICustomerPhoneStructures

            Dim oPhoneStructures As TIMSS.API.CustomerInfo.ICustomerPhoneStructures

            oPhoneStructures = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerPhoneStructures")
            oPhoneStructures.Filter.Add("CountryCode", TIMSS.Enumerations.QueryOperatorEnum.Equals, Country)
            oPhoneStructures.Filter.Add("AvailableFlag", TIMSS.Enumerations.QueryOperatorEnum.Equals, "Y")
            oPhoneStructures.Fill()


            Return oPhoneStructures

        End Function

        Private Function DF_AddCommunicationMethod(ByVal PortalId As Integer, _
            ByVal oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications, _
            Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.CustomerInfo.ICustomerCommunication


            Dim oclsGUID(0) As BusinessObjectGUIDStorage

            Dim bGUIDExists As Boolean = False

            
            'START 3246-6173710 - Incorrect session key for adding customer communication
            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifyAddCustomerCommunicationGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifyAddCustomerCommunicationGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(SessionKeys.PersonifyAddCustomerCommunicationGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "CustomerCommunication"
                    '.GUID = oCustomers(0).Guid
                End With

            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifyAddCustomerCommunicationGUIDKeys), BusinessObjectGUIDStorage())
            End If
            'END 3246-6173710 - Incorrect session key for adding customer communication

            With oCommunications(0)
                If bGUIDExists Then
                    .Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = .Guid
                End If

            End With
            AddSessionObject(SessionKeys.PersonifyAddCustomerCommunicationGUIDKeys, oclsGUID)

            oCommunications.Save()


            If oCommunications.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oCommunications.ValidationIssues, RespondedValidationIssues)

                oCommunications.Save()
            End If
            ' Clear the cached communication methods if no validation issues exist
            If oCommunications.ValidationIssues.ErrorCount = 0 Then
                'Remove the guids
                ClearSessionObject(SessionKeys.PersonifyAddCustomerCommunicationGUIDKeys)
            End If
            Return oCommunications(0)


        End Function


#End Region

#Region "Page Events"

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
            If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                If Not Page.IsPostBack Then 'Request("__EVENTTARGET").IndexOf("btnEditCommunication") > 0 Then
                    option1 = DF_GetOption1ValueForCommunicationType(_EditCommTypeCode)
                End If
            End If

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Me.IsPersonifyWebUserLoggedIn = False Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    'MBR Renewal Change Begin
                    'Added this to redirect if the user is not logged in
                    Dim strReturnURL As String = String.Format("returnUrl={0}", HttpUtility.UrlEncode(Request.RawUrl.ToString))
                    Response.Redirect(NavigateURL(PortalSettings.LoginTabId, "", strReturnURL), True)
                    'MBR Renewal Change End
                End If

                AddTemplate()

                If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                    _EditCommTypeCode = Request.QueryString("COMMTYPE").ToString.ToUpper
                    _EditCommLocationCode = Request.QueryString("COMMLOCATION").ToString.ToUpper
                End If
                If Not IsPostBack Then
                    If Not oMessageControl.ValidationIssues Is Nothing Then
                        oMessageControl.Clear()
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region


       


        Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
            'Save the record
            If SaveCommunicationMethod1() Then
                'MBR Renewal Change
                If Not String.IsNullOrEmpty(Request.QueryString("ReturnURL")) Then
                    Response.Redirect(HttpUtility.UrlDecode(Request.QueryString("ReturnURL")))
                Else
                    Response.Redirect(NavigateURL)
                End If
            End If
        End Sub

        Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If

            'MBR Renewal Change
            If Not String.IsNullOrEmpty(Request.QueryString("ReturnURL")) Then
                Response.Redirect(HttpUtility.UrlDecode(Request.QueryString("ReturnURL")))
            Else
                Response.Redirect(NavigateURL)
            End If
            'Response.Redirect(NavigateURL)

        End Sub
        Private Function SetPropertyInfo(ByVal Name As String) As TIMSS.API.Core.PropertyInfo

            Dim APIPropertyInfo As TIMSS.API.Core.PropertyInfo = New TIMSS.API.Core.PropertyInfo

            APIPropertyInfo.Name = Name
            APIPropertyInfo.PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup

            Return APIPropertyInfo
        End Function
        Private Function SaveCommunicationMethod1() As Boolean
            
            Try

                
                Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables

                If Request.QueryString("ModuleId") IsNot Nothing Then
                    globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
                Else
                    globalVariables.ModuleId = 0
                End If
                globalVariables.CustomerCommunication = "CustomerCommunication"

                If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then

                    Dim oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications

                    oCommunications = DF_GetSingleCustomerCommunicationMethod(PortalId, MasterCustomerId, SubCustomerId, Request.QueryString("COMMTYPE").ToString.ToUpper, Request.QueryString("COMMLOCATION").ToString.ToUpper)

                    'Get the Option1 Value for the Comm Type
                    '3246-6897226
                    option1 = DF_GetOption1ValueForCommunicationType(_EditCommTypeCode)

                    'If Request.QueryString("COMMTYPE").ToString.ToUpper = "EMAIL" Then
                    If option1 = "EMAIL" Or option1 = "WEB" Then
                        Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_FormattedPhoneAddress")
                        oCommunications(0).FormattedPhoneAddress = CType(ctl, TextBox).Text
                    Else
                        Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CountryCode")
                        If ctl IsNot Nothing Then
                            oCommunications(0).CountryCode = ""
                            oCommunications(0).CountryCode = CType(ctl, DropDownList).SelectedValue
                        Else
                            oCommunications(0).CountryCode = ""
                            oCommunications(0).CountryCode = GetDefaultCountryCodeForOrganization()
                        End If
                    End If


                    Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oCommunications(0))


                    For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                        '3246-5742903
                        '3246-6897226
                        'Commented this out. No need to set the FormattedPhoneAddress as it is already set if it EMAIL or WEB Type
                        'If pd.Name <> "CommTypeCode" And pd.Name <> "CommLocationCode" And pd.Name <> "CountryCode" And Not (pd.Name = "FormattedPhoneAddress" And Request.QueryString("COMMTYPE").ToString.ToUpper = "EMAIL") Then
                        '3246-6897226
                        If pd.Name <> "CommTypeCode" And pd.Name <> "CommLocationCode" And pd.Name <> "CountryCode" And pd.Name <> "FormattedPhoneAddress" Then
                            Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & pd.Name)
                            If ctl IsNot Nothing Then
                                If ctl.GetType Is GetType(DropDownList) Then
                                    'CType(oCommunications(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, DropDownList).SelectedValue)
                                    oCommunications(0).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, DropDownList).SelectedValue)
                                End If

                                If ctl.GetType Is GetType(TextBox) Then
                                    CType(oCommunications(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, TextBox).Text)
                                End If

                                If ctl.GetType Is GetType(CheckBox) Then
                                    CType(oCommunications(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, CheckBox).Checked)
                                End If
                            End If
                        End If
                    Next
                    Dim oCustomerCommunication As TIMSS.API.CustomerInfo.ICustomerCommunication = DF_AddCommunicationMethod(PortalId, oCommunications, oMessageControl.ValidationIssues)
                    If oCustomerCommunication.ValidationIssues IsNot Nothing AndAlso oCustomerCommunication.ValidationIssues.Count > 0 Then
                        'The save was not successfull
                        oMessageControl.Show(CType(oCustomerCommunication.ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                        Return False
                    End If

                Else

                    Dim oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications
                    oCommunications = DF_GetEmptyCustomerCommunicationsCollection()

                    oCommunications(0).MasterCustomerId = MasterCustomerId
                    oCommunications(0).SubCustomerId = SubCustomerId

                    Dim commType As String = String.Empty
                    commType = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CommTypeCode"), DropDownList).SelectedValue
                    oCommunications(0).CommTypeCode = oCommunications(0).CommTypeCode.List(commType).ToCodeObject
                    Dim commLocation As String = String.Empty
                    commLocation = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CommLocationCode"), DropDownList).SelectedValue
                    oCommunications(0).CommLocationCode = oCommunications(0).CommLocationCode.List(commLocation).ToCodeObject

                    'Get the Option1 Value for the Comm Type
                    '3246-6897226
                    option1 = DF_GetOption1ValueForCommunicationType(commType)

                    '3246-6897226 - Check the Option1 for Comm Type
                    If option1 = "EMAIL" Or option1 = "WEB" Then
                        'If commType = "EMAIL" Then
                        Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_FormattedPhoneAddress")
                        oCommunications(0).FormattedPhoneAddress = CType(ctl, TextBox).Text
                    Else
                        Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CountryCode")
                        If ctl IsNot Nothing Then
                            oCommunications(0).CountryCode = ""
                            oCommunications(0).CountryCode = CType(ctl, DropDownList).SelectedValue
                        Else
                            oCommunications(0).CountryCode = ""
                            oCommunications(0).CountryCode = GetDefaultCountryCodeForOrganization()
                        End If
                    End If

                    Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oCommunications(0))


                    For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                        '3246-6897226 - No need to set for FormattedPhoneAddress as it is already set for WEB and EMAIL type
                        If pd.Name <> "CommTypeCode" And pd.Name <> "CommLocationCode" And pd.Name <> "FormattedPhoneAddress" Then
                            Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & pd.Name)
                            If ctl IsNot Nothing Then
                                If ctl.GetType Is GetType(DropDownList) Then
                                    CType(oCommunications(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, DropDownList).SelectedValue)
                                End If
                                If ctl.GetType Is GetType(TextBox) Then
                                    CType(oCommunications(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, TextBox).Text)
                                End If
                                If ctl.GetType Is GetType(CheckBox) Then
                                    CType(oCommunications(0), TIMSS.API.Core.BusinessObject).SetPropertyValue(SetPropertyInfo(pd.Name), CType(ctl, CheckBox).Checked)
                                End If
                            End If
                        End If
                    Next

                    Dim oCustomerCommunication As TIMSS.API.CustomerInfo.ICustomerCommunication = DF_AddCommunicationMethod(PortalId, oCommunications, oMessageControl.ValidationIssues)
                    If oCustomerCommunication.ValidationIssues IsNot Nothing AndAlso oCustomerCommunication.ValidationIssues.ErrorCount > 0 Then
                        'The save was not successfull
                        oMessageControl.Show(CType(oCustomerCommunication.ValidationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                        Return False
                    End If
                End If

                    Return True

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
                Return False
            End Try

        End Function

        Private Sub CountrySelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

            If IsPostBack Then
                Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
                If Request.QueryString("ModuleId") IsNot Nothing Then
                    globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
                Else
                    globalVariables.ModuleId = 0
                End If
                globalVariables.CustomerCommunication = "CustomerCommunication"
                Dim ddlComType As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CommTypeCode"), DropDownList)

                SetCommunicationMaskForPhone(CType(sender, DropDownList).SelectedValue)
                SetVisibleBasedOnPhoneOrWeb(ddlComType.Text)
            End If

        End Sub

        Private Sub CommTypeSelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
            'sets the global variables used in template file for controls ID's
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            If Request.QueryString("ModuleId") IsNot Nothing Then
                globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
            Else
                globalVariables.ModuleId = 0
            End If
            globalVariables.CustomerCommunication = "CustomerCommunication"
            Dim ddlCountry As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CountryCode"), DropDownList)
            SetCommunicationMaskForPhone(ddlCountry.SelectedValue)
            SetVisibleBasedOnPhoneOrWeb(CType(sender, DropDownList).Text)
            If ddlCountry.SelectedValue.Length = 0 Then
                ddlCountry.SelectedValue = GetDefaultCountryCodeForOrganization()
            End If

        End Sub

        Private Sub SetVisibleBasedOnPhoneOrWeb(ByVal CommType As String)


            If CommType.Length = 0 Then
                Exit Sub
            End If
            Dim rwCountry As Control = FindControl("rwCountry")
            Dim rwNumber As Control = FindControl("rwNumber")
            Dim rwEmail As Control = FindControl("rwEmail")

            If CommType = "-1" Then
                rwEmail.Visible = False
                rwNumber.Visible = False
                rwCountry.Visible = False
                Exit Sub
            End If
            


            rwEmail.Visible = False
            rwNumber.Visible = False
            rwCountry.Visible = False
            option1 = DF_GetOption1ValueForCommunicationType(CommType)



            If option1 = "WEB" Then
                rwEmail.Visible = True
                'Show/Hide Do Not Call Flag
                ShowHideDoNotCall(False)
            ElseIf option1 = "PHONE" Then
                rwNumber.Visible = True
                rwCountry.Visible = True
                'Show/Hide Do Not Call Flag (Hide if it is E-Mail)
                ShowHideDoNotCall(True)
            End If

        End Sub
        'Show/Hide Do Not Call Flag (Hide if it is E-Mail)
        Private Sub ShowHideDoNotCall(ByVal Show As Boolean)
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            If Request.QueryString("ModuleId") IsNot Nothing Then
                globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
            Else
                globalVariables.ModuleId = 0
            End If
            globalVariables.CustomerCommunication = "CustomerCommunication"

            Dim pnlDoNotCall As Panel = CType(FindControl("pnlDoNotCall"), Panel)

            If Not pnlDoNotCall Is Nothing Then
                If Show Then
                    pnlDoNotCall.Visible = True
                Else
                    pnlDoNotCall.Visible = False
                End If
            End If
        End Sub

        Private Sub SetCommunicationMaskForPhone(ByVal CountryCode As String)

            Dim oPhoneStructures As TIMSS.API.CustomerInfo.ICustomerPhoneStructures
            Dim oPhoneStructure As TIMSS.API.CustomerInfo.ICustomerPhoneStructure
            If CountryCode.Length = 0 Then
                Exit Sub
            End If
            oPhoneStructures = DF_GetCustomerPhoneStructures(PortalId, CountryCode)

            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            If Request.QueryString("ModuleId") IsNot Nothing Then
                globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
            Else
                globalVariables.ModuleId = 0
            End If
            globalVariables.CustomerCommunication = "CustomerCommunication"
            Dim ddlCountry As DropDownList = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_CountryCode"), DropDownList)

            '3246-5742903
            Dim txtPhoneExt As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_PhoneExtension"), TextBox)
            Dim txtPhoneAreaCode As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_PhoneAreaCode"), TextBox)
            Dim txtPhoneNumber As TextBox = CType(FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_PhoneNumber"), TextBox)

            Dim lblExt As Label = CType(FindControl("lblExt"), Label)
            ' Reset the forms
            If Not txtPhoneExt Is Nothing Then
                txtPhoneExt.Visible = False
            End If
            If Not lblExt Is Nothing Then
                lblExt.Visible = False
            End If

            ddlCountry.Visible = True
            Dim lblCountry As Label = CType(FindControl("lblCountry"), Label)
            lblCountry.Visible = True
            Dim lblPhoneFax As Label = CType(FindControl("lblPhoneFax"), Label)
            lblPhoneFax.Visible = True

            Dim lblArea As Label = CType(FindControl("lblArea"), Label)
            Dim lblNumber As Label = CType(FindControl("lblNumber"), Label)

            If oPhoneStructures.Count > 0 Then
                For Each oPhoneStructure In oPhoneStructures
                    With oPhoneStructure
                        Select Case oPhoneStructure.FieldName
                            Case "PHONE_COUNTRY_CODE"

                            Case "PHONE_AREA_CODE"
                                txtPhoneAreaCode.Visible = True
                                lblArea.Visible = True
                                txtPhoneAreaCode.MaxLength = .MaxLength
                                lblNumber.Visible = True
                            Case "PHONE_NUMBER"
                                'strMask += " " & .Format
                                txtPhoneNumber.Visible = True
                                txtPhoneNumber.MaxLength = .MaxLength
                            Case "PHONE_EXTENSION"
                                txtPhoneExt.MaxLength = .MaxLength
                                txtPhoneExt.Visible = True
                                lblExt.Text = "(" & StrConv(.Prefix, VbStrConv.ProperCase) & ")"
                                lblExt.Visible = True
                        End Select
                    End With
                Next
            Else
                SetCommunicationMaskForPhone("[ALL]")
            End If

        End Sub


        Private Sub AddTemplate()
            '3246-5742903
            Dim SavePostBack As Boolean = False
            For Each key As String In Request.Params.AllKeys
                If key.IndexOf("btnSave") >= 0 Then
                    SavePostBack = True
                End If
            Next
            'sets the template file 
            If (Not (CType(Request.QueryString("TemplateFile"), String)) Is Nothing) Then
                xslCommunicationMethods.XSLfile = Server.MapPath(ModulePath + "Templates\" + CType(Request.QueryString("TemplateFile"), String))
            Else
                xslCommunicationMethods.XSLfile = Server.MapPath(ModulePath + "Templates\AddCommunicationMethodTemplate.xsl")
            End If

            'sets the global variables used in template file for controls ID's
            Dim globalVariables As XSLFileGlobalVariables = New XSLFileGlobalVariables
            If Request.QueryString("ModuleId") IsNot Nothing Then
                globalVariables.ModuleId = CInt(Request.QueryString("ModuleId"))
            Else
                globalVariables.ModuleId = 0
            End If
            globalVariables.CustomerCommunication = "CustomerCommunication"
            xslCommunicationMethods.AddObject("", globalVariables)

            xslCommunicationMethods.Display()

            '3246-5774803
            LoadPrimaryURL()
            LoadPublishURL()
            LoadDoNotCallURL()
            'END 3246-5774803

            Dim oCommunications As TIMSS.API.CustomerInfo.ICustomerCommunications = Nothing
            Dim showPrimary As Boolean = True
            If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                '3246-5742903
                If Not SavePostBack Then
                    oCommunications = DF_GetSingleCustomerCommunicationMethod(PortalId, MasterCustomerId, SubCustomerId, Request.QueryString("COMMTYPE").ToString.ToUpper, Request.QueryString("COMMLOCATION").ToString.ToUpper)

                    If oCommunications.Count > 0 Then
                        If oCommunications(0).PrimaryFlag = True Then
                            showPrimary = True
                        Else
                            showPrimary = False
                        End If

                        'START 3246-7686700  E-biz: Cannot change an existing phone/fax/email to primary
                        ''Dim pnlPrimary As Panel = CType(FindControl("pnlPrimary"), Panel)
                        ''If pnlPrimary IsNot Nothing Then
                        ''    If showPrimary Then
                        ''        pnlPrimary.Visible = True
                        ''    Else
                        ''        pnlPrimary.Visible = False
                        ''    End If
                        ''End If
                        'END 3246-7686700  E-biz: Cannot change an existing phone/fax/email to primary


                    End If

                    '5880516
                    SetCommunicationMaskForPhone(oCommunications(0).CountryCode)
                    'end 5880516


                End If

            End If

            Dim oCs As TIMSS.API.CustomerInfo.ICustomers
            oCs = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")

            Dim oC As TIMSS.API.CustomerInfo.ICustomer
            oC = oCs.AddNew()

            Dim oCommunication As TIMSS.API.CustomerInfo.ICustomerCommunication
            oCommunication = oC.Communications.AddNew()

            'get the properties of TIMSS.API.CustomerInfo.ICustomer type
            Dim cPropDesc As ComponentModel.PropertyDescriptorCollection = ComponentModel.TypeDescriptor.GetProperties(oCommunication)

            For Each pd As ComponentModel.PropertyDescriptor In cPropDesc
                Dim ctl As Control = FindControl("ctl_" & globalVariables.ModuleId & "_" & globalVariables.CustomerCommunication & "_" & pd.Name)
                'if a control for current property was found
                If ctl IsNot Nothing Then

                    If pd.Name = "CountryCode" Then
                        CType(ctl, DropDownList).DataTextField = "CountryDescription"
                        CType(ctl, DropDownList).DataValueField = "CountryCode"
                        CType(ctl, DropDownList).DataSource = TIMSS.API.CachedApplicationData.ApplicationDataCache.Countries
                        CType(ctl, DropDownList).DataBind()
                        CType(ctl, DropDownList).CssClass = "tmar_cucm_input"
                        CType(ctl, DropDownList).AutoPostBack = True
                        'set the default country
                        CType(ctl, DropDownList).SelectedValue = GetDefaultCountryCodeForOrganization()

                        'add handler to handle the dropdownlist index change 
                        'adjust the communication mask accordingly to the country selected
                        AddHandler CType(ctl, DropDownList).SelectedIndexChanged, AddressOf CountrySelectedIndexChanged

                    End If
                    'if property is of type Lookup - control will be a DropDownList
                    If oCommunication.Schema(pd.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                        'control is filled with the codes available for the current property


                        If pd.Name = "CommTypeCode" Then
                            If Request.QueryString("MODE").ToString.ToUpper() = "ADD" Then
                                CType(ctl, DropDownList).DataTextField = C_DATATEXTFIELD
                                CType(ctl, DropDownList).DataValueField = C_DATAVALUEFIELD
                                CType(ctl, DropDownList).DataSource = GetApplicationCodes("CUS", "COMM_TYPE", True)

                                CType(ctl, DropDownList).CssClass = "tmar_cucm_input"
                                CType(ctl, DropDownList).DataBind()
                                CType(ctl, DropDownList).AutoPostBack = True
                                AddHandler CType(ctl, DropDownList).SelectedIndexChanged, AddressOf CommTypeSelectedIndexChanged

                                Dim bAdd As Boolean = True
                                For Each l As ListItem In CType(ctl, DropDownList).Items
                                    If l.Value = "-1" Then
                                        bAdd = False
                                    End If
                                Next
                                If bAdd Then
                                    Dim oListItem As New ListItem
                                    oListItem.Text = "-- Select a Communication Type --"
                                    oListItem.Value = "-1"
                                    CType(ctl, DropDownList).Items.Insert(0, oListItem)
                                    oListItem = Nothing
                                End If

                            Else
                                ctl.Visible = False
                                ctl = FindControl("lblCommTypeText")
                                CType(ctl, Label).Visible = True
                            End If

                        ElseIf pd.Name = "CommLocationCode" Then
                            If Request.QueryString("MODE").ToString.ToUpper() = "EDIT" Then
                                ctl.Visible = False
                                ctl = FindControl("lblLocationText")
                                CType(ctl, Label).Visible = True
                            Else
                                Dim oCodes As TIMSS.API.Core.ICode
                                oCodes = CType(oC, TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oCommunication.Schema(pd.Name), TIMSS.API.Core.ICodePropertyInfo))
                                CType(ctl, DropDownList).DataTextField = C_DATATEXTFIELD
                                CType(ctl, DropDownList).DataValueField = C_DATAVALUEFIELD
                                CType(ctl, DropDownList).DataSource = GetApplicationCodes("CUS", "COMM_LOCATION", True)
                                CType(ctl, DropDownList).CssClass = "tmar_cucm_input"
                                CType(ctl, DropDownList).DataBind()
                            End If
                        Else
                            Dim oCodes As TIMSS.API.Core.ICode
                            oCodes = CType(oC, TIMSS.API.Core.BusinessObject).GetCodeInfo(CType(oCommunication.Schema(pd.Name), TIMSS.API.Core.ICodePropertyInfo))
                            CType(ctl, DropDownList).DataTextField = C_DATATEXTFIELD
                            CType(ctl, DropDownList).DataValueField = C_DATAVALUEFIELD
                            CType(ctl, DropDownList).DataSource = oCodes.List
                            CType(ctl, DropDownList).CssClass = "tmar_cucm_input"
                            CType(ctl, DropDownList).DataBind()
                        End If

                    End If

                    If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                        '3246-5742903
                        If Not SavePostBack Then
                            Dim value As String
                            If oCommunications(0).Schema(pd.Name).PropertyType = TIMSS.Enumerations.PropertyTypeEnum.Lookup Then
                                value = CType(CType(oCommunications(0), TIMSS.API.Core.BusinessObject).GetPropertyValue(pd.Name), TIMSS.API.Core.ICode).Code
                            Else
                                value = CType(oCommunications(0), TIMSS.API.Core.BusinessObject).GetPropertyValue(pd.Name)
                            End If
                            If pd.Name = "CommTypeCode" Then
                                ctl = FindControl("lblCommTypeText")
                                CType(ctl, Label).Visible = True
                                CType(ctl, Label).Text = value
                            End If
                            If pd.Name = "CommLocationCode" Then
                                ctl = FindControl("lblLocationText")
                                CType(ctl, Label).Visible = True
                                CType(ctl, Label).Text = value
                            End If


                            If ctl.GetType Is GetType(DropDownList) Then
                                CType(ctl, DropDownList).SelectedValue = value
                            End If
                            If ctl.GetType Is GetType(TextBox) Then
                                CType(ctl, TextBox).Text = value
                            End If
                            If ctl.GetType Is GetType(CheckBox) Then
                                CType(ctl, CheckBox).Checked = CBool(value)
                            End If
                        End If

                    End If

                End If

            Next

            Dim rwCountry As Control = FindControl("rwCountry")
            Dim rwNumber As Control = FindControl("rwNumber")
            Dim rwEmail As Control = FindControl("rwEmail")
            If Request.QueryString("MODE").ToString.ToUpper = "EDIT" Then
                If Request.QueryString("COMMTYPE").ToString.ToUpper = "EMAIL" OrElse _
                    Request.QueryString("COMMTYPE").ToString.ToUpper = "WEB" Then '3246-6409343 
                    If rwEmail IsNot Nothing Then
                        rwEmail.Visible = True
                    End If
                    If rwNumber IsNot Nothing Then
                        rwNumber.Visible = False
                    End If
                    If rwCountry IsNot Nothing Then
                        rwCountry.Visible = False
                    End If

                    'Hide/Show Do Not Call Flag
                    ShowHideDoNotCall(False)
                Else

                    If rwEmail IsNot Nothing Then
                        rwEmail.Visible = False
                    End If
                    If rwNumber IsNot Nothing Then
                        rwNumber.Visible = True
                    End If
                    If rwCountry IsNot Nothing Then
                        rwCountry.Visible = True
                    End If

                    'Hide/Show Do Not Call Flag
                    ShowHideDoNotCall(True)
                End If
            Else
                If rwEmail IsNot Nothing Then
                    rwEmail.Visible = False
                End If
                If rwNumber IsNot Nothing Then
                    rwNumber.Visible = False
                End If
                If rwCountry IsNot Nothing Then
                    rwCountry.Visible = False
                End If
            End If
        End Sub
        '3246-5774803
        Private Sub LoadPrimaryURL()

            Dim imgPrimary As Image
            If FindControl("imgPrimary") IsNot Nothing Then
                imgPrimary = CType(FindControl("imgPrimary"), Image)
                imgPrimary.ImageUrl = "~/" & SiteImagesFolder & "/check.gif"
            End If

        End Sub
        Private Sub LoadPublishURL()

            Dim imgPublished As Image
            If FindControl("imgPublished") IsNot Nothing Then
                imgPublished = CType(FindControl("imgPublished"), Image)
                imgPublished.ImageUrl = "~/" & SiteImagesFolder & "/addressbook_16x16.gif"
            End If
        End Sub
        'END 3246-5774803
        Private Sub LoadDoNotCallURL()

            Dim imgPublished As Image
            If FindControl("imgDoNotCall") IsNot Nothing Then
                imgPublished = CType(FindControl("imgDoNotCall"), Image)
                imgPublished.ImageUrl = "~/" & SiteImagesFolder & "/DoNotCall_16x16.gif"
            End If
        End Sub

        Public Class XSLFileGlobalVariables
            Public ModuleId As Integer
            Public CustomerCommunication As String
        End Class

    End Class

End Namespace
