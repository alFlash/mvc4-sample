
Namespace Personify.DNN.Modules.OrderSummary

    Public Class ModuleSettingsNames

        Public Const TemplateName As String = "TemplateName"
        Public Const ContinueShoppingUrl As String = "ContinueShoppingUrl"
        Public Const ContinueShoppingUrlType As String = "ContinueShoppingUrlType"

        Public Const GoToMyOrdersUrl As String = "GoToMyOrdersUrl"
        Public Const GoToMyOrdersUrlType As String = "GoToMyOrdersUrlType"

        Public Const DCDFilesDownloadUrl As String = "DCDFilesDownloadUrl"
        Public Const DCDFilesDownloadUrlType As String = "DCDFilesDownloadUrlType"

        Public Const DCDFilesGotoDownloadPage As String = "DCDFilesGotoDownloadPage"

        Public Const C_TEMPLATEFOLDERNAME As String = "Templates"
        Public Const C_FILEPATTERN As String = "*.?s*" '*.xsl

        Public Const C_PRINTRECIEPTOPTION As String = "PrintRecieptOption"
        Public Const C_SHOWHOTELRESERVATIONINPOPUP As String = "ShowHotelReservationInPopup"
    End Class

End Namespace
