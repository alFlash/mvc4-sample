Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.OrderSummary.Business

Namespace Personify.DNN.Modules.OrderSummary

    Public MustInherit Class OrderSummaryEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents cboSelectTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ctlContinueShoppingURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlGoToMyOrdersURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents ctlDCDFileDownloadURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblDCDFileDownloadURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkDCDFilesGotoDownloadPage As CheckBox
        Protected WithEvents cboSelectPrintRecieptOption As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkHotelReservationInPopup As CheckBox

        Protected WithEvents tblSelectShipping As HtmlTable
#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'Dim objCtlOrderSummary As New OrderSummaryController
                'Dim objOrderSummary As New OrderSummaryInfo

                '' Determine ItemId
                'If Not (Request.Params("ItemId") Is Nothing) Then
                '    itemId = Int32.Parse(Request.Params("ItemId"))
                'Else
                '    itemId = Null.NullInteger()
                'End If

                If Not Page.IsPostBack Then
                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")


                    'Load Templates
                    If Not cboSelectTemplate.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            cboSelectTemplate.Items.Add(li)
                        Next
                        'cboSelectTemplate.SelectedIndex = cboSelectTemplate.Items.IndexOf(cboSelectTemplate.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                        cboSelectTemplate.SelectedIndex = cboSelectTemplate.Items.IndexOf(cboSelectTemplate.Items.FindByValue(Convert.ToString(Settings(ModuleSettingsNames.TemplateName))))
                    End If

                    'Continue Shopping URL
                    ctlContinueShoppingURL.UrlType = CType(Settings(ModuleSettingsNames.ContinueShoppingUrlType), String)
                    ctlContinueShoppingURL.Url = CType(Settings(ModuleSettingsNames.ContinueShoppingUrl), String)

                    If Settings(ModuleSettingsNames.GoToMyOrdersUrl) IsNot Nothing Then
                        ctlGoToMyOrdersURL.Url = CType(Settings(ModuleSettingsNames.GoToMyOrdersUrl), String)
                    End If

                    If Settings(ModuleSettingsNames.GoToMyOrdersUrlType) IsNot Nothing Then
                        ctlGoToMyOrdersURL.UrlType = CType(Settings(ModuleSettingsNames.GoToMyOrdersUrlType), String)
                    End If

                    If Settings(ModuleSettingsNames.C_PRINTRECIEPTOPTION) IsNot Nothing Then
                        cboSelectPrintRecieptOption.SelectedValue = Convert.ToString(Settings(ModuleSettingsNames.C_PRINTRECIEPTOPTION))
                    Else
                        cboSelectPrintRecieptOption.SelectedValue = "INV"
                    End If

                    'DCD Files Download
                    If Settings(ModuleSettingsNames.DCDFilesGotoDownloadPage) IsNot Nothing Then
                        If CType(Settings(ModuleSettingsNames.DCDFilesGotoDownloadPage), String) = "Y" Then
                            chkDCDFilesGotoDownloadPage.Checked = True
                            ctlDCDFileDownloadURL.Visible = True
                            lblDCDFileDownloadURL.Visible = True
                        Else
                            chkDCDFilesGotoDownloadPage.Checked = False
                            ctlDCDFileDownloadURL.Visible = False
                            lblDCDFileDownloadURL.Visible = False
                        End If
                    Else
                        chkDCDFilesGotoDownloadPage.Checked = False
                        ctlDCDFileDownloadURL.Visible = False
                        lblDCDFileDownloadURL.Visible = False
                    End If

                    If Settings(ModuleSettingsNames.DCDFilesDownloadUrl) IsNot Nothing Then
                        ctlDCDFileDownloadURL.Url = CType(Settings(ModuleSettingsNames.DCDFilesDownloadUrl), String)
                    End If

                    If Settings(ModuleSettingsNames.DCDFilesDownloadUrlType) IsNot Nothing Then
                        ctlDCDFileDownloadURL.UrlType = CType(Settings(ModuleSettingsNames.DCDFilesDownloadUrlType), String)
                    End If

                    If Settings(ModuleSettingsNames.C_SHOWHOTELRESERVATIONINPOPUP) IsNot Nothing Then
                        chkHotelReservationInPopup.Checked = (CType(Settings(ModuleSettingsNames.C_SHOWHOTELRESERVATIONINPOPUP), String) = "Y")
                    Else
                        chkHotelReservationInPopup.Checked = False
                    End If
                    
                End If

                Dim oShipViaList As TIMSS.API.ApplicationInfo.IApplicationCodes
                oShipViaList = GetApplicationCodes("ORD", "SHIP_VIA", True)

                If oShipViaList.Count > 0 Then
                    For Each oShipVia As TIMSS.API.ApplicationInfo.IApplicationCode In oShipViaList
                        Dim tr As New HtmlTableRow

                        Dim tc1 As New HtmlTableCell
                        tc1.InnerHtml = oShipVia.Code & " URL:"
                        tr.Cells.Add(tc1)

                        Dim tc2 As New HtmlTableCell
                        Dim txtShipURL As New TextBox
                        With txtShipURL
                            .ID = "txtShipURL" & oShipVia.Code
                            .Width = Unit.Pixel(500)
                            .TextMode = TextBoxMode.MultiLine
                            .Rows = 3
                            If Settings(oShipVia.Code) IsNot Nothing Then
                                .Text = CStr(Settings(oShipVia.Code))
                            Else
                                .Text = "#TRN#"
                            End If

                        End With
                        tc2.Controls.Add(txtShipURL)
                        tr.Cells.Add(tc2)
                        tblSelectShipping.Rows.Add(tr)
                    Next
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Function GetTemplates() As ListItemCollection
            Try
                Dim lic As New ListItemCollection
                Dim ListItem As ListItem

                ' Create a reference to the current directory.
                Dim dInfo As New System.IO.DirectoryInfo(Me.MapPathSecure((ModulePath & ModuleSettingsNames.C_TEMPLATEFOLDERNAME)))
                ' Create an array representing the files in the current directory.
                Dim fInfo As System.IO.FileInfo() = dInfo.GetFiles(ModuleSettingsNames.C_FILEPATTERN)
                Dim fiTemp As System.IO.FileInfo
                For Each fiTemp In fInfo
                    ListItem = New ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    lic.Add(ListItem)
                Next fiTemp
                Return lic

            Catch ex As Exception
                Throw ex
            End Try
        End Function


        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    Dim objPersonify As New OrderSummaryInfo


                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    'Save Template
                    UpdateModuleSetting(ModuleSettingsNames.TemplateName, cboSelectTemplate.SelectedValue)

                    'Continue Shopping URL
                    UpdateModuleSetting(ModuleSettingsNames.ContinueShoppingUrl, ctlContinueShoppingURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.ContinueShoppingUrlType, ctlContinueShoppingURL.UrlType)

                    UpdateModuleSetting(ModuleSettingsNames.GoToMyOrdersUrl, ctlGoToMyOrdersURL.Url)
                    UpdateModuleSetting(ModuleSettingsNames.GoToMyOrdersUrlType, ctlGoToMyOrdersURL.UrlType)

                    UpdateModuleSetting(ModuleSettingsNames.C_PRINTRECIEPTOPTION, cboSelectPrintRecieptOption.SelectedValue)

                    'DCD Files Download URL
                    UpdateModuleSetting(ModuleSettingsNames.DCDFilesGotoDownloadPage, IIf(chkDCDFilesGotoDownloadPage.Checked, "Y", "N").ToString)
                    If ctlDCDFileDownloadURL IsNot Nothing Then
                        UpdateModuleSetting(ModuleSettingsNames.DCDFilesDownloadUrl, ctlDCDFileDownloadURL.Url)
                        UpdateModuleSetting(ModuleSettingsNames.DCDFilesDownloadUrlType, ctlDCDFileDownloadURL.UrlType)
                    End If

                    Dim oShipViaList As TIMSS.API.ApplicationInfo.IApplicationCodes
                    oShipViaList = GetApplicationCodes("ORD", "SHIP_VIA", True)

                    If oShipViaList.Count > 0 Then
                        For Each oShipVia As TIMSS.API.ApplicationInfo.IApplicationCode In oShipViaList
                            Dim txtURL As TextBox = CType(FindControl("txtShipURL" & oShipVia.Code), TextBox)
                           UpdateModuleSetting(oShipVia.Code, txtURL.Text)
                        Next

                    End If

                    UpdateModuleSetting(ModuleSettingsNames.C_SHOWHOTELRESERVATIONINPOPUP, IIf(chkHotelReservationInPopup.Checked, "Y", "N").ToString)

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                If Not Null.IsNull(itemId) Then
                    Dim objCtlOrderSummary As New OrderSummaryController
                    objCtlOrderSummary.Delete(itemId)
                End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub chkDCDFilesGotoDownloadPage_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDCDFilesGotoDownloadPage.CheckedChanged
            If chkDCDFilesGotoDownloadPage.Checked Then
                ctlDCDFileDownloadURL.Visible = True
                lblDCDFileDownloadURL.Visible = True
            Else
                ctlDCDFileDownloadURL.Visible = False
                lblDCDFileDownloadURL.Visible = False
            End If
        End Sub
    End Class

End Namespace
