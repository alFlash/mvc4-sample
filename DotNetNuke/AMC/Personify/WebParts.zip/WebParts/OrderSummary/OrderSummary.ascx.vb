Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Imports Personify.ApplicationManager
Imports Personify.ApplicationManager.PersonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects
Imports Personify.DNN.Modules.OrderSummary.Business


Namespace Personify.DNN.Modules.OrderSummary

    Public MustInherit Class OrderSummary
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable


#Region "Controls"

        Protected OrderSummaryTemplate As Personify.WebControls.XslTemplate
        Public WithEvents btnPrintInvoice As Button
        Protected WithEvents btnGoToMyOrders As Button
        Protected WithEvents btnContinueShopping As Button


#End Region

#Region "Private Variables"

        Dim OrderNumber As String
        Dim ReceiptNumber As String

        'Private _MasterCustomerId As String
        'Private _SubCustomerId As Integer

#End Region

#Region "Edit Setting Properties"
        Private ReadOnly Property EditSetting_TemplateFile() As String
            Get

                Dim strFileName As String = CType(Settings(ModuleSettingsNames.TemplateName), String)

                If Not strFileName Is Nothing AndAlso strFileName.Length = 0 Then
                    strFileName = "OrderSummary.xsl"
                End If
                'OrderPayments.xsl

                Return ModulePath + "Templates/" + strFileName
            End Get
        End Property

        Private ReadOnly Property EditSetting_ContinueURL() As String
            Get
                Return CType(Settings(ModuleSettingsNames.ContinueShoppingUrl), String)

            End Get
        End Property

        Private ReadOnly Property EditSetting_GoToMyOrdersURL() As String
            Get
                If Settings(ModuleSettingsNames.GoToMyOrdersUrl) IsNot Nothing Then
                    Return CType(Settings(ModuleSettingsNames.GoToMyOrdersUrl), String)
                Else
                    Return Nothing
                End If

            End Get
        End Property

        Private ReadOnly Property EditSetting_PrintRecieptOption() As String
            Get
                If Settings(ModuleSettingsNames.C_PRINTRECIEPTOPTION) IsNot Nothing Then
                    Return CType(Settings(ModuleSettingsNames.C_PRINTRECIEPTOPTION), String)
                Else
                    Return Nothing
                End If
            End Get
        End Property

        Private ReadOnly Property EditSetting_ShowHotelReservationInPopup() As Boolean
            Get
                Dim strShowHotelReservationInPopup As String
                strShowHotelReservationInPopup = ModuleSettingsNames.C_SHOWHOTELRESERVATIONINPOPUP
                If Settings(strShowHotelReservationInPopup) IsNot Nothing Then
                    Return (CType(Settings(strShowHotelReservationInPopup), String) = "Y")
                Else
                    Return False
                End If
            End Get
        End Property

#End Region

        Private Function IsOneClickDonation() As Boolean

            Dim bReturn As Boolean = False


            Try


                If Not String.IsNullOrEmpty(Request.QueryString("Mode")) Then
                    If TIMSS.Common.Encryption.Decrypt(Request.QueryString("Mode")) = "Anonymous" Then
                        bReturn = True
                    End If
                End If
            Catch ex As Exception

            End Try


            Return bReturn

        End Function

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                'If Session("tt") IsNot Nothing AndAlso CStr(Session("tt")) = "1" Then

                '    Dim t As ApplicationManager.DCDDownload = New DCDDownload
                '    t.FileId = 4
                '    t.ECDProductId = 336
                '    t.FileName = "ECD_MED_1.doc"
                '    t.DownloadFile("")
                '    Response.End()
                '    Session("tt") = Nothing
                '    Exit Sub
                'End If



                Dim role As String

                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Or IsOneClickDonation() Then


                    If Me.IsPersonifyWebUserLoggedIn = False And IsOneClickDonation() = False Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        btnContinueShopping.Visible = False
                        btnGoToMyOrders.Visible = False
                        Exit Sub

                    End If

                    If EditSetting_ContinueURL Is Nothing Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        btnContinueShopping.Visible = False
                        btnGoToMyOrders.Visible = False
                        btnPrintInvoice.Visible = False
                        Exit Sub
                    End If

                    If EditSetting_GoToMyOrdersURL Is Nothing Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        btnContinueShopping.Visible = False
                        btnGoToMyOrders.Visible = False
                        btnPrintInvoice.Visible = False
                        Exit Sub
                    End If

                    If EditSetting_PrintRecieptOption Is Nothing Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                        btnContinueShopping.Visible = False
                        btnGoToMyOrders.Visible = False
                        btnPrintInvoice.Visible = False
                        Exit Sub
                    End If




                    'Set the order number from query string





                    If Request.QueryString("ORDERNUMBER") IsNot Nothing Then
                        OrderNumber = XSS_HTMLEncode(Request.QueryString("ORDERNUMBER"))
                        btnContinueShopping.PostBackUrl = NavigateURL(Convert.ToInt32(Settings(EditSetting_ContinueURL)))
                        'btnGoToMyOrders.PostBackUrl = NavigateURL(Convert.ToInt32(EditSetting_GoToMyOrdersURL))

                        '3246-5727084 START Invoice cannot be printed
                        Dim strInvoiceURL As String = ""
                        Dim _clsReports As New Reporting(OrganizationId, OrganizationUnitId)



                        If IsPostBack Then
                            If Request("__EVENTTARGET").IndexOf("lbtnHotelReservation_") > 0 Then
                                Dim strEventTarget As String = Request("__EVENTTARGET")
                                Dim str As String() = strEventTarget.Split("_")
                                If str.Length = 3 Then
                                    LinkToHotelBlockingReservation(str(1), str(2))
                                End If
                            End If
                            If CheckIfPostbackByButton("btnPrintInvoice") Then
                                '3246-5727084 START Invoice cannot be printed
                                If EditSetting_PrintRecieptOption = "ACK" Then
                                    strInvoiceURL = _clsReports.GetOrderAcknowledgementURL(PortalId, OrderNumber)
                                Else
                                    strInvoiceURL = _clsReports.GetOrderInvoiceURL(PortalId, OrderNumber)
                                End If
                                _clsReports = Nothing

                                'If strInvoiceURL.Length > 0 Then
                                '    btnPrintInvoice.PostBackUrl = strInvoiceURL
                                'End If

                                If strInvoiceURL.Length = 0 Then
                                    If EditSetting_PrintRecieptOption = "ACK" Then
                                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RecieptAcknowledgementNotAvailable", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                    Else
                                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvoiceNotAvailable", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                    End If
                                Else
                                    If IsValidUrl(strInvoiceURL) Then
                                        OpenReportInNewWindow(strInvoiceURL)
                                    End If
                                    ' btnPrintInvoice.PostBackUrl = strInvoiceURL

                                End If
                            End If
                        End If
                        '3246-5727084 END Invoice cannot be printed

                        LoadWebPartTemplate(False)
                    ElseIf Request.QueryString("RECEIPT") IsNot Nothing Then
                        ReceiptNumber = XSS_HTMLEncode(Request.QueryString("RECEIPT"))
                        'btnContinueShopping.PostBackUrl = NavigateURL(Convert.ToInt32(EditSetting_ContinueURL))
                        'btnGoToMyOrders.PostBackUrl = NavigateURL(Convert.ToInt32(EditSetting_GoToMyOrdersURL))
                        LoadWebPartTemplate(True)
                        'only for orders
                        btnPrintInvoice.Visible = False
                    Else
                        'Display message that NO ORDER NUMBER
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingOrderNoMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        btnContinueShopping.Visible = False
                        btnGoToMyOrders.Visible = False
                        'only for orders
                        btnPrintInvoice.Visible = False
                    End If
                Else
                    btnContinueShopping.Visible = False
                    btnGoToMyOrders.Visible = False
                    btnPrintInvoice.Visible = False
                    DisplayUserAccessMessage(role)
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LinkToHotelBlockingReservation(ByVal OrderNumber As String, ByVal OrderLineNumber As String)
            Dim strReservationUrl As String = String.Empty
            Dim oOrderDetails As TIMSS.API.OrderInfo.IOrderDetails
            oOrderDetails = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetails")

            oOrderDetails.Fill(OrderNumber, CType(OrderLineNumber, Integer))
            If oOrderDetails.Count = 1 Then
                Dim GotoLink As Boolean = True
                If oOrderDetails(0).CanCreateHotelReservationBridge Then
                    If Not oOrderDetails(0).CreateHotelReservationBridgeForShipCustomer() Then
                        GotoLink = False
                    End If
                End If
                If GotoLink Then
                    strReservationUrl = GetHotelReservationURL(oOrderDetails(0))
                    If Not String.IsNullOrEmpty(strReservationUrl) Then
                        If EditSetting_ShowHotelReservationInPopup Then
                            If strReservationUrl.Contains("'") Then
                                strReservationUrl = strReservationUrl.Replace("'", "\'")
                            End If
                            Response.Write("<script>")
                            Response.Write(String.Format("window.open('{0}','_blank')", strReservationUrl))
                            Response.Write("</script>")
                        Else
                            Response.Redirect(strReservationUrl)
                        End If
                    End If
                End If
            End If
        End Sub

        Private Function GetHotelReservationURL(ByVal OrderDetail As TIMSS.API.OrderInfo.IOrderDetail) As String
            Dim oOrderDetailHotelNew As TIMSS.API.OrderInfo.IOrderDetailHotel = Nothing
            Dim oOrderDetailHotelModified As TIMSS.API.OrderInfo.IOrderDetailHotel = Nothing
            Dim strUrl As String = String.Empty
            Dim strNewUrl As String = String.Empty
            OrderDetail.OrderDetailHotels.Fill(False, True)
            If OrderDetail.OrderDetailHotels.Count = 1 Then
                strUrl = OrderDetail.OrderDetailHotels(0).HotelReservationURL
            ElseIf OrderDetail.OrderDetailHotels.Count > 1 Then
                oOrderDetailHotelNew = OrderDetail.OrderDetailHotels.FindObject("HotelReservationStatus", "New")
                oOrderDetailHotelModified = OrderDetail.OrderDetailHotels.FindObject("HotelReservationStatus", "Modified")
                If oOrderDetailHotelNew IsNot Nothing Then
                    strUrl = oOrderDetailHotelNew.HotelReservationURL
                ElseIf oOrderDetailHotelModified IsNot Nothing Then
                    strUrl = oOrderDetailHotelModified.HotelReservationURL
                Else
                    strNewUrl = GetNewBridgeUrl(OrderDetail)
                    If Not String.IsNullOrEmpty(strNewUrl) Then
                        strUrl = strNewUrl
                    End If
                End If
            End If
            Return strUrl
        End Function

        Private Function GetNewBridgeUrl(ByVal OrderDetail As TIMSS.API.OrderInfo.IOrderDetail) As String
            Dim strUrl As String = String.Empty
            For Each oOrderDetailHotel As TIMSS.API.OrderInfo.IOrderDetailHotel In OrderDetail.OrderDetailHotels
                If String.IsNullOrEmpty(oOrderDetailHotel.HotelReservationStatus) AndAlso _
                    String.IsNullOrEmpty(oOrderDetailHotel.HotelReservationId) Then
                    strUrl = oOrderDetailHotel.HotelReservationURL
                End If
            Next
            Return strUrl
        End Function

        Function IsValidUrl(ByVal url As String) As Boolean
            Return System.Text.RegularExpressions.Regex.IsMatch(url, _
                "(http|ftp|https)://([\w-]+\.)+(/[\w- ./?%&=]*)?")
        End Function

        Private Sub OpenReportInNewWindow(ByVal ValidUrl As String)
            Try
                Dim intIndex As Integer = ValidUrl.IndexOf("?")
                Dim strUrlMain As String = ValidUrl.Substring(0, intIndex)
                Dim strUrlComponent As String = ValidUrl.Substring(intIndex, ValidUrl.Length - intIndex)
                If strUrlComponent.Contains("\") OrElse strUrlComponent.Contains("/") Then
                    strUrlComponent = strUrlComponent.Replace("\", "%5C")
                    strUrlComponent = strUrlComponent.Replace("/", "%5C")
                End If
                strUrlMain = strUrlMain & strUrlComponent
                Response.Write(String.Concat("<script type='text/javascript'>windObj = window.open('" + strUrlMain + "');</script>"))
            Catch
                If EditSetting_PrintRecieptOption = "ACK" Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RecieptAcknowledgementNotAvailable", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvoiceNotAvailable", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If
            End Try
        End Sub

        Private Function CheckIfPostbackByButton(ByVal ButtonName As String) As Boolean

            'Dim strControlName As String = "btnUpdateCart_" + ModuleId.ToString

            'strControlName = ButtonName + "_" + ModuleId.ToString
            Dim bReturn As Boolean = False

            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(ButtonName) > 0 Then
                    bReturn = True
                    Exit For
                End If

            Next

            Return bReturn

        End Function

        Private Sub btnGoToMyOrders_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGoToMyOrders.Click
            Try
                Response.Redirect(NavigateURL(Convert.ToInt32(EditSetting_GoToMyOrdersURL)), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub btnContinueShopping_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinueShopping.Click
            Try
                Response.Redirect(NavigateURL(Convert.ToInt32(EditSetting_ContinueURL)), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub



        Public Sub LoadWebPartTemplate(ByVal withReceipt As Boolean)


            OrderSummaryTemplate.Visible = True
            OrderSummaryTemplate.XSLfile = Server.MapPath(EditSetting_TemplateFile)

            OrderSummaryTemplate.AddObject("ModuleId", ModuleId)

            Dim oODClass() As OrderDetails = Nothing
            Dim oOrderTotals() As OrderTotals = Nothing
            Dim oBillToShipToAddress() As BillToShipToAddress = Nothing
            Dim oOrderReceiptDetails() As OrderReceiptDetails = Nothing
            Dim oShippingDetails() As ShippingDetails = Nothing


            Dim oEntireOrderSummary As EntireOrderSummary
            If withReceipt = False Then
                oEntireOrderSummary = New EntireOrderSummary(OrganizationId, OrganizationUnitId, (OrderNumber), True, Me.BaseCurrency, Me.PortalCurrency, FetchOnDemand)
            Else
                oEntireOrderSummary = New EntireOrderSummary(OrganizationId, OrganizationUnitId, CInt(ReceiptNumber), Me.BaseCurrency, Me.PortalCurrency, FetchOnDemand)
            End If

            If (Not (oEntireOrderSummary.BillToShipToAddress(0).BillMasterCustomerId.ToLower = Me.MasterCustomerId.ToLower AndAlso _
                           oEntireOrderSummary.BillToShipToAddress(0).BillSubCustomerId = Me.SubCustomerId.ToString) AndAlso _
                           Not (oEntireOrderSummary.OrderDetails(0).ShipMasterCustomerId.ToLower = Me.MasterCustomerId.ToLower AndAlso _
                           oEntireOrderSummary.OrderDetails(0).ShipSubCustomerId = Me.SubCustomerId.ToString) AndAlso (Not IsOneClickDonation())) And (Not IsManagingSegment()) Then
                'Does not belong to bill or ship to customer ids

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Unauthorized.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else



                oODClass = oEntireOrderSummary.OrderDetails
                oOrderTotals = oEntireOrderSummary.OrderTotals
                oBillToShipToAddress = oEntireOrderSummary.BillToShipToAddress
                oOrderReceiptDetails = oEntireOrderSummary.OrderReceiptDetails
                oShippingDetails = oEntireOrderSummary.LoadClassShippingDetails(Nothing)

                oBillToShipToAddress = oEntireOrderSummary.BillToShipToAddress
                If oEntireOrderSummary IsNot Nothing Then

                    If oODClass Is Nothing OrElse oODClass.Length = 0 Then
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoSummaryToShow", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        btnContinueShopping.Visible = False
                        Exit Sub
                    End If
                    If oShippingDetails IsNot Nothing AndAlso oShippingDetails.Length > 0 Then
                        Dim oShippingCompanies(oShippingDetails.Length - 1) As ShippingCompany
                        Dim i As Integer = 0
                        For Each oShippingDetail As ShippingDetails In oShippingDetails
                            oShippingCompanies(i) = New ShippingCompany
                            With oShippingCompanies(i)
                                .ShipViaCode = oShippingDetail.ShipViaCode
                                If Settings(oShippingDetail.ShipViaCode) IsNot Nothing Then
                                    .ShipViaURL = CStr(Settings(oShippingDetail.ShipViaCode))
                                    If .ShipViaURL.IndexOf("#TRN#") < 0 Then
                                        .ShipViaURL = String.Empty
                                    End If
                                Else
                                    '.ShipViaURL = "http://www.fedex.com/Tracking=#TRN#"
                                End If
                            End With
                            i = i + 1
                        Next

                        OrderSummaryTemplate.AddObject("", oShippingCompanies)
                    End If

                    OrderSummaryTemplate.AddObject("", oODClass)
                    OrderSummaryTemplate.AddObject("", oOrderTotals)
                    OrderSummaryTemplate.AddObject("", oBillToShipToAddress)
                    OrderSummaryTemplate.AddObject("", oOrderReceiptDetails)
                    OrderSummaryTemplate.AddObject("ModuleId", ModuleId)

                    OrderSummaryTemplate.Display()

                    For Each oOrderDetail As OrderDetails In oODClass
                        If oOrderDetail.Subsystem = "ECD" Then
                            For Each oDCDFile As DCDFileList In oOrderDetail.DCDFiles
                                If oDCDFile IsNot Nothing Then
                                    Dim btnDownloadDCDFile As Button = CType(FindControl(String.Concat("btnDownload_", ModuleId.ToString, "_", oOrderDetail.OrderLineNumber.ToString, "_", oDCDFile.FileId.ToString)), Button)

                                    If btnDownloadDCDFile IsNot Nothing Then
                                        AddHandler btnDownloadDCDFile.Command, AddressOf DoDownload
                                    End If
                                End If
                            Next
                        End If
                    Next
                Else
                    'TODO - Show MEssage that invalid ORder Is Selected
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoSummaryToShow", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    btnContinueShopping.Visible = False
                End If
            End If
        End Sub
#End Region

#Region "Helper function"

        Private Sub DoDownload(ByVal sender As Object, ByVal e As CommandEventArgs)
            Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))

            Dim DCDParameters As DCDDownloadParameters = New DCDDownloadParameters
            With DCDParameters
                .OrderNumber = CommandArgumentInfo(0)
                .OrderLine = CInt(CommandArgumentInfo(1))
                .FileId = CInt(CommandArgumentInfo(2))
            End With

            If Settings(ModuleSettingsNames.DCDFilesGotoDownloadPage) IsNot Nothing Then
                If CBool(IIf(CType(Settings(ModuleSettingsNames.DCDFilesGotoDownloadPage), String) = "Y", True, False)) Then

                    'Redirect to another page to process download
                    Response.Redirect(String.Concat("~/Default.aspx?tabid=", CType(Settings(ModuleSettingsNames.DCDFilesDownloadUrl), String), "&OrderNo=", TIMSSURLEncryption(DCDParameters.OrderNumber), "&OrderLine=", DCDParameters.OrderLine, "&FileId=", DCDParameters.FileId))
                Else
                    'process download directly on this page
                    DownloadDCDFile(DCDParameters)
                End If
            Else
                'process download directly on this page
                DownloadDCDFile(DCDParameters)
            End If
        End Sub

        Private Function TIMSSURLEncryption(ByVal value As String, Optional ByVal decrypt As Boolean = False) As String
            Dim result As String = ""

            If Not decrypt Then
                result = TIMSS.Common.Encryption.Encrypt(value)
                result = Replace(Server.UrlEncode(result), "", "+")
            Else
                result = TIMSS.Common.Encryption.Decrypt(value)
            End If

            Return result
        End Function


        Private Function GetExpireFileDate(ByVal oDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo) As String
            Dim maxDate As Date
            With oDCDInfo.DCDFileDetails(0)
                If .AllowedTimeToDownload > 0 Then
                    Dim orderDate As Date = oDCDInfo.OrderDetail.OrderDate
                    If .TimeToDownloadUnitCodeString.ToUpper = "DAY" Then
                        maxDate = orderDate.AddDays(.AllowedTimeToDownload)
                    ElseIf .TimeToDownloadUnitCodeString.ToUpper = "MONTH" Then
                        maxDate = orderDate.AddMonths(.AllowedTimeToDownload)
                    ElseIf .TimeToDownloadUnitCodeString.ToUpper = "YEAR" Then
                        maxDate = orderDate.AddYears(.AllowedTimeToDownload)
                    Else
                        'default to day if it's not set
                        maxDate = orderDate.AddDays(.AllowedTimeToDownload)
                    End If
                    Return maxDate.ToShortDateString
                End If
            End With

            Return ""

        End Function

        Private Function IsProductFileAvailable(ByVal oDCDInfo As TIMSS.API.OrderInfo.IOrderDetailECDInfo) As Boolean
            Dim result As Boolean = True

            'check valid date for DCD product
            'download count
            'product is not web_enable
            With oDCDInfo.DCDFileDetails(0)

                If .LimitedDownloadsFlag Then
                    If (.DownloadsAllowed - oDCDInfo.DownloadCount) <= 0 Then
                        Return False
                    End If
                End If
                If .AllowedTimeToDownload > 0 Then
                    'if greater than 0 - must check if allow time is valid
                    Dim expireDate As String = GetExpireFileDate(oDCDInfo)
                    If expireDate <> "" Then
                        Dim maxDate As Date = CDate(expireDate)
                        If maxDate < Today Then
                            Return False
                        End If
                    End If

                ElseIf Not isDateWithinRange(.ValidFrom, .ValidTo) Then
                    Return False
                End If

                If Not (oDCDInfo.OrderDetail.OrderMaster.BillMasterCustomerId = Me.MasterCustomerId AndAlso _
                    oDCDInfo.OrderDetail.OrderMaster.BillSubCustomerId = Me.SubCustomerId) AndAlso _
                    Not (oDCDInfo.OrderDetail.OrderMaster.ShipMasterCustomerId = Me.MasterCustomerId AndAlso _
                    oDCDInfo.OrderDetail.OrderMaster.ShipSubCustomerId = Me.SubCustomerId) Then
                    'Does not belong to bill or ship to customer ids
                    Return False
                End If

            End With

            Return result
        End Function


        Private Function DownloadDCDFile(ByVal downloadParameters As DCDDownloadParameters) As Boolean

            Dim isFileDownloaded As Boolean
            Dim oStartFileTime As Date

            'need to get document title 
            Dim oDCDInfoList As TIMSS.API.OrderInfo.IOrderDetailECDInfoList
            oDCDInfoList = GetOrderDetailDCDInfoList(downloadParameters.OrderNumber, downloadParameters.OrderLine, downloadParameters.FileId)

            If Not IsProductFileAvailable(oDCDInfoList(0)) Then
                Me.DisplayErrorMessage(Localization.GetString("DCDProductInvalid", Me.LocalResourceFile))
                Return False
            End If

            Dim oDownload As New DCDDownload
            Dim oDownloadLog As New DCDDownloadLog

            With oDownload
                .FileName = oDCDInfoList(0).DCDFileDetails(0).FileName
                .FileId = CInt(downloadParameters.FileId)
                .ECDProductId = oDCDInfoList(0).DCDFileDetails(0).ProductId
                .ImpersonateUser = False
            End With



            oStartFileTime = Date.Now

            isFileDownloaded = oDownload.DownloadFile("")

            If isFileDownloaded Then

                With oDownloadLog
                    .FileSize = oDownload.FileSize
                    .StartTime = oStartFileTime
                    .RemoteIP = oDownload.UserIPAddress
                    .EndTime = Date.Now
                    .OrderNo = downloadParameters.OrderNumber
                    .OrderLine = downloadParameters.OrderLine
                    .FileId = downloadParameters.FileId
                    .FileToSend = downloadParameters.FileName
                    .DocumentTitle = oDCDInfoList(0).DCDFileDetails(0).DocumentTitle
                    .FileToSend = oDCDInfoList(0).DCDFileDetails(0).FileName
                    .MasterCustomerId = MasterCustomerId
                    .SubCustomerId = SubCustomerId
                    .ProductId = oDCDInfoList(0).DCDFileDetails(0).ProductId
                    'to do: more columns to assign
                End With

                If oDCDInfoList IsNot Nothing AndAlso oDCDInfoList.Count > 0 Then
                    oDCDInfoList(0).DownloadCount += 1
                    oDCDInfoList.Save()
                End If
                SaveDCDSENDLog(oDownloadLog) 'Create DCD log
                Me.DisplayErrorMessage(Localization.GetString("DCDProductError", Me.LocalResourceFile))
                Response.End()
            Else
                'file is not download
                Me.DisplayErrorMessage(Localization.GetString("DCDProductError", Me.LocalResourceFile))
            End If


        End Function

        Private Sub DisplayErrorMessage(ByVal message As String)
            Skins.Skin.AddModuleMessage(Me, message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError) '3246-6116989
        End Sub

        Private Sub DisplayMessage(ByVal message As String)
            Skins.Skin.AddModuleMessage(Me, message, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning) '3246-6116989
        End Sub


        Private Function IsManagingSegment() As Boolean
            If AffiliateManagementSessionHelper.IsManagingSegment(PortalId) Then
                Return True
            Else
                Return False
            End If
        End Function


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


        Public Class ShippingCompany
            Public ShipViaURL As String
            Public ShipViaCode As String
        End Class

#Region "Personify Data"

        Private Function GetOrderDetailDCDInfoList(ByVal OrderNumber As String, ByVal OrderLine As Integer, ByVal FileId As Integer) As TIMSS.API.OrderInfo.IOrderDetailECDInfoList

            Dim oDCDInfoList As TIMSS.API.OrderInfo.IOrderDetailECDInfoList
            oDCDInfoList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetailECDInfoList")
            oDCDInfoList.Fill(OrderNumber, OrderLine, FileId)

            Return oDCDInfoList

        End Function


        Private Function SaveDCDSENDLog(ByVal oDCDDownloadLog As ApplicationManager.PersonifyDataObjects.DCDDownloadLog) As Boolean

            Dim oDCDSendLogList As TIMSS.API.DigitalContentDeliveryInfo.IDigitalContentDeliverySendLogs
            Dim oDCDSendLog As TIMSS.API.DigitalContentDeliveryInfo.IDigitalContentDeliverySendLog
            oDCDSendLogList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.DigitalContentDeliveryInfo, "DigitalContentDeliverySendLogs")

            oDCDSendLog = oDCDSendLogList.CreateNew()
            With oDCDDownloadLog
                oDCDSendLog.FileId = .FileId
                oDCDSendLog.DocumentTitle = .DocumentTitle
                oDCDSendLog.FileToSend = .FileToSend
                oDCDSendLog.ProductId = .ProductId
                oDCDSendLog.StartTime = .StartTime
                oDCDSendLog.EndTime = .EndTime
                oDCDSendLog.FileSize = .FileSize
                oDCDSendLog.BytesSent = .FileSize 'need to change
                oDCDSendLog.Status = "Completed" 'need to change
                oDCDSendLog.StatusDate = Date.Now
                oDCDSendLog.ProductId = .ProductId
                oDCDSendLog.RemoteIp = .RemoteIP
                oDCDSendLog.OrderNumber = .OrderNo
                oDCDSendLog.MasterCustomerId = .MasterCustomerId
                oDCDSendLog.SubCustomerId = .SubCustomerId
                oDCDSendLog.FileToSend = .FileToSend
            End With
            oDCDSendLogList.Add(oDCDSendLog)
            oDCDSendLogList.Save()

            If oDCDSendLogList.ValidationIssues.ErrorCount = 0 Then
                Return True
            End If

            Return False
        End Function


#End Region

    End Class

End Namespace
