Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports Personify.ShoppingCartManager.Business
Imports Personify.applicationmanager

Namespace Personify.DNN.Modules.ShoppingCart

    Public MustInherit Class TransferShoppingCart        
        Inherits PersonifyDNNBaseForm
        Private ShoppingCartID As String
#Region "Controls"
#End Region

        Private Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
            Try
                If Me.Request.QueryString.Item("ShoppingCartID") IsNot Nothing Then
                    Me.ShoppingCartID = Me.Request.QueryString.Item("ShoppingCartID").ToString
                End If
                If (Me.ShoppingCartID <> String.Empty) Then
                    If Me.IsPersonifyWebUserLoggedIn Then
                        Dim oCart As New ShoppingCartController
                        Dim oLogin As New LoginManager(Me.MasterCustomerId, Me.SubCustomerId)
                        oLogin.UpdateShoppingCartItemPrice(Me.MasterCustomerId, Me.SubCustomerId)
                        oCart.TransferCartToUser(Me.ShoppingCartID, Me.MasterCustomerId, Me.SubCustomerId)
                        oCart.TransferCartComponentsToUser(Me.ShoppingCartID, Me.MasterCustomerId, Me.SubCustomerId)
                        oCart.TransferCartDCDFilesToUser(Me.ShoppingCartID, Me.MasterCustomerId, Me.SubCustomerId)
                    Else
                        SetAnonymousUserCookie(Me.ShoppingCartID)
                    End If
                End If
                'Redirect the page to the Tab ID in the URL
                If Me.Request.QueryString.Item("tabid") IsNot Nothing Then
                    Response.Redirect(NavigateURL(CInt(Me.Request.QueryString.Item("tabid").ToString)))
                End If
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try
        End Sub

        Private Sub SetAnonymousUserCookie(ByVal ShoppingCartID As String)
            If HttpContext.Current.Request.Browser.Cookies = True Then
                Response.Cookies("AnonumousTimssCMSUser").Value = ShoppingCartID
                Response.Cookies("AnonumousTimssCMSUser").Expires = DateTime.Now.AddDays(90)
            End If

        End Sub

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
