
Namespace Personify.DNN.Modules.ShoppingCart

    Public Class ModuleSettingsNames
        Public Const ShoppingCartDetailUrl As String = "ShoppingCartDetailUrl"
        Public Const ShoppingCartDetailUrlType As String = "ShoppingCartDetailUrlType"
        Public Const ShoppingCartCheckOutUrl As String = "ShoppingCartCheckOutUrl"
        Public Const ShoppingCartCheckOutUrlType As String = "ShoppingCartCheckOutUrlType"

        Public Const ShoppingCartContinueShoppingUrl As String = "ShoppingCartContinueShoppingUrl"
        Public Const ShoppingCartContinueShoppingUrlType As String = "ShoppingCartContinueShoppingUrlType"

        Public Const ShoppingCartAddRemoveSessionsUrl As String = "ShoppingCartAddRemoveSessionsUrl"
        Public Const ShoppingCartAddRemoveSessionsUrlType As String = "ShoppingCartAddRemoveSessionsUrlType"

        Public Const ShoppingCartShowBadgeLink As String = "ShoppingCartShowBadgeLink"
		Public Const ShoppingCartBadgesUrl As String = "ShoppingCartBadgesUrl"
        Public Const ShoppingCartBadgesUrlType As String = "ShoppingCartBadgesUrlType"

        Public Const CheckOut_RedirectToLoginURL As String = "CheckOut_RedirectToLoginURL"
        Public Const CheckOut_RedirectToLoginURLType As String = "CheckOut_RedirectToLoginURLType"
        Public Const C_TEMPLATE_FILE As String = "TemplateFile"
	End Class

End Namespace
