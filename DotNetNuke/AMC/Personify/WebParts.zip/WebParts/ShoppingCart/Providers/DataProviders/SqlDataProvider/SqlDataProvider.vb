Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports DotNetNuke

Namespace Personify.ShoppingCartManager.Data

    <CLSCompliant(False)> _
    Public Class SqlDataProvider

        Inherits Personify.ShoppingCartManager.Data.DataProvider


#Region "Private Members"
        Private Const ProviderType As String = "data"
        Private _providerConfiguration As Framework.Providers.ProviderConfiguration = Framework.Providers.ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _connectionString As String
        Private _providerPath As String
        Private _objectQualifier As String
        Private _databaseOwner As String
#End Region

#Region "Constructors"
        Public Sub New()

            ' Read the configuration specific information for this provider
            Dim objProvider As Framework.Providers.Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Framework.Providers.Provider)

            ' Read the attributes for this provider
            If objProvider.Attributes("connectionStringName") <> "" AndAlso _
            System.Configuration.ConfigurationManager.AppSettings(objProvider.Attributes("connectionStringName")) <> "" Then
                _connectionString = System.Configuration.ConfigurationManager.AppSettings(objProvider.Attributes("connectionStringName"))
            Else
                _connectionString = objProvider.Attributes("connectionString")
            End If

            _providerPath = objProvider.Attributes("providerPath")

            _objectQualifier = objProvider.Attributes("objectQualifier")
            If _objectQualifier <> "" And _objectQualifier.EndsWith("_") = False Then
                _objectQualifier += "_"
            End If

            _databaseOwner = objProvider.Attributes("databaseOwner")
            If _databaseOwner <> "" And _databaseOwner.EndsWith(".") = False Then
                _databaseOwner += "."
            End If

        End Sub
#End Region

#Region "Properties"
        Public ReadOnly Property ConnectionString() As String
            Get
                Return _connectionString
            End Get
        End Property

        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

        Public ReadOnly Property ObjectQualifier() As String
            Get
                Return _objectQualifier
            End Get
        End Property

        Public ReadOnly Property DatabaseOwner() As String
            Get
                Return _databaseOwner
            End Get
        End Property
#End Region

#Region "General Public Methods"
        Private Function GetNull(ByVal Field As Object) As Object

            Return DotNetNuke.Common.Utilities.Null.GetNull(Field, DBNull.Value)
        End Function
#End Region

#Region "ShoppingCart Methods"

        Public Overrides Function GetShoppingCart(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal WishList As Boolean, Optional ByVal IncludeSubProducts As Boolean = False, Optional ByVal PortalId As Integer = -1) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartGet", MasterCustomerId, SubCustomerId, WishList, IncludeSubProducts, PortalId), IDataReader)
        End Function

        Public Overrides Function GetShoppingCartForMembershipRenewalOrder(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal OrderNumber As String, Optional ByVal PortalId As Integer = -1) As System.Data.IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartGetForMBRRenewals", MasterCustomerId, SubCustomerId, OrderNumber, PortalId), IDataReader)
        End Function


        Public Overrides Function GetProductComponents(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal WishList As Boolean, ByVal ProductId As Integer, Optional ByVal PortalId As Integer = -1) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartGetProductComponent", MasterCustomerId, SubCustomerId, WishList, ProductId, PortalId), IDataReader)
        End Function

        Public Overrides Function GetProductComponentsByCartItemID(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal WishList As Boolean, ByVal CartItemID As Integer) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartGetProductComponentByCartItemID", MasterCustomerId, SubCustomerId, WishList, CartItemID), IDataReader)
        End Function

        Public Overrides Function AddShoppingCart(ByVal masterCustomerId As String, ByVal subCustomerId As Integer, ByVal productId As Integer, ByVal subProductId As Integer, ByVal RelatedCartItemId As Integer, ByVal productType As String, ByVal subsystem As String, ByVal shortName As String, ByVal longName As String, ByVal quantity As Integer, ByVal listPrice As Decimal, ByVal price As Decimal, ByVal rateCode As String, ByVal rateStructure As String, ByVal isWishList As Boolean, ByVal addDate As DateTime, ByVal modDate As DateTime, ByVal MaxBadges As Integer, ByVal shipMasterCustomerId As String, ByVal shipSubCustomerId As Integer, ByVal ShipCustomerLabelName As String, ByVal UserDefinedField1 As String, ByVal UserDefinedField2 As String, ByVal UserDefinedField3 As String, ByVal MarketCode As String, ByVal HasValidScheduledPrice As Boolean, ByVal MaximumTickets As Integer, Optional ByVal PortalId As Integer = -1, Optional ByVal isDirectPriceUpdate As Boolean = False, Optional ByVal ComponentExists As Boolean = False, Optional ByVal OrderNo As String = Nothing, Optional ByVal OrderLineNo As Integer = 0) As Integer

            'Dim ir As IDataReader
            Dim OutCartItemId As Integer

            Dim CommandParams(32) As SqlParameter

            CommandParams(0) = New SqlParameter("masterCustomerId", masterCustomerId)
            CommandParams(1) = New SqlParameter("subCustomerId", subCustomerId)
            CommandParams(2) = New SqlParameter("RelatedCartItemId", RelatedCartItemId)
            CommandParams(3) = New SqlParameter("productId", productId)
            CommandParams(4) = New SqlParameter("subProductId", subProductId)
            CommandParams(5) = New SqlParameter("productType", productType)
            CommandParams(6) = New SqlParameter("subsystem", subsystem)
            CommandParams(7) = New SqlParameter("shortName", shortName)
            CommandParams(8) = New SqlParameter("longName", longName)
            CommandParams(9) = New SqlParameter("quantity", quantity)
            CommandParams(10) = New SqlParameter("listPrice", listPrice)
            CommandParams(11) = New SqlParameter("price", price)
            CommandParams(12) = New SqlParameter("rateCode", rateCode)
            CommandParams(13) = New SqlParameter("rateStructure", rateStructure)
            CommandParams(14) = New SqlParameter("isWishList", isWishList)
            CommandParams(15) = New SqlParameter("addDate", addDate)
            CommandParams(16) = New SqlParameter("modDate", modDate)
            CommandParams(17) = New SqlParameter("MaxBadges", MaxBadges)
            CommandParams(18) = New SqlParameter("shipMasterCustomerId", shipMasterCustomerId)
            CommandParams(19) = New SqlParameter("shipSubCustomerId", shipSubCustomerId)
            CommandParams(20) = New SqlParameter("ShipCustomerLabelName", ShipCustomerLabelName)
            CommandParams(21) = New SqlParameter("PortalId", PortalId)
            CommandParams(22) = New SqlParameter("IsDirectPriceUpdate", isDirectPriceUpdate)
            CommandParams(23) = New SqlParameter("ComponentExists", ComponentExists)
            CommandParams(24) = New SqlParameter("UserDefinedField1", UserDefinedField1)
            CommandParams(25) = New SqlParameter("UserDefinedField2", UserDefinedField2)
            CommandParams(26) = New SqlParameter("UserDefinedField3", UserDefinedField3)
            CommandParams(27) = New SqlParameter("MarketCode", MarketCode)
            CommandParams(28) = New SqlParameter("HasValidScheduledPrice", HasValidScheduledPrice)

            CommandParams(29) = New SqlParameter("MaximumTickets", MaximumTickets)
            CommandParams(30) = New SqlParameter("OrderNo", OrderNo)
            CommandParams(31) = New SqlParameter("OrderLineNo", OrderLineNo)

            CommandParams(32) = New SqlParameter("OutCartItemId", OutCartItemId)
            CommandParams(32).Direction = ParameterDirection.Output

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartAdd", CommandParams)


            Return CInt(CommandParams(32).Value)

            'Return CType(SqlHelper.ExecuteScalar(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartAdd", masterCustomerId, subCustomerId, productId, subProductId, GetNull(productType), subsystem, GetNull(shortName), GetNull(longName), quantity, GetNull(listPrice), GetNull(price), GetNull(rateCode), GetNull(rateStructure), isWishList, addDate, modDate, MaxBadges, shipMasterCustomerId, shipSubCustomerId, ShipCustomerLabelName, RelCartId), Integer)
        End Function

        Public Overrides Sub UpdateShoppingCart(ByVal cartItemId As Integer, ByVal masterCustomerId As String, ByVal subCustomerId As Integer, ByVal productId As Integer, ByVal subProductId As Integer, ByVal productType As String, ByVal subsystem As String, ByVal shortName As String, ByVal longName As String, ByVal quantity As Integer, ByVal listPrice As Decimal, ByVal price As Decimal, ByVal rateCode As String, ByVal rateStructure As String, ByVal isWishList As Boolean, ByVal addDate As DateTime, ByVal modDate As DateTime, ByVal MaxBadges As Integer, ByVal shipMasterCustomerId As String, ByVal shipSubCustomerId As Integer, ByVal ShipCustomerLabelName As String, ByVal UserDefinedField1 As String, ByVal UserDefinedField2 As String, ByVal UserDefinedField3 As String, ByVal MarketCode As String, ByVal HasValidScheduledPrice As Boolean, ByVal MaximumTickets As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartUpdate", cartItemId, masterCustomerId, subCustomerId, productId, subProductId, GetNull(productType), subsystem, GetNull(shortName), GetNull(longName), quantity, GetNull(listPrice), GetNull(price), GetNull(rateCode), GetNull(rateStructure), isWishList, addDate, modDate, MaxBadges, shipMasterCustomerId, shipSubCustomerId, ShipCustomerLabelName, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode, HasValidScheduledPrice, MaximumTickets)
        End Sub

        Public Overrides Sub MoveItem(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer, ByVal isWishList As Boolean, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartMoveItem", MasterCustomerId, SubCustomerId, ProductId, isWishList, PortalId)
        End Sub

        Public Overrides Sub MoveItemByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal isWishList As Boolean, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartMoveItemByCartitemId", MasterCustomerId, SubCustomerId, CartItemId, isWishList, PortalId)
        End Sub

        Public Overrides Sub UpdateCartQuantity(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer, ByVal Quantity As Integer, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartUpdateQuantity", MasterCustomerId, SubCustomerId, ProductId, Quantity, PortalId)
        End Sub

        Public Overrides Sub UpdateCartQuantityByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal Quantity As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartUpdateQuantityByCartItemId", MasterCustomerId, SubCustomerId, CartItemId, Quantity)
        End Sub

        Public Overrides Sub DeleteShoppingCart(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartDeleteCart", MasterCustomerId, SubCustomerId, PortalId)
        End Sub

        Public Overrides Sub DeleteShoppingCartItemByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal IsWishList As Boolean)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartDeleteCartItemByCartItemId", MasterCustomerId, SubCustomerId, CartItemId, IsWishList)
        End Sub

        Public Overrides Sub DeleteShoppingCartItem(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer, ByVal IsWishList As Boolean, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartDeleteCartItem", MasterCustomerId, SubCustomerId, ProductId, IsWishList, PortalId)
        End Sub

        Public Overrides Function GetMiniShoppingCart(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, Optional ByVal PortalId As Integer = -1) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartGetMiniCart", MasterCustomerId, SubCustomerId, PortalId), IDataReader)
        End Function

        Public Overrides Sub TransferCartToUser(ByVal AnonymousId As String, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartTransferCartToUser", AnonymousId, MasterCustomerId, SubCustomerId)
        End Sub

        Public Overrides Sub AddUpdateBadge(ByVal CartItemId As Integer, ByVal BadgeNumber As Integer, ByVal BadgeTypeCode As String, ByVal FirstName As String, ByVal FullName As String, ByVal Company As String, ByVal City As String, ByVal State As String, ByVal PostalCode As String)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartAddUpdateBadge", CartItemId, BadgeNumber, BadgeTypeCode, FirstName, FullName, Company, City, State, PostalCode)
        End Sub

        Public Overrides Sub DeleteBadges(ByVal CartItemId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartDeleteBadges", CartItemId)
        End Sub

        Public Overrides Function GetBadges(ByVal CartItemId As Integer) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartGetBadges", CartItemId), IDataReader)
        End Function

        Public Overrides Sub DeleteShoppingCartExistingOrders(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "Personify_ShoppingCartDeleteExistingOrders", MasterCustomerId, SubCustomerId, PortalId)
        End Sub



#End Region

#Region "Overload ShoppingCart Methods With UserDefined Fields"





#End Region

#Region "ShoppingCart Components"
        Public Overrides Function AddShoppingCartComponents(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal ProductId As Integer, ByVal ComponentProductId As Integer, ByVal ShortName As String, ByVal LongName As String, ByVal AddDate As DateTime, ByVal ModDate As DateTime, ByVal isWishList As Boolean, Optional ByVal PortalId As Integer = -1) As Integer
            Dim OutComponentCartItemId As Integer

            Dim CommandParams(11) As SqlParameter

            CommandParams(0) = New SqlParameter("MasterCustomerId", MasterCustomerId)
            CommandParams(1) = New SqlParameter("SubCustomerId", SubCustomerId)
            CommandParams(2) = New SqlParameter("CartItemId", CartItemId)
            CommandParams(3) = New SqlParameter("productId", ProductId)
            CommandParams(4) = New SqlParameter("ComponentProductId", ComponentProductId)
            CommandParams(5) = New SqlParameter("shortName", ShortName)
            CommandParams(6) = New SqlParameter("longName", LongName)
            CommandParams(7) = New SqlParameter("IsWishList", isWishList)
            CommandParams(8) = New SqlParameter("AddDate", AddDate)
            CommandParams(9) = New SqlParameter("ModDate", ModDate)
            CommandParams(10) = New SqlParameter("PortalId", PortalId)
            CommandParams(11) = New SqlParameter("OutComponentCartItemId", OutComponentCartItemId)
            CommandParams(11).Direction = ParameterDirection.Output

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsAdd", CommandParams)

            Return CInt(CommandParams(11).Value)
        End Function

        Public Overrides Sub UpdateShoppingCartComponents(ByVal ComponentCartItemId As Integer, ByVal CartItemId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer, ByVal ComponentProductId As Integer, ByVal ShortName As String, ByVal LongName As String, ByVal isWishList As Boolean, ByVal AddDate As DateTime, ByVal ModDate As DateTime)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsUpdate", ComponentCartItemId, CartItemId, MasterCustomerId, SubCustomerId, ProductId, ComponentProductId, GetNull(ShortName), GetNull(LongName), isWishList, AddDate, ModDate)
        End Sub

        Public Overrides Sub DeleteShoppingCartComponents(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsDeleteCart", MasterCustomerId, SubCustomerId, PortalId)
        End Sub

        Public Overrides Sub DeleteShoppingCartComponentsItemByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsDeleteCartItem", MasterCustomerId, SubCustomerId, CartItemId)
        End Sub

        Public Overrides Sub DeleteShoppingCartComponentsItemByComponentCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ComponentCartItemId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsDeleteItemByComponentCartItemId", MasterCustomerId, SubCustomerId, ComponentCartItemId)
        End Sub

        Public Overrides Function GetShoppingCartComponentsByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal WishList As Boolean, Optional ByVal PortalId As Integer = -1) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsGetAllComponentsByCartItemId", MasterCustomerId, SubCustomerId, PortalId, CartItemId, WishList), IDataReader)
        End Function

        Public Overrides Function GetShoppingCartComponentsByComponentCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ComponentCartItemId As Integer, ByVal isWishList As Boolean, Optional ByVal PortalId As Integer = -1) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsGetByComponentCartItemId", MasterCustomerId, SubCustomerId, PortalId, isWishList, ComponentCartItemId), IDataReader)
        End Function

        Public Overrides Sub TransferCartComponentsToUser(ByVal AnonymousId As String, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsTransferCartToUser", AnonymousId, MasterCustomerId, SubCustomerId)
        End Sub

        Public Overrides Sub MoveCartComponentsItem(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal isWishList As Boolean, Optional ByVal PortalId As Integer = -1)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartComponentsMoveItem", MasterCustomerId, SubCustomerId, CartItemId, isWishList, PortalId)
        End Sub
#End Region

#Region "DCD product files"
        Public Overrides Function AddShoppingCartDCDFiles(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal ProductId As Integer, ByVal FileId As Integer, ByVal FileName As String, ByVal DocumentTitle As String, ByVal DisplayCopyright As Boolean, ByVal CopyrightText As String, ByVal isWishList As Boolean, ByVal AddDate As DateTime, ByVal ModDate As DateTime, ByVal PortalId As Integer) As Integer
            Dim OutCartItemFileId As Integer

            Dim CommandParams(13) As SqlParameter

            CommandParams(0) = New SqlParameter("MasterCustomerId", MasterCustomerId)
            CommandParams(1) = New SqlParameter("SubCustomerId", SubCustomerId)
            CommandParams(2) = New SqlParameter("CartItemId", CartItemId)
            CommandParams(3) = New SqlParameter("productId", ProductId)
            CommandParams(4) = New SqlParameter("FileId", FileId)
            CommandParams(5) = New SqlParameter("FileName", FileName)
            CommandParams(6) = New SqlParameter("DocumentTitle", DocumentTitle)
            CommandParams(7) = New SqlParameter("DisplayCopyright", DisplayCopyright)
            CommandParams(8) = New SqlParameter("CopyrightText", CopyrightText)
            CommandParams(9) = New SqlParameter("IsWishList", isWishList)
            CommandParams(10) = New SqlParameter("AddDate", AddDate)
            CommandParams(11) = New SqlParameter("ModDate", ModDate)
            CommandParams(12) = New SqlParameter("PortalId", PortalId)
            CommandParams(13) = New SqlParameter("OutCartItemFileId", OutCartItemFileId)
            CommandParams(13).Direction = ParameterDirection.Output

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesAdd", CommandParams)

            Return CInt(CommandParams(13).Value)
        End Function

        Public Overrides Sub UpdateShoppingCartDCDFiles(ByVal CartItemFileId As Integer, ByVal CartItemId As Integer, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer, ByVal FileId As Integer, ByVal FileName As String, ByVal DocumentTitle As String, ByVal DisplayCopyright As Boolean, ByVal CopyrightText As String, ByVal isWishList As Boolean, ByVal AddDate As DateTime, ByVal ModDate As DateTime)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesUpdate", CartItemFileId, MasterCustomerId, SubCustomerId, CartItemId, ProductId, FileId, GetNull(FileName), GetNull(DocumentTitle), DisplayCopyright, GetNull(CopyrightText), isWishList, AddDate, ModDate)
        End Sub

        Public Overrides Sub DeleteShoppingCartDCDFiles(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal PortalId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesDeleteCart", MasterCustomerId, SubCustomerId, PortalId)
        End Sub

        Public Overrides Sub DeleteShoppingCartDCDFilesItemByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesDeleteCartItem", MasterCustomerId, SubCustomerId, CartItemId)
        End Sub

        Public Overrides Sub DeleteShoppingCartDCDFilesItemByCartItemFileId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemFileId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesDeleteItemByCartItemFileId", MasterCustomerId, SubCustomerId, CartItemFileId)
        End Sub

        Public Overrides Function GetShoppingCartDCDFilesByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal WishList As Boolean, ByVal PortalId As Integer) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesGetAllDCDFilesByCartItemId", MasterCustomerId, SubCustomerId, PortalId, CartItemId, WishList), IDataReader)
        End Function

        Public Overrides Function GetShoppingCartDCDFilesByCartItemFileId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemFileId As Integer, ByVal isWishList As Boolean, ByVal PortalId As Integer) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesGetByCartItemFileId", MasterCustomerId, SubCustomerId, PortalId, isWishList, CartItemFileId), IDataReader)
        End Function

        Public Overrides Sub TransferCartDCDFilesToUser(ByVal AnonymousId As String, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesTransferCartToUser", AnonymousId, MasterCustomerId, SubCustomerId)
        End Sub

        Public Overrides Sub MoveCartDCDFilesItem(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal isWishList As Boolean, ByVal PortalId As Integer)
            SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner & ObjectQualifier & "PersonifyShoppingCartDCDFilesMoveItem", MasterCustomerId, SubCustomerId, CartItemId, isWishList, PortalId)
        End Sub
#End Region


    
    End Class

End Namespace