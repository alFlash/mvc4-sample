/************************************************************/
/*****              SQLDataProvider                     *****/
/*****              ShoppingCart               *****/
/*****                                                  *****/
/***** Note: To manually execute this script you must   *****/
/*****       perform a search and replace operation     *****/
/*****       for {databaseOwner} and {objectQualifier}  *****/
/*****                                                  *****/
/************************************************************/

/* Insert here the code to create tables and stored procs   */

/****** Object:  Table {databaseOwner}[TIMSSCMS_ShoppingCart]    Script Date: 4/12/2006 9:35:28 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[{objectQualifier}TIMSSCMS_ShoppingCart]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table {databaseOwner}[{objectQualifier}TIMSSCMS_ShoppingCart]
GO

/****** Object:  Table {databaseOwner}[TIMSSCMS_ShoppingCart]    Script Date: 4/12/2006 9:35:31 AM ******/
CREATE TABLE {databaseOwner}[{objectQualifier}TIMSSCMS_ShoppingCart] (
	[CartItemId] [int] IDENTITY (1, 1) NOT NULL ,
	[MasterCustomerId] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SubCustomerId] [int] NOT NULL ,
	[ProductId] [int] NOT NULL ,
	[SubProductId] [int] NOT NULL ,
	[ProductType] [nvarchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Subsystem] [nvarchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ShortName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LongName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Quantity] [int] NOT NULL ,
	[ListPrice] [money] NULL ,
	[Price] [money] NULL ,
	[RateCode] [nvarchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RateStructure] [nvarchar] (24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsWishList] [bit] NOT NULL ,
	[AddDate] [datetime] NOT NULL ,
	[ModDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE {databaseOwner}[{objectQualifier}TIMSSCMS_ShoppingCart] WITH NOCHECK ADD 
	CONSTRAINT [PK_TIMSSCMS_ShoppingCart] PRIMARY KEY  CLUSTERED 
	(
		[CartItemId]
	)  ON [PRIMARY] 
GO

ALTER TABLE {databaseOwner}[{objectQualifier}TIMSSCMS_ShoppingCart] ADD 
	CONSTRAINT [DF_TIMSSCMS_ShoppingCart_SubProductId] DEFAULT (0) FOR [SubProductId],
	CONSTRAINT [DF_TIMSSCMS_ShoppingCart_Price] DEFAULT (0) FOR [Price],
	CONSTRAINT [DF_TIMSSCMS_ShoppingCart_ADD_DATE] DEFAULT (getdate()) FOR [AddDate],
	CONSTRAINT [DF_TIMSSCMS_ShoppingCart_MOD_DATE] DEFAULT (getdate()) FOR [ModDate]
GO




/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartAdd    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[{objectQualifier}TIMSSCMS_ShoppingCartAdd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartAdd]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartDeleteCart    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartDeleteCart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartDeleteCart]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartDeleteCartItem    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartDeleteCartItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartDeleteCartItem]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartGet    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartGet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartGet]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartGetMiniCart    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartGetMiniCart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartGetMiniCart]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartGetProductComponent    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartGetProductComponent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartGetProductComponent]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartList    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartList]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartMoveItem    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartMoveItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartMoveItem]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartUpdate    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartUpdate]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartUpdateQuantity    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartUpdateQuantity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartUpdateQuantity]
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartTransferCartToUser    Script Date: 4/12/2006 9:27:00 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'{databaseOwner}[TIMSSCMS_ShoppingCartTransferCartToUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure {databaseOwner}[TIMSSCMS_ShoppingCartTransferCartToUser]
GO


SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartDeleteCart    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartDeleteCart
	@MasterCustomerId varchar(32),
	@SubCustomerId int
AS

DELETE FROM {objectQualifier}TIMSSCMS_ShoppingCart
WHERE
	[MasterCustomerId] = @MasterCustomerId
	AND [SubCustomerId] = @SubCustomerId
	AND [IsWishList] = 0

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartDeleteCartItem    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartDeleteCartItem
	@MasterCustomerId varchar(32),
	@SubCustomerId int,
	@ProductId int,
	@IsWishList bit
AS

DELETE FROM {objectQualifier}TIMSSCMS_ShoppingCart
WHERE
	[MasterCustomerId] = @MasterCustomerId
	AND [SubCustomerId] = @SubCustomerId
	AND [ProductId] = @ProductId
	AND [IsWishList] = @IsWishList

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartGet    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartGet
	@MasterCustomerId varchar(32),
	@SubCustomerId int,
	@WishList as bit
	
AS

SELECT
	[CartItemId],
	[MasterCustomerId],
	[SubCustomerId],
	[ProductId],
	[SubProductId],
	[ProductType],
	[Subsystem],
	[ShortName],
	[LongName],
	[Quantity],
	[ListPrice],
	[Price],
	[RateCode],
	[RateStructure],
	[IsWishList],
	[AddDate],
	[ModDate]
FROM {objectQualifier}TIMSSCMS_ShoppingCart
WHERE
	[MasterCustomerId] = @MasterCustomerId
	AND [SubCustomerId] = @SubCustomerId
	AND [IsWishList] = @WishList
	AND [SubProductId] = 0
	

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartGetMiniCart    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartGetMiniCart
(
	@MasterCustomerId varchar(32),
	@SubCustomerId int
)
as
set nocount on
DECLARE @ShoppingCartItems integer
DECLARE @ShoppingCartTotal money
SET @ShoppingCartItems = (
							select count(*) 
							from {objectQualifier}TIMSSCMS_ShoppingCart 
							where 
							IsWishList = 0 
							and [MasterCustomerId] = @MasterCustomerId 
							and [SubCustomerid] = @SubCustomerId)
							
SET @ShoppingCartTotal = (
							select SUM(Quantity * Price) 
							from {objectQualifier}TIMSSCMS_ShoppingCart 
							where 
							IsWishList = 0 
							and [MasterCustomerId] = @MasterCustomerId 
							and [SubCustomerid] = @SubCustomerId)
							
select @ShoppingCartItems as ShoppingCartItems, @ShoppingCartTotal As ShoppingCartTotal

RETURN

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartGetProductComponent    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartGetProductComponent
	@MasterCustomerId varchar(32),
	@SubCustomerId int,
	@WishList as bit,
	@ProductId int
	
AS

SELECT
	[CartItemId],
	[MasterCustomerId],
	[SubCustomerId],
	[ProductId],
	[SubProductId],
	[ProductType],
	[Subsystem],
	[ShortName],
	[LongName],
	[Quantity],
	[ListPrice],
	[Price],
	[RateCode],
	[RateStructure],
	[IsWishList],
	[AddDate],
	[ModDate]
FROM {objectQualifier}TIMSSCMS_ShoppingCart
WHERE
	[MasterCustomerId] = @MasterCustomerId
	AND [SubCustomerId] = @SubCustomerId
	AND [IsWishList] = @WishList
	AND [SubProductId] <> 0
	AND [ProductId] = @ProductId
	

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartList    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartList
AS

SELECT
	[CartItemId],
	[MasterCustomerId],
	[SubCustomerId],
	[ProductId],
	[SubProductId],
	[ProductType],
	[Subsystem],
	[ShortName],
	[LongName],
	[Quantity],
	[ListPrice],
	[Price],
	[RateCode],
	[RateStructure],
	[IsWishList],
	[AddDate],
	[ModDate]
FROM {objectQualifier}TIMSSCMS_ShoppingCart

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartMoveItem    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartMoveItem
@MasterCustomerId varchar(32),
	@SubCustomerId int,
	@ProductId int, 
	@IsWishList bit
AS

UPDATE {objectQualifier}TIMSSCMS_ShoppingCart SET
	[IsWishList] = @IsWishList
WHERE
	[MasterCustomerId] = @MasterCustomerId
	AND [SubCustomerId] = @SubCustomerId
	AND [ProductId] = @ProductId

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartUpdate    Script Date: 4/12/2006 9:27:00 AM ******/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartUpdate
	@CartItemId int, 
	@MasterCustomerId varchar(32), 
	@SubCustomerId int, 
	@ProductId int, 
	@SubProductId int, 
	@ProductType nvarchar(24), 
	@Subsystem nvarchar(3), 
	@ShortName nvarchar(255), 
	@LongName nvarchar(255), 
	@Quantity int, 
	@ListPrice money, 
	@Price money, 
	@RateCode nvarchar(24), 
	@RateStructure nvarchar(24), 
	@IsWishList bit, 
	@AddDate datetime, 
	@ModDate datetime 
AS

UPDATE {objectQualifier}TIMSSCMS_ShoppingCart SET
	[MasterCustomerId] = @MasterCustomerId,
	[SubCustomerId] = @SubCustomerId,
	[ProductId] = @ProductId,
	[SubProductId] = @SubProductId,
	[ProductType] = @ProductType,
	[Subsystem] = @Subsystem,
	[ShortName] = @ShortName,
	[LongName] = @LongName,
	[Quantity] = @Quantity,
	[ListPrice] = @ListPrice,
	[Price] = @Price,
	[RateCode] = @RateCode,
	[RateStructure] = @RateStructure,
	[IsWishList] = @IsWishList,
	[AddDate] = @AddDate,
	[ModDate] = @ModDate
WHERE
	[CartItemId] = @CartItemId

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}TIMSSCMS_ShoppingCartUpdateQuantity    Script Date: 4/12/2006 9:27:00 AM ******/


/* -------------------------------------------------------------------------------------
/   TIMSSCMS_ShoppingCartUpdateQuantity
/  ------------------------------------------------------------------------------------- */
CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartUpdateQuantity
	@ProductId int, 
	@Quantity int
AS

UPDATE {objectQualifier}TIMSSCMS_ShoppingCart SET
	[Quantity] = @Quantity
WHERE
	[ProductId] = @ProductId
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartAdd    Script Date: 4/12/2006 9:27:00 AM *****
*/

CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartAdd
	@MasterCustomerId varchar(32),
	@SubCustomerId int,
	@ProductId int,
	@SubProductId int,
	@ProductType nvarchar(24),
	@Subsystem nvarchar(3),
	@ShortName nvarchar(255),
	@LongName nvarchar(255),
	@Quantity int,
	@ListPrice money,
	@Price money,
	@RateCode nvarchar(24),
	@RateStructure nvarchar(24),
	@IsWishList bit,
	@AddDate datetime,
	@ModDate datetime
AS

IF NOT EXISTS(SELECT ProductId FROM {objectQualifier}TIMSSCMS_ShoppingCart WHERE [ProductId] = @ProductId AND [SubProductId] = @SubProductId AND [MasterCustomerId] = @MasterCustomerId AND [SubCustomerId] = @SubCustomerId)

BEGIN

INSERT INTO {objectQualifier}TIMSSCMS_ShoppingCart (
	[MasterCustomerId],
	[SubCustomerId],
	[ProductId],
	[SubProductId],
	[ProductType],
	[Subsystem],
	[ShortName],
	[LongName],
	[Quantity],
	[ListPrice],
	[Price],
	[RateCode],
	[RateStructure],
	[IsWishList],
	[AddDate],
	[ModDate]
) VALUES (
	@MasterCustomerId,
	@SubCustomerId,
	@ProductId,
	@SubProductId,
	@ProductType,
	@Subsystem,
	@ShortName,
	@LongName,
	@Quantity,
	@ListPrice,
	@Price,
	@RateCode,
	@RateStructure,
	@IsWishList,
	@AddDate,
	@ModDate
)
END
ELSE
BEGIN
UPDATE {objectQualifier}TIMSSCMS_ShoppingCart SET
	[MasterCustomerId] = @MasterCustomerId,
	[SubCustomerId] = @SubCustomerId,
	[ProductId] = @ProductId,
	[SubProductId] = @SubProductId,
	[ProductType] = @ProductType,
	[Subsystem] = @Subsystem,
	[ShortName] = @ShortName,
	[LongName] = @LongName,
	[Quantity] = [Quantity] + @Quantity,
	[ListPrice] = @ListPrice,
	[Price] = @Price,
	[RateCode] = @RateCode,
	[RateStructure] = @RateStructure,
	[IsWishList] = @IsWishList,
	[ModDate] = @ModDate
WHERE
	[MasterCustomerId] = @MasterCustomerId
	AND [SubCustomerId] = @SubCustomerId
	AND [ProductId] = @ProductId
	AND [SubProductId] = @SubProductId

END


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


/* -------------------------------------------------------------------------------------
/   TIMSSCMS_ShoppingCartTransferCartToUser
/  ------------------------------------------------------------------------------------- */
CREATE PROCEDURE {databaseOwner}{objectQualifier}TIMSSCMS_ShoppingCartTransferCartToUser
	@AnonymousId varchar(32), 
	@MasterCustomerId varchar(32),
	@SubCustomerId int
AS

UPDATE {objectQualifier}TIMSSCMS_ShoppingCart SET
	[MasterCustomerId] = @MasterCustomerId,
	[SubCustomerId] = @SubCustomerId
WHERE
	[MasterCustomerId] = @AnonymousId
