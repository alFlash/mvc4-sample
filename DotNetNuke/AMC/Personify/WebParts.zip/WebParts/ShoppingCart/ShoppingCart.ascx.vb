Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports Personify.ShoppingCartManager.Business


Imports System.Text

Namespace Personify.DNN.Modules.ShoppingCart

    Public MustInherit Class ShoppingCart
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected WithEvents Button1 As System.Web.UI.WebControls.Button
        Protected WithEvents btnEmptyCart As System.Web.UI.WebControls.ImageButton
        Protected WithEvents Textbox1 As System.Web.UI.WebControls.TextBox
        Protected WithEvents Textbox2 As System.Web.UI.WebControls.TextBox
        Protected WithEvents Textbox3 As System.Web.UI.WebControls.TextBox
        Protected WithEvents Textbox4 As System.Web.UI.WebControls.TextBox
		Protected WithEvents Textbox5 As System.Web.UI.WebControls.TextBox
		Protected WithEvents Textbox6 As System.Web.UI.WebControls.TextBox
        Protected WithEvents s As System.Web.UI.WebControls.TextBox
        Protected WithEvents pt As System.Web.UI.WebControls.TextBox
        Protected WithEvents rc As System.Web.UI.WebControls.TextBox
        Protected WithEvents rs As System.Web.UI.WebControls.TextBox
        Protected WithEvents spid As System.Web.UI.WebControls.TextBox
		Protected WithEvents lblSubTotal As System.Web.UI.WebControls.Label
        Protected WithEvents oMessageControl As WebControls.MessageControl

        Protected ShoppingCartXslTemplate As WebControls.XslTemplate
#End Region

#Region "Private Variables"
        Private SubTotal As Decimal = 0
        Dim _mtgProductList As ArrayList = Nothing
        'Private MasterCustomerId As String
        'Private SubCustomerId As Integer
        'Private IsLoggedIn As Boolean
#End Region

        Private ReadOnly Property EditSetting_Checkout_RedirectToLoginURL() As String
            Get

                Dim LoginURLBuilder As New System.Text.StringBuilder

                LoginURLBuilder.Append("~/Default.aspx?tabid=")
                LoginURLBuilder.Append(CType(Settings(ModuleSettingsNames.CheckOut_RedirectToLoginURL), String))
                LoginURLBuilder.Append("&returnurl=")
                LoginURLBuilder.Append(HttpUtility.UrlEncode(Request.Url.AbsoluteUri))
                'FLAG: Go to checkout page directly when returning from login
                LoginURLBuilder.Append(HttpUtility.UrlEncode("&AUTO=Y"))
                Return LoginURLBuilder.ToString

            End Get
        End Property

        Private ReadOnly Property EditSetting_ContinueShoppingURL() As String
            Get
                If Settings(ModuleSettingsNames.ShoppingCartContinueShoppingUrl) IsNot Nothing Then
                    Return "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartContinueShoppingUrl), String)
                Else
                    Return "~/Default.aspx"
                End If
            End Get
        End Property

        Private ReadOnly Property EditSetting_AddRemoveSessionsURL() As String
            Get
                If Settings(ModuleSettingsNames.ShoppingCartAddRemoveSessionsUrl) IsNot Nothing Then
                    Return NavigateURL(CType(Settings(ModuleSettingsNames.ShoppingCartContinueShoppingUrl), Integer))
                Else
                    Return String.Empty
                End If
            End Get
        End Property
     

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            RegisterJSScripts("js\hintbox.js", "HintBox")

            Try
                If Settings(ModuleSettingsNames.C_TEMPLATE_FILE) IsNot Nothing Then
                    LoadCarts()
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadCarts()
            GetMyShoppingCart()

            If CreateOrderMaster AndAlso Me.IsPersonifyWebUserLoggedIn Then
                get_clsOrderCheckOutProcessHelper.CreateOrderMaster(MasterCustomerId, SubCustomerId)
            End If

            'Auto redirect to checkout page
            If Request.QueryString("AUTO") IsNot Nothing AndAlso CStr(Request.QueryString("AUTO")).ToUpper = "Y" Then
                CheckOut()
            End If

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is requiredw by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            '        If Not UserInfo.Profile.ProfileProperties("MasterCustomerId") Is Nothing AndAlso Not UserInfo.Profile.ProfileProperties("SubCustomerId") Is Nothing Then
            '            MasterCustomerId = CType(UserInfo.Profile.ProfileProperties("MasterCustomerId").PropertyValue, String)
            '            SubCustomerId = CType(UserInfo.Profile.ProfileProperties("SubCustomerId").PropertyValue, Integer)
            '        Else 'The current user does not have these attributes
            '            'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMCIDSCIDMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            'MasterCustomerId = ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
            'SubCustomerId = 0
            '        End If

            InitializeComponent()
        End Sub

#End Region


#Region "Temporary"

        Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
            AddToCart(CType(Textbox1.Text, Integer), CType(Textbox2.Text, Integer))
            LoadCarts()
        End Sub

        Private Sub AddToCart(ByVal p As Integer, Optional ByVal q As Integer = 1)
            Dim oController As New ShoppingCartController
            Dim oCart As New ShoppingCartInfo
            oCart.Subsystem = s.Text
            oCart.ProductType = pt.Text
            oCart.RateCode = rc.Text
            oCart.RateStructure = rs.Text

            '           oCart.MasterCustomerId = ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId)
            '            oCart.SubCustomerId = SubCustomerId

            oCart.MasterCustomerId = MasterCustomerId
            oCart.SubCustomerId = SubCustomerId

            oCart.ShortName = Textbox3.Text
            oCart.LongName = Textbox4.Text
            oCart.Price = CDec(Textbox5.Text)
			oCart.Quantity = q
			oCart.MaxBadges = CType(Textbox6.Text, Integer)
            oCart.ProductId = p
            oCart.SubProductId = CType(spid.Text, Integer)
            oCart.AddDate = Date.Now
            oCart.ModDate = Date.Now
            oCart.IsWishList = False
            oController.AddToCart(oCart)
            oController = Nothing
        End Sub
#End Region

#Region "Events"

       
        Private Sub ClearOrderFromSession()

            ClearSessionObject(SessionKeys.PersonifyOrder)
        End Sub

        Private Sub DoCartOperations(ByVal sender As Object, ByVal e As CommandEventArgs)
            Select Case e.CommandName.ToLower
                Case "addtowishlist"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim ProductId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim Position As Integer = CType(CommandArgumentInfo(1), Integer)
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(2), Integer)
                    'Dim qtyBox As TextBox
                    'qtyBox = CType(FindControl("ShoppingCartItemQuantity" & Position), TextBox)
                    'If Not qtyBox Is Nothing Then
                    MoveItemByCartItemID(ProductId, CartItemId, True)
                    'End If
                    Response.Redirect(NavigateURL(), True)
                Case "deletecartitem"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim Position As Integer = CType(CommandArgumentInfo(1), Integer)
                    DeleteCartItemByCartItemID(CType(CartItemId, Integer), False)
                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "deletecartsubitem"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim Position As Integer = CType(CommandArgumentInfo(1), Integer)
                    Dim Position1 As Integer = CType(CommandArgumentInfo(2), Integer)

                    Dim oController As New ShoppingCartController
                    Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, False, CartItemId)

                    For j As Integer = 0 To CList.Count - 1
                        Dim CartSubItemId As Integer = CType(CList(j), ShoppingCartInfo).CartItemId

                        If (j + 1) = Position1 Then
                            DeleteCartItemByCartItemID(CType(CartSubItemId, Integer), False)
                        End If
                    Next

                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "deletecartdcdfilesitem"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim CartItemFileId As Integer = CType(CommandArgumentInfo(1), Integer)
                    Dim Position As Integer = CType(CommandArgumentInfo(2), Integer)
                    Dim Position1 As Integer = CType(CommandArgumentInfo(3), Integer)

                    Dim oController As New ShoppingCartController
                    Dim DCDFilesList As ArrayList = oController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, CartItemId, False, PortalId)

                    For j As Integer = 0 To DCDFilesList.Count - 1
                        If DCDFilesList.Count = 1 Then
                            DeleteCartItemByCartItemID(CType(CartItemId, Integer), False)
                        Else
                            DeleteDCDFilesByCartItemFileID(CType(CartItemFileId, Integer))
                        End If
                    Next

                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "deletewishlistsubitem"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim Position As Integer = CType(CommandArgumentInfo(1), Integer)
                    Dim Position1 As Integer = CType(CommandArgumentInfo(2), Integer)

                    Dim oController As New ShoppingCartController
                    Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, True, CartItemId)

                    For j As Integer = 0 To CList.Count - 1
                        Dim CartSubItemId As Integer = CType(CList(j), ShoppingCartInfo).CartItemId

                        If (j + 1) = Position1 Then
                            DeleteCartItemByCartItemID(CType(CartSubItemId, Integer), True)
                        End If
                    Next

                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "deletewishlistdcdfilesitem"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim CartItemFileId As Integer = CType(CommandArgumentInfo(1), Integer)
                    Dim Position As Integer = CType(CommandArgumentInfo(2), Integer)
                    Dim Position1 As Integer = CType(CommandArgumentInfo(3), Integer)

                    Dim oController As New ShoppingCartController
                    Dim DCDFilesList As ArrayList = oController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, CartItemId, True, PortalId)

                    For j As Integer = 0 To DCDFilesList.Count - 1
                        If DCDFilesList.Count = 1 Then
                            DeleteCartItemByCartItemID(CType(CartItemId, Integer), True)
                        Else
                            DeleteDCDFilesByCartItemFileID(CType(CartItemFileId, Integer))
                        End If
                    Next

                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "goback"
                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "updatecart"
                    If UpdateShoppingCart() Then
                        ClearOrderFromSession()
                        ClearValidationIssues()
                        Response.Redirect(NavigateURL(), True)
                    Else
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidQuantity", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                Case "emptycart"
                    EmptyCart()
                    ClearOrderFromSession()
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
                Case "checkout"
                    If ValidatePreCheckoutCondition() Then
                        CheckOut()
                    End If
                Case "continueshopping"
                    Response.Redirect(EditSetting_ContinueShoppingURL)

                Case "deletewishlistitem"
                    DeleteCartItemByCartItemID(CType(e.CommandArgument, Integer), True)
                    Response.Redirect(NavigateURL(), True)
                Case "movetocart"
                    Dim CommandArgumentInfo() As String = CType(e.CommandArgument, String).Split(CChar("-"))
                    Dim ProductId As Integer = CType(CommandArgumentInfo(0), Integer)
                    Dim CartItemId As Integer = CType(CommandArgumentInfo(1), Integer)
                    MoveItemByCartItemID(ProductId, CartItemId, False)
                    ClearValidationIssues()
                    Response.Redirect(NavigateURL(), True)
            End Select
        End Sub

        Private Function UpdateShoppingCart() As Boolean

            Dim bReturn As Boolean = True
            If IsQuantityValid() Then
                Dim oCartInfo As New MiniShoppingCartInfo
                Dim oManager As New ShoppingCartController
                'Dim AList As ArrayList = oManager.GetCustomerCart(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, False)

                Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False)

                For i As Integer = 0 To AList.Count - 1
                    Dim CartItemId As Integer = CType(AList(i), ShoppingCartInfo).CartItemId
                    'Dim ProductId As Integer = CType(AList(i), ShoppingCartInfo).ProductId
                    Dim Quantity As TextBox = CType(FindControl("ShoppingCartItemQuantity" & (i + 1)), TextBox)
                    If Not Quantity Is Nothing AndAlso Quantity.Enabled = True Then
                        UpdateCartQuantityByCartItemId(MasterCustomerId, SubCustomerId, CartItemId, CType(Quantity.Text, Integer))
                    End If

                    Dim oController As New ShoppingCartController
                    Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, False, CartItemId)

                    For j As Integer = 0 To CList.Count - 1
                        Dim CartSubItemId As Integer = CType(CList(j), ShoppingCartInfo).CartItemId
                        'Dim ProductId As Integer = CType(AList(i), ShoppingCartInfo).ProductId
                        Dim SubItemQuantity As TextBox = CType(FindControl("ComponentsQuantity" & (i + 1) & (j + 1)), TextBox)
                        If Not Quantity Is Nothing Then
                            UpdateCartQuantityByCartItemId(MasterCustomerId, SubCustomerId, CartSubItemId, CType(SubItemQuantity.Text, Integer))
                        End If
                    Next
                Next


            Else
                bReturn = False
                'Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidQuantity", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If

            Return bReturn

        End Function
        Private Function IsQuantityValid() As Boolean

            Dim Quantity As TextBox

            Dim bReturn As Boolean = True
            'Validate Quantity

            Dim oCartInfo As New MiniShoppingCartInfo
            Dim oManager As New ShoppingCartController

            Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False)
            '            Dim AList As ArrayList = oManager.GetCustomerCart(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, False)

            For i As Integer = 0 To AList.Count - 1
                Quantity = CType(FindControl("ShoppingCartItemQuantity" & (i + 1)), TextBox)

                If Quantity IsNot Nothing AndAlso Quantity.Enabled = True Then
                    If IsNumeric(Quantity.Text) Then
                        If CInt(Quantity.Text) < 1 Then
                            bReturn = False
                        End If
                    Else
                        bReturn = False
                    End If
                    If bReturn = False Then
                        Exit For
                    End If
                End If
                
            Next
            Return bReturn
        End Function

#End Region

#Region "Shopping Cart Helpers"
        Private CreateOrderMaster As Boolean


        Private Sub GetMyShoppingCart()

            Dim oCartInfo As New MiniShoppingCartInfo
            Dim oManager As New ShoppingCartController

            '			Dim AList As ArrayList = oManager.GetCustomerCart(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, False)

            Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False)

            Dim oWishListManager As New ShoppingCartController

            Dim AWishList As ArrayList = oWishListManager.GetCustomerCart(MasterCustomerId, SubCustomerId, True)

            If AList.Count = 0 And AWishList.Count = 0 Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("CartIsEmpty", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                'Return ResolveUrl("~/" & siteimagesFolder & "/btn_emptycart.gif")
                CreateOrderMaster = False
                'Skins.Skin.AddModuleMessage(Me, "HEading", "MEssageText", ResolveUrl("~/" & siteimagesFolder & "/timss-warning-yellow.gif")) '3246-6224780 & 3246-6224731
            Else
                ShoppingCartXslTemplate.XSLfile = Server.MapPath(ModulePath & "Templates\" & CType(Settings(ModuleSettingsNames.C_TEMPLATE_FILE), String))
                CreateOrderMaster = True
                If AList.Count > 0 Then

                    Dim oItems(AList.Count - 1) As ShoppingCartItem
                    Dim showAllBadgeLink As Boolean = False
                    Dim DCDFileTotal As Decimal = 0
                    'Form the parameter list
                    For i As Integer = 0 To AList.Count - 1
                        oItems(i) = New ShoppingCartItem
                        oItems(i).CartItemId = CType(AList(i), ShoppingCartInfo).CartItemId
                        oItems(i).AddDate = CType(AList(i), ShoppingCartInfo).AddDate.ToShortDateString
                        oItems(i).LongName = CType(AList(i), ShoppingCartInfo).LongName
                        'Fixed Ticket #3246-8157039 : Added condition in the below line
                        oItems(i).Price = IIf(CType(AList(i), ShoppingCartInfo).HasValidScheduledPrice, _
                                            Localization.GetString("HideSchedulePriceLabelMessage.Text", LocalResourceFile), FormatAmount(CType(AList(i), ShoppingCartInfo).Price))
                        oItems(i).ProductId = CType(AList(i), ShoppingCartInfo).ProductId
                        oItems(i).Quantity = CType(CType(AList(i), ShoppingCartInfo).Quantity, String)
                        oItems(i).ShipCustomerLabelName = CType(AList(i), ShoppingCartInfo).ShipCustomerLabelName
                        oItems(i).ShortName = CType(AList(i), ShoppingCartInfo).ShortName
                        If oItems(i).ShortName <> String.Empty Then
                            oItems(i).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oItems(i).ProductId
                        End If
                        oItems(i).SubSystem = CType(AList(i), ShoppingCartInfo).Subsystem
                        oItems(i).TotalPrice = FormatAmount(CType(AList(i), ShoppingCartInfo).Price * CType(AList(i), ShoppingCartInfo).Quantity)
                        oItems(i).MaxBadges = CType(CType(AList(i), ShoppingCartInfo).MaxBadges, String)
                        oItems(i).ComponentExist = CType(CType(AList(i), ShoppingCartInfo).ComponentExists, Boolean)
                        oItems(i).MaxTickets = CType(CType(AList(i), ShoppingCartInfo).MaximumTickets, String)


                        If (CType(AList(i), ShoppingCartInfo).Subsystem = "MTG" Or CType(AList(i), ShoppingCartInfo).Subsystem = "XBT") And CType(Settings(ModuleSettingsNames.ShoppingCartShowBadgeLink), String) = "Y" Then
                            'show Edit Badges link only if MTG or XBT subsystem
                            oItems(i).BadgesText = Localization.GetString("BadgesLink.Text", LocalResourceFile)
                            oItems(i).BadgesNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartBadgesUrl), String) & "&ProductId=" & oItems(i).ProductId
                            showAllBadgeLink = True
                            If CType(AList(i), ShoppingCartInfo).Subsystem = "MTG" Then
                                Dim ProductDetails As ProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(oItems(i).ProductId, True, True, True, True, False, Nothing, False, "", 0, True, True, True, True, True)
                                If ProductDetails IsNot Nothing AndAlso ProductDetails.SubProducts IsNot Nothing AndAlso ProductDetails.SubProducts.Length > 0 Then
                                    'Add/Remove Sessions functionality
                                    oItems(i).AddRemoveSessionsText = Localization.GetString("AddRemoveSessionsLink.Text", LocalResourceFile)
                                    oItems(i).AddRemoveSessionsNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartAddRemoveSessionsUrl), String) & "&CartItemId=" & oItems(i).CartItemId & "&ProductId=" & oItems(i).ProductId
                                End If
                            End If
                        End If



                        'if the meeting has badges then add the badge order parameters\
                        If CType(AList(i), ShoppingCartInfo).MaxBadges > 0 Then
                            Dim ABadgeList As ArrayList = oManager.GetBadges(oItems(i).CartItemId)
                            If ABadgeList.Count > 0 Then
                                Dim oBadgeParams(ABadgeList.Count - 1) As OrderEntryParametersForBadges
                                For x As Integer = 0 To ABadgeList.Count - 1
                                    oBadgeParams(x) = New OrderEntryParametersForBadges
                                    oBadgeParams(x).BadgeNumber = CType(ABadgeList(x), BadgeInfo).BadgeNumber
                                    oBadgeParams(x).BadgeTypeCode = CType(ABadgeList(x), BadgeInfo).BadgeTypeCode
                                    oBadgeParams(x).FirstName = CType(ABadgeList(x), BadgeInfo).FirstName
                                    oBadgeParams(x).FullName = CType(ABadgeList(x), BadgeInfo).FullName
                                    oBadgeParams(x).Company = CType(ABadgeList(x), BadgeInfo).Company

                                    oBadgeParams(x).City = CType(ABadgeList(x), BadgeInfo).City
                                    oBadgeParams(x).State = CType(ABadgeList(x), BadgeInfo).State
                                    oBadgeParams(x).PostalCode = CType(ABadgeList(x), BadgeInfo).PostalCode
                                Next
                                oItems(i).Badges = oBadgeParams

                            End If
                        End If


                        Dim oController As New ShoppingCartController
                        'Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, False, oItems(i).CartItemId)
                       'Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(lg2.MasterCustomerId, lg2.SubCustomerId, False, oItems(i).CartItemId)
                        If oItems(i).ComponentExist Then
                            Dim CList As ArrayList = oController.GetShoppingCartComponentsByCartItemId(MasterCustomerId, SubCustomerId, oItems(i).CartItemId, False, PortalId)
                            If CList.Count > 0 Then


                                Dim oComponentItems(CList.Count - 1) As ShoppingCartComponentsItem
                                For j As Integer = 0 To CList.Count - 1
                                    oComponentItems(j) = New ShoppingCartComponentsItem
                                    oComponentItems(j).ProductId = CType(CList(j), ShoppingCartComponentInfo).ProductId
                                    oComponentItems(j).CartItemId = CType(CList(j), ShoppingCartComponentInfo).CartItemId
                                    oComponentItems(j).ShortName = CType(CList(j), ShoppingCartComponentInfo).ShortName
                                    oComponentItems(j).LongName = CType(CList(j), ShoppingCartComponentInfo).LongName
                                    oComponentItems(j).AddDate = CType(CList(j), ShoppingCartComponentInfo).AddDate.ToString
                                    oComponentItems(j).ComponentProductId = CType(CList(j), ShoppingCartComponentInfo).ComponentProductId
                                    oComponentItems(j).ComponentCartItemId = CType(CList(j), ShoppingCartComponentInfo).ComponentCartItemId
                                    'an cuna fix
                                    oComponentItems(j).MaxTickets = CType(CList(j), ShoppingCartComponentInfo).MaxTickets
                                    oComponentItems(j).Subsystem = CType(CList(j), ShoppingCartComponentInfo).Subsystem
                                    oComponentItems(j).ProductType = CType(CList(j), ShoppingCartComponentInfo).ProductType

                                    If oComponentItems(j).ShortName <> String.Empty Then
                                        oComponentItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oComponentItems(j).ComponentProductId
                                    End If
                                Next
                                oItems(i).Components = oComponentItems

                            End If
                        End If

                        'Get Sub Products.
                        Dim SList As ArrayList = oController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, False, oItems(i).CartItemId)

                        If SList.Count > 0 Then

                            Dim oSubProductItems(SList.Count - 1) As ShoppingCartItem
                            For j As Integer = 0 To SList.Count - 1
                                oSubProductItems(j) = New ShoppingCartItem
                                oSubProductItems(j).ProductId = CType(SList(j), ShoppingCartInfo).ProductId
                                oSubProductItems(j).CartItemId = CType(SList(j), ShoppingCartInfo).CartItemId
                                oSubProductItems(j).ShortName = CType(SList(j), ShoppingCartInfo).ShortName
                                oSubProductItems(j).LongName = CType(SList(j), ShoppingCartInfo).LongName
                                oSubProductItems(j).Price = FormatAmount(CType(SList(j), ShoppingCartInfo).Price)
                                oSubProductItems(j).Quantity = CType(CType(SList(j), ShoppingCartInfo).Quantity, String)
                                oSubProductItems(j).TotalPrice = FormatAmount(CType(SList(j), ShoppingCartInfo).Price * CType(SList(j), ShoppingCartInfo).Quantity)
                                'an cuna fix
                                oSubProductItems(j).MaxTickets = CType(SList(j), ShoppingCartInfo).MaximumTickets
                                oSubProductItems(j).SubSystem = CType(SList(j), ShoppingCartInfo).Subsystem
                                oSubProductItems(j).ProductType = CType(SList(j), ShoppingCartInfo).ProductType
                                If oSubProductItems(j).ShortName <> String.Empty Then
                                    oSubProductItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oSubProductItems(j).ProductId
                                End If
                            Next
                            oItems(i).SubProducts = oSubProductItems

                        End If

                        'Get DCD Files
                        Dim DCDExtraFileTotal As Decimal = 0
                        If CType(AList(i), ShoppingCartInfo).Subsystem.ToUpper = "ECD" Then
                            Dim DCDFileList As ArrayList = oController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, oItems(i).CartItemId, False, PortalId)

                            If DCDFileList.Count > 0 Then
                                DCDExtraFileTotal = CType(oItems(i).Price, Decimal) * (DCDFileList.Count - 1)
                                Dim oDCDFileItems(DCDFileList.Count - 1) As ShoppingCartDCDFilesItem
                                For j As Integer = 0 To DCDFileList.Count - 1
                                    oDCDFileItems(j) = New ShoppingCartDCDFilesItem
                                    oDCDFileItems(j).CartItemFileId = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).CartItemFileId
                                    oDCDFileItems(j).CartItemId = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).CartItemId
                                    oDCDFileItems(j).CopyrightText = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).CopyrightText
                                    oDCDFileItems(j).DisplayCopyright = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).DisplayCopyright
                                    oDCDFileItems(j).DocumentTitle = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).DocumentTitle
                                    oDCDFileItems(j).ProductId = CType(DCDFileList(j), ShoppingCartDCDFilesInfo).ProductId
                                    If oDCDFileItems(j).DocumentTitle <> String.Empty Then
                                        oDCDFileItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oDCDFileItems(j).ProductId
                                    End If
                                Next
                                oItems(i).DCDFiles = oDCDFileItems
                            End If
                        End If
                        DCDFileTotal = DCDFileTotal + DCDExtraFileTotal
                    Next

                    ' Get, format and construct the subtotal from the 
                    ' Localized string
                    'oCartInfo = oManager.GetMiniShoppingCart(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId)
                    oCartInfo = oManager.GetMiniShoppingCart(MasterCustomerId, SubCustomerId)

                    'Dim SubTotal As String = String.Format(Localization.GetString("lblSubTotal", LocalResourceFile), oCartInfo.ShoppingCartTotal)
                    Dim SubTotal As String = String.Format("{0} {1}", PortalCurrency.Symbol, (oCartInfo.ShoppingCartTotal + DCDFileTotal))
                    'SubTotal = CType(CType(SubTotal, Decimal) + DCDFileTotal, String)
                    ShoppingCartXslTemplate.AddObject("Subtotal", SubTotal)
                    If CType(Settings(ModuleSettingsNames.ShoppingCartShowBadgeLink), String) = "Y" AndAlso showAllBadgeLink Then
                        Dim EditAllBadgesText As String
                        Dim EditAllBadgesNavigateURL As String


                        EditAllBadgesText = Localization.GetString("EditAllBadgesLink.Text", LocalResourceFile)
                        EditAllBadgesNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartBadgesUrl), String)
                        ShoppingCartXslTemplate.AddObject("EditAllBadgesText", EditAllBadgesText)
                        ShoppingCartXslTemplate.AddObject("EditAllBadgesNavigateURL", EditAllBadgesNavigateURL)

                    End If

                    ShoppingCartXslTemplate.AddObject("", oItems)

                    oCartInfo = Nothing
                    oManager = Nothing


                End If

            'WishList
            If AWishList.Count > 0 Then
                Dim WishListItemsCount As Integer = AWishList.Count
                ShoppingCartXslTemplate.AddObject("WishListItemsCount", WishListItemsCount)

                Dim oWishListItems(AWishList.Count - 1) As ShoppingCartItem

                'Form the parameter list
                For i As Integer = 0 To AWishList.Count - 1
                        oWishListItems(i) = New ShoppingCartItem
                        oWishListItems(i).CartItemId = CType(AWishList(i), ShoppingCartInfo).CartItemId
                        oWishListItems(i).AddDate = CType(AWishList(i), ShoppingCartInfo).AddDate.ToShortDateString
                        oWishListItems(i).LongName = CType(AWishList(i), ShoppingCartInfo).LongName
                        oWishListItems(i).Price = FormatAmount(CType(AWishList(i), ShoppingCartInfo).Price)
                        oWishListItems(i).ProductId = CType(AWishList(i), ShoppingCartInfo).ProductId
                        oWishListItems(i).Quantity = CType(CType(AWishList(i), ShoppingCartInfo).Quantity, String)
                        oWishListItems(i).MaxTickets = CType(AWishList(i), ShoppingCartInfo).MaximumTickets

                        oWishListItems(i).ShipCustomerLabelName = CType(AWishList(i), ShoppingCartInfo).ShipCustomerLabelName
                        oWishListItems(i).ShortName = CType(AWishList(i), ShoppingCartInfo).ShortName
                        If oWishListItems(i).ShortName <> String.Empty Then
                            oWishListItems(i).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oWishListItems(i).ProductId
                        End If
                        oWishListItems(i).TotalPrice = FormatAmount(CType(AWishList(i), ShoppingCartInfo).Price * CType(AWishList(i), ShoppingCartInfo).Quantity)
                        oWishListItems(i).ComponentExist = CType(CType(AWishList(i), ShoppingCartInfo).ComponentExists, Boolean)




                        Dim oController As New ShoppingCartController
                        'Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(lg4.MasterCustomerId, lg4.SubCustomerId, False, oWishListItems(i).CartItemId)
                        ''Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, False, oWishListItems(i).CartItemId)
                        'If CList.Count > 0 Then

                        '    Dim oComponentItems(CList.Count - 1) As ShoppingCartItem
                        '    For j As Integer = 0 To CList.Count - 1
                        '        oComponentItems(j) = New ShoppingCartItem
                        '        oComponentItems(j).ProductId = CType(CList(i), ShoppingCartInfo).ProductId
                        '        oComponentItems(j).CartItemId = CType(CList(i), ShoppingCartInfo).CartItemId
                        '        oComponentItems(j).ShortName = CType(CList(i), ShoppingCartInfo).ShortName
                        '        oComponentItems(j).LongName = CType(CList(i), ShoppingCartInfo).LongName
                        '        oComponentItems(j).Price = String.Format("{0:c}", CType(CList(i), ShoppingCartInfo).Price)
                        '        oComponentItems(j).Quantity = CType(CType(CList(i), ShoppingCartInfo).Quantity, String)
                        '        oComponentItems(j).TotalPrice = String.Format("{0:c}", CType(CList(i), ShoppingCartInfo).Price * CType(AList(i), ShoppingCartInfo).Quantity)
                        '        If oComponentItems(j).ShortName <> String.Empty Then
                        '            oComponentItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oComponentItems(j).ProductId
                        '        End If
                        '    Next
                        '    oWishListItems(i).Components = oComponentItems

                        'End If
                        If oWishListItems(i).ComponentExist Then
                            Dim CWList As ArrayList = oController.GetShoppingCartComponentsByCartItemId(MasterCustomerId, SubCustomerId, oWishListItems(i).CartItemId, True, PortalId)
                            If CWList.Count > 0 Then


                                Dim oComponentItems(CWList.Count - 1) As ShoppingCartComponentsItem
                                For j As Integer = 0 To CWList.Count - 1
                                    oComponentItems(j) = New ShoppingCartComponentsItem
                                    oComponentItems(j).ProductId = CType(CWList(j), ShoppingCartComponentInfo).ProductId
                                    oComponentItems(j).CartItemId = CType(CWList(j), ShoppingCartComponentInfo).CartItemId
                                    oComponentItems(j).ShortName = CType(CWList(j), ShoppingCartComponentInfo).ShortName
                                    oComponentItems(j).LongName = CType(CWList(j), ShoppingCartComponentInfo).LongName
                                    oComponentItems(j).AddDate = CType(CWList(j), ShoppingCartComponentInfo).AddDate.ToString
                                    oComponentItems(j).ComponentProductId = CType(CWList(j), ShoppingCartComponentInfo).ComponentProductId
                                    oComponentItems(j).ComponentCartItemId = CType(CWList(j), ShoppingCartComponentInfo).ComponentCartItemId
                                    oComponentItems(j).MaxTickets = CType(CWList(j), ShoppingCartComponentInfo).MaxTickets

                                    If oComponentItems(j).ShortName <> String.Empty Then
                                        oComponentItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oComponentItems(j).ComponentProductId
                                    End If
                                Next
                                oWishListItems(i).Components = oComponentItems

                            End If
                        End If

                        Dim WSList As ArrayList = oController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, True, oWishListItems(i).CartItemId)

                        If WSList.Count > 0 Then

                            Dim oSubProductItems(WSList.Count - 1) As ShoppingCartItem

                            For j As Integer = 0 To WSList.Count - 1
                                oSubProductItems(j) = New ShoppingCartItem
                                oSubProductItems(j).ProductId = CType(WSList(j), ShoppingCartInfo).ProductId
                                oSubProductItems(j).CartItemId = CType(WSList(j), ShoppingCartInfo).CartItemId
                                oSubProductItems(j).ShortName = CType(WSList(j), ShoppingCartInfo).ShortName
                                oSubProductItems(j).LongName = CType(WSList(j), ShoppingCartInfo).LongName
                                oSubProductItems(j).Price = FormatAmount(CType(WSList(j), ShoppingCartInfo).Price)
                                oSubProductItems(j).Quantity = CType(CType(WSList(j), ShoppingCartInfo).Quantity, String)
                                oSubProductItems(j).TotalPrice = FormatAmount(CType(WSList(j), ShoppingCartInfo).Price * CType(WSList(j), ShoppingCartInfo).Quantity)
                                If oSubProductItems(j).ShortName <> String.Empty Then
                                    oSubProductItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oSubProductItems(j).ProductId
                                End If
                            Next
                            oWishListItems(i).SubProducts = oSubProductItems

                        End If

                        'Get DCD Files
                        If CType(AWishList(i), ShoppingCartInfo).Subsystem.ToUpper = "ECD" Then
                            Dim WDCDFileList As ArrayList = oController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, oWishListItems(i).CartItemId, True, PortalId)

                            If WDCDFileList.Count > 0 Then
                                Dim oWDCDFileItems(WDCDFileList.Count - 1) As ShoppingCartDCDFilesItem
                                For j As Integer = 0 To WDCDFileList.Count - 1
                                    oWDCDFileItems(j) = New ShoppingCartDCDFilesItem
                                    oWDCDFileItems(j).CartItemFileId = CType(WDCDFileList(j), ShoppingCartDCDFilesInfo).CartItemFileId
                                    oWDCDFileItems(j).CartItemId = CType(WDCDFileList(j), ShoppingCartDCDFilesInfo).CartItemId
                                    oWDCDFileItems(j).CopyrightText = CType(WDCDFileList(j), ShoppingCartDCDFilesInfo).CopyrightText
                                    oWDCDFileItems(j).DisplayCopyright = CType(WDCDFileList(j), ShoppingCartDCDFilesInfo).DisplayCopyright
                                    oWDCDFileItems(j).DocumentTitle = CType(WDCDFileList(j), ShoppingCartDCDFilesInfo).DocumentTitle
                                    oWDCDFileItems(j).ProductId = CType(WDCDFileList(j), ShoppingCartDCDFilesInfo).ProductId
                                    If oWDCDFileItems(j).DocumentTitle <> String.Empty Then
                                        oWDCDFileItems(j).ProductNavigateURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartDetailUrl), String) & "&ProductId=" & oWDCDFileItems(j).ProductId
                                    End If
                                Next
                                oWishListItems(i).DCDFiles = oWDCDFileItems
                            End If
                        End If



                    Next

                oWishListManager = Nothing
                If oWishListItems IsNot Nothing AndAlso oWishListItems.Length > 0 Then
                    ShoppingCartXslTemplate.AddObject("WishListItems", oWishListItems)
                End If
            End If

                '3246-5774803
                Dim MoveToCartImageURL As String = GetMoveToCartImageURL()
                ShoppingCartXslTemplate.AddObject("MoveToCartImageURL", MoveToCartImageURL)
                Dim EmptyCartImageURL As String = GetEmptyCartImageURL()
                ShoppingCartXslTemplate.AddObject("EmptyCartImageURL", EmptyCartImageURL)
                Dim CheckoutImageURL As String = GetCheckoutImageURL()
                ShoppingCartXslTemplate.AddObject("CheckoutImageURL", CheckoutImageURL)
                Dim UpdateCartImageURL As String = GetUpdateCartImageURL()
                ShoppingCartXslTemplate.AddObject("UpdateCartImageURL", UpdateCartImageURL)
                Dim DeleteItemImageURL As String = GetDeleteItemImageURL()
                ShoppingCartXslTemplate.AddObject("DeleteItemImageURL", DeleteItemImageURL)
                Dim WishListImageURL As String = GetWishListImageURL()
                ShoppingCartXslTemplate.AddObject("WishListImageURL", WishListImageURL)
                'end 3246-5774803
                Dim ExpandImageURL As String = GetExpandImageURL()
                ShoppingCartXslTemplate.AddObject("ExpandImageURL", ExpandImageURL)
                Dim CollapseImageURL As String = GetCollapseImageURL()
                ShoppingCartXslTemplate.AddObject("CollapseImageURL", CollapseImageURL)
                ShoppingCartXslTemplate.AddObject("ModuleId", ModuleId.ToString)
            ShoppingCartXslTemplate.Display()

            For i As Integer = 0 To AList.Count - 1
                Dim btnSaveItemInWishList As ImageButton = CType(FindControl("btnSaveItemInWishList" & (i + 1)), ImageButton)
                If btnSaveItemInWishList IsNot Nothing Then
                    AddHandler btnSaveItemInWishList.Command, AddressOf DoCartOperations
                End If
                Dim btnDeleteCartItem As ImageButton = CType(FindControl("btnDeleteCartItem" & (i + 1)), ImageButton)
                If btnDeleteCartItem IsNot Nothing Then
                    AddHandler btnDeleteCartItem.Command, AddressOf DoCartOperations
                    btnDeleteCartItem.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteCartItem", LocalResourceFile) & "');")
                End If

                Dim oController As New ShoppingCartController
                    Dim CList As ArrayList = oController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, False, CType(AList(i), ShoppingCartInfo).CartItemId)

                    For j As Integer = 0 To CList.Count - 1
                        Dim btnDeleteCartSubItem As ImageButton = CType(FindControl("btnDeleteComponentItem" & (i + 1) & (j + 1)), ImageButton)
                        If btnDeleteCartSubItem IsNot Nothing Then
                            AddHandler btnDeleteCartSubItem.Command, AddressOf DoCartOperations
                            btnDeleteCartSubItem.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteCartItem", LocalResourceFile) & "');")
                        End If
                    Next

                    Dim DCDFileList As ArrayList = oController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, CType(AList(i), ShoppingCartInfo).CartItemId, False, PortalId)
                    For j As Integer = 0 To DCDFileList.count - 1
                        Dim btnDeleteDCDFilesItem As ImageButton = CType(FindControl(String.Concat("btnDeleteDCDFilesItem", (i + 1), (j + 1))), ImageButton)

                        If btnDeleteDCDFilesItem IsNot Nothing Then
                            AddHandler btnDeleteDCDFilesItem.Command, AddressOf DoCartOperations
                            btnDeleteDCDFilesItem.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteCartItem", LocalResourceFile) & "');")
                        End If
                    Next
                Next

                For i As Integer = 0 To AWishList.Count - 1
                    Dim btnWishListSaveItemInWishList As ImageButton = CType(FindControl("btnWishListSaveItemInWishList" & (i + 1)), ImageButton)
                    If btnWishListSaveItemInWishList IsNot Nothing Then
                        AddHandler btnWishListSaveItemInWishList.Command, AddressOf DoCartOperations
                    End If

                    Dim btnWishListDeleteCartItem As ImageButton = CType(FindControl("btnWishListDeleteCartItem" & (i + 1)), ImageButton)
                    If btnWishListDeleteCartItem IsNot Nothing Then
                        AddHandler btnWishListDeleteCartItem.Command, AddressOf DoCartOperations
                        btnWishListDeleteCartItem.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteWishListItem", LocalResourceFile) & "');")
                    End If

                    Dim oWishListController As New ShoppingCartController
                    Dim WList As ArrayList = oWishListController.GetProductComponentsByCartItemID(MasterCustomerId, SubCustomerId, True, CType(AWishList(i), ShoppingCartInfo).CartItemId)

                    For j As Integer = 0 To WList.Count - 1
                        Dim btnDeleteWishListSubItem As ImageButton = CType(FindControl("btnWishListDeleteComponentItem" & (i + 1) & (j + 1)), ImageButton)
                        If btnDeleteWishListSubItem IsNot Nothing Then
                            AddHandler btnDeleteWishListSubItem.Command, AddressOf DoCartOperations
                            btnDeleteWishListSubItem.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteCartItem", LocalResourceFile) & "');")
                        End If
                    Next

                    Dim WishListDCDFileList As ArrayList = oWishListController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, CType(AWishList(i), ShoppingCartInfo).CartItemId, True, PortalId)
                    For j As Integer = 0 To WishListDCDFileList.Count - 1
                        Dim btnWishListDeleteDCDFilesItem As ImageButton = CType(FindControl(String.Concat("btnWishListDeleteDCDFilesItem", (i + 1), (j + 1))), ImageButton)

                        If btnWishListDeleteDCDFilesItem IsNot Nothing Then
                            AddHandler btnWishListDeleteDCDFilesItem.Command, AddressOf DoCartOperations
                            btnWishListDeleteDCDFilesItem.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteCartItem", LocalResourceFile) & "');")
                        End If
                    Next
                Next
                Dim btnReturn As ImageButton = CType(FindControl("btnReturn"), ImageButton)
                If btnReturn IsNot Nothing Then
                    AddHandler btnReturn.Command, AddressOf DoCartOperations
                End If
                Dim btnUpdateCart As ImageButton = CType(FindControl("btnUpdateCart"), ImageButton)
                If btnUpdateCart IsNot Nothing Then
                    AddHandler btnUpdateCart.Command, AddressOf DoCartOperations
                End If
                Dim btnEmptyCart As ImageButton = CType(FindControl("btnEmptyCart"), ImageButton)
                If btnEmptyCart IsNot Nothing Then
                    AddHandler btnEmptyCart.Command, AddressOf DoCartOperations
                    btnEmptyCart.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("EmptyCart", LocalResourceFile) & "');")
                End If

                Dim btnCheckout1 As ImageButton = CType(FindControl("btnCheckout1"), ImageButton)
                If btnCheckout1 IsNot Nothing Then
                    AddHandler btnCheckout1.Command, AddressOf DoCartOperations
                End If

                Dim btnContinue As LinkButton = CType(FindControl("btnContinue"), LinkButton)
                If btnContinue IsNot Nothing Then
                    AddHandler btnContinue.Command, AddressOf DoCartOperations
                End If


            End If


        End Sub



        Private Sub EmptyCart()

            Dim oController As New ShoppingCartController
            oController.DeleteCart(MasterCustomerId, SubCustomerId, PortalId)
            'oController.DeleteCart(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId)
            'For Components.
            oController.DeleteShoppingCartComponents(MasterCustomerId, SubCustomerId, PortalId)
            'For DCD Files.
            oController.DeleteShoppingCartDCDFiles(MasterCustomerId, SubCustomerId, PortalId)
            oController = Nothing
            'Auto Login
            'Dim loginStatus As DotNetNuke.Security.Membership.UserLoginStatus
            'Dim oLoginManager As New Personify.LoginManager()
            'Dim objUser As UserInfo

            'oLoginManager.Login("awilson", "awilson123", loginStatus, objUser)
            'If loginStatus = DotNetNuke.Security.Membership.UserLoginStatus.LOGIN_SUCCESS Then
            '    Response.Redirect(NavigateURL(), True)
            'End If

        End Sub

        'Private Sub UpdateCartQuantity(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal ProductId As Integer, ByVal Quantity As Integer)
        '	Dim oController As New ShoppingCartController
        '	oController.UpdateCartQuantity(MasterCustomerId, SubCustomerId, ProductId, Quantity)
        '	oController = Nothing
        'End Sub
        Private Sub UpdateCartQuantityByCartItemId(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal CartItemId As Integer, ByVal Quantity As Integer)
            Dim oController As New ShoppingCartController
            oController.UpdateCartQuantityByCartItemId(MasterCustomerId, SubCustomerId, CartItemId, Quantity)

            'get badges for the cart item id
            If oController.GetBadges(CartItemId).Count > Quantity Then
                oController.DeleteBadges(CartItemId)
            End If

            '            
            oController = Nothing
        End Sub

        Private Sub DeleteCartItem(ByVal ProductId As Integer, ByVal IsWishList As Boolean)
            Try
                Dim oController As New ShoppingCartController
                'oController.DeleteCartItem(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, ProductId, IsWishList)
                oController.DeleteCartItem(MasterCustomerId, SubCustomerId, ProductId, IsWishList, PortalId)
                oController = Nothing

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub DeleteCartItemByCartItemID(ByVal CartItemID As Integer, ByVal IsWishList As Boolean)
            Try
                Dim oController As New ShoppingCartController


                'oController.DeleteCartItemByCartItemId(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, CartItemID, IsWishList)
                oController.DeleteCartItemByCartItemId(MasterCustomerId, SubCustomerId, CartItemID, IsWishList)
                'Delete associated component items.
                oController.DeleteShoppingCartComponentsItemByCartItemId(MasterCustomerId, SubCustomerId, CartItemID)
                'Delete associated DCD files items.
                oController.DeleteShoppingCartDCDFilesItemByCartItemId(MasterCustomerId, SubCustomerId, CartItemID)
                oController = Nothing

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        'Delete DCD Files by CartItemFileID
        Private Sub DeleteDCDFilesByCartItemFileID(ByVal CartItemFileID As Integer)
            Try
                Dim oController As New ShoppingCartController

                oController.DeleteShoppingCartDCDFilesItemByCartItemFileId(MasterCustomerId, SubCustomerId, CartItemFileID)
                oController = Nothing

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub MoveItem(ByVal ProductId As Integer, ByVal IsWishList As Boolean)
            Try
                Dim oController As New ShoppingCartController

                oController.MoveItem(MasterCustomerId, SubCustomerId, ProductId, IsWishList)
                'oController.MoveItem(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, ProductId, IsWishList)
                oController = Nothing

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub MoveItemByCartItemID(ByVal Productid As Integer, ByVal CartItemID As Integer, ByVal IsWishList As Boolean)
            Try
                Dim oController As New ShoppingCartController


                oController.MoveItemByCartItemID(MasterCustomerId, SubCustomerId, CartItemID, IsWishList)
                'oController.MoveItemByCartItemID(ApplicationManager.Customer.GetAnonymousUserId(MasterCustomerId), SubCustomerId, CartItemID, IsWishList)
                'Move Componenets.
                oController.MoveCartComponentsItem(MasterCustomerId, SubCustomerId, CartItemID, IsWishList)
                'Move DCD Files.
                oController.MoveCartDCDFilesItem(MasterCustomerId, SubCustomerId, CartItemID, IsWishList)
                oController = Nothing

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Protected Function GetImage(ByVal ImageName As String) As String
            Return ModulePath & ImageName
        End Function
#End Region

        Private Sub ClearValidationIssues()
            'Clear the existing validation issues if they exist
            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If
        End Sub

        Private Sub CheckOut()

            If Me.IsPersonifyWebUserLoggedIn = False Then

                '                If UserInfo.Profile.ProfileProperties("MasterCustomerId") Is Nothing Then
                'TODO - Redirect to login page

                Response.Redirect(EditSetting_Checkout_RedirectToLoginURL)
                Exit Sub
            End If

            'Update cart --- then checkout

            UpdateShoppingCart()
            Dim strURL As String

            strURL = "~/Default.aspx?tabid=" & CType(Settings(ModuleSettingsNames.ShoppingCartCheckOutUrl), String)
            Response.Redirect(strURL)

            Exit Sub

            'To do RTW: unused code START HERE




            'REdirect only if all the issues have been resp0onded ... add the check here

        End Sub

        Private Function ValidatePreCheckoutCondition() As Boolean
            Dim oManager As New ShoppingCartController
            Dim AList As ArrayList = oManager.GetCustomerCart(MasterCustomerId, SubCustomerId, False)
            Dim AcceptedTerm As Boolean = True
            Dim SameMTGCartItem As Boolean = False
            _mtgProductList = New ArrayList
            If AList.Count > 0 Then
                For i As Integer = 0 To AList.Count - 1
                    If CType(AList(i), ShoppingCartInfo).Subsystem.ToUpper = "ECD" Then
                        CheckProductAcceptTerm(CType(AList(i), ShoppingCartInfo), oManager, AcceptedTerm)
                    ElseIf CType(AList(i), ShoppingCartInfo).Subsystem.ToUpper = "MTG" AndAlso Not SameMTGCartItem Then
                        'AN commenting this out
                        ' SameMTGCartItem = CheckMTGDuplicateCartItem(CType(AList(i), ShoppingCartInfo))
                    End If
                Next
            End If

            If Not AcceptedTerm Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AcceptTerm.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'AN commenting this out
            'If SameMTGCartItem Then
            '    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("DuplicateMTGCartItemMessage.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            '    Return False
            'End If

            Return True
        End Function

        Private Sub CheckProductAcceptTerm(ByVal ShoppingCartItem As ShoppingCartInfo, ByVal CartController As ShoppingCartController, ByRef AcceptedTerm As Boolean)

            Dim DCDFileList As ArrayList = CartController.GetShoppingCartDCDFilesByCartItemId(MasterCustomerId, SubCustomerId, ShoppingCartItem.CartItemId, False, PortalId)
            If DCDFileList.Count > 0 Then
                For j As Integer = 0 To DCDFileList.Count - 1
                    If CType(DCDFileList(j), ShoppingCartDCDFilesInfo).DisplayCopyright Then
                        Dim tempCheckBox As CheckBox

                        tempCheckBox = CType(Me.FindControl(String.Concat("chkAcceptTerm_", ModuleId.ToString, "_", CType(DCDFileList(j), ShoppingCartDCDFilesInfo).CartItemFileId.ToString)), CheckBox)
                        If Not tempCheckBox Is Nothing AndAlso tempCheckBox.GetType Is GetType(CheckBox) Then
                            If Not (Request(tempCheckBox.UniqueID) = "on") Then
                                AcceptedTerm = False
                            End If
                        End If
                    End If
                Next
            End If
        End Sub

        Private Function CheckMTGDuplicateCartItem(ByVal ShoppingCartItem As ShoppingCartInfo) As Boolean
            If _mtgProductList.Contains(ShoppingCartItem.ProductId) AndAlso _
                                        ShoppingCartItem.RelatedCartItemId = 0 AndAlso _
                                        String.IsNullOrEmpty(ShoppingCartItem.ShipMasterCustomerId) Then
                Return True
            End If
            _mtgProductList.Add(ShoppingCartItem.ProductId)
            Return False
        End Function

        Private Function GetExpandImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/expand.gif")
        End Function
        Private Function GetCollapseImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/collapse.gif")
        End Function

        Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
            Dim ScriptPath As String = ResolveUrl(path)
            If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
                Dim script As StringBuilder = New StringBuilder
                script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
                script = Nothing
            End If
        End Sub
#Region "Image Function"
        '3246-5774803
        Private Function GetMoveToCartImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_movetocart.gif")
        End Function
        Private Function GetEmptyCartImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_emptycart.gif")
        End Function
        Private Function GetUpdateCartImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_updatecart.gif")
        End Function
        Private Function GetCheckoutImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_checkout.gif")
        End Function
        Private Function GetDeleteItemImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_deleteitem.gif")
        End Function
        Private Function GetWishListImageURL() As String
            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_wishlist.gif")
        End Function
        'END 3246-5774803
#End Region
    End Class


    Public Class ShoppingCartItem
        Public AddDate As String
        Public ShipCustomerLabelName As String
        Public ProductId As Integer
        Public CartItemId As Integer
        Public ShortName As String
        Public ProductNavigateURL As String
        Public LongName As String
        Public MaxBadges As String
        Public BadgesText As String
        Public BadgesNavigateURL As String
        Public AddRemoveSessionsText As String
        Public AddRemoveSessionsNavigateURL As String
        Public Price As String
        Public Quantity As String
        Public TotalPrice As String
        Public SubSystem As String
        Public ProductType As String
        Public MaxTickets As Integer
        'Modified for components
        Public Components() As ShoppingCartComponentsItem
        Public SubProducts() As ShoppingCartItem
        Public Badges() As OrderEntryParametersForBadges
        Public StartEndDate As String 'added 10-05-2007 for membership & subscription products
        Public ComponentExist As Boolean
        Public DCDFiles() As ShoppingCartDCDFilesItem
    End Class

    'Added class for DCD Files
    Public Class ShoppingCartDCDFilesItem
        Public CartItemFileId As Integer
        Public CartItemId As Integer
        Public DocumentTitle As String
        Public DisplayCopyright As Boolean
        Public CopyrightText As String
        Public ProductNavigateURL As String
        Public ProductId As Integer
    End Class

    'Added class for components
    Public Class ShoppingCartComponentsItem
        Public AddDate As String
        Public ProductId As Integer
        Public CartItemId As Integer
        Public ShortName As String
        Public LongName As String
        Public MaxTickets As Integer
        Public ComponentCartItemId As Integer
        Public ComponentProductId As Integer
        Public ProductNavigateURL As String
        'AN Cuna fix
        Public Subsystem As String
        Public ProductType As String
    End Class
End Namespace
