Namespace Personify.DNN.Modules.Reporting

    Public Class ModuleSettingsNames

        Public Const C_FRAMEBORDER As String = "IFrame_Frameborder"
        Public Const C_HEIGHT As String = "IFrame_Height"
        Public Const C_WIDTH As String = "IFrame_Width"
        Public Const C_SCROLLING As String = "IFrame_Scrolling"
        Public Const C_DISPLAY_REPORT_IN_IFRAME As String = "DisplayReportInIFrame"
        Public Const C_DEFAULT_REPORT_NAME As String = "IFrame_Default_Report_Name"
        Public Const C_ALIGN As String = "IFrame_Align"
        Public Const C_SELECTEDREPORTS As String = "Selected_Reports"
    End Class
End Namespace