Imports System
Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.Reporting
Imports DotNetNuke
Imports DotNetNuke.Services.Exceptions.Exceptions
Imports System.Configuration
Imports System.IO



Namespace Personify.DNN.Modules.Reporting

    Public MustInherit Class ReportingMasterList
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdReportNameWithPath As System.Web.UI.WebControls.DataGrid
#End Region

#Region "Private Variables"
        Protected dsReport As New System.Data.DataSet
        Protected dtReport As New DataTable
        Protected oRow As DataRow
        Protected dt As DataTable = New DataTable

        Private row As System.Web.UI.WebControls.TableRow
        Private cell As System.Web.UI.WebControls.TableCell
        Private ImagePath As String = String.Concat("~/", SiteImagesFolder)
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    LoadData()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadData()
            Dim orow As DataRow
            dt.Columns.Add(New DataColumn("ReportFriendlyName", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportNameWithPath", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportIconFileName", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("Id", GetType(String)))
            dt.Columns.Add(New DataColumn("DeleteIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("UpdateIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("EditIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("CancelIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("PreviewIcon", GetType(String)))

            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifyReportSettings", PortalId), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    orow = dt.NewRow
                    orow("ReportFriendlyName") = oSiteData.Item("ReportFriendlyName").ToString
                    orow("ReportNameWithPath") = oSiteData.Item("ReportNameWithPath").ToString
                    orow("ReportIconFileName") = oSiteData.Item("ReportIconPath").ToString
                    orow("ReportIcon") = (String.Concat(ImagePath, "/", oSiteData.Item("ReportIconPath").ToString)).ToString
                    orow("Id") = oSiteData.Item("Id").ToString
                    orow("DeleteIcon") = (String.Concat(ImagePath, DotNetNuke.Services.Localization.Localization.GetString("DeleteIcon", LocalResourceFile))).ToString
                    orow("UpdateIcon") = (String.Concat(ImagePath, DotNetNuke.Services.Localization.Localization.GetString("UpdateIcon", LocalResourceFile))).ToString
                    orow("EditIcon") = (String.Concat(ImagePath, DotNetNuke.Services.Localization.Localization.GetString("EditIcon", LocalResourceFile))).ToString
                    orow("CancelIcon") = (String.Concat(ImagePath, DotNetNuke.Services.Localization.Localization.GetString("CancelIcon", LocalResourceFile))).ToString
                    orow("PreviewIcon") = (String.Concat(ImagePath, DotNetNuke.Services.Localization.Localization.GetString("PreviewIcon", LocalResourceFile))).ToString
                    dt.Rows.Add(orow)
                End While
            End If

            grdReportNameWithPath.DataSource = dt
            grdReportNameWithPath.DataBind()
        End Sub

        Public Sub grdReportNameWithPath_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdReportNameWithPath.EditCommand
            grdReportNameWithPath.EditItemIndex = e.Item.ItemIndex
            grdReportNameWithPath.ShowFooter = False
            LoadData()
        End Sub

        Private Sub grdReportNameWithPath_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdReportNameWithPath.ItemCommand
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
            Dim sqlParamArr(5) As SqlParameter
            sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
            sqlParamArr(1) = New SqlParameter("@ReportFriendlyName", SqlDbType.NVarChar, 256)
            sqlParamArr(2) = New SqlParameter("@ReportNameWithPath", SqlDbType.NVarChar, 256)
            sqlParamArr(3) = New SqlParameter("@ReportIconPath", SqlDbType.NVarChar, 256)
            sqlParamArr(4) = New SqlParameter("@id", SqlDbType.Int)

            If e.CommandName = "Delete" Then
                sqlParamArr(0).Value = PortalId.ToString
                sqlParamArr(4).Value = CType(CType(e.Item.FindControl("lblId"), Label).Text, Integer)
                Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(localConnectionString, "dbo." & "" & "DeletePersonifyReportSettings", sqlParamArr(0), sqlParamArr(4))
                grdReportNameWithPath.ShowFooter = True
                grdReportNameWithPath.EditItemIndex = -1
                LoadData()
            ElseIf e.CommandName = "Update" Then
                Dim txtReportNameWithPath As TextBox = CType(e.Item.FindControl("editReportPath"), TextBox)
                Dim txtFriendlyReportName As TextBox = CType(e.Item.FindControl("editReportName"), TextBox)
                Dim ddlReportIcon As DropDownList = CType(e.Item.FindControl("editReportIconFileName"), DropDownList)

                If txtReportNameWithPath IsNot Nothing AndAlso txtFriendlyReportName IsNot Nothing AndAlso ddlReportIcon IsNot Nothing Then
                    If txtReportNameWithPath.Text.Length > 0 AndAlso txtFriendlyReportName.Text.Length > 0 Then

                        sqlParamArr(0).Value = PortalId.ToString
                        sqlParamArr(1).Value = CType(CType(e.Item.FindControl("editReportName"), TextBox).Text, String)
                        sqlParamArr(2).Value = CType(CType(e.Item.FindControl("editReportPath"), TextBox).Text, String)
                        sqlParamArr(3).Value = CType(CType(e.Item.FindControl("editReportIconFileName"), DropDownList).SelectedValue, String)
                        sqlParamArr(4).Value = CType(CType(e.Item.FindControl("lblId"), Label).Text, Integer)

                        Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(localConnectionString, "dbo." & "" & "UpdatePersonifyReportSettings", sqlParamArr(0), sqlParamArr(4), sqlParamArr(1), sqlParamArr(2), sqlParamArr(3))
                    End If
                End If
                grdReportNameWithPath.ShowFooter = True
                grdReportNameWithPath.EditItemIndex = -1
                LoadData()
            ElseIf e.CommandName = "Cancel" Then
                grdReportNameWithPath.EditItemIndex = -1
                grdReportNameWithPath.ShowFooter = True
                LoadData()
            ElseIf e.CommandName = "Add" Then
                Dim txtReportNameWithPath As TextBox = CType(e.Item.FindControl("addReportPath"), TextBox)
                Dim txtFriendlyReportName As TextBox = CType(e.Item.FindControl("addReportname"), TextBox)
                Dim ddlReportIcon As DropDownList = CType(e.Item.FindControl("addReportIconFileName"), DropDownList)

                If txtReportNameWithPath IsNot Nothing AndAlso txtFriendlyReportName IsNot Nothing AndAlso ddlReportIcon IsNot Nothing Then
                    If txtReportNameWithPath.Text.Length > 0 AndAlso txtFriendlyReportName.Text.Length > 0 Then

                        sqlParamArr(0).Value = PortalId.ToString
                        sqlParamArr(1).Value = txtFriendlyReportName.Text.ToString
                        sqlParamArr(2).Value = txtReportNameWithPath.Text.ToString
                        sqlParamArr(3).Value = ddlReportIcon.SelectedValue.ToString

                        Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(localConnectionString, "dbo." & "" & "AddPersonifyReportSettings", sqlParamArr(0), sqlParamArr(1), sqlParamArr(2), sqlParamArr(3))

                        txtReportNameWithPath.Text = ""
                        txtFriendlyReportName.Text = ""
                    End If
                End If
                grdReportNameWithPath.ShowFooter = True
                grdReportNameWithPath.EditItemIndex = -1
                LoadData()
            End If
        End Sub



#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

        Protected Sub ReportIconLoad(ByVal sender As Object, ByVal e As System.EventArgs)
            Dim ReportIconList As System.Web.UI.WebControls.DropDownList = CType(sender, System.Web.UI.WebControls.DropDownList)

            If ReportIconList IsNot Nothing Then
                Dim tempSelectedValue As String = ReportIconList.SelectedValue.ToString
                Dim dInfo As New DirectoryInfo(MapPathSecure(ImagePath))
                ' Create an array representing the files in the current directory.
                Dim fInfo As FileInfo() = dInfo.GetFiles()
                Dim fiTemp As FileInfo
                ReportIconList.Items.Clear()
                For Each fiTemp In fInfo
                    Dim ListItem As New System.Web.UI.WebControls.ListItem
                    ListItem.Text = fiTemp.Name
                    ListItem.Value = fiTemp.Name
                    ReportIconList.Items.Add(ListItem)
                    ListItem = Nothing
                Next fiTemp
                dInfo = Nothing
                If Not tempSelectedValue = "" Then
                    ReportIconList.SelectedValue = tempSelectedValue
                End If
            End If
        End Sub

        Protected Sub LaunchPreview(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
            Dim ReportInstance As Boolean = False
            Dim Status As String = ""
            Dim ReportKind As String = ""
            Dim LastRunDateTime As String = ""

            Dim _clsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)

            Response.Write(String.Concat("<script type='text/javascript'>detailedresults=window.open('", _clsReporting.GenerateReportURL(PortalId, CType(sender, ImageButton).ToolTip, ReportInstance, Status, ReportKind, LastRunDateTime), "');</script>"))

            _clsReporting = Nothing
        End Sub

        Protected Sub AddIconLoad(ByVal sender As Object, ByVal e As System.EventArgs)
            Dim AddIcon As ImageButton = CType(sender, ImageButton)

            AddIcon.ImageUrl = (String.Concat(ImagePath, DotNetNuke.Services.Localization.Localization.GetString("AddIcon", LocalResourceFile))).ToString
        End Sub

#End Region

    End Class

End Namespace
