Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Drawing
Imports System.Threading
Imports DotNetNuke
Imports DotNetNuke.UI
Imports DotNetNuke.Services.Exceptions.Exceptions
Imports DotNetNuke.Services.Localization


Namespace Personify.DNN.Modules.Reporting

    Public MustInherit Class Reporting
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"
        'Protected WithEvents lbtnReport As System.Web.UI.WebControls.LinkButton
        'Protected WithEvents lnkReport As System.Web.UI.WebControls.HyperLink
        Private row As System.Web.UI.WebControls.TableRow
        Private cell As System.Web.UI.WebControls.TableCell
        Protected WithEvents ReportInfo As New System.Web.UI.WebControls.Table

#End Region
        Protected dt As DataTable = New DataTable
        Private DefaultReportPath As String

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    'lbtnReport.Visible = True

                    LoadData()
                    'ReportPlaceHolder
                    For Each orow As DataRow In dt.Rows
                        If IfReportSelected(orow("ReportFriendlyName")) Then
                            AddRow(orow("ReportFriendlyName"), orow("ReportNameWithPath"), orow("ReportIcon"))
                        End If
                    Next
                    If Settings(ModuleSettingsNames.C_DISPLAY_REPORT_IN_IFRAME) IsNot Nothing AndAlso Settings(ModuleSettingsNames.C_DISPLAY_REPORT_IN_IFRAME) = "Y" Then
                        LoadIFrame(True)
                    Else
                        LoadIFrame(False)
                    End If
                Else
                    LoadIFrame(False)
                    DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub



        Private Function IfReportSelected(ByVal FriendlyName As String) As Boolean
            If Settings(ModuleSettingsNames.C_SELECTEDREPORTS) IsNot Nothing AndAlso Not Settings(ModuleSettingsNames.C_SELECTEDREPORTS) = "" Then
                Dim SelectedReportList As String = Settings(ModuleSettingsNames.C_SELECTEDREPORTS)

                Dim ReportList() As String = SelectedReportList.Split(",")

                For Each ReportName As String In ReportList
                    If ReportName = FriendlyName Then
                        Return True
                    End If
                Next
                Return False
            Else
                Return False
            End If
        End Function

        Private Sub AddRow(ByVal FriendlyName As String, ByVal ReportPath As String, ByVal ReportIcon As String)

            row = New System.Web.UI.WebControls.TableRow

            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(GetImageControl(ReportIcon))
            cell.Wrap = False
            cell.Width = CType(Unit.Percentage(3), System.Web.UI.WebControls.Unit)
            cell.HorizontalAlign = HorizontalAlign.Left
            row.Cells.Add(cell)
            ReportInfo.Rows.Add(row)

            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(GetLinkButtonControl(FriendlyName, ReportPath))
            cell.Wrap = False
            cell.HorizontalAlign = HorizontalAlign.Left
            row.Cells.Add(cell)
            ReportInfo.Rows.Add(row)

        End Sub

        Public Function GetLinkButtonControl(ByVal FriendlyName As String, ByVal ReportPath As String) As System.Web.UI.Control
            Dim lnkButton As New System.Web.UI.WebControls.LinkButton

            With lnkButton
                .ForeColor = Color.Black
                .Text = FriendlyName
                .ToolTip = ReportPath
                .EnableViewState = True
            End With
            AddHandler lnkButton.Click, AddressOf EventHandler

            Return lnkButton
        End Function

        Public Function GetImageControl(ByVal ReportIcon As String) As System.Web.UI.Control
            Dim imgReportIcon As New System.Web.UI.WebControls.Image

            With imgReportIcon
                .ImageUrl = String.Concat("~/", SiteImagesFolder, "/", ReportIcon)
                .EnableViewState = True
            End With

            Return imgReportIcon
        End Function

        Sub EventHandler(ByVal sender As Object, ByVal e As System.EventArgs)
            ' Handle the event.
            '
            Try
                LaunchReport(CType(sender, LinkButton).ToolTip)
            Catch ex As Exception
                Throw ex
            End Try

        End Sub



        Private Function GetReportName(ByVal ReportNameWithPath As String) As String
            Dim arrFolder() As String = ReportNameWithPath.Split("/")

            If arrFolder(arrFolder.Length - 1) IsNot Nothing AndAlso arrFolder(arrFolder.Length - 1).Length > 0 Then
                Return arrFolder(arrFolder.Length - 1)
            Else
                Return ReportNameWithPath
            End If
        End Function
#End Region

#Region "Optional Interfaces"
        Private Sub LoadData()
            Dim orow As DataRow
            dt.Columns.Add(New DataColumn("ReportFriendlyName", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportNameWithPath", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("Id", GetType(String)))

            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifyReportSettings", PortalId), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    orow = dt.NewRow
                    orow("ReportFriendlyName") = oSiteData.Item("ReportFriendlyName").ToString
                    orow("ReportNameWithPath") = oSiteData.Item("ReportNameWithPath").ToString
                    orow("ReportIcon") = oSiteData.Item("ReportIconPath").ToString
                    If oSiteData.Item("ReportFriendlyName").ToString = Settings(ModuleSettingsNames.C_DEFAULT_REPORT_NAME) Then
                        DefaultReportPath = oSiteData.Item("ReportNameWithPath").ToString
                    End If
                    orow("Id") = oSiteData.Item("Id").ToString
                    dt.Rows.Add(orow)
                End While
            End If
        End Sub

        Public Overrides ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)

                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.EditContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.EditContent, "", "", EditUrl("EditMasterReportList"), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

     
        Private Function GetURL(ByVal ReportPath As String) As String
            Dim ReportInstance As Boolean = False
            Dim Status As String = ""
            Dim ReportKind As String = ""
            Dim LastRunDateTime As String = ""
            Dim strReportaPath As String = ""

            If ReportPath.Length = 0 Then
                Return ""
            End If

            Dim _ClsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)
            strReportaPath = _ClsReporting.GenerateReportURL(PortalId, ReportPath, ReportInstance, Status, ReportKind, LastRunDateTime)

            If strReportaPath IsNot Nothing Then
                Return strReportaPath
            End If

            _ClsReporting = Nothing
            'Launch the url in a new browser
        End Function

        

        Private Sub LaunchReport(ByVal ReportPath As String)
            Dim URL As String
            Dim ReleaseURL As String
            URL = GetURL(ReportPath)
            If URL.Length > 0 Then
                'Response.Redirect(URL)

                Dim _ClsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)
                If URL.IndexOf("ProxySession") > 0 Then
                    'Fire the URL to release the session
                    ReleaseURL = _ClsReporting.GetReleaseURL(True)
                Else
                    'Fire the URL to release the session
                    ReleaseURL = _ClsReporting.GetReleaseURL(False)
                End If

                'Response.Write("<script type='text/javascript'>var detailedresults=window.open('" & URL & "');</script>")

                'Begin - Java Script to release the BO License
                Dim sb = New System.Text.StringBuilder()
                sb.Append("<script language='javascript'>")
                sb.Append("var windObj = null;")
                sb.Append("var RepObj = null;")
                sb.Append("var timer;")
                sb.Append("windObj = window.open('")
                sb.Append(URL)
                sb.Append("');")
                sb.Append("timer = setInterval('polling()', 500);")
                sb.Append("function polling() {")
                sb.Append("if (windObj && windObj.closed) {")
                sb.Append("clearInterval(timer);")
                sb.Append("RepObj = window.open('")
                sb.Append(ReleaseURL)
                sb.Append("','Report', 'toolbar=0,menubar=0,resizable=0,left=4000,directories=0,width=1,height=1');")
                sb.Append("RepObj.close();")
                sb.Append("}}")

                'Commented out for now
                'sb.Append("if(typeof window.addEventListener != 'undefined') {")
                'sb.Append("window.addEventListener('beforeunload', ReleaseLicense, false);}")
                'sb.Append(" else if (typeof document.addEventListener != 'undefined') {")
                'sb.Append("document.addEventListener('beforeunload', ReleaseLicense, false);}")
                'sb.Append(" else if (typeof window.attachEvent != 'undefined') {")
                'sb.Append("window.attachEvent('onbeforeunload', ReleaseLicense);}")

                'sb.Append("function ReleaseLicense() {")
                'sb.Append("RepObj = window.open('")
                'sb.Append(ReleaseURL)
                'sb.Append("','Report', 'toolbar=0,menubar=0,resizable=0,left=4000,directories=0,width=1,height=1');")
                'sb.Append("RepObj.close();}")


                sb.Append("</script>")

                Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "InitializeJS", sb.ToString)
                'End - Java Script to release the BO License
                
            Else
                Exit Sub
            End If
        End Sub

        Private Sub LoadIFrame(ByVal Display As Boolean)
            Dim ReportIFrame As HtmlControls.HtmlControl = CType(Me.FindControl("ReportIFrame"), HtmlControls.HtmlControl)

            If Not Display Then
                ReportIFrame.Visible = False
                ReportInfo.Visible = True
                Exit Sub
            End If

            ReportInfo.Visible = False
            Dim URL As String

            If DefaultReportPath IsNot Nothing Then
                URL = GetURL(DefaultReportPath)
                If URL.Length = 0 Then
                    Exit Sub
                End If
            Else
                Exit Sub
            End If
            ReportIFrame.Attributes.Add("src", URL)

            If Settings(ModuleSettingsNames.C_FRAMEBORDER) IsNot Nothing Then
                ReportIFrame.Attributes.Add("frameborder", Settings(ModuleSettingsNames.C_FRAMEBORDER))
            Else
                ReportIFrame.Attributes.Add("frameborder", "0")
            End If

            If Settings(ModuleSettingsNames.C_HEIGHT) IsNot Nothing Then
                ReportIFrame.Attributes.Add("height", Settings(ModuleSettingsNames.C_HEIGHT))
            Else
                ReportIFrame.Attributes.Add("height", "200")
            End If

            If Settings(ModuleSettingsNames.C_WIDTH) IsNot Nothing Then
                ReportIFrame.Attributes.Add("width", Settings(ModuleSettingsNames.C_WIDTH))
            Else
                ReportIFrame.Attributes.Add("width", "200")
            End If

            If Settings(ModuleSettingsNames.C_SCROLLING) IsNot Nothing Then
                ReportIFrame.Attributes.Add("scrolling", GetScrollingOption(Settings(ModuleSettingsNames.C_SCROLLING)))
            Else
                ReportIFrame.Attributes.Add("scrolling", "Auto")
            End If

            If Settings(ModuleSettingsNames.C_ALIGN) IsNot Nothing Then
                ReportIFrame.Attributes.Add("align", GetAlignOption(Settings(ModuleSettingsNames.C_ALIGN)))
            Else
                ReportIFrame.Attributes.Add("align", "Left")
            End If


            Dim _ClsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)
            Dim ReleaseURL As String

            If URL.IndexOf("ProxySession") > 0 Then
                'Fire the URL to release the session
                ReleaseURL = _ClsReporting.GetReleaseURL(True)
            Else
                'Fire the URL to release the session
                ReleaseURL = _ClsReporting.GetReleaseURL(False)
            End If

            'Begin - Java Script to release the BO License
            Dim sb = New System.Text.StringBuilder()
            sb.Append("<script language='javascript'>")
            sb.Append("var RepObj = null;")
            sb.Append("function ReleaseLicense() {")
            sb.Append("RepObj = window.open('")
            sb.Append(ReleaseURL)
            sb.Append("','Report', 'toolbar=0,menubar=0,resizable=0,left=4000,directories=0,width=1,height=1');")
            sb.Append("RepObj.close();}")

            sb.Append("if(typeof window.addEventListener != 'undefined') {")
            sb.Append("window.addEventListener('unload', ReleaseLicense, false);}")
            sb.Append(" else if (typeof document.addEventListener != 'undefined') {")
            sb.Append("document.addEventListener('unload', ReleaseLicense, false);}")
            sb.Append(" else if (typeof window.attachEvent != 'undefined') {")
            sb.Append("window.attachEvent('onunload', ReleaseLicense);}")

            sb.Append("</script>")

            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "InitializeJS", sb.ToString)
            'End - Java Script to release the BO License


        End Sub

        Private Function GetScrollingOption(ByVal value As Integer) As String
            Select Case value
                Case ScrollingOptions.AUTO
                    Return "Auto"
                Case ScrollingOptions.YES
                    Return "Yes"
                Case ScrollingOptions.NO
                    Return "No"
            End Select
            Return "Auto"
        End Function

        Private Function GetAlignOption(ByVal value As Integer) As String
            Select Case value
                Case AlignOptions.LEFT
                    Return "Left"
                Case AlignOptions.RIGHT
                    Return "Right"
                Case AlignOptions.TOP
                    Return "Top"
                Case AlignOptions.MIDDLE
                    Return "Middle"
                Case AlignOptions.BOTTOM
                    Return "Bottom"
            End Select
            Return "Left"
        End Function

        Private Enum ScrollingOptions
            AUTO = 0
            YES = 1
            NO = 2
        End Enum

        Private Enum AlignOptions
            LEFT = 0
            RIGHT = 1
            TOP = 2
            MIDDLE = 3
            BOTTOM = 4
        End Enum
    End Class




End Namespace
