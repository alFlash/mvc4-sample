Imports System
Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.Reporting
Imports DotNetNuke
Imports DotNetNuke.Services.Exceptions.Exceptions
Imports System.Configuration
Imports System.IO



Namespace Personify.DNN.Modules.Reporting

    Public MustInherit Class ReportingEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents rbtDisplayMode As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents txtIFrameHeight As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtIFrameWidth As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkIFrameFrameborder As System.Web.UI.WebControls.CheckBox
        Protected WithEvents ddlIFrameScrolling As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlIFrameDefaultReportName As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlIFrameAlign As System.Web.UI.WebControls.DropDownList
        Protected WithEvents pnlIframeProperties As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlReportList As System.Web.UI.WebControls.Panel
        Protected WithEvents tblReportList As System.Web.UI.WebControls.Table
#End Region

#Region "Private Variables"
        Protected dsReport As New System.Data.DataSet
        Protected dtReport As New DataTable
        Protected oRow As DataRow
        Protected dt As DataTable = New DataTable

        Private row As System.Web.UI.WebControls.TableRow
        Private cell As System.Web.UI.WebControls.TableCell
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub AddNewRow(ByVal Column1 As String, ByVal Column2 As String, ByVal column3 As String)
            If dsReport IsNot Nothing Then
                oRow = dsReport.Tables(0).NewRow()
                oRow.Item("ReportFriendlyName") = Column1
                oRow.Item("ReportNameWithPath") = Column2
                oRow.Item("ReportIcon") = column3
                dsReport.Tables(0).Rows.Add(oRow)
            End If

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                UpdateSettings()
                Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub LoadData()
            Dim orow As DataRow
            dt.Columns.Add(New DataColumn("ReportFriendlyName", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportNameWithPath", GetType(String)))
            dt.Columns.Add(New DataColumn("ReportIcon", GetType(String)))
            dt.Columns.Add(New DataColumn("Id", GetType(String)))

            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifyReportSettings", PortalId), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    orow = dt.NewRow
                    orow("ReportFriendlyName") = oSiteData.Item("ReportFriendlyName").ToString
                    orow("ReportNameWithPath") = oSiteData.Item("ReportNameWithPath").ToString
                    orow("ReportIcon") = oSiteData.Item("ReportIconPath").ToString
                    orow("Id") = oSiteData.Item("Id").ToString
                    dt.Rows.Add(orow)
                End While
            End If

        End Sub
        Private Sub LoadReportName()
            For Each oRow As DataRow In dt.Rows
                Dim ListItem As New System.Web.UI.WebControls.ListItem

                ListItem.Text = oRow("ReportFriendlyName").ToString
                ListItem.Value = oRow("ReportFriendlyName").ToString
                ddlIFrameDefaultReportName.Items.Add(ListItem)
                ListItem = Nothing
            Next
        End Sub

        Private Sub LoadSettings()
            If Not Settings(ModuleSettingsNames.C_DISPLAY_REPORT_IN_IFRAME) Is Nothing AndAlso (CType(Settings(ModuleSettingsNames.C_DISPLAY_REPORT_IN_IFRAME), String) = "Y") Then
                rbtDisplayMode.SelectedValue = "0"

                pnlIframeProperties.Visible = True
                pnlReportList.Visible = False
            Else
                rbtDisplayMode.SelectedValue = "1"

                pnlIframeProperties.Visible = False
                pnlReportList.Visible = True
            End If

            If Not Settings(ModuleSettingsNames.C_HEIGHT) Is Nothing Then
                txtIFrameHeight.Text = CType(Settings(ModuleSettingsNames.C_HEIGHT), String)
            End If

            If Not Settings(ModuleSettingsNames.C_WIDTH) Is Nothing Then
                txtIFrameWidth.Text = CType(Settings(ModuleSettingsNames.C_WIDTH), String)
            End If

            If Not Settings(ModuleSettingsNames.C_FRAMEBORDER) Is Nothing Then
                chkIFrameFrameborder.Checked = CBool(IIf(CType(Settings(ModuleSettingsNames.C_FRAMEBORDER), String) = "Y", True, False))
            End If

            If Not Settings(ModuleSettingsNames.C_SCROLLING) Is Nothing Then
                ddlIFrameScrolling.SelectedValue = CType(Settings(ModuleSettingsNames.C_SCROLLING), String)
            End If

            If Not Settings(ModuleSettingsNames.C_DEFAULT_REPORT_NAME) Is Nothing Then
                ddlIFrameDefaultReportName.SelectedValue = CType(Settings(ModuleSettingsNames.C_DEFAULT_REPORT_NAME), String)
            End If

            If Not Settings(ModuleSettingsNames.C_ALIGN) Is Nothing Then
                ddlIFrameAlign.SelectedValue = CType(Settings(ModuleSettingsNames.C_ALIGN), String)
            End If
        End Sub

        Private Sub LoadReportList()
            For Each orow As DataRow In dt.Rows
                AddRow(orow("Id"), orow("ReportFriendlyName"), orow("ReportIcon"))
            Next
        End Sub

        Private Sub AddRow(ByVal ReportID As String, ByVal FriendlyName As String, ByVal ReportIcon As String)
            row = New System.Web.UI.WebControls.TableRow

            cell = New System.Web.UI.WebControls.TableCell
            Dim imgReportIcon As New System.Web.UI.WebControls.Image
            imgReportIcon.ImageUrl = String.Concat("~/", SiteImagesFolder, "/", ReportIcon)
            cell.Controls.Add(imgReportIcon)
            cell.Width = CType(Unit.Percentage(3), System.Web.UI.WebControls.Unit)
            cell.Wrap = False
            cell.HorizontalAlign = HorizontalAlign.Left
            row.Cells.Add(cell)

            cell = New System.Web.UI.WebControls.TableCell
            Dim lblReportFriendlyName As New System.Web.UI.WebControls.Label
            lblReportFriendlyName.Text = FriendlyName
            cell.Controls.Add(lblReportFriendlyName)
            cell.Width = CType(Unit.Percentage(10), System.Web.UI.WebControls.Unit)
            cell.Wrap = False
            cell.HorizontalAlign = HorizontalAlign.Left
            row.Cells.Add(cell)

            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(GetCheckBox(FriendlyName, ReportID))
            cell.Wrap = False
            cell.HorizontalAlign = HorizontalAlign.Left
            row.Cells.Add(cell)

            tblReportList.Rows.Add(row)
        End Sub

        Private Function GetCheckBox(ByVal FriendlyName As String, ByVal ReportID As String) As System.Web.UI.Control
            Dim chkSelectReport As New System.Web.UI.WebControls.CheckBox
            chkSelectReport.ID = String.Concat("chkReport_", ReportID)
            chkSelectReport.Checked = IfReportSelected(FriendlyName)
            chkSelectReport.EnableViewState = True
            Return chkSelectReport
        End Function

        Private Function IfReportSelected(ByVal FriendlyName As String) As Boolean
            If Settings(ModuleSettingsNames.C_SELECTEDREPORTS) IsNot Nothing AndAlso Not Settings(ModuleSettingsNames.C_SELECTEDREPORTS) = "" Then
                Dim SelectedReportList As String = Settings(ModuleSettingsNames.C_SELECTEDREPORTS)

                Dim ReportList() As String = SelectedReportList.Split(",")

                For Each ReportName As String In ReportList
                    If ReportName = FriendlyName Then
                        Return True
                    End If
                Next
                Return False
            Else
                Return False
            End If
        End Function

        Private Sub UpdateSettings()
          UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

            UpdateModuleSetting(ModuleSettingsNames.C_DISPLAY_REPORT_IN_IFRAME, IIf(rbtDisplayMode.SelectedValue = "0", "Y", "N"))
            UpdateModuleSetting(ModuleSettingsNames.C_HEIGHT, txtIFrameHeight.Text)
            UpdateModuleSetting(ModuleSettingsNames.C_WIDTH, txtIFrameWidth.Text)
            UpdateModuleSetting(ModuleSettingsNames.C_FRAMEBORDER, IIf(chkIFrameFrameborder.Checked, "Y", "N"))
            UpdateModuleSetting(ModuleSettingsNames.C_SCROLLING, ddlIFrameScrolling.SelectedValue)
            UpdateModuleSetting(ModuleSettingsNames.C_DEFAULT_REPORT_NAME, ddlIFrameDefaultReportName.SelectedValue)
            UpdateModuleSetting(ModuleSettingsNames.C_ALIGN, ddlIFrameAlign.SelectedValue)

            If Not rbtDisplayMode.SelectedValue = "0" Then
                Dim SelectedReports As String = ""
                For Each orow As DataRow In dt.Rows
                    If tblReportList.FindControl(String.Concat("chkReport_", orow("Id"))) IsNot Nothing Then
                        If CType(tblReportList.FindControl(String.Concat("chkReport_", orow("Id"))), System.Web.UI.WebControls.CheckBox).Checked Then
                            If SelectedReports = "" Then
                                SelectedReports = String.Concat(SelectedReports, orow("ReportFriendlyName"))
                            Else
                                SelectedReports = String.Concat(SelectedReports, ",", orow("ReportFriendlyName"))
                            End If
                        End If
                    End If
                Next

                UpdateModuleSetting(ModuleSettingsNames.C_SELECTEDREPORTS, SelectedReports)
            End If


        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            LoadData()
            LoadReportList()
            LoadSettings()
            LoadReportName()
        End Sub

#End Region


        Protected Sub rbtDisplayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtDisplayMode.SelectedIndexChanged
            If CType(sender, RadioButtonList).SelectedValue = "0" Then
                pnlIframeProperties.Visible = True
                pnlReportList.Visible = False
            Else
                pnlIframeProperties.Visible = False
                pnlReportList.Visible = True
            End If
        End Sub
    End Class

End Namespace
