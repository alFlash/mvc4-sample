Namespace Personify.DNN.Modules.MyMeetings

    Public Class ModuleSettingsNames
        Public Const MyMeetingOrderUrl As String = "MyMeetingOrderUrl"
        Public Const MyMeetingDetailUrl As String = "MyMeetingDetailUrl"
        Public Const MyMeetingAgendaUrl As String = "MyMeetingAgendaUrl"
        Public Const MyMeetingAllMeetingsUrl As String = "MyMeetingAllMeetingsUrl"
        Public Const MyMeetingOrderUrlType As String = "MyMeetingOrderUrlType"
        Public Const MyMeetingDetailUrlType As String = "MyMeetingDetailUrlType"
        Public Const MyMeetingAgendaUrlType As String = "MyMeetingAgendaUrlType"
        Public Const MyMeetingAllMeetingsUrlType As String = "MyMeetingAllMeetingsUrlType"
        Public Const MyMeetingDisplayAllMeetings As String = "MyMeetingDisplayAllMeetings"
        Public Const ShowHotelReservationLinkInPopup As String = "ShowHotelReservationLinkInPopup"
    End Class

End Namespace