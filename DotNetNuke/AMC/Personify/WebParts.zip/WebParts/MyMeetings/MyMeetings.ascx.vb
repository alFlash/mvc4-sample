Option Strict Off

Imports System
Imports System.Web
Imports DotNetNuke
Imports Personify.DNN.Modules.MyMeetings.Business


Namespace Personify.DNN.Modules.MyMeetings

    Public MustInherit Class MyMeetings
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        'Private MasterCustomerId As String
        'Private SubCustomerId As Integer

#Region " Properties "
        'Dim _datasource As DataTable
        Private _DisplayAllMeetings As Boolean
        Private _ViewAgendaActionTab As Integer
        Private _ViewOrderActionTab As Integer
        Private _ViewAllActionURL As String

        Friend Property DisplayAllMeetings() As Boolean
            Get
                Return _DisplayAllMeetings
            End Get
            Set(ByVal Value As Boolean)
                _DisplayAllMeetings = Value
            End Set
        End Property

        Friend Property ViewAgendaActionTab() As Integer
            Get
                Return _ViewAgendaActionTab
            End Get
            Set(ByVal Value As Integer)
                _ViewAgendaActionTab = Value
            End Set
        End Property


        Friend Property ViewOrderActionTab() As Integer
            Get
                Return _ViewOrderActionTab
            End Get
            Set(ByVal Value As Integer)
                _ViewOrderActionTab = Value
            End Set
        End Property

        Friend Property ViewAllActionURL() As String
            Get
                Return _ViewAllActionURL
            End Get
            Set(ByVal Value As String)
                _ViewAllActionURL = Value
            End Set
        End Property
#End Region

#Region "Controls"
        Protected WithEvents ceva As System.Web.UI.WebControls.Label
        'Protected WithEvents dlstAllMeetings As System.Web.UI.WebControls.DataList
        Protected WithEvents lblNoMeetingsMessage As System.Web.UI.WebControls.Label
        Protected WithEvents pnlMeetingInfo As System.Web.UI.WebControls.Panel
        'Protected WithEvents hypViewAll As System.Web.UI.WebControls.HyperLink
        'Public WithEvents lblShowing As System.Web.UI.WebControls.Label
        Protected MeetingTemplate As Personify.WebControls.XslTemplate
        'Protected WithEvents h As LinkButton

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks></remarks>
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)

                If Personify.ApplicationManager.AffiliateManagementSessionHelper.IsManagingAffiliate(PortalId) OrElse Me.IsPersonifyWebUserLoggedIn = True OrElse role = "personifyuser" OrElse role = "personifyadmin" Then
                    '3246-7278052
                    'If Not Page.IsPostBack Then
                    If MasterCustomerId <> "" Then
                        ReadWebPartSettings()
                        BindMeetingData()
                    Else
                        pnlMeetingInfo.Visible = False
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                    'End If

                Else 'The current user does not have these attributes
                    pnlMeetingInfo.Visible = False
                    Me.DisplayUserAccessMessage(role)
                End If


                Dim PressedButton As String = CheckIfPostBackByButton("imgPrintBadge")
                If Not String.IsNullOrEmpty(PressedButton) Then

                    PressedButton = PressedButton.Substring(PressedButton.LastIndexOf("$") + 1)
                    PressedButton = PressedButton.Substring(0, PressedButton.IndexOf("."))


                    Dim ProductCode As String = Request(PressedButton + "_1")
                    Dim ShipMasterCustomerId As String = Request(PressedButton + "_2")
                    Dim ShipSubCustomerId As String = Request(PressedButton + "_3")

                    Dim oclsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)

                    Dim PrintBadgeURL As String = GetPrintBadgeMeetingURL(OrganizationId, OrganizationUnitId, ProductCode, ShipMasterCustomerId, Convert.ToString(ShipSubCustomerId))

                    If Not String.IsNullOrEmpty(PrintBadgeURL) AndAlso IsValidUrl(PrintBadgeURL) Then

                        Response.Redirect(PrintBadgeURL)
                    Else
                        Dim RawUrl As String = Request.RawUrl
                        If RawUrl.IndexOf("?") > 0 Then
                            RawUrl += "&"
                        Else
                            RawUrl += "?"
                        End If
                        RawUrl += "error=" + PrintBadgeURL
                        Response.Redirect(RawUrl)
                    End If
                End If

                If IsPostBack Then
                    If Request("__EVENTTARGET").IndexOf("lbtnHotelReservation_") > 0 Then
                        Dim strEventTarget As String = Request("__EVENTTARGET")
                        Dim str As String() = strEventTarget.Split("_")
                        If str.Length = 3 Then
                            LinkToHotelBlockingReservation(str(1), str(2))
                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Function IsValidUrl(ByVal url As String) As Boolean
            Return System.Text.RegularExpressions.Regex.IsMatch(url, _
                "(http|ftp|https)://([\w-]+\.)+(/[\w- ./?%&=]*)?")
        End Function

        Private Function CheckIfPostBackByButton(ByVal strControlName As String) As String
            Dim bReturn As String = ""
            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(strControlName) > 0 Then
                    bReturn = Key
                    Exit For
                End If
            Next
            Return bReturn
        End Function


        Private Function GetPrintBadgeMeetingURL(ByVal OrgId As String, ByVal OrgUnitId As String, ByVal ProductCode As String, ByVal ShipMCID As String, ByVal ShipSubId As Integer) As String
            Dim strURL As String = ""
            Dim strStatus As String = ""

            Dim oclsReporting As New Personify.ApplicationManager.Reporting(OrganizationId, OrganizationUnitId)

            strURL = oclsReporting.GetReportURL(PortalId, "MTG1001P", strStatus, OrgId, OrgUnitId, ProductCode, ShipMCID, ShipSubId, "ALL")

            oclsReporting = Nothing

            Return strURL

        End Function

        Private Sub BindMeetingData()
            Dim oMeetingInfo As TIMSS.API.WebInfo.IWebCustomerMeetingInfoViewList = GetMyMeetings(PortalId.ToString, MasterCustomerId, CInt(SubCustomerId), DisplayAllMeetings)
            Dim MeetingList(oMeetingInfo.Count - 1) As MeetingObject
            Dim counter As Integer = 0

            For Each item As TIMSS.API.WebInfo.IWebCustomerMeetingInfoView In oMeetingInfo
                Dim aProduct As TIMSS.API.WebInfo.ITmarWebProductViewList

                aProduct = get_clsProductHelper.GetWebProductInfo(CInt(item.ProductId))

                If aProduct IsNot Nothing AndAlso aProduct.Count > 0 Then
                    Dim myMeetingObject As New MeetingObject

                    myMeetingObject.Description = item.Meetingdesc
                    myMeetingObject.Order_line_no = item.OrderLineNumber.ToString
                    myMeetingObject.Order_no = item.OrderNumber

                    myMeetingObject.StartDate = FormatDateTime(item.Meetingstartdate, DateFormat.ShortDate)
                    myMeetingObject.Url = GetDetailUrl(CType(item.ProductId, Integer))
                    myMeetingObject.increment = counter

                    If Not item.OrderNumber Is Nothing Then
                        Dim strOrderNumber As String = item.OrderNumber
                        strOrderNumber = HttpContext.Current.Server.UrlEncode(strOrderNumber)

                        Dim oOrderDetails As TIMSS.API.OrderInfo.IOrderDetails
                        oOrderDetails = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetails")

                        oOrderDetails.Fill(item.OrderNumber, CType(item.OrderLineNumber, Integer))

                        If oOrderDetails.Count = 1 Then
                            myMeetingObject.CanCreateHotelReservationBridge = oOrderDetails(0).CanCreateHotelReservationBridge
                            myMeetingObject.CanManageHotelReservation = oOrderDetails(0).CanManageHotelReservation
                            If oOrderDetails(0).CanCreateHotelReservationBridge OrElse oOrderDetails(0).CanManageHotelReservation Then
                                myMeetingObject.ShowHotelBlockingLink = True
                            Else
                                myMeetingObject.ShowHotelBlockingLink = False
                            End If
                        Else
                            myMeetingObject.CanCreateHotelReservationBridge = False
                            myMeetingObject.CanManageHotelReservation = False
                            myMeetingObject.ShowHotelBlockingLink = False
                        End If

                        myMeetingObject.ViewOrderUrl = NavigateURL(CType(Settings(ModuleSettingsNames.MyMeetingOrderUrl), Integer), "", "OrderNumber", strOrderNumber)
                        myMeetingObject.ViewAgendaUrl = NavigateURL(CInt(ViewAgendaActionTab), "", "OrderNumber", strOrderNumber)

                        myMeetingObject.ProductCode = item.ProductCode
                        myMeetingObject.ShipMasterCustomerId = item.ShipMasterCustomerId
                        myMeetingObject.ShipSubCustomerId = item.ShipSubCustomerId

                        '3246-5774803
                        myMeetingObject.ViewImageURL = ResolveUrl(GetViewImageURL())
                        myMeetingObject.CalImageURL = ResolveUrl(GetCalImageURL())
                        myMeetingObject.PrintImageURL = ResolveUrl(GetPrintImageURL())
                        myMeetingObject.BriefcaseImageURL = ResolveUrl(GetBriefcaseImageURL())
                        myMeetingObject.IconBlankImageURL = ResolveUrl(GetIconBlankImageURL())
                        'end 3246-5774803

                        'AddSessions                       

                        'aProduct = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "TmarWebProductViewList")
                        'aProduct.Filter.Add("ProductId", CInt(item.ProductId))
                        'aProduct.Fill()

                        If aProduct(0).MeetingLastRegistrationDate > Today Then
                            If item.CurrencyCode = PortalCurrency.Code Then


                                myMeetingObject.AddSessionsText = Localization.GetString("AddSessionsText", LocalResourceFile)
                                myMeetingObject.AddSessionsNavigateURL = NavigateURL(CType(Settings(ModuleSettingsNames.MyMeetingDetailUrl), Integer), "", "OrderNumber=" & strOrderNumber & "&ProductId=" & item.ProductId)
                                myMeetingObject.AddSessionsImageURL = GetAddSessionsImageURL()
                            Else
                                myMeetingObject.AddSessionsText = ""
                                myMeetingObject.AddSessionsNavigateURL = ""
                                myMeetingObject.AddSessionsImageURL = ""
                            End If
                        End If
                        'end AddSessions

                    End If
                    MeetingList(counter) = myMeetingObject
                    counter = counter + 1
                End If
            Next

            'DataSource = CType(oMeetingInfo.Table, DataTable)
            Dim intCurrent As Integer
            Dim templatefile As String = ""
            If Settings("Layout") Is Nothing Then
                templatefile = ModulePath + "Templates\MyMeetingsTemplate.xsl"
            Else
                templatefile = ModulePath + "Templates\" + Settings("Layout").ToString
            End If
            MeetingTemplate.XSLfile = Server.MapPath(templatefile)
            'Dim lblShowing As Label
            Dim hypViewAll As HyperLink

            If Not MeetingList Is Nothing AndAlso MeetingList.Length > 0 Then
                If Not DisplayAllMeetings Then
                    intCurrent = 2
                    If MeetingList.Length = 1 Then intCurrent = 1
                    If MeetingList.Length > 2 Then
                        Array.Clear(MeetingList, 2, MeetingList.Length - 2)
                        MeetingTemplate.AddObject("", MeetingList)

                    Else
                        MeetingTemplate.AddObject("", MeetingList)

                    End If

                Else
                    intCurrent = MeetingList.Length
                    '**Display all data
                    MeetingTemplate.AddObject("", MeetingList)
                End If

                Try
                    MeetingTemplate.Display()
                Catch ex As Exception

                End Try

                hypViewAll = CType(Me.FindControl("hypViewAll".ToString), HyperLink)
                ' lblShowing = CType(Me.FindControl("lblShowing".ToString), Label)
                Try
                    'lblShowing.Text = Localization.GetString("showing", LocalResourceFile) & " " & intCurrent.ToString & " " & Localization.GetString("of", LocalResourceFile) & " " & intTotal.ToString
                Catch ex As Exception

                End Try

                If Not MeetingList Is Nothing AndAlso MeetingList.Length > 0 Then
                    'lblNoMeetingsMessage.Visible = False
                End If
                If Not DisplayAllMeetings Then
                    hypViewAll.NavigateUrl = ViewAllActionURL
                Else
                    hypViewAll.Visible = False   'Hide the button if all rows have been displayed
                End If
                If MeetingList.Length <= 2 Then
                    hypViewAll.Visible = False   'Hide the button if there is no more than 2 rows of data
                End If





            Else
                lblNoMeetingsMessage.Visible = True
            End If
        End Sub

        Private Sub LinkToHotelBlockingReservation(ByVal OrderNumber As String, ByVal OrderLineNumber As String)
            Dim strReservationUrl As String = String.Empty
            Dim oOrderDetails As TIMSS.API.OrderInfo.IOrderDetails
            oOrderDetails = TIMSS.Global.GetCollection(OrganizationId, OrganizationUnitId, TIMSS.Enumerations.NamespaceEnum.OrderInfo, "OrderDetails")

            oOrderDetails.Fill(OrderNumber, CType(OrderLineNumber, Integer))
            If oOrderDetails.Count = 1 Then
                Dim GotoLink As Boolean = True
                If oOrderDetails(0).CanCreateHotelReservationBridge Then
                    If Not oOrderDetails(0).CreateHotelReservationBridgeForShipCustomer() Then
                        GotoLink = False
                    End If
                End If
                If GotoLink Then
                    strReservationUrl = GetHotelReservationURL(oOrderDetails(0))
                    If Not String.IsNullOrEmpty(strReservationUrl) Then
                        If Settings(ModuleSettingsNames.ShowHotelReservationLinkInPopup) IsNot Nothing AndAlso CType(Settings(ModuleSettingsNames.ShowHotelReservationLinkInPopup), String) = "Y" Then
                            Response.Write("<script>")
                            Response.Write(String.Format("window.open('{0}','_blank')", strReservationUrl))
                            Response.Write("</script>")
                        Else
                            Response.Redirect(strReservationUrl)
                        End If
                    End If
                End If
            End If
        End Sub

        Private Function GetHotelReservationURL(ByVal OrderDetail As TIMSS.API.OrderInfo.IOrderDetail) As String
            Dim oOrderDetailHotelNew As TIMSS.API.OrderInfo.IOrderDetailHotel = Nothing
            Dim oOrderDetailHotelModified As TIMSS.API.OrderInfo.IOrderDetailHotel = Nothing
            Dim strUrl As String = String.Empty
            Dim strNewUrl As String = String.Empty
            OrderDetail.OrderDetailHotels.Fill(False, True)
            If OrderDetail.OrderDetailHotels.Count = 1 Then
                strUrl = OrderDetail.OrderDetailHotels(0).HotelReservationURL
            ElseIf OrderDetail.OrderDetailHotels.Count > 1 Then
                oOrderDetailHotelNew = OrderDetail.OrderDetailHotels.FindObject("HotelReservationStatus", "New")
                oOrderDetailHotelModified = OrderDetail.OrderDetailHotels.FindObject("HotelReservationStatus", "Modified")
                If oOrderDetailHotelNew IsNot Nothing Then
                    strUrl = oOrderDetailHotelNew.HotelReservationURL
                ElseIf oOrderDetailHotelModified IsNot Nothing Then
                    strUrl = oOrderDetailHotelModified.HotelReservationURL
                Else
                    strNewUrl = GetNewBridgeUrl(OrderDetail)
                    If Not String.IsNullOrEmpty(strNewUrl) Then
                        strUrl = strNewUrl
                    End If
                End If
            End If
            Return strUrl
        End Function

        Private Function GetNewBridgeUrl(ByVal OrderDetail As TIMSS.API.OrderInfo.IOrderDetail) As String
            Dim strUrl As String = String.Empty
            For Each oOrderDetailHotel As TIMSS.API.OrderInfo.IOrderDetailHotel In OrderDetail.OrderDetailHotels
                If String.IsNullOrEmpty(oOrderDetailHotel.HotelReservationStatus) AndAlso _
                    String.IsNullOrEmpty(oOrderDetailHotel.HotelReservationId) Then
                    strUrl = oOrderDetailHotel.HotelReservationURL
                End If
            Next
            Return strUrl
        End Function


        Private Sub ReadWebPartSettings()
            Dim strActionURL As String
            Dim intViewAllActionTab As Integer


            If Not Settings(ModuleSettingsNames.MyMeetingDisplayAllMeetings) Is Nothing Then
                DisplayAllMeetings = CBool(Settings(ModuleSettingsNames.MyMeetingDisplayAllMeetings))
            End If

            If Not Settings(ModuleSettingsNames.MyMeetingOrderUrl) Is Nothing Then
                ViewOrderActionTab = CInt(Settings(ModuleSettingsNames.MyMeetingOrderUrl))
            End If


            If Not Settings(ModuleSettingsNames.MyMeetingAgendaUrl) Is Nothing Then
                ViewAgendaActionTab = CInt(Settings(ModuleSettingsNames.MyMeetingAgendaUrl))
            End If


            If Not Settings(ModuleSettingsNames.MyMeetingAllMeetingsUrl) Is Nothing Then
                intViewAllActionTab = CInt(Settings(ModuleSettingsNames.MyMeetingAllMeetingsUrl))
            End If

            strActionURL = NavigateURL(CInt(Settings(ModuleSettingsNames.MyMeetingAllMeetingsUrl)))
            ViewAllActionURL = strActionURL

        End Sub

        Public Function GetMyMeetings(ByVal PortalId As String, ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer, ByVal DisplayAll As Boolean) As TIMSS.API.WebInfo.IWebCustomerMeetingInfoViewList


            Dim oWebMeetings As TIMSS.API.WebInfo.IWebCustomerMeetingInfoViewList

            oWebMeetings = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebCustomerMeetingInfoViewList")
            If Not DisplayAll Then
                oWebMeetings.MaximumRows = 3
            End If

            oWebMeetings.Filter.Add("ShipMasterCustomerId", MasterCustomerId)
            oWebMeetings.Filter.Add("ShipSubCustomerId", SubCustomerId.ToString)
            oWebMeetings.Sort("MeetingStartDate", "MeetingDesc")
            oWebMeetings.Fill()

            Return oWebMeetings
        End Function

        Protected Function GetDetailUrl(ByVal ProductId As Integer) As String
            Return NavigateURL(CInt(Settings(ModuleSettingsNames.MyMeetingDetailUrl)), "", "productId", ProductId.ToString)
        End Function
        '3246-5774803

        Private Function GetIconBlankImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/icon_blank.gif")
        End Function
        Private Function GetBriefcaseImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/briefcase.gif")
        End Function
        Private Function GetViewImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/view.gif")
        End Function
        Private Function GetCalImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/cal.GIF")
        End Function
        Private Function GetPrintImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/print.gif")
        End Function
        Private Function GetAddSessionsImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/plus2.gif")
        End Function
        'END 3246-5774803
#End Region

#Region "Optional Interfaces"
        'Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        '    Get
        'Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
        '        Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
        '        Return Actions
        '    End Get
        'End Property

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


    End Class

    Public Class MeetingObject
        Public increment As Integer
        Public Url As String
        Public Description As String
        Public Order_no As String
        Public Order_line_no As String
        Public StartDate As String
        Public ViewOrderUrl As String
        Public ViewAgendaUrl As String
        'Add URL for Print Badges
        Public PrintBadgeURL As String

        Public ViewImageURL As String
        Public CalImageURL As String
        Public PrintImageURL As String
        Public BriefcaseImageURL As String
        Public IconBlankImageURL As String

        Public AddSessionsText As String
        Public AddSessionsNavigateURL As String
        Public AddSessionsImageURL As String

        Public ProductCode As String
        Public ShipMasterCustomerId As String
        Public ShipSubCustomerId As Integer

        'Hotel Reservation
        Public ShowHotelBlockingLink As Boolean
        Public CanCreateHotelReservationBridge As Boolean
        Public CanManageHotelReservation As Boolean
    End Class

    
End Namespace
