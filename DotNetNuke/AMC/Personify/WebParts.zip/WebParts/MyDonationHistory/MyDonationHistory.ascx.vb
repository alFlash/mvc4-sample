Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.MyDonationHistory.Business

Namespace Personify.DNN.Modules.MyDonationHistory
    <CLSCompliant(False)> _
    Public MustInherit Class MyDonationHistory
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


#Region "Controls"
        Protected WithEvents lblError As System.Web.UI.WebControls.Label
        Protected WithEvents pnlMain As System.Web.UI.WebControls.Panel

        Protected WithEvents btnSearch As System.Web.UI.WebControls.Button
        Protected WithEvents rdCreditType As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents ctrlCalanderBeginDate As Telerik.Web.UI.RadDatePicker

        Protected WithEvents xslDonations As WebControls.XslTemplate
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Settings("MyDonationHistoryTemplate") IsNot Nothing Then

                    lblError.Text = String.Empty
                    pnlMain.Visible = True

                    If Not Page.IsPostBack Then
                        rdCreditType.SelectedIndex = 0

                        Dim month As Integer = Date.Now().Month
                        Dim day As Integer = Date.Now().Day
                        Dim year As Integer = Date.Now().Year
                        Dim nMonth As Integer = 0
                        Dim nDay As Integer = 0
                        Dim nYear As Integer = 0
                        Dim beginDate As DateTime

                        If month = 1 Then
                            nYear = year - 1
                            nMonth = 12
                            nDay = day
                        Else
                            nYear = year
                            nMonth = month - 1
                            nDay = day
                            If IsDate(nMonth & "-" & nDay & "-" & nYear) Then
                            Else
                                If nMonth = 2 Then
                                    nDay = 28
                                Else
                                    nDay = nDay - 1
                                End If
                            End If
                        End If
                        beginDate = Date.Parse(nMonth & "-" & nDay & "-" & nYear)

                        ctrlCalanderBeginDate.SelectedDate = beginDate.ToString("MM/dd/yyyy")

                        Dim oFnd As TIMSS.API.FundRaisingInfo.IFundRaisingCredits
                        oFnd = DF_GetCustomerFundRaisingInfo(MasterCustomerId, SubCustomerId)

                        Dim donationHistory(oFnd.Count) As Donation
                        Dim i As Integer = 0
                        For Each item As TIMSS.API.FundRaisingInfo.IFundRaisingCredit In oFnd
                            If ((rdCreditType.SelectedValue = "Hard" And Not item.SoftCreditFlag) Or (rdCreditType.SelectedValue = "Soft" And item.SoftCreditFlag)) And (Date.Parse(ctrlCalanderBeginDate.SelectedDate()) <= item.TransactionDate) Then
                                donationHistory(i) = New Donation
                                If item.Fund <> String.Empty Then
                                    donationHistory(i).donationName = item.Fund
                                End If
                                If item.Campaign <> String.Empty Then
                                    If item.Fund <> String.Empty Then
                                        donationHistory(i).donationName = donationHistory(i).donationName & "-" & item.Campaign
                                    Else
                                        donationHistory(i).donationName = item.Campaign
                                    End If
                                End If
                                If item.Appeal <> String.Empty Then
                                    If donationHistory(i).donationName <> String.Empty Then
                                        donationHistory(i).donationName = donationHistory(i).donationName & "-" & item.Appeal
                                    Else
                                        donationHistory(i).donationName = item.Appeal
                                    End If
                                End If

                                donationHistory(i).donationDate = Format(item.TransactionDate, "dd/MM/yyyy")
                                If Math.Round(item.CreditAmount) = item.CreditAmount Then
                                    donationHistory(i).AmountInteger = True
                                Else
                                    donationHistory(i).AmountInteger = False
                                End If
                                'donationHistory(i).amount = item.CreditAmount.ToString()
                                donationHistory(i).amount = String.Concat(PortalCurrency.Symbol, " ", ConvertPriceFromBaseToPortalCurrency(item.CreditAmount).ToString)
                                i = i + 1
                            End If
                        Next
                        If i > 0 Then
                            xslDonations.XSLfile = Server.MapPath(ModulePath + "/Templates/" & CStr(Settings("MyDonationHistoryTemplate")))
                            xslDonations.AddObject("", donationHistory)
                            xslDonations.Display()
                        End If
                    End If
                Else
                    pnlMain.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
            Try

                Dim oFnd As TIMSS.API.FundRaisingInfo.IFundRaisingCredits
                oFnd = DF_GetCustomerFundRaisingInfo(MasterCustomerId, SubCustomerId)

                Dim donationHistory(oFnd.Count) As Donation
                Dim i As Integer = 0

                For Each item As TIMSS.API.FundRaisingInfo.IFundRaisingCredit In oFnd
                    If ((rdCreditType.SelectedValue = "Hard" And Not item.SoftCreditFlag) Or (rdCreditType.SelectedValue = "Soft" And item.SoftCreditFlag)) And (Date.Parse(ctrlCalanderBeginDate.SelectedDate()) <= item.TransactionDate) Then
                        donationHistory(i) = New Donation
                        If item.Fund <> String.Empty Then
                            donationHistory(i).donationName = item.Fund
                        End If
                        If item.Campaign <> String.Empty Then
                            If item.Fund <> String.Empty Then
                                donationHistory(i).donationName = donationHistory(i).donationName & "-" & item.Campaign
                            Else
                                donationHistory(i).donationName = item.Campaign
                            End If
                        End If
                        If item.Appeal <> String.Empty Then
                            If donationHistory(i).donationName <> String.Empty Then
                                donationHistory(i).donationName = donationHistory(i).donationName & "-" & item.Appeal
                            Else
                                donationHistory(i).donationName = item.Appeal
                            End If
                        End If
                        donationHistory(i).donationDate = Format(item.TransactionDate, "dd/MM/yyyy")
                        If Math.Round(item.CreditAmount) = item.CreditAmount Then
                            donationHistory(i).AmountInteger = True
                        Else
                            donationHistory(i).AmountInteger = False
                        End If
                        donationHistory(i).amount = String.Concat(PortalCurrency.Symbol, " ", ConvertPriceFromBaseToPortalCurrency(item.CreditAmount).ToString)

                        i = i + 1
                    End If
                Next

                If i > 0 Then
                    xslDonations.XSLfile = Server.MapPath(ModulePath + "/Templates/" & CStr(Settings("MyDonationHistoryTemplate")))
                    xslDonations.AddObject("", donationHistory)
                    xslDonations.Display()
                Else
                    lblError.Text = Localization.GetString("NoRecordsMatchingCriterias", LocalResourceFile)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


        Private Function DF_GetCustomerFundRaisingInfo(ByVal MasterCustomerId As String, _
                                          ByVal SubCustomerId As Integer) _
                                          As TIMSS.API.FundRaisingInfo.IFundRaisingCredits

            Dim oFnd As TIMSS.API.FundRaisingInfo.IFundRaisingCredits

            oFnd = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.FundRaisingInfo, "FundRaisingCredits")

            oFnd.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MasterCustomerId)
            oFnd.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, SubCustomerId)
            oFnd.Filter.Add("OrgUnitId", TIMSS.Enumerations.QueryOperatorEnum.Equals, OrganizationUnitId)
            oFnd.Filter.Add("OrgId", TIMSS.Enumerations.QueryOperatorEnum.Equals, OrganizationId)
            oFnd.Fill()

            Return oFnd

        End Function


    End Class
    Public Class Donation
        Public donationName As String
        Public amount As String
        Public AmountInteger As Boolean
        Public donationDate As String
    End Class
End Namespace
