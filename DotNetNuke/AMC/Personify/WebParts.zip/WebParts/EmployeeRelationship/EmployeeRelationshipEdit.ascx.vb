Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.EmployeeRelationship.Business

Namespace Personify.DNN.Modules.EmployeeRelationship

    Public MustInherit Class EmployeeRelationshipEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents lnkUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblActionButtons As System.Web.UI.WebControls.Label
        Protected WithEvents rdSegmentActionButtonType As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents pnlSegmentActionURLForNew As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlSegmentActionURLForSearch As System.Web.UI.WebControls.Panel
        Protected WithEvents lblSegmentActionURLForNew As System.Web.UI.WebControls.Label
        Protected WithEvents drpSegmentActionURLForNew As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblSegmentActionURLForSearch As System.Web.UI.WebControls.Label
        Protected WithEvents drpSegmentActionURLForSearch As DotNetNuke.UI.UserControls.UrlControl


#End Region
#Region "Constants"
        Private Const C_SEGMENT_ACTION_BUTTON_TYPE As String = "SegmentActionButtonType"
        Private Const C_SEGMENT_ACTION_URL_FOR_SEARCH As String = "SegmentActionURLForSearch"
        Private Const C_SEGMENT_ACTION_URL_FOR_NEW As String = "SegmentActionURLForNew"
#End Region
#Region "Private Members"
        Private newOnly As String
        Private searchOnly As String
        Private both As String

        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objCtlEmployeeRelationship As New EmployeeRelationshipController
                Dim objEmployeeRelationship As New EmployeeRelationshipInfo

                ' Determine ItemId
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Null.NullInteger()
                End If

                newOnly = Localization.GetString("NewOnly", LocalResourceFile)
                searchOnly = Localization.GetString("SearchOnly", LocalResourceFile)
                both = Localization.GetString("Both", LocalResourceFile)

                If Not Page.IsPostBack Then
                    LoadSettings()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    UpdateSettings()
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub rdSegmentActionButtonType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdSegmentActionButtonType.SelectedIndexChanged
            Select Case rdSegmentActionButtonType.SelectedValue
                Case newOnly
                    pnlSegmentActionURLForNew.Visible = True
                    pnlSegmentActionURLForSearch.Visible = False
                Case searchOnly
                    pnlSegmentActionURLForNew.Visible = False
                    pnlSegmentActionURLForSearch.Visible = True
                Case both
                    pnlSegmentActionURLForNew.Visible = True
                    pnlSegmentActionURLForSearch.Visible = True
            End Select

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
#Region "Helper Functions"
        Private Sub LoadSettings()

            With rdSegmentActionButtonType.Items
                .Insert(0, (New ListItem(newOnly, newOnly)))
                .Insert(1, (New ListItem(searchOnly, searchOnly)))
                .Insert(2, (New ListItem(both, both)))
            End With

            If Settings(C_SEGMENT_ACTION_BUTTON_TYPE) Is Nothing Then
                Me.pnlSegmentActionURLForNew.Visible = False
                Me.pnlSegmentActionURLForSearch.Visible = False
            Else
                rdSegmentActionButtonType.SelectedValue = CStr(Settings(C_SEGMENT_ACTION_BUTTON_TYPE))
                Select Case CStr(Settings(C_SEGMENT_ACTION_BUTTON_TYPE))
                    Case newOnly
                        pnlSegmentActionURLForNew.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_NEW) Is Nothing Then
                            drpSegmentActionURLForNew.Url = CStr(Settings(C_SEGMENT_ACTION_URL_FOR_NEW))
                        End If
                        pnlSegmentActionURLForSearch.Visible = False
                    Case searchOnly
                        pnlSegmentActionURLForNew.Visible = False
                        pnlSegmentActionURLForSearch.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH) Is Nothing Then
                            drpSegmentActionURLForSearch.Url = CStr(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH))
                        End If
                    Case both
                        pnlSegmentActionURLForNew.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_NEW) Is Nothing Then
                            drpSegmentActionURLForNew.Url = CStr(Settings(C_SEGMENT_ACTION_URL_FOR_NEW))
                        End If
                        pnlSegmentActionURLForSearch.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH) Is Nothing Then
                            drpSegmentActionURLForSearch.Url = CStr(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH))
                        End If

                End Select
            End If


        End Sub

        Private Sub UpdateSettings()

            Dim objModules As New Entities.Modules.ModuleController

            Select Case rdSegmentActionButtonType.SelectedValue
                Case newOnly
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_BUTTON_TYPE, rdSegmentActionButtonType.SelectedValue)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_URL_FOR_NEW, drpSegmentActionURLForNew.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_URL_FOR_SEARCH, "")
                Case searchOnly
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_BUTTON_TYPE, rdSegmentActionButtonType.SelectedValue)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_URL_FOR_NEW, "")
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_URL_FOR_SEARCH, drpSegmentActionURLForSearch.Url)
                Case both
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_BUTTON_TYPE, rdSegmentActionButtonType.SelectedValue)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_URL_FOR_NEW, drpSegmentActionURLForNew.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_SEGMENT_ACTION_URL_FOR_SEARCH, drpSegmentActionURLForSearch.Url)
            End Select
            objModules = Nothing
        End Sub

#End Region

    End Class

End Namespace
