Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.EmployeeRelationship.Business

Namespace Personify.DNN.Modules.EmployeeRelationship
    <CLSCompliant(False)> _
    Public MustInherit Class EmployeeRelationship
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"
        Protected WithEvents pnlAdd As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlEdit As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlView As System.Web.UI.WebControls.Panel
        Protected WithEvents lblNameAdd As System.Web.UI.WebControls.Label
        Protected WithEvents txtNameAdd As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnSearchAdd As System.Web.UI.WebControls.Button
        Protected WithEvents drpEmploymentTypeAdd As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblEmploymentDateAdd As System.Web.UI.WebControls.Label
        Protected WithEvents ctrlCalanderEmploymentDateAdd As Telerik.Web.UI.RadDatePicker
        Protected WithEvents btnNewAdd As System.Web.UI.WebControls.Button
        Protected WithEvents lblEmploymentTypeAdd As System.Web.UI.WebControls.Label
        Protected WithEvents lblSupervisorAdd As System.Web.UI.WebControls.Label
        Protected WithEvents txtSupervisorAdd As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblFullTimeAdd As System.Web.UI.WebControls.Label
        Protected WithEvents chkFullTimeAdd As System.Web.UI.WebControls.CheckBox
        Protected WithEvents btnUpdateAdd As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelAdd As System.Web.UI.WebControls.Button
        Protected WithEvents lblNameEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblNameValueEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblEmploymentTypeEdit As System.Web.UI.WebControls.Label
        Protected WithEvents drpEmploymentTypeEdit As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblEmploymentDateEdit As System.Web.UI.WebControls.Label
        Protected WithEvents ctrlCalanderEmploymentDateEdit As Telerik.Web.UI.RadDatePicker
        Protected WithEvents lblSupervisorEdit As System.Web.UI.WebControls.Label
        Protected WithEvents txtSupervisorEdit As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblFullTimeEdit As System.Web.UI.WebControls.Label
        Protected WithEvents chkFullTimeEdit As System.Web.UI.WebControls.CheckBox
        Protected WithEvents btnUpdateEdit As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelEdit As System.Web.UI.WebControls.Button
        Protected WithEvents lblNameView As System.Web.UI.WebControls.Label
        Protected WithEvents lblNameValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblEmploymentTypeView As System.Web.UI.WebControls.Label
        Protected WithEvents lblEmploymentTypeValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblEmploymentDateView As System.Web.UI.WebControls.Label
        Protected WithEvents lblEmploymentDateValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblSupervisorView As System.Web.UI.WebControls.Label
        Protected WithEvents lblSupervisorValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblFulltimeView As System.Web.UI.WebControls.Label
        Protected WithEvents lblFulltimeValueView As System.Web.UI.WebControls.Label
        Protected WithEvents btnDoneView As System.Web.UI.WebControls.Button
        'Protected WithEvents lnkSearchAdd As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lnkNewAdd As System.Web.UI.WebControls.HyperLink

        Protected WithEvents pnlSearchAdd As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlNewAdd As System.Web.UI.WebControls.Panel

        Protected WithEvents pnlEmployeeRelationship As System.Web.UI.WebControls.Panel

        Protected WithEvents oMessageControl As WebControls.MessageControl

        'HTML hidden used to know if the call is from Search interface
        Protected WithEvents hdnSearch As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected WithEvents hdnEmployeeMasterCustomer As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected WithEvents hdnEmployeeSubCustomer As System.Web.UI.HtmlControls.HtmlInputHidden

        Protected WithEvents lblSegmentDesc As System.Web.UI.WebControls.Label

        Dim segmentinfo As AffiliateManagementSessionHelper.SegmentInfo

        Protected WithEvents imgSearch As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgNew As System.Web.UI.HtmlControls.HtmlImage
#End Region

#Region "Constants"
        Const C_RELATIONSHIP_TYPE As String = "EMPLOYMENT"
        Const C_RELATIONSHIP_CODE As String = "EMPLOYER"
        'Const C_ACTIVE_FLAG As Boolean = True

        Private Const C_SEGMENT_ACTION_BUTTON_TYPE As String = "SegmentActionButtonType"
        Private Const C_SEGMENT_ACTION_URL_FOR_SEARCH As String = "SegmentActionURLForSearch"
        Private Const C_SEGMENT_ACTION_URL_FOR_NEW As String = "SegmentActionURLForNew"
#End Region

#Region "Info"
        Private mode As String = "ADD"
        Private strEmployerMasterCustomerId As String
        Private strEmployerSubCustomerId As String
        Private CusRelationship As String

        Public fromOutside As Integer = 0
        Dim IsNew As Boolean = False
        Dim IsSearch As Boolean = False
        Dim newCustomer As String = Nothing

        'direct call from CustomerSearch when coming from AffiliateSegmentList AddMember feature
        Dim IsExecute As Boolean = False

#End Region
#Region "Properties"
        'property to get/set the employeeMasterCustomerId
        Public Property EmployeeMasterCustomer() As String
            Get
                Return CStr(ViewState("EmployeeMasterCustomerId"))
            End Get
            Set(ByVal Value As String)
                ViewState("EmployeeMasterCustomerId") = Value
            End Set
        End Property

        'property to get/set the employeeSubCustomerId
        Public Property EmployeeSubCustomer() As String
            Get
                Return CStr(ViewState("EmployeeSubCustomerId"))
            End Get
            Set(ByVal Value As String)
                ViewState("EmployeeSubCustomerId") = Value
            End Set
        End Property

#End Region
#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If Not oMessageControl.ValidationIssues Is Nothing Then
                        oMessageControl.Clear()
                    End If

                    'segment description shown on top of the page
                    lblSegmentDesc.Text = segmentinfo.SegmentDescr

                    '3246-5774803
                    LoadImages()
                    'END 3246-5774803

                    'check if comming from CustomerSearch directly
                    If Request.QueryString("Execute") IsNot Nothing Then
                        IsExecute = True
                    Else
                        IsExecute = False
                    End If

                    If Page.IsPostBack And String.Compare(hdnSearch.Value, "Y", True) = 0 Then
                        'the previous call was from the Search interface forcing the parent window to reload
                        IsSearch = True
                        hdnSearch.Value = "N"
                        EmployeeMasterCustomer = hdnEmployeeMasterCustomer.Value
                        EmployeeSubCustomer = hdnEmployeeSubCustomer.Value
                    End If
                    If IsSearch And fromOutside = 1 Then
                        Exit Sub
                    Else
                        InitializeControl()
                    End If
                
                Else
                pnlEmployeeRelationship.Visible = False
               DisplayUserAccessMessage(role)
                End If
                


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Protected Sub btnUpdateAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateAdd.Click

            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If

            'Perform date validation
            If Not IsValidDates() Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("EmploymentStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                'ctrlCalanderEmploymentDateEdit.SetDate = ""
                ctrlCalanderEmploymentDateEdit.Clear()
                Exit Sub
            End If

            Dim RelatedName As String = txtNameAdd.Text 'ReturnEmployee().LabelName
            Dim RelationshipType As String = "Employment"
            Dim RelationshipCode As String = "Employer"
            Dim ReciprocalCode As String = drpEmploymentTypeAdd.SelectedValue
            'Dim BeginDate As Date = CDate(ctrlCalanderEmploymentDateAdd.getDate)
            Dim BeginDate As Date
            If Not ctrlCalanderEmploymentDateAdd.IsEmpty Then BeginDate = ctrlCalanderEmploymentDateAdd.SelectedDate
            Dim SupervisorName As String = txtSupervisorAdd.Text
            Dim FullTimeFlag As Boolean = chkFullTimeAdd.Checked
            Dim PrimaryEmployerFlag As Boolean = False
            Dim validationIssues As TIMSS.API.Core.Validation.IIssuesCollection

            validationIssues = SaveEmployeeRelationship(TransactionMode.ADD, _
                     strEmployerMasterCustomerId, _
                     CInt(strEmployerSubCustomerId), EmployeeMasterCustomer, CInt(EmployeeSubCustomer), RelatedName, _
                     RelationshipType, RelationshipCode, ReciprocalCode, _
                     BeginDate, SupervisorName, FullTimeFlag, PrimaryEmployerFlag, Nothing)



            If validationIssues.Count > 0 Then
                'The save was not successfull
                oMessageControl.Show(CType(validationIssues, TIMSS.API.Core.Validation.IssuesCollection))
            Else
                Dim cancelActionURL As Integer = segmentinfo.AffiliateListTabId

                Response.Redirect(NavigateURL(cancelActionURL), True)
            End If

        End Sub


        Protected Sub btnUpdateEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateEdit.Click

            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If


            'Perform date validation
            If Not IsValidDates() Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("EmploymentStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                'ctrlCalanderEmploymentDateEdit.SetDate = ""
                ctrlCalanderEmploymentDateEdit.Clear()
                Exit Sub
            End If

            Dim ReciprocalCode As String = drpEmploymentTypeEdit.SelectedValue
            'Dim BeginDate As Date = CDate(ctrlCalanderEmploymentDateEdit.getDate)
            Dim BeginDate As Date
            If Not ctrlCalanderEmploymentDateEdit.IsEmpty Then BeginDate = ctrlCalanderEmploymentDateEdit.SelectedDate
            Dim SupervisorName As String = txtSupervisorEdit.Text
            Dim FullTimeFlag As Boolean = chkFullTimeEdit.Checked
            Dim CustomerRelationshipId As Integer = CInt(CusRelationship)
            Dim validationIssues As TIMSS.API.Core.Validation.IIssuesCollection

            validationIssues = SaveEmployeeRelationship(TransactionMode.EDIT, _
                 strEmployerMasterCustomerId, _
                 CInt(strEmployerSubCustomerId), Nothing, -1, Nothing, _
                 Nothing, Nothing, ReciprocalCode, _
                 BeginDate, SupervisorName, FullTimeFlag, Nothing, CustomerRelationshipId)


            If validationIssues.Count > 0 Then
                'The save was not successfull
                oMessageControl.Show(CType(validationIssues, TIMSS.API.Core.Validation.IssuesCollection))
            Else
                Dim cancelActionURL As Integer = segmentinfo.AffiliateListTabId

                Response.Redirect(NavigateURL(cancelActionURL), True)
            End If
        End Sub

        Protected Sub btnCancelAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelAdd.Click, btnCancelEdit.Click, btnDoneView.Click
            Try
                If Not oMessageControl.ValidationIssues Is Nothing Then
                    oMessageControl.Clear()
                End If
                Dim cancelActionURL As Integer = segmentinfo.AffiliateListTabId

                Response.Redirect(NavigateURL(cancelActionURL), True)
            Catch ex As Threading.ThreadAbortException

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            'JavaScript code to hide the Search IFrame when customer selected
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "setClick", "<script language='javascript'>setClick(event)</script>")
            Dim selectblocker As HtmlControl = CType(Me.FindControl("selectblocker"), HtmlControl)
            selectblocker.Attributes("onload") = "setClick(event, this.contentWindow)"
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "RefreshParent", "<script language='javascript'>RefreshParent()</script>")

            SetInfo()

            If (Not IsPostBack) AndAlso (newCustomer Is Nothing) AndAlso (Not EmployeeMasterCustomer Is Nothing) AndAlso (Not EmployeeSubCustomer Is Nothing) Then
                'call from Search interface
                fromOutside = 1

                IsSearch = True
                hdnSearch.Value = "Y"

            Else
                fromOutside = 0
            End If

        End Sub

#End Region
#Region "Helper functions"
        Public Sub InitializeControl()
            'chceck permissions for ADD, EDIT, VIEW
            If HasPermission() Then
                pnlEmployeeRelationship.Visible = True
                Select Case mode
                    Case "ADD"
                        InitializeControlAdd()
                    Case "EDIT"
                        InitializeControlEdit()
                    Case "VIEW"
                        InitializeControlView()
                End Select
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoPermissionsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If

        End Sub
        Public Sub SetInfo()
            Dim strQueryString As String = Request.Url.Query
            Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
            Dim strQueryParam As String

            'set the value for properties
            For Each strQueryParam In arrQueryString
                If strQueryParam.IndexOf("mcid") <> -1 Then   'If found
                    EmployeeMasterCustomer = strQueryParam.Replace("mcid=", "")
                    EmployeeMasterCustomer = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(EmployeeMasterCustomer))
                    hdnEmployeeMasterCustomer.Value = EmployeeMasterCustomer
                ElseIf strQueryParam.IndexOf("scid") <> -1 Then
                    EmployeeSubCustomer = strQueryParam.Replace("scid=", "")
                    EmployeeSubCustomer = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(EmployeeSubCustomer))
                    hdnEmployeeSubCustomer.Value = EmployeeSubCustomer
                ElseIf strQueryParam.IndexOf("referrer") <> -1 Then
                    'the call is from the New interface
                    newCustomer = strQueryParam
                    IsNew = True
                ElseIf strQueryParam.IndexOf("args") <> -1 Then
                    CusRelationship = strQueryParam
                    CusRelationship = CusRelationship.Replace("args=", "")
                ElseIf strQueryParam.IndexOf("action") <> -1 Then
                    'specifies the action AddMember, EditMember or ViewMember
                    mode = strQueryParam
                    mode = mode.Replace("action=", "")
                End If
            Next
            'get the value of current segment info
            segmentinfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
            strEmployerMasterCustomerId = segmentinfo.SegmentQualifier1
            strEmployerSubCustomerId = segmentinfo.SegmentQualifier2

        End Sub
        Private Sub InitializeControlAdd()
            pnlAdd.Visible = True
            pnlEdit.Visible = False
            pnlView.Visible = False
            Dim ctrl As String
            Dim updatePressed As Boolean = False
            If IsExecute Then
                For Each ctrl In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("btnUpdateAdd") > 0 Then
                        updatePressed = True
                    End If
                Next
            End If
            If (Not Page.IsPostBack) Or (IsExecute And Not updatePressed) Then
                'EmploymentType dropdown will load if first page load or comming directly from CustomerSearch and is first load of page
                With drpEmploymentTypeAdd
                    .DataSource = GetCustomerRelationshipCodes(C_RELATIONSHIP_TYPE, C_RELATIONSHIP_CODE)
                    .DataTextField = "ReciprocalCode"
                    .DataValueField = "ReciprocalCode"
                    .DataBind()
                End With
            End If
            If (Page.IsPostBack And IsSearch And fromOutside = 0) Then
                'EmploymentType dropdown will load if page is reload when comming from CustomerSearch IFrame
                With drpEmploymentTypeAdd
                    .DataSource = GetCustomerRelationshipCodes(C_RELATIONSHIP_TYPE, C_RELATIONSHIP_CODE)
                    .DataTextField = "ReciprocalCode"
                    .DataValueField = "ReciprocalCode"
                    .DataBind()
                End With
            End If

            If EmployeeMasterCustomer <> String.Empty And EmployeeMasterCustomer <> String.Empty Then
                txtNameAdd.Text = ReturnEmployee().LabelName
            End If
            'based on Settings("SegmentActionButtonType") values New and Search buttons will be shown or not 
            If Not Settings(C_SEGMENT_ACTION_BUTTON_TYPE) Is Nothing Then
                Select Case CStr(Settings(C_SEGMENT_ACTION_BUTTON_TYPE))
                    Case "New"
                        pnlNewAdd.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_NEW) Is Nothing Then
                            lnkNewAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_NEW), Integer), "", "&ref=segment&reftabid=" & TabId)
                        End If
                        pnlSearchAdd.Visible = False
                    Case "Search"
                        pnlNewAdd.Visible = False
                        pnlSearchAdd.Visible = True

                        Dim selectblocker As HtmlControl = CType(Me.FindControl("selectblocker"), HtmlControl)
                        selectblocker.Attributes("src") = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer), "", "")

                        'If Not Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH) Is Nothing Then
                        'lnkSearchAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer))
                        'End If
                    Case "Both"
                        pnlNewAdd.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_NEW) Is Nothing Then
                            lnkNewAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_NEW), Integer), "", "&ref=segment&reftabid=" & TabId)
                        End If
                        pnlSearchAdd.Visible = True
                        Dim selectblocker As HtmlControl = CType(Me.FindControl("selectblocker"), HtmlControl)
                        selectblocker.Attributes("src") = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer), "", "")

                        'If Not Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH) Is Nothing Then
                        'lnkSearchAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer))
                        'End If
                    Case Else
                        pnlNewAdd.Visible = False
                        pnlSearchAdd.Visible = False
                End Select
            End If


        End Sub

        Private Sub InitializeControlEdit()
            pnlAdd.Visible = False
            pnlEdit.Visible = True
            pnlView.Visible = False

            If Not Page.IsPostBack Then
                'load of EmploymentType dropdown
                With drpEmploymentTypeEdit
                    .DataSource = GetCustomerRelationshipCodes(C_RELATIONSHIP_TYPE, C_RELATIONSHIP_CODE)
                    .DataTextField = "ReciprocalCode"
                    .DataValueField = "ReciprocalCode"
                    .DataBind()
                End With

                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                'get customer object for the selected Employer segment
                oCustomers = GetCustomer(strEmployerMasterCustomerId, strEmployerSubCustomerId)
                Dim oRelationships As TIMSS.API.CustomerInfo.ICustomerRelationships = oCustomers(0).Relationships
                Dim oRelationship As TIMSS.API.CustomerInfo.ICustomerRelationship

                For Each oRelationship In oRelationships
                    'find the selected relationship and edit that relationship - set the controls values
                    If CStr(oRelationship.ReciprocalId) = CusRelationship Then
                        lblNameValueEdit.Text = oRelationship.RelatedCustomer.LabelName
                        drpEmploymentTypeEdit.SelectedValue = oRelationship.ReciprocalCode.Code
                        'ctrlCalanderEmploymentDateEdit.SetDate = Format(oRelationship.BeginDate, "MM/dd/yyyy")
                        ctrlCalanderEmploymentDateEdit.SelectedDate = oRelationship.BeginDate
                        txtSupervisorEdit.Text = oRelationship.SupervisorName
                        chkFullTimeEdit.Checked = oRelationship.FullTimeFlag
                    End If
                Next
            End If
        End Sub

        Private Sub InitializeControlView()
            pnlAdd.Visible = False
            pnlEdit.Visible = False
            pnlView.Visible = True
            If Not Page.IsPostBack Then
                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                oCustomers = GetCustomer(strEmployerMasterCustomerId, strEmployerSubCustomerId)
                Dim oRelationships As TIMSS.API.CustomerInfo.ICustomerRelationships = oCustomers(0).Relationships
                Dim oRelationship As TIMSS.API.CustomerInfo.ICustomerRelationship

                For Each oRelationship In oRelationships
                    'find the selected relationship and edit that relationship - set the controls values
                    If CStr(oRelationship.ReciprocalId) = CusRelationship Then
                        lblNameValueView.Text = oRelationship.RelatedCustomer.LabelName
                        lblEmploymentTypeValueView.Text = oRelationship.ReciprocalCode.Code
                        lblEmploymentDateValueView.Text = Format(oRelationship.BeginDate, "MM/dd/yyyy")
                        lblSupervisorValueView.Text = oRelationship.SupervisorName
                        lblFulltimeValueView.Text = CStr(IIf(oRelationship.FullTimeFlag, "Y", "N"))
                    End If
                Next
            End If

        End Sub
        Private Function HasPermission() As Boolean
            If Page.IsPostBack Then Return True

            Try
                Select Case mode.ToUpper()
                    Case "ADD"
                        'test AddMemberFlag
                        If Not segmentinfo.CanAddMemberFlag Then
                            Return False
                        End If
                    Case "EDIT"
                        'test ReadOnlyFlag
                        If segmentinfo.ReadOnlyFlag Then
                            Return False
                        End If
                        'check if a relationship was selected
                        If (CusRelationship Is Nothing) Or (CusRelationship = "") Then
                            Return False
                        End If

                    Case "VIEW"
                        'check if a relationship was selected
                        If (CusRelationship Is Nothing) Or (CusRelationship = "") Then
                            Return False
                        End If
                    Case Else
                        Return False
                End Select
                If (mode Is Nothing) OrElse String.Compare(mode, "ADD", True) = 0 Then
                Else
                    'check if selected relationship exists for EDIT and VIEW
                    Dim CusRelationshipIdExists As Boolean = False
                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                    oCustomers = GetCustomer(strEmployerMasterCustomerId, strEmployerSubCustomerId)
                    Dim oRelationships As TIMSS.API.CustomerInfo.ICustomerRelationships = oCustomers(0).Relationships
                    Dim oRelationship As TIMSS.API.CustomerInfo.ICustomerRelationship

                    For Each oRelationship In oRelationships
                        If CStr(oRelationship.ReciprocalId) = CusRelationship Then ' .CustomerRelationshipId
                            CusRelationshipIdExists = True
                        End If
                    Next
                    If CusRelationshipIdExists = False Then
                        Return False
                    End If

                End If
                Return True

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            Finally

            End Try
        End Function

        Private Function ReturnEmployee() As TIMSS.API.CustomerInfo.ICustomer
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = GetCustomer(EmployeeMasterCustomer, EmployeeSubCustomer)

            Return oCustomers(0)
        End Function

        'check for valid dates
        Private Function IsValidDates() As Boolean
            'If Not IsDate(ctrlCalanderEmploymentDateAdd.getDate) AndAlso (mode = "ADD") Then
            '    Return False
            'End If

            'If Not IsDate(ctrlCalanderEmploymentDateEdit.getDate) AndAlso (mode = "EDIT") Then
            '    Return False
            'End If

            If ctrlCalanderEmploymentDateAdd.IsEmpty AndAlso (mode = "ADD") Then
                Return False
            End If

            If ctrlCalanderEmploymentDateEdit.IsEmpty AndAlso (mode = "EDIT") Then
                Return False
            End If

            Return True
        End Function


        '3246-5774803
        Private Sub LoadImages()

            imgNew.Src = ResolveUrl("~/" & SiteImagesFolder & "/folderopen.gif")
            imgSearch.Src = ResolveUrl("~/" & SiteImagesFolder & "/plus2.gif")
        End Sub
        'END 3246-5774803

#End Region


#Region "Personify Data"
        Private Function GetCustomer(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", MCID)
                .Filter.Add("SubCustomerId", SCID)
                .Fill()
            End With

            Return oCustomers

        End Function


        Private Function GetCustomerRelationshipCodes(ByVal RelationshipType As String, ByVal RelationshipCode As String) As TIMSS.API.CustomerInfo.ICustomerRelationshipCodes

            Dim oCusRelationshipCodes As TIMSS.API.CustomerInfo.ICustomerRelationshipCodes
            Dim strCacheKey As String = "GetCusRelationshipCodes" & RelationshipType & RelationshipCode



            If PersonifyDataCache.Fetch(strCacheKey) Is Nothing Then

                oCusRelationshipCodes = Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerRelationshipCodes")
                'oCusRelationshipCodes.FillMode = TIMSS.Enumerations.CollectionFillModeEnum.OnDemand
                With oCusRelationshipCodes
                    .Filter.Add("RelationshipType", RelationshipType)
                    .Filter.Add("RelationshipCode", RelationshipCode)
                    .Filter.Add("ActiveFlag", "Y")
                    .Fill()
                End With


                PersonifyDataCache.Store(strCacheKey, oCusRelationshipCodes)
            End If

            Return PersonifyDataCache.Fetch(strCacheKey)

        End Function

        Private Function SaveEmployeeRelationship(ByVal Mode As TransactionMode, _
                    ByVal EmployerMasterCustomer As String, _
                    ByVal EmployerSubCustomer As Integer, ByVal RelatedMasterCustomer As String, ByVal RelatedSubCustomer As Integer, ByVal RelatedName As String, _
                    ByVal RelationshipType As String, ByVal RelationshipCode As String, ByVal ReciprocalCode As String, _
                    ByVal BeginDate As Date, ByVal SupervisorName As String, ByVal FullTimeFlag As Boolean, ByVal PrimaryEmployerFlag As Boolean, ByVal CustomerRelationshipId As Integer, _
              Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection



            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False


            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "EmployeeRelationship"
                End With

            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys), BusinessObjectGUIDStorage())
            End If

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            'oCustomers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, EmployerMasterCustomer)
            'oCustomers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, EmployerSubCustomer)
            oCustomers.Fill(EmployerMasterCustomer, EmployerSubCustomer)
            Dim oRelationships As TIMSS.API.CustomerInfo.ICustomerRelationships = oCustomers(0).Relationships

            If Mode = TransactionMode.ADD Then
                With oRelationships.AddNew()
                    .MasterCustomerId = EmployerMasterCustomer
                    .SubCustomerId = CInt(EmployerSubCustomer)
                    .RelatedName = RelatedName
                    .RelationshipType = .RelationshipType.List(RelationshipType).ToCodeObject
                    .RelationshipCode = .RelationshipCode.List(RelationshipCode).ToCodeObject
                    .ReciprocalCode = .ReciprocalCode.List(ReciprocalCode).ToCodeObject

                    .RelatedMasterCustomerId = RelatedMasterCustomer
                    .RelatedSubCustomerId = RelatedSubCustomer

                    .BeginDate = CDate(BeginDate)
                    .SupervisorName = SupervisorName
                    .FullTimeFlag = FullTimeFlag
                    .PrimaryEmployerFlag = PrimaryEmployerFlag

                End With

            ElseIf Mode = TransactionMode.EDIT Then

                Dim i As Integer
                For i = 0 To oRelationships.Count - 1
                    With oRelationships(i)
                        If CStr(.ReciprocalId) = CustomerRelationshipId Then
                            .ReciprocalCode = .ReciprocalCode.List(ReciprocalCode).ToCodeObject
                            .BeginDate = BeginDate
                            .SupervisorName = SupervisorName
                            .FullTimeFlag = FullTimeFlag
                            .PrimaryEmployerFlag = PrimaryEmployerFlag
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).Relationships(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).Relationships(i).Guid
                End If

            ElseIf Mode = TransactionMode.DELETE Then

                Dim i As Integer
                For i = 0 To oRelationships.Count - 1
                    With oRelationships(i)
                        If CStr(.ReciprocalId) = CustomerRelationshipId Then 'CustomerRelationshipId
                            .EndDate = CDate(Format(Date.Now, "MM/dd/yyyy"))
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).Relationships(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).Relationships(i).Guid
                End If
            End If

            AddSessionObject(SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys, oclsGUID)


            oCustomers.Save()

            If oCustomers.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)

                oCustomers.Save()
            End If

            ' Clear the cached communication methods if no validation issues exist
            If oCustomers.ValidationIssues.ErrorCount = 0 Then
                If PersonifyDataCache.Fetch("GetCustomer" & EmployerMasterCustomer & EmployerSubCustomer) Is Nothing Then
                    PersonifyDataCache.Remove("GetCustomer" & EmployerMasterCustomer & EmployerSubCustomer)
                End If


                ClearSessionObject(SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys)
            End If
            Return oCustomers.ValidationIssues



        End Function

#End Region
    End Class

End Namespace
