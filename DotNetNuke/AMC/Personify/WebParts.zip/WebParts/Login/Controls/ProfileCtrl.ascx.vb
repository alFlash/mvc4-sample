'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security
Imports system
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.UI.WebControls


Namespace Personify.DNN.Modules.Login

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Profile UserModuleBase is used to register Users
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	03/02/2006
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ProfileCtrl
        Inherits UserModuleBase

#Region "Events"

        Public Event ProfileUpdated As System.EventHandler
        Public Event ProfileUpdateCompleted As System.EventHandler

#End Region

#Region "Controls"
        Protected WithEvents cmdUpdate As CommandButton
        Protected WithEvents ProfileProperties As ProfileEditorControl
        Protected WithEvents trTitle As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblTitle As System.Web.UI.WebControls.Label
#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the EditorMode
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/02/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property EditorMode() As PropertyEditorMode
            Get
                Return ProfileProperties.EditMode()
            End Get
            Set(ByVal Value As PropertyEditorMode)
                ProfileProperties.EditMode = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the User is valid
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/18/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property IsValid() As Boolean
            Get
                Dim _IsValid As Boolean = False

                If ProfileProperties.IsValid Or IsAdmin Then
                    _IsValid = True
                End If

                Return _IsValid
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether the Update button
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/18/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ShowUpdate() As Boolean
            Get
                Return cmdUpdate.Visible
            End Get
            Set(ByVal Value As Boolean)
                cmdUpdate.Visible = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the UserProfile associated with this control
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/02/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property UserProfile() As DotNetNuke.Entities.Users.UserProfile
            Get
                Dim _Profile As DotNetNuke.Entities.Users.UserProfile = Nothing
                If Not User Is Nothing Then
                    _Profile = User.Profile
                End If
                Return _Profile
            End Get
        End Property

#End Region

#Region "Private Methods"


#End Region

#Region "Event Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Raises the OnProfileUpdateCompleted Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	07/13/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub OnProfileUpdateCompleted(ByVal e As System.EventArgs)

            RaiseEvent ProfileUpdateCompleted(Me, e)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Raises the ProfileUpdated Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub OnProfileUpdated(ByVal e As EventArgs)

            RaiseEvent ProfileUpdated(Me, e)

        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DataBind binds the data to the controls
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub DataBind()

            If IsAdmin Then
                lblTitle.Text = String.Format(Localization.GetString("ProfileTitle.Text", LocalResourceFile), User.Username, User.UserID.ToString)
            Else
                trTitle.Visible = False
            End If

            'Before we bind the Profile to the editor we need to "update" the visible data
            Dim properties As ProfilePropertyDefinitionCollection = UserProfile.ProfileProperties

            For Each profProperty As ProfilePropertyDefinition In properties
                If IsAdmin Then
                    profProperty.Visible = True
                End If
            Next

            ProfileProperties.DataSource = UserProfile.ProfileProperties
            ProfileProperties.DataBind()

        End Sub

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Init runs when the control is initialised
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Init(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Init

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ProfileProperties.LocalResourceFile = Me.LocalResourceFile
            '3246-5774803
            LoadImages()
            'END 3246-5774803
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the Update Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click

            If IsValid Then
                Dim properties As ProfilePropertyDefinitionCollection = CType(ProfileProperties.DataSource, ProfilePropertyDefinitionCollection)

                'Update User's profile
                User = ProfileController.UpdateUserProfile(User, properties)

                OnProfileUpdated(System.EventArgs.Empty)
                OnProfileUpdateCompleted(System.EventArgs.Empty)
            End If

        End Sub

#End Region
#Region "Images Functions"
        '3246-5774803
        Private Sub LoadImages()

            cmdUpdate.ImageUrl = ResolveUrl("~/" & "DefaultPersonifyImages" & "/save.gif")
        End Sub
        'END 3246-5774803
#End Region

    End Class

End Namespace


