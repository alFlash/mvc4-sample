Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


Namespace Personify.DNN.Modules.Login

    Public MustInherit Class LoginEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents rbtCanPurchaseMemberOnlyProducts As RadioButtonList
        Protected WithEvents txtMasterCustomerId As TextBox
        Protected WithEvents txtSubCustomerId As TextBox
        Protected WithEvents cvValidate As CustomValidator

        Protected WithEvents pnlRegister As Panel
        Protected WithEvents chkShowRegister As CheckBox
        Protected WithEvents pnlRegisterActionURL As Panel
        Protected WithEvents drpRegisterActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents chkRegisterActionURL As CheckBox
        Protected WithEvents chkRememberMe As CheckBox

        Protected WithEvents chkActivateAccountActionURL As CheckBox
        Protected WithEvents pnlActivateAccountActionURL As Panel
        Protected WithEvents drpActivateAccountActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents drpChangePasswordActionURL As DotNetNuke.UI.UserControls.UrlControl
        'Protected WithEvents drpSSOURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents txtSSOURL As New TextBox
        Protected WithEvents chkForgotPasswordActionURL As CheckBox
        Protected WithEvents chkRedirectSSOURL As New CheckBox
        'Protected WithEvents txtSSORedirectUrl As TextBox
        Protected WithEvents pnlForgotPasswordActionURL As Panel
        Protected WithEvents drpForgotPasswordActionURL As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents rftxtSSOURL As System.Web.UI.WebControls.RequiredFieldValidator

#End Region

#Region "Private Members"
        Private itemId As Integer

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ' Determine ItemId
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Null.NullInteger()
                End If

                If Not Page.IsPostBack Then
                    LoadSettings()
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub Pre_Render(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            Dim oModules As New Entities.Modules.ModuleController
            With oModules
                If (oModules.GetModuleSettings(ModuleId).ContainsKey("HostMasterCustomerId") AndAlso oModules.GetModuleSettings(ModuleId).ContainsKey("HostSubCustomerId") AndAlso oModules.GetModuleSettings(ModuleId).ContainsKey("HostCanPurchaseMemberOnlyProducts")) Then
                    txtMasterCustomerId.Text = .GetModuleSettings(ModuleId).Item("HostMasterCustomerId").ToString
                    txtSubCustomerId.Text = .GetModuleSettings(ModuleId).Item("HostSubCustomerId").ToString
                    rbtCanPurchaseMemberOnlyProducts.SelectedValue = .GetModuleSettings(ModuleId).Item("HostCanPurchaseMemberOnlyProducts").ToString
                End If                
            End With
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                If (cvValidate.IsValid) AndAlso Page.IsValid Then
                    Dim oModules As New Entities.Modules.ModuleController
                    With oModules
                        .UpdateModuleSetting(ModuleId, "HostMasterCustomerId", txtMasterCustomerId.Text)
                        .UpdateModuleSetting(ModuleId, "HostSubCustomerId", txtSubCustomerId.Text)
                        .UpdateModuleSetting(ModuleId, "HostCanPurchaseMemberOnlyProducts", rbtCanPurchaseMemberOnlyProducts.SelectedValue)
                        If chkForgotPasswordActionURL.Checked Then
                            .UpdateModuleSetting(ModuleId, "ShowForgotPasswordLink", "Y")
                            .UpdateModuleSetting(ModuleId, "ForgotPasswordActionURL", drpForgotPasswordActionURL.Url)
                        Else
                            .UpdateModuleSetting(ModuleId, "ShowForgotPasswordLink", "N")
                        End If
                        If chkActivateAccountActionURL.Checked Then
                            .UpdateModuleSetting(ModuleId, "ShowActivateAccountLink", "Y")
                            .UpdateModuleSetting(ModuleId, "ActivateAccountActionURL", drpActivateAccountActionURL.Url)
                        Else
                            .UpdateModuleSetting(ModuleId, "ShowActivateAccountLink", "N")
                        End If
                        If chkRedirectSSOURL.Checked Then
                            .UpdateModuleSetting(ModuleId, "chkRedirectSSOURL", "Y")
                            .UpdateModuleSetting(ModuleId, "SSOURL", txtSSOURL.Text)
                        Else
                            .UpdateModuleSetting(ModuleId, "chkRedirectSSOURL", "N")
                        End If

                        .UpdateModuleSetting(ModuleId, "ChangePasswordActionURL", drpChangePasswordActionURL.Url)

                        If chkShowRegister.Checked Then
                            .UpdateModuleSetting(ModuleId, "ShowRegister", "Y")
                            If chkRegisterActionURL.Checked Then
                                .UpdateModuleSetting(ModuleId, "UseCustomerRegistrationActionURL", "Y")
                                .UpdateModuleSetting(ModuleId, "CustomerRegistrationActionURL", drpRegisterActionURL.Url)
                            Else
                                .UpdateModuleSetting(ModuleId, "UseCustomerRegistrationActionURL", "N")
                            End If
                        Else
                            .UpdateModuleSetting(ModuleId, "ShowRegister", "N")
                        End If

                        If chkRememberMe.Checked Then
                            .UpdateModuleSetting(ModuleId, "ShowRememberMe", "Y")
                        Else
                            .UpdateModuleSetting(ModuleId, "ShowRememberMe", "N")
                        End If

                    End With

                    Response.Redirect(NavigateURL(), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub chkForgotPasswordActionURL_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chkForgotPasswordActionURL.CheckedChanged
            If chkForgotPasswordActionURL.Checked Then
                pnlForgotPasswordActionURL.Visible = True
            Else
                pnlForgotPasswordActionURL.Visible = False
            End If

        End Sub

        Private Sub chkActivateAccountActionURL_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chkActivateAccountActionURL.CheckedChanged
            If chkActivateAccountActionURL.Checked Then
                pnlActivateAccountActionURL.Visible = True
            Else
                pnlActivateAccountActionURL.Visible = False
            End If

        End Sub

        Private Sub chkShowRegister_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chkShowRegister.CheckedChanged
            If chkShowRegister.Checked Then
                pnlRegister.Visible = True
                chkRegisterActionURL.Checked = False
                pnlRegisterActionURL.Visible = False
            Else
                pnlRegister.Visible = False
                chkRegisterActionURL.Checked = False
                pnlRegisterActionURL.Visible = False
            End If
        End Sub

        Private Sub chkRegisterActionURL_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chkRegisterActionURL.CheckedChanged
            If chkRegisterActionURL.Checked Then
                pnlRegisterActionURL.Visible = True
            Else
                pnlRegisterActionURL.Visible = False
            End If
        End Sub

        Protected Sub ValidateInput(ByVal source As Object, ByVal args As ServerValidateEventArgs)
            cvValidate.ErrorMessage = Localization.GetString("InputErrorMessage", LocalResourceFile).ToString
            If (txtMasterCustomerId.Text = "" OrElse txtSubCustomerId.Text = "") Then
                txtSubCustomerId.Text = ""
                txtMasterCustomerId.Text = ""
                args.IsValid = True
                Return
            End If
            args.IsValid = CheckMasterAndSubCustomerId(txtMasterCustomerId.Text, txtSubCustomerId.Text)
        End Sub

        Private Function CheckMasterAndSubCustomerId(ByVal MasterCustomerId As String, ByVal SubCustomerId As String) As Boolean

            'Dim tempCustomer As TIMSS.API.CustomerInfo.ICustomers = ApplicationManager.Customer.GetCustomer(PortalId, MasterCustomerId, SubCustomerId)

            'If (tempCustomer.Count = 0) Then
            '    Return False
            'End If

            Return True
        End Function

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub chkRedirectSSOURL_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkRedirectSSOURL.CheckedChanged
            If chkRedirectSSOURL.Checked Then
                txtSSOURL.Visible = True
                rftxtSSOURL.Enabled = True
            Else
                txtSSOURL.Visible = False
                rftxtSSOURL.Enabled = False
            End If
        End Sub
#End Region

#Region " Helper functions"

        Private Sub LoadSettings()

            


            If Not Settings("ShowRegister") Is Nothing Then
                If CType(Settings("ShowRegister"), String) = "Y" Then
                    chkShowRegister.Checked = True
                    pnlRegister.Visible = True
                    If Not Settings("UseCustomerRegistrationActionURL") Is Nothing Then
                        If CType(Settings("UseCustomerRegistrationActionURL"), String) = "Y" Then
                            chkRegisterActionURL.Checked = True
                            pnlRegisterActionURL.Visible = True
                            If Not Settings("CustomerRegistrationActionURL") Is Nothing Then
                                drpRegisterActionURL.Url = CType(Settings("CustomerRegistrationActionURL"), String)
                            End If
                        Else
                            chkRegisterActionURL.Checked = False
                            pnlRegisterActionURL.Visible = False
                        End If
                    Else
                        chkRegisterActionURL.Checked = False
                        pnlRegisterActionURL.Visible = False
                    End If
                Else
                    chkShowRegister.Checked = False
                    pnlRegister.Visible = False
                    chkRegisterActionURL.Checked = False
                    pnlRegisterActionURL.Visible = False
                End If
            Else
                chkShowRegister.Checked = False
                pnlRegister.Visible = False
                chkRegisterActionURL.Checked = False
                pnlRegisterActionURL.Visible = False
            End If


            If Not Settings("ShowForgotPasswordLink") Is Nothing Then
                If CType(Settings("ShowForgotPasswordLink"), String) = "Y" Then
                    chkForgotPasswordActionURL.Checked = True
                    pnlForgotPasswordActionURL.Visible = True
                    If Not Settings("ForgotPasswordActionURL") Is Nothing Then
                        drpForgotPasswordActionURL.Url = CType(Settings("ForgotPasswordActionURL"), String)
                    End If
                Else
                    chkForgotPasswordActionURL.Checked = False
                    pnlForgotPasswordActionURL.Visible = False
                End If
            Else
                chkForgotPasswordActionURL.Checked = False
                pnlForgotPasswordActionURL.Visible = False
            End If


            If Not Settings("ShowActivateAccountLink") Is Nothing Then
                If CType(Settings("ShowActivateAccountLink"), String) = "Y" Then
                    chkActivateAccountActionURL.Checked = True
                    pnlActivateAccountActionURL.Visible = True
                    If Not Settings("ActivateAccountActionURL") Is Nothing Then
                        drpActivateAccountActionURL.Url = CType(Settings("ActivateAccountActionURL"), String)
                    End If
                Else
                    chkActivateAccountActionURL.Checked = False
                    pnlActivateAccountActionURL.Visible = False
                End If
            Else
                chkActivateAccountActionURL.Checked = False
                pnlActivateAccountActionURL.Visible = False
            End If

            If Not Settings("ChangePasswordActionURL") Is Nothing Then
                drpChangePasswordActionURL.Url = CType(Settings("ChangePasswordActionURL"), String)
            End If

            If Not Settings("ShowRememberMe") Is Nothing Then
                If CType(Settings("ShowRememberMe"), String) = "Y" Then
                    Me.chkRememberMe.Checked = True
                End If
            End If
            
             'modification by vijay
            
            If Not Settings("chkRedirectSSOURL") Is Nothing Then
                If CType(Settings("chkRedirectSSOURL"), String) = "Y" Then
                    chkRedirectSSOURL.Checked = True
                    txtSSOURL.Visible = True
                    If Not Settings("SSOURL") Is Nothing Then
                        txtSSOURL.Text = CType(Settings("SSOURL"), String)
                    End If
                Else
                    chkRedirectSSOURL.Checked = False
                    txtSSOURL.Visible = False
                End If
            Else
                chkRedirectSSOURL.Checked = False
                txtSSOURL.Visible = False
            End If

        End Sub
#End Region

 
        
#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
