Imports System.Web.Security
Imports AspNetSecurity = System.Web.Security
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.Security.Roles
Imports DotNetNuke
Imports DotNetNuke.UI
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.UI.Skins.Controls.ModuleMessage
Imports DotNetNuke.UI.WebControls
Imports DotNetNuke.UI.UserControls
Imports Personify
Imports System.Xml

Imports System.Configuration
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Imports Microsoft.ApplicationBlocks.Data
Imports Personify.ApplicationManager.PersonifyEnumerations

'Test

Namespace Personify.DNN.Modules.Login
    Public MustInherit Class Login
        Inherits Entities.Modules.UserModuleBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Private Members"

        Private ipAddress As String
        Private strPropertyDefinitionXmlFile As String
        Private strShoppingCartDataProviderFile As String
        Private m_objProperties As Entities.Profile.ProfilePropertyDefinitionCollection

#End Region

#Region "Controls"

        Protected WithEvents ctlProfile As ProfileCtrl '= CType(LoadControl("~/controls/ProfileCtrl.ascx"), UserControls.ProfileCtrl)
        Protected WithEvents ctlPassword As PasswordCtrl '= CType(LoadControl("~/controls/PasswordCtrl.ascx"), UserControls.PasswordCtrl)
        Protected WithEvents cmdRegister As System.Web.UI.WebControls.Button
        Protected WithEvents cmdProceed As CommandButton
        Protected WithEvents cmdPassword As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdActivateAccount As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdLogin As System.Web.UI.WebControls.Button
        Protected WithEvents chkCookie As System.Web.UI.WebControls.CheckBox
        Protected WithEvents pnlProceed As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlPassword As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlProfile As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlLogin As System.Web.UI.WebControls.Panel

        Protected WithEvents lblLogin As System.Web.UI.WebControls.Label
        Protected WithEvents TDRegister As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtVerification As System.Web.UI.WebControls.TextBox
        Protected WithEvents ctlCaptcha As CaptchaControl
        Protected WithEvents rowVerification1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowVerification2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents trCaptcha1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents trCaptcha2 As System.Web.UI.HtmlControls.HtmlTableRow
#End Region

#Region "Protected Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Redirect URL (after successful login)
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	04/18/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property RedirectURL() As String
            Get
                Dim _RedirectURL As String = ""

                If Not Request.QueryString("returnurl") Is Nothing Then
                    ' return to the url passed to signin
                    _RedirectURL = HttpUtility.UrlDecode(Request.QueryString("returnurl"))
                Else
                    Dim setting As Object = DotNetNuke.Entities.Modules.UserModuleBase.GetSetting(PortalId, "Redirect_AfterLogin")

                    If CType(setting, Integer) = Null.NullInteger Then
                        If PortalSettings.LoginTabId <> -1 And PortalSettings.HomeTabId <> -1 Then
                            ' redirect to portal home page specified
                            _RedirectURL = NavigateURL(PortalSettings.HomeTabId)
                        Else
                            ' redirect to current page 
                            _RedirectURL = NavigateURL(Me.TabId)
                        End If
                    Else ' redirect to after login page
                        _RedirectURL = NavigateURL(CType(setting, Integer))
                    End If
                End If

                If _RedirectURL.ToLower.StartsWith("http") Then
                    If Not _RedirectURL.ToLower.StartsWith("http://" + Request.Url.Host.ToLower + "/") And Not _RedirectURL.ToLower.StartsWith("https://" + Request.Url.Host.ToLower + "/") Then
                        Return NavigateURL(PortalSettings.HomeTabId)
                    End If
                End If

                Return _RedirectURL

            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the Captcha control is used to validate the login
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/17/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property UseCaptcha() As Boolean
            Get
                Dim setting As Object = GetSetting(PortalId, "Security_CaptchaLogin")
                Return CType(setting, Boolean)
            End Get
        End Property

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the current Page No
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property PageNo() As Integer
            Get
                Dim _PageNo As Integer = 0
                If Not ViewState("PageNo") Is Nothing Then
                    _PageNo = CInt(ViewState("PageNo"))
                End If
                Return _PageNo
            End Get
            Set(ByVal Value As Integer)
                ViewState("PageNo") = Value
            End Set
        End Property

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddLocalizedModuleMessage adds a localized module message
        ''' </summary>
        ''' <param name="message">The localized message</param>
        ''' <param name="type">The type of message</param>
        ''' <param name="display">A flag that determines whether the message should be displayed</param>
        ''' <history>
        ''' 	[cnurse]	03/14/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Sub AddLocalizedModuleMessage(ByVal message As String, ByVal type As ModuleMessageType, ByVal display As Boolean)

            If display Then
                UI.Skins.Skin.AddModuleMessage(Me, message, type)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleMessage adds a module message
        ''' </summary>
        ''' <param name="message">The message</param>
        ''' <param name="type">The type of message</param>
        ''' <param name="display">A flag that determines whether the message should be displayed</param>
        ''' <history>
        ''' 	[cnurse]	03/14/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Sub AddModuleMessage(ByVal message As String, ByVal type As ModuleMessageType, ByVal display As Boolean)

            AddLocalizedModuleMessage(Localization.GetString(message, LocalResourceFile), type, display)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ShowPanel controls what "panel" is to be displayed
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/21/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ShowPanel()

            Dim showLogin As Boolean = (PageNo = 0)
            Dim showPassword As Boolean = (PageNo = 1)
            Dim showProfile As Boolean = (PageNo = 2)

            pnlPassword.Visible = showPassword
            pnlProfile.Visible = showProfile
            pnlLogin.Visible = showLogin

            Select Case PageNo
                Case 0
                    If PortalSettings.UserRegistration = PortalRegistrationType.NoRegistration Then
                        TDRegister.Visible = False
                    End If
                    txtPassword.Attributes.Add("value", txtPassword.Text)
                    lblLogin.Text = Localization.GetSystemMessage(PortalSettings, "MESSAGE_LOGIN_INSTRUCTIONS")
                Case 1
                    'ctlPassword.UserId = UserId
                    'ctlPassword.DataBind()
                    'Response.Redirect("http://www.google.com")
                    Response.Redirect(NavigateURL(CType(Settings("ChangePasswordActionURL"), Integer)))
                Case 2
                    ctlProfile.UserId = UserId
                    ctlProfile.DataBind()
            End Select

            trCaptcha1.Visible = UseCaptcha
            trCaptcha2.Visible = UseCaptcha

            If UseCaptcha Then
                ctlCaptcha.ErrorMessage = Localization.GetString("InvalidCaptcha", Me.LocalResourceFile)
                ctlCaptcha.Text = Localization.GetString("CaptchaText", Me.LocalResourceFile)
            End If


            If Not Settings("ShowForgotPasswordLink") Is Nothing Then
                If CType(Settings("ShowForgotPasswordLink"), String) = "Y" Then
                    cmdPassword.Visible = True
                Else
                    cmdPassword.Visible = False
                End If
            Else
                cmdPassword.Visible = False
            End If


            If Not Settings("ShowActivateAccountLink") Is Nothing Then
                If CType(Settings("ShowActivateAccountLink"), String) = "Y" Then
                    cmdActivateAccount.Visible = True
                Else
                    cmdActivateAccount.Visible = False
                End If
            Else
                cmdActivateAccount.Visible = False
            End If

            If Not Settings("ShowRegister") Is Nothing Then
                If CType(Settings("ShowRegister"), String) = "Y" Then
                    cmdRegister.Visible = True
                Else
                    cmdRegister.Visible = False
                End If
            Else
                cmdRegister.Visible = False
            End If

            If Not Settings("ShowRememberMe") Is Nothing Then
                If CType(Settings("ShowRememberMe"), String) = "Y" Then
                    chkCookie.Visible = True
                Else
                    chkCookie.Visible = False
                End If
            Else
                chkCookie.Visible = False
            End If


        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UserAuthorized runs when the user has been authorized by the data store
        ''' </summary>
        ''' <param name="objUser">The logged in User</param>
        ''' <history>
        ''' 	[cnurse]	03/15/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UserAuthorized(ByVal objUser As UserInfo, ByVal canProceed As Boolean, ByVal IsPasswordChangeRequired As Boolean)

            Dim updatePassword As Boolean = False
            Dim updateProfile As Boolean = False
            Dim strMessage As String

            UserId = objUser.UserID

            'Set the Page Culture(Language) based on the Users Preferred Locale
            'If (Not objUser.Profile Is Nothing) AndAlso (Not objUser.Profile.PreferredLocale Is Nothing) Then
            '    Localization.SetLanguage(objUser.Profile.PreferredLocale)
            'Else
            '    Localization.SetLanguage(PortalSettings.DefaultLanguage)
            'End If

            'Check whether Password needs updating
            If PasswordConfig.PasswordExpiry > 0 Then
                Dim expiryDate As DateTime = objUser.Membership.LastPasswordChangeDate.AddDays(PasswordConfig.PasswordExpiry)
                If expiryDate < Today Then
                    'Password Expired
                    strMessage = String.Format(Localization.GetString("PasswordExpired", Me.LocalResourceFile), expiryDate.ToLongDateString)
                    AddLocalizedModuleMessage(strMessage, ModuleMessageType.YellowWarning, True)
                    updatePassword = True
                    pnlProceed.Visible = False
                End If
                If (Not updatePassword) And expiryDate < Today.AddDays(PasswordConfig.PasswordExpiryReminder) Then
                    'Password update reminder
                    strMessage = String.Format(Localization.GetString("PasswordExpiring", Me.LocalResourceFile), expiryDate.ToLongDateString)
                    AddLocalizedModuleMessage(strMessage, ModuleMessageType.YellowWarning, True)
                    updatePassword = Not canProceed
                    pnlProceed.Visible = True
                    '3246-5774803
                    cmdProceed.ImageUrl = GetRTImageURL()
                    'END 3246-5774803
                End If
            End If
            If (Not updatePassword) And objUser.Membership.UpdatePassword Then
                'Admin has forced password update
                AddModuleMessage("PasswordUpdate", ModuleMessageType.YellowWarning, True)
                updatePassword = True
            End If

            'Check whether Profile needs updating
            If (Not updatePassword) Then
                'Admin has forced password update
                AddModuleMessage("ProfileUpdate", ModuleMessageType.YellowWarning, True)
                'updateProfile = Not ProfileController.ValidateProfile(PortalId, objUser.Profile)
            End If

            If updatePassword Then
                PageNo = 1

            ElseIf updateProfile Then
                PageNo = 2
                '            ElseIf IsPasswordChangeRequired Then
                '               Response.Redirect(NavigateURL(CType(Settings("ChangePasswordActionURL"), Integer)))
            Else
                'Complete Login
                'UserController.UserLogin(PortalId, objUser, PortalSettings.PortalName, ipAddress, chkCookie.Checked)

                ' redirect browser
                Response.Redirect(RedirectURL, True)


            End If

            ShowPanel()


        End Sub

     
        'Private Function WindowsAuthorization(ByRef loginStatus As UserLoginStatus) As UserInfo

        '    Dim strMessage As String = Null.NullString

        '    Dim objUser As UserInfo = UserController.GetUserByName(PortalSettings.PortalId, txtUsername.Text, False)
        '    Dim objAuthentication As New DotNetNuke.Security.Authentication.AuthenticationController
        '    Dim objAuthUser As DotNetNuke.Security.Authentication.UserInfo = objAuthentication.ProcessFormAuthentication(txtUsername.Text, txtPassword.Text)
        '    Dim _userID As Integer = -1

        '    If (Not objAuthUser Is Nothing) AndAlso (objUser Is Nothing) Then
        '        ' Add this user into DNN database for better performance on next logon
        '        Dim createStatus As UserCreateStatus
        '        Dim objAuthUsers As New DotNetNuke.Security.Authentication.UserController
        '        createStatus = objAuthUsers.AddDNNUser(objAuthUser)
        '        _userID = objAuthUser.UserID

        '        ' Windows/DNN password validation should be same, check this status here
        '        strMessage = UserController.GetUserCreateStatus(createStatus)
        '    ElseIf (Not objAuthUser Is Nothing) AndAlso (Not objUser Is Nothing) Then
        '        ' User might has been imported by Admin or automatically added with random password
        '        ' update DNN password to match with authenticated password from AD                            
        '        If objUser.Membership.Password <> txtPassword.Text Then
        '            UserController.ChangePassword(objUser, objUser.Membership.Password, txtPassword.Text)
        '        End If
        '        _userID = objUser.UserID
        '    End If

        '    If (_userID > 0) Then
        '        ' Authenticated with DNN
        '        objUser = UserController.ValidateUser(PortalId, txtUsername.Text, txtPassword.Text, "", PortalSettings.PortalName, ipAddress, loginStatus)
        '        If loginStatus <> UserLoginStatus.LOGIN_SUCCESS Then
        '            strMessage = Localization.GetString("LoginFailed", Me.LocalResourceFile)
        '        End If
        '    Else
        '        objUser = Nothing
        '    End If

        '    AddLocalizedModuleMessage(strMessage, ModuleMessageType.RedError, strMessage <> "")

        '    Return objUser

        'End Function

#End Region

#Region "Public Methods"

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Init runs when the control is initialised
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'Set the Password Control Properties
            ctlPassword.ID = "Password"

            'Set the Profile Control Properties
            ctlProfile.ID = "Profile"
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            HandleSSORedirection() 'SSO integration call

            ' Verify if portal has a customized login page
            If Not Null.IsNull(PortalSettings.LoginTabId) And IsAdminControl() Then
                ' login page exists and trying to access this control directly with url param -> not allowed
                Response.Redirect(NavigateURL(PortalSettings.LoginTabId))
            End If

            'DotNetNuke.UI.Utilities.ClientAPI.RegisterKeyCapture(Me.Parent, Me.cmdLogin, Asc(vbCr))

            If Not Request.UserHostAddress Is Nothing Then
                ipAddress = Request.UserHostAddress
            End If

            If Page.IsPostBack = False Then
                Try
                    If Not Request.QueryString("verificationcode") Is Nothing Then
                        If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                            'Display Verification Rows 
                            rowVerification1.Visible = True
                            rowVerification2.Visible = True
                            txtVerification.Text = Request.QueryString("verificationcode")
                        End If
                    End If

                    PageNo = 0
                    If Not Request.QueryString("username") Is Nothing Then
                        txtUsername.Text = Request.QueryString("username")
                        SetFormFocus(txtPassword)
                    Else
                        SetFormFocus(txtUsername)
                    End If
                Catch
                    'control not there or error setting focus
                End Try
            End If
            If Not UserInfo.IsSuperUser AndAlso Not UserInfo.Profile.ProfileProperties("MasterCustomerId") Is Nothing AndAlso Not UserInfo.Profile.ProfileProperties("SubCustomerId") Is Nothing Then
                'hide Login web part after a successfull login
                Me.Parent.Parent.Parent.Visible = False
                Exit Sub
            End If
            ShowPanel()

        End Sub

        '' -----------------------------------------------------------------------------
        '' <summary>
        '' cmdLogin_Click runs when the login button is clicked
        '' </summary>
        '' <remarks>
        '' </remarks>
        '' <history>
        '' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
        ''                       and localisation
        ''     [cnurse]    12/11/2005  Updated to reflect abstraction of Membership
        '' </history>
        '' -----------------------------------------------------------------------------
        'Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click

        '    'Dim oLoginManager As New Personify.LoginManager()

        '    'oLoginManager.Login(txtUsername.Text, txtPassword.Text)

        '    CheckCustomerProfileProperty()
        '    SyncronizeAccounts()
        '    If (UseCaptcha And ctlCaptcha.IsValid) OrElse (Not UseCaptcha) Then
        '        'Try to validate user
        '        Dim loginStatus As UserLoginStatus
        '        Dim objUser As UserInfo = UserController.ValidateUser(PortalId, txtUsername.Text, txtPassword.Text, txtVerification.Text, PortalSettings.PortalName, ipAddress, loginStatus)

        '        If objUser Is Nothing Then  'Some kind of Login failure
        '            If loginStatus = UserLoginStatus.LOGIN_FAILURE Then
        '                'Try Windows Authorization 
        '                '(user may be authorized in Windows, but not in DNN yet)
        '                objUser = WindowsAuthorization(loginStatus)
        '            End If
        '        End If

        '        If objUser Is Nothing Then
        '            Select Case loginStatus
        '                Case UserLoginStatus.LOGIN_USERNOTAPPROVED
        '                    'Check if its the first time logging in to a verified site
        '                    If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
        '                        If Not rowVerification1.Visible Then
        '                            'Display Verification Rows so User can enter verification code
        '                            rowVerification1.Visible = True
        '                            rowVerification2.Visible = True
        '                        Else
        '                            If txtVerification.Text <> "" Then
        '                                AddModuleMessage("InvalidCode", ModuleMessageType.RedError, True)
        '                            Else
        '                                AddModuleMessage("EnterCode", ModuleMessageType.GreenSuccess, True)
        '                            End If
        '                        End If
        '                    End If
        '                Case UserLoginStatus.LOGIN_USERLOCKEDOUT
        '                    AddModuleMessage("UserLockedOut", ModuleMessageType.RedError, True)
        '                    ' notify administrator about account lockout ( possible hack attempt )
        '                    Dim Custom As New ArrayList
        '                    Custom.Add(txtUsername.Text)
        '                    Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", _
        '                        Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_SUBJECT", Localization.GlobalResourceFile, Custom), _
        '                        Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_BODY", Localization.GlobalResourceFile, Custom), _
        '                        "", "", "", "", "", "")
        '                Case UserLoginStatus.LOGIN_FAILURE
        '                    AddModuleMessage("LoginFailed", ModuleMessageType.RedError, True)
        '            End Select
        '        Else    'Login Success
        '            If Not (objUser.IsSuperUser) Then
        '                If objUser.Profile.ProfileProperties.GetByName("SubCustomerId") IsNot Nothing And objUser.Profile.ProfileProperties.GetByName("MasterCustomerId") IsNot Nothing Then
        '                    If (objUser.Profile.ProfileProperties.GetByName("SubCustomerId").PropertyValue = "") Then
        '                        TransferCartToTIMSSUser( _
        '                        CType(objUser.Profile.ProfileProperties.GetByName("MasterCustomerId").PropertyValue, String), 0)
        '                    Else
        '                        TransferCartToTIMSSUser( _
        '                        CType(objUser.Profile.ProfileProperties.GetByName("MasterCustomerId").PropertyValue, String), _
        '                        CType(objUser.Profile.ProfileProperties.GetByName("SubCustomerId").PropertyValue, Integer))
        '                    End If
        '                End If
        '            End If
        '            UserAuthorized(objUser, False)
        '        End If
        '    End If

        'End Sub
        Public Sub ClearAllSessionObjects()

            'Dim SessionKeyList As String() = System.Enum.GetNames(GetType(SessionKeys))
            'Dim ActualKey As String

            'For Each Key As String In SessionKeyList
            '    ActualKey = "Personify" + "_" + PortalId.ToString + "_" + Key.ToString
            '    HttpContext.Current.Session.Remove(ActualKey)
            'Next

            Dim SessionKeyList As String() = System.Enum.GetNames(GetType(SessionKeys))
            Dim ActualKey As String

            For Each Key As String In SessionKeyList
                'ActualKey = "Personify" + "_" + PortalId.ToString + "_" + Key.ToString
                ActualKey = String.Concat("Personify_", PortalId.ToString, Key.ToString)
                HttpContext.Current.Session.Remove(ActualKey)
            Next

        End Sub


        Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click
            'Dim loginStatus As UserLoginStatus
            Dim oLoginManager As New Personify.LoginManager(txtUsername.Text, txtPassword.Text)
            Dim oRetLoginStatus As Personify.LoginStatus
            'Dim objUser As UserInfo = Nothing

            
            '3246-5798961            
            ClearAllSessionObjects()

            oLoginManager.UseCaptcha = UseCaptcha
            oLoginManager.IsCaptchaValid = ctlCaptcha.IsValid
            oLoginManager.VerificationTextRequired = UseCaptcha
            oLoginManager.VerificationText = txtVerification.Text
            oLoginManager.CreatePersistantCookie = chkCookie.Checked
            oLoginManager.LoginModuleId = ModuleId

            Dim IsPasswordChangeRequired As Boolean = False
            Dim TempMasterCustomerId As String = Nothing
            Dim TempSubCustomerId As Integer = 0

            oRetLoginStatus = oLoginManager.Login()

            If oRetLoginStatus.IsPasswordChangeRequired = True Then
                '3246-7164569 
                TempMasterCustomerId = oRetLoginStatus.MasterCustomerId
                TempSubCustomerId = oRetLoginStatus.SubCustomerId

                Dim returnurl As String = ""
                If Request("returnurl") IsNot Nothing AndAlso Convert.ToString(Request("returnurl")).Length > 0 Then
                    returnurl = Request("returnurl")
                End If

                Dim url As String = NavigateURL(CType(Settings("ChangePasswordActionURL"), Integer), "", "mcid=" + TempMasterCustomerId.ToString + "&scid=" + TempSubCustomerId.ToString)

                'If returnurl IsNot Nothing AndAlso returnurl.Length > 0 Then
                '    'Response.Redirect(url + "&returnurl=" + returnurl)
                'End If
                If url.IndexOf("?") > 0 Then
                    url = url + "&returnurl=" + returnurl
                Else
                    url = url + "?returnurl=" + returnurl
                End If
                Response.Redirect(url)
            End If

            If oRetLoginStatus.objUser Is Nothing Then
                Select Case oRetLoginStatus.loginStatus
                    Case UserLoginStatus.LOGIN_USERNOTAPPROVED
                        'Check if its the first time logging in to a verified site
                        If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                            If Not rowVerification1.Visible Then
                                'Display Verification Rows so User can enter verification code
                                rowVerification1.Visible = True
                                rowVerification2.Visible = True
                            Else
                                If txtVerification.Text <> "" Then
                                    AddModuleMessage("InvalidCode", ModuleMessageType.RedError, True)
                                Else
                                    AddModuleMessage("EnterCode", ModuleMessageType.GreenSuccess, True)
                                End If
                            End If
                        Else
                            AddModuleMessage("UserNotAuthorized", ModuleMessageType.RedError, True)
                        End If
                    Case UserLoginStatus.LOGIN_USERLOCKEDOUT
                        AddModuleMessage("UserLockedOut", ModuleMessageType.RedError, True)
                        ' notify administrator about account lockout ( possible hack attempt )
                        Dim Custom As New ArrayList
                        Custom.Add(txtUsername.Text)
                        Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", _
                            Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_SUBJECT", Localization.GlobalResourceFile, Custom), _
                            Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_BODY", Localization.GlobalResourceFile, Custom), _
                            "", "", "", "", "", "")
                    Case UserLoginStatus.LOGIN_FAILURE
                        AddModuleMessage("LoginFailed", ModuleMessageType.RedError, True)
                End Select
            Else    'Login Success

                'START Check if PADSS setup is complete 
                If oRetLoginStatus.objUser.IsSuperUser AndAlso Not LoginManager.DoesPADSSAuditLogExists() Then
                    AddModuleMessage("PADSSInvalidSetup", ModuleMessageType.RedError, True)
                    Exit Sub
                Else
                    UserAuthorized(oRetLoginStatus.objUser, False, IsPasswordChangeRequired)
                End If
                'END Check if PADSS setup is complete 

            End If


        End Sub

        'Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click
        '    Dim loginStatus As UserLoginStatus
        '    Dim oLoginManager As New Personify.LoginManager()
        '    Dim objUser As UserInfo = Nothing


        '    '3246-5798961            
        '    Personify.WebUtility.SessionManager.ClearAllSessionObjects(PortalId)


        '    oLoginManager.UseCaptcha = UseCaptcha
        '    oLoginManager.IsCaptchaValid = ctlCaptcha.IsValid
        '    oLoginManager.VerificationTextRequired = UseCaptcha
        '    oLoginManager.VerificationText = txtVerification.Text
        '    oLoginManager.CreatePersistantCookie = chkCookie.Checked
        '    oLoginManager.LoginModuleId = ModuleId

        '    Dim IsPasswordChangeRequired As Boolean = False
        '    Dim TempMasterCustomerId As String = Nothing
        '    Dim TempSubCustomerId As Integer = 0

        '    oLoginManager.Login(txtUsername.Text, txtPassword.Text, loginStatus, objUser, IsPasswordChangeRequired, TempMasterCustomerId)

        '    If IsPasswordChangeRequired = True Then

        '        Dim returnurl As String = ""
        '        If Request("returnurl") IsNot Nothing AndAlso Convert.ToString(Request("returnurl")).Length > 0 Then
        '            returnurl = Request("returnurl")
        '        End If

        '        Dim url As String = NavigateURL(CType(Settings("ChangePasswordActionURL"), Integer), "", "mcid=" + TempMasterCustomerId.ToString + "&scid=" + TempSubCustomerId.ToString)

        '        'If returnurl IsNot Nothing AndAlso returnurl.Length > 0 Then
        '        '    'Response.Redirect(url + "&returnurl=" + returnurl)
        '        'End If
        '        If url.IndexOf("?") > 0 Then
        '            url = url + "&returnurl=" + returnurl
        '        Else
        '            url = url + "?returnurl=" + returnurl
        '        End If
        '        Response.Redirect(url)
        '    End If

        '    If objUser Is Nothing Then
        '        Select Case loginStatus
        '            Case UserLoginStatus.LOGIN_USERNOTAPPROVED
        '                'Check if its the first time logging in to a verified site
        '                If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
        '                    If Not rowVerification1.Visible Then
        '                        'Display Verification Rows so User can enter verification code
        '                        rowVerification1.Visible = True
        '                        rowVerification2.Visible = True
        '                    Else
        '                        If txtVerification.Text <> "" Then
        '                            AddModuleMessage("InvalidCode", ModuleMessageType.RedError, True)
        '                        Else
        '                            AddModuleMessage("EnterCode", ModuleMessageType.GreenSuccess, True)
        '                        End If
        '                    End If
        '                Else
        '                    AddModuleMessage("UserNotAuthorized", ModuleMessageType.RedError, True)
        '                End If
        '            Case UserLoginStatus.LOGIN_USERLOCKEDOUT
        '                AddModuleMessage("UserLockedOut", ModuleMessageType.RedError, True)
        '                ' notify administrator about account lockout ( possible hack attempt )
        '                Dim Custom As New ArrayList
        '                Custom.Add(txtUsername.Text)
        '                Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", _
        '                    Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_SUBJECT", Localization.GlobalResourceFile, Custom), _
        '                    Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_BODY", Localization.GlobalResourceFile, Custom), _
        '                    "", "", "", "", "", "")
        '            Case UserLoginStatus.LOGIN_FAILURE
        '                AddModuleMessage("LoginFailed", ModuleMessageType.RedError, True)
        '        End Select
        '    Else    'Login Success

        '        'START Check if PADSS setup is complete 
        '        If objUser.IsSuperUser AndAlso Not LoginManager.DoesPADSSAuditLogExists() Then
        '            AddModuleMessage("PADSSInvalidSetup", ModuleMessageType.RedError, True)
        '            Exit Sub
        '        Else
        '            UserAuthorized(objUser, False, IsPasswordChangeRequired)
        '        End If
        '        'END Check if PADSS setup is complete 

        '    End If


        'End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdPassword_Click runs when the Password Reminder button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdPassword_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles cmdPassword.Click
            'Response.Redirect(NavigateURL("SendPassword"), True)
            If Not Settings("ShowForgotPasswordLink") Is Nothing Then
                If CType(Settings("ShowForgotPasswordLink"), String) = "Y" Then
                    If Not Settings("ForgotPasswordActionURL") Is Nothing Then
                        Response.Redirect(NavigateURL(CType(Settings("ForgotPasswordActionURL"), Integer)), True)
                    End If
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdPassword_Click runs when the Activate Account button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[schira]	05/25/2007  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdActivateAccount_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles cmdActivateAccount.Click
            If Not Settings("ShowActivateAccountLink") Is Nothing Then
                If CType(Settings("ShowActivateAccountLink"), String) = "Y" Then
                    If Not Settings("ActivateAccountActionURL") Is Nothing Then
                        Response.Redirect(NavigateURL(CType(Settings("ActivateAccountActionURL"), Integer)), True)
                    End If
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdProceed_Click runs when the Proceed Anyway button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	06/30/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdProceed_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProceed.Click
            Dim _User As UserInfo = ctlPassword.User
            UserAuthorized(_User, True, False)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdRegister_Click runs when the register button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [cnurse]    12/11/2005  Updated to reflect abstraction of Membership
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRegister_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdRegister.Click
            If (Not Settings("UseCustomerRegistrationActionURL") Is Nothing) AndAlso (CType(Settings("UseCustomerRegistrationActionURL"), String) = "Y") AndAlso (Not Settings("CustomerRegistrationActionURL") Is Nothing) Then
                Response.Redirect(NavigateURL(CType(Settings("CustomerRegistrationActionURL"), Integer), True))
            Else
                If PortalSettings.UserRegistration <> PortalRegistrationType.NoRegistration Then
                    Dim registerUrl As String
                    If PortalSettings.UserTabId <> -1 Then
                        ' user defined tab
                        registerUrl = NavigateURL(PortalSettings.UserTabId)
                    Else
                        ' admin tab
                        registerUrl = NavigateURL("Register")
                    End If
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' PasswordUpdated runs when the password is updated
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/15/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub PasswordUpdated(ByVal sender As Object, ByVal e As PasswordCtrl.PasswordUpdatedEventArgs) Handles ctlPassword.PasswordUpdated

            Dim status As PasswordUpdateStatus = e.UpdateStatus

            If status = PasswordUpdateStatus.Success Then
                AddModuleMessage("PasswordChanged", ModuleMessageType.GreenSuccess, True)

                'Authorize User
                Dim _User As UserInfo = ctlPassword.User
                _User.Membership.LastPasswordChangeDate = Now()
                _User.Membership.UpdatePassword = False
                UserAuthorized(_User, True, False)
            Else
                AddModuleMessage(status.ToString(), ModuleMessageType.RedError, True)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProfileUpdated runs when the profile is updated
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProfileUpdated(ByVal sender As Object, ByVal e As System.EventArgs) Handles ctlProfile.ProfileUpdated

            'Authorize User
            UserAuthorized(ctlProfile.User, True, False)
        End Sub


#End Region

#Region "Optional Interfaces"
        Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
            Return Nothing
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
            Return Nothing
        End Function

#End Region

#Region " SSO Events"
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="oSSOInfo"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/29/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AddAccountToDnn(ByVal oSSOInfo As TIMSS.API.CustomerInfo.ICustomer)
            Try

                Dim AffiliateId As Integer
                If Not Request.Cookies("AffiliateId") Is Nothing Then
                    AffiliateId = Integer.Parse(Request.Cookies("AffiliateId").Value)
                End If

                Dim oUserCtrl As New UserController
                Dim oNewUser As New UserInfo

                Dim createStatus As UserCreateStatus

                With oNewUser
                    .Username = oSSOInfo.WebUsers(0).UserId
                    .PortalID = PortalId
                    .Profile.FirstName = oSSOInfo.FirstName
                    .Profile.LastName = oSSOInfo.LastName

                    .DisplayName = oSSOInfo.FirstName + " " + oSSOInfo.LastName
                    .Profile.Street = oSSOInfo.PrimaryAddress.Address.Address1
                    .Profile.City = oSSOInfo.PrimaryAddress.Address.City
                    .Profile.Region = oSSOInfo.PrimaryAddress.Address.County
                    .Profile.PostalCode = oSSOInfo.PrimaryAddress.Address.PostalCode
                    .Profile.Country = oSSOInfo.PrimaryAddress.Address.Country.CountryCode
                    .Profile.Telephone = oSSOInfo.PrimaryPhone
                    .Membership.Email = oSSOInfo.PrimaryEmailAddress
                    .Membership.Username = oSSOInfo.WebUsers(0).UserId
                    .Membership.Password = txtPassword.Text
                    .Membership.Approved = CBool(IIf(oSSOInfo.IsCustomerActive, True, False))
                    .AffiliateID = AffiliateId
                    '.Profile.Cell = oSSOInfo.PrimaryPhone
                    .Profile.Fax = oSSOInfo.PrimaryFax
                    .Profile.Website = oSSOInfo.PrimaryUrl

                    .Profile.ProfileProperties.GetByName("MasterCustomerId").PropertyValue = oSSOInfo.MasterCustomerId
                    .Profile.ProfileProperties.GetByName("SubCustomerId").PropertyValue = oSSOInfo.SubCustomerId.ToString
                    '.Profile.ProfileProperties.GetByName("CanPurchaseMemberOnlyProducts").PropertyValue = "True"
                    .Profile.ProfileProperties.GetByName("CanPurchaseMemberOnlyProducts").PropertyValue = oSSOInfo.CanPurchaseMemberProducts.ToString


                    createStatus = UserController.CreateUser(oNewUser)
                End With

                If createStatus = UserCreateStatus.Success Then

                    Dim oEventLog As New Services.Log.EventLog.EventLogController

                    oEventLog.AddLog(oNewUser, PortalSettings, oNewUser.UserID, oSSOInfo.WebUsers(0).UserId, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.USER_CREATED)

                    ' Add user to role define in 
                    ' the settings section
                    SyncronizeDnnRole(oNewUser, oSSOInfo)
                Else
                    ' There must have been an error
                    ' during this registration
                    Dim UserRegistrationStatus As AspNetSecurity.MembershipCreateStatus

                    UserRegistrationStatus = CType(oNewUser.UserID * -1, AspNetSecurity.MembershipCreateStatus)
                    Dim oUserController As New UserController

                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FailedCreatingUser", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="oUserInfo"></param>
        ''' <param name="oSSOInfo"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/29/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UpdateDnnAccount(ByVal oUserInfo As UserInfo, ByVal oSSOInfo As TIMSS.API.CustomerInfo.ICustomer)
            Try

                'Dim oUserInfo As New UserInfo
                Dim oUserCtrl As New UserController

                ' Update the user
                With oUserInfo
                    .FirstName = oSSOInfo.FirstName
                    .LastName = oSSOInfo.LastName
                    .DisplayName = oSSOInfo.FirstName + " " + oSSOInfo.LastName
                    .Profile.Street = oSSOInfo.PrimaryAddress.Address.Address1
                    .Profile.City = oSSOInfo.PrimaryAddress.Address.City
                    .Profile.Region = oSSOInfo.PrimaryAddress.Address.County
                    .Profile.PostalCode = oSSOInfo.PrimaryAddress.Address.PostalCode
                    .Profile.Country = oSSOInfo.PrimaryAddress.Address.Country.CountryCode

                    .Profile.ProfileProperties.GetByName("MasterCustomerId").PropertyValue = oSSOInfo.MasterCustomerId
                    .Profile.ProfileProperties.GetByName("SubCustomerId").PropertyValue = oSSOInfo.SubCustomerId.ToString
                    '.Profile.ProfileProperties.GetByName("CanPurchaseMemberOnlyProducts").PropertyValue = "True"
                    .Profile.ProfileProperties.GetByName("CanPurchaseMemberOnlyProducts").PropertyValue = oSSOInfo.CanPurchaseMemberProducts.ToString

                    If Not oSSOInfo.PrimaryPhone Is String.Empty Then
                        .Profile.Telephone = oSSOInfo.PrimaryPhone
                    End If

                    If Not oSSOInfo.PrimaryEmailAddress Is String.Empty Then
                        .Membership.Email = oSSOInfo.PrimaryEmailAddress
                    End If

                    .Membership.Username = oSSOInfo.WebUsers(0).UserId
                    '.Profile.Cell = oSSOInfo.PrimaryPhone
                    .Profile.Fax = oSSOInfo.PrimaryFax
                    '.Profile.IM = oSSOInfo.IM
                    If Not oSSOInfo.PrimaryUrl Is String.Empty Then
                        .Profile.Website = oSSOInfo.PrimaryUrl
                    End If
                    .Membership.Password = txtPassword.Text
                    .Membership.Approved = CBool(IIf(oSSOInfo.IsCustomerActive, True, False))
                End With

                UserController.UpdateUser(PortalId, oUserInfo)

                ' Add user to role
                SyncronizeDnnRole(oUserInfo, oSSOInfo)

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub UpdateAdminProfile(ByVal oUserInfo As UserInfo)
            Try
                Dim oUserCtrl As New UserController
                Dim update As Boolean
                Dim tempName As String = Nothing
                Dim oModules As New Entities.Modules.ModuleController
                If (oModules.GetModuleSettings(ModuleId).ContainsKey("HostMasterCustomerId") AndAlso oModules.GetModuleSettings(ModuleId).ContainsKey("HostSubCustomerId") AndAlso oModules.GetModuleSettings(ModuleId).ContainsKey("HostCanPurchaseMemberOnlyProducts")) Then
                    update = False

                    With oUserInfo
                        If .Profile.ProfileProperties.GetByName("MasterCustomerId") IsNot Nothing AndAlso .Profile.ProfileProperties.GetByName("SubCustomerId") IsNot Nothing Then

                            If Not (.Profile.ProfileProperties.GetByName("MasterCustomerId").PropertyValue = oModules.GetModuleSettings(ModuleId).Item("HostMasterCustomerId").ToString) Then
                                update = True
                                .Profile.ProfileProperties.GetByName("MasterCustomerId").PropertyValue = oModules.GetModuleSettings(ModuleId).Item("HostMasterCustomerId").ToString
                            End If
                            If Not (.Profile.ProfileProperties.GetByName("SubCustomerId").PropertyValue = oModules.GetModuleSettings(ModuleId).Item("HostSubCustomerId").ToString) Then
                                update = True
                                .Profile.ProfileProperties.GetByName("SubCustomerId").PropertyValue = oModules.GetModuleSettings(ModuleId).Item("HostSubCustomerId").ToString
                            End If
                            If Not (.Profile.ProfileProperties.GetByName("CanPurchaseMemberOnlyProducts").PropertyValue = oModules.GetModuleSettings(ModuleId).Item("HostCanPurchaseMemberOnlyProducts").ToString) Then
                                update = True
                                .Profile.ProfileProperties.GetByName("CanPurchaseMemberOnlyProducts").PropertyValue = oModules.GetModuleSettings(ModuleId).Item("HostCanPurchaseMemberOnlyProducts").ToString
                            End If
                            tempName = .Profile.FirstName
                            .Profile.FirstName = oUserInfo.FirstName + "1"
                        End If
                    End With
                End If

                If update Then
                    UserController.UpdateUser(PortalId, oUserInfo)
                    oUserInfo.Profile.FirstName = tempName
                    UserController.UpdateUser(PortalId, oUserInfo)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        
        Private Sub CheckCustomerProfileProperty()
            strPropertyDefinitionXmlFile = MapPath("PropertyDefinitions.xml")

            Dim oPropertyCollection As DotNetNuke.Entities.Profile.ProfilePropertyDefinitionCollection
            oPropertyCollection = New DotNetNuke.Entities.Profile.ProfilePropertyDefinitionCollection
            Dim oCollection As Entities.Profile.ProfilePropertyDefinitionCollection = ProfileController.GetPropertyDefinitionsByPortal(PortalId)
            Dim PropertyDefinitionId As Integer
            Dim Add As Boolean


            If System.IO.File.Exists(strPropertyDefinitionXmlFile) Then
                oPropertyCollection = DeserializeObject(strPropertyDefinitionXmlFile)
                For Each oProperty As Entities.Profile.ProfilePropertyDefinition In oPropertyCollection
                    oProperty.PortalId = PortalId

                    Add = True

                    For Each oProp As Entities.Profile.ProfilePropertyDefinition In oCollection
                        If (oProp.PropertyName = oProperty.PropertyName AndAlso oProp.PropertyCategory = oProperty.PropertyCategory) Then
                            Add = False

                            Exit For
                        End If
                    Next
                    If Add Then
                        PropertyDefinitionId = ProfileController.AddPropertyDefinition(oProperty)
                        oProperty.ViewOrder = PropertyDefinitionId
                        oProperty.PropertyDefinitionId = PropertyDefinitionId
                        ProfileController.UpdatePropertyDefinition(oProperty)
                    End If
                Next
            Else
                ' This is just so you can create the initial xml file
                ' you will not need this call in your code
                oPropertyCollection = GetProperties()

                Serialize(strPropertyDefinitionXmlFile, oPropertyCollection)
            End If

        End Sub

        Private Function GetProperties() As ProfilePropertyDefinitionCollection
            'Dim strKey As String = ProfileController.PROPERTIES_CACHEKEY & "." & PortalId.ToString

            If m_objProperties Is Nothing Then
                'm_objProperties = CType(DataCache.GetCache(strKey), ProfilePropertyDefinitionCollection)
                If m_objProperties Is Nothing Then
                    m_objProperties = ProfileController.GetPropertyDefinitionsByPortal(PortalId)
                    'DataCache.SetCache(strKey, m_objProperties)
                End If
            End If
            Return m_objProperties
        End Function

        Private Function DeserializeObject(ByVal FileName As String) As Entities.Profile.ProfilePropertyDefinitionCollection
            Try
                Dim oStream As New IO.FileStream(FileName, System.IO.FileMode.Open)
                Dim oSerializer As New System.Xml.Serialization.XmlSerializer(GetType(Entities.Profile.ProfilePropertyDefinitionCollection))
                Dim oClone As Entities.Profile.ProfilePropertyDefinitionCollection = CType(oSerializer.Deserialize(oStream), Entities.Profile.ProfilePropertyDefinitionCollection)
                oStream.Close()
                Return oClone

            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Private Sub Serialize(ByVal FileName As String, ByVal obj As Entities.Profile.ProfilePropertyDefinitionCollection)
            Dim s As New System.Xml.Serialization.XmlSerializer(GetType(Entities.Profile.ProfilePropertyDefinitionCollection))
            ' Writing the XML file to disk requires a TextWriter.
            Dim writer As New System.IO.StreamWriter(FileName)
            ' Serialize the object, and close the StreamWriter.
            s.Serialize(writer, obj)
            writer.Close()
        End Sub

        'Private Sub TransferCartToTIMSSUser(ByVal MasterCustomerId As String, ByVal SubCustomerId As Integer)
        '    Dim oCart As New ShoppingCartManager.Business.ShoppingCartController
        '    If MasterCustomerId <> String.Empty AndAlso SubCustomerId <> -1 AndAlso CheckShoppingCart() Then
        '        oCart.TransferCartToUser(ApplicationManager.Customer.GetAnonymousUserId(""), MasterCustomerId, SubCustomerId)
        '    End If
        'End Sub

        Private Function CheckShoppingCart() As Boolean
            strShoppingCartDataProviderFile = MapPath("..\\..\\bin\\Personify.DNN.Modules.ShoppingCart.SqlDataProvider.dll")
            If (System.IO.File.Exists(strShoppingCartDataProviderFile)) Then
                Return True
            Else
                Return False
            End If
        End Function


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="oUserInfo"></param>
        ''' <param name="oSSOInfo"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[achagoury]	1/29/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub SyncronizeDnnRole(ByVal oUserInfo As UserInfo, ByVal oSSOInfo As TIMSS.API.CustomerInfo.ICustomer)
            Try
                Dim oRoleCtrl As New Security.Roles.RoleController
                Dim oRoleLookup As New Security.Roles.RoleInfo
                Dim oRoleInfo As New Security.Roles.RoleInfo

                ' TODO:  At some point we may want to expose the roles from
                ' TCMS to TIMSS. A rep can now assign a role to a user form 
                ' TIMSS directly - in which case we would change the property
                ' to use below
                oRoleLookup = oRoleCtrl.GetRoleByName(oUserInfo.PortalID, oSSOInfo.Membership)

                ' If the role is a valid one
                ' We'll check if the user is already 
                ' in that role or not
                If Not oRoleLookup Is Nothing Then
                    oRoleInfo = oRoleCtrl.GetUserRole(oUserInfo.PortalID, oUserInfo.UserID, oRoleLookup.RoleID)
                    ' If the user is not in that role
                    ' then we will add it
                    If oRoleInfo Is Nothing Then
                        oRoleCtrl.AddUserRole(oUserInfo.PortalID, oUserInfo.UserID, oRoleLookup.RoleID, Null.NullDate)
                    End If
                End If

                Dim DefaultRoleToAdd As String = CType(Settings("DefaultRoleToAdd"), String)
                'Check module setting to see if need to add user to defaul role
                If Not (DefaultRoleToAdd Is Nothing OrElse DefaultRoleToAdd Is String.Empty) Then
                    oRoleLookup = oRoleCtrl.GetRoleByName(oUserInfo.PortalID, DefaultRoleToAdd)
                    If Not oRoleLookup Is Nothing Then 'valid role
                        oRoleInfo = oRoleCtrl.GetUserRole(oUserInfo.PortalID, oUserInfo.UserID, oRoleLookup.RoleID)
                        If oRoleInfo Is Nothing Then 'user not in role then add
                            oRoleCtrl.AddUserRole(oUserInfo.PortalID, oUserInfo.UserID, oRoleLookup.RoleID, Null.NullDate)
                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

#End Region

#Region "SSO Integration functions"

        Private Function GetRegisterURL() As String
            Dim registerUrl As String = ""

            If (Not Settings("UseCustomerRegistrationActionURL") Is Nothing) AndAlso (CType(Settings("UseCustomerRegistrationActionURL"), String) = "Y") AndAlso (Not Settings("CustomerRegistrationActionURL") Is Nothing) Then
                registerUrl = NavigateURL(CType(Settings("CustomerRegistrationActionURL"), Integer))
            Else
                If PortalSettings.UserRegistration <> PortalRegistrationType.NoRegistration Then

                    If PortalSettings.UserTabId <> -1 Then
                        ' user defined tab
                        registerUrl = NavigateURL(PortalSettings.UserTabId)
                    Else
                        ' admin tab
                        registerUrl = NavigateURL("Register")
                    End If
                End If
            End If

            Return registerUrl

        End Function
        Private Function GetCustomerToken() As String
            If Not Session("customerToken") Is Nothing AndAlso CStr(Session("customerToken")) <> "" Then
                Return CStr(Session("customerToken"))
            ElseIf Not Request("CT") Is Nothing AndAlso Request("CT") <> "" Then

                Dim decrypted As String = SSOLoginManager.DecryptCustomerToken(Request("CT"))
                Return decrypted.Substring(decrypted.IndexOf("|") + 1, decrypted.Length - decrypted.IndexOf("|") - 1)
            End If
            Return Nothing
        End Function

        Private Function IsUserLoggedIn() As Boolean
            Try
                If userinfo Is Nothing Then
                    Return False
                End If
                If Not userinfo.IsSuperUser AndAlso _
                        (userinfo.Profile.GetPropertyValue("MasterCustomerId") <> String.Empty) AndAlso _
                        (userinfo.Profile.GetPropertyValue("SubCustomerId") <> String.Empty) AndAlso _
                        (userinfo.Profile.GetPropertyValue("MasterCustomerId") IsNot Nothing) AndAlso _
                        (userinfo.Profile.GetPropertyValue("SubCustomerId") IsNot Nothing) Then
                    Return True
                Else 'User is not logged in                
                    Return False
                End If
            Catch exc As Exception
                Throw exc
            End Try
            'Return False
        End Function

        Private Sub HandleSSORedirection()

            'SSO start        
            Dim oModules As New Entities.Modules.ModuleController
            Dim strRedirectUrl As String
            Dim strSSORedirectUrl As String = Request.Url.AbsoluteUri()
            Dim strRedirectSSOUrl As String
            Dim strType As String = ""

            Dim EnableSSO As String = System.Configuration.ConfigurationManager.AppSettings("EnableSSO")
            If EnableSSO IsNot Nothing AndAlso EnableSSO.ToUpper = "Y" Then

                'Auto redirect user if is already logged in
                If Not (UserInfo.IsSuperUser OrElse IsAdmin) Then
                    If oModules.GetModuleSettings(ModuleId).ContainsKey("SSOURL") AndAlso oModules.GetModuleSettings(ModuleId).ContainsKey("chkRedirectSSOURL") Then
                        If CType(Settings("chkRedirectSSOURL"), String) = "Y" Then

                            If GetCustomerToken() Is Nothing AndAlso Not IsUserLoggedIn() Then
                                strRedirectUrl = oModules.GetModuleSettings(ModuleId).Item("SSOURL").ToString()
                                strRedirectSSOUrl = SSOLoginManager.ConstructSSOURL(strRedirectUrl, strSSORedirectUrl)
                                Response.Redirect(strRedirectSSOUrl)
                            ElseIf IsUserLoggedIn() Then
                                Response.Redirect(Me.RedirectURL(), True)
                            ElseIf GetCustomerToken() IsNot Nothing Then
                                If String.IsNullOrEmpty(SSOLoginManager.GetVendorCustomerId(GetCustomerToken)) Then
                                    'CustomerToken exist but does not have personify master customer & sub ids
                                    Dim registerURL As New System.Text.StringBuilder
                                    Dim SSOEmailId As String = SSOLoginManager.GetSSOUserEmail(GetCustomerToken())
                                    registerURL.Append(GetRegisterURL())
                                    registerURL.Append("?Email=")
                                    registerURL.Append(SSOEmailId)
                                    registerURL.Append("&returnurl=")
                                    registerURL.Append(Me.RedirectURL)
                                    Response.Redirect(registerURL.ToString(), True)
                                Else
                                    'User has id but unable to login: Other reasons
                                    AddModuleMessage("FailedLoginSSOUser", ModuleMessageType.RedError, True)

                                End If



                            End If
                        End If
                    End If
                    ' 
                End If
            End If

            
        End Sub

#End Region
#Region "Images Functions"
        '3246-5774803       
        Private Function GetRTImageURL() As String

            Return ResolveUrl("~/" & "DefaultPersonifyImages" & "/rt.gif")
        End Function
        'END 3246-5774803
#End Region

    End Class

End Namespace

