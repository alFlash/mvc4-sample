Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.AddUpdateTranscript.Business
Imports System.IO

Namespace Personify.DNN.Modules.AddUpdateTranscript

    Public MustInherit Class AddUpdateTranscriptEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings


#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

		Private Const C_FILEPATTERN As String = "*.?s*"	'*.xsl
		Protected WithEvents select_AddTemplate As System.Web.UI.WebControls.DropDownList
		Protected WithEvents select_UpdateTemplate As System.Web.UI.WebControls.DropDownList

		Protected WithEvents txtDisplayNumber As System.Web.UI.WebControls.TextBox
		Protected WithEvents rvDisplayNumber As System.Web.UI.WebControls.RangeValidator
		Protected WithEvents rfDisplayNumber As System.Web.UI.WebControls.RequiredFieldValidator

		Const C_TEMPLATES As String = "Templates"
		Const C_ADDTEMPLATES As String = "AddTemplates"
		Const C_UPDATETEMPLATES As String = "UpdateTemplates"
		Const C_ALLOWCECREDITENTRY As String = "AllowCECreditEntry"

		Protected WithEvents CheckBoxAllowCECreditEntry As CheckBox

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"

		Private Function GetTemplates() As ListItemCollection
			Try
				Dim lic As New ListItemCollection
				Dim ListItem As ListItem
				' Create a reference to the current directory.
				Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
				' Create an array representing the files in the current directory.
				Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
				Dim fiTemp As FileInfo
				For Each fiTemp In fInfo
					ListItem = New ListItem
					ListItem.Text = fiTemp.Name
					ListItem.Value = fiTemp.Name
					lic.Add(ListItem)
				Next fiTemp
				Return lic

			Catch ex As Exception
				Throw ex
			End Try
		End Function

		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

				Dim _portalSettings As Entities.Portals.PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), Entities.Portals.PortalSettings)

				If Not select_AddTemplate.Items.Count > 0 Then
					Dim li As ListItem
					For Each li In GetTemplates()
						If li.Text = "AddTranscripts.xsl" Then
							li.Selected = True
						End If
						select_AddTemplate.Items.Add(li)
					Next
					select_AddTemplate.SelectedIndex = select_AddTemplate.Items.IndexOf(select_AddTemplate.Items.FindByValue(Convert.ToString(Settings(C_ADDTEMPLATES))))
				End If

				If Not select_UpdateTemplate.Items.Count > 0 Then
					Dim li As ListItem
					For Each li In GetTemplates()
						If li.Text = "UpdateTranscripts.xsl" Then
							li.Selected = True
						End If
						select_UpdateTemplate.Items.Add(li)
					Next
					select_UpdateTemplate.SelectedIndex = select_UpdateTemplate.Items.IndexOf(select_UpdateTemplate.Items.FindByValue(Convert.ToString(Settings(C_UPDATETEMPLATES))))
				End If

				If Not IsPostBack Then

					Dim AllowCECreditEntry As Boolean = False
					If Not Settings(C_ALLOWCECREDITENTRY) Is Nothing Then
						AllowCECreditEntry = CType(Settings(C_ALLOWCECREDITENTRY), Boolean)
					End If
					CheckBoxAllowCECreditEntry.Checked = AllowCECreditEntry

				End If

			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try
				' Only Update if the Entered Data is Valid
				If Page.IsValid = True Then

					
                    UpdateModuleSetting(Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
                    UpdateModuleSetting(C_ADDTEMPLATES, select_AddTemplate.SelectedValue)
                    UpdateModuleSetting(C_UPDATETEMPLATES, select_UpdateTemplate.SelectedValue)
                    UpdateModuleSetting(C_ALLOWCECREDITENTRY, CheckBoxAllowCECreditEntry.Checked.ToString)


                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)
                End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try
				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
