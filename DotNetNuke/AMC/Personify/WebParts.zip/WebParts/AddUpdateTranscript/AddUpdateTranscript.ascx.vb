Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.AddUpdateTranscript.Business
Imports System.Text
Imports System.Globalization
Imports Personify.ApplicationManager

Namespace Personify.DNN.Modules.AddUpdateTranscript

    Public MustInherit Class AddUpdateTranscript
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable
        'Implements Entities.Modules.ISearchable

#Region "Controls"

		Protected MyTranscriptsXslTemplate As Personify.WebControls.XslTemplate
		Protected lblNothing As Label

		Const C_TEMPLATES As String = "Templates"
		Const C_ADDTEMPLATES As String = "AddTemplates"
		Const C_UPDATETEMPLATES As String = "UpdateTemplates"
		Const C_DISPLAY_NUMBER As String = "DisplayNumber"
		Const C_DETAILS_ACTION As String = "DetailsActionURL"
		Const C_VIEWALL_ACTION As String = "ViewAllActionURL"
		Const C_ADDTRANSCRIPT_ACTION As String = "AddTranscript"
		Const C_SHOWADDTRANSCRIPT_ACTION As String = "ShowAddTranscript"
		Const C_SHOWDETAILS_ACTION As String = "ShowDetails"
		Const C_ALLOWCECREDITENTRY As String = "AllowCECreditEntry"

		'Protected WithEvents CancelButton As LinkButton
        'Protected WithEvents SaveButton As LinkButton

        Protected WithEvents RequiredFieldValidator As RequiredFieldValidator

        Dim frmMasterCustomerId As String = ""
        Dim frmSubCustomerId As Integer = 0
        Dim TranscriptID As Integer = 0


#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                Dim IsManagingAffiliate As Boolean = False

                Try
                    IsManagingAffiliate = AffiliateManagementSessionHelper.IsManagingAffiliate(PortalId)
                Catch ex As Exception

                End Try

                If IsManagingAffiliate = True Then

                    Dim affInfo As AffiliateManagementSessionHelper.AffiliateInfo
                    affInfo = AffiliateManagementSessionHelper.GetCurrentAffiliateInfo(PortalId)
                    frmMasterCustomerId = affInfo.AffiliateCustomerId.MasterCustomerId
                    frmSubCustomerId = affInfo.AffiliateCustomerId.SubCustomerId
                   
                Else
                    If Not UserInfo.Profile.GetPropertyValue("MasterCustomerId") Is Nothing AndAlso Not UserInfo.Profile.GetPropertyValue("SubCustomerId") Is Nothing AndAlso UserInfo.Profile.GetPropertyValue("SubCustomerId") <> "" Then
                        frmMasterCustomerId = MasterCustomerId
                        frmSubCustomerId = SubCustomerId
                    End If

                End If

                If IsManagingAffiliate Or role = "personifyuser" Or role = "personifyadmin" Then

                    RegisterJSScripts("js\calendar.js", "Calendar")

                    If Not IsPostBack Then
                        Page.Session("AddUpdateTranscriptReferer") = Request.ServerVariables("HTTP_REFERER")
                    End If

                    If Not Settings(C_ADDTEMPLATES) Is Nothing Or Not Settings(C_UPDATETEMPLATES) Is Nothing Then

                        TranscriptID = Convert.ToInt32(Request("TID"))
                       

                        Dim templatefile As String = ""

                        If TranscriptID > 0 Then

                            templatefile = ModulePath + "Templates\" + Settings(C_UPDATETEMPLATES).ToString

                            MyTranscriptsXslTemplate.XSLfile = Server.MapPath(templatefile)
                            MyTranscriptsXslTemplate.AddObject("ModuleId", ModuleId)

                            Dim Transcript As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscript
                            Transcript = GetTranscriptByID(frmMasterCustomerId, frmSubCustomerId, TranscriptID)


                            If Transcript IsNot Nothing Then

                                'update mode
                                MyTranscriptsXslTemplate.AddObject("", Transcript)
                                MyTranscriptsXslTemplate.Display()

                                Dim SaveButton As LinkButton
                                SaveButton = CType(Me.FindControl("SaveButton" + ModuleId.ToString), LinkButton)
                                If SaveButton IsNot Nothing Then
                                    AddHandler SaveButton.Click, AddressOf SaveButton_Click
                                End If

                            Else
                                lblNothing.Visible = True
                            End If
                        Else  'add mode

                            templatefile = ModulePath + "Templates\" + Settings(C_ADDTEMPLATES).ToString
                            MyTranscriptsXslTemplate.XSLfile = Server.MapPath(templatefile)
                            MyTranscriptsXslTemplate.AddObject("ModuleId", ModuleId)

                            Dim AllowCECreditEntry As Boolean = False
                            If Not Settings(C_ALLOWCECREDITENTRY) Is Nothing Then
                                Try
                                    AllowCECreditEntry = Convert.ToBoolean(Settings(C_ALLOWCECREDITENTRY))
                                Catch ex As Exception

                                End Try
                            End If

                            MyTranscriptsXslTemplate.AddObject("AllowCECreditEntry", AllowCECreditEntry)

                            '3246-5774803
                            Dim CalImageURL As String = GetCalImageURL()
                            MyTranscriptsXslTemplate.AddObject("CalImageURL", CalImageURL)
                            'end 3246-5774803

                            MyTranscriptsXslTemplate.Display()

                            Dim dplActivityType As DropDownList
                            dplActivityType = CType(Me.FindControl("dplActivityType" + ModuleId.ToString), DropDownList)
                            If dplActivityType IsNot Nothing Then
                                With dplActivityType
                                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("TRN", "ACTIVITY_TYPE", True)
                                    'update app_code set available_to_web_flag = 'Y' where subsystem = 'trn' and type='ACTIVITY_TYPE'
                                    .DataSource = appCodes
                                    .DataTextField = "Description"
                                    .DataValueField = "Code"
                                    .DataBind()
                                End With
                            End If

                            Dim dplCECreditType As DropDownList
                            dplCECreditType = CType(Me.FindControl("dplCECreditType" + ModuleId.ToString), DropDownList)
                            If dplCECreditType IsNot Nothing Then
                                With dplCECreditType
                                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("TRN", "CE_CREDIT_TYPE", True)
                                    'update app_code set available_to_web_flag = 'Y' where subsystem = 'trn' and type='CE_CREDIT_TYPE'
                                    .DataSource = appCodes
                                    .DataTextField = "Description"
                                    .DataValueField = "Code"
                                    .DataBind()
                                End With
                            End If

                            Dim dplGradeCode As DropDownList
                            dplGradeCode = CType(Me.FindControl("dplGradeCode" + ModuleId.ToString), DropDownList)
                            If dplGradeCode IsNot Nothing Then
                                With dplGradeCode
                                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = GetApplicationCodes("TRN", "GRADE", True)
                                    'update app_code set available_to_web_flag = 'Y' where subsystem = 'trn' and type='GRADE'
                                    .DataSource = appCodes
                                    .DataTextField = "Description"
                                    .DataValueField = "Code"
                                    .DataBind()
                                End With
                            End If

                            Dim AddButton As LinkButton
                            AddButton = CType(Me.FindControl("AddButton" + ModuleId.ToString), LinkButton)
                            If AddButton IsNot Nothing Then
                                AddHandler AddButton.Click, AddressOf AddButton_Click
                            End If

                            If role = "admin" Then
                                AddButton.Visible = False
                            End If

                            'Dim calCECreditDate As Image
                            'calCECreditDate = CType(Me.FindControl("calCECreditDate" + ModuleId.ToString), Image)
                            'If calCECreditDate IsNot Nothing Then
                            '    Dim txtCECreditDate As TextBox
                            '    txtCECreditDate = CType(Me.FindControl("txtCECreditDate" + ModuleId.ToString), TextBox)
                            '    If txtCECreditDate IsNot Nothing Then
                            '        calCECreditDate.Attributes.Add("onclick", "popupCal('Cal', '" + txtCECreditDate.ClientID.ToString + "', '" + GetFormatString() + "','" + GetMonthNameString() + "','" + GetDayNameString() + "');")
                            '        txtCECreditDate.Text = DateTime.Now.ToString("MM/dd/yyyy")
                            '    End If
                            'End If

                            'Added Telerik Date Picker
                            Dim CEDatePlaceHolder As New PlaceHolder
                            CeDatePlaceHolder = Me.FindControl("CECreditDate")

                            If (CEDatePlaceHolder IsNot Nothing) Then
                                Dim CEDateCalendar As New Telerik.Web.UI.RadDatePicker
                                CEDateCalendar.EnableViewState = True
                                CEDateCalendar.MinDate = "1/1/1900"
                                CEDateCalendar.ID = "CEDateCalendar"
                                RequiredFieldValidator = New RequiredFieldValidator
                                RequiredFieldValidator.Display = ValidatorDisplay.Dynamic
                                RequiredFieldValidator.ErrorMessage = "Please specify a Date"
                                RequiredFieldValidator.ControlToValidate = "CEDateCalendar"
                                CEDatePlaceHolder.Controls.Add(CEDateCalendar)
                                CEDatePlaceHolder.Controls.Add(RequiredFieldValidator)
                            End If
                        End If

                        Dim CancelButton As LinkButton
                        CancelButton = CType(Me.FindControl("CancelButton" + ModuleId.ToString), LinkButton)
                        If CancelButton IsNot Nothing Then
                            AddHandler CancelButton.Click, AddressOf CancelButton_Click
                        End If
                        If role = "admin" Then
                            CancelButton.Visible = False
                        End If
                    Else

                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))

                    End If
                Else
                    DisplayUserAccessMessage(role)
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)
            'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Cancel", Skins.Controls.ModuleMessage.ModuleMessageType.RedError)

            Dim url As String = Convert.ToString(Page.Session("AddUpdateTranscriptReferer"))
            If url IsNot Nothing Then
                Response.Redirect(url, True)
            End If


        End Sub

        Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)

            Dim Transcript As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscript
            Transcript = GetTranscriptByID(frmMasterCustomerId, frmSubCustomerId, TranscriptID)


            Dim CoomentsTextBox As TextBox
            CoomentsTextBox = CType(Me.FindControl("CoomentsTextBox" + ModuleId.ToString), TextBox)
            If CoomentsTextBox IsNot Nothing Then

                Transcript.Comments = CoomentsTextBox.Text
                '   Dim result As Boolean = _
                Transcript = AddUpdateTranscript(frmMasterCustomerId, frmSubCustomerId, Transcript)

                'If result = True Then
                'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Saved", Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                'End If

                Dim url As String = Convert.ToString(Page.Session("AddUpdateTranscriptReferer"))
                If url IsNot Nothing Then
                    Response.Redirect(url, True)
                End If

            End If

        End Sub

        Private Sub AddButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)

            If Page.IsValid = True Then

                'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Add", Skins.Controls.ModuleMessage.ModuleMessageType.RedError)


                Dim Transcripts As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscripts
                Transcripts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.TranscriptInfo, "TranscriptCustomerTranscripts")


                Dim CECreditType As String = ""
                Dim dplCECreditType As DropDownList
                dplCECreditType = CType(Me.FindControl("dplCECreditType" + ModuleId.ToString), DropDownList)
                If dplCECreditType IsNot Nothing Then
                    CECreditType = dplCECreditType.SelectedValue
                End If

                Dim GradeCode As String = ""
                Dim dplGradeCode As DropDownList
                dplGradeCode = CType(Me.FindControl("dplGradeCode" + ModuleId.ToString), DropDownList)
                If dplGradeCode IsNot Nothing Then
                    GradeCode = dplGradeCode.SelectedValue
                End If

                Dim CECredits As Integer = 0
                Dim txtCECredits As TextBox
                txtCECredits = CType(Me.FindControl("txtCECredits" + ModuleId.ToString), TextBox)
                If txtCECredits IsNot Nothing Then
                    Try
                        CECredits = Convert.ToInt32(txtCECredits.Text)
                    Catch ex As Exception

                    End Try

                End If

                'Dim CECreditDate As Date = DateTime.Now
                'Dim txtCECreditDate As TextBox
                'txtCECreditDate = CType(Me.FindControl("txtCECreditDate" + ModuleId.ToString), TextBox)
                'If txtCECreditDate IsNot Nothing Then
                '    Try
                '        CECreditDate = Convert.ToDateTime(txtCECreditDate.Text)
                '    Catch ex As Exception

                '    End Try
                'End If

                'Added Telerik Date Picker
                Dim CECreditDate As Date = DateTime.Now
                Dim CEDateCalendar As New Telerik.Web.UI.RadDatePicker
                CEDateCalendar = CType(Me.FindControl("CEDateCalendar"), Telerik.Web.UI.RadDatePicker)
                If CEDateCalendar IsNot Nothing Then
                    Try
                       CECreditDate = CEDateCalendar.SelectedDate.ToString
                    Catch ex As Exception

                    End Try
                End If

                Dim strProgramTitle As String = String.Empty
                Dim txtProgramTitleTextBox As TextBox
                txtProgramTitleTextBox = CType(Me.FindControl("ProgramTitleTextBox" + ModuleId.ToString), TextBox)
                If txtProgramTitleTextBox IsNot Nothing AndAlso txtProgramTitleTextBox.Text.Length > 0 Then
                    strProgramTitle = txtProgramTitleTextBox.Text
                Else
                    strProgramTitle = "new program title"
                End If

                Dim strActivityType As String = String.Empty
                Dim dplActivityType As DropDownList
                dplActivityType = CType(Me.FindControl("dplActivityType" + ModuleId.ToString), DropDownList)
                If dplActivityType IsNot Nothing AndAlso dplActivityType.SelectedValue IsNot Nothing Then
                    strActivityType = dplActivityType.SelectedValue
                End If

                Dim Comments As String = ""
                Dim CommentsTextBox As TextBox
                CommentsTextBox = CType(Me.FindControl("CommentsTextBox" + ModuleId.ToString), TextBox)
                If CommentsTextBox IsNot Nothing Then
                    Comments = CommentsTextBox.Text
                End If


                With Transcripts.AddNew
                    .MasterCustomerId = frmMasterCustomerId
                    .SubCustomerId = frmSubCustomerId
                    .ProgramTitle = strProgramTitle
                    If strActivityType.Length > 0 Then
                        .ReadOnly("ActivityTypeCode") = False
                        .ActivityTypeCode = .ActivityTypeCode.List(strActivityType).ToCodeObject
                    End If
            .CECreditTypeCode = .CECreditTypeCode.List(CECreditType).ToCodeObject
            .GradeCode = .GradeCode.List(GradeCode).ToCodeObject
            '.GradeCode = GradeCode
            .CECredits = CECredits
            .CECreditDate = CECreditDate
            .Comments = Comments
            '.CertificateDate = CECreditDate
            .StartDate = CECreditDate
            '.CertificationCode = .CertificationCode.List("CERT").ToCodeObject
            .AdHocActivityDescription = "web"
                End With

                Dim trn As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscript

                trn = AddUpdateTranscript(frmMasterCustomerId, frmSubCustomerId, Transcripts(0))


                If trn IsNot Nothing AndAlso trn.ValidationIssues.Count = 0 Then

                    Dim url As String = Convert.ToString(Page.Session("AddUpdateTranscriptReferer"))
                    If url IsNot Nothing Then
                        Response.Redirect(url, True)
                    End If
                Else
                    Dim mess As String = Localization.GetString("Error.Text", LocalResourceFile)
                    If trn IsNot Nothing AndAlso trn.ValidationIssues.Count > 0 Then
                        mess = trn.ValidationIssues(0).Message
                    End If
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, mess, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

            End If

        End Sub

		Function GetMonthNameString() As String

			Dim TrimChars As Char() = {","c, " "c}

			' Get culture array of month names and convert to string for
			' passing to the popup calendar
			Dim MonthNameString As String = ""
			Dim Month As String
			For Each Month In DateTimeFormatInfo.CurrentInfo.MonthNames
				MonthNameString += Month & ","
			Next
			MonthNameString = MonthNameString.TrimEnd(TrimChars)

			Return MonthNameString

		End Function

		Function GetFormatString() As String
			Return DateTimeFormatInfo.CurrentInfo.ShortDatePattern.ToString
		End Function

		Function GetDayNameString() As String

			Dim TrimChars As Char() = {","c, " "c}


			' Get culture array of day names and convert to string for
			' passing to the popup calendar
			Dim DayNameString As String = ""
			Dim Day As String
			For Each Day In DateTimeFormatInfo.CurrentInfo.DayNames
				DayNameString += Day.Substring(0, 3) & ","
			Next
			DayNameString = DayNameString.TrimEnd(TrimChars)

			Return DayNameString

		End Function

		Private Sub RegisterJSScripts(ByVal path As String, ByVal sname As String)
			Dim ScriptPath As String = ResolveUrl(path)
			If (Not Me.Page.ClientScript.IsClientScriptBlockRegistered(sname)) Then
				Dim script As StringBuilder = New StringBuilder
				script.AppendFormat("<script type='text/javascript' src='{0}'></script>", ScriptPath)
				Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType, sname, script.ToString())
				script = Nothing
			End If
		End Sub

#Region "Images Functions"
        '3246-5774803
        Private Function GetCalImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/cal.gif")
        End Function
        'END 3246-5774803
#End Region

#Region "Personify Data"

        Private Function GetTranscriptByID(ByVal MCID As String, ByVal SCID As Integer, ByVal TranscriptCustomerTranscriptId As Integer) As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscript

            Dim oTranscripts As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscripts

            oTranscripts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.TranscriptInfo, "TranscriptCustomerTranscripts")

            oTranscripts.Filter.Add("MasterCustomerID", MCID)
            oTranscripts.Filter.Add("SubCustomerID", SCID)
            oTranscripts.Filter.Add("TranscriptCustomerTranscriptId", TranscriptCustomerTranscriptId)
            oTranscripts.Fill()

            If oTranscripts IsNot Nothing AndAlso oTranscripts.Count > 0 Then
                Return oTranscripts(0)
            End If

            Return Nothing
        End Function

        Private Function AddUpdateTranscript(ByVal MCID As String, ByVal SCID As Integer, ByVal TranscriptCustomerTranscript As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscript) As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscript

            Dim oTranscripts As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscripts



            oTranscripts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.TranscriptInfo, "TranscriptCustomerTranscripts")

            oTranscripts.Add(TranscriptCustomerTranscript)

            oTranscripts.Save()

            Return oTranscripts(0)

        End Function
#End Region
	End Class

End Namespace
