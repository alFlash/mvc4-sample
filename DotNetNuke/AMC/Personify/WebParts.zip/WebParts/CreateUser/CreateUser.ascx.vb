Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.CreateUser.Business
Imports TIMSS.Server.BusinessMessages.EmailAndFax
Imports System.Threading
Imports System.Web.Mail
Imports System.Xml
Imports System.Xml.XPath
Imports System.Xml.Xsl
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data

Namespace Personify.DNN.Modules.CreateUser

    Public MustInherit Class CreateUser
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable


#Region "Controls"
        Protected WithEvents pnlMain As System.Web.UI.WebControls.Panel
        Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtConfirmPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents ddlHintQuestion As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtHintAnswer As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnCreateAccount As System.Web.UI.WebControls.Button
#End Region
#Region "Properties"
        Public Property PasswordRegularExpression() As String
            Get
                Return CStr(ViewState("PasswordRegularExpression"))
            End Get
            Set(ByVal Value As String)
                ViewState("PasswordRegularExpression") = Value
            End Set
        End Property
        Public Property AdminEmailAddress() As String
            Get
                Return CStr(ViewState("AdminEmailAddress"))
            End Get
            Set(ByVal Value As String)
                ViewState("AdminEmailAddress") = Value
            End Set
        End Property

        Public Property MCId() As String
            Get
                Return CStr(ViewState("MCId"))
            End Get
            Set(ByVal Value As String)
                ViewState("MCId") = Value
            End Set
        End Property

        Public Property SCId() As String
            Get
                Return CStr(ViewState("SCId"))
            End Get
            Set(ByVal Value As String)
                ViewState("SCId") = Value
            End Set
        End Property
#End Region
#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    If GetPersonifySiteSettings(PortalId) Then
                        If ValidateApplicationId() Then
                            pnlMain.Visible = True
                            LoadHintQuestion()
                        Else
                            pnlMain.Visible = False                            
                        End If
                    Else
                        pnlMain.Visible = False
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Sub btnCreateAccount_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCreateAccount.Click
            Try
                If FormValidation() Then
                    If CreateUser() Then
                        SendEmail()
                        AutoLogin()
                    End If
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "Helper Functions"

        Private Function LoadHintQuestion() As Boolean
            Try
                ddlHintQuestion.DataTextField = "Description"
                ddlHintQuestion.DataValueField = "Code"

                ddlHintQuestion.DataSource = GetApplicationCodes("CUS", "HINT_QUESTION", False)
                ddlHintQuestion.DataBind()

                Dim oLI As New System.Web.UI.WebControls.ListItem
                oLI.Text = Localization.GetString("HintQuestionInitLine", LocalResourceFile)
                oLI.Value = "-1"
                oLI.Selected = True
                ddlHintQuestion.Items.Insert(0, oLI)
                Return True
            Catch ex As Exception
                Return False
            End Try
        End Function

        Private Function GetPersonifySiteSettings(ByVal CurrPortalID As Integer) As Boolean
            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(ConnectionString, "dbo." & "" & "GetPersonifySiteSettings", CurrPortalID), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    If (Not oSiteData.Item("AdminEmailAddress") Is Nothing) AndAlso (Not oSiteData.Item("AdminEmailAddress").ToString = "") Then
                        AdminEmailAddress = CType(oSiteData.Item("AdminEmailAddress"), String)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                    If (Not oSiteData.Item("PasswordRegularExpression") Is Nothing) AndAlso (Not oSiteData.Item("PasswordRegularExpression").ToString = "") Then
                        PasswordRegularExpression = CType(oSiteData.Item("PasswordRegularExpression"), String)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("FixSiteSettingsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                End While
            Else
                Return False
            End If
            oSiteData.Close()
            oSiteData = Nothing

            Return True
        End Function
        Private Function ValidateApplicationId() As Boolean
            If Request.QueryString("reload") = "yes" Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SuccessMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                Return False
            End If
            If Request.QueryString("a") = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("UnauthorizedAccessMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            Dim oPasswordAssistanceData As System.Data.SqlClient.SqlDataReader
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            Dim ApplicationId As Guid = New Guid(Request.QueryString("a"))
            oPasswordAssistanceData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(ConnectionString, "dbo." & "" & "GetPersonifyActivateAccount", PortalId, ApplicationId), System.Data.SqlClient.SqlDataReader)
            If oPasswordAssistanceData.HasRows Then
                oPasswordAssistanceData.Read()
                Dim CustomerId As String = oPasswordAssistanceData.Item("CustomerId").ToString
                ParseCustomerId(CustomerId, MCId, SCId)

                Dim expirationDate As Date = CType(oPasswordAssistanceData.Item("ExpirationDate").ToString, Date)
                If expirationDate.Date < Date.Today Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RecordExpiredMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If
                Dim activeFlag As Boolean = CType(oPasswordAssistanceData.Item("ActiveFlag").ToString, Boolean)
                If Not activeFlag Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("RecordNotActiveMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("UnauthorizedAccessMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            oPasswordAssistanceData.Close()
            oPasswordAssistanceData = Nothing
            Return True
        End Function



        Private Function FormValidation() As Boolean
            'current password cannot be empty
            If txtUserName.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserNameEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            'password cannot be empty
            If txtPassword.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("PasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            'confirm password cannot be empty
            If txtConfirmPassword.Text = String.Empty Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ConfirmPasswordEmptyMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'password should be equal to confirm password
            If Not txtConfirmPassword.Text = txtPassword.Text Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("ConfirmNotEqualPasswordMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            'check password format
            Dim oRegex As New System.Text.RegularExpressions.Regex(PasswordRegularExpression)
            If Not oRegex.IsMatch(txtPassword.Text) Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidPasswordFormat", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If


            'UserName must not exists in WEB_USER table
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers
            oWebList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")
            oWebList.Filter.Add("UserId", "txtUserName.Text")
            oWebList.Fill()
          
            If oWebList.Count > 0 Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("UserNameExistsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            If ddlHintQuestion IsNot Nothing AndAlso ddlHintQuestion.SelectedValue = "-1" Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("HintQuestionError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If
            If txtHintAnswer IsNot Nothing AndAlso String.Compare(txtHintAnswer.Text, String.Empty) = 0 Then
                Skins.Skin.AddModuleMessage(Me, Localization.GetString("HintAnswerError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Return False
            End If

            Return True
        End Function

        Private Sub SendEmail()
            Try
                If Page.IsValid Then
                    pnlMain.Visible = False

                    Dim oEmail As New TIMSS.EmailManager

                    oEmail.To = GetEmailAddressTo()

                    Dim Subject As String = Services.Localization.Localization.GetString("AccountActivatedEmailSubject", Me.LocalResourceFile)
                    oEmail.Subject = Subject

                    'from admin email address
                    Dim FromEmailAddress As String = AdminEmailAddress
                    oEmail.FromEmail = AdminEmailAddress
                    oEmail.FromName = Services.Localization.Localization.GetString("EmailFromName", Me.LocalResourceFile)

                    Dim emailTemplateFile As String = Server.MapPath(ModulePath + "Templates\EmailTemplate.xsl")

                    Dim xml As System.Xml.XmlReader = New System.Xml.XmlTextReader(New System.IO.StringReader(String.Concat("<?xml version='1.0'?><User><UserName>", txtUserName.Text, "</UserName></User>")))
                    Dim document As XmlDocument = New XmlDocument()
                    document.Load(xml)
                    Dim transformer As XslCompiledTransform = New XslCompiledTransform()
                    transformer.Load(emailTemplateFile)
                    Dim output As StringWriter = New StringWriter()
                    transformer.Transform(document, Nothing, output)
                    oEmail.Body = output.ToString
                    output.Close()

                    oEmail.Send()
                End If
            Catch exc As System.Net.Mail.SmtpFailedRecipientException
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("InvalidEmailAddress", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                pnlMain.Visible = True
            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub
        'get the email address for the customerid
        Private Function GetEmailAddressTo() As String
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = GetCustomer(MCId, SCId)
            Return oCustomers(0).PrimaryEmailAddress
        End Function

        Private Function CreateUser() As Boolean
            Return CreateWebUserAccount(MCId, CType(SCId, Integer), txtUserName.Text, txtPassword.Text, ddlHintQuestion.SelectedValue, txtHintAnswer.Text)
        End Function

        Private Sub AutoLogin()
            'ActiveFlag updated to 0
            Dim sqlParamArr(2) As SqlParameter
            Dim ConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
            sqlParamArr(0).Value = PortalId.ToString
            sqlParamArr(1) = New SqlParameter("@ApplicationId", SqlDbType.NVarChar, 100)
            sqlParamArr(1).Value = Request.QueryString("a")
            sqlParamArr(2) = New SqlParameter("@ActiveFlag", SqlDbType.Bit)
            sqlParamArr(2).Value = 0
            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(ConnectionString, "dbo." & "" & "UpdatePersonifyActivateAccount", sqlParamArr(0), sqlParamArr(1), sqlParamArr(2))

            
            'Auto Login
            Dim loginStatus As Personify.LoginStatus
            Dim oLoginManager As New Personify.LoginManager(txtUserName.Text, txtPassword.Text)
            Dim objUser As UserInfo = Nothing

            loginStatus = oLoginManager.Login()
            If loginStatus.loginStatus = DotNetNuke.Security.Membership.UserLoginStatus.LOGIN_SUCCESS Then
                Response.Redirect(NavigateURL(TabId, "", "&reload=yes"))
            End If

        End Sub

        Private Sub ParseCustomerId(ByVal customerId As String, ByRef MCId As String, ByRef SCId As String)

            Dim aryCustomerId() As String = customerId.Split(TIMSS.Constants.Application.C_KEY_DELIMITER)

            If (aryCustomerId.Length > 1) Then
                MCId = aryCustomerId(aryCustomerId.GetUpperBound(0) - 1)
                SCId = aryCustomerId(aryCustomerId.GetUpperBound(0))
            End If


        End Sub

        Private Function GetCustomer(ByVal MCID As String, ByVal SCID As String) As TIMSS.API.CustomerInfo.ICustomers

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", MCID)
                .Filter.Add("SubCustomerId", SCID)
                .Fill()
            End With

            Return oCustomers

        End Function

        Private Function CreateWebUserAccount(ByVal MCID As String, _
                                                        ByVal SCID As Integer, _
                                                        ByVal UserId As String, _
                                                        ByVal Password As String, _
                                                        ByVal HintQuestion As String, _
                                                        ByVal HintAnswer As String) As Boolean

            '**Check if the user exists
            Dim oWebUser As TIMSS.API.WebInfo.IWebUser
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers
            Dim oCustList As TIMSS.API.CustomerInfo.ICustomers
            Dim isWebUserAccountCreated As Boolean = False

            oCustList = GetCustomer(MCID, SCID)
            'CreateWebUserAccount = False

            If Not DoesWebUserIDExists(UserId) Then
                oWebList = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

                oWebList.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, MCID)
                oWebList.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CStr(SCID))
                oWebList.Fill()
                If oWebList.Count > 0 Then

                    ' save schema
                    Dim bOrigUserIdReadOnlyUpdate As Boolean
                    bOrigUserIdReadOnlyUpdate = oWebList.Schema.Item("UserId").IsReadOnly.OnUpdate
                    oWebList.Schema.Item("UserId").IsReadOnly.OnUpdate = False

                    oWebList(0).UserId = UserId
                    oWebList(0).Password = Password
                    oWebList(0).DisableLoginFlag = False
                    oWebList(0).IsPasswordChangeRequired = False
                    If HintQuestion.Trim <> "" Then
                        oWebList(0).HintQuestionCode = oWebList(0).HintQuestionCode.List(HintQuestion).ToCodeObject
                        oWebList(0).HintAnswer = HintAnswer
                    End If

                    oWebList.Save()
                    'CreateWebUserAccount = True
                    isWebUserAccountCreated = True

                    ' reset schema to original value
                    oWebList.Schema.Item("UserId").IsReadOnly.OnUpdate = bOrigUserIdReadOnlyUpdate
                Else
                    oWebUser = oWebList.AddNew()
                    With oWebUser
                        .MasterCustomerId = MCID
                        .SubCustomerId = SCID
                        .UserId = UserId
                        .Password = Password
                        If HintQuestion.Trim <> "" Then
                            .HintQuestionCode = .HintQuestionCode.List(HintQuestion).ToCodeObject
                            .HintAnswer = HintAnswer
                        End If
                        .DisableLoginFlag = False
                        .IsPasswordChangeRequired = False
                    End With
                    oWebList.Save()
                    'CreateWebUserAccount = True
                    isWebUserAccountCreated = True
                End If
            Else
                'UserId already exists
            End If

            Return isWebUserAccountCreated
        End Function
        Private Function DoesWebUserIDExists(ByVal UserId As String) As Boolean
            'Check if the user exists
            Dim oWebList As TIMSS.API.WebInfo.IWebUsers


            oWebList =Me.PErsonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.WebInfo, "WebUsers")

            oWebList.Filter.Add("UserId", TIMSS.Enumerations.QueryOperatorEnum.Equals, UserId)
            oWebList.Fill()
            If oWebList.Count > 0 Then
                Return True
            End If

            Return False

        End Function

#End Region
    End Class

End Namespace
