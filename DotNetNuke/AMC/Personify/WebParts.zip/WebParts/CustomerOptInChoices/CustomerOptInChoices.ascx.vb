Imports System
Imports System.Web.UI.WebControls
Imports Personify
Imports Personify.ApplicationManager.PersonifyDataObjects


Namespace Personify.DNN.Modules.CustomerOptInChoices

    Public MustInherit Class CustomerOptInChoices
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable
        'Private strMCID As String
        'Private strSCID As String
        Protected WithEvents xslOptInChoices As WebControls.XslTemplate
        Protected WithEvents btnSave As New System.Web.UI.WebControls.Button
        Protected WithEvents btnCancel As New System.Web.UI.WebControls.Button

        Protected WithEvents imgOptedIn As Image
        Protected WithEvents imgOptedOut As Image
        Protected WithEvents imgUnDecided As Image

#Region "Controls"
        Protected WithEvents lblError As Label

#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                If Settings("CustomerOptInChoicesTemplate") IsNot Nothing Then
                    Dim role As String
                    role = Me.GetUserRole(UserInfo)

                    If (Me.IsPersonifyWebUserLoggedIn = True Or role = "personifyuser" Or role = "personifyadmin") Then
                        If Not IsPostBack Then
                            LoadPersonifyTemplate()
                        End If
                    Else
                        btnSave.Visible = False
                        btnCancel.Visible = False
                        Skins.Skin.AddModuleMessage(Me, Localization.GetString("NeedLogin", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                Else
                    Skins.Skin.AddModuleMessage(Me, Localization.GetString("NeedSettings", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)

            End Try

        End Sub
       
        Private Sub LoadPersonifyTemplate()

            If Not Settings("CustomerOptInChoicesTemplate") Is Nothing Then
                xslOptInChoices.XSLfile = Server.MapPath(ModulePath + "/Templates/" & CStr(Settings("CustomerOptInChoicesTemplate")))
            Else
                xslOptInChoices.XSLfile = Server.MapPath(ModulePath + "/Templates/CustomerOptInChoicesTemplate.xsl")
            End If

            Dim oInterests As TIMSS.API.ApplicationInfo.IApplicationCodes
            oInterests = df_GetWebEnabledApplicationCodes("CUS", "OPT_IN_INTEREST_AREA")

            'oInterests.Sort("Code", ComponentModel.ListSortDirection.Ascending)

            Dim oCusOptInOptOuts(oInterests.Count - 1) As OptInOptOutOptions
            oCusOptInOptOuts = df_GetCustomerOptInOptOutChoices(MasterCustomerId, SubCustomerId)
            Dim oCusOptInCount, oCusOptOutCount, x As Integer
            oCusOptInCount = 0
            oCusOptOutCount = 0
            For x = 0 To oCusOptInOptOuts.Length - 1
                If Not oCusOptInOptOuts(x) Is Nothing Then
                    If oCusOptInOptOuts(x).OptInFlag Then
                        oCusOptInCount = oCusOptInCount + 1
                    Else
                        If oCusOptInOptOuts(x).Key <> "0" Then
                            oCusOptOutCount = oCusOptOutCount + 1
                        End If
                    End If
                End If
            Next
            xslOptInChoices.AddObject("CustomerOptInOptOuts", oCusOptInOptOuts)
            xslOptInChoices.AddObject("OptInCount", oCusOptInCount)
            xslOptInChoices.AddObject("OptOutCount", oCusOptOutCount)
            Dim OptedInURL As String = GetOptedInURL()
            xslOptInChoices.AddObject("OptedInURL", OptedInURL)
            Dim OptedOutURL As String = GetOptedOutURL()
            xslOptInChoices.AddObject("OptedOutURL", OptedOutURL)
            Dim UnDecidedURL As String = GetUnDecidedURL()
            xslOptInChoices.AddObject("UnDecidedURL", UnDecidedURL)
            btnSave.Visible = True
            btnCancel.Visible = True
            xslOptInChoices.Display()
        End Sub


        Private Sub SaveChoices(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click

            Dim strOptInID As String
            Dim oInterests As TIMSS.API.ApplicationInfo.IApplicationCodes
            oInterests = df_GetWebEnabledApplicationCodes("CUS", "OPT_IN_INTEREST_AREA")
            'oInterests.Sort("Code", ComponentModel.ListSortDirection.Ascending)

            Dim aOptInOptOuts As CustomerOptInOptOutOptions
            aOptInOptOuts = New CustomerOptInOptOutOptions

            Dim OptInOption As OptInOptOutOptions

            aOptInOptOuts.MasterCustomerId = MasterCustomerId
            aOptInOptOuts.SubCustomerId = SubCustomerId

            Dim i As Integer
            i = 0

            'Get the Present Opt-in/Opt-outs for the Customer
            Dim oCusOptInOptOuts(oInterests.Count - 1) As OptInOptOutOptions
            oCusOptInOptOuts = df_GetCustomerOptInOptOutChoices(MasterCustomerId, SubCustomerId)

            For Each oInterest As TIMSS.API.ApplicationInfo.IApplicationCode In oInterests
                strOptInID = FindOptInControl("Out_" + i.ToString)
                If strOptInID <> "" Then
                    OptInOption = New OptInOptOutOptions
                    OptInOption.Code = oCusOptInOptOuts(i).Code
                    OptInOption.Description = oCusOptInOptOuts(i).Description
                    OptInOption.OptInFlag = False
                    OptInOption.Key = strOptInID
                    aOptInOptOuts.MyOptInsOptOuts.Add(OptInOption)
                End If
                strOptInID = FindOptInControl("In_" + i.ToString)
                If strOptInID.ToString <> "" Then
                    OptInOption = New OptInOptOutOptions
                    OptInOption.Code = oCusOptInOptOuts(i).Code
                    OptInOption.Description = oCusOptInOptOuts(i).Description
                    OptInOption.OptInFlag = True
                    OptInOption.Key = strOptInID
                    aOptInOptOuts.MyOptInsOptOuts.Add(OptInOption)
                End If
                strOptInID = FindOptInControl("Available_" + i.ToString)
                If strOptInID.ToString <> "" Then
                    OptInOption = New OptInOptOutOptions
                    OptInOption.Code = oCusOptInOptOuts(i).Code
                    OptInOption.Description = oCusOptInOptOuts(i).Description
                    aOptInOptOuts.MyAvailableOptions.Add(OptInOption)
                End If
                i = i + 1
            Next

            If df_SaveOptInInterests(aOptInOptOuts) Then
                LoadPersonifyTemplate()
            End If

        End Sub

        Private ReadOnly Property FindOptInControl(ByVal ControlId As String) As String
            Get
                Dim strReturn As String = ""

                For i As Integer = 0 To Page.Request.Form.Keys.Count - 1
                    If Page.Request.Form.Keys(i).Contains(ControlId) Then
                        strReturn = Page.Request.Form(Page.Request.Form.Keys(i))
                        Exit For
                    End If
                Next

                Return strReturn
            End Get
        End Property

        Private Sub Cancel(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            LoadPersonifyTemplate()
        End Sub

        Private Sub LoadImages()

            imgOptedIn.ImageUrl = "~/" & SiteImagesFolder & "/OptedIn.gif"
            imgOptedOut.ImageUrl = "~/" & SiteImagesFolder & "/OptedOut.gif"
            imgUnDecided.ImageUrl = "~/" & SiteImagesFolder & "/UnDecided.gif"
        End Sub

        Private Function GetOptedInURL() As String

            Return "~/" & SiteImagesFolder & "/OptedIn.gif"
        End Function
        Private Function GetOptedOutURL() As String

            Return "~/" & SiteImagesFolder & "/OptedOut.gif"
        End Function

        Private Function GetUnDecidedURL() As String

            Return "~/" & SiteImagesFolder & "/UnDecided.gif"
        End Function


#End Region

#Region "Optional Interfaces"
       
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


#Region "Personify Data"

        Private Function df_GetCustomerOptInOptOutChoices(ByVal MasterCustomerId As String, ByVal SubCustomerId As String) As OptInOptOutOptions()


            Dim oCustomerOptIns As TIMSS.API.CustomerInfo.ICustomerOptIns
            oCustomerOptIns = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerOptIns")


            With oCustomerOptIns
                .Filter.Add("MasterCustomerID", MasterCustomerId)
                .Filter.Add("SubCustomerID", SubCustomerId)
                '.Filter.Add("OptedInFlag", "Y")
                .Fill()
            End With



            Dim oInterests As TIMSS.API.ApplicationInfo.IApplicationCodes
            oInterests = df_GetWebEnabledApplicationCodes("CUS", "OPT_IN_INTEREST_AREA")
            Dim blnMyInterest, blnOptedIn As Boolean

            Dim x As Integer
            x = 0

            Dim myOptions(oInterests.Count) As OptInOptOutOptions
            For Each oInterest As TIMSS.API.ApplicationInfo.IApplicationCode In oInterests
                blnOptedIn = False
                blnMyInterest = False

                For Each myInterestCode As TIMSS.API.CustomerInfo.ICustomerOptIn In oCustomerOptIns
                    If myInterestCode.OptionShortName = oInterest.Code AndAlso myInterestCode.OptionTypeCode.Code = "INTEREST_AREA" Then
                        blnMyInterest = True
                        blnOptedIn = myInterestCode.OptedInFlag
                        Exit For
                    End If
                Next

                If Not blnMyInterest Then
                    With oInterest
                        'Not Opted In or Opted Out (Available Options)
                        myOptions(x) = New OptInOptOutOptions
                        myOptions(x).Code = .Code
                        myOptions(x).Description = .Description
                        'Set the Key to 0 if NEVER Opted in or Opted Out
                        myOptions(x).Key = "0"
                    End With
                Else
                    With oInterest
                        'Opted In or Opted Out
                        myOptions(x) = New OptInOptOutOptions
                        myOptions(x).Code = .Code
                        myOptions(x).Description = .Description
                        'Set the Key to 1 if Opted In/ Opted Out
                        myOptions(x).Key = "1"
                        myOptions(x).OptInFlag = blnOptedIn
                    End With
                End If
                x = x + 1
            Next

            Return myOptions

        End Function

        Private Function df_SaveOptInInterests(ByVal OptOptions As CustomerOptInOptOutOptions) As Boolean



            Dim oCustomerOptIns As TIMSS.API.CustomerInfo.ICustomerOptIns
            'Dim oCustomerOptIn As TIMSS.API.CustomerInfo.ICustomerOptIn

            oCustomerOptIns = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerOptIns")

            With oCustomerOptIns
                .Filter.Add("MasterCustomerID", OptOptions.MasterCustomerId)
                .Filter.Add("SubCustomerID", OptOptions.SubCustomerId)
                .Fill()
            End With

            For Each oCusOptIn As TIMSS.API.CustomerInfo.ICustomerOptIn In oCustomerOptIns
                'TODO - do not set if unchanged
                If oCusOptIn.OptedInFlag <> df_GetMeOptValues(OptOptions, oCusOptIn.OptionShortName, oCusOptIn.OptedInFlag) Then
                    oCusOptIn.OptedInFlag = Not oCusOptIn.OptedInFlag
                End If
            Next

            For i As Integer = 0 To OptOptions.MyAvailableOptions.Count - 1
                With oCustomerOptIns.AddNew()
                    .MasterCustomerId = OptOptions.MasterCustomerId
                    .SubCustomerId = OptOptions.SubCustomerId
                    .OptionTypeCode.Code = "INTEREST_AREA"
                    .OptionShortName = OptOptions.MyAvailableOptions(i).Code
                    .OptionDescription = OptOptions.MyAvailableOptions(i).Description
                    .OptedInFlag = True
                End With
            Next

            Return oCustomerOptIns.Save()

        End Function

        Private Function df_GetMeOptValues(ByVal OptOptions As CustomerOptInOptOutOptions, ByVal strValueToGet As String, _
                                                ByVal blnOriginal As Boolean) As Boolean
            For Each oOption As OptInOptOutOptions In OptOptions.MyOptInsOptOuts
                If oOption.Code = strValueToGet Then
                    Return oOption.OptInFlag
                End If
            Next
            Return blnOriginal
        End Function

        Private Function df_GetWebEnabledApplicationCodes(ByVal Subsystem As String, ByVal Type As String) As TIMSS.API.ApplicationInfo.IApplicationCodes

            Return GetApplicationCodes(Subsystem, Type, True)

        End Function


#End Region
    End Class

End Namespace
