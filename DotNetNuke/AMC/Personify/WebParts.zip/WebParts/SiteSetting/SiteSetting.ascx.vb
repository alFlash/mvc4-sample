Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.SiteSetting.Business
Imports System.Xml
Imports System.Data.SqlClient
Imports System.data
Imports Personify
Imports TIMSS.Security.Network
Imports DotNetNuke
Imports Personify.ApplicationManager
Imports DotNetNuke.Entities.Modules
Imports System.Collections.Generic
Imports Telerik.Web.UI
Imports TIMSS.SqlObjects

Namespace Personify.DNN.Modules.SiteSetting

    Public MustInherit Class SiteSetting
        'Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        Inherits PortalModuleBase
        Implements DotNetNuke.Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable
#Region " Private Members "
        Private xConfigDoc As New XmlDocument
        Private xRoot As XmlElement
        Private ConnectionNode As XmlNode
        Private Const CONFIGFILE As String = "..\..\Config\Config.xml"
        Private connectionString As String
        Private oDBInfo As DataSet

        Private ServerName As String
        Private Database As String
        Private Username As String
        Private Password As String

        Private SeatInformation As New SeatInformation
        Private Pswd As String
        Private objSiteSettings As New ApplicationManager.PersonifyDataObjects.SiteSettings(0)
        Private ProductImageURL As String
        Private ImageURL As String

        Private CollAction As Action
        Private CurrentPortalId As Integer
        Private AppTypes As New ArrayList
#End Region

#Region "Controls"

        Protected WithEvents pnlSiteSettingGrid As New Panel
        Protected WithEvents dgSite As New DataGrid

        Protected WithEvents pnlPortalSettingGrid As New Panel
        Protected WithEvents dgPortal As New DataGrid

        Protected WithEvents pnlRemotingDatabaseConnection As New Panel
        Protected WithEvents txtRemotingAssocName As New TextBox
        Protected WithEvents txtRemotingEnvName As New TextBox
        Protected WithEvents txtRemotingAppTypeName As New TextBox
        Protected WithEvents txtRemotingVersionName As New TextBox
        Protected WithEvents txtRemotingDbName As New TextBox
        Protected WithEvents txtRemotingLogin As New TextBox
        Protected WithEvents txtRemotingPswd As New TextBox
        Protected WithEvents btnUpdateSiteSettings As New Button
        Protected WithEvents btnRestoreSiteSettings As New Button
        Protected WithEvents btnTestConnection As New Button
        Protected WithEvents lblConnectionStatus As New Label

        Protected WithEvents pnlPortalSetting As New Panel
        Protected WithEvents lblPortalIDValue As New Label
        Protected WithEvents lblPortalNameValue As New Label
        Protected WithEvents drpOrgUnits As New RadComboBox
        Protected WithEvents drpPortalCurrency As New RadComboBox

        Protected WithEvents cboAffiliatePortalTabId As New RadComboBox
        'Protected WithEvents cboAffiliatePortalTabId As New DropDownList
        Protected WithEvents cboMyPortalTabId As New RadComboBox
        Protected WithEvents txtProductImageURL As New TextBox
        Protected WithEvents txtImageURL As New TextBox
        Protected WithEvents txtAdminEmail As New TextBox
        Protected WithEvents txtPasswordRegex As New TextBox
        Protected WithEvents btnUpdate As New Button
        Protected WithEvents btnRestore As New Button
        
        Protected WithEvents ImageColumn As New DotNetNuke.UI.WebControls.ImageCommandColumn

        Protected WithEvents btnRestartApplication As New Button
        Protected WithEvents btnClearCache As New Button

        Protected WithEvents butIMSRoleSync As New Button
        Protected WithEvents lblIMSRoleResult As Label
        Protected WithEvents pnlIMSRole As Panel

#End Region

#Region " Enums "
        Private Enum Action
            EDITSITE = 0
            EDITPORTAL = 1
            VIEW = 2
        End Enum

#End Region

#Region "Event Handlers"

        Public Function GetUserRole(ByVal UserInfo As DotNetNuke.Entities.Users.UserInfo) As String

            Dim isPersonifyLogged As Boolean = False
            If Not UserInfo.Profile.GetPropertyValue("MasterCustomerId") Is Nothing Then
                If UserInfo.Profile.GetPropertyValue("MasterCustomerId").Length > 0 Then
                    If Not UserInfo.Profile.GetPropertyValue("SubCustomerId") Is Nothing Then
                        If UserInfo.Profile.GetPropertyValue("SubCustomerId").Length >= 0 Then
                            isPersonifyLogged = True
                        End If
                    End If
                End If
            End If


            Dim myrole As String
            Dim isAdmin As Boolean
            Dim roles(), role As String

            'Default
            myrole = "none"

            isAdmin = False

            If UserInfo.IsSuperUser Then
                myrole = "host"
            Else
                Dim roleController As DotNetNuke.Security.Roles.RoleController = New DotNetNuke.Security.Roles.RoleController
                roles = roleController.GetRolesByUser(UserInfo.UserID, UserInfo.PortalID)
                For Each role In roles
                    If (role = "Administrators") Then
                        isAdmin = True
                    End If
                Next
                If isAdmin Then
                    If isPersonifyLogged = True Then
                        myrole = "personifyadmin"
                    Else
                        myrole = "admin"
                    End If
                Else
                    If isPersonifyLogged = True Then
                        myrole = "personifyuser"
                    Else
                        If UserInfo.UserID > 0 Then
                            myrole = "user"
                        End If
                    End If
                End If
            End If
            Return myrole
        End Function


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim role As String
            role = Me.GetUserRole(UserInfo)

            If Not role = "none" Then
                'START IMS 3246-6159915
                If Not IsPostBack Then
                    Me.DisplayIMSConfiguration()
                End If
                'END IMS 3246-6159915
                CheckConnection()
                LoadPage()

            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("NoUserLoggedIn.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If

        End Sub


        Private Sub btnRestore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRestore.Click
            Response.Redirect(NavigateURL(), True)

        End Sub
        

        Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
            If Me.btnUpdate.Visible Then
                Dim sqlParamArr(17) As SqlParameter
                Dim LocalConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

                sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
                sqlParamArr(0).Value = CurrentPortalId.ToString
                sqlParamArr(1) = New SqlParameter("@AssociationName", SqlDbType.NVarChar, 256)
                sqlParamArr(2) = New SqlParameter("@EnvironmentName", SqlDbType.NVarChar, 256)
                sqlParamArr(3) = New SqlParameter("@AppTypeName", SqlDbType.NVarChar, 256)
                sqlParamArr(4) = New SqlParameter("@VersionName", SqlDbType.NVarChar, 256)
                sqlParamArr(5) = New SqlParameter("@DatabaseName", SqlDbType.NVarChar, 256)
                sqlParamArr(6) = New SqlParameter("@Login", SqlDbType.NVarChar, 256)
                sqlParamArr(7) = New SqlParameter("@Password", SqlDbType.NVarChar, 256)
                If btnUpdate.Text = "Add" Then
                    GetPersonifySiteSettings(0)
                    sqlParamArr(1).Value = SeatInformation.AssociationName
                    sqlParamArr(2).Value = SeatInformation.EnvironmentName
                    sqlParamArr(3).Value = SeatInformation.AppTypeName
                    sqlParamArr(4).Value = SeatInformation.VersionName
                    sqlParamArr(5).Value = SeatInformation.DatabaseName
                    sqlParamArr(6).Value = SeatInformation.Login
                    sqlParamArr(7).Value = TIMSS.Common.Encryption.Encrypt(Pswd)
                Else
                    sqlParamArr(1).Value = String.Empty
                    sqlParamArr(2).Value = String.Empty
                    sqlParamArr(3).Value = String.Empty
                    sqlParamArr(4).Value = String.Empty
                    sqlParamArr(5).Value = String.Empty
                    sqlParamArr(6).Value = String.Empty
                    sqlParamArr(7).Value = String.Empty
                End If

                sqlParamArr(8) = New SqlParameter("@AffiliatePortalTabId", SqlDbType.Int)
                sqlParamArr(8).Value = cboAffiliatePortalTabId.SelectedValue.ToString
                sqlParamArr(9) = New SqlParameter("@MyPortalTabId", SqlDbType.Int)
                sqlParamArr(9).Value = cboMyPortalTabId.SelectedValue.ToString
                sqlParamArr(10) = New SqlParameter("@ProductImageURL", SqlDbType.Int)
                sqlParamArr(10).Value = txtProductImageURL.Text

                sqlParamArr(11) = New SqlParameter("@AdminEmailAddress", SqlDbType.NVarChar, 100)
                sqlParamArr(11).Value = txtAdminEmail.Text

                sqlParamArr(12) = New SqlParameter("@PasswordRegularExpression", SqlDbType.NVarChar, 256)
                sqlParamArr(12).Value = txtPasswordRegex.Text

                '3246-5774803 - Personify Icons and Image Changes            
                sqlParamArr(13) = New SqlParameter("@ImageURL", SqlDbType.NVarChar, 256)
                If txtImageURL.Text = String.Empty Then
                    sqlParamArr(13).Value = Localization.GetString("DefaultPersonifyImages", LocalResourceFile)
                Else
                    sqlParamArr(13).Value = txtImageURL.Text
                End If

                Dim OrgInfo As String() = drpOrgUnits.SelectedValue.ToString.Split(";")

                sqlParamArr(14) = New SqlParameter("@OrgId", SqlDbType.NVarChar, 8)
                sqlParamArr(14).Value = OrgInfo(0)

                sqlParamArr(15) = New SqlParameter("@OrgUnitId", SqlDbType.NVarChar, 8)
                sqlParamArr(15).Value = OrgInfo(1).Trim

                sqlParamArr(16) = New SqlParameter("@PortalCurrency", SqlDbType.NVarChar, 8)
                sqlParamArr(16).Value = drpPortalCurrency.SelectedValue.ToString.Split(";")(0).Trim


                If btnUpdate.Text = "Update" Then
                    Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "UpdatePersonifySiteSettings", sqlParamArr(0), _
                  sqlParamArr(1), sqlParamArr(2), sqlParamArr(3), sqlParamArr(4), sqlParamArr(5), sqlParamArr(6), sqlParamArr(7), sqlParamArr(8), sqlParamArr(9), sqlParamArr(10), sqlParamArr(11), sqlParamArr(12), sqlParamArr(13), sqlParamArr(14), sqlParamArr(15), sqlParamArr(16))
                Else
                    Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "AddPersonifySiteSettings", sqlParamArr(0), _
                    sqlParamArr(1), sqlParamArr(2), sqlParamArr(3), sqlParamArr(4), sqlParamArr(5), sqlParamArr(6), sqlParamArr(7), sqlParamArr(8), sqlParamArr(9), sqlParamArr(10), sqlParamArr(11), sqlParamArr(12), sqlParamArr(13), sqlParamArr(14), sqlParamArr(15), sqlParamArr(16))
                End If
            End If
                PersonifyDataCache.ClearCache()

                Response.Redirect(NavigateURL(), True)

                'DotNetNuke.Common.Utilities.Config.Touch()
        End Sub

        Private Sub btnRestartApplication_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRestartApplication.Click
            PersonifyDataCache.ClearCache()
            DotNetNuke.Common.Utilities.Config.Touch()
            Response.Redirect(NavigateURL(), True)
        End Sub
        Private Sub btnClearCache_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClearCache.Click
            PersonifyDataCache.ClearCache()
            TIMSS.API.CachedApplicationData.ApplicationDataCache.ExpireAll()

            Response.Redirect(NavigateURL(), True)
        End Sub
        Private Sub butIMSRoleSync_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butIMSRoleSync.Click
            'call the IMS web service to get vendor roles            
            Dim roleHash As Hashtable = IMSManager.GetAvailableVendorRoles()
            Dim newRoleAdded As Integer = 0
            For Each Item As DictionaryEntry In roleHash
                If CreateDotnetnukeRole(PortalId, CStr(Item.Key), CStr(Item.Value)) Then
                    newRoleAdded += 1
                End If
            Next
            Me.lblIMSRoleResult.Text = String.Concat(newRoleAdded.ToString, " role(s) have been added.")
            Me.lblIMSRoleResult.Visible = True
        End Sub

        Private Sub btnUpdateSiteSettings_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateSiteSettings.Click
            If Me.pnlRemotingDatabaseConnection.Visible Then
                Dim sqlParamArr(17) As SqlParameter
                Dim LocalConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

                sqlParamArr(0) = New SqlParameter("@PortalId", SqlDbType.Int)
                sqlParamArr(0).Value = -1

                sqlParamArr(1) = New SqlParameter("@AssociationName", SqlDbType.NVarChar, 256)
                sqlParamArr(1).Value = txtRemotingAssocName.Text.ToString
                sqlParamArr(2) = New SqlParameter("@EnvironmentName", SqlDbType.NVarChar, 256)
                sqlParamArr(2).Value = txtRemotingEnvName.Text.ToString
                sqlParamArr(3) = New SqlParameter("@AppTypeName", SqlDbType.NVarChar, 256)
                sqlParamArr(3).Value = txtRemotingAppTypeName.Text.ToString
                sqlParamArr(4) = New SqlParameter("@VersionName", SqlDbType.NVarChar, 256)
                sqlParamArr(4).Value = txtRemotingVersionName.Text.ToString
                sqlParamArr(5) = New SqlParameter("@DatabaseName", SqlDbType.NVarChar, 256)
                sqlParamArr(5).Value = txtRemotingDbName.Text.ToString
                sqlParamArr(6) = New SqlParameter("@Login", SqlDbType.NVarChar, 256)
                sqlParamArr(6).Value = txtRemotingLogin.Text.ToString
                sqlParamArr(7) = New SqlParameter("@Password", SqlDbType.NVarChar, 256)
                sqlParamArr(7).Value = TIMSS.Common.Encryption.Encrypt(txtRemotingPswd.Text.ToString)

                sqlParamArr(8) = New SqlParameter("@AffiliatePortalTabId", SqlDbType.Int)
                sqlParamArr(8).Value = 0
                sqlParamArr(9) = New SqlParameter("@MyPortalTabId", SqlDbType.Int)
                sqlParamArr(9).Value = 0
                sqlParamArr(10) = New SqlParameter("@ProductImageURL", SqlDbType.Int)
                sqlParamArr(10).Value = 0

                sqlParamArr(11) = New SqlParameter("@AdminEmailAddress", SqlDbType.NVarChar, 100)
                sqlParamArr(11).Value = String.Empty

                sqlParamArr(12) = New SqlParameter("@PasswordRegularExpression", SqlDbType.NVarChar, 256)
                sqlParamArr(12).Value = String.Empty

                '3246-5774803 - Personify Icons and Image Changes            
                sqlParamArr(13) = New SqlParameter("@ImageURL", SqlDbType.NVarChar, 256)
                sqlParamArr(13).Value = String.Empty

                sqlParamArr(14) = New SqlParameter("@OrgId", SqlDbType.NVarChar, 8)
                sqlParamArr(14).Value = String.Empty

                sqlParamArr(15) = New SqlParameter("@OrgUnitId", SqlDbType.NVarChar, 8)
                sqlParamArr(15).Value = String.Empty

                sqlParamArr(16) = New SqlParameter("@PortalCurrency", SqlDbType.NVarChar, 8)
                sqlParamArr(16).Value = String.Empty

                Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(LocalConnectionString, "dbo." & "" & "UpdatePersonifySiteSettings", sqlParamArr(0), _
                  sqlParamArr(1), sqlParamArr(2), sqlParamArr(3), sqlParamArr(4), sqlParamArr(5), sqlParamArr(6), sqlParamArr(7), sqlParamArr(8), sqlParamArr(9), sqlParamArr(10), sqlParamArr(11), sqlParamArr(12), sqlParamArr(13), sqlParamArr(14), sqlParamArr(15), sqlParamArr(16))

            End If
            PersonifyDataCache.ClearCache()
            DotNetNuke.Common.Utilities.Config.Touch()
            Response.Redirect(NavigateURL(), True)
        End Sub

        Private Sub btnRestoreSiteSettings_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRestoreSiteSettings.Click
            Response.Redirect(NavigateURL(), True)
        End Sub
#End Region

#Region "IMS helper"

        'START IMS 3246-6159915
        'Const values
        Private Const ConstEnableIMS As String = "EnableIMSRoleSetting"

        Private Sub DisplayIMSConfiguration()
            Dim IMSWebReferenceURL As String = ConfigurationManager.AppSettings("IMSWebReferenceURL")
            Dim EnableIMS As String = ConfigurationManager.AppSettings("EnableIMS")
            If Not String.IsNullOrEmpty(IMSWebReferenceURL) AndAlso Not String.IsNullOrEmpty(EnableIMS) Then
                If Settings(ConstEnableIMS) IsNot Nothing AndAlso EnableIMS.ToUpper = "Y" Then
                    pnlIMSRole.Visible = CType(Settings(ConstEnableIMS), Boolean)
                Else
                    pnlIMSRole.Visible = False
                End If
            Else
                pnlIMSRole.Visible = False
            End If

        End Sub
        Private Function CreateDotnetnukeRole(ByVal PortalId As Integer, ByVal RoleName As String, ByVal RoleDescription As String) As Boolean

            Dim oRoleCtrl As New DotNetNuke.Security.Roles.RoleController
            Dim oPersonifyRole As DotNetNuke.Security.Roles.RoleInfo

            oPersonifyRole = oRoleCtrl.GetRoleByName(PortalId, RoleName)

            If oPersonifyRole Is Nothing Then
                oPersonifyRole = New DotNetNuke.Security.Roles.RoleInfo
                oPersonifyRole.PortalID = PortalId
                oPersonifyRole.RoleName = RoleName
                oPersonifyRole.Description = RoleDescription
                oPersonifyRole.RoleGroupID = -1
                oPersonifyRole.IsPublic = True
                oPersonifyRole.AutoAssignment = False
                oPersonifyRole.BillingFrequency = "M"
                oPersonifyRole.TrialFrequency = "N"
                oRoleCtrl.AddRole(oPersonifyRole)
                Return True
            End If
            Return False
        End Function
        'END IMS 3246-6159915
#End Region

#Region " Functions "
        Private Sub CreateSiteSettingDataTable(ByRef dt As DataTable)
            dt.Columns.Add(CreateDataColumn("PortalID", "System.String"))
            dt.Columns.Add(CreateDataColumn("AssocName", "System.String"))
            dt.Columns.Add(CreateDataColumn("EnvName", "System.String"))
            dt.Columns.Add(CreateDataColumn("AppTypeName", "System.String"))
            dt.Columns.Add(CreateDataColumn("VerName", "System.String"))
            dt.Columns.Add(CreateDataColumn("DBName", "System.String"))
        End Sub

        Private Sub CreatePortalSettingDataTable(ByRef dt As DataTable)
            dt.Columns.Add(CreateDataColumn("PortalID", "System.String"))
            dt.Columns.Add(CreateDataColumn("PortalName", "System.String"))
            dt.Columns.Add(CreateDataColumn("ProductImageURL", "System.String"))
            dt.Columns.Add(CreateDataColumn("ImageURL", "System.String"))
            dt.Columns.Add(CreateDataColumn("PasswordReg", "System.String"))
            dt.Columns.Add(CreateDataColumn("AdminEmail", "System.String"))
            dt.Columns.Add(CreateDataColumn("OrgId", "System.String"))
            dt.Columns.Add(CreateDataColumn("OrgUnitId", "System.String"))
            dt.Columns.Add(CreateDataColumn("PortalCurrency", "System.String"))
        End Sub

        Private Function CreateDataColumn(ByVal ColName As String, ByVal Datatype As String) As DataColumn
            Dim dc As New DataColumn
            dc.ColumnName = ColName
            dc.DataType = System.Type.GetType(Datatype)
            Return dc
        End Function

        Private Sub CreateSiteDataRow(ByRef dr As DataRow, ByVal DataExist As Boolean)
            dr("PortalID") = "0"
            If DataExist Then
                dr("AssocName") = SeatInformation.AssociationName
                dr("EnvName") = SeatInformation.EnvironmentName
                dr("AppTypeName") = SeatInformation.AppTypeName
                dr("VerName") = SeatInformation.VersionName
                dr("DBName") = SeatInformation.DatabaseName
            Else
                dr("AssocName") = ""
                dr("EnvName") = ""
                dr("AppTypeName") = ""
                dr("VerName") = ""
                dr("DBName") = ""
            End If
        End Sub

        Private Sub CreatePortalDataRow(ByRef dr As DataRow, ByVal DataExist As Boolean)
            If DataExist Then
                dr("PasswordReg") = objSiteSettings.PasswordRegularExpression
                dr("AdminEmail") = objSiteSettings.AdminEmailAddress
                dr("OrgId") = objSiteSettings.OrgId
                dr("OrgUnitId") = objSiteSettings.OrgUnitId
                dr("PortalCurrency") = objSiteSettings.PortalCurrency
                dr("ProductImageURL") = objSiteSettings.ProductImageURL
                dr("ImageURL") = objSiteSettings.ImageURL
            Else
                dr("PasswordReg") = ""
                dr("AdminEmail") = ""
                dr("OrgId") = ""
                dr("OrgUnitId") = ""
                dr("ProductImageURL") = ""
                dr("ImageURL") = ""
                dr("PortalCurrency") = ""
            End If

        End Sub

        Private Sub LoadPage()
            Select Case CollAction
                Case Action.EDITSITE
                    Me.pnlRemotingDatabaseConnection.Visible = True
                    Me.pnlPortalSetting.Visible = False
                    pnlIMSRole.Visible = False 'IMS 3246-6159915

                    If Not Page.IsPostBack Then
                        GetPersonifySiteSettings(0)

                        If Not (Page.IsPostBack) Then
                            PopulateSeatInfo()
                        End If

                        Me.btnUpdateSiteSettings.Text = "Update"
                    End If

                Case Action.EDITPORTAL
                    Me.pnlRemotingDatabaseConnection.Visible = False
                    Me.pnlPortalSetting.Visible = True
                    pnlIMSRole.Visible = False 'IMS 3246-6159915

                    If Not Page.IsPostBack Then

                        GetPersonifyPortalSettings(CurrentPortalId)

                        drpOrgUnits.DataTextField = "Key"
                        drpOrgUnits.DataValueField = "Key"
                        drpOrgUnits.DataSource = New_GetOrgUnits()
                        drpOrgUnits.DataBind()

                        If Not drpOrgUnits.Items.FindItemByValue(String.Concat(objSiteSettings.OrgId, ";", objSiteSettings.OrgUnitId)) Is Nothing Then
                            drpOrgUnits.Items.FindItemByValue(String.Concat(objSiteSettings.OrgId, ";", objSiteSettings.OrgUnitId)).Selected = True
                            BindPortalCurrencyList(objSiteSettings.OrgId)
                        Else
                            BindPortalCurrencyList(drpOrgUnits.SelectedValue.ToString.Split(";")(0))
                        End If



                        ''Display a list of portal currencies


                        If Not drpPortalCurrency.Items.FindItemByValue(objSiteSettings.PortalCurrency) Is Nothing Then
                            drpPortalCurrency.Items.FindItemByValue(objSiteSettings.PortalCurrency).Selected = True
                        End If



                        Dim arrPortalTabs As System.Collections.ArrayList = GetPortalTabs(CurrentPortalId, True, True, False, False, False)

                        cboAffiliatePortalTabId.DataSource = arrPortalTabs
                        cboAffiliatePortalTabId.DataBind()
                        'aN test
                        If Not cboAffiliatePortalTabId.Items.FindItemByValue(objSiteSettings.AffilatePortalTabId.ToString) Is Nothing Then
                            cboAffiliatePortalTabId.Items.FindItemByValue(objSiteSettings.AffilatePortalTabId.ToString).Selected = True
                        End If


                        cboMyPortalTabId.DataSource = arrPortalTabs
                        cboMyPortalTabId.DataBind()
                        If Not cboMyPortalTabId.Items.FindItemByValue(objSiteSettings.MyPortalTabId.ToString) Is Nothing Then
                            cboMyPortalTabId.Items.FindItemByValue(objSiteSettings.MyPortalTabId.ToString).Selected = True
                        End If
                        If objSiteSettings.AdminEmailAddress IsNot Nothing Then
                            txtAdminEmail.Text = objSiteSettings.AdminEmailAddress.ToString
                        End If
                        If objSiteSettings.PasswordRegularExpression IsNot Nothing Then
                            txtPasswordRegex.Text = objSiteSettings.PasswordRegularExpression.ToString
                        End If
                        If objSiteSettings.ProductImageURL IsNot Nothing Then
                            txtProductImageURL.Text = objSiteSettings.ProductImageURL.ToString
                        End If
                        '3246-5774803 - Personify Icons and Image Changes
                        If objSiteSettings.ImageURL IsNot Nothing Then
                            txtImageURL.Text = objSiteSettings.ImageURL.ToString
                        End If

                        If String.IsNullOrEmpty(objSiteSettings.OrgId) Then
                            btnUpdate.Text = "Add"
                        Else
                            btnUpdate.Text = "Update"
                        End If
                    End If

                Case Action.VIEW
                    Me.pnlRemotingDatabaseConnection.Visible = False
                    Me.pnlPortalSetting.Visible = False
            End Select

            PopulateGrids()

        End Sub

        Private Sub PopulateGrids()
            Dim Portaldt As New DataTable
            Dim Sitedt As New DataTable
            Dim dr As DataRow = Nothing

            CreateSiteSettingDataTable(Sitedt)
            dr = Sitedt.NewRow

            If GetPersonifySiteSettings(0) Then
                CreateSiteDataRow(dr, True)
            Else
                CreateSiteDataRow(dr, False)
            End If
            Sitedt.Rows.Add(dr)
            If CollAction = Action.VIEW Then
                For Each column As DataGridColumn In dgSite.Columns
                    If column.GetType Is GetType(DotNetNuke.UI.WebControls.ImageCommandColumn) Then
                        Dim imageColumn As DotNetNuke.UI.WebControls.ImageCommandColumn = CType(column, DotNetNuke.UI.WebControls.ImageCommandColumn)

                        If imageColumn.CommandName = "Edit" Then
                            'Dim formatString As String = EditUrl("PID", "KEYFIELD", action)
                            Dim formatString As String = FormatControlURL(Page.Request.Url.AbsoluteUri, Action.EDITSITE, "PID=" & "0")

                            imageColumn.NavigateURLFormatString = formatString

                            '3246-5774803
                            imageColumn.ImageURL = GetEditImageURL()
                            'END 3246-5774803
                        End If
                    End If
                Next
            End If

            Dim oPortals As System.Data.SqlClient.SqlDataReader
            oPortals = GetPersonifyPortals()
            CreatePortalSettingDataTable(Portaldt)
            If oPortals.HasRows Then
                While oPortals.Read
                    dr = Portaldt.NewRow()
                    dr("PortalID") = oPortals.Item("PortalID").ToString
                    dr("PortalName") = oPortals.Item("PortalName").ToString
                    If oPortals.Item("PortalID").ToString = CurrentPortalId.ToString Then
                        lblPortalIDValue.Text = oPortals.Item("PortalID").ToString
                        lblPortalNameValue.Text = oPortals.Item("PortalName").ToString
                    End If

                    If (GetPersonifyPortalSettings(CType(oPortals.Item("PortalID"), Integer))) Then
                        CreatePortalDataRow(dr, True)
                    Else
                        CreatePortalDataRow(dr, False)
                    End If
                    Portaldt.Rows.Add(dr)

                    If CollAction = Action.VIEW Then
                        For Each column As DataGridColumn In dgPortal.Columns
                            If column.GetType Is GetType(DotNetNuke.UI.WebControls.ImageCommandColumn) Then
                                Dim imageColumn As DotNetNuke.UI.WebControls.ImageCommandColumn = CType(column, DotNetNuke.UI.WebControls.ImageCommandColumn)

                                If imageColumn.CommandName = "Edit" Then
                                    'Dim formatString As String = EditUrl("PID", "KEYFIELD", action)
                                    Dim formatString As String = FormatControlURL(Page.Request.Url.AbsoluteUri, Action.EDITPORTAL, "PID=" & "{0}")
                                    formatString = formatString.Replace("KEYFIELD", "{0}")
                                    imageColumn.NavigateURLFormatString = formatString

                                    '3246-5774803
                                    imageColumn.ImageURL = GetEditImageURL()
                                    'END 3246-5774803
                                End If
                            End If
                        Next
                    End If
                End While
                dgPortal.DataSource = Portaldt
                dgPortal.DataBind()

                'an changes
                dgSite.DataSource = Sitedt
                dgSite.DataBind()
            End If
        End Sub

        Public Function FormatControlURL(ByVal strActionUrl As String, _
                         ByVal strActionName As String, _
                         Optional ByVal strMiscArgs As String = "") As String
            Try
                If InStr(strActionUrl, "?") = 0 Then
                    strActionUrl = strActionUrl & "?action=" & strActionName
                Else
                    strActionUrl = strActionUrl & "&action=" & strActionName
                End If

                If strMiscArgs.Length > 0 Then
                    If Not strMiscArgs.StartsWith("&") Then
                        strMiscArgs = "&" & strMiscArgs
                    End If
                    strActionUrl = strActionUrl & strMiscArgs
                End If
                Return strActionUrl
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
                Return ""
            End Try
        End Function

        Private Function GetPersonifyPortals() As System.Data.SqlClient.SqlDataReader
            Dim oPortal As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString
            oPortal = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPortals"), System.Data.SqlClient.SqlDataReader)
            If oPortal.HasRows Then
                Return oPortal
            Else
                Throw New ApplicationException("Unable to read Seat Information for Run Mode WEB. Contact system administrator.")
                Return Nothing
            End If
        End Function

        Private Sub PopulateSeatInfo()
            txtRemotingAssocName.Text = SeatInformation.AssociationName
            txtRemotingEnvName.Text = SeatInformation.EnvironmentName
            txtRemotingAppTypeName.Text = SeatInformation.AppTypeName
            txtRemotingVersionName.Text = SeatInformation.VersionName
            txtRemotingDbName.Text = SeatInformation.DatabaseName
            txtRemotingLogin.Text = SeatInformation.Login()
            txtRemotingPswd.Text = Pswd
        End Sub


        Private Function GetPersonifySiteSettings(ByVal CurrPortalID As Integer) As Boolean
            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifySiteSettings", CurrPortalID), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    SeatInformation.AssociationName = oSiteData.Item("AssociationName").ToString
                    SeatInformation.EnvironmentName = oSiteData.Item("EnvironmentName").ToString
                    SeatInformation.AppTypeName = oSiteData.Item("AppTypeName").ToString
                    SeatInformation.VersionName = oSiteData.Item("VersionName").ToString
                    SeatInformation.DatabaseName = oSiteData.Item("DatabaseName").ToString
                    SeatInformation.Login = oSiteData.Item("Login").ToString
                    Try
                        Pswd = TIMSS.Common.Encryption.Decrypt(oSiteData.Item("Password").ToString)
                    Catch ex As Exception
                        Pswd = oSiteData.Item("Password").ToString
                    End Try
                End While
            Else
                Return False
            End If
            oSiteData.Close()
            oSiteData = Nothing

            Return True
        End Function

        Private Function GetPersonifyPortalSettings(ByVal CurrPortalID As Integer) As Boolean
            Dim oSiteData As System.Data.SqlClient.SqlDataReader
            Dim localConnectionString As String = System.Configuration.ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            oSiteData = CType(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(localConnectionString, "dbo." & "" & "GetPersonifySiteSettings", CurrPortalID), System.Data.SqlClient.SqlDataReader)
            If oSiteData.HasRows Then
                While oSiteData.Read
                    objSiteSettings.OrgId = oSiteData.Item("OrganizationId").ToString
                    objSiteSettings.OrgUnitId = oSiteData.Item("OrganizationUnitId").ToString
                    objSiteSettings.PortalCurrency = oSiteData.Item("PortalCurrency").ToString
                    If Not oSiteData.Item("AffiliatePortalTabId").ToString = "" Then
                        objSiteSettings.AffilatePortalTabId = CType(oSiteData.Item("AffiliatePortalTabId").ToString, Integer)
                    End If
                    If Not oSiteData.Item("MyPortalTabId").ToString = "" Then
                        objSiteSettings.MyPortalTabId = CType(oSiteData.Item("MyPortalTabId").ToString, Integer)
                    End If
                    If (Not oSiteData.Item("ProductImageURL") Is Nothing) AndAlso (Not oSiteData.Item("ProductImageURL").ToString = "") Then
                        objSiteSettings.ProductImageURL = CType(oSiteData.Item("ProductImageURL"), String)
                    End If
                    '3246-5774803 - Personify Icons and Image Changes
                    If (Not oSiteData.Item("ImageURL") Is Nothing) AndAlso (Not oSiteData.Item("ImageURL").ToString = "") Then
                        objSiteSettings.ImageURL = CType(oSiteData.Item("ImageURL"), String)
                    Else
                        objSiteSettings.ImageURL = ""
                    End If
                    If (Not oSiteData.Item("AdminEmailAddress") Is Nothing) AndAlso (Not oSiteData.Item("AdminEmailAddress").ToString = "") Then
                        objSiteSettings.AdminEmailAddress = CType(oSiteData.Item("AdminEmailAddress").ToString, String)
                    Else
                        objSiteSettings.AdminEmailAddress = ""
                    End If
                    If (Not oSiteData.Item("PasswordRegularExpression") Is Nothing) AndAlso (Not oSiteData.Item("PasswordRegularExpression").ToString = "") Then
                        objSiteSettings.PasswordRegularExpression = CType(oSiteData.Item("PasswordRegularExpression").ToString, String)
                    Else
                        objSiteSettings.PasswordRegularExpression = ""
                    End If
                    '3246-5774803 - Personify Icons and Image Changes

                End While
            Else
                Return False
            End If
            oSiteData.Close()
            oSiteData = Nothing

            Return True
        End Function


        Private Function DetermineCollectionAction() As Boolean
            Dim strAction As String

            strAction = Request.QueryString("action")
            CurrentPortalId = Convert.ToInt16(Request.QueryString("PID"))

            Me.pnlSiteSettingGrid.Visible = True
            Me.pnlPortalSettingGrid.Visible = True
            If strAction Is Nothing OrElse strAction Is String.Empty Then
                DetermineCollectionAction = True
                CollAction = Action.VIEW
                Me.pnlRemotingDatabaseConnection.Visible = False
                Me.pnlPortalSetting.Visible = False
            Else
                If CurrentPortalId > -1 Then
                    Select Case CType(strAction, Integer)
                        Case Action.EDITSITE
                            CollAction = Action.EDITSITE
                            DetermineCollectionAction = True
                            Me.pnlRemotingDatabaseConnection.Visible = True
                            Me.pnlPortalSetting.Visible = False
                            pnlIMSRole.Visible = False
                        Case Action.EDITPORTAL
                            DetermineCollectionAction = True
                            CollAction = Action.EDITPORTAL
                            Me.pnlRemotingDatabaseConnection.Visible = False
                            Me.pnlPortalSetting.Visible = True
                        Case Else
                            DetermineCollectionAction = True
                            CollAction = Action.VIEW
                            Me.pnlRemotingDatabaseConnection.Visible = False
                            Me.pnlPortalSetting.Visible = False
                    End Select
                Else
                    DetermineCollectionAction = False
                End If
            End If
        End Function

        '3246-5774803
        Private Function GetEditImageURL() As String

            Dim ImagesFolder As String = Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(PortalId).ImageURL

            Return ResolveUrl("~/" & ImagesFolder & "/edit.gif")
        End Function
        'END 3246-5774803



        Private Function NEW_GetOrgUnits() As DataTable

            Dim request As ISelectRequest = New SelectRequest("OrganizationList")
            Dim tblPSM As ISelectTable = New SelectTable("PSM_ORGUNIT_MEMBER", "PSM")
            Dim tblAO As ISelectTable = New SelectTable("APP_ORGANIZATION", "AO")
            Dim oQueryResult As IQueryResult

            Dim ocolUserId As ISelectedColumn = New SelectedColumn("PSM", "User_id")

            tblPSM.ResultColumns.Add("Org_Id")
            tblPSM.ResultColumns.Add("Org_Unit_Id")
            tblAO.ResultColumns.Add("Currency_Code", "Currency")

            request.Tables.Add(tblPSM)
            request.Tables.Add(tblAO)

            Dim tableJoin As TableJoin = New TableJoin("Normal join", tblPSM, tblAO, JoinType.Normal)
            tableJoin.ColumnJoins.Add(New ColumnJoin("Org_Id", "Org_Id"))

            request.TableJoins.Add(tableJoin)

            request.Parameters.Add("PSM", "User_Id", "P_UserId", "User_id")

            GetPersonifySiteSettings(0)

            Dim oParameters As New Hashtable
            oParameters.Add("P_UserId", SeatInformation.Login)
            Dim OrgId As String = Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(0).OrgId
            Dim OrgUnitId As String = Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(0).OrgUnitId

            Dim _ClsConnect As New PersonifyConnect(OrgId, OrgUnitId)

            oQueryResult = _ClsConnect.PersonifyExecuteQueryRequest(request, oParameters)

            Dim oReturnDataTable As DataTable = oQueryResult.DataSet.Tables(0)

            With oReturnDataTable
                .Columns.Add("Key", GetType(System.String))

                For i As Integer = 0 To .Rows.Count - 1
                    .Rows(i).Item("Key") = String.Concat(.Rows(i).Item("Org_Id"), ";", .Rows(i).Item("Org_Unit_Id"))
                Next

            End With


            Return oReturnDataTable


        End Function


        Protected Function BindPortalCurrencyList(ByVal PoRGiD As String) As DataTable


            'Dim OrgId As String = Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(0).OrgId
            'Dim OrgUnitId As String = Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(0).OrgUnitId

            'Dim _ClsConnect As New PersonifyConnect(OrgId, OrgUnitId)

            'Dim objSearch As New TIMSS.API.Core.SearchObject(OrgId, OrgUnitId)

            'objSearch.Target = _ClsConnect.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ApplicationInfo, "ApplicationCurrencies")

            'objSearch.Parameters.Add("Currency_Code", TIMSS.Enumerations.QueryOperatorEnum.Equals, "", False, True)
            'objSearch.Parameters.Add("Descr", TIMSS.Enumerations.QueryOperatorEnum.Equals, "", False, True)
            'objSearch.Parameters.Add("Currency_Symbol", TIMSS.Enumerations.QueryOperatorEnum.Equals, "", False, True)

            'objSearch.Search()


           

            Dim oResultSet As TIMSS.Interfaces.IResultSet = Nothing
            Dim oSql As New System.Text.StringBuilder

            oSql.Append("select currency_code,descr,Currency_Symbol from app_currency ac ")
            oSql.Append(" where exists ")
            oSql.Append(" (select currency_code from app_exchange_rate ar ")
            oSql.Append(" where ac.currency_code = ar.currency_code and exists ")
            oSql.Append(" (select currency_code from app_organization ao  ")
            oSql.Append(" where  base_currency_code = ao.currency_code and ")
            oSql.Append(" org_id = '")
            oSql.Append(PoRGiD)
            oSql.Append("' ))")

            Dim oSingleRequest As TIMSS.DataAccess.SimpleRequest

            oSingleRequest = New TIMSS.DataAccess.SimpleRequest("Currency", oSql.ToString)

            oResultSet = TIMSS.Global.GetData(oSingleRequest)
            drpPortalCurrency.DataSourceID = ""

            drpPortalCurrency.DataTextField = "Currency_Code"
            drpPortalCurrency.DataValueField = "Currency_Code"
            drpPortalCurrency.DataSource = oResultSet.Unpack.Tables(0)
            drpPortalCurrency.DataBind()

            Return oResultSet.Unpack.Tables(0)



            'Return objSearch.Results.Table







        End Function


        Private Sub CheckConnection()
            If TIMSS.PersonifyInitializer.SystemWasInitialized = True Then
                lblConnectionStatus.Text = Localization.GetString("Connected", LocalResourceFile)
            Else
                lblConnectionStatus.Text = Localization.GetString("Disconnect", LocalResourceFile)
            End If

        End Sub
#End Region

#Region "Optional Interfaces"


        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
            Return Nothing
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserID As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As DotNetNuke.Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
            Return Nothing
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            If Not UserInfo.IsSuperUser Then

                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NotHostMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                Me.Visible = False
            End If
            DetermineCollectionAction()


            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Public Overridable ReadOnly Property ModuleActions() As DotNetNuke.Entities.Modules.Actions.ModuleActionCollection Implements DotNetNuke.Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New DotNetNuke.Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, DotNetNuke.Services.Localization.Localization.GetString(DotNetNuke.Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), DotNetNuke.Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property


        'Private Sub drpPortalCurrency_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles drpPortalCurrency.DataBound
        '    CType(drpPortalCurrency.Footer.FindControl("RadComboItemsCount"), Label).Text = Convert.ToString(drpPortalCurrency.Items.Count)
        'End Sub

        Protected Sub drpPortalCurrency_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxItemEventArgs) Handles drpPortalCurrency.ItemDataBound
            e.Item.Text = String.Format("{0};  {1};  {2}", _
            DirectCast(e.Item.DataItem, DataRowView)("Currency_Code").ToString(), _
            DirectCast(e.Item.DataItem, DataRowView)("Descr").ToString(), _
            DirectCast(e.Item.DataItem, DataRowView)("Currency_Symbol").ToString())
        End Sub


        Protected Sub drpOrgUnits_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxItemEventArgs) Handles drpOrgUnits.ItemDataBound
            e.Item.Text = String.Format("{0};  {1};  {2}", _
                    DirectCast(e.Item.DataItem, DataRowView)("Org_Id").ToString(), _
                    DirectCast(e.Item.DataItem, DataRowView)("Org_Unit_Id").ToString(), _
                    DirectCast(e.Item.DataItem, DataRowView)("Currency").ToString())
       
        End Sub

       
       
        Private Sub drpOrgUnits_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles drpOrgUnits.SelectedIndexChanged
            BindPortalCurrencyList(e.Value.ToString.Split(";")(0))
            If drpPortalCurrency.Items.Count > 0 Then
                drpPortalCurrency.Items(0).Selected = True
            Else
                drpPortalCurrency.Text = ""
            End If

        End Sub
    End Class


End Namespace
