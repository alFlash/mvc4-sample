Option Strict Off

Imports System
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

Imports TIMSS.SqlObjects

Namespace Personify.DNN.Modules.SiteSetting
    <WebService(Namespace:="http://tempuri.org/")> _
 <System.Web.Script.Services.ScriptService()> _
 <WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
 <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
  Public Class PersonifyAjax
        Inherits System.Web.Services.WebService
        
        <WebMethod()> _
        Public Function SearchInstitutions(ByVal prefixText As String, ByVal count As Integer) As String()

            Dim oCustomers As System.Data.DataSet


            oCustomers = df_GetCompanies_NEW(0, prefixText)
            Dim s(oCustomers.Tables(0).Rows.Count) As String
            Dim i As Integer = 0
            For Each customer As DataRow In oCustomers.Tables(0).Rows
                s(i) = CStr(customer.Item("customer_label_name")) '& TIMSS.Constants.Application.C_KEY_DELIMITER & CStr(customer.Item("master_customer_id"))
                i = i + 1
            Next


            Return s

        End Function

        <WebMethod()> _
       Public Function SearchCompanies(ByVal prefixText As String, ByVal count As Integer) As String()

            Dim oCustomers As System.Data.DataSet


            oCustomers = df_GetCompanies_NEW(0, prefixText)
            Dim s(oCustomers.Tables(0).Rows.Count) As String
            Dim i As Integer = 0
            For Each customer As DataRow In oCustomers.Tables(0).Rows
                s(i) = CStr(customer.Item("customer_label_name")) & TIMSS.Constants.Application.C_KEY_DELIMITER & CStr(customer.Item("master_customer_id")) & TIMSS.Constants.Application.C_KEY_DELIMITER & CStr(customer.Item("sub_customer_id"))
                i = i + 1
            Next


            Return s

        End Function


        Private Function df_GetCompanies_NEW(ByVal PortalId As Integer, ByVal CompanyName As String) As DataSet

            Dim strCacheKey As String = ""



            Dim oQueryResult As IQueryResult
            'Dim oParameters As New Hashtable
            Dim oParameters As New TIMSS.SqlObjects.RequestParameters

            oParameters.Add(New RequestParameter("P_RECORDTYPE", "C"))
            oParameters.Add(New RequestParameter("P_LABELNAME", CompanyName))


            Dim param1 As RequestParameter
            param1 = New RequestParameter("P_RECORDTYPE", "C")
            param1.Name = "P_RECORDTYPE"


            Dim param2 As RequestParameter
            param2 = New RequestParameter("P_LABELNAME", CompanyName)
            param2.Name = "P_LABELNAME"



            oQueryResult = TIMSS.Global.App.Execute(df_GetSelectRequest_GetCompanies, "@P_LABELNAME", CompanyName, "@P_RECORDTYPE", "C")

            'Massage the dataset
            With oQueryResult
                If .Success Then
                    For Each oRow As DataRow In .DataSet.Tables(0).Rows
                        'oRow.Item("master_customer_id") = "(" & oRow.Item("master_customer_id") & "-" & oRow.Item("sub_customer_id") & ")"
                        oRow.Item("master_customer_id") = TIMSS.Constants.Application.C_KEY_DELIMITER & oRow.Item("master_customer_id") & TIMSS.Constants.Application.C_KEY_DELIMITER & oRow.Item("sub_customer_id")
                    Next

                End If

            End With


            Return oQueryResult.DataSet

        End Function

        Private Function df_GetSelectRequest_GetCompanies() As IBaseRequest
            Dim request As ISelectRequest = New SelectRequest("GetCompanies")

            Dim tblCustomer As SelectTable = New SelectTable("cus_primary_info_vw", "c")

            tblCustomer.ResultColumns.Add("master_customer_id")
            tblCustomer.ResultColumns.Add("sub_customer_id")
            tblCustomer.ResultColumns.Add("customer_label_name")
            tblCustomer.ResultColumns.Add("formatted_address")

            'tblAppCode.ResultColumns.Add("display_order")
            request.Tables.Add(tblCustomer)
            request.Parameters.Add("c", "record_type", "P_RECORDTYPE", String.Empty)
            request.Parameters.Add("c", "customer_label_name", "P_LABELNAME", "a", ParameterDirection.Input, QueryOperatorType.StartsWith)

            Return request
        End Function

    End Class
End Namespace