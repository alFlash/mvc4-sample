Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.SiteSetting.Business
Imports System.Xml
Imports System.Data.SqlClient
Imports System.data
Imports Personify
Imports TIMSS.Security.Network
Imports DotNetNuke

'START IMS 3246-6159915
Namespace Personify.DNN.Modules.SiteSetting

    Public MustInherit Class SiteSettingEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings
      
#Region "Controls"
        Protected WithEvents chkEnableRole As CheckBox
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents lblInvalidConfig As Label


        'Const values
        Private Const ConstEnableIMS As String = "EnableIMSRoleSetting"

#End Region

#Region "Events"
        Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

            If Not IsPostBack Then
                LoadSetting()
            End If
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            ' Only Update if the Entered Data is Valid
            If Page.IsValid = True Then
                Dim MC As New DotNetNuke.Entities.Modules.ModuleController
                MC.UpdateModuleSetting(ModuleId, ConstEnableIMS, CType(chkEnableRole.Checked, String))
                Response.Redirect(NavigateURL(), True)
            End If

        End Sub


        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(NavigateURL(), True)
        End Sub


#End Region

#Region "helper"

        Private Sub LoadSetting()

            'Read from web config if IMS parameters exists
            Dim IMSWebReferenceURL As String = ConfigurationManager.AppSettings("IMSWebReferenceURL")
            Dim EnableIMS As String = ConfigurationManager.AppSettings("EnableIMS")

            If Not String.IsNullOrEmpty(IMSWebReferenceURL) AndAlso Not String.IsNullOrEmpty(EnableIMS) _
                AndAlso EnableIMS.ToUpper = "Y" Then

                If Settings(ConstEnableIMS) IsNot Nothing Then
                    'Config exists               
                    chkEnableRole.Checked = CType(Settings(ConstEnableIMS), Boolean)
                End If

            Else
                'Error message                     
                chkEnableRole.Enabled = False
                lblInvalidConfig.Visible = True
            End If

        End Sub

#End Region

    End Class


End Namespace
'END IMS 3246-6159915