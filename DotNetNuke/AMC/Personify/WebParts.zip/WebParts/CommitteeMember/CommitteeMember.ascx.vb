Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects



Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.CommitteeMember.Business


Namespace Personify.DNN.Modules.CommitteeMember
    <CLSCompliant(False)> _
    Public MustInherit Class CommitteeMember
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

        'Implements Entities.Modules.IPortable

#Region "Controls"

        Protected WithEvents lblNameAdd As System.Web.UI.WebControls.Label
        Protected WithEvents txtNameAdd As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnNewAdd As System.Web.UI.WebControls.Button
        Protected WithEvents lblPositionAdd As System.Web.UI.WebControls.Label
        Protected WithEvents drpPositionAdd As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ctrlCalanderTermStartDateAdd As Telerik.Web.UI.RadDatePicker
        Protected WithEvents ctrlCalanderTermEndDateAdd As Telerik.Web.UI.RadDatePicker
        Protected WithEvents lblTermStartDateAdd As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermEndDateAdd As System.Web.UI.WebControls.Label
        Protected WithEvents drpVotingStatusAdd As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblVotingStatusAdd As System.Web.UI.WebControls.Label
        Protected WithEvents lblNotesAdd As System.Web.UI.WebControls.Label
        Protected WithEvents txtNotesAdd As System.Web.UI.WebControls.TextBox

        Protected WithEvents btnUpdateAdd As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelAdd As System.Web.UI.WebControls.Button
        Protected WithEvents pnlAdd As System.Web.UI.WebControls.Panel

        Protected WithEvents lblNameEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblNameValueEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblPositionEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblPositionValueEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermEndDateEdit As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermStartDateEdit As System.Web.UI.WebControls.Label
        Protected WithEvents ctrlCalanderTermStartDateEdit As Telerik.Web.UI.RadDatePicker
        Protected WithEvents ctrlCalanderTermEndDateEdit As Telerik.Web.UI.RadDatePicker

        Protected WithEvents lblVotingStatusEdit As System.Web.UI.WebControls.Label
        Protected WithEvents drpVotingStatusEdit As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblNotesEdit As System.Web.UI.WebControls.Label
        Protected WithEvents txtNotesEdit As System.Web.UI.WebControls.TextBox

        Protected WithEvents btnUpdateEdit As System.Web.UI.WebControls.Button
        Protected WithEvents btnCancelEdit As System.Web.UI.WebControls.Button
        Protected WithEvents pnlEdit As System.Web.UI.WebControls.Panel


        Protected WithEvents lblNameView As System.Web.UI.WebControls.Label
        Protected WithEvents lblNameValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblPositionView As System.Web.UI.WebControls.Label
        Protected WithEvents lblPositionValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermStartDateView As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermStartDateValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermEndDateView As System.Web.UI.WebControls.Label
        Protected WithEvents lblTermEndDateValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblVotingStatusView As System.Web.UI.WebControls.Label
        Protected WithEvents lblVotingStatusValueView As System.Web.UI.WebControls.Label
        Protected WithEvents lblNotesView As System.Web.UI.WebControls.Label
        Protected WithEvents lblNotesValueView As System.Web.UI.WebControls.Label

        Protected WithEvents btnDoneView As System.Web.UI.WebControls.Button
        Protected WithEvents pnlView As System.Web.UI.WebControls.Panel
        'Protected WithEvents lnkSearchAdd As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lnkNewAdd As System.Web.UI.WebControls.HyperLink
        Protected WithEvents pnlSearchAdd As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlNewAdd As System.Web.UI.WebControls.Panel

        Protected WithEvents pnlCommitteeMember As System.Web.UI.WebControls.Panel

        Protected WithEvents oMessageControl As WebControls.MessageControl

        'HTML hidden used to know if the call is from Search interface
        Protected WithEvents hdnSearch As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected WithEvents hdnMemberMasterCustomer As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected WithEvents hdnMemberSubCustomer As System.Web.UI.HtmlControls.HtmlInputHidden


        Protected WithEvents hdnExecute As System.Web.UI.HtmlControls.HtmlInputHidden

        Protected WithEvents lblSegmentDesc As System.Web.UI.WebControls.Label

        Protected WithEvents imgNew As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgSearch As System.Web.UI.HtmlControls.HtmlImage
#End Region
#Region "Constats"
        Const C_SUBSYSTEM As String = "COM"
        Const C_TYPE_POSITION As String = "POSITION"
        Const C_TYPE_VOTING_STATUS As String = "VOTING_STATUS"
        Const C_ACTIVE_FLAG As String = "Y"
        Const C_AVAILABLE_TO_WEB_FLAG As String = "Y"
        Const C_PARTICIPATION_STATUS_CODE As String = "ACTIVE"

        Private Const C_SEGMENT_ACTION_BUTTON_TYPE As String = "SegmentActionButtonType"
        Private Const C_SEGMENT_ACTION_URL_FOR_SEARCH As String = "SegmentActionURLForSearch"
        Private Const C_SEGMENT_ACTION_URL_FOR_NEW As String = "SegmentActionURLForNew"
#End Region

#Region "Info"
        Private mode As String = "ADD"
        Private strCommitteeMasterCustomerId As String
        Private strCommitteeSubCustomerId As String
        Private CusRelationship As String


        Public fromOutside As Integer = 0
        Dim IsNew As Boolean = False
        Dim IsSearch As Boolean = False
        Dim newCustomer As String = Nothing

        'direct call from CustomerSearch when coming from AffiliateSegmentList AddMember feature
        Dim IsExecute As Boolean = False

        Dim segmentinfo As AffiliateManagementsessionhelper.SegmentInfo

#End Region
#Region "Properties"
        'property to get/set the memberMasterCustomerId
        Public Property MemberMasterCustomer() As String
            Get
                Return CStr(ViewState("MemberMasterCustomerId"))
            End Get
            Set(ByVal Value As String)
                ViewState("MemberMasterCustomerId") = Value
            End Set
        End Property

        'property to get/set the MemberSubCustomerId
        Public Property MemberSubCustomer() As String
            Get
                Return CStr(ViewState("MemberSubCustomerId"))
            End Get
            Set(ByVal Value As String)
                ViewState("MemberSubCustomerId") = Value
            End Set
        End Property

#End Region


#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If Not oMessageControl.ValidationIssues Is Nothing Then
                        oMessageControl.Clear()
                    End If

                    'segment description on top of the page
                    lblSegmentDesc.Text = segmentinfo.SegmentDescr
                    '3246-5774803
                    LoadImages()
                    'END 3246-5774803

                    If Request.QueryString("Execute") IsNot Nothing Then
                        IsExecute = True
                    Else
                        IsExecute = False
                    End If
                    If Page.IsPostBack And String.Compare(hdnSearch.Value, "Y", True) = 0 Then
                        'the previous call was from the Search interface forcing the parent window to reload
                        IsSearch = True
                        hdnSearch.Value = "N"
                        MemberMasterCustomer = hdnMemberMasterCustomer.Value
                        MemberSubCustomer = hdnMemberSubCustomer.Value
                    End If
                    If (IsSearch And fromOutside = 1) Then
                        Exit Sub
                    Else
                        InitializeControl()
                    End If

                
                Else
                    DisplayUserAccessMessage(role)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Protected Sub btnUpdateAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateAdd.Click

            Dim PositionCode As String
            Dim ParticipationStatusCode As String
            Dim VotingStatusCode As String
            Dim BeginDate As Date
            Dim EndDate As Date = Nothing
            Dim Comments As String

            'Perform date validation
            If Not IsValidDates() Then
                Exit Sub
            End If

            'read the value of the controls
            PositionCode = drpPositionAdd.SelectedValue
            VotingStatusCode = drpVotingStatusAdd.SelectedValue
            'BeginDate = CDate(ctrlCalanderTermStartDateAdd.getDate)
            If Not ctrlCalanderTermStartDateAdd.IsEmpty Then BeginDate = ctrlCalanderTermStartDateAdd.SelectedDate
            'If ctrlCalanderTermEndDateAdd.getDate <> String.Empty Then
            '    EndDate = CDate(ctrlCalanderTermEndDateAdd.getDate)
            'End If
            If Not ctrlCalanderTermEndDateAdd.IsEmpty Then EndDate = ctrlCalanderTermEndDateAdd.SelectedDate

            Comments = txtNotesAdd.Text
            ParticipationStatusCode = C_PARTICIPATION_STATUS_CODE
            'get the new committe member
            Dim member As TIMSS.API.CustomerInfo.ICustomer = ReturnMember()
            If member Is Nothing Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SelectMember", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Exit Sub
            End If
            Dim MemberAddressId As Long = member.AddressDetails(0).CustomerAddressId
            Dim MemberAddressTypeCode As TIMSS.API.Core.ICode = member.AddressDetails(0).AddressTypeCode


            Dim validationIssues As TIMSS.API.Core.Validation.IIssuesCollection = SaveCommitteeMember(PersonifyEnumerations.TransactionMode.ADD, _
                strCommitteeMasterCustomerId, _
                CInt(strCommitteeSubCustomerId), MemberMasterCustomer, CInt(MemberSubCustomer), _
                MemberAddressId, MemberAddressTypeCode, _
                PositionCode, _
                VotingStatusCode, BeginDate, EndDate, _
                Comments, ParticipationStatusCode, -1)
            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If

            If validationIssues.Count > 0 Then
                'The save was not successfull
                oMessageControl.Show(CType(validationIssues, TIMSS.API.Core.Validation.IssuesCollection))
            Else
                Dim segmentInfo As AffiliateManagementSessionHelper.SegmentInfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
                Dim cancelActionURL As Integer = segmentInfo.AffiliateListTabId

                Response.Redirect(NavigateURL(cancelActionURL), True)
            End If

        End Sub


        Protected Sub btnUpdateEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateEdit.Click
            Dim VotingStatusCode As String
            Dim BeginDate As Date
            Dim EndDate As Date = Nothing
            Dim Comments As String
            Dim CommitteeMemberId As Integer

            'Perform date validation
            If Not IsValidDates() Then
                Exit Sub
            End If

            VotingStatusCode = drpVotingStatusEdit.SelectedValue
            'BeginDate = CDate(ctrlCalanderTermStartDateEdit.getDate)
            'If ctrlCalanderTermEndDateEdit.getDate <> String.Empty Then
            '    EndDate = CDate(ctrlCalanderTermEndDateEdit.getDate)
            'End If

            If Not ctrlCalanderTermStartDateEdit.IsEmpty Then BeginDate = ctrlCalanderTermStartDateEdit.SelectedDate
            If Not ctrlCalanderTermEndDateEdit.IsEmpty Then EndDate = ctrlCalanderTermEndDateEdit.SelectedDate
            
            Comments = txtNotesEdit.Text
            CommitteeMemberId = CInt(CusRelationship)

            Dim validationIssues As TIMSS.API.Core.Validation.IIssuesCollection = SaveCommitteeMember( _
                                     ApplicationManager.PersonifyEnumerations.TransactionMode.EDIT, _
                strCommitteeMasterCustomerId, _
                CInt(strCommitteeSubCustomerId), Nothing, -1, _
                Nothing, Nothing, _
                Nothing, _
                VotingStatusCode, BeginDate, EndDate, _
                Comments, Nothing, CommitteeMemberId)

            If Not oMessageControl.ValidationIssues Is Nothing Then
                oMessageControl.Clear()
            End If

            If validationIssues.Count > 0 Then
                'The save was not successfull
                oMessageControl.Show(CType(validationIssues, TIMSS.API.Core.Validation.IssuesCollection))
            Else
                Dim segmentInfo As AffiliateManagementSessionHelper.SegmentInfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
                Dim cancelActionURL As Integer = segmentInfo.AffiliateListTabId

                Response.Redirect(NavigateURL(cancelActionURL), True)
            End If
        End Sub

        Protected Sub btnCancelAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelAdd.Click, btnCancelEdit.Click, btnDoneView.Click
            Try
                If Not oMessageControl.ValidationIssues Is Nothing Then
                    oMessageControl.Clear()
                End If
                Dim segmentInfo As AffiliateManagementSessionHelper.SegmentInfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
                Dim cancelActionURL As Integer = segmentInfo.AffiliateListTabId

                Response.Redirect(NavigateURL(cancelActionURL), True)
            Catch ex As Threading.ThreadAbortException

            Catch ex As Exception
                'ProcessException(ex)
                Exit Sub
            End Try
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            'JavaScript code to hide the Search IFrame when customer selected
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "setClick", "<script language='javascript'>setClick(event)</script>")
            Dim selectblocker As HtmlControl = CType(Me.FindControl("selectblocker"), HtmlControl)
            selectblocker.Attributes("onload") = "setClick(event, this.contentWindow)"
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "RefreshParent", "<script language='javascript'>RefreshParent()</script>")

            'set all the properties 
            SetInfo()

            If (Not IsPostBack) AndAlso (newCustomer Is Nothing) AndAlso (Not MemberMasterCustomer Is Nothing) AndAlso (Not MemberSubCustomer Is Nothing) Then
                'call from Search interface
                fromOutside = 1

                IsSearch = True
                hdnSearch.Value = "Y"

            Else
                fromOutside = 0
            End If

        End Sub

#End Region
#Region "Helper functions"

        Public Sub InitializeControl()
            'check for permissions for ADD, EDIT, VIEW
            If HasPermission() Then
                pnlCommitteeMember.Visible = True
                Select Case mode
                    Case "ADD"
                        InitializeControlAdd()
                    Case "EDIT"
                        InitializeControlEdit()
                    Case "VIEW"
                        InitializeControlView()
                End Select
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoPermissionsMessage", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
        End Sub
        Public Sub SetInfo()
            Dim strQueryString As String = Request.Url.Query
            Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
            Dim strQueryParam As String

            For Each strQueryParam In arrQueryString
                If strQueryParam.IndexOf("mcid") <> -1 Then
                    'set MemberMasterCustomer
                    MemberMasterCustomer = strQueryParam.Replace("mcid=", "")
                    MemberMasterCustomer = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(MemberMasterCustomer))
                    hdnMemberMasterCustomer.Value = MemberMasterCustomer
                ElseIf strQueryParam.IndexOf("scid") <> -1 Then
                    'set MemberSubCustomer
                    MemberSubCustomer = strQueryParam.Replace("scid=", "")
                    MemberSubCustomer = TIMSS.Common.Encryption.Decrypt(Server.UrlDecode(MemberSubCustomer))
                    hdnMemberSubCustomer.Value = MemberSubCustomer
                ElseIf strQueryParam.IndexOf("referrer") <> -1 Then
                    'the call is from the New interface
                    newCustomer = strQueryParam
                    IsNew = True
                ElseIf strQueryParam.IndexOf("args") <> -1 Then
                    CusRelationship = strQueryParam
                    CusRelationship = CusRelationship.Replace("args=", "")
                ElseIf strQueryParam.IndexOf("action") <> -1 Then
                    'specifies the action AddMember, EditMember or ViewMember
                    mode = strQueryParam
                    mode = mode.Replace("action=", "")
                End If
            Next

            'get the current segment information
            segmentinfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
            strCommitteeMasterCustomerId = segmentinfo.SegmentQualifier1
            strCommitteeSubCustomerId = segmentinfo.SegmentQualifier2

        End Sub
        Private Sub InitializeControlAdd()
            'build ADD interface

            'only ADD panel is shown, EDIT and VIEW panels are hidden
            pnlAdd.Visible = True
            pnlEdit.Visible = False
            pnlView.Visible = False
            Dim ctrl As String
            Dim updatePressed As Boolean = False
            If IsExecute Then
                'comming from CustomerSearch directly - AffiliateSegmentList -> Add Member->CustomerSearch->CommitteeMember
                For Each ctrl In Page.Request.Params.AllKeys
                    If ctrl.IndexOf("btnUpdateAdd") > 0 Then
                        updatePressed = True
                    End If
                Next
            End If
            If (Not Page.IsPostBack) Or (IsExecute And Not updatePressed) Then
                'Dropdown will be loaded in 2 cases first load of page and comming from CustomerSearch directly
                'load Position Dropdown items
                With Me.drpPositionAdd
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = Me.GetApplicationCodes(C_SUBSYSTEM, C_TYPE_POSITION, True)
                    .DataSource = appCodes
                    .DataTextField = "Description"
                    .DataValueField = "Code"
                    .DataBind()
                End With
                'load VotingStatus Dropdown items
                With Me.drpVotingStatusAdd
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = Me.GetApplicationCodes(C_SUBSYSTEM, C_TYPE_VOTING_STATUS, True)
                    .DataSource = appCodes
                    .DataTextField = "Description"
                    .DataValueField = "Code"
                    .DataBind()
                End With
            End If

            If (Page.IsPostBack And IsSearch And fromOutside = 0) Then
                'load dropdowns when page is reloaded after coming from CustomerSearch IFrame
                With Me.drpPositionAdd
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = Me.GetApplicationCodes(C_SUBSYSTEM, C_TYPE_POSITION, True)
                    .DataSource = appCodes
                    .DataTextField = "Description"
                    .DataValueField = "Code"
                    .DataBind()
                End With
                With Me.drpVotingStatusAdd
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = Me.GetApplicationCodes(C_SUBSYSTEM, C_TYPE_VOTING_STATUS, True)
                    .DataSource = appCodes
                    .DataTextField = "Description"
                    .DataValueField = "Code"
                    .DataBind()
                End With
            End If
            If MemberMasterCustomer <> String.Empty And MemberSubCustomer <> String.Empty Then
                'show the name of the selected Customer or New Customer
                txtNameAdd.Text = ReturnMember().LabelName
            End If

            'based on Settings("SegmentActionButtonType") values New and Search buttons will be shown or not 
            If Not Settings(C_SEGMENT_ACTION_BUTTON_TYPE) Is Nothing Then
                Select Case CStr(Settings(C_SEGMENT_ACTION_BUTTON_TYPE)).ToUpper
                    Case "NEW"
                        pnlNewAdd.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_NEW) Is Nothing Then
                            lnkNewAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_NEW), Integer), "", "&ref=segment&reftabid=" & TabId)
                        End If
                        pnlSearchAdd.Visible = False
                    Case "SEARCH"
                        pnlNewAdd.Visible = False
                        pnlSearchAdd.Visible = True
                        Dim selectblocker As HtmlControl = CType(Me.FindControl("selectblocker"), HtmlControl)
                        selectblocker.Attributes("src") = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer), "", "")

                        'If Not Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH) Is Nothing Then
                        'lnkSearchAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer))
                        'End If
                    Case "BOTH"
                        pnlNewAdd.Visible = True
                        If Not Settings(C_SEGMENT_ACTION_URL_FOR_NEW) Is Nothing Then
                            lnkNewAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_NEW), Integer), "", "&ref=segment&reftabid=" & TabId)
                        End If
                        pnlSearchAdd.Visible = True
                        Dim selectblocker As HtmlControl = CType(Me.FindControl("selectblocker"), HtmlControl)
                        selectblocker.Attributes("src") = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer), "", "")


                        'If Not Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH) Is Nothing Then
                        'lnkSearchAdd.NavigateUrl = NavigateURL(CType(Settings(C_SEGMENT_ACTION_URL_FOR_SEARCH), Integer))
                        'End If
                    Case Else
                        pnlNewAdd.Visible = False
                        pnlSearchAdd.Visible = False
                End Select
            End If

        End Sub

        Private Sub InitializeControlEdit()
            pnlAdd.Visible = False
            pnlEdit.Visible = True
            pnlView.Visible = False
            If Not Page.IsPostBack Then
                'when page is first loaded VotingStatus DropDown is loaded
                With Me.drpVotingStatusEdit
                    Dim appCodes As TIMSS.API.ApplicationInfo.IApplicationCodes = Me.GetApplicationCodes(C_SUBSYSTEM, C_TYPE_VOTING_STATUS, True)
                    .DataSource = appCodes
                    .DataTextField = "Description"
                    .DataValueField = "Code"
                    .DataBind()
                End With


                Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                'get customer object for current Committee
                oCustomers = GetCustomers(strCommitteeMasterCustomerId, strCommitteeSubCustomerId)
                Dim oMembers As TIMSS.API.CommitteeInfo.ICommitteeMembers = oCustomers(0).CommitteeMembers
                Dim oMember As TIMSS.API.CommitteeInfo.ICommitteeMember

                For Each oMember In oMembers
                    'find the selected member and set the controls with his values
                    If CStr(oMember.CommitteeMemberId) = CusRelationship Then
                        lblNameValueEdit.Text = oMember.CommitteeMemberLabelName
                        lblPositionValueEdit.Text = oMember.PositionCode.Description
                        drpVotingStatusEdit.SelectedValue = oMember.VotingStatusCode.Code
                        'ctrlCalanderTermStartDateEdit.SetDate = Format(oMember.BeginDate, "MM/dd/yyyy")
                        'ctrlCalanderTermEndDateEdit.SetDate = Format(oMember.EndDate, "MM/dd/yyyy")
                        ctrlCalanderTermStartDateEdit.SelectedDate = oMember.BeginDate
                        ctrlCalanderTermEndDateEdit.SelectedDate = oMember.EndDate
                        txtNotesEdit.Text = oMember.Comments
                    End If
                Next
            End If
        End Sub

        Private Sub InitializeControlView()
            pnlAdd.Visible = False
            pnlEdit.Visible = False
            pnlView.Visible = True

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            'get Customer object for the selected Committee
            oCustomers = GetCustomers(strCommitteeMasterCustomerId, strCommitteeSubCustomerId)
            Dim oMembers As TIMSS.API.CommitteeInfo.ICommitteeMembers = oCustomers(0).CommitteeMembers
            Dim oMember As TIMSS.API.CommitteeInfo.ICommitteeMember

            For Each oMember In oMembers
                'find the selected member and set the controls value with the values of this member
                If CStr(oMember.CommitteeMemberId) = CusRelationship Then
                    lblNameValueView.Text = oMember.CommitteeMemberLabelName
                    lblPositionValueView.Text = oMember.PositionCode.Description
                    lblVotingStatusValueView.Text = oMember.VotingStatusCode.Description
                    lblTermStartDateValueView.Text = Format(oMember.BeginDate, "MM/dd/yyyy")
                    lblTermEndDateValueView.Text = Format(oMember.EndDate, "MM/dd/yyyy")
                    lblNotesValueView.Text = oMember.Comments
                End If
            Next
        End Sub

        Private Function ReturnMember() As TIMSS.API.CustomerInfo.ICustomer
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            'get Customer
            oCustomers = GetCustomers(MemberMasterCustomer, MemberSubCustomer)
            Return oCustomers(0)
        End Function

        Private Function HasPermission() As Boolean
            If Page.IsPostBack Then Return True
            'check permissions to ADD, EDIT, VIEW only at first load of the Page
            Try

                Select Case mode.ToUpper()
                    Case "ADD"
                        'test AddMemberFlag
                        If Not segmentinfo.CanAddMemberFlag Then
                            Return False
                        End If
                    Case "EDIT"
                        'test ReadOnlyFlag
                        If segmentinfo.ReadOnlyFlag Then
                            Return False
                        End If
                        'check if it was specified a member to edit
                        If (CusRelationship Is Nothing) Or (CusRelationship = "") Then
                            Return False
                        End If

                    Case "VIEW"
                        'check if it was specified a member to view
                        If (CusRelationship Is Nothing) Or (CusRelationship = "") Then
                            Return False
                        End If
                    Case Else
                        Return False
                End Select
                If (mode Is Nothing) OrElse String.Compare(mode, "ADD", True) = 0 Then
                Else
                    'check for EDIT and VIEW that the specified Committee Member Exists
                    Dim CommitteeMemberExists As Boolean = False
                    Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
                    oCustomers = GetCustomers(strCommitteeMasterCustomerId, strCommitteeSubCustomerId)
                    Dim oMembers As TIMSS.API.CommitteeInfo.ICommitteeMembers = oCustomers(0).CommitteeMembers
                    Dim oMember As TIMSS.API.CommitteeInfo.ICommitteeMember

                    For Each oMember In oMembers
                        If CStr(oMember.CommitteeMemberId) = CusRelationship Then
                            CommitteeMemberExists = True
                        End If
                    Next
                    If CommitteeMemberExists = False Then
                        Return False
                    End If

                End If
                Return True

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            Finally

            End Try
        End Function


        'check for valid dates
        Private Function IsValidDates() As Boolean
            Try
                'If Not IsDate(ctrlCalanderTermStartDateAdd.getDate) AndAlso (mode = "ADD") Then
                '    ctrlCalanderTermStartDateAdd.SetDate = ""
                '    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '    Return False
                'End If

                If ctrlCalanderTermStartDateAdd.IsEmpty AndAlso (mode = "ADD") Then
                    ctrlCalanderTermStartDateAdd.Clear()
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If

                ''Only if TermEndDate has been specified, then only run the validations
                'If ctrlCalanderTermEndDateAdd.getDate <> String.Empty Then
                '    If Not IsDate(ctrlCalanderTermEndDateAdd.getDate) AndAlso (mode = "ADD") Then
                '        ctrlCalanderTermEndDateAdd.SetDate = ""
                '        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEndDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '        Return False
                '    End If

                '    If ctrlCalanderTermEndDateAdd.getDate <> String.Empty AndAlso DateDiff(DateInterval.Day, CDate(ctrlCalanderTermStartDateAdd.getDate), CDate(ctrlCalanderTermEndDateAdd.getDate)) < 0 AndAlso (mode = "ADD") Then
                '        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("EndDateGreaterThanStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '        Return False
                '    End If
                'End If

                'Only if TermEndDate has been specified, then only run the validations
                If Not ctrlCalanderTermEndDateAdd.IsEmpty Then
                    If ctrlCalanderTermEndDateAdd.IsEmpty AndAlso (mode = "ADD") Then
                        ctrlCalanderTermEndDateAdd.Clear()
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEndDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    If Not ctrlCalanderTermEndDateAdd.IsEmpty AndAlso DateDiff(DateInterval.Day, CDate(ctrlCalanderTermStartDateAdd.SelectedDate), CDate(ctrlCalanderTermEndDateAdd.SelectedDate)) < 0 AndAlso (mode = "ADD") Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("EndDateGreaterThanStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                End If

                'If Not IsDate(ctrlCalanderTermStartDateEdit.getDate) AndAlso (mode = "EDIT") Then
                '    ctrlCalanderTermStartDateEdit.SetDate = ""
                '    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '    Return False
                'End If


                If ctrlCalanderTermStartDateEdit.IsEmpty AndAlso (mode = "EDIT") Then
                    ctrlCalanderTermStartDateEdit.Clear()
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Return False
                End If

                ''Only if TermEndDate has been specified, then only run the validations
                'If ctrlCalanderTermEndDateEdit.getDate <> String.Empty Then
                '    If Not IsDate(ctrlCalanderTermEndDateEdit.getDate) AndAlso (mode = "EDIT") Then
                '        ctrlCalanderTermEndDateAdd.SetDate = ""
                '        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEndDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '        Return False
                '    End If

                '    If ctrlCalanderTermEndDateEdit.getDate <> String.Empty AndAlso DateDiff(DateInterval.Day, CDate(ctrlCalanderTermStartDateEdit.getDate), CDate(ctrlCalanderTermEndDateEdit.getDate)) < 0 AndAlso (mode = "EDIT") Then
                '        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("EndDateGreaterThanStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                '        Return False
                '    End If
                'End If

                'Only if TermEndDate has been specified, then only run the validations
                If Not ctrlCalanderTermEndDateEdit.IsEmpty Then
                    If ctrlCalanderTermEndDateEdit.IsEmpty AndAlso (mode = "EDIT") Then
                        ctrlCalanderTermEndDateAdd.Clear()
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidEndDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If

                    If Not ctrlCalanderTermEndDateEdit.IsEmpty AndAlso DateDiff(DateInterval.Day, CDate(ctrlCalanderTermStartDateEdit.SelectedDate), CDate(ctrlCalanderTermEndDateEdit.SelectedDate)) < 0 AndAlso (mode = "EDIT") Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("EndDateGreaterThanStartDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Return False
                    End If
                End If

                Return True

            Catch ex As Exception
                Return False
            End Try
        End Function

        '3246-5774803
        Private Sub LoadImages()
            imgNew.Src = ResolveUrl("~/" & SiteImagesFolder & "/plus2.gif")
            imgSearch.Src = ResolveUrl("~/" & SiteImagesFolder & "/folderopen.gif")

        End Sub
        'end  3246-5774803
#End Region

#Region "PErsonify DAta"

        Private Function GetCustomers(ByVal MCID As String, ByVal SCID As Integer) As TIMSS.API.CustomerInfo.ICustomers

            Dim ocs As TIMSS.API.CustomerInfo.ICustomers

            ocs = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            ocs.Filter.Add("MasterCustomerId", MCID)
            ocs.Filter.Add("SubCustomerId", SCID)
            ocs.Fill()

            Return ocs


        End Function

        Private Function SaveCommitteeMember(ByVal Mode As TransactionMode, _
            ByVal CommitteeMasterCustomer As String, _
            ByVal CommitteeSubCustomer As Integer, ByVal MemberMasterCustomer As String, ByVal MemberSubCustomer As Integer, _
            ByVal MemberAddressId As Long, ByVal MemberAddressTypeCode As TIMSS.API.Core.ICode, _
            ByVal PositionCode As String, _
            ByVal VotingStatusCode As String, ByVal BeginDate As Date, ByVal EndDate As Date, _
            ByVal Comments As String, ByVal ParticipationStatusCode As String, ByVal CommitteeMemberId As Integer, _
      Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection



            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False


            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(SessionKeys.PersonifySaveCommitteeMemberGUIDKeys) Is Nothing Then
                    ClearSessionObject(SessionKeys.PersonifySaveCommitteeMemberGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(SessionKeys.PersonifySaveCommitteeMemberGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "CommitteeMember"
                End With

            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(SessionKeys.PersonifySaveCommitteeMemberGUIDKeys), BusinessObjectGUIDStorage())
            End If

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PErsonifyGetCollection( TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            oCustomers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CommitteeMasterCustomer)
            oCustomers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CommitteeSubCustomer)
            oCustomers.Fill()
            Dim oCommitteeMembers As TIMSS.API.CommitteeInfo.ICommitteeMembers = oCustomers(0).CommitteeMembers
            Dim oCommitteeMember As TIMSS.API.CommitteeInfo.ICommitteeMember


            If Mode = TransactionMode.ADD Then
                oCommitteeMember = oCommitteeMembers.CreateNew()
                oCommitteeMembers.Add(oCommitteeMember)
                With oCommitteeMember
                    .CommitteeMasterCustomer = CommitteeMasterCustomer
                    .CommitteeSubCustomer = CommitteeSubCustomer
                    .MemberMasterCustomer = MemberMasterCustomer
                    .MemberSubCustomer = MemberSubCustomer
                    .PositionCode = .PositionCode.List(PositionCode).ToCodeObject
                    .VotingStatusCode = .VotingStatusCode.List(VotingStatusCode).ToCodeObject
                    .BeginDate = BeginDate
                    .EndDate = EndDate
                    .Comments = Comments
                    .ParticipationStatusCode = .ParticipationStatusCode.List(ParticipationStatusCode).ToCodeObject
                    .MemberAddressId = MemberAddressId
                    .MemberAddressTypeCode = MemberAddressTypeCode
                End With



            ElseIf Mode = TransactionMode.EDIT Then

                Dim i As Integer
                For i = 0 To oCustomers(0).CommitteeMembers.Count - 1
                    With oCustomers(0).CommitteeMembers(i)
                        If CStr(.CommitteeMemberId) = CommitteeMemberId Then
                            .VotingStatusCode = .VotingStatusCode.List(VotingStatusCode).ToCodeObject
                            .BeginDate = BeginDate
                            .EndDate = EndDate
                            .Comments = Comments
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).CommitteeMembers(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).CommitteeMembers(i).Guid
                End If
            ElseIf Mode = TransactionMode.DELETE Then
                Dim i As Integer
                For i = 0 To oCustomers(0).CommitteeMembers.Count - 1
                    With oCustomers(0).CommitteeMembers(i)
                        If CStr(.CommitteeMemberId) = CommitteeMemberId Then
                            'Remove Member
                            .EndDate = CDate(Format(Date.Now, "MM/dd/yyyy"))
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).CommitteeMembers(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).CommitteeMembers(i).Guid
                End If
            End If

            AddSessionObject(SessionKeys.PersonifySaveCommitteeMemberGUIDKeys, oclsGUID)


            oCustomers.Save()

            If oCustomers.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)

                oCustomers.Save()
            End If

            ' Clear the cached communication methods if no validation issues exist
            If oCustomers.ValidationIssues.ErrorCount = 0 Then
                If PersonifyDataCache.Fetch("GetCustomer" & CommitteeMasterCustomer & CommitteeSubCustomer) Is Nothing Then
                    PersonifyDataCache.Remove("GetCustomer" & CommitteeMasterCustomer & CommitteeSubCustomer)
                End If
               
                ClearSessionObject(SessionKeys.PersonifySaveCommitteeMemberGUIDKeys)
            End If
            Return oCustomers.ValidationIssues


        End Function


#End Region
    End Class

End Namespace
