Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.ProductListing.Business
Imports System.IO

Namespace Personify.DNN.Modules.ProductListing

	Public MustInherit Class ProductListingEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings

#Region "Controls"

		Private Const C_TEMPLATES As String = "Templates"
		Private Const C_FILEPATTERN As String = "*.?s*"	'*.xsl

		Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
		Protected WithEvents DropDownList_Attributes As DropDownList
		Protected WithEvents ListBox_Subsystems As ListBox
		Protected WithEvents TextBoxBase_ProductIDs As Personify.WebControls.TextBoxBase
		Protected WithEvents DropDownList_MainProduct As DropDownList
		Protected WithEvents DropDownList_MembersOnly As DropDownList
		Protected WithEvents DropDownList_AddToCart As DropDownList
		Protected WithEvents DropDownList_AddToWishList As DropDownList
		Protected WithEvents DropDownList_BuyForGroup As DropDownList
		Protected WithEvents DropDownList_DisplayImage As DropDownList
		Protected WithEvents DropDownList_DefaultPerPage As DropDownList
		Protected WithEvents DropDownList_Columns As DropDownList
		Protected WithEvents DropDownList_DefaultSorting As DropDownList
		Protected WithEvents TextBoxBase_TruncateDescription As Personify.WebControls.TextBoxBase
        Protected WithEvents TextBoxBase_MaxProduct As Personify.WebControls.TextBoxBase
        Protected WithEvents TextBox_DefaultQuantity As System.Web.UI.WebControls.TextBox
		Protected WithEvents DropDownList_Layout As DropDownList
		Protected WithEvents Urlcontrol_DetailUrl As DotNetNuke.UI.UserControls.UrlControl
		Protected WithEvents Urlcontrol_BuyForGroup As DotNetNuke.UI.UserControls.UrlControl
		Protected WithEvents Randomize_CheckBox As CheckBox

#End Region

#Region "Private Members"
		Private itemId As Integer
#End Region

#Region "Event Handlers"


		Private Function GetTemplates() As ListItemCollection
			Try
				Dim lic As New ListItemCollection
				Dim ListItem As ListItem
				' Create a reference to the current directory.
				Dim dInfo As New DirectoryInfo(Me.MapPathSecure((ModulePath & C_TEMPLATES)))
				' Create an array representing the files in the current directory.
				Dim fInfo As FileInfo() = dInfo.GetFiles(C_FILEPATTERN)
				Dim fiTemp As FileInfo
				For Each fiTemp In fInfo
					ListItem = New ListItem
					ListItem.Text = fiTemp.Name
					ListItem.Value = fiTemp.Name
					lic.Add(ListItem)
				Next fiTemp
				Return lic

			Catch ex As Exception
				Throw ex
			End Try
		End Function


		'Public Function Settings(ByVal aSettingString As String) As String
		'	Dim value As String = ""
		'	Dim MC As New DotNetNuke.Entities.Modules.ModuleController
		'	Dim HSettings As Hashtable = MC.GetModuleSettings(ModuleId)
		'	value = Convert.ToString(HSettings(aSettingString))
		'	Return value
		'End Function

		Private Sub LoadDropDownListSetting(ByVal aDropDownList As DropDownList, ByVal aSettingString As String, ByVal aSettingList As String)

			If Not aDropDownList.Items.Count > 0 Then

				Dim YesNo As String = Localization.GetString(aSettingList, Me.LocalResourceFile)
				Dim aYesNo() As String = YesNo.Split(New Char() {"|"c})

				Dim aSetting As String = Convert.ToString(Settings(aSettingString))

				For i As Integer = 0 To Convert.ToInt32(aYesNo.Length / 2) - 1
					aDropDownList.Items.Add(New System.Web.UI.WebControls.ListItem(aYesNo(2 * i + 1), aYesNo(2 * i)))
					If aDropDownList.Items(aDropDownList.Items.Count - 1).Value = aSetting Then
						aDropDownList.SelectedValue = aSetting
					End If
				Next
			End If


		End Sub



		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

				If Not IsPostBack Then

                    Dim ss As TIMSS.API.ApplicationInfo.IApplicationSubsystems = df_GetProductRelatedActiveSubsystemList()

					If ListBox_Subsystems.Items.Count = 0 Then
						ListBox_Subsystems.Items.Add(New System.Web.UI.WebControls.ListItem("All", ""))
						For Each sss As TIMSS.API.ApplicationInfo.IApplicationSubsystem In ss
							ListBox_Subsystems.Items.Add(New System.Web.UI.WebControls.ListItem(sss.SubsystemName, sss.Subsystem))
						Next

						Dim setting As String = Convert.ToString(Settings("Subsystens"))
						If setting IsNot Nothing AndAlso setting.Length > 0 Then
							Dim ssettings() As String = setting.Split(New Char() {"|"c})
							If ssettings IsNot Nothing AndAlso ssettings.Length > 0 Then
								For i As Integer = 0 To ssettings.Length - 1

									Dim x As Integer = ListBox_Subsystems.Items.IndexOf(ListBox_Subsystems.Items.FindByValue(ssettings(i)))
									If x >= 0 Then
										ListBox_Subsystems.Items(x).Selected = True
									End If
								Next
							End If
						End If
						If ListBox_Subsystems.SelectedIndex < 1 Then ListBox_Subsystems.SelectedIndex = 0
					End If

					LoadDropDownListSetting(DropDownList_Attributes, "Attributes", "Attributes.List")

                    If Settings("DefaultQuantity") IsNot Nothing Then
                        TextBox_DefaultQuantity.Text = CStr(Settings("DefaultQuantity"))
                    Else
                        TextBox_DefaultQuantity.Text = "1"
                    End If

                    If Settings("ProductIDs") IsNot Nothing Then
                        TextBoxBase_ProductIDs.Text = Convert.ToString(Settings("ProductIDs"))
                    End If

                    LoadDropDownListSetting(DropDownList_Columns, "Columns", "Columns.List")

                    LoadDropDownListSetting(DropDownList_MainProduct, "MainProduct", "YesNo.List")
                    LoadDropDownListSetting(DropDownList_MembersOnly, "MembersOnly", "YesNoBoth.List")
                    LoadDropDownListSetting(DropDownList_AddToCart, "AddToCart", "YesNo.List")
                    LoadDropDownListSetting(DropDownList_AddToWishList, "AddToWishList", "YesNo.List")
                    LoadDropDownListSetting(DropDownList_BuyForGroup, "BuyForGroup", "YesNo.List")



                    LoadDropDownListSetting(DropDownList_DisplayImage, "DisplayImage", "YesNo.List")

                    If Not DropDownList_Layout.Items.Count > 0 Then
                        Dim li As ListItem
                        For Each li In GetTemplates()
                            DropDownList_Layout.Items.Add(li)
                        Next
                        DropDownList_Layout.SelectedIndex = DropDownList_Layout.Items.IndexOf(DropDownList_Layout.Items.FindByValue(Convert.ToString(Settings("Layout"))))
                    End If


                    LoadDropDownListSetting(DropDownList_DefaultPerPage, "ItemsPerPage", "ItemsPerPage.List")
                    LoadDropDownListSetting(DropDownList_DefaultSorting, "Sorting", "Sorting.List")

                    If Settings("MaxProduct") IsNot Nothing Then
                        TextBoxBase_MaxProduct.Text = Convert.ToString(Settings("MaxProduct"))
                    Else
                        TextBoxBase_MaxProduct.Text = "0"
                    End If

                    If Settings("Truncate") IsNot Nothing Then
                        TextBoxBase_TruncateDescription.Text = Convert.ToString(Settings("Truncate"))
                    Else
                        TextBoxBase_TruncateDescription.Text = "0"
                    End If

                    If Settings("Randomize") IsNot Nothing Then
                        Randomize_CheckBox.Checked = Convert.ToBoolean(Settings("Randomize"))
                    Else
                        Randomize_CheckBox.Checked = False
                    End If

                    If Settings("DetailUrl") IsNot Nothing AndAlso Settings("DetailUrlType") IsNot Nothing Then
                        Urlcontrol_DetailUrl.Url = Convert.ToString(Settings("DetailUrl"))
                        Urlcontrol_DetailUrl.UrlType = Convert.ToString(Settings("DetailUrlType"))
                    End If

                    If Settings("BuyForGroupUrl") IsNot Nothing AndAlso Settings("BuyForGroupUrlType") IsNot Nothing Then
                        Urlcontrol_BuyForGroup.Url = Convert.ToString(Settings("BuyForGroupUrl"))
                        Urlcontrol_BuyForGroup.UrlType = Convert.ToString(Settings("BuyForGroupUrlType"))
                    End If

                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try
				' Only Update if the Entered Data is Valid
				If Page.IsValid = True Then

					Dim MC As New DotNetNuke.Entities.Modules.ModuleController

                    MC.UpdateModuleSetting(ModuleId, Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)

					MC.UpdateModuleSetting(ModuleId, "Attributes", DropDownList_Attributes.SelectedValue)

					MC.UpdateModuleSetting(ModuleId, "ProductIDs", TextBoxBase_ProductIDs.Text)
					MC.UpdateModuleSetting(ModuleId, "Columns", DropDownList_Columns.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "MainProduct", DropDownList_MainProduct.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "MembersOnly", DropDownList_MembersOnly.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "AddToCart", DropDownList_AddToCart.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "AddToWishList", DropDownList_AddToWishList.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "BuyForGroup", DropDownList_BuyForGroup.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "DisplayImage", DropDownList_DisplayImage.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "Layout", DropDownList_Layout.SelectedValue)
					MC.UpdateModuleSetting(ModuleId, "ItemsPerPage", DropDownList_DefaultPerPage.SelectedValue)
                    MC.UpdateModuleSetting(ModuleId, "Sorting", DropDownList_DefaultSorting.SelectedValue)
                    MC.UpdateModuleSetting(ModuleId, "DefaultQuantity", TextBox_DefaultQuantity.Text)
					MC.UpdateModuleSetting(ModuleId, "MaxProduct", TextBoxBase_MaxProduct.Text)
					MC.UpdateModuleSetting(ModuleId, "Truncate", TextBoxBase_TruncateDescription.Text)
					MC.UpdateModuleSetting(ModuleId, "DetailUrl", Urlcontrol_DetailUrl.Url)
					MC.UpdateModuleSetting(ModuleId, "DetailUrlType", Urlcontrol_DetailUrl.UrlType)

					MC.UpdateModuleSetting(ModuleId, "BuyForGroupUrl", Urlcontrol_BuyForGroup.Url)
					MC.UpdateModuleSetting(ModuleId, "BuyForGroupUrlType", Urlcontrol_BuyForGroup.UrlType)

					MC.UpdateModuleSetting(ModuleId, "Randomize", Convert.ToString(Randomize_CheckBox.Checked))

					Dim ss As String = ""
					If ListBox_Subsystems.Items.Count > 0 Then
						For i As Integer = 0 To ListBox_Subsystems.Items.Count - 1
							If i = 0 AndAlso ListBox_Subsystems.Items(i).Selected = True Then
								Exit For
							End If

							If ListBox_Subsystems.Items(i).Selected = True Then
								If ss.Length > 0 Then ss = ss + "|"
								ss = ss + ListBox_Subsystems.Items(i).Value
							End If
						Next
					End If
					MC.UpdateModuleSetting(ModuleId, "Subsystens", ss)

					Response.Redirect(NavigateURL(), True)
				End If
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try
				'If Not Null.IsNull(itemId) Then
				'	Dim objCtlProductListing As New ProductListingController
				'	objCtlProductListing.Delete(itemId)
				'End If

				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

#Region "PErsonify DAta"
        Private Function df_GetProductRelatedActiveSubsystemList() As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            Dim oAllSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems
            Dim oActiveSubsystems As TIMSS.API.ApplicationInfo.IApplicationSubsystems

            oAllSubsystems = TIMSS.API.CachedApplicationData.ApplicationDataCache.SubSystems

            oActiveSubsystems = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.ApplicationInfo, "ApplicationSubsystems")

            For i As Integer = 0 To oAllSubsystems.Count - 1
                If oAllSubsystems(i).ActiveFlag = True AndAlso oAllSubsystems(i).ProductFlag = True Then
                    oActiveSubsystems.Add(oAllSubsystems(i))
                End If
            Next

            Return oActiveSubsystems

        End Function


#End Region
	End Class

End Namespace
