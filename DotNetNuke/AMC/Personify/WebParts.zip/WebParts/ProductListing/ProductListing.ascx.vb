Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects


Imports System.Web

Imports System.Collections.Specialized
Imports System.Text.RegularExpressions

Imports DotNetNuke.Common.Lists
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Security
Imports Personify
Imports TIMSS
Imports TIMSS.API
Imports TIMSS.API.Core
Imports TIMSS.SqlObjects

Imports System.Collections.Generic


Namespace Personify.DNN.Modules.ProductListing

	Public MustInherit Class ProductListing
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm


#Region "Controls"
        Protected WithEvents PLDataPager As WebControls.DataPager
        Protected WithEvents PLDataPagerBottom As WebControls.DataPager
		Protected PLXslTemplate As WebControls.XslTemplate
		Protected WithEvents ItemsPerPageDropDownList As System.Web.UI.WebControls.DropDownList
		Protected WithEvents SortByDropDownList As System.Web.UI.WebControls.DropDownList
		Protected HiddenFieldClass As HiddenField
		Protected HiddenFieldCategory As HiddenField
		Protected HiddenFieldSubcategory As HiddenField
		'Protected WithEvents aMessageControl As WebControls.MessageControl

#End Region

#Region "variables"

        Private _strListRateStructure As String = String.Empty
        Private _strMemberRateStructure As String = String.Empty

#End Region

#Region "Event Handlers"

        Public Products As TIMSS.API.WebInfo.ITmarWebProductViewList

        Public Class aProduct
            Public ProductId As Integer
            Public WebLongDescription As String
            Public WebShortDescription As String
            Public LongName As String
            Public ShortName As String
            Public URLToGo As String
            Public SmallImageFileName As String
            Public Code As String
            Public ParentCode As String
            Public Subsystem As String

            'MTG subsystem properties
            Public StartDate As String
            Public EndDate As String
            Public FacilityState As String
            Public FacilityCity As String
            Public FacilityLabelName As String
            Public Status As String
            Public MaxBadges As Integer

            'INV susbsystem properties
            Public NextInvReceiptDate As String

            'Pricing Properties
            Public AddToCartFlag As Boolean

            Public AllPrices As WebPrices
            Public ListPrices As WebPrices
            Public MemberPrices As WebPrices
            Public YourPrices As WebPrices



        End Class


        Private Function CheckIfPostBackByButton(ByVal strControlName As String, ByVal strWitch As String) As String
            Dim bReturn As String = ""
            For Each Key As String In Request.Form.Keys
                If Key.IndexOf(strControlName) > 0 Then
                    If Key.IndexOf(strWitch) > 0 Then
                        bReturn = Key
                        Exit For
                    End If
                End If
            Next
            Return bReturn
        End Function


        Private Function StripHTML(ByVal objHTML As String) As String
            Try
                Dim strOutput As String
                If Not IsDBNull(objHTML) Then
                    strOutput = objHTML
                    ' create regular expression object
                    Dim objRegExp1 As Regex = New Regex("<(.|\n)+?>", RegexOptions.IgnoreCase)

                    ' replace all HTML tag matches with the empty string
                    strOutput = objRegExp1.Replace(strOutput, "")

                    ' create regular expression object
                    Dim objRegExp2 As Regex = New Regex("&lt;(.|\n)+?&gt;", RegexOptions.IgnoreCase)

                    ' replace all HTML tag matches with the empty string
                    strOutput = objRegExp2.Replace(strOutput, "")
                    ' remove breaks
                    strOutput = Replace(strOutput, ControlChars.Lf, "")
                    strOutput = Replace(strOutput, Chr(13), "")
                    Return strOutput
                Else
                    Return ""
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Function



        Protected Sub SortByDropDownList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
            'GetWebProducts()
            PLDataPager.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)
            PLDataPagerBottom.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)

            LoadDataToXML()
        End Sub

        Protected Sub ItemsPerPageDropDownList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
            'GetWebProducts()
            PLDataPager.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)
            PLDataPagerBottom.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)

            LoadDataToXML()
        End Sub

        Private Sub PLDataPager_Change() Handles PLDataPager.Change
            'PLDataPager.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)
            PLDataPager.DataSourcePaged.CurrentPageIndex = PLDataPager.CurrentPage - 1
            PLDataPagerBottom.CurrentPage = PLDataPager.CurrentPage
            PLDataPagerBottom.DataSourcePaged.CurrentPageIndex = PLDataPager.CurrentPage - 1
            LoadDataToXML()
        End Sub

        Private Sub PLDataPagerBottom_Change() Handles PLDataPagerBottom.Change
            'PLDataPager.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)
            PLDataPagerBottom.DataSourcePaged.CurrentPageIndex = PLDataPagerBottom.CurrentPage - 1
            PLDataPager.CurrentPage = PLDataPagerBottom.CurrentPage
            PLDataPager.DataSourcePaged.CurrentPageIndex = PLDataPagerBottom.CurrentPage - 1
            LoadDataToXML()
        End Sub

        'Private tmpMasterCustomerId As String = String.Empty
        'Private tmpSubCustomerId As Integer = 0
        'Private tmpisLoggedin As Boolean = False
        Private MeetingFull As Boolean = False

        Public Class aRow
            Public row() As aProduct
        End Class
        Private Function IsUserPErsonifyMember() As Boolean

            Dim role As String
            Dim bREturn As Boolean = False
            role = Me.GetUserRole(UserInfo)
            If role = "personifyuser" Or role = "personifyadmin" Then
                Dim oRoleCtrl As New DotNetNuke.Security.Roles.RoleController
                Dim oPersonifyRoles() As String
                oPersonifyRoles = oRoleCtrl.GetRolesByUser(UserId, PortalId)
                If oPersonifyRoles IsNot Nothing AndAlso oPersonifyRoles.Length > 0 Then
                    For Each oPersonifyRole As String In oPersonifyRoles
                        If oPersonifyRole = "PersonifyMember" Then
                            bREturn = True
                        End If
                    Next
                End If
            End If

            Return bREturn
        End Function

        'Private Function GetPackagePrice(ByVal oProd As TIMSS.API.WebInfo.ITmarWebProductView, ByVal RateStructures() As String) As WebPrices


        '    Dim oSelectRequest As TIMSS.DataAccess.SimpleRequest = Nothing
        '    Dim strCalculatedProductIds As New System.Text.StringBuilder
        '    Dim strSpecificProductIds As New System.Text.StringBuilder

        '    Dim oResultSet As TIMSS.Interfaces.IResultSet = Nothing
        '    Dim oDS As DataSet = Nothing
        '    Dim SQLString As New System.Text.StringBuilder
        '    Dim ReferenceDate As Date = TIMSS.Global.App.ServerDateTime

        '    With SQLString
        '        .Append(" Select product_id, component_product_id, rate_method_code, rate_structure, rate_code ")
        '        .Append(" from product_component ")
        '        .AppendFormat(" where product_id = {0} and active_flag = 'Y' ", oProd.ProductId)
        '    End With


        '    oSelectRequest = New TIMSS.DataAccess.SimpleRequest("PIDS", SQLString.ToString)
        '    oResultSet = TIMSS.[Global].App.GetData(oSelectRequest)
        '    oDS = oResultSet.Unpack()

        '    If oDS.Tables.Count > 0 Then
        '        For i As Integer = 0 To oDS.Tables(0).Rows.Count - 1
        '            If String.Compare(oDS.Tables(0).Rows(i).Item("rate_method_code"), "CALCULATED", True) = 0 Then
        '                If strCalculatedProductIds.Length > 0 Then
        '                    strCalculatedProductIds.Append(",")
        '                End If
        '                strCalculatedProductIds.Append(oDS.Tables(0).Rows(i).Item("Product_id"))
        '            Else
        '                If strSpecificProductIds.Length > 0 Then
        '                    strSpecificProductIds.Append(",")
        '                End If
        '                strSpecificProductIds.Append(oDS.Tables(0).Rows(i).Item("Product_id"))
        '            End If
        '        Next
        '    End If

        '    '
        '    Dim oCalcProds As TIMSS.API.WebInfo.ITmarWebProductViewList

        '    If strCalculatedProductIds.Length > 0 Then
        '        oCalcProds = TIMSS.API.CachedApplicationData.ApplicationDataCache.GetProductsWithPriceFromCache(strCalculatedProductIds.ToString.Split(","), RateStructures, Me.PortalCurrencyCode, Me.BaseCurrency.Code)
        '    End If

        '    'Get the price for the specified RS and RC
        '    If strSpecificProductIds.Length > 0 Then

        '        For Each Product As String In strSpecificProductIds.ToString.Split(",")
        '            Dim params(2) As TIMSS.CacheFilterItem

        '            params(0) = New TIMSS.CacheFilterItem("ProductId", Product)
        '            'params(1) = New TIMSS.CacheFilterItem("Type", [Type])
        '            'params(2) = New TIMSS.CacheFilterItem("ActiveFlag", "Y")

        '        Next


        '        '  Return TIMSS.CacheLoader.LoadBOCFromCache(GetType(TIMSS.API.ProductInfo.IProductPricingList), params)

        '    End If

        '    'sum up all the prices, convert currency for specified pids, do not convert for Calculate PID's - the cache functionw ill do the conversion.


        'End Function


        'Private Function ConstructWebPricesObject(ByVal Mode As String, ByVal oProd As TIMSS.API.WebInfo.ITmarWebProductView) As WebPrices
        '    'TODO - get the default list and member rate structures. Rate Codes should not matter.
        '    'TODO - include logic to calculate package prices
        '    'TODO - include logic for schedule based pricing.
        '    Dim oWebPrice As WebPrice
        '    Dim oWebPrices As WebPrices = Nothing

        '    oWebPrices = New WebPrices

        '    oWebPrice = oWebPrices.AddNewWebPrice
        '    oWebPrice.ProductId = oProd.ProductId

        '    Select Case Mode
        '        Case "LIST"
        '            'if package
        '            If oProd.ProductTypeCodeString = "P" Then
        '                'oWebPrice.RateCode = "STD"
        '                'oWebPrice.RateCodeDescr = "Standard"
        '                'oWebPrice.RateStructure = "LIST"
        '                'oWebPrice.RateStructureDescr = "LIST"

        '                oWebPrice.IsDefault = True
        '                'oWebPrice.MaxBadges = oProd.YourPriceMaxBadges
        '                'oWebPrice.Price = 
        '            End If
        '            'oWebPrice.RateCode = "STD"
        '            'oWebPrice.RateCodeDescr = "Standard"
        '            'oWebPrice.RateStructure = "LIST"
        '            'oWebPrice.RateStructureDescr = "LIST"

        '            oWebPrice.IsDefault = True
        '            oWebPrice.MaxBadges = oProd.YourPriceMaxBadges
        '            oWebPrice.Price = oProd.ListPrice
        '            oWebPrice.RateStructure = Me._strListRateStructure


        '        Case "MEMBER"
        '            'oWebPrice.RateCode = "STD"
        '            'oWebPrice.RateCodeDescr = "Standard"
        '            'oWebPrice.RateStructure = "MEMBER"

        '            oWebPrice.IsDefault = True
        '            oWebPrice.MaxBadges = oProd.YourPriceMaxBadges
        '            oWebPrice.Price = oProd.MemberPrice
        '            oWebPrice.RateStructureDescr = Me._strMemberRateStructure

        '        Case "YOURPRICE"
        '            oWebPrice.RateCode = oProd.YourPriceRateCode
        '            'oWebPrice.RateCodeDescr = "test"
        '            oWebPrice.RateStructure = oProd.YourPriceRateStructure
        '            'oWebPrice.RateStructureDescr = "test"

        '            oWebPrice.IsDefault = True
        '            oWebPrice.MaxBadges = oProd.YourPriceMaxBadges
        '            oWebPrice.Price = oProd.YourPrice


        '    End Select
        '    'For Schdeudle bases
        '    'If oProd.scheduleid <> 0 Then




        '    'End If



        '    Return oWebPrices
        '    'TODO: Schedule Pricing

        'End Function

        Private Sub LoadDataToXML()
            Try

                Dim TruncateDescription As Integer = Convert.ToInt32(Settings("Truncate")) ' from settings

                If PLDataPager.DataSourcePaged.Count > 0 Then

                    If (PLDataPager.DataSourcePaged IsNot Nothing AndAlso PLDataPager.DataSourcePaged.Count > 0) Then

                        Dim ie As IEnumerator = PLDataPager.DataSourcePaged.GetEnumerator
                        Dim AllProducts(PLDataPager.DataSourcePaged.Count - 1) As aProduct
                        Dim isAdmin As Boolean = False


                        Dim iIndex As Integer = 0
                        While ie.MoveNext

                            Dim o As TIMSS.API.WebInfo.ITmarWebProductView
                            o = CType(ie.Current, TIMSS.API.WebInfo.ITmarWebProductView)

                            AllProducts(iIndex) = New aProduct
                            AllProducts(iIndex).ProductId = CInt(o.ProductId)

                            AllProducts(iIndex).Subsystem = o.Subsystem
                            'PLRestructure
                            AllProducts(iIndex).AddToCartFlag = o.AddToCartFlag
                            get_clsProductHelper.SetProductWithAllDefaultPrices(o, AllProducts(iIndex).ListPrices, AllProducts(iIndex).MemberPrices, AllProducts(iIndex).YourPrices)
                            'AllProducts(iIndex).ListPrices = get_clsProductHelper.GetProductPricesForListRateStructure(o)
                            'AllProducts(iIndex).MemberPrices = get_clsProductHelper.GetProductPricesForMemberRateStructure(o)
                            'AllProducts(iIndex).YourPrices = get_clsProductHelper.GetProductPricesForCustomer(o)

                            If Not Me.IsPersonifyWebUserLoggedIn Then
                                If UserInfo.UserID <> -1 Then
                                    AllProducts(iIndex).Code = o.ProductCode
                                    AllProducts(iIndex).ParentCode = o.ParentProduct
                                    isAdmin = True
                                End If
                            End If

                            If o.Subsystem = "MTG" Then
                                'PLRestructure - 

                                'Dim ProductDetails As ProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(CInt(o.ProductId), False, False, True, True, False, Nothing, Me.IsPersonifyWebUserLoggedIn, MasterCustomerId, SubCustomerId, True, False, False, True, True)

                                'If ProductDetails IsNot Nothing AndAlso ProductDetails.CustomerPrice IsNot Nothing AndAlso ProductDetails.CustomerPrice.Count > 0 Then
                                '    'PLRestructure - Max Badges will have to come from somewhere else
                                '    AllProducts(iIndex).MaxBadges = ProductDetails.CustomerPrice(0).MaxBadges
                                'End If

                                AllProducts(iIndex).MaxBadges = o.YourPriceMaxBadges


                                AllProducts(iIndex).StartDate = o.MeetingStartDate.ToString("MMMM d, yyyy hh:mmtt")
                                AllProducts(iIndex).EndDate = o.MeetingEndDate.ToString("MMMM d, yyyy hh:mmtt")
                                Dim oFacInfo As FacilityInformation = Nothing
                                If o.FacilityMasterCustomerId IsNot Nothing AndAlso o.FacilityMasterCustomerId.Length > 0 Then

                                    oFacInfo = get_clsProductHelper.GetFacilityInfo(o.FacilityMasterCustomerId, o.FacilitySubCustomerId)
                                End If

                                If oFacInfo IsNot Nothing Then
                                    AllProducts(iIndex).FacilityLabelName = oFacInfo.FacilityName
                                    AllProducts(iIndex).FacilityCity = oFacInfo.City
                                    AllProducts(iIndex).FacilityState = oFacInfo.State
                                End If
                                'If oAddress IsNot Nothing AndAlso oAddress.Count > 0 AndAlso oAddress(0) IsNot Nothing Then
                                '    AllProducts(iIndex).FacilityCity = oAddress(0).City
                                '    AllProducts(iIndex).FacilityState = oAddress(0).State
                                'End If
                                If o.MeetingCapacity > o.MeetingRegistrations Then
                                    AllProducts(iIndex).Status = Localization.GetString("AvailableMessage", LocalResourceFile)
                                End If

                                If o.MeetingCapacity = o.MeetingRegistrations And o.MeetingWaitListCapacity > o.MeetingWaitListRegistrations Then
                                    AllProducts(iIndex).Status = Localization.GetString("WaitlistedMessage", LocalResourceFile)
                                End If

                                'PLRestructure
                                'If o.MeetingCapacity = o.MeetingRegistrations And o.MeetingWaitListCapacity = o.MeetingWaitListRegistrations And (ProductDetails.ProductInfo(0).ProductTypeCodeString = "M" Or ProductDetails.ProductInfo(0).ProductTypeCodeString = "S") Then
                                If o.MeetingCapacity = o.MeetingRegistrations And o.MeetingWaitListCapacity = o.MeetingWaitListRegistrations And (o.ProductTypeCodeString = "M" Or o.ProductTypeCodeString = "S") Then
                                    AllProducts(iIndex).Status = Localization.GetString("FullMessage", LocalResourceFile)
                                End If
                            End If



                            If o.Subsystem = "INV" Then
                                If o.InventoryFlag = False Then
                                    AllProducts(iIndex).Status = Localization.GetString("InStockMessage", LocalResourceFile)
                                Else
                                    If o.TotalAvailableInventory > 0 Then
                                        AllProducts(iIndex).Status = Localization.GetString("InStockMessage", LocalResourceFile)
                                    Else
                                        AllProducts(iIndex).Status = Localization.GetString("OutOfStockMessage", LocalResourceFile)
                                        If o.NextInvReceiptDate.ToString("MMMM d, yyyy") = "01/01/0001" Then
                                            AllProducts(iIndex).NextInvReceiptDate = o.NextInvReceiptDate.ToString("MMMM d, yyyy")
                                        Else
                                            AllProducts(iIndex).NextInvReceiptDate = Nothing
                                        End If

                                    End If
                                End If
                            End If



                            Dim WebShortDescription As String = o.WebShortDescription
                            If WebShortDescription Is Nothing Then
                                WebShortDescription = ""
                            End If
                            If TruncateDescription > 0 AndAlso WebShortDescription.Length > 0 Then
                                WebShortDescription = HtmlUtils.Shorten(StripHTML(WebShortDescription), TruncateDescription, "...")
                            End If
                            AllProducts(iIndex).WebShortDescription = WebShortDescription


                            Dim WebLongDescription As String = o.WebLongDescription
                            If WebLongDescription Is Nothing Then
                                WebLongDescription = ""
                            End If
                            If TruncateDescription > 0 AndAlso WebLongDescription.Length > 0 Then
                                WebLongDescription = HtmlUtils.Shorten(StripHTML(WebLongDescription), TruncateDescription, "...")
                            End If

                            If TruncateDescription < 0 Then
                                WebLongDescription = ""
                            End If

                            AllProducts(iIndex).WebLongDescription = WebShortDescription

                            If Convert.ToInt32(Settings("DisplayImage")) = 1 Then AllProducts(iIndex).SmallImageFileName = o.SmallImageFileName
                            AllProducts(iIndex).LongName = o.LongName
                            AllProducts(iIndex).ShortName = o.ShortName
                            If Settings("DetailUrl") IsNot Nothing AndAlso Convert.ToString(Settings("DetailUrl")).Length > 0 AndAlso Convert.ToInt32(Settings("DetailUrl")) > 0 Then
                                AllProducts(iIndex).URLToGo = NavigateURL(CType(Settings("DetailUrl"), Integer)) + "?ProductId=" + o.ProductId.ToString
                            End If

                            iIndex = iIndex + 1
                        End While



                        Dim RepeatDirection As System.Web.UI.WebControls.RepeatDirection = RepeatDirection.Horizontal   'from settings
                        Dim RepeatColumns As Integer = Convert.ToInt32(Settings("Columns")) ' from settings
                        If Not (RepeatColumns > 0) Then RepeatColumns = 2
                        Dim DisplayMainProduct As Boolean = False    ' from settings
                        If Convert.ToInt32(Settings("MainProduct")) = 1 Then DisplayMainProduct = True


                        Dim MainProduct As New aProduct
                        Dim startindex As Integer = 0
                        If DisplayMainProduct = True Then
                            startindex = 1
                            MainProduct = AllProducts(0)
                        End If


                        Dim rowcount As Integer = Convert.ToInt32((AllProducts.Length - startindex) / RepeatColumns)
                        If ((AllProducts.Length - startindex) / RepeatColumns - rowcount) > 0 Then
                            rowcount = rowcount + 1
                        End If

                        Dim PaginatateAllProducts(rowcount - 1) As aRow

                        For x As Integer = 0 To PaginatateAllProducts.Length - 1
                            PaginatateAllProducts(x) = New aRow
                            Dim row(RepeatColumns - 1) As aProduct
                            For y As Integer = 0 To RepeatColumns - 1
                                row(y) = New aProduct

                                Dim index As Integer
                                If (RepeatDirection = Web.UI.WebControls.RepeatDirection.Horizontal) Then
                                    index = x * RepeatColumns + y + startindex
                                Else
                                    index = y * RepeatColumns + x + startindex
                                End If

                                If index < AllProducts.Length Then
                                    row(y) = AllProducts(index)
                                End If
                            Next
                            PaginatateAllProducts(x).row = row
                        Next

                        Dim templatefile As String = ""
                        Try
                            templatefile = ModulePath + "Templates\" + Settings("Layout").ToString()
                            'templatefile = ModulePath + "Templates\" + "ProductListing.xsl"
                        Catch ex As Exception
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WrongTemplate.Text", LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End Try


                        PLXslTemplate.XSLfile = Server.MapPath(templatefile)
                        If MainProduct IsNot Nothing Then PLXslTemplate.AddObject("MainProduct", MainProduct)
                        If PaginatateAllProducts IsNot Nothing AndAlso PaginatateAllProducts.Length > 0 Then PLXslTemplate.AddObject("", PaginatateAllProducts)

                        PLXslTemplate.AddObject("IsAdmin", isAdmin)
                        PLXslTemplate.AddObject("ModuleId", ModuleId)
                        PLXslTemplate.AddObject("RepeatColumns", RepeatColumns)
                        Dim ProductImageURL As String = Convert.ToString(Me.GetDNNSiteSettings.ProductImageURL)

                        PLXslTemplate.AddObject("ProductImageURL", ProductImageURL)

                        PLXslTemplate.Display()

                        Dim CanPurchaseMemberOnlyProducts As Boolean = IsUserPErsonifyMember()

                        'Change this to read from the personify member role


                        'add to cart button for member only products ?
                        'If UserInfo.Profile.ProfileProperties("CanPurchaseMemberOnlyProducts") IsNot Nothing AndAlso Not String.IsNullOrEmpty(UserInfo.Profile.ProfileProperties("CanPurchaseMemberOnlyProducts").ToString) Then
                        '	If Convert.ToBoolean(UserInfo.Profile.GetPropertyValue("CanPurchaseMemberOnlyProducts")) = True Then
                        '		CanPurchaseMemberOnlyProducts = True
                        '	End If
                        'End If

                        If AllProducts IsNot Nothing AndAlso AllProducts.Length > 0 Then


                            For x As Integer = 0 To AllProducts.Length - 1
                                If AllProducts(x) IsNot Nothing AndAlso AllProducts(x).ProductId > 0 Then

                                    'Dim aProductDetails As ProductDetails
                                    '  aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(AllProducts(x).ProductId, False, False, True, True, , , Me.IsPersonifyWebUserLoggedIn, MasterCustomerId, SubCustomerId, True, True)

                                    Dim aPricingControl As New WebControls.PricingControl

                                    aPricingControl.ID = "PricingControl" + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                                    aPricingControl.PortalID = PortalId
                                    aPricingControl.IsMember = CanPurchaseMemberOnlyProducts
                                    'ANMC
                                    aPricingControl.PortalCurrency = PortalCurrency
                                    'TODO: All Prices will be needed
                                    'PLRestructure
                                    aPricingControl.AllPrices = AllProducts(x).AllPrices
                                    aPricingControl.ListPrices = AllProducts(x).ListPrices
                                    aPricingControl.MemberPrices = AllProducts(x).MemberPrices
                                    aPricingControl.YourPrices = AllProducts(x).YourPrices

                                    aPricingControl.MemberPriceLabel = Localization.GetString("MemberPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.ListPriceLabel = Localization.GetString("ListPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.YourPriceLabel = Localization.GetString("YourPriceLabel.Text", LocalResourceFile)
                                    aPricingControl.HideSchedulePriceLabelMessage = Localization.GetString("HideSchedulePriceLabelMessage.Text", LocalResourceFile) 'CP: Added HideSchedulePriceLabelMessage

                                    If Settings("DisplayRateCodeSettingsKey_" + AllProducts(x).Subsystem.ToUpper) IsNot Nothing Then
                                        aPricingControl.ShowRateCode = True
                                    End If

                                    If Me.IsPersonifyWebUserLoggedIn = True Then
                                        aPricingControl.IsMember = True
                                    Else
                                        aPricingControl.IsMember = False
                                    End If

                                    Dim tempPlaceHolder As New PlaceHolder

                                    tempPlaceHolder = CType(Me.FindControl("PricingPlaceHolder" + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString), PlaceHolder)
                                    If (tempPlaceHolder IsNot Nothing) Then
                                        tempPlaceHolder.Controls.Add(aPricingControl)
                                    End If

                                    Dim aAddToCartControl As New WebControls.AddToCartControl

                                    aAddToCartControl.ID = "AddToCartControl" + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString

                                    aAddToCartControl.Visible = False 'from settings
                                    MeetingFull = False
                                    If AllProducts(x).Status = Localization.GetString("FullMessage", LocalResourceFile) Then
                                        MeetingFull = True
                                    End If
                                    If Not MeetingFull Then


                                        If _
                                        Convert.ToInt32(Settings("AddToCart")) = 1 _
                                        Or Convert.ToInt32(Settings("AddToWishList")) = 1 _
                                        Or Convert.ToInt32(Settings("BuyForGroup")) = 1 _
                                        Then

                                            aAddToCartControl.Visible = True
                                            '  3246-7598766   
                                            aAddToCartControl.VisibleAddToCart = Convert.ToInt32(Settings("AddToCart")) = 1 AndAlso AllProducts(x).AddToCartFlag = True

                                            If Convert.ToInt32(Settings("AddToWishList")) = 1 Then
                                                aAddToCartControl.VisibleWishList = True
                                            Else
                                                aAddToCartControl.VisibleWishList = False
                                            End If

                                            aAddToCartControl.VisibleBuyForGroup = False
                                            If Not MeetingFull Then

                                                If Convert.ToInt32(Settings("BuyForGroup")) = 1 Then
                                                    'amr
                                                    If (get_clsAffiliateManagement.IsGroupPurchaseEnabledForSegmentController(PortalId, MasterCustomerId, SubCustomerId) = True) Then
                                                        aAddToCartControl.VisibleBuyForGroup = True
                                                    End If
                                                End If

                                                If Settings("DefaultQuantity") IsNot Nothing Then
                                                    aAddToCartControl.Quantity = CType(Settings("DefaultQuantity"), Integer)
                                                Else
                                                    aAddToCartControl.Quantity = 1
                                                End If
                                                Select Case AllProducts(x).Subsystem
                                                    Case "INV", "MISC", "SUB"
                                                        aAddToCartControl.VisibleQuantity = True
                                                    Case "MTG"
                                                        If AllProducts(x).MaxBadges >= 1 Then
                                                            aAddToCartControl.VisibleQuantity = True
                                                        Else
                                                            aAddToCartControl.VisibleQuantity = False
                                                        End If
                                                    Case Else
                                                        aAddToCartControl.VisibleQuantity = False
                                                End Select


                                                aAddToCartControl.ProductId = AllProducts(x).ProductId
                                                aAddToCartControl.Text = Localization.GetString("AddToCart.Text", LocalResourceFile)
                                                aAddToCartControl.WishListText = Localization.GetString("AddToWishList.Text", LocalResourceFile)
                                                aAddToCartControl.BuyForGroupText = Localization.GetString("BuyForGroup.Text", LocalResourceFile)
                                                aAddToCartControl.ButtonCss = "btna"

                                                aAddToCartControl.ButtonMode = WebControls.AddToCartControl.EnumButtonMode.Button
                                                '3246-5774803
                                                aAddToCartControl.ImageURL = GetAddToCartImageURL() 'ModulePath & "images/btn_addtocart.gif"
                                                aAddToCartControl.WishListImageURL = GetWishListImageURL() 'ModulePath & "images/btn_wishlist.gif"
                                                aAddToCartControl.BuyForGroupImageURL = GetBuyForGroupImageURL() 'ModulePath & "images/btn_buyforgroup.gif"
                                                'end 3246-5774803

                                                'AddHandler aAddToCartControl.ButtonClick, AddressOf AddToCartControl_ButtonClick
                                                'AddHandler aAddToCartControl.WishListButtonClick, AddressOf AddToWishListControl_ButtonClick

                                                'Virtual product change
                                                If Not AllProducts(x).Subsystem = "ECD" Then
                                                    tempPlaceHolder = CType(Me.FindControl("AddToCartPlaceHolder" + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString), PlaceHolder)
                                                    If (tempPlaceHolder IsNot Nothing) Then
                                                        tempPlaceHolder.Controls.Add(aAddToCartControl)
                                                    End If
                                                End If
                                            End If
                                        End If

                                    End If
                                End If

                            Next

                        End If
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Function AddToCart( _
  ByVal MasterCustomerId As String, _
  ByVal SubCustomerId As Integer, _
   ByVal ProductID As Integer, _
   ByVal SubProductId As Integer, _
   ByVal ProductDetails _
   As ProductDetails, _
   ByVal Quantity As Integer, _
   ByVal RateCode As String, _
   ByVal RateStructure As String, _
   ByVal Price As Decimal, _
  ByVal isWishList As Boolean, _
  ByVal HasValidScheduledPrice As Boolean _
  ) As Integer
            'ByVal RateStructure As String, _			'ByVal RateCode As String _
            Try

                Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                Dim oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
                With oCartInfo
                    .Subsystem = ProductDetails.ProductInfo(0).Subsystem
                    .ProductType = ProductDetails.ProductInfo(0).ProductTypeCodeString
                    .RateStructure = RateStructure
                    .RateCode = RateCode

                    .MasterCustomerId = MasterCustomerId 'ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                    .SubCustomerId = SubCustomerId '0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)

                    .LongName = ProductDetails.ProductInfo(0).LongName
                    .ShortName = ProductDetails.ProductInfo(0).ShortName
                    .Price = Price
                    'Fixed Ticket #3246-8157039 : set the HasValidScheduledPrice property
                    .HasValidScheduledPrice = HasValidScheduledPrice
                    .Quantity = Quantity
                    .ProductId = ProductID
                    .SubProductId = SubProductId 'not 0
                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .MaxBadges = 0

                    'AN FIX ---------------
                    .MaximumTickets = ProductDetails.ProductInfo(0).MaximumTickets
                    '--------------------
                    .IsWishList = isWishList
                    .ShipMasterCustomerId = Nothing
                    .ShipSubCustomerId = 0
                    If ProductDetails.Components.Count > 0 Then
                        .ComponentExists = True
                    Else
                        .ComponentExists = False
                    End If

                    'AN CUNA FIX + 3246-7611874  
                    .MaxBadges = GetMaxBadges(ProductDetails, .RelatedCartItemId, .RateStructure, .RateCode)

                    

                    'If ProductDetails.ListPrices IsNot Nothing Then
                    '    If ProductDetails.ListPrices.Count > 0 Then
                    '        For i As Integer = 0 To ProductDetails.ListPrices.Count - 1
                    '            If ProductDetails.ListPrices(i).RateStructure = .RateStructure And ProductDetails.ListPrices(i).RateCode = .RateCode Then
                    '                .MaxBadges = ProductDetails.ListPrices(i).MaxBadges
                    '            End If
                    '        Next
                    '    End If
                    'End If

                    'If ProductDetails.MemberPrices IsNot Nothing Then
                    '    If ProductDetails.MemberPrices.Count > 0 Then
                    '        For i As Integer = 0 To ProductDetails.MemberPrices.Count - 1
                    '            If ProductDetails.MemberPrices(i).RateStructure = .RateStructure And ProductDetails.MemberPrices(i).RateCode = .RateCode Then
                    '                .MaxBadges = ProductDetails.MemberPrices(i).MaxBadges
                    '            End If
                    '        Next
                    '    End If
                    'End If

                End With
                Dim CartItemId As Integer = oCartController.AddToCart(oCartInfo)
                '3246-7459082  - First Badge Info Should Default1
                If oCartInfo.MaxBadges > 0 AndAlso Me.IsPersonifyWebUserLoggedIn Then
                    Dim odtDefaultBAdge As DefaultBadgeInfo = GetDefaultBadgeInformation()
                    If odtDefaultBAdge IsNot Nothing Then
                        oCartController.AddUpdateBadge(CartItemId, 1, "SELF", odtDefaultBAdge.FirstName, odtDefaultBAdge.LabelName, odtDefaultBAdge.CompanyName, odtDefaultBAdge.City, odtDefaultBAdge.State, odtDefaultBAdge.PostalCode)
                    End If

                End If


                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If
                Return CartItemId
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Function
        '3246-7459082  - First Badge Info Should Default1
        Private Class DefaultBadgeInfo

            Public FirstName As String
            Public LastName As String
            Public LabelName As String
            Public CompanyName As String
            Public City As String
            Public State As String
            Public PostalCode As String

        End Class
        Private Function GetDefaultBadgeInformation() As DefaultBadgeInfo

            Dim RetDefaultBadgeInfo As DefaultBadgeInfo

            ' Dim abc As TIMSS.API.CustomerInfo.ICustomerPrimaryInfoViewList

            Dim searchObj As New TIMSS.API.Core.SearchObject(OrganizationId, OrganizationUnitId)
            searchObj.Target = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "CustomerPrimaryInfoViewList")
            searchObj.EnforceLimits = False

            Dim oParm As TIMSS.API.Core.SearchProperty

            oParm = New TIMSS.API.Core.SearchProperty("MasterCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = MasterCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("SubCustomerId")
            oParm.UseInQuery = True
            oParm.ShowInResults = False
            oParm.Value = SubCustomerId
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("FirstName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("LastName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("LabelName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("CompanyName")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("City")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            oParm = New TIMSS.API.Core.SearchProperty("State")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)


            oParm = New TIMSS.API.Core.SearchProperty("PostalCode")
            oParm.UseInQuery = False
            oParm.ShowInResults = True
            searchObj.Parameters.Add(oParm)

            searchObj.Search()

            If searchObj.Results.Table IsNot Nothing AndAlso searchObj.Results.Table.Rows.Count > 0 Then
                RetDefaultBadgeInfo = New DefaultBadgeInfo
                With RetDefaultBadgeInfo


                    .FirstName = IIf(searchObj.Results.Table.Rows(0)("FirstName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("FirstName"))

                    .LastName = IIf(searchObj.Results.Table.Rows(0)("LastName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("LastName"))
                    .LabelName = IIf(searchObj.Results.Table.Rows(0)("LabelName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("LabelName"))
                    .CompanyName = IIf(searchObj.Results.Table.Rows(0)("CompanyName") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("CompanyName"))
                    .City = IIf(searchObj.Results.Table.Rows(0)("City") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("City"))
                    .State = IIf(searchObj.Results.Table.Rows(0)("State") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("State"))
                    .PostalCode = IIf(searchObj.Results.Table.Rows(0)("PostalCode") Is System.DBNull.Value, "", searchObj.Results.Table.Rows(0)("PostalCode"))
                End With

                Return RetDefaultBadgeInfo
            Else
                Return Nothing
            End If



        End Function

        'AN CUNA FIX
        Private Function GetMaxBadges(ByVal pProductDetails As ProductDetails, ByVal pRelatedCartItemId As Integer, ByVal pRateStructure As String, ByVal pRateCode As String) As Integer

            Dim intMaxBadges As Integer = 0
            Dim bRateFound As Boolean = False
            If pRelatedCartItemId <> 0 Then
                intMaxBadges = 0
            Else

                'the badge information should come from teh customer price. 3246-7611874  
                If pProductDetails.CustomerPrice IsNot Nothing AndAlso pProductDetails.CustomerPrice.Count > 0 Then
                    For i As Integer = 0 To pProductDetails.CustomerPrice.Count - 1
                        If pProductDetails.CustomerPrice(i).RateStructure = pRateStructure And pProductDetails.CustomerPrice(i).RateCode = pRateCode Then
                            intMaxBadges = pProductDetails.CustomerPrice(i).MaxBadges
                            bRateFound = True
                        End If
                    Next
                End If


                'if the user is not logged in, then go for the list price.
                If Not bRateFound AndAlso pProductDetails.ListPrices IsNot Nothing AndAlso pProductDetails.ListPrices.Count > 0 Then
                    For i As Integer = 0 To pProductDetails.ListPrices.Count - 1
                        If pProductDetails.ListPrices(i).RateStructure = pRateStructure And pProductDetails.ListPrices(i).RateCode = pRateCode Then
                            intMaxBadges = pProductDetails.ListPrices(i).MaxBadges
                            bRateFound = True
                        End If
                    Next

                End If

                If Not bRateFound AndAlso pProductDetails.MemberPrices IsNot Nothing AndAlso pProductDetails.MemberPrices.Count > 0 Then

                    For i As Integer = 0 To pProductDetails.MemberPrices.Count - 1
                        If pProductDetails.MemberPrices(i).RateStructure = pRateStructure And pProductDetails.MemberPrices(i).RateCode = pRateCode Then
                            intMaxBadges = pProductDetails.MemberPrices(i).MaxBadges
                            bRateFound = True
                        End If
                    Next
                End If

            End If


            Return intMaxBadges

        End Function

        Private Sub AddComponentsToCart( _
 ByVal MasterCustomerId As String, _
 ByVal SubCustomerId As Integer, _
 ByVal CartItemId As Integer, _
  ByVal ProductID As Integer, _
  ByVal ProductComponentDetails _
  As ProductComponent, _
 ByVal isWishList As Boolean _
 )
            'ByVal RateStructure As String, _			'ByVal RateCode As String _
            Try

                Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                Dim oCartComponentInfo As New ShoppingCartManager.Business.ShoppingCartComponentInfo
                With oCartComponentInfo

                    .MasterCustomerId = MasterCustomerId 'ApplicationManager.Customer.GetAnonymousUserId(CType(UserInfo.Profile.GetPropertyValue("MasterCustomerId"), String))
                    .SubCustomerId = SubCustomerId '0 'CType(UserInfo.Profile.ProfileProperties("SubCustomerId"), Integer)
                    .CartItemId = CartItemId
                    .LongName = ProductComponentDetails.LongName
                    .ShortName = ProductComponentDetails.ShortName
                    .ProductId = ProductID
                    .ComponentProductId = ProductComponentDetails.ProductId
                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .IsWishList = isWishList
                    .PortalId = PortalId

                End With
                oCartController.AddShoppingCartComponents(oCartComponentInfo)
                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub AddToCommonControl_ButtonClick( _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
         ByVal tempAddToCartControl As WebControls.AddToCartControl, _
        ByVal e As System.EventArgs, _
        ByVal isWishList As Boolean, Optional ByVal IsGUID As Boolean = False _
        )

            Try
                Dim bFetchYourPrice As Boolean

                Dim tempPricingControl As WebControls.PricingControl

                If IsGUID Then
                    bFetchYourPrice = False
                Else
                    bFetchYourPrice = Me.IsPersonifyWebUserLoggedIn
                End If


                tempPricingControl = CType(Me.FindControl("PricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString), WebControls.PricingControl)

                Dim aProductDetails As ProductDetails
                aProductDetails = get_clsProductHelper.GetAllDetailsForAProduct(Convert.ToInt32(tempAddToCartControl.ProductId), False, False, True, True, False, , bFetchYourPrice, MasterCustomerId, SubCustomerId, True, True)

                Dim aPrice As Decimal = Convert.ToDecimal(Request("PricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_price"))
                Dim aRateCode As String = Convert.ToString(Request("PricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_rc"))
                Dim aRateStructure As String = Convert.ToString(Request("PricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_rs"))
                'Fixed Ticket #3246-8157039 : get the HasValidScheduledPrice flag value from pricing control
                Dim HasValidScheduledPrice As Boolean = Convert.ToBoolean(Request("PricingControl" + ModuleId.ToString + "_" + tempAddToCartControl.ProductId.ToString + "_hasValidScheduledPrice"))

                ' add upsell product
                Dim q As Integer = Convert.ToInt32(Request(tempAddToCartControl.txtQuantity.UniqueID))
                'Fixed Ticket #3246-8157039: passed HasValidScheduledPrice to AddToCart method
                Dim CartItemId As Integer = AddToCart(MasterCustomerId, SubCustomerId, CType(tempAddToCartControl.ProductId, Integer), 0, aProductDetails, q, aRateCode, aRateStructure, aPrice, isWishList, HasValidScheduledPrice)
                'Add components to shopping cart
                If aProductDetails.Components.Count > 0 Then
                    For i As Integer = 0 To aProductDetails.Components.Count - 1
                        If (aProductDetails.Components(i) IsNot Nothing) Then
                            AddComponentsToCart(MasterCustomerId, SubCustomerId, CartItemId, CType(tempAddToCartControl.ProductId, Integer), aProductDetails.Components(i), isWishList)
                        End If
                    Next
                End If
                If isWishList = False Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Dim _goScroll As String = "<script language='javascript'>setTimeout('window.scrollTo(0, 0)',1);</script>"
                    If Not Page.ClientScript.IsStartupScriptRegistered("goScroll") Then
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "goScroll", _goScroll)

                    End If
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("WishListMessageControl.Text", LocalResourceFile).Replace("$quantity$", q.ToString), Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Dim _goScroll As String = "<script language='javascript'>setTimeout('window.scrollTo(0, 0)',1);</script>"
                    If Not Page.ClientScript.IsStartupScriptRegistered("goScroll") Then
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "goScroll", _goScroll)

                    End If
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub AddToCartControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)

            AddToCommonControl_ButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, e, False)
        End Sub

        Private Sub AddToWishListControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
            AddToCommonControl_ButtonClick(MasterCustomerId, SubCustomerId, tempAddToCartControl, e, True)
        End Sub

        Private Sub BuyforGroupControl_ButtonClick(ByVal tempAddToCartControl As WebControls.AddToCartControl, ByVal e As System.EventArgs)
            Dim guid As String = Convert.ToString(AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId))
            If guid Is Nothing Then
                guid = System.Guid.NewGuid().ToString("N").ToUpper()
                If guid.Length > 20 Then
                    guid = guid.Substring(1, 20)
                End If
                AffiliateManagementSessionHelper.SetGroupPurchaseInfo(PortalId, guid)
            End If

            AddToCommonControl_ButtonClick(guid, 0, tempAddToCartControl, e, False, True)

            Dim intTabId As Integer = AffiliateManagementSessionHelper.GetCurrentSegmentGroupPurchaseActionURL(PortalId)

            If intTabId = 0 Then
                Response.Redirect(NavigateURL(CType(Settings("BuyForGroupUrl"), Integer)), True)
            Else
                Response.Redirect(NavigateURL(intTabId), True)
            End If

        End Sub

        Private Sub LoadDropDownListSetting(ByVal aDropDownList As DropDownList, ByVal aSettingString As String, ByVal aSettingList As String)

            If Not aDropDownList.Items.Count > 0 Then

                Dim YesNo As String = Localization.GetString(aSettingList, Me.LocalResourceFile + "Edit")
                Dim aYesNo() As String = YesNo.Split(New Char() {"|"c})

                Dim aSetting As String = Convert.ToString(Settings(aSettingString))

                For i As Integer = 0 To Convert.ToInt32(aYesNo.Length / 2) - 1
                    aDropDownList.Items.Add(New System.Web.UI.WebControls.ListItem(aYesNo(2 * i + 1), aYesNo(2 * i)))
                    If aDropDownList.Items(aDropDownList.Items.Count - 1).Value = aSetting Then
                        aDropDownList.SelectedValue = aSetting
                    End If
                Next
            End If


        End Sub

        Private Sub RedirectOnChange()
            Dim url As String = NavigateURL()

            If url.IndexOf("?") > 0 Then
                url += "&"
            Else
                url += "?"
            End If

            If HiddenFieldClass.Value IsNot Nothing AndAlso HiddenFieldClass.Value.Length > 0 Then
                url += "CLASS" + HiddenFieldClass.Value + "&"
            End If

            If HiddenFieldCategory.Value IsNot Nothing AndAlso HiddenFieldCategory.Value.Length > 0 Then
                url += "CATEGORY" + HiddenFieldCategory.Value + "&"
            End If

            If HiddenFieldSubcategory.Value IsNot Nothing AndAlso HiddenFieldSubcategory.Value.Length > 0 Then
                url += "SUBCATEGORY" + HiddenFieldSubcategory.Value + "&"
            End If

            url += "SORTBY=" + SortByDropDownList.SelectedValue + "&"
            url += "PAGESIZE=" + ItemsPerPageDropDownList.SelectedValue

            Response.Redirect(url, True)
        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                'Fixed Ticket #3246-8277698
                If IsPostBack Then
                    GetRefreshState()
                End If

                get_clsProductHelper.GetListAndMemberRateStructures(_strListRateStructure, _strMemberRateStructure)

                If Settings("Layout") IsNot Nothing Then

                    ItemsPerPageDropDownList.AutoPostBack = True

                    If ItemsPerPageDropDownList.Items.Count = 0 Then ' from settings
                        LoadDropDownListSetting(ItemsPerPageDropDownList, "ItemsPerPage", "ItemsPerPage.List")
                    End If
                    AddHandler ItemsPerPageDropDownList.SelectedIndexChanged, AddressOf ItemsPerPageDropDownList_SelectedIndexChanged

                    SortByDropDownList.AutoPostBack = True

                    If SortByDropDownList.Items.Count = 0 Then ' from settings
                        LoadDropDownListSetting(SortByDropDownList, "Sorting", "Sorting.List")
                    End If
                    AddHandler SortByDropDownList.SelectedIndexChanged, AddressOf SortByDropDownList_SelectedIndexChanged


                    If Not IsPostBack Then

                        Dim pclass As String = Request("CLASS")
                        If pclass IsNot Nothing AndAlso pclass.Length > 0 Then
                            HiddenFieldClass.Value = pclass
                        End If

                        Dim pcategory As String = Request("CATEGORY")
                        If pcategory IsNot Nothing AndAlso pcategory.Length > 0 Then
                            HiddenFieldCategory.Value = pcategory
                        End If

                        Dim psubcategory As String = Request("SUBCATEGORY")
                        If psubcategory IsNot Nothing AndAlso psubcategory.Length > 0 Then
                            HiddenFieldSubcategory.Value = psubcategory
                        End If

                        Dim SORTBY As String = Request("SORTBY")
                        If SORTBY IsNot Nothing AndAlso SORTBY.Length > 0 Then
                            SortByDropDownList.SelectedValue = SORTBY
                        End If

                        Dim PAGESIZE As String = Request("PAGESIZE")
                        If PAGESIZE IsNot Nothing AndAlso PAGESIZE.Length > 0 Then
                            ItemsPerPageDropDownList.SelectedValue = PAGESIZE
                        End If

                    End If

                    Dim loadxml As Boolean = True
                    If Not Request.Params("__EVENTTARGET") Is Nothing Then
                        If Request.Params("__EVENTTARGET").IndexOf("PLDataPager") >= 0 Then
                            'loadxml later in the event
                            loadxml = False
                        End If
                        If Request.Params("__EVENTTARGET").IndexOf("ItemsPerPageDropDownList") >= 0 Then
                            'loadxml later in the event
                            loadxml = False
                            RedirectOnChange()

                        End If
                        If Request.Params("__EVENTTARGET").IndexOf("SortByDropDownList") >= 0 Then
                            'loadxml later in the event
                            loadxml = False
                            RedirectOnChange()
                        End If

                    End If


                    Dim SortByPropertyName As String = Nothing
                    'Dim SortDirection As System.ComponentModel.ListSortDirection = Nothing
                    If SortByDropDownList.SelectedIndex >= 0 Then
                        SortByPropertyName = SortByDropDownList.SelectedValue
                    End If

                    Dim Products As TIMSS.API.WebInfo.ITmarWebProductViewList = Nothing

                    Dim listingtype As Integer = Convert.ToInt32(Settings("Attributes"))
                    Dim Featured As Boolean = False 'from settings
                    Dim Promotional As Boolean = False 'from settings
                    If listingtype = 1 Or listingtype = 3 Then Featured = True
                    If listingtype = 2 Or listingtype = 3 Then Promotional = True


                    Dim sproductids As String = Convert.ToString(Settings("ProductIDs"))
                    Dim ProductIDs() As String = Nothing 'from settings

                    If sproductids IsNot Nothing AndAlso sproductids.Length > 0 Then
                        ProductIDs = sproductids.Split(New Char() {","c})


                        'randomize

                        If Settings("Randomize") IsNot Nothing AndAlso Convert.ToBoolean(Settings("Randomize")) = True Then
                            If Not IsPostBack Then

                                Randomize()
                                Dim pick As Integer = Convert.ToInt32((ProductIDs.Length - 1) * Rnd())

                                Dim ProductIDs2(0) As String
                                ProductIDs2(0) = ProductIDs(pick)
                                ProductIDs = ProductIDs2
                                Session("ProductIDs") = ProductIDs
                            Else
                                ProductIDs = CType(Session("ProductIDs"), String())
                            End If

                            ItemsPerPageDropDownList.Visible = False
                            SortByDropDownList.Visible = False
                        End If
                    End If

                    Dim MaximumRows As Integer = Convert.ToInt32(Settings("MaxProduct")) 'from settings

                    Dim MembersOnlyFiltering As MembersOnlyFilter
                    Select Case Convert.ToInt32(Settings("MembersOnly"))
                        Case 0
                            MembersOnlyFiltering = MembersOnlyFilter.No
                        Case 1
                            MembersOnlyFiltering = MembersOnlyFilter.Yes
                        Case 2
                            MembersOnlyFiltering = MembersOnlyFilter.Both
                    End Select

                    Dim SubSystem() As String = Nothing
                    If HiddenFieldClass.Value IsNot Nothing And HiddenFieldClass.Value.Length > 0 Then
                        Dim aSubSystem(0) As String
                        aSubSystem(0) = HiddenFieldClass.Value
                        SubSystem = aSubSystem
                    Else
                        If Settings("Subsystens") IsNot Nothing AndAlso Convert.ToString(Settings("Subsystens")).Length > 0 Then
                            Dim ss As String = Convert.ToString(Settings("Subsystens"))
                            SubSystem = ss.Split(New Char() {"|"c})
                        End If
                    End If

                    If HiddenFieldCategory.Value IsNot Nothing And HiddenFieldCategory.Value.Length > 0 Then
                        'if category
                        If HiddenFieldSubcategory.Value IsNot Nothing And HiddenFieldSubcategory.Value.Length < 1 Then
                            HiddenFieldSubcategory.Value = Nothing
                        End If
                        ' Products = get_clsProductHelper.GetProductListing(HiddenFieldCategory.Value, HiddenFieldSubcategory.Value, MaximumRows, SortByPropertyName, , MembersOnlyFiltering)
                        'PLRestructure --- get product id's
                        'TODO - Sorting
                        ProductIDs = get_clsProductHelper.GetProductListing_KeysOnly(HiddenFieldCategory.Value, HiddenFieldSubcategory.Value)


                    ElseIf HiddenFieldClass.Value IsNot Nothing And HiddenFieldClass.Value.Length > 0 Then
                        'if class
                        'Products = get_clsProductHelper.GetProductListing(HiddenFieldClass.Value, MaximumRows, SortByPropertyName, , MembersOnlyFiltering)
                        'TODO - Sorting
                        ProductIDs = get_clsProductHelper.GetProductListing_KeysOnly(HiddenFieldClass.Value)
                    Else
                        'rest of the cases
                        'Products = get_clsProductHelper.GetProductListing(SubSystem, Featured, Promotional, ProductIDs, MaximumRows, SortByPropertyName, , MembersOnlyFiltering)

                        If sproductids.Length > 0 Then
                            ProductIDs = sproductids.Split(",")
                        Else
                            Dim strSubsystems As String = String.Empty
                            If SubSystem IsNot Nothing AndAlso SubSystem.Length > 0 Then
                                strSubsystems = String.Join(",", SubSystem)
                            End If
                            ProductIDs = get_clsProductHelper.GetProductListing_KeysOnly(strSubsystems, Featured, Promotional, MembersOnlyFiltering, MaximumRows)
                        End If
                                             
                    End If
                    'PLRestructure --- test code
                    'Dim strPIDs As String()
                    'strPIDs = get_clsProductHelper.GetProductListing_KeysOnly("INV", False, False, 100)   
                    If ProductIDs IsNot Nothing AndAlso ProductIDs.Length > 0 Then
                        Products = TIMSS.API.CachedApplicationData.ApplicationDataCache.GetWebEnabledProductsWithPriceFromCache(ProductIDs, get_clsProductHelper.GetBestQualifiedRateStructureForLoginUserArray(), Me.PortalCurrencyCode, Me.BaseCurrency.Code, get_clsProductHelper.DefaultListRateStructure, get_clsProductHelper.DefaultMemberRateStructure)
                    End If

                    'if randomize

                    If Products IsNot Nothing AndAlso Products.Count > 0 Then

                        PLDataPager.Visible = True
                        PLDataPager.ShowFirstLast = True

                        PLDataPager.PagingMode = WebControls.PagingModeType.PostBack
                        PLDataPager.PageSize = 10 'from settings
                        If Convert.ToInt32(Settings("ItemsPerPage")) > 0 Then PLDataPager.PageSize = Convert.ToInt32(Settings("ItemsPerPage"))

                        If ItemsPerPageDropDownList.SelectedIndex >= 0 Then
                            PLDataPager.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)
                        End If
                        PLDataPager.DataSourcePaged.CurrentPageIndex = PLDataPager.CurrentPage - 1

                        PLDataPager.DataSource = Products
                        'PLDataPager.DataSource = get_clsProductHelper.GetProductListing_KeysOnly("INV", False, False, 100)
                        PLDataPager.DataBind()

                        PLDataPagerBottom.Visible = True
                        PLDataPagerBottom.ShowFirstLast = True

                        PLDataPagerBottom.PagingMode = WebControls.PagingModeType.PostBack
                        PLDataPagerBottom.PageSize = 10 'from settings
                        If Convert.ToInt32(Settings("ItemsPerPage")) > 0 Then PLDataPagerBottom.PageSize = Convert.ToInt32(Settings("ItemsPerPage"))

                        If ItemsPerPageDropDownList.SelectedIndex >= 0 Then
                            PLDataPagerBottom.PageSize = Convert.ToInt32(ItemsPerPageDropDownList.SelectedValue)
                        End If
                        PLDataPagerBottom.DataSourcePaged.CurrentPageIndex = PLDataPagerBottom.CurrentPage - 1

                        PLDataPagerBottom.DataSource = Products
                        PLDataPagerBottom.DataBind()

                        'aici
                        If Products.Count > PLDataPager.PageSize Then
                            ItemsPerPageDropDownList.Visible = True
                            SortByDropDownList.Visible = True
                        Else
                            ItemsPerPageDropDownList.Visible = False
                            SortByDropDownList.Visible = False
                        End If


                        If loadxml = True Then
                            LoadDataToXML()
                        End If

                    End If

                Else

                    'aMessageControl.ShowMessage(Localization.GetString("NoLayoutSelected.Text", LocalResourceFile), WebControls.MessageControl.TIMMSMessageType.RedError)
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If


                Dim PressedButton As String = CheckIfPostBackByButton("AddToCartControl" + ModuleId.ToString, "Add_To_Cart") ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                'Fixed Ticket:3246-8277698
                If Not IsPageRefreshed Then
                    If PressedButton.Length > 0 Then
                        PressedButton = PressedButton.Replace("$", ":")
                        PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                        Dim aAddToCartControl As New WebControls.AddToCartControl
                        aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                        AddToCartControl_ButtonClick(aAddToCartControl, Nothing)

                    Else
                        PressedButton = CheckIfPostBackByButton("AddToCartControl" + ModuleId.ToString, "Add_To_Wish_List")  ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                        'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                        If PressedButton.Length > 0 Then
                            PressedButton = PressedButton.Replace("$", ":")
                            PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                            Dim aAddToCartControl As New WebControls.AddToCartControl
                            aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                            AddToWishListControl_ButtonClick(aAddToCartControl, Nothing)
                        Else
                            PressedButton = CheckIfPostBackByButton("AddToCartControl" + ModuleId.ToString, "Buy_For_Group")     ' + ModuleId.ToString + "_" + AllProducts(x).ProductId.ToString
                            'dnn:ctr384:ProductListing:AddToCartControl384_26:txtQuantity
                            If PressedButton.Length > 0 Then
                                PressedButton = PressedButton.Replace("$", ":")
                                PressedButton = PressedButton.Split(New Char() {":"c})(PressedButton.Split(New Char() {":"c}).Length - 2)
                                Dim aAddToCartControl As New WebControls.AddToCartControl
                                aAddToCartControl = CType(Me.FindControl(PressedButton), WebControls.AddToCartControl)
                                BuyforGroupControl_ButtonClick(aAddToCartControl, Nothing)
                            End If

                        End If
                    End If
                End If
                'Fixed Ticket:#3246-8277698
                SaveRefreshState()
            Catch ex As System.Threading.ThreadAbortException

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region "Image Functions"
        '3246-5774803       
        Private Function GetAddToCartImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_addtocart.gif")
        End Function
        Private Function GetWishListImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_wishlist.gif")
        End Function
        Private Function GetBuyForGroupImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/btn_buyforgroup.gif")
        End Function
        'END 3246-5774803
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            
            InitializeComponent()
        End Sub

#End Region

        

    End Class

End Namespace
