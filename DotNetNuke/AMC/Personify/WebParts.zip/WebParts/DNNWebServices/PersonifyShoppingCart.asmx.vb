Option Strict Off

Imports Personify.applicationmanager
Imports Personify.ApplicationManager.PErsonifyEnumerations
Imports Personify.ApplicationManager.PersonifyDataObjects

Imports System
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Configuration
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Entities.Profile
Imports System.Collections.Generic

Namespace Personify.DNN.Modules.DNNWebServices
    <WebService(Namespace:="http://personify.tmaresources.com/")> _
 <WebServiceBinding(ConformsTo:=WsiProfiles.None)> _
 <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
  Public Class PersonifyShoppingCart
        Inherits System.Web.Services.WebService

#Region "Constants"
        Public Const C_FUND_EVENT_SUBSYTEM As String = "EVE"
#End Region

#Region "Web Method"

        <WebMethod()> _
         Public Function Connect( _
                    ByVal Login As String _
                    , ByVal Password As String _
                    , ByVal aOrgId As String _
                    , ByVal aOrgUnitId As String _
                 ) As Result_Message

            Dim oConnection As Connection = Nothing
            Dim oResult As Result_Message = New Result_Message
            Try
                oConnection = New Connection
                oResult = oConnection.GetNewConnection(Login, Password, aOrgId, aOrgUnitId)
            Finally
                oConnection = Nothing
            End Try

            Return oResult
        End Function

        <WebMethod()> _
         Public Function Disconnect(ByVal Token As String) As Boolean
            Dim oConnection As Connection = Nothing
            Try
                oConnection = New Connection
                Return oConnection.Disconnect(Token)
            Catch ex As Exception

            Finally
                oConnection = Nothing
            End Try

            Return False
        End Function

        <WebMethod(MessageName:="AddMainProductToCart")> _
        <Obsolete("If you are adding FND Event Products plase pass Price, Prodyct Name followed by IsFundEvent.")> _
        Public Function AddMainProductToCart( _
            ByVal Token As String, _
            ByVal BillMasterCustomerId As String, _
            ByVal BillSubCustomerId As Integer, _
            ByVal ProductId As Integer, _
            ByVal Quantity As Integer, _
            ByVal ShipMasterCustomerId As String, _
            ByVal ShipSubCustomerId As Integer, _
            ByVal RateStructure As String, _
            ByVal RateCode As String, _
            ByVal UserDefinedField1 As String, _
            ByVal UserDefinedField2 As String, _
            ByVal UserDefinedField3 As String, _
            ByVal MarketCode As String) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""
            Dim oConnection As Connection
            Try
                oConnection = New Connection(Token)
                oResult = AddToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, BillMasterCustomerId, BillSubCustomerId, ProductId, oConnection.PortalId, Quantity, RateCode, RateStructure, False, ShipMasterCustomerId, ShipSubCustomerId, "", 0, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode)
            Catch ex As Exception
                oResult.Message = ex.Message
            Finally
                oConnection = Nothing
            End Try
            Return oResult
        End Function

        <WebMethod(MessageName:="AddFundEventToCart")> _
        Public Function AddMainProductToCart( _
                ByVal Token As String, _
                ByVal BillMasterCustomerId As String, _
                ByVal BillSubCustomerId As Integer, _
                ByVal ProductId As Integer, _
                ByVal Quantity As Integer, _
                ByVal ShipMasterCustomerId As String, _
                ByVal ShipSubCustomerId As Integer, _
                ByVal RateStructure As String, _
                ByVal RateCode As String, _
                ByVal UserDefinedField1 As String, _
                ByVal UserDefinedField2 As String, _
                ByVal UserDefinedField3 As String, _
                ByVal MarketCode As String, _
                ByVal Price As Decimal, _
                ByVal ProductName As String, _
                ByVal IsFundEvent As Boolean) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)

            If IsFundEvent Then
                oResult = AddFundEventToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, BillMasterCustomerId, BillSubCustomerId, ProductId, oConnection.PortalId, Quantity, RateCode, RateStructure, False, ShipMasterCustomerId, ShipSubCustomerId, Price, ProductName, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode)
            Else
                oResult = AddToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, BillMasterCustomerId, BillSubCustomerId, ProductId, oConnection.PortalId, Quantity, RateCode, RateStructure, False, ShipMasterCustomerId, ShipSubCustomerId, "", 0, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode)
            End If

            oConnection = Nothing
            Return oResult
        End Function

        <WebMethod()> _
        Public Function AddMainProductToWishList( _
            ByVal Token As String, _
            ByVal BillMasterCustomerId As String, _
            ByVal BillSubCustomerId As Integer, _
            ByVal ProductId As Integer, _
            ByVal Quantity As Integer, _
            ByVal ShipMasterCustomerId As String, _
            ByVal ShipSubCustomerId As Integer, _
            ByVal RateStructure As String, _
            ByVal RateCode As String, _
            ByVal UserDefinedField1 As String, _
            ByVal UserDefinedField2 As String, _
            ByVal UserDefinedField3 As String, _
            ByVal MarketCode As String) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            oResult = AddToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, BillMasterCustomerId, BillSubCustomerId, ProductId, oConnection.PortalId, Quantity, RateCode, RateStructure, True, ShipMasterCustomerId, ShipSubCustomerId, "", 0, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode)

            oConnection = Nothing

            Return oResult
        End Function

        <WebMethod()> _
        Public Function AddSubProductToCart( _
            ByVal Token As String, _
            ByVal BillMasterCustomerId As String, _
            ByVal BillSubCustomerId As Integer, _
            ByVal ProductId As Integer, _
            ByVal SubProductId As Integer, _
            ByVal RelatedCartItemId As Integer, _
            ByVal Quantity As Integer, _
            ByVal ShipMasterCustomerId As String, _
            ByVal ShipSubCustomerId As Integer, _
            ByVal RateStructure As String, _
            ByVal RateCode As String, _
            ByVal UserDefinedField1 As String, _
            ByVal UserDefinedField2 As String, _
            ByVal UserDefinedField3 As String, _
            ByVal MarketCode As String) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            oResult = AddToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, BillMasterCustomerId, BillSubCustomerId, ProductId, oConnection.PortalId, Quantity, RateCode, RateStructure, False, ShipMasterCustomerId, ShipSubCustomerId, "", 0, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode, SubProductId, RelatedCartItemId)

            oConnection = Nothing
            Return oResult
        End Function

        <WebMethod()> _
        Public Function AddSubProductToWishList( _
            ByVal Token As String, _
            ByVal BillMasterCustomerId As String, _
            ByVal BillSubCustomerId As Integer, _
            ByVal ProductId As Integer, _
            ByVal SubProductId As Integer, _
            ByVal RelatedCartItemId As Integer, _
            ByVal Quantity As Integer, _
            ByVal ShipMasterCustomerId As String, _
            ByVal ShipSubCustomerId As Integer, _
            ByVal RateStructure As String, _
            ByVal RateCode As String, _
            ByVal UserDefinedField1 As String, _
            ByVal UserDefinedField2 As String, _
            ByVal UserDefinedField3 As String, _
            ByVal MarketCode As String) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            If SubProductId = -1 Or RelatedCartItemId = -1 Then
                oResult.Message = "Failed add to Wishlist, please check product."
                Return oResult
            End If

            oResult = AddToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, BillMasterCustomerId, BillSubCustomerId, ProductId, oConnection.PortalId, Quantity, RateCode, RateStructure, True, ShipMasterCustomerId, ShipSubCustomerId, "", 0, UserDefinedField1, UserDefinedField2, UserDefinedField3, MarketCode, SubProductId, RelatedCartItemId)

            oConnection = Nothing
            Return oResult
        End Function

        <WebMethod()> _
        Public Function AddDCDFilesToCart( _
            ByVal Token As String, _
            ByVal CartItemId As Integer, _
            ByVal BillMasterCustomerId As String, _
            ByVal BillSubCustomerId As Integer, _
            ByVal ProductId As Integer, _
            ByVal FileId As Integer) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            oResult = AddDCDFilesToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, CartItemId, BillMasterCustomerId, BillSubCustomerId, ProductId, FileId, oConnection.PortalId, False)

            oConnection = Nothing
            Return oResult
        End Function

        <WebMethod()> _
       Public Function AddDCDFilesToWishList( _
           ByVal Token As String, _
           ByVal CartItemId As Integer, _
           ByVal BillMasterCustomerId As String, _
           ByVal BillSubCustomerId As Integer, _
           ByVal ProductId As Integer, _
           ByVal FileId As Integer) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            oResult = AddDCDFilesToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, CartItemId, BillMasterCustomerId, BillSubCustomerId, ProductId, FileId, oConnection.PortalId, True)

            oConnection = Nothing
            Return oResult
        End Function

        <WebMethod(MessageName:="EmptyCart")> _
            Public Function EmptyCart( _
                ByVal Token As String, _
                ByVal MasterCustomerId As String, _
                ByVal SubCustomerId As Integer) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            oResult = DeleteCart(oConnection.PortalId, MasterCustomerId, SubCustomerId)

            oConnection = Nothing
            Return oResult
        End Function

        <WebMethod(MessageName:="DeleteProductFromCart")> _
            Public Function DeleteProductFromCart( _
                    ByVal Token As String, _
                    ByVal MasterCustomerId As String, _
                    ByVal SubCustomerId As Integer, _
                    ByVal ProductId As Integer, _
                    ByVal IsWishList As Boolean) As Result

            Dim oResult As New Result
            oResult.ItemId = -1
            oResult.Message = ""

            Dim oConnection As New Connection(Token)
            oResult = DeleteCartItem(oConnection.PortalId, MasterCustomerId, SubCustomerId, ProductId, IsWishList)

            oConnection = Nothing
            Return oResult
        End Function
#End Region

#Region "Helper Function"

        Protected Overridable Function GetBaseCurrency(ByVal OrganizationId As String) As Currency
            Dim strCurrencySymbol As String = ""
            Dim oAppCurrency As TIMSS.API.ApplicationInfo.IApplicationCurrencies
            Dim oAppOrganizations As TIMSS.API.ApplicationInfo.IApplicationOrganizations
            oAppOrganizations = TIMSS.API.CachedApplicationData.ApplicationDataCache.ApplicationOrganizations(OrganizationId)
            If oAppOrganizations.Count > 0 Then
                oAppCurrency = TIMSS.API.CachedApplicationData.ApplicationDataCache.Currencies(oAppOrganizations(0).CurrencyCodeString)
                If oAppCurrency.Count > 0 Then
                    strCurrencySymbol = oAppCurrency(0).CurrencySymbol
                End If
            End If
            Dim oCurrency As New Currency
            oCurrency.Code = oAppOrganizations(0).CurrencyCodeString
            oCurrency.Symbol = strCurrencySymbol
            Return oCurrency
        End Function

        Private Function GetCustomer(ByVal MCID As String, ByVal SCID As String, ByVal OrgId As String, ByVal OrgUnitId As String) As TIMSS.API.CustomerInfo.ICustomers
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers
            Dim _PersonifyConnect As New PersonifyConnect(OrgId, OrgUnitId)
            oCustomers = _PersonifyConnect.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            With oCustomers
                .Filter.Add("MasterCustomerId", MCID)
                .Filter.Add("SubCustomerId", SCID)
                .Fill()
            End With
            _PersonifyConnect = Nothing
            Return oCustomers
        End Function

        Private Function AddDCDFilesToCart( _
        ByVal OrgId As String, ByVal OrgUnitId As String, ByVal PortalCurrencyCode As String, _
        ByVal CartItemId As Integer, _
        ByVal BillMasterCustomerId As String, _
        ByVal BillSubCustomerId As Integer, _
        ByVal ProductId As Integer, _
        ByVal FileId As Integer, _
        ByVal PortalId As Integer, _
        ByVal IsWishList As Boolean) As Result

            Dim oDCDFilesCartInfo As New ShoppingCartManager.Business.ShoppingCartDCDFilesInfo
            Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
            Dim aProductDetail As ProductDetails
            Dim oResult As New Result

            Dim oCurrency As New Currency
            oCurrency.Code = PortalCurrencyCode

            Dim _ProductHelper As New ProductHelper(OrgId, OrgUnitId, oCurrency, GetBaseCurrency(OrgId), True, PortalId)
            Try

                aProductDetail = _ProductHelper.GetAllDetailsForAProduct(ProductId, True, True, True, True, , , , BillMasterCustomerId, BillSubCustomerId, True, True)

                For Each DCDFile As TIMSS.API.DigitalContentDeliveryInfo.IDigitalContentDeliverySetup In aProductDetail.DCDFileListing
                    If CType(DCDFile.FileId, Integer) = FileId Then
                        With oDCDFilesCartInfo
                            .CartItemId = CartItemId
                            .MasterCustomerId = BillMasterCustomerId
                            .SubCustomerId = BillSubCustomerId
                            .ProductId = ProductId
                            .CopyrightText = DCDFile.CopyrightText
                            .DisplayCopyright = DCDFile.DisplayCopyrightFlag
                            .FileId = FileId
                            .FileName = DCDFile.FileName
                            .DocumentTitle = DCDFile.DocumentTitle
                            .IsWishList = IsWishList
                            .PortalId = PortalId
                            .AddDate = Date.Now()
                            .ModDate = Date.Now()
                        End With

                        oResult.ItemId = oCartController.AddShoppingCartDCDFiles(oDCDFilesCartInfo)
                        oResult.Message = "Item successfully added to the Cart"
                        Return oResult
                    End If
                Next
            Catch exc As Exception
                oResult.ItemId = -1
                oResult.Message = exc.Message
                Return oResult
            End Try
            _ProductHelper = Nothing
            oResult.ItemId = -1
            oResult.Message = "Failed adding files to cart, can not find file."
            Return oResult
        End Function

        Private Function AddToCart( _
        ByVal OrgId As String, ByVal OrgUnitId As String, ByVal PortalCurrencyCode As String, _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
        ByVal ProductID As Integer, _
        ByVal PortalId As Integer, _
        ByVal Quantity As Integer, _
        ByVal RateCode As String, _
        ByVal RateStructure As String, _
        ByVal IsWishList As Boolean, _
        ByVal ShipMasterCustomerId As String, _
        ByVal ShipSubCustomerId As Integer, _
        Optional ByVal OrderNo As String = Nothing, _
        Optional ByVal OrderLineNo As Integer = Nothing, _
        Optional ByVal UserDefinedField1 As String = Nothing, _
        Optional ByVal UserDefinedField2 As String = Nothing, _
        Optional ByVal UserDefinedField3 As String = Nothing, _
        Optional ByVal MarketCode As String = Nothing, _
        Optional ByVal SubProductId As Integer = -1, _
        Optional ByVal RelatedCartItemId As Integer = -1 _
        ) As Result

            Dim oWebCustomerPrices As WebPrices = Nothing
            Dim oResult As New Result
            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            Dim oCurrency As New Currency
            oCurrency.Code = PortalCurrencyCode

            Dim _ProductHelper As New ProductHelper(OrgId, OrgUnitId, oCurrency, GetBaseCurrency(OrgId), True, PortalId)

            Try
                Dim CartItemId As Integer
                Dim oCartController As New ShoppingCartManager.Business.ShoppingCartController
                Dim oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
                Dim aProductDetail As ProductDetails

                If Not String.IsNullOrEmpty(RateStructure) AndAlso Not String.IsNullOrEmpty(RateCode) Then
                    If Not SubProductId = -1 Then
                        oWebCustomerPrices = _ProductHelper.GetProductSpecificRatePrices(SubProductId, RateStructure, RateCode)
                    Else
                        oWebCustomerPrices = _ProductHelper.GetProductSpecificRatePrices(ProductID, RateStructure, RateCode)
                    End If
                ElseIf MasterCustomerId.Length > 12 Then
                    'Get the list Pricing
                    If Not SubProductId = -1 Then
                        oWebCustomerPrices = _ProductHelper.GetProductListDefaultPrices(SubProductId, PricingOptions.DefaultPricing)
                    Else
                        oWebCustomerPrices = _ProductHelper.GetProductListDefaultPrices(ProductID, PricingOptions.DefaultPricing)
                    End If
                Else
                    'If the Customer is logged in
                    oCustomers = GetCustomer(MasterCustomerId, SubCustomerId.ToString, OrgId, OrgUnitId)
                    If oCustomers.Count = 0 Then
                        oResult.ItemId = -1
                        oResult.Message = "Failed add to cart, please check customer ID."
                        Return oResult
                    End If
                    _ProductHelper.MCID = MasterCustomerId
                    _ProductHelper.SCID = SubCustomerId
                    'Get the Pricing for the Customer
                    If Not SubProductId = -1 Then
                        oWebCustomerPrices = _ProductHelper.GetProductYourDefaultPrices(SubProductId, PricingOptions.DefaultPricing)
                    Else
                        oWebCustomerPrices = _ProductHelper.GetProductYourDefaultPrices(ProductID, PricingOptions.DefaultPricing)
                    End If
                End If

                If Not SubProductId = -1 Then
                    aProductDetail = _ProductHelper.GetAllDetailsForAProduct(SubProductId, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True)
                Else
                    aProductDetail = _ProductHelper.GetAllDetailsForAProduct(ProductID, True, True, True, True, , , , MasterCustomerId, SubCustomerId, True, True)
                End If


                If aProductDetail Is Nothing OrElse Not aProductDetail.ProductInfo.Count > 0 Then
                    oResult.ItemId = -1
                    oResult.Message = "Failed add to cart, please check product."
                    Return oResult
                End If

                If aProductDetail.ProductInfo(0).Subsystem = "MTG" OrElse aProductDetail.ProductInfo(0).Subsystem = "MBR" Then
                    If Quantity <> 1 Then
                        oResult.ItemId = -1
                        oResult.Message = "Failed add to cart, please check quantity of product."
                        Return oResult
                    End If
                End If

                With oCartInfo
                    .Subsystem = aProductDetail.ProductInfo(0).Subsystem
                    .ProductType = aProductDetail.ProductInfo(0).ProductTypeCodeString

                    'oWebCustomerPrices = _ProductHelper.GetProductPricesForCustomer(ProductID, MasterCustomerId, SubCustomerId)

                    If oWebCustomerPrices Is Nothing Then
                        oResult.ItemId = -1
                        oResult.Message = "Failed add to cart, please check customer ID."
                        Return oResult
                    End If

                    If RateStructure = "" Then
                        RateStructure = oWebCustomerPrices(0).RateStructure
                    End If
                    .RateStructure = RateStructure

                    If RateCode = "" Then
                        RateCode = oWebCustomerPrices(0).RateCode
                    End If
                    .RateCode = RateCode

                    .MasterCustomerId = MasterCustomerId
                    .SubCustomerId = SubCustomerId
                    .LongName = aProductDetail.ProductInfo(0).LongName
                    .ShortName = aProductDetail.ProductInfo(0).ShortName
                    .Price = oWebCustomerPrices(0).Price

                    .Quantity = Quantity
                    .ProductId = ProductID

                    'Added Order No and Order Line No
                    .OrderNo = OrderNo
                    .OrderLineNo = OrderLineNo

                    If SubProductId = -1 Then
                        .SubProductId = 0
                    Else
                        .SubProductId = SubProductId
                    End If

                    If RelatedCartItemId = -1 Then
                        .RelatedCartItemId = 0
                    Else
                        .RelatedCartItemId = RelatedCartItemId
                    End If

                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .MaxBadges = 0
                    .IsWishList = IsWishList
                    .IsDirectPriceUpdate = False

                    If SubProductId = -1 AndAlso (Not ShipMasterCustomerId = "") AndAlso ShipSubCustomerId = 0 Then
                        oCustomers = GetCustomer(ShipMasterCustomerId, (ShipSubCustomerId).ToString, OrgId, OrgUnitId)
                        If oCustomers.Count > 0 Then
                            .ShipMasterCustomerId = ShipMasterCustomerId
                            .ShipSubCustomerId = ShipSubCustomerId
                            .ShipCustomerLabelName = oCustomers(0).LabelName
                        Else
                            oResult.ItemId = -1
                            oResult.Message = "Failed add to cart, please check Ship-To customer ID."
                            Return oResult
                        End If
                    End If

                    If aProductDetail.Components.Count > 0 Then
                        .ComponentExists = True
                    Else
                        .ComponentExists = False
                    End If

                    If .Subsystem = "MTG" Then
                        If aProductDetail.ListPrices IsNot Nothing Then
                            If aProductDetail.ListPrices.Count > 0 Then
                                For i As Integer = 0 To aProductDetail.ListPrices.Count - 1
                                    If aProductDetail.ListPrices(i).RateStructure = .RateStructure And aProductDetail.ListPrices(i).RateCode = .RateCode Then
                                        .MaxBadges = aProductDetail.ListPrices(i).MaxBadges
                                    End If
                                Next
                            End If
                        End If

                        If aProductDetail.MemberPrices IsNot Nothing Then
                            If aProductDetail.MemberPrices.Count > 0 Then
                                For i As Integer = 0 To aProductDetail.MemberPrices.Count - 1
                                    If aProductDetail.MemberPrices(i).RateStructure = .RateStructure And aProductDetail.MemberPrices(i).RateCode = .RateCode Then
                                        .MaxBadges = aProductDetail.MemberPrices(i).MaxBadges
                                    End If
                                Next
                            End If
                        End If
                    End If

                    .UserDefinedField1 = UserDefinedField1
                    .UserDefinedField2 = UserDefinedField2
                    .UserDefinedField3 = UserDefinedField3
                    .MarketCode = MarketCode
                End With
                CartItemId = oCartController.AddToCart(oCartInfo, PortalId)

                'Add to Shopping Cart Component
                Dim oComponentCartInfo As ShoppingCartManager.Business.ShoppingCartComponentInfo
                If aProductDetail.Components.Count > 0 Then
                    For i As Integer = 0 To aProductDetail.Components.Count - 1
                        oComponentCartInfo = New ShoppingCartManager.Business.ShoppingCartComponentInfo

                        With oComponentCartInfo
                            .CartItemId = CartItemId
                            .MasterCustomerId = MasterCustomerId
                            .SubCustomerId = SubCustomerId
                            .ProductId = aProductDetail.ProductId
                            .ComponentProductId = aProductDetail.Components(i).ProductId
                            .LongName = aProductDetail.Components(i).LongName
                            .ShortName = aProductDetail.Components(i).ShortName
                            .IsWishList = IsWishList
                            .ModuleId = 0
                            .PortalId = PortalId
                            .AddDate = Date.Now()
                            .ModDate = Date.Now()
                        End With

                        oCartController.AddShoppingCartComponents(oComponentCartInfo, PortalId)
                    Next
                End If

                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If

                oResult.ItemId = CartItemId
                oResult.Message = "Item successfully added to the Cart"
                _ProductHelper = Nothing
                Return oResult
            Catch exc As Exception
                oResult.ItemId = -1
                oResult.Message = exc.Message
                Return oResult
            End Try
        End Function

        Private Function AddFundEventToCart( _
        ByVal OrgId As String, ByVal OrgUnitId As String, ByVal PortalCurrencyCode As String, _
        ByVal MasterCustomerId As String, _
        ByVal SubCustomerId As Integer, _
        ByVal ProductID As Integer, _
        ByVal PortalId As Integer, _
        ByVal Quantity As Integer, _
        ByVal RateCode As String, _
        ByVal RateStructure As String, _
        ByVal IsWishList As Boolean, _
        ByVal ShipMasterCustomerId As String, _
        ByVal ShipSubCustomerId As Integer, _
        ByVal Price As Decimal, _
        ByVal ProductName As String, _
        Optional ByVal UserDefinedField1 As String = Nothing, _
        Optional ByVal UserDefinedField2 As String = Nothing, _
        Optional ByVal UserDefinedField3 As String = Nothing, _
        Optional ByVal MarketCode As String = Nothing, _
        Optional ByVal SubProductId As Integer = -1, _
        Optional ByVal RelatedCartItemId As Integer = -1 _
        ) As Result

            'Dim oWebCustomerPrices As WebPrices = Nothing
            Dim CartItemId As Integer
            Dim oResult As New Result
            Dim oCartController As ShoppingCartManager.Business.ShoppingCartController = Nothing
            Dim oCartInfo As ShoppingCartManager.Business.ShoppingCartInfo = Nothing
            Dim oProductHelper As ProductHelper = Nothing
            Dim oCurrency As New Currency

            Try
                If ProductID <= 0 Then
                    oResult.ItemId = -1
                    oResult.Message = "Failed add to cart, please check product Id."
                    Exit Try
                End If

                oCurrency.Code = PortalCurrencyCode

                oProductHelper = New ProductHelper(OrgId, OrgUnitId, oCurrency, GetBaseCurrency(OrgId), True, PortalId)
                If oProductHelper.IsValidFundProduct(ProductID) = False Then
                    oResult.ItemId = -1
                    oResult.Message = "Failed add to cart, please check product."
                    Exit Try
                End If

                oCartController = New ShoppingCartManager.Business.ShoppingCartController
                oCartInfo = New ShoppingCartManager.Business.ShoppingCartInfo

                With oCartInfo
                    .Subsystem = C_FUND_EVENT_SUBSYTEM 'WSEnums.EVE
                    .ProductType = "FUND"
                    .MasterCustomerId = MasterCustomerId
                    .SubCustomerId = SubCustomerId
                    .ProductId = ProductID
                    .LongName = ProductName
                    .ShortName = ProductName
                    .Quantity = Quantity
                    .RateStructure = RateStructure
                    .RateCode = RateCode
                    .Price = Price
                    .AddDate = Date.Now
                    .ModDate = Date.Now
                    .MaxBadges = 0
                    .IsWishList = IsWishList
                    .IsDirectPriceUpdate = True
                    .UserDefinedField1 = UserDefinedField1
                    .UserDefinedField2 = UserDefinedField2
                    .UserDefinedField3 = UserDefinedField3
                    .MarketCode = MarketCode
                End With
                CartItemId = oCartController.AddToCart(oCartInfo, PortalId)

                oResult.ItemId = CartItemId
                oResult.Message = "Event successfully added to the Cart"

            Catch exc As Exception
                oResult.ItemId = -1
                oResult.Message = exc.Message

            Finally
                If oCartController IsNot Nothing Then
                    oCartController.Dispose()
                End If
            End Try

            Return oResult
        End Function


        Private Function DeleteCart( _
            ByVal PortalId As Integer, _
            ByVal MasterCustomerId As String, _
            ByVal SubCustomerId As Integer) As Result

            Dim oResult As New Result
            Dim oCartController As ShoppingCartManager.Business.ShoppingCartController = Nothing

            Try
                If String.IsNullOrEmpty(MasterCustomerId) = True Then
                    oResult.ItemId = -1
                    oResult.Message = "Failed to delete items from the cart, please check customer ID."
                    Exit Try
                End If

                oCartController = New ShoppingCartManager.Business.ShoppingCartController
                oCartController.DeleteCart(MasterCustomerId, SubCustomerId, PortalId)

                oResult.Message = "Successfully deleted the Cart"""

            Catch exc As Exception
                oResult.ItemId = -1
                oResult.Message = exc.Message

            Finally
                If oCartController IsNot Nothing Then
                    oCartController.Dispose()
                End If
            End Try

            Return oResult
        End Function

        Private Function DeleteCartItem( _
            ByVal PortalId As Integer, _
            ByVal MasterCustomerId As String, _
            ByVal SubCustomerId As Integer, _
            ByVal ProductId As Integer, _
            ByVal IsWishList As Boolean) As Result

            Dim oResult As New Result
            Dim oCartController As ShoppingCartManager.Business.ShoppingCartController = Nothing

            Try
                If String.IsNullOrEmpty(MasterCustomerId) = True Then
                    oResult.ItemId = -1
                    oResult.Message = "Failed to delete items from the cart, please check customer ID."
                    Exit Try

                ElseIf ProductId <= 0 Then
                    oResult.ItemId = -1
                    oResult.Message = "Failed to delete items from the cart, please check product ID."
                    Exit Try
                End If

                oCartController = New ShoppingCartManager.Business.ShoppingCartController
                oCartController.DeleteCartItem(MasterCustomerId, SubCustomerId, ProductId, IsWishList, PortalId)

                oResult.Message = "Item successfully deleted from the Cart"""

            Catch exc As Exception
                oResult.ItemId = -1
                oResult.Message = exc.Message

            Finally
                If oCartController IsNot Nothing Then
                    oCartController.Dispose()
                End If
            End Try

            Return oResult
        End Function
#End Region

#Region "Result Class"
        Public Class Result
            Public ItemId As Integer
            Public Message As String

            Public Sub New()
            End Sub

            Public Sub New(ByVal intItemID As Integer, _
                        ByVal strMessage As String)
                ItemId = intItemID
                Message = strMessage
            End Sub

        End Class
#End Region

#Region "AddListOfProductsToCart"

#Region "Variables"
        Private oConnection As Connection
        Private oWebCustomerPrices As WebPrices = Nothing
        Private oCustomers As TIMSS.API.CustomerInfo.ICustomers = Nothing
        Private aProductDetail As ProductDetails = Nothing
        Private CartItem As ShoppingCartItem = Nothing
        Private ProductHelper As ProductHelper = Nothing
        Private oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
        Private oCartController As New ShoppingCartManager.Business.ShoppingCartController
        Private arrResult As New List(Of Result)
        Private strErrorMessage As New System.Text.StringBuilder
        Private strShipCustomerLabelName As String
#End Region

#Region "Web Method"
        <WebMethod()> _
Public Function AddListOfProductsToCart( _
    ByVal Token As String, _
    ByVal ListOfShoppingCartItems() As ShoppingCartItem) As Result()
            Dim oResult() As Result
            oConnection = New Connection(Token)
            oResult = AddListOfItemsToCart(ListOfShoppingCartItems)
            oConnection = Nothing
            Return oResult
        End Function
#End Region

#Region "Helper Functions"
        Private Function AddListOfItemsToCart( _
               ByVal ListOfShoppingCartItems() As ShoppingCartItem) As Result()

            Dim Result As Result
            Dim oCurrency As New Currency
            oCurrency.Code = oConnection.PortalCurrencyCode
            ProductHelper = New ProductHelper(oConnection.OrgId, oConnection.OrgUnitId, oCurrency, GetBaseCurrency(oConnection.OrgId), True, oConnection.PortalId)
            Dim blnExistingOrdersDeleted As Boolean

            Try
                Dim CartItemId As Integer
                'Dim oCartInfo As New ShoppingCartManager.Business.ShoppingCartInfo
                'Dim aProductDetail As ProductDetails

                'Loop through the Shopping Cart Main Products
                For Each CartItem As ShoppingCartItem In ListOfShoppingCartItems
                    'Check for Bill Customer, Ship Customer and Product for any issues
                    If String.IsNullOrEmpty(CheckCustomerAndProduct(CartItem)) AndAlso _
                    aProductDetail.ProductInfo.Count > 0 AndAlso oWebCustomerPrices.Count > 0 Then

                        'If this is for an existing order clear the existing orders from the Cart.
                        If Not String.IsNullOrEmpty(CartItem.ProductInfo.OrderNo) AndAlso Not blnExistingOrdersDeleted Then
                            oCartController.DeleteShoppingCartExistingOrders(CartItem.ProductInfo.MasterCustomerId, CartItem.ProductInfo.SubCustomerId, oConnection.PortalId)
                            blnExistingOrdersDeleted = True
                        End If

                        With oCartInfo
                            .Subsystem = aProductDetail.ProductInfo(0).Subsystem
                            .ProductType = aProductDetail.ProductInfo(0).ProductTypeCodeString

                            If CartItem.ProductInfo.RateStructure = "" Then
                                CartItem.ProductInfo.RateStructure = oWebCustomerPrices(0).RateStructure
                            End If
                            .RateStructure = CartItem.ProductInfo.RateStructure

                            If CartItem.ProductInfo.RateCode = "" Then
                                CartItem.ProductInfo.RateCode = oWebCustomerPrices(0).RateCode
                            End If
                            .RateCode = CartItem.ProductInfo.RateCode

                            .MasterCustomerId = CartItem.ProductInfo.MasterCustomerId
                            .SubCustomerId = CartItem.ProductInfo.SubCustomerId
                            If CartItem.ProductInfo.ShipMasterCustomerId <> "" AndAlso CartItem.ProductInfo.ShipSubCustomerId >= 0 Then
                                .ShipMasterCustomerId = CartItem.ProductInfo.ShipMasterCustomerId
                                .ShipSubCustomerId = CartItem.ProductInfo.ShipSubCustomerId
                                .ShipCustomerLabelName = strShipCustomerLabelName
                            End If
                            .LongName = aProductDetail.ProductInfo(0).LongName
                            .ShortName = aProductDetail.ProductInfo(0).ShortName
                            .Price = oWebCustomerPrices(0).Price
                            .Quantity = CartItem.ProductInfo.Quantity
                            .ProductId = CartItem.ProductInfo.ProductID
                            .AddDate = Date.Now
                            .ModDate = Date.Now
                            .MaxBadges = 0
                            .IsWishList = CartItem.ProductInfo.IsWishList
                            .IsDirectPriceUpdate = False

                            If aProductDetail.Components.Count > 0 Then
                                .ComponentExists = True
                            Else
                                .ComponentExists = False
                            End If

                            'If it is a Meeting Product set Badges and Tickets
                            If .Subsystem = "MTG" Then
                                SetBadgesAndTickets(aProductDetail, CartItem, oCartInfo)
                            End If

                            .UserDefinedField1 = CartItem.ProductInfo.UserDefinedField1
                            .UserDefinedField2 = CartItem.ProductInfo.UserDefinedField2
                            .UserDefinedField3 = CartItem.ProductInfo.UserDefinedField3
                            .MarketCode = CartItem.ProductInfo.MarketCode
                            .OrderNo = CartItem.ProductInfo.OrderNo

                            If Not IsDBNull(CartItem.ProductInfo.OrderLineNo) Then
                                .OrderLineNo = CartItem.ProductInfo.OrderLineNo
                            Else
                                .OrderLineNo = 0
                            End If
                        End With
                        CartItemId = oCartController.AddToCart(oCartInfo, oConnection.PortalId)

                        'Add Components to Shopping Cart
                        If aProductDetail.Components.Count > 0 Then
                            AddComponents(CartItemId, CartItem)
                        End If

                        Result = New Result(CartItemId, "Item successfully added to the Cart")
                        arrResult.Add(Result)

                        'Add the Sub Products
                        If CartItem.ListOfSubProducts.Count > 0 Then
                            AddSubProducts(CartItem, CartItemId)
                        End If
                    Else
                        Result = New Result(CartItemId, strErrorMessage.ToString)
                        arrResult.Add(Result)
                    End If

                    'Empty the Error Message String
                    strErrorMessage.Remove(0, strErrorMessage.Length)

                Next

                If Not oCartController Is Nothing Then
                    oCartController.Dispose()
                End If

                oConnection = Nothing
                ProductHelper = Nothing
                oCartInfo = Nothing
                oCartController = Nothing

            Catch exc As Exception
                arrResult.Add(New Result(-1, strErrorMessage.ToString))
            End Try

            Return arrResult.ToArray

        End Function


        Private Function CheckCustomerAndProduct(ByVal CartItem As ShoppingCartItem) As String
            'If a GUID is passed
            If Not CartItem.ProductInfo.MasterCustomerId.Length > 12 Then
                'If the Customer is logged in
                oCustomers = GetCustomer(CartItem.ProductInfo.MasterCustomerId, CartItem.ProductInfo.SubCustomerId.ToString, oConnection.OrgId, oConnection.OrgUnitId)
                If oCustomers.Count = 0 Then
                    strErrorMessage.Append(String.Format("Failed add to cart, please check Bill Customer ID. Product ID: '{0}'", CartItem.ProductInfo.ProductID.ToString()))
                End If
            End If

            If strErrorMessage.Length = 0 Then
                'Get the Product Detail
                aProductDetail = ProductHelper.GetAllDetailsForAProduct(CartItem.ProductInfo.ProductID, True, True, True, True, , , , CartItem.ProductInfo.MasterCustomerId, CartItem.ProductInfo.SubCustomerId, True, True, True)

                If aProductDetail Is Nothing OrElse aProductDetail.ProductInfo.Count = 0 Then
                    strErrorMessage.Append(String.Format("Failed add to cart, please check Product. Product ID: '{0}'", CartItem.ProductInfo.ProductID.ToString()))
                ElseIf aProductDetail.ProductInfo(0).Subsystem = "MTG" OrElse aProductDetail.ProductInfo(0).Subsystem = "MBR" Then
                    If CartItem.ProductInfo.Quantity <> 1 Then
                        strErrorMessage.Append(String.Format("Failed add to cart, please check Product. Product ID: '{0}'", CartItem.ProductInfo.ProductID.ToString()))
                    End If
                End If
            End If

            If strErrorMessage.Length = 0 Then
                If Not String.IsNullOrEmpty(CartItem.ProductInfo.RateStructure) AndAlso Not String.IsNullOrEmpty(CartItem.ProductInfo.RateCode) Then
                    'Get the list Pricing
                    oWebCustomerPrices = ProductHelper.GetProductSpecificRatePrices(CartItem.ProductInfo.ProductID, CartItem.ProductInfo.RateStructure, CartItem.ProductInfo.RateCode)
                ElseIf CartItem.ProductInfo.MasterCustomerId.Length > 12 Then
                    'Get the Pricing for the Customer
                    oWebCustomerPrices = ProductHelper.GetProductListDefaultPrices(CartItem.ProductInfo.ProductID, PricingOptions.DefaultPricing)
                Else
                    ProductHelper.MCID = CartItem.ProductInfo.MasterCustomerId
                    ProductHelper.SCID = CartItem.ProductInfo.SubCustomerId
                    oWebCustomerPrices = ProductHelper.GetProductYourDefaultPrices(CartItem.ProductInfo.ProductID, PricingOptions.DefaultPricing)
                End If

                If oWebCustomerPrices Is Nothing Then
                    strErrorMessage.Append(String.Format("Failed add to cart, please check customer ID. Product ID: '{0}'", CartItem.ProductInfo.ProductID.ToString()))
                End If
            End If

            'Check the Ship Customer
            If strErrorMessage.Length = 0 Then
                If CartItem.ProductInfo.ShipMasterCustomerId <> "" AndAlso CartItem.ProductInfo.ShipSubCustomerId >= 0 Then
                    oCustomers = GetCustomer(CartItem.ProductInfo.ShipMasterCustomerId, CartItem.ProductInfo.ShipSubCustomerId.ToString, oConnection.OrgId, oConnection.OrgId)
                    If oCustomers.Count > 0 Then
                        strShipCustomerLabelName = oCustomers(0).LabelName
                    Else
                        strErrorMessage.Append(String.Format("Failed add to cart, please check Ship Customer ID. Product ID: '{0}'", CartItem.ProductInfo.ProductID.ToString()))
                    End If
                End If
            End If

            Return strErrorMessage.ToString

        End Function

        Private Sub AddComponents(ByVal CartItemID As Integer, ByVal CartItem As ShoppingCartItem)
            'Add Product Components to Shopping Cart 
            Dim oComponentCartInfo As ShoppingCartManager.Business.ShoppingCartComponentInfo
            For i As Integer = 0 To aProductDetail.Components.Count - 1
                oComponentCartInfo = New ShoppingCartManager.Business.ShoppingCartComponentInfo
                With oComponentCartInfo
                    .CartItemId = CartItemID
                    .MasterCustomerId = CartItem.ProductInfo.MasterCustomerId
                    .SubCustomerId = CartItem.ProductInfo.SubCustomerId
                    .ProductId = aProductDetail.ProductId
                    .ComponentProductId = aProductDetail.Components(i).ProductId
                    .LongName = aProductDetail.Components(i).LongName
                    .ShortName = aProductDetail.Components(i).ShortName
                    .IsWishList = CartItem.ProductInfo.IsWishList
                    .ModuleId = 0
                    .PortalId = oConnection.PortalId
                    .AddDate = Date.Now()
                    .ModDate = Date.Now()
                End With
                oCartController.AddShoppingCartComponents(oComponentCartInfo, oConnection.PortalId)
            Next
        End Sub

        Private Sub SetBadgesAndTickets(ByVal aProductDetail As ProductDetails, _
                        ByVal CartItem As ShoppingCartItem, _
                        ByVal oCartInfo As ShoppingCartManager.Business.ShoppingCartInfo)
            If aProductDetail.ListPrices IsNot Nothing Then
                If aProductDetail.ListPrices.Count > 0 Then
                    For i As Integer = 0 To aProductDetail.ListPrices.Count - 1
                        If aProductDetail.ListPrices(i).RateStructure = CartItem.ProductInfo.RateStructure And _
                                aProductDetail.ListPrices(i).RateCode = CartItem.ProductInfo.RateCode Then
                            oCartInfo.MaxBadges = aProductDetail.ListPrices(i).MaxBadges
                        End If
                    Next
                End If
            End If

            If aProductDetail.MemberPrices IsNot Nothing Then
                If aProductDetail.MemberPrices.Count > 0 Then
                    For i As Integer = 0 To aProductDetail.MemberPrices.Count - 1
                        If aProductDetail.MemberPrices(i).RateStructure = CartItem.ProductInfo.RateStructure And _
                                aProductDetail.MemberPrices(i).RateCode = CartItem.ProductInfo.RateCode Then
                            oCartInfo.MaxBadges = aProductDetail.MemberPrices(i).MaxBadges
                        End If
                    Next
                End If
            End If
            oCartInfo.MaximumTickets = aProductDetail.ProductInfo(0).MaximumTickets

        End Sub

        'Need to re-write this so that we don't call the AddToCart mutliple no of times
        Private Sub AddSubProducts(ByVal CartItem As ShoppingCartItem, ByVal intCartItemId As Integer)
            For Each SubItem As ProductInfo In CartItem.ListOfSubProducts
                Dim Result As Result = New Result
                If CheckSubProduct(SubItem.ProductID) Then
                    Result = AddToCart(oConnection.OrgId, oConnection.OrgUnitId, oConnection.PortalCurrencyCode, _
                        CartItem.ProductInfo.MasterCustomerId, CartItem.ProductInfo.SubCustomerId, _
                        CartItem.ProductInfo.ProductID, oConnection.PortalId, SubItem.Quantity, SubItem.RateCode, SubItem.RateStructure, _
                        SubItem.IsWishList, SubItem.ShipMasterCustomerId, SubItem.ShipSubCustomerId, _
                        SubItem.OrderNo, SubItem.OrderLineNo, SubItem.UserDefinedField1, SubItem.UserDefinedField2, _
                        SubItem.UserDefinedField3, SubItem.MarketCode, SubItem.ProductID, intCartItemId)
                Else
                    Result.ItemId = -1
                    Result.Message = "Failed add to cart, not a valid Sub Product. Please check Product ID: " + SubItem.ProductID.ToString
                End If
                arrResult.Add(Result)
            Next
        End Sub

        Private Function CheckSubProduct(ByVal lngProductID As Long) As Boolean
            Dim isSubProduct As Boolean
            If aProductDetail IsNot Nothing Then
                For i As Integer = 0 To aProductDetail.SubProducts.Length - 1
                    If aProductDetail.SubProducts(i).ProductId = lngProductID Then
                        isSubProduct = True
                        Exit For
                    End If
                Next
            End If
            Return isSubProduct
        End Function
#End Region

#Region "Helper Classese"
        <Serializable()> _
        Public Class ShoppingCartItem
            Public ProductInfo As ProductInfo
            Public ListOfSubProducts As List(Of ProductInfo)
        End Class

        <Serializable()> _
        Public Class ProductInfo
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
            Public ProductID As Integer
            Public Quantity As Integer
            Public RateCode As String
            Public RateStructure As String
            Public IsWishList As Boolean
            Public ShipMasterCustomerId As String
            Public ShipSubCustomerId As Integer
            Public UserDefinedField1 As String = Nothing
            Public UserDefinedField2 As String = Nothing
            Public UserDefinedField3 As String = Nothing
            Public MarketCode As String = Nothing
            Public OrderNo As String = Nothing
            Public OrderLineNo As Integer
        End Class
#End Region


#End Region



    End Class
End Namespace
