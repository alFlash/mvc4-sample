Imports Microsoft.VisualBasic
Imports TIMSS.API.Core

Public Class TokenObject
	Public Token As String
	Public Login As String
    Public Password As String
    Public OrgId As String
    Public OrgUnitId As String
    Public PortalId As Integer
    Public PortalCurrency As String
    Public LastAccess As DateTime

    Public Sub New( _
      ByVal aLogin As String _
      , ByVal aPassword As String _
      , ByVal aOrgId As String _
      , ByVal aOrgUnitId As String _
      , ByVal aPortalId As Integer _
      , ByVal aPortalCurrency As String _
   )
        Token = System.Guid.NewGuid().ToString("N").ToUpper
        LastAccess = Now
        Login = aLogin
        Password = aPassword
        OrgId = aOrgId
        OrgUnitId = aOrgUnitId
        PortalId = aPortalId
        PortalCurrency = aPortalCurrency
    End Sub

    Public Sub New()
    End Sub

End Class

Public Class Result_Message
    Public Success As Boolean
    Public Message As String
    Public Token As String
End Class


'Public Enum WSEnums
'    EVE
'End Enum

Public Class ApplicationTokenManager

    Private _LastCleanup As DateTime
    Private _SessionTimeout As Integer
    Private _TokenList As ArrayList
    Private WithEvents SessionTimer As System.Timers.Timer

    Public Sub New(Optional ByVal SessionTimeoutInMinutes As Integer = 20)
        _LastCleanup = Now
        _SessionTimeout = SessionTimeoutInMinutes
        _TokenList = New ArrayList

        SessionTimer = New System.Timers.Timer
        SessionTimer.Interval = _SessionTimeout * 20 * 60 * 1000
        SessionTimer.AutoReset = True
        AddHandler SessionTimer.Elapsed, AddressOf TimerElapsed
        SessionTimer.Start()
    End Sub

    Public Function CreateTokenObject( _
        ByVal aLogin As String _
        , ByVal aPassword As String _
        , ByVal aOrgId As String _
        , ByVal aOrgUnitId As String _
        , ByVal aPortalId As Integer _
        , ByVal aPortalCurrency As String _
        ) As TokenObject
        Dim oToken As New TokenObject(aLogin, aPassword, aOrgId, aOrgUnitId, aPortalId, aPortalCurrency)
        _TokenList.Add(oToken)
        Return oToken
    End Function

    Public Function GetTokenObject(ByVal Token As String) As TokenObject
        Dim TokenObjectResult As TokenObject = Nothing
        If Not String.IsNullOrEmpty(Token) Then
            Dim strToken As String = Token.ToUpper
            If (_TokenList IsNot Nothing) Then
                If (_TokenList.Count > 0) Then
                    For i As Integer = 0 To _TokenList.Count - 1
                        If (_TokenList(i) IsNot Nothing) Then
                            Dim aTokenObject As TokenObject = CType(_TokenList(i), TokenObject)
                            If aTokenObject.Token = strToken Then
                                TokenObjectResult = aTokenObject
                                Exit For
                            End If
                        End If
                    Next
                End If
            End If
        End If
        Return TokenObjectResult
    End Function

    Public Function GetTokenObject( _
            ByVal aLogin As String _
            , ByVal aPassword As String _
            , ByVal aOrgId As String _
            , ByVal aOrgUnitId As String _
            ) As TokenObject

        Dim TokenObjectResult As TokenObject = Nothing
        If (_TokenList IsNot Nothing) Then
            If (_TokenList.Count > 0) Then
                For i As Integer = 0 To _TokenList.Count - 1
                    If (_TokenList(i) IsNot Nothing) Then
                        Dim aTokenObject As TokenObject = CType(_TokenList(i), TokenObject)
                        If aTokenObject.Login = aLogin AndAlso aTokenObject.Password = aPassword AndAlso aTokenObject.OrgId = aOrgId _
                            AndAlso aTokenObject.OrgUnitId = aOrgUnitId Then 'AndAlso aTokenObject.PortalId = aPortalId _
                            'AndAlso aTokenObject.PortalCurrency = aPortalCurrency Then
                            TokenObjectResult = aTokenObject
                            Exit For
                        End If
                    End If
                Next
            End If
        End If
        Return TokenObjectResult
    End Function

    Public Function DeleteTokenObject(ByVal Token As String) As Boolean
        Dim strToken As String = Token.ToUpper
        If (_TokenList IsNot Nothing) Then
            If (_TokenList.Count > 0) Then
                For i As Integer = 0 To _TokenList.Count - 1
                    If (_TokenList(i) IsNot Nothing) Then
                        Dim aTokenObject As TokenObject = CType(_TokenList(i), TokenObject)
                        If aTokenObject.Token = strToken Then
                            _TokenList.RemoveAt(i)
                            Exit For
                        End If
                    End If
                Next
            End If
        End If
        Return True
    End Function

    Private Sub TimerElapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs)
        ClearTokenList()
    End Sub

    Public Sub CleanupTokenList()
        Dim dteMin As DateTime

        dteMin = Today.Date.AddMinutes(-1 * _SessionTimeout)
        SessionTimer.Stop()

        If (_TokenList IsNot Nothing) Then
            If (_TokenList.Count > 0) Then
                For i As Integer = _TokenList.Count - 1 To 0 Step -1
                    If (_TokenList(i) IsNot Nothing) Then
                        Dim aTokenObject As TokenObject = CType(_TokenList(i), TokenObject)
                        If aTokenObject.LastAccess < dteMin Then
                            _TokenList.RemoveAt(i)
                        End If
                    End If
                Next
            End If
        End If
        _LastCleanup = Now
        SessionTimer.Start()
    End Sub

    Public Sub ClearTokenList()
        _TokenList = New ArrayList
    End Sub

End Class
