Imports Microsoft.VisualBasic
Imports TIMSS.API.Core
Imports System.Configuration
Imports System.Web
Imports TIMSS.SQLObjects
Imports System.Collections
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports TIMSS.Server.ResourceStorage
Imports TIMSS.Server.ResourceStorage.InstallationDatabase
Imports TIMSS.Server.ResourceStorage.Ping
Imports TIMSS.Client.Implementation.Security.Authentication
Imports DotNetNuke.Entities.Portals

Public Class Connection

    Public OrgId As String
    Public OrgUnitId As String
    Public PortalId As Integer
    Public PortalCurrencyCode As String
    Public Shared TokenManager As ApplicationTokenManager

    Public Sub New()
    End Sub

    Public Sub New(ByVal Token As String)
        Dim oToken As TokenObject = GetTokenObject(Token)
        OrgId = oToken.OrgId
        OrgUnitId = oToken.OrgUnitId
        PortalId = oToken.PortalId
        PortalCurrencyCode = oToken.PortalCurrency
    End Sub

    Public Function GetNewConnection( _
       ByVal Login As String _
      , ByVal Password As String _
      , ByVal OrgId As String _
      , ByVal OrgUnitId As String) As Result_Message


        Dim oResult As Result_Message = New Result_Message
        Dim oWSAuthentication As TIMSS.WebserviceAuthentication = New TIMSS.WebserviceAuthentication
        Dim oAuthorizeUser As TIMSS.WebserviceAuthentication.Result_AuthorizeUser = Nothing
        Dim oGetAccessPoints As TIMSS.WebserviceAuthentication.Result_GetAccessPoints = Nothing

        If TokenManager Is Nothing Then
            TokenManager = New ApplicationTokenManager
        End If

        If Not TIMSS.PersonifyInitializer.SystemWasInitialized Then
            TIMSS.PersonifyInitializer.Initialize(HttpContext.Current.Request.PhysicalApplicationPath, Personify.ApplicationManager.PersonifySiteSettings.GetSeatInformation)
        End If

        Dim oTokenObject As TokenObject = TokenManager.GetTokenObject(Login, Password, OrgId, OrgUnitId)

        Try
            If oTokenObject IsNot Nothing Then
                oResult.Message = ""
                oResult.Success = True
                oResult.Token = oTokenObject.Token
            Else
                oAuthorizeUser = oWSAuthentication.AuthorizeUser(Login, Password, OrgId, OrgUnitId)
                If oAuthorizeUser.Success Then
                    oGetAccessPoints = oWSAuthentication.GetAccessPoints(Login, Password, OrgId, OrgUnitId)
                End If
                If Not oAuthorizeUser.Success Then
                    oResult.Message = oAuthorizeUser.ErrorMessage
                    oResult.Success = False
                ElseIf Not oGetAccessPoints.Success Then
                    oResult.Message = oGetAccessPoints.ErrorMessage
                    oResult.Success = False
                Else
                    'Get the Portal ID
                    Dim intPortalId As Integer = GetPortalID(GetDomainName(HttpContext.Current.Request, False))
                    'Get Portal info from PersonifySiteSettings (Currency Code)
                    Dim oSettings As Personify.ApplicationManager.PersonifyDataObjects.SiteSettings _
                            = Personify.ApplicationManager.PersonifySiteSettings.GetSiteSettings(intPortalId)
                    oTokenObject = TokenManager.CreateTokenObject(Login, Password, OrgId, OrgUnitId, intPortalId, oSettings.PortalCurrency)
                    oResult.Message = ""
                    oResult.Success = True
                    oResult.Token = oTokenObject.Token
                End If
            End If
        Catch ex As Exception
            oResult.Success = False
            oResult.Message = ex.Message
        Finally
            oWSAuthentication = Nothing
            oAuthorizeUser = Nothing
            oGetAccessPoints = Nothing
        End Try

        Return oResult

    End Function

    Public Function Disconnect(ByVal Token As String) As Boolean
        Try
            If TokenManager IsNot Nothing Then Return TokenManager.DeleteTokenObject(Token)
        Catch ex As Exception
            Throw ex
        End Try
        Return Nothing
    End Function

    Private Function GetTokenObject(ByVal Token As String) As TokenObject
        Dim oToken As TokenObject = TokenManager.GetTokenObject(Token)
        If oToken Is Nothing Then
            Throw New Exception("Invalid Token, please login again.")
        End If
        Return oToken
    End Function

    Public Shared Function GetDomainName(ByVal Request As HttpRequest, ByVal ParsePortNumber As Boolean) As String
        Dim DomainName As System.Text.StringBuilder = New System.Text.StringBuilder
        Dim URL() As String
        Dim URI As String   ' holds Request.Url, less the "?" parameters
        Dim intURL As Integer

        ' split both URL separater, and parameter separator
        ' We trim right of '?' so test for filename extensions can occur at END of URL-componenet.
        ' Test:   'www.aspxforum.net'  should be returned as a valid domain name.
        ' just consider left of '?' in URI
        ' Binary, else '?' isn't taken literally; only interested in one (left) string
        URI = Request.Url.ToString()
        Dim hostHeader As String = Config.GetSetting("HostHeader")
        If Not hostHeader Is Nothing Then
            If hostHeader.Length > 0 Then
                URI = URI.ToLower.Replace(hostHeader.ToLower, "")
            End If
        End If
        intURL = InStr(URI, "?", CompareMethod.Binary)
        If intURL > 0 Then
            URI = Left(URI, intURL - 1)
        End If

        URL = Split(URI, "/")

        For intURL = 2 To URL.GetUpperBound(0)
            Select Case URL(intURL).ToLower
                Case "admin", "controls", "desktopmodules", "mobilemodules", "premiummodules", "providers"
                    Exit For
                Case Else
                    ' exclude filenames ENDing in ".aspx" or ".axd" --- 
                    '   we'll use reverse match,
                    '   - but that means we are checking position of left end of the match;
                    '   - and to do that, we need to ensure the string we test against is long enough;
                    If (URL(intURL).Length >= ".aspx".Length) Then      'long enough for both tests
                        If InStrRev(URL(intURL).ToLower(), ".aspx") = (URL(intURL).Length - (".aspx".Length - 1)) _
                        Or InStrRev(URL(intURL).ToLower(), ".axd") = (URL(intURL).Length - (".axd".Length - 1)) _
                        Or InStrRev(URL(intURL).ToLower(), ".ashx") = (URL(intURL).Length - (".ashx".Length - 1)) _
                        Or InStrRev(URL(intURL).ToLower(), ".asmx") = (URL(intURL).Length - (".asmx".Length - 1)) _
                        Or InStrRev(URL(intURL).ToLower(), ".wsdl") = (URL(intURL).Length - (".wsdl".Length - 1)) Then
                            Exit For
                        End If
                    End If
                    ' non of the exclusionary names found
                    DomainName.Append(IIf(DomainName.ToString <> "", "/", "").ToString & URL(intURL))
            End Select
        Next intURL

        ' handle port specification
        If ParsePortNumber Then
            If DomainName.ToString.IndexOf(":") <> -1 Then
                Dim usePortNumber As Boolean = (Not Request.IsLocal)
                If Not DotNetNuke.Common.Utilities.Config.GetSetting("UsePortNumber") Is Nothing Then
                    usePortNumber = Boolean.Parse(DotNetNuke.Common.Utilities.Config.GetSetting("UsePortNumber"))
                End If
                If usePortNumber = False Then
                    DomainName = DomainName.Replace(":" & Request.Url.Port.ToString(), "")
                End If
            End If
        End If

        Return DomainName.ToString

    End Function

    Public Shared Function GetPortalID(ByVal strPortalAlias As String) As Integer
        Dim oPortals As PortalAliasCollection
        Dim intPortalID As Integer = -1
        oPortals = CType(DotNetNuke.Common.Utilities.DataCache.GetCache("GetPortalByAlias"), PortalAliasCollection)
        Dim objPortalAliasInfo As DotNetNuke.Entities.Portals.PortalAliasInfo = oPortals(strPortalAlias.ToLower)
         If objPortalAliasInfo IsNot Nothing Then
            intPortalID = objPortalAliasInfo.PortalId
        End If
        Return intPortalID
    End Function

End Class
