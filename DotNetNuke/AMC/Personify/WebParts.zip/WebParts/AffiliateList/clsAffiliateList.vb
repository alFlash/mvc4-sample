Namespace Personify.DNN.Modules.AffiliateList
    Public Class clsAffiliateList
#Region "constants"
        'Action URL's        
        Public Const C_Order_History_Action_URL As String = "OrderHistoryActionURL"
        Public Const C_Print_Roster_Action_URL As String = "PrintRosterActionURL"
        Public Const C_Buy_Product_Action_URL As String = "BuyProductActionURL"
        Public Const C_Employee_Action_URL As String = "EmployeeActionURL"
        Public Const C_Member_Action_URL As String = "MemberActionURL"
        Public Const C_Group_Email_Action_URL As String = "GroupEmailActionURL"
        Public Const C_Create_Order_Action_URL As String = "CreateOrderActionURL"
        Public Const C_Profile_Action_URL As String = "ProfileActionURL"
        Public Const C_Renew_Action_URL As String = "RenewActionURL"

        Public Const C_Purchase_Action_URL As String = "PurchaseActionURL"

        Public Const C_Page_Size As String = "PageSize"
        Public Const C_Show_Search As String = "ShowSearch"
        Public Const C_Show_Phone As String = "ShowPhone"
        Public Const C_Show_Segment_Detail As String = "ShowSegmentDetail"
        Public Const C_Segment_Details_Type As String = "SegmentDetailsType"
        Public Const C_Segment_Details_Action_URL As String = "SegmentDetailsActionURL"
        Public Const C_Allow_Segment_Details_Delete As String = "AllowSegmentDetailsDelete"

        Public Const C_Display_Options As String = "DisplayOptions"
        Public Const C_Show_Group_Panel As String = "ShowGroupPanel"

        'Public Const C_Cancel_Action_URL As String = "CancelActionURL"

        Public Const C_Buy_Product_For_Same_Group_Action_URL As String = "BuyProductForSameGroupActionURL"
        Public Const C_Buy_Product_For_Different_Group_Action_URL As String = "BuyProductForDifferentGroupActionURL"
        Public Const C_Checkout_Action_URL As String = "CheckoutActionURL"
        Public Const C_AFFILIATELIST_GROUP_PURCHASE_CONFIRM_ACTION_URL As String = "AffiliateListGroupPurchaseConfirmActionURL"

#End Region
    End Class
End Namespace

