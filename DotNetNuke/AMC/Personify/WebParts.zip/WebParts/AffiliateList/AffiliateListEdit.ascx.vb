Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Personify.DNN.Modules.AffiliateList.clsAffiliateList

Namespace Personify.DNN.Modules.AffiliateList

    Public MustInherit Class AffiliateListEdit
        Inherits Personify.ApplicationManager.PersonifyDNNBaseFormEditSettings
#Region "Controls"
        'Regular Listing Controls
        Protected WithEvents rdDisplayOptionsAsRegularListing As System.Web.UI.WebControls.RadioButton

        Protected WithEvents pnlDisplayAsRegularListing As System.Web.UI.WebControls.Panel

        'Protected WithEvents rdShowGroupPanel As System.Web.UI.WebControls.RadioButtonList

        Protected WithEvents pnlShowGroupPurchasePanel As System.Web.UI.WebControls.Panel
        Protected WithEvents rdShowGroupPurchasePanel As System.Web.UI.WebControls.RadioButton
        Protected WithEvents drpPurchaseActionURL As DotNetNuke.UI.UserControls.UrlControl

        Protected WithEvents pnlShowGroupActionPanel As System.Web.UI.WebControls.Panel
        Protected WithEvents rdShowGroupActionPanel As System.Web.UI.WebControls.RadioButton
        Protected WithEvents lblActionURLs As System.Web.UI.WebControls.Label
        Protected WithEvents lblOrderHistoryActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpOrderHistoryActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblPrintRosterActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpPrintRosterActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblBuyProductActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpBuyProductActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblEmployeeActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpEmployeeActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblMemberActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpMemberActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblGroupEmailActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpGroupEmailActionURL As DotNetNuke.UI.UserControls.UrlControl
        'Protected WithEvents lblCreateOrderActionURL As DotNetNuke.UI.UserControls.LabelControl
        'Protected WithEvents drpCreateOrderActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblProfileActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpProfileActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblRenewActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpRenewActionURL As DotNetNuke.UI.UserControls.UrlControl


        Protected WithEvents txtPageSize As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkShowSearch As System.Web.UI.WebControls.CheckBox
        Protected WithEvents lblShowSearch As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents lblDetailListing As System.Web.UI.WebControls.Label
        'Protected WithEvents chkShowPhone As System.Web.UI.WebControls.CheckBox
        'Protected WithEvents lblShowPhone As DotNetNuke.UI.UserControls.LabelControl
        'Protected WithEvents chkShowSegmentDetail As System.Web.UI.WebControls.CheckBox
        'Protected WithEvents lblShowSegmentDetail As DotNetNuke.UI.UserControls.LabelControl
        'Protected WithEvents pnlSegmentDetailsType As System.Web.UI.WebControls.Panel
        'Protected WithEvents lblSegmentDetailsType As System.Web.UI.WebControls.Label
        'Protected WithEvents rdSegmentDetailsType As System.Web.UI.WebControls.RadioButtonList
        'Protected WithEvents lblSegmentDetailsActionURL As System.Web.UI.WebControls.Label
        'Protected WithEvents drpSegmentDetailsActionURL As DotNetNuke.UI.UserControls.UrlControl
        'Protected WithEvents pnlSegmentDetailsActionURL As System.Web.UI.WebControls.Panel
        Protected WithEvents lblAllowSegmentDetailsDelete As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents chkAllowSegmentDetailsDelete As System.Web.UI.WebControls.CheckBox


        'Group Action Controls
        Protected WithEvents rdDisplayOptionsAsGroupAction As System.Web.UI.WebControls.RadioButton

        Protected WithEvents pnlDisplayAsGroupAction As System.Web.UI.WebControls.Panel

        Protected WithEvents lblActionURLsGroup As System.Web.UI.WebControls.Label
        Protected WithEvents lblPrintRosterActionURLGroup As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpPrintRosterActionURLGroup As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblGroupEmailActionURLGroup As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpGroupEmailActionURLGroup As DotNetNuke.UI.UserControls.UrlControl
        'Protected WithEvents lblRenewActionURLGroup As DotNetNuke.UI.UserControls.LabelControl
        'Protected WithEvents drpRenewActionURLGroup As DotNetNuke.UI.UserControls.UrlControl


        Protected WithEvents rdDisplayOptionsAsGroupPurchaseConfirmation As System.Web.UI.WebControls.RadioButton

        Protected WithEvents pnlDisplayAsGroupPurchaseConfirmation As System.Web.UI.WebControls.Panel

        Protected WithEvents lblPurchaseConfirmationActionURLs As System.Web.UI.WebControls.Label
        Protected WithEvents lblBuyProductForSameGroupActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpBuyProductForSameGroupActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblBuyProductForDifferentGroupActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpBuyProductForDifferentGroupActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblCheckoutActionURL As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpCheckoutActionURL As DotNetNuke.UI.UserControls.UrlControl
        Protected WithEvents lblAffiliateListGroupPurchaseConfirm As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents drpAffiliateListGroupPurchaseConfirm As DotNetNuke.UI.UserControls.UrlControl


        Protected WithEvents lnkUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkCancel As System.Web.UI.WebControls.LinkButton

#End Region

#Region "Private Members"
        Private itemId As Integer
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                ' Determine ItemId
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Null.NullInteger()
                End If


                If Not Page.IsPostBack Then
                    LoadSettings()
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub lnkUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkUpdate.Click
            If Page.IsValid Then
                Try
                    UpdateSettings()
                    Response.Redirect(NavigateURL(), True)
                Catch ex As Exception
                    ProcessModuleLoadException(Me, ex)
                End Try
            End If
        End Sub

        Private Sub lnkCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        'Private Sub chkShowSegmentDetail_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowSegmentDetail.CheckedChanged
        'If chkShowSegmentDetail.Checked Then
        'pnlSegmentDetailsType.Visible = True
        'pnlSegmentDetailsActionURL.Visible = False
        'Select Case rdSegmentDetailsType.SelectedValue
        'Case "Miscellaneous"
        'pnlSegmentDetailsActionURL.Visible = False
        'Case "Geographic"
        'pnlSegmentDetailsActionURL.Visible = False
        'Case "Membership"
        'pnlSegmentDetailsActionURL.Visible = False
        'Case "Committee"
        'pnlSegmentDetailsActionURL.Visible = True
        'lblSegmentDetailsActionURL.Text = Localization.GetString("committeeLabel", LocalResourceFile)
        'Case "Employment"
        'pnlSegmentDetailsActionURL.Visible = True
        'lblSegmentDetailsActionURL.Text = Localization.GetString("employmentLabel", LocalResourceFile)
        'End Select
        'End If

        'End Sub

        'Private Sub rdSegmentDetailsType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdSegmentDetailsType.SelectedIndexChanged
        'Select Case rdSegmentDetailsType.SelectedValue
        'Case "Miscellaneous"
        'pnlSegmentDetailsActionURL.Visible = False
        'Case "Geographic"
        'pnlSegmentDetailsActionURL.Visible = False
        'Case "Membership"
        'pnlSegmentDetailsActionURL.Visible = False
        'Case "Committee"
        'pnlSegmentDetailsActionURL.Visible = True
        'lblSegmentDetailsActionURL.Text = Localization.GetString("committeeLabel", LocalResourceFile)
        'Case "Employment"
        'pnlSegmentDetailsActionURL.Visible = True
        'lblSegmentDetailsActionURL.Text = Localization.GetString("employmentLabel", LocalResourceFile)
        'End Select

        'End Sub

        Private Sub rdDisplayOptions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdDisplayOptionsAsRegularListing.CheckedChanged, rdDisplayOptionsAsGroupAction.CheckedChanged, rdDisplayOptionsAsGroupPurchaseConfirmation.CheckedChanged
            If rdDisplayOptionsAsRegularListing.Checked Then
                pnlDisplayAsRegularListing.Visible = True
                pnlDisplayAsGroupAction.Visible = False
                pnlDisplayAsGroupPurchaseConfirmation.Visible = False
            ElseIf rdDisplayOptionsAsGroupAction.Checked Then
                pnlDisplayAsRegularListing.Visible = False
                pnlDisplayAsGroupAction.Visible = True
                pnlDisplayAsGroupPurchaseConfirmation.Visible = False
            ElseIf rdDisplayOptionsAsGroupPurchaseConfirmation.Checked Then
                pnlDisplayAsRegularListing.Visible = False
                pnlDisplayAsGroupAction.Visible = False
                pnlDisplayAsGroupPurchaseConfirmation.Visible = True
            End If
        End Sub

        Private Sub rdShowGroupActionPanel_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdShowGroupActionPanel.CheckedChanged, rdShowGroupPurchasePanel.CheckedChanged
            If rdShowGroupPurchasePanel.Checked Then
                pnlShowGroupPurchasePanel.Visible = True
                pnlShowGroupActionPanel.Visible = False
            ElseIf rdShowGroupActionPanel.Checked Then
                pnlShowGroupPurchasePanel.Visible = False
                pnlShowGroupActionPanel.Visible = True
            End If
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
#Region " Helper functions"

        Private Sub LoadSettings()

            'With rdSegmentDetailsType.Items
            '.Insert(0, "Committee")
            '.Insert(1, "Membership")
            '.Insert(2, "Employment")
            '.Insert(3, "Geographic")
            '.Insert(4, "Miscellaneous")
            'End With

            If Not Settings(C_Display_Options) Is Nothing Then
                If CType(Settings(C_Display_Options), String) = "Regular" Then
                    rdDisplayOptionsAsRegularListing.Checked = True
                    rdDisplayOptionsAsGroupAction.Checked = False
                    rdDisplayOptionsAsGroupPurchaseConfirmation.Checked = False

                    pnlDisplayAsRegularListing.Visible = True
                    pnlDisplayAsGroupAction.Visible = False
                    pnlDisplayAsGroupPurchaseConfirmation.Visible = False

                    If (Settings(C_Page_Size) Is Nothing) Then
                        txtPageSize.Text = "10"
                    Else
                        txtPageSize.Text = CStr(Settings(C_Page_Size))
                    End If

                    If (Settings(C_Show_Search) Is Nothing) OrElse CType(Settings(C_Show_Search), String) = "N" Then
                        chkShowSearch.Checked = False
                    Else
                        chkShowSearch.Checked = True
                    End If

                    If (Not Settings(C_Show_Group_Panel) Is Nothing) Then
                        If CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                            pnlShowGroupPurchasePanel.Visible = False
                            pnlShowGroupActionPanel.Visible = True
                            rdShowGroupActionPanel.Checked = True

                            If Not Settings(C_Order_History_Action_URL) Is Nothing Then
                                drpOrderHistoryActionURL.Url = CStr(Settings(C_Order_History_Action_URL))
                            End If
                            If Not Settings(C_Print_Roster_Action_URL) Is Nothing Then
                                drpPrintRosterActionURL.Url = CStr(Settings(C_Print_Roster_Action_URL))
                            End If

                            If Not Settings(C_Employee_Action_URL) Is Nothing Then
                                drpEmployeeActionURL.Url = CStr(Settings(C_Employee_Action_URL))
                            End If
                            If Not Settings(C_Member_Action_URL) Is Nothing Then
                                drpMemberActionURL.Url = CStr(Settings(C_Member_Action_URL))
                            End If
                            If Not Settings(C_Group_Email_Action_URL) Is Nothing Then
                                drpGroupEmailActionURL.Url = CStr(Settings(C_Group_Email_Action_URL))
                            End If
                            'If Not Settings(C_Create_Order_Action_URL) Is Nothing Then
                            'drpCreateOrderActionURL.Url = CStr(Settings(C_Create_Order_Action_URL))
                            'End If
                            If Not Settings(C_Profile_Action_URL) Is Nothing Then
                                drpProfileActionURL.Url = CStr(Settings(C_Profile_Action_URL))
                            End If
                            If Not Settings(C_Renew_Action_URL) Is Nothing Then
                                drpRenewActionURL.Url = CStr(Settings(C_Renew_Action_URL))
                            End If



                            If (Settings(C_Allow_Segment_Details_Delete) Is Nothing) OrElse CType(Settings(C_Allow_Segment_Details_Delete), String) = "N" Then
                                chkAllowSegmentDetailsDelete.Checked = False
                            Else
                                chkAllowSegmentDetailsDelete.Checked = True
                            End If


                            'If (Settings(C_Show_Phone) Is Nothing) OrElse CType(Settings(C_Show_Phone), String) = "N" Then
                            'chkShowPhone.Checked = False
                            'Else
                            'chkShowPhone.Checked = True
                            'End If



                            'If (Settings(C_Show_Segment_Detail) Is Nothing) OrElse CType(Settings(C_Show_Segment_Detail), String) = "N" Then
                            'chkShowSegmentDetail.Checked = False
                            'pnlSegmentDetailsType.Visible = False
                            'pnlSegmentDetailsActionURL.Visible = False
                            'Else
                            'chkShowSegmentDetail.Checked = True
                            'pnlSegmentDetailsType.Visible = True
                            'If Not Settings(C_Segment_Details_Type) Is Nothing Then
                            'If Not rdSegmentDetailsType.Items.FindByValue(CStr(Settings(C_Segment_Details_Type))) Is Nothing Then
                            'rdSegmentDetailsType.Items.FindByValue(CStr(Settings(C_Segment_Details_Type))).Selected = True
                            'End If
                            'End If

                            'Select Case CType(Settings(C_Segment_Details_Type), String)
                            'Case "Miscellaneous"
                            'pnlSegmentDetailsActionURL.Visible = False
                            'Case "Membership"
                            'pnlSegmentDetailsActionURL.Visible = False
                            'Case "Geographic"
                            'pnlSegmentDetailsActionURL.Visible = False
                            'Case "Committee"
                            'pnlSegmentDetailsActionURL.Visible = True
                            'If Not Settings(C_Segment_Details_Action_URL) Is Nothing Then
                            'drpSegmentDetailsActionURL.Url = CStr(Settings(C_Segment_Details_Action_URL))
                            'End If
                            'lblSegmentDetailsActionURL.Text = Localization.GetString("committeeLabel", LocalResourceFile)
                            'If (Settings(C_Allow_Segment_Details_Delete) Is Nothing) OrElse CType(Settings(C_Allow_Segment_Details_Delete), String) = "N" Then
                            'chkAllowSegmentDetailsDelete.Checked = False
                            'Else
                            'chkAllowSegmentDetailsDelete.Checked = True
                            'End If

                            'Case "Employment"
                            'pnlSegmentDetailsActionURL.Visible = True
                            'If Not Settings(C_Segment_Details_Action_URL) Is Nothing Then
                            'drpSegmentDetailsActionURL.Url = CStr(Settings(C_Segment_Details_Action_URL))
                            'End If
                            'lblSegmentDetailsActionURL.Text = Localization.GetString("employmentLabel", LocalResourceFile)
                            'If (Settings(C_Allow_Segment_Details_Delete) Is Nothing) OrElse CType(Settings(C_Allow_Segment_Details_Delete), String) = "N" Then
                            'chkAllowSegmentDetailsDelete.Checked = False
                            'Else
                            'chkAllowSegmentDetailsDelete.Checked = True
                            'End If
                            'End Select
                            'End If

                        ElseIf CStr(Settings(C_Show_Group_Panel)) = "GroupPurchase" Then
                            pnlShowGroupPurchasePanel.Visible = True
                            pnlShowGroupActionPanel.Visible = False

                            rdShowGroupPurchasePanel.Checked = True

                            If Not Settings(C_Purchase_Action_URL) Is Nothing Then
                                drpPurchaseActionURL.Url = CStr(Settings(C_Purchase_Action_URL))
                            End If

                        End If

                    End If

                ElseIf CType(Settings(C_Display_Options), String) = "GroupAction" Then
                    rdDisplayOptionsAsRegularListing.Checked = False
                    rdDisplayOptionsAsGroupAction.Checked = True
                    rdDisplayOptionsAsGroupPurchaseConfirmation.Checked = False

                    pnlDisplayAsRegularListing.Visible = False
                    pnlDisplayAsGroupAction.Visible = True
                    pnlDisplayAsGroupPurchaseConfirmation.Visible = False

                    If Not Settings(C_Print_Roster_Action_URL) Is Nothing Then
                        drpPrintRosterActionURLGroup.Url = CStr(Settings(C_Print_Roster_Action_URL))
                    End If
                    If Not Settings(C_Group_Email_Action_URL) Is Nothing Then
                        drpGroupEmailActionURLGroup.Url = CStr(Settings(C_Group_Email_Action_URL))
                    End If
                    'If Not Settings(C_Renew_Action_URL) Is Nothing Then
                    'drpRenewActionURLGroup.Url = CStr(Settings(C_Renew_Action_URL))
                    'End If
                    If Not Settings(C_Buy_Product_Action_URL) Is Nothing Then
                        drpBuyProductActionURL.Url = CStr(Settings(C_Buy_Product_Action_URL))
                    End If


                ElseIf CType(Settings(C_Display_Options), String) = "PurchaseConfirmation" Then
                    rdDisplayOptionsAsRegularListing.Checked = False
                    rdDisplayOptionsAsGroupAction.Checked = False
                    rdDisplayOptionsAsGroupPurchaseConfirmation.Checked = True

                    pnlDisplayAsRegularListing.Visible = False
                    pnlDisplayAsGroupAction.Visible = False
                    pnlDisplayAsGroupPurchaseConfirmation.Visible = True

                    If Not Settings(C_Buy_Product_For_Same_Group_Action_URL) Is Nothing Then
                        drpBuyProductForSameGroupActionURL.Url = CStr(Settings(C_Buy_Product_For_Same_Group_Action_URL))
                    End If
                    If Not Settings(C_Buy_Product_For_Different_Group_Action_URL) Is Nothing Then
                        drpBuyProductForDifferentGroupActionURL.Url = CStr(Settings(C_Buy_Product_For_Different_Group_Action_URL))
                    End If
                    If Not Settings(C_Checkout_Action_URL) Is Nothing Then
                        drpCheckoutActionURL.Url = CStr(Settings(C_Checkout_Action_URL))
                    End If
                    If Not Settings(C_AFFILIATELIST_GROUP_PURCHASE_CONFIRM_ACTION_URL) Is Nothing Then
                        drpAffiliateListGroupPurchaseConfirm.Url = CStr(Settings(C_AFFILIATELIST_GROUP_PURCHASE_CONFIRM_ACTION_URL))
                    End If


                End If

            Else
                rdDisplayOptionsAsRegularListing.Checked = False
                rdDisplayOptionsAsGroupAction.Checked = False
                rdDisplayOptionsAsGroupPurchaseConfirmation.Checked = False

                pnlDisplayAsRegularListing.Visible = False
                pnlDisplayAsGroupAction.Visible = False
                pnlDisplayAsGroupPurchaseConfirmation.Visible = False
            End If


        End Sub

        Private Sub UpdateSettings()

            Dim objModules As New Entities.Modules.ModuleController


            objModules.UpdateModuleSetting(Me.ModuleId, Setting_OnDemandDataLoad, chkEnableOnDemand.Checked.ToString)
            If rdDisplayOptionsAsRegularListing.Checked Then

                objModules.UpdateModuleSetting(Me.ModuleId, C_Display_Options, "Regular")

                If txtPageSize.Text = String.Empty Or txtPageSize.Text = "0" Then
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Page_Size, "10")
                Else
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Page_Size, txtPageSize.Text)
                End If

                If chkShowSearch.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Search, "Y")
                Else
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Search, "N")
                End If


                If rdShowGroupActionPanel.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Group_Panel, "GroupAction")


                    objModules.UpdateModuleSetting(Me.ModuleId, C_Order_History_Action_URL, drpOrderHistoryActionURL.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Print_Roster_Action_URL, drpPrintRosterActionURL.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Employee_Action_URL, drpEmployeeActionURL.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Member_Action_URL, drpMemberActionURL.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Group_Email_Action_URL, drpGroupEmailActionURL.Url)
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Create_Order_Action_URL, drpCreateOrderActionURL.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Profile_Action_URL, drpProfileActionURL.Url)
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Renew_Action_URL, drpRenewActionURL.Url)

                    'If chkShowPhone.Checked Then
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Phone, "Y")
                    'Else
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Phone, "N")
                    'End If

                    If chkAllowSegmentDetailsDelete.Checked Then
                        objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "Y")
                    Else
                        objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "N")
                    End If

                    'If chkShowSegmentDetail.Checked Then
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Segment_Detail, "Y")
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Segment_Details_Type, rdSegmentDetailsType.SelectedValue)

                    'Select Case rdSegmentDetailsType.SelectedValue
                    'Case "Committee"
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Segment_Details_Action_URL, drpSegmentDetailsActionURL.Url)
                    'If chkAllowSegmentDetailsDelete.Checked Then
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "Y")
                    'Else
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "N")
                    'End If
                    'Case "Employment"
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Segment_Details_Action_URL, drpSegmentDetailsActionURL.Url)
                    'If chkAllowSegmentDetailsDelete.Checked Then
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "Y")
                    'Else
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "N")
                    'End If
                    'End Select



                    'Else
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Segment_Detail, "N")
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Segment_Details_Type, "")
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Segment_Details_Action_URL, "")
                    'objModules.UpdateModuleSetting(Me.ModuleId, C_Allow_Segment_Details_Delete, "N")
                    'End If

                ElseIf Me.rdShowGroupPurchasePanel.Checked Then
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Show_Group_Panel, "GroupPurchase")
                    objModules.UpdateModuleSetting(Me.ModuleId, C_Purchase_Action_URL, drpPurchaseActionURL.Url)
                End If
            ElseIf rdDisplayOptionsAsGroupAction.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_Display_Options, "GroupAction")
                objModules.UpdateModuleSetting(Me.ModuleId, C_Print_Roster_Action_URL, drpPrintRosterActionURLGroup.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_Group_Email_Action_URL, drpGroupEmailActionURLGroup.Url)
                'objModules.UpdateModuleSetting(Me.ModuleId, C_Renew_Action_URL, drpRenewActionURLGroup.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_Buy_Product_Action_URL, drpBuyProductActionURL.Url)

            ElseIf rdDisplayOptionsAsGroupPurchaseConfirmation.Checked Then
                objModules.UpdateModuleSetting(Me.ModuleId, C_Display_Options, "PurchaseConfirmation")
                objModules.UpdateModuleSetting(Me.ModuleId, C_Buy_Product_For_Same_Group_Action_URL, drpBuyProductForSameGroupActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_Buy_Product_For_Different_Group_Action_URL, drpBuyProductForDifferentGroupActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_Checkout_Action_URL, drpCheckoutActionURL.Url)
                objModules.UpdateModuleSetting(Me.ModuleId, C_AFFILIATELIST_GROUP_PURCHASE_CONFIRM_ACTION_URL, drpAffiliateListGroupPurchaseConfirm.Url)
            End If


            objModules = Nothing
        End Sub

#End Region

    End Class

End Namespace
