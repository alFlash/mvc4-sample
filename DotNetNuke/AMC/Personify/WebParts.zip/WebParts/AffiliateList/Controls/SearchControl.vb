Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Web.UI.HtmlControls
Imports System.Text


Namespace Personify.DNN.Modules.AffiliateList
    <Description(""), ToolboxData("<{0}:SearchControl runat=server></{0}:SearchControl>")> _
    Public Class SearchControl
        Inherits CompositeControl

#Region " Controls "
        Private lblSearchBy As Label
        Private lstSearchFields As DropDownList
        Private txtSearchText As TextBox

        Private m_ShowAllVisible As Boolean = False

#End Region

#Region "Constants"
        Private Const C_SEGMENT_EMPLOYEE As String = "EMPLOYEE"
        Private Const C_SEGMENT_MEMBERSHIP As String = "PRODUCT"
        Private Const C_SEGMENT_GEOGRAPHIC As String = "GEOGRAPHY"
        Private Const C_SEGMENT_COMMITTEE As String = "COMMITTEE"
        Private Const C_SEGMENT_MISCELLANEOUS As String = "MISCELLANEOUS"
#End Region

#Region "Controls Properties"

        'the string "Search Type"
        Public Property SearchType() As String
            Get
                Return CStr(ViewState("SearchType"))
            End Get

            Set(ByVal value As String)
                ViewState("SearchType") = value
            End Set
        End Property
        'the string "Search By"
        Public Property SearchBy() As String
            Get
                Return CStr(ViewState("SearchBy"))
            End Get

            Set(ByVal value As String)
                ViewState("SearchBy") = value
            End Set
        End Property
        'the string "ShowAllVisible"
        Public Property ShowAllVisible() As Boolean
            Get
                Return m_ShowAllVisible
            End Get

            Set(ByVal value As Boolean)
                m_ShowAllVisible = value
            End Set
        End Property
        'the string shown on the link "Show All"
        Public Property ShowAll() As String
            Get
                Return CStr(ViewState("ShowAll"))
            End Get

            Set(ByVal value As String)
                ViewState("ShowAll") = value
            End Set
        End Property

        'the text from the button "Search"
        Public Property Search() As String
            Get
                Return CStr(ViewState("Search"))
            End Get

            Set(ByVal value As String)
                ViewState("Search") = value
            End Set
        End Property


        'set/get the content of the TextBox Search
        Public Property SearchText() As String
            Get
                Return txtSearchText.Text
            End Get
            Set(ByVal value As String)
                txtSearchText.Text = value
            End Set
        End Property

        'set/get the content of the DropDownList SearchBy
        Public Property SearchFieldsValue() As String
            Get
                Return lstSearchFields.SelectedValue
            End Get
            Set(ByVal value As String)
                lstSearchFields.SelectedValue = value
            End Set
        End Property
        'set/get the index of the DropDownList SearchBy
        Public Property SearchFieldsIndex() As Integer
            Get
                Return lstSearchFields.SelectedIndex
            End Get
            Set(ByVal value As Integer)
                lstSearchFields.SelectedIndex = value
            End Set
        End Property


        'the LocalResourceFile 
        Public Property LocalResourceFile() As String
            Get
                Return CStr(ViewState("LocalResourceFile"))
            End Get
            Set(ByVal value As String)
                ViewState("LocalResourceFile") = value
            End Set
        End Property

        '3246-5774803
        Public Property ArrowImageURL() As String
            Get
                Return CStr(ViewState("ArrowImageURL"))
            End Get
            Set(ByVal value As String)
                ViewState("ArrowImageURL") = value
            End Set
        End Property
        'end 3246-5774803

#End Region


#Region "Create Control Overrides "
        Protected Overrides Sub CreateChildControls()
            ' Setup the controls on the page
            Dim table As New HtmlTable

            If Page.IsPostBack Then
                Dim sField As String = String.Empty
                Dim sValue As String = String.Empty

                'read searchField and searchValue
                For Each key As String In Page.Request.Params.AllKeys
                    If key IsNot Nothing Then
                        If key.IndexOf("lstSearchFields") >= 0 Then
                            sField = Page.Request.Params(key)
                        End If
                        If key.IndexOf("txtSearchText") >= 0 Then
                            sValue = Page.Request.Params(key)
                        End If
                    End If
                Next
                If sValue = String.Empty Or sField = String.Empty Then
                    'if it wasn't a search action the ShowAll link is hidden
                    ShowAllVisible = False
                Else
                    'if it was a search action the ShowAll link is shown
                    ShowAllVisible = True
                End If
                If Page.Request("__EVENTARGUMENT") = "ShowAll" Then
                    'if ShowAll was clicked ShowAll link is hidden
                    ShowAllVisible = False
                End If
            End If

            ' set table attributes
            With table
                .Border = 0
                .ApplyStyleSheetSkin(Page)
                '.Width = Unit.Percentage(100).ToString
                '.Height = "100px"
                .CellSpacing = 1
                .CellPadding = 15
                .Attributes.Add("class", "tmar_FormTable")
            End With

            'Search button
            Dim innerHTMLSearch As StringBuilder = New StringBuilder()
            '3246-5774803
            innerHTMLSearch.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""javascript:if(searchCriterias()) {1}; else alert('{4}');"">&nbsp; {2}<img src=""{3}"" />&nbsp;</a></div>", Me.UniqueID, Page.ClientScript.GetPostBackEventReference(Me, "Search"), Search, ArrowImageURL, Localization.GetString("MissingSearchingCriteria", LocalResourceFile))
            'end 3246-5774803

            'SearchAll button
            Dim innerHTMLSearchAll As StringBuilder = New StringBuilder()
            If ShowAllVisible Then
                innerHTMLSearchAll.AppendFormat("<a id=""{0}"" href=""javascript:{1}"">{2}&nbsp;</a></div>", Me.UniqueID, Page.ClientScript.GetPostBackEventReference(Me, "ShowAll"), ShowAll)
            End If


            ' Put the controls inside a table
            table.Rows.Add(CreateHtmlTableRow( _
                    CreateControlInHtmlCell(lblSearchBy, "lblSearchBy", SearchBy), _
                    CreateControlInHtmlCell(lstSearchFields, "lstSearchFields", ""), _
                    CreateControlInHtmlCell(txtSearchText, "txtSearchText", ""), _
                    CreateSearchButtonInHtmlCell(innerHTMLSearch.ToString), _
                    CreateSearchButtonInHtmlCell(innerHTMLSearchAll.ToString)))

            Controls.Add(table)

            'JavaScript code to check if searching criteria was selected
            Dim InitializeJS As StringBuilder = New StringBuilder()
            InitializeJS.AppendLine("<script language='javascript'>")
            InitializeJS.AppendLine("function returnObjByIdentifier(id)")
            InitializeJS.AppendLine("{")
            InitializeJS.AppendLine("if (document.getElementById) ")
            InitializeJS.AppendLine("{var returnVar = document.getElementById(id);}")
            InitializeJS.AppendLine("else if (document.all) ")
            InitializeJS.AppendLine("{var returnVar = document.all[id];}")
            InitializeJS.AppendLine("else if (document.layers)")
            InitializeJS.AppendLine("{var returnVar = document.layers[id];}")
            InitializeJS.AppendLine("return returnVar;")
            InitializeJS.AppendLine("}")

            InitializeJS.AppendLine("function searchCriterias(){")
            Dim lstSearchFieldsClientId As String = CType(FindControl("lstSearchFields"), DropDownList).ClientID
            Dim txtSearchTextClientId As String = CType(FindControl("txtSearchText"), TextBox).ClientID
            InitializeJS.AppendLine("lstSearchFields = returnObjByIdentifier('" & lstSearchFieldsClientId & "');")
            InitializeJS.AppendLine("txtSearchText = returnObjByIdentifier('" & txtSearchTextClientId & "');")
            InitializeJS.AppendLine("if ((lstSearchFields.selectedIndex == 0) || (txtSearchText.value == """")) {return false;}")
            InitializeJS.AppendLine("else {return true;}")
            InitializeJS.AppendLine("}")
            InitializeJS.AppendLine("</script>")

            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "InitializeJS", InitializeJS.ToString)


        End Sub

#End Region

#Region " Create HTML Table , Rows and Cells "

        Private Function CreateHtmlTableRow(ByVal ParamArray HtmlCells() As HtmlTableCell) As HtmlTableRow
            Dim tablerow As New HtmlTableRow
            Dim i As Integer = 0
            For Each Cell As HtmlTableCell In HtmlCells

                If Not Cell Is Nothing Then

                    If i = 0 Then ' this is the first column
                        Cell.NoWrap = True
                        'Cell.Attributes.Add("style", "width: 150px")
                    End If

                    tablerow.Cells.Add(Cell)
                End If

                i += 1
            Next

            Return tablerow
        End Function
        Private Overloads Function CreateSearchButtonInHtmlCell(ByVal innerHtml As String) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            tablecell.InnerHtml = innerHtml
            'tablecell.Attributes.Add("style", "width: 250px")

            'tablecell.Controls.Add(Control)

            Return tablecell

        End Function
        Private Overloads Function CreateControlInHtmlCell(ByRef Control As DropDownList, _
                ByVal ID As String, ByVal Text As String) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function

        Private Overloads Function CreateControlInHtmlCell(ByRef Control As Button, _
        ByVal ID As String, ByVal Text As String, ByVal NavigateURL As String) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function
        Private Overloads Function CreateControlInHtmlCell(ByRef Control As LinkButton, _
                ByVal ID As String, ByVal Text As String) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function
        Private Overloads Function CreateControlInHtmlCell(ByRef Control As HyperLink, _
        ByVal ID As String, ByVal Text As String, ByVal NavigateURL As String) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text, NavigateURL)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function

        Private Overloads Function CreateControlInHtmlCell(ByRef Control As Label, _
        ByVal ID As String, ByVal Text As String, _
                  Optional ByVal Width As Integer = -1) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text, Width)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function



        Private Overloads Function CreateControlInHtmlCell(ByRef Control As TextBox, ByVal ID As String, ByVal Text As String, _
                      Optional ByVal Width As Integer = -1, _
                      Optional ByVal EnableViewState As Boolean = False, _
                      Optional ByVal MaxLength As Integer = -1) As HtmlTableCell


            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text, Width, EnableViewState, MaxLength)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function


        Private Overloads Sub SetControlProperties(ByRef Control As DropDownList, ByVal ID As String, ByVal Text As String)
            Control = New DropDownList
            With Control
                .ID = ID
                With .Items

                    Dim searchList() As String = Nothing
                    Select Case SearchType
                        Case C_SEGMENT_EMPLOYEE
                            searchList = Localization.GetString("EmploymentSearchOptionsList", LocalResourceFile).Split(CChar("|"))
                        Case C_SEGMENT_MEMBERSHIP
                            searchList = Localization.GetString("MembershipSearchOptionsList", LocalResourceFile).Split(CChar("|"))
                        Case C_SEGMENT_GEOGRAPHIC
                            searchList = Localization.GetString("GeographicSearchOptionsList", LocalResourceFile).Split(CChar("|"))
                        Case C_SEGMENT_COMMITTEE
                            searchList = Localization.GetString("CommitteeSearchOptionsList", LocalResourceFile).Split(CChar("|"))
                        Case C_SEGMENT_MISCELLANEOUS
                            searchList = Localization.GetString("MiscellaneousSearchOptionsList", LocalResourceFile).Split(CChar("|"))
                    End Select
                    Dim i As Integer = 0
                    While i < searchList.Length - 1
                        .Add(New ListItem(searchList(i), searchList(i + 1)))
                        i = i + 2
                    End While
                    .Insert(0, New ListItem(Localization.GetString("ChooseOneMessage", LocalResourceFile), ""))
                End With
            End With

        End Sub
        Private Overloads Sub SetControlProperties(ByRef Control As HyperLink, ByVal ID As String, ByVal Text As String, ByVal NavigateURL As String)
            Control = New HyperLink
            With Control
                .ID = ID
                .Text = Text
                .NavigateUrl = NavigateURL
            End With
        End Sub
        Private Overloads Sub SetControlProperties(ByRef Control As LinkButton, ByVal ID As String, ByVal Text As String)
            Control = New LinkButton
            With Control
                .ID = ID
                .Text = Text
            End With
        End Sub

        Private Overloads Sub SetControlProperties(ByRef Control As Button, ByVal ID As String, ByVal Text As String)
            Control = New Button
            With Control
                .ID = ID
                .Text = Text
            End With
        End Sub


        Private Overloads Sub SetControlProperties(ByRef Control As Label, ByVal ID As String, ByVal Text As String, _
                Optional ByVal Width As Integer = -1)
            Control = New Label
            With Control
                .ID = ID
                .Text = Text
                If Width <> -1 Then
                    .Width = Unit.Percentage(Width)
                End If

            End With
        End Sub



        Private Overloads Sub SetControlProperties(ByRef Control As TextBox, ByVal ID As String, ByVal Text As String, _
                   Optional ByVal Width As Integer = -1, Optional ByVal EnableViewState As Boolean = False, Optional ByVal MaxLength As Integer = -1)
            Control = New TextBox
            With Control
                .ID = ID
                .Text = Text
                If Width <> -1 Then
                    .Width = Width
                End If
                .EnableViewState = EnableViewState
                If MaxLength <> -1 Then
                    .MaxLength = MaxLength
                End If
            End With
        End Sub


#End Region

#Region "Handle Click"

        ' Defines the Click event.
        Public Event Click As EventHandler

        ' Invokes delegates registered with the Click event.

        Protected Overridable Sub OnClick(ByVal e As EventArgs)

            If Not ClickEvent Is Nothing Then
                RaiseEvent Click(Me, e)
            End If
        End Sub
#End Region

    End Class
End Namespace