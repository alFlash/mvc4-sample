Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Web.UI.HtmlControls
Imports System.Text

Namespace Personify.DNN.Modules.AffiliateList

    <Description(""), ToolboxData("<{0}:MemberActions runat=server></{0}:MemberActions>")> _
    Public Class MemberActions
        Inherits CompositeControl


#Region "Controls"
        Private lblApplyTo As Label
        Private rdApplyTo As RadioButtonList

        Private m_RenewVisible As Boolean = True
        Private m_PrintRosterVisible As Boolean = True
        Private m_SendEmailVisible As Boolean = True
        'Private m_AddMemberVisible As Boolean = True

        Private m_PurchaseForAllVisible As Boolean = True
        Private m_PurchaseForSelectedVisible As Boolean = True
#End Region

#Region "Controls Properties"

        'the string "ApplyTo"
        Public Property ApplyToText() As String
            Get
                Return CStr(ViewState("ApplyToText"))
            End Get

            Set(ByVal value As String)
                ViewState("ApplyToText") = value
            End Set
        End Property
        'the string "AllEmployeesText"
        Public Property AllEmployeesText() As String
            Get
                Return CStr(ViewState("AllEmployeesText"))
            End Get

            Set(ByVal value As String)
                ViewState("AllEmployeesText") = value
            End Set
        End Property
        'the string "SelectedText"
        Public Property SelectedText() As String
            Get
                Return CStr(ViewState("SelectedText"))
            End Get

            Set(ByVal value As String)
                ViewState("SelectedText") = value
            End Set
        End Property
        
        'Renew button Visiblity
        Public Property RenewVisible() As Boolean
            Get
                Return m_RenewVisible
            End Get

            Set(ByVal value As Boolean)
                m_RenewVisible = value
            End Set
        End Property
        'the string shown on the link "Renew"
        Public Property RenewText() As String
            Get
                Return CStr(ViewState("RenewText"))
            End Get

            Set(ByVal value As String)
                ViewState("RenewText") = value
            End Set
        End Property
        'the link for "Renew"
        Public Property RenewNavigateURL() As String
            Get
                Return CStr(ViewState("RenewNavigateURL"))
            End Get

            Set(ByVal value As String)
                ViewState("RenewNavigateURL") = value
            End Set
        End Property

        'PrintRoster button Visiblity
        Public Property PrintRosterVisible() As Boolean
            Get
                Return m_PrintRosterVisible
            End Get

            Set(ByVal value As Boolean)
                m_PrintRosterVisible = value
            End Set
        End Property
        'the string shown on the link "PrintRoster"
        Public Property PrintRosterText() As String
            Get
                Return CStr(ViewState("PrintRosterText"))
            End Get

            Set(ByVal value As String)
                ViewState("PrintRosterText") = value
            End Set
        End Property
        Public Property PrintRosterNavigateURL() As String
            Get
                Return CStr(ViewState("PrintRosterNavigateURL"))
            End Get

            Set(ByVal value As String)
                ViewState("PrintRosterNavigateURL") = value
            End Set
        End Property

        Public Property ConfirmPrintRosterMessage() As String
            Get
                Return CStr(ViewState("ConfirmPrintRosterMessage"))
            End Get

            Set(ByVal value As String)
                ViewState("ConfirmPrintRosterMessage") = value
            End Set
        End Property

        'SendEmail button Visiblity
        Public Property SendEmailVisible() As Boolean
            Get
                Return m_SendEmailVisible
            End Get

            Set(ByVal value As Boolean)
                m_SendEmailVisible = value
            End Set
        End Property
        'the string shown on the link "SendEmail"
        Public Property SendEmailText() As String
            Get
                Return CStr(ViewState("SendEmailText"))
            End Get

            Set(ByVal value As String)
                ViewState("SendEmailText") = value
            End Set
        End Property
        'link for SendEmail
        Public Property SendEmailNavigateURL() As String
            Get
                Return CStr(ViewState("SendEmailNavigateURL"))
            End Get

            Set(ByVal value As String)
                ViewState("SendEmailNavigateURL") = value
            End Set
        End Property

        Public Property ConfirmSendEmailMessage() As String
            Get
                Return CStr(ViewState("ConfirmSendEmailMessage"))
            End Get

            Set(ByVal value As String)
                ViewState("ConfirmSendEmailMessage") = value
            End Set
        End Property

        'AddMember button Visiblity
        Public Property AddMemberVisible() As Boolean
            Get
                Return CBool(ViewState("AddMemberVisible"))
            End Get

            Set(ByVal value As Boolean)
                ViewState("AddMemberVisible") = value
            End Set
        End Property
        'the string shown on the link "AddMember"
        Public Property AddMemberText() As String
            Get
                Return CStr(ViewState("AddMemberText"))
            End Get

            Set(ByVal value As String)
                ViewState("AddMemberText") = value
            End Set
        End Property

        'the NavigateURL for link "AddMember"
        Public Property AddMemberNavigateURL() As String
            Get
                Return CStr(ViewState("AddMemberNavigateURL"))
            End Get

            Set(ByVal value As String)
                ViewState("AddMemberNavigateURL") = value
            End Set
        End Property

        'Purchase for all button Visiblity
        Public Property PurchaseForAllVisible() As Boolean
            Get
                Return m_PurchaseForAllVisible
            End Get

            Set(ByVal value As Boolean)
                m_PurchaseForAllVisible = value
            End Set
        End Property
        'the string shown on "PurchaseForAll"
        Public Property PurchaseForAllText() As String
            Get
                Return CStr(ViewState("PurchaseForAllText"))
            End Get

            Set(ByVal value As String)
                ViewState("PurchaseForAllText") = value
            End Set
        End Property

        'the NavigateURL for "PurchaseForAll"
        Public Property PurchaseForAllNavigateURL() As String
            Get
                Return CStr(ViewState("PurchaseForAllNavigateURL"))
            End Get

            Set(ByVal value As String)
                ViewState("PurchaseForAllNavigateURL") = value
            End Set
        End Property

        'Purchase for selected button Visiblity
        Public Property PurchaseForSelectedVisible() As Boolean
            Get
                Return m_PurchaseForSelectedVisible
            End Get

            Set(ByVal value As Boolean)
                m_PurchaseForSelectedVisible = value
            End Set
        End Property
        'the string shown on "PurchaseForSelected"
        Public Property PurchaseForSelectedText() As String
            Get
                Return CStr(ViewState("PurchaseForSelectedText"))
            End Get

            Set(ByVal value As String)
                ViewState("PurchaseForSelectedText") = value
            End Set
        End Property

        'the NavigateURL for "PurchaseForSelected"
        Public Property PurchaseForSelectedNavigateURL() As String
            Get
                Return CStr(ViewState("PurchaseForSelectedNavigateURL"))
            End Get

            Set(ByVal value As String)
                ViewState("PurchaseForSelectedNavigateURL") = value
            End Set
        End Property

        Public Property ConfirmPurchaseMessage() As String
            Get
                Return CStr(ViewState("ConfirmPurchaseMessage"))
            End Get

            Set(ByVal value As String)
                ViewState("ConfirmPurchaseMessage") = value
            End Set
        End Property

        'the GroupPurchasePanel
        Public Property GroupPurchasePanelVisible() As Boolean
            Get
                Return CBool(ViewState("GroupPurchasePanelVisible"))
            End Get

            Set(ByVal value As Boolean)
                ViewState("GroupPurchasePanelVisible") = value
            End Set
        End Property

        'the GroupActionPanel
        Public Property GroupActionPanelVisible() As Boolean
            Get
                Return CBool(ViewState("GroupActionPanelVisible"))
            End Get

            Set(ByVal value As Boolean)
                ViewState("GroupActionPanelVisible") = value
            End Set
        End Property


       

#End Region


#Region "Create Control Overrides "
        Protected Overrides Sub CreateChildControls()

            Dim table As New HtmlTable


            ' set table attributes
            With table
                .Border = 0
                .Width = Unit.Percentage(100).ToString
                .CellSpacing = 1
                .CellPadding = 3
                .Attributes.Add("class", "tmar_Subhead3")
                .ApplyStyleSheetSkin(Page)
            End With
            If GroupActionPanelVisible Then
                ' Setup the controls on the page

                Dim table1 As New HtmlTable

                With table1
                    .Border = 0
                    .ApplyStyleSheetSkin(Page)
                    '.Width = Unit.Percentage(100).ToString
                    .CellSpacing = 1
                    .CellPadding = 3
                    '.Attributes.Add("class", "tmar_FormTable")
                End With

                'AddMember button
                Dim lnkAddMember As StringBuilder = New StringBuilder()
                lnkAddMember.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""{1}"">&nbsp; {2}&nbsp;</a></div>", Me.UniqueID, AddMemberNavigateURL, AddMemberText)
                'Dim lnkRenew As StringBuilder = New StringBuilder()
                'lnkRenew.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""{1}"">&nbsp; {2}&nbsp;</a></div>", Me.UniqueID, RenewNavigateURL, RenewText)

                'PrintRoster button
                Dim lnkPrintRoster As StringBuilder = New StringBuilder()
                'postback event if PrintRoster clicked
                Dim postBack As String = "{" & Page.ClientScript.GetPostBackEventReference(Me, "PrintRoster") & ";}"
                'JavaScript code for confirmation window if AllEmployees radio is checked
                Dim js As String = "if (allEmployees" & Me.ClientID & "()){if (confirm('" & ConfirmPrintRosterMessage & "'))" & postBack & ";}else " & postBack & ";"
                lnkPrintRoster.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""javascript:{1}"">&nbsp; {2}&nbsp;</a></div>", Me.UniqueID, js, PrintRosterText)

                'SendEmail button
                Dim lnkSendEmail As StringBuilder = New StringBuilder()
                'postback event if SendEmail is clicked
                postBack = "{" & Page.ClientScript.GetPostBackEventReference(Me, "SendEmail") & ";}"
                'JavaScript code for confirmation window if Allemployees radio is checked
                js = "if (allEmployees" & Me.ClientID & "()){if (confirm('" & ConfirmSendEmailMessage & "'))" & postBack & ";}else " & postBack & ";"
                lnkSendEmail.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""javascript:{1}"">&nbsp; {2}&nbsp;</a></div>", Me.UniqueID, js, SendEmailText)


                ' Put the controls inside a table
                table1.Rows.Add(CreateHtmlTableRow( _
                        CreateControlInHtmlCell(lblApplyTo, "lblApplyTo", ApplyToText), _
                        CreateControlInHtmlCell(rdApplyTo, "rdApplyTo"), _
                        CreateLinkButtonInHtmlCell(lnkPrintRoster.ToString, PrintRosterVisible), _
                        CreateLinkButtonInHtmlCell(lnkSendEmail.ToString, SendEmailVisible) _
                        ))
                'CreateLinkButtonInHtmlCell(lnkRenew.ToString, RenewVisible), _



                ' Create a new table to display the "Add Employee  / Add Member" button
                'table2.Rows.Add(CreateHtmlTableRow(CreateLinkButtonInHtmlCell(lnkAddMember.ToString, AddMemberVisible, "right")))

                ' Main table : Contains table1 & table2

                table.Rows.Add(CreateHtmlTableRow(CreateControlInHtmlCell(table1, "table1"), _
                                                  CreateLinkButtonInHtmlCell(lnkAddMember.ToString, AddMemberVisible, "right")))


                Controls.Add(table)

                'JavaScript code to check if searching criteria was selected
                Dim InitializeJS As StringBuilder = New StringBuilder()
                InitializeJS.AppendLine("<script language='javascript'>")

                InitializeJS.AppendLine("function allEmployees" & Me.ClientID & "(){")
                Dim rdApplyToClientId As String = CType(FindControl("rdApplyTo"), RadioButtonList).ClientID
                InitializeJS.AppendLine("rdList = document.getElementById(""" & rdApplyToClientId & "_0"");")
                InitializeJS.AppendLine("if (rdList.checked) {return true;}")
                InitializeJS.AppendLine("else {return false};")
                InitializeJS.AppendLine("}")
                InitializeJS.AppendLine("</script>")

                Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "InitializeJS" & Me.ClientID, InitializeJS.ToString)



            End If

            If GroupPurchasePanelVisible Then
                'Group Purchase panel visible
                Dim table2 As New HtmlTable

                With table2
                    .Border = 0
                    .CellSpacing = 1
                    .CellPadding = 9
                    .ApplyStyleSheetSkin(Page)
                    .Width = "500"
                    '.Attributes.Add("class", "tmar_FormTable")
                End With
                'Purchase For All button
                Dim lnkPurchaseForAll As StringBuilder = New StringBuilder()
                'postback event
                Dim postBack As String = "{" & Page.ClientScript.GetPostBackEventReference(Me, "PurchaseForAll") & ";}"
                'JavaScript code to open a confirmation window if Allemployees radio button is selected
                Dim js As String = "if (confirm('" & ConfirmPurchaseMessage & "'))" & postBack & ";"
                lnkPurchaseForAll.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""javascript:{1}"">&nbsp; {2}</a></div>", Me.UniqueID, js, PurchaseForAllText)

                'PurchaseForSelected button
                Dim lnkPurchaseForSelected As StringBuilder = New StringBuilder()
                lnkPurchaseForSelected.AppendFormat("<div class=""btn""><a class=""btna"" id=""{0}"" href=""javascript:{1}"">&nbsp; {2}</a></div>", Me.UniqueID, "{" & Page.ClientScript.GetPostBackEventReference(Me, "PurchaseForSelected") & ";}", PurchaseForSelectedText)


                ' Put the controls inside a table
                table2.Rows.Add(CreateHtmlTableRow( _
                       CreateLinkButtonInHtmlCell(lnkPurchaseForAll.ToString, PurchaseForAllVisible, "center"), _
                        CreateLinkButtonInHtmlCell(lnkPurchaseForSelected.ToString, PurchaseForSelectedVisible, "center")))

                'Dim oTableCell As HtmlTableCell = CreateLinkButtonInHtmlCell(lnkPurchaseForAll.ToString, PurchaseForAllVisible)
                'If PurchaseForSelectedVisible Then
                '    If Not oTableCell Is Nothing Then
                '        TableCell.InnerHtml = innerHtml
                '        TableCell.Align = align
                '    Else
                '        CreateLinkButtonInHtmlCell(lnkPurchaseForSelected.ToString, PurchaseForSelectedVisible)
                '    End If
                'End If

                table.Rows.Add(CreateHtmlTableRow(CreateControlInHtmlCell(table2, "table2")))
                Controls.Add(table)
            End If
            
        End Sub


#End Region
#Region " Create HTML Table , Rows and Cells "

        Private Function CreateHtmlTableRow(ByVal ParamArray HtmlCells() As HtmlTableCell) As HtmlTableRow
            Dim tablerow As New HtmlTableRow
            Dim i As Integer = 0
            For Each Cell As HtmlTableCell In HtmlCells

                If Not Cell Is Nothing Then
                    Cell.NoWrap = True
                    'Cell.Attributes.Add("align", "right")
                    tablerow.Cells.Add(Cell)
                End If

                i += 1
            Next

            Return tablerow
        End Function
        Private Overloads Function CreateLinkButtonInHtmlCell(ByVal innerHtml As String, ByVal visible As Boolean, Optional ByVal align As String = "left") As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            If visible Then
                tablecell.InnerHtml = innerHtml
                tablecell.Align = align
            End If

            Return tablecell

        End Function
        Private Overloads Function CreateControlInHtmlCell(ByRef Control As RadioButtonList, _
                ByVal ID As String) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function


        Private Overloads Function CreateControlInHtmlCell(ByRef Control As Label, _
        ByVal ID As String, ByVal Text As String, _
                  Optional ByVal Width As Integer = -1) As HtmlTableCell

            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            SetControlProperties(Control, ID, Text, Width)

            tablecell.Controls.Add(Control)

            Return tablecell

        End Function
        Public Overloads Function CreateControlInHTMLCell(ByRef control As HtmlTable, ByVal id As String) As HtmlTableCell
            Dim tablecell As HtmlTableCell

            tablecell = New HtmlTableCell

            tablecell.Controls.Add(control)

            Return tablecell

        End Function

        Private Overloads Sub SetControlProperties(ByRef Control As RadioButtonList, ByVal ID As String)
            Control = New RadioButtonList
            With Control
                .ID = ID
                .RepeatDirection = RepeatDirection.Horizontal
                With .Items
                    .Add(New ListItem(AllEmployeesText, "AllEmployees"))
                    .Add(New ListItem(SelectedText, "Selected"))
                End With
                .Items(1).Selected = True
            End With

        End Sub



        Private Overloads Sub SetControlProperties(ByRef Control As Label, ByVal ID As String, ByVal Text As String, _
                Optional ByVal Width As Integer = -1)
            Control = New Label
            With Control
                .ID = ID
                .Text = Text
                If Width <> -1 Then
                    .Width = Unit.Percentage(Width)
                End If

            End With
        End Sub

#End Region

    End Class
End Namespace

