Option Strict Off

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Text

Imports Personify.ApplicationManager.PersonifyDataObjects
Imports Personify.ApplicationManager

Imports Personify.DNN.Modules.AffiliateList.clsAffiliateList

Namespace Personify.DNN.Modules.AffiliateList

    Public MustInherit Class AffiliateList
        Inherits Personify.ApplicationManager.PersonifyDNNBaseForm
        'Implements Entities.Modules.IPortable

#Region "Controls"
        Protected WithEvents pnlSegments As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlSearchControlMembers As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMemberActions As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMemberActionsBottom As System.Web.UI.WebControls.Panel

        Protected WithEvents searchControlMembers As SearchControl
        Protected WithEvents memberActions As MemberActions
        Protected WithEvents memberActionsBottom As MemberActions

        Protected WithEvents xslMembersView As WebControls.XslTemplate
        Protected WithEvents dpMembersView As WebControls.DataPager

        'Protected WithEvents lblErrorMessage As System.Web.UI.WebControls.Label
        Protected WithEvents lblSegmentDesc As System.Web.UI.WebControls.Label
        Protected WithEvents lblMembersCount As System.Web.UI.WebControls.Label

        Dim sort As Boolean = False

        Dim SegmentType As String = String.Empty
        Dim qualifier1 As String = String.Empty
        Dim qualifier2 As String = String.Empty

        Dim segmentinfo As AffiliateManagementSessionHelper.SegmentInfo

        Protected WithEvents lblSelected As Label
        Protected WithEvents chkSelectAll As CheckBox

        'Protected WithEvents hdnSelected As System.Web.UI.HtmlControls.HtmlInputHidden

        Protected ItemsPerPage As Integer = 10
        Protected ItemsCount As Integer = 0
        Protected ActualItemsCount As Integer = 0
        Protected CurrentItemsPerPage As Integer = 0
        Protected hdnSelectedValue As String = ""

        Protected WithEvents oMessageControl As WebControls.MessageControl

        Private m_EventTarget As String
        Private m_EventArgument As String


        Dim tempMembers As ArrayList
        Dim tMembers As Hashtable
#End Region

#Region "Constants"
        Private Const C_SEGMENT_EMPLOYEE As String = "EMPLOYEE"
        Private Const C_SEGMENT_MEMBERSHIP As String = "PRODUCT"
        Private Const C_SEGMENT_GEOGRAPHIC As String = "GEOGRAPHY"
        Private Const C_SEGMENT_COMMITTEE As String = "COMMITTEE"
        Private Const C_SEGMENT_MISCELLANEOUS As String = "MISCELLANEOUS"
#End Region


#Region "Properties"
        Public Property SortCriteria() As String
            Get
                Dim o As Object = Me.ViewState("_SortCriteria")
                If (o Is Nothing) Then
                    Return "LabelName"
                Else
                    Return CType(o, String)
                End If
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_SortCriteria") = Value
            End Set
        End Property
        Public Property SortDirection() As String
            Get
                Dim o As Object = Me.ViewState("_SortDirection")
                If (o Is Nothing) Then
                    Return "asc"
                Else
                    Return CType(o, String)
                End If
            End Get
            Set(ByVal Value As String)
                Me.ViewState("_SortDirection") = Value
            End Set
        End Property
        Public Property CurrentPage() As Integer
            Get
                Dim o As Object = Me.ViewState("_CurrentPage")
                If (o Is Nothing) Then
                    Return 0
                Else
                    Return CType(o, Integer)
                End If
            End Get
            Set(ByVal Value As Integer)
                Me.ViewState("_CurrentPage") = Value
            End Set
        End Property

        Public Property EventTarget() As String
            Get
                If (m_EventTarget Is Nothing) Then
                    Return String.Empty
                Else
                    Return m_EventTarget
                End If
            End Get
            Set(ByVal Value As String)
                m_EventTarget = Value
            End Set
        End Property
        Public Property EventArgument() As String
            Get
                If (m_EventArgument Is Nothing) Then
                    Return String.Empty
                Else
                    Return m_EventArgument
                End If
            End Get
            Set(ByVal Value As String)
                m_EventArgument = Value
            End Set
        End Property
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim role As String
               role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    InitializeControl()


                Else 'The current user does not have these attributes
                    pnlSegments.Visible = False
                    DisplayUserAccessMessage(role)
                End If

            Catch ex As Threading.ThreadAbortException
                'Ignore this one because the Redirect causes this

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub dpMembersView_Change() Handles dpMembersView.Change
            'this event is triggered if DataPager is moving to another page
            If CurrentPage >= 1 Then
                Select Case SegmentType
                    Case C_SEGMENT_EMPLOYEE
                        BuildEmployeeSegmentAffiliateListXSLTemplate()
                    Case C_SEGMENT_MEMBERSHIP
                        BuildMembershipProductSegmentAffiliateListXSLTemplate()
                    Case C_SEGMENT_GEOGRAPHIC
                        BuildGeographySegmentAffiliateListXSLTemplate()
                    Case C_SEGMENT_COMMITTEE
                        BuildCommitteeSegmentAffiliateListXSLTemplate()
                    Case C_SEGMENT_MISCELLANEOUS
                        BuildMiscellaneousSegmentAffiliateListXSLTemplate()
                End Select
            End If
        End Sub


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()



        End Sub

#End Region

#Region "Helper Functions"
        Private Sub InitializeControl()

            'read current segment information
            segmentinfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)
            qualifier1 = segmentinfo.SegmentQualifier1
            qualifier2 = segmentinfo.SegmentQualifier2
            SegmentType = segmentinfo.SegmentType

            'the name(description) of this segment wiull be shown on top of the page
            lblSegmentDesc.Text = segmentinfo.SegmentDescr

            'read the number of items per page from the Settings
            ItemsPerPage = CType(Settings(C_Page_Size), Integer)
            'property to keep __EVENTTARGET value
            EventTarget = Page.Request("__EVENTTARGET")
            'property to keep __EVENTARGUMENT value
            EventArgument = Page.Request("__EVENTARGUMENT")

            'Segment Information is missing 
            If Not Page.IsPostBack And (qualifier1 = String.Empty Or qualifier2 = String.Empty Or SegmentType = String.Empty) Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingSegmentInformation", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                pnlSegments.Visible = False
                Exit Sub
            End If
            'you should first set in AffiliateListEdit "Display Options" setting - select one of the display options
            If Settings(C_Display_Options) Is Nothing Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                pnlSegments.Visible = False
                Exit Sub
            End If

            'if AffiliateList is set for Group Action display option GroupActionNavigateURL will be different from String.empty
            Dim GroupActionNavigateURL As String = CheckIfGroupActions()
            If Not GroupActionNavigateURL = String.Empty Then
                Response.Redirect(GroupActionNavigateURL, True)
            End If

            'test if Remove action must be done
            RemoveItemFromAffiliateList()

            pnlSegments.Visible = True

            If Page.IsPostBack Then
                'the array of selected items from AffiliateList
                hdnSelectedValue = Request.Params("hdnSelected")
            End If

            pnlSearchControlMembers.Visible = False
            pnlMemberActions.Visible = False
            pnlMemberActionsBottom.Visible = False

            If Not Settings(C_Display_Options) Is Nothing Then
                Select Case CStr(Settings(C_Display_Options))
                    Case "Regular"
                        'Display Options from AffiliateListEdit was set as "Regular"
                        If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
                            'the search bar will be shown
                            pnlSearchControlMembers.Visible = True
                            'set searchControlMembers properties
                            With searchControlMembers
                                .SearchBy = Localization.GetString("SearchBy", LocalResourceFile)
                                .ShowAll = Localization.GetString("ShowAll", LocalResourceFile)
                                .Search = Localization.GetString("Search", LocalResourceFile)
                                .LocalResourceFile = LocalResourceFile
                                .SearchType = SegmentType
                                '3246-5774803
                                .ArrowImageURL = GetArrowImageURL()
                                'end 3246-5774803
                            End With
                        End If

                        'Show the SegmentDescription and MembersCount
                        lblSegmentDesc.Text = segmentinfo.SegmentDescr
                        With lblMembersCount
                            Select Case SegmentType
                                Case "COMMITTEE"
                                    .Text = " (" & GetCommitteeSegmentAffiliateListCount(qualifier1, qualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                Case "EMPLOYEE"
                                    .Text = " (" & GetEmployeeSegmentAffiliateListCount(qualifier1, qualifier2) & " " & Localization.GetString("Employees", LocalResourceFile) & ")"
                                Case "MISCELLANEOUS"
                                    .Text = " (" & GetMiscellaneousSegmentAffiliateListCount(qualifier1, qualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                Case "GEOGRAPHY"
                                    .Text = " (" & GetGeographySegmentAffiliateListCount(qualifier1, qualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                                Case "PRODUCT"
                                    .Text = " (" & GetMembershipProductSegmentAffiliateListCount(qualifier1, qualifier2) & " " & Localization.GetString("Members", LocalResourceFile) & ")"
                            End Select
                        End With
                        If (Not Settings(C_Show_Group_Panel) Is Nothing) Then
                            Select Case CStr(Settings(C_Show_Group_Panel))
                                Case "GroupAction"
                                    '"Show Group Action Panel" was selected
                                    pnlMemberActions.Visible = True
                                    pnlMemberActionsBottom.Visible = True
                                    'set properties for top memberActions bar
                                    With memberActions
                                        .GroupActionPanelVisible = True
                                        .GroupPurchasePanelVisible = False
                                        .AddMemberVisible = False
                                        Select Case SegmentType
                                            Case C_SEGMENT_EMPLOYEE
                                                .AddMemberText = Localization.GetString("AddEmployee", LocalResourceFile)
                                                .AddMemberNavigateURL = NavigateURL(CType(Settings(C_Employee_Action_URL), Integer))
                                                .AddMemberVisible = True
                                            Case C_SEGMENT_COMMITTEE
                                                .AddMemberText = Localization.GetString("AddMember", LocalResourceFile)
                                                .AddMemberNavigateURL = NavigateURL(CType(Settings(C_Member_Action_URL), Integer))
                                                .AddMemberVisible = True
                                        End Select

                                        .SelectedText = Localization.GetString("Selected", LocalResourceFile)
                                        .AllEmployeesText = Localization.GetString("AllEmployees", LocalResourceFile)
                                        .ApplyToText = Localization.GetString("ApplyTo", LocalResourceFile)
                                        .PrintRosterText = Localization.GetString("PrintRoster", LocalResourceFile)
                                        .PrintRosterVisible = True
                                        .PrintRosterNavigateURL = NavigateURL(CType(Settings(C_Print_Roster_Action_URL), Integer))
                                        .ConfirmPrintRosterMessage = Localization.GetString("ConfirmPrintRosterMessage", LocalResourceFile)
                                        .RenewText = Localization.GetString("Renew", LocalResourceFile)
                                        .RenewVisible = True
                                        .RenewNavigateURL = NavigateURL()
                                        .SendEmailText = Localization.GetString("SendEmail", LocalResourceFile)
                                        .SendEmailVisible = True
                                        .SendEmailNavigateURL = NavigateURL(CType(Settings(C_Group_Email_Action_URL), Integer))
                                        .ConfirmSendEmailMessage = Localization.GetString("ConfirmSendEmailMessage", LocalResourceFile)
                                    End With
                                    'set properties for bottom memberActions bar
                                    With memberActionsBottom
                                        .GroupActionPanelVisible = True
                                        .GroupPurchasePanelVisible = False
                                        .AddMemberVisible = False
                                        Select Case SegmentType
                                            Case C_SEGMENT_EMPLOYEE
                                                .AddMemberText = Localization.GetString("AddEmployee", LocalResourceFile)
                                                .AddMemberNavigateURL = NavigateURL(CType(Settings(C_Employee_Action_URL), Integer))
                                                .AddMemberVisible = True
                                            Case C_SEGMENT_COMMITTEE
                                                .AddMemberText = Localization.GetString("AddMember", LocalResourceFile)
                                                .AddMemberNavigateURL = NavigateURL(CType(Settings(C_Member_Action_URL), Integer))
                                                .AddMemberVisible = True
                                        End Select

                                        .SelectedText = Localization.GetString("Selected", LocalResourceFile)
                                        .AllEmployeesText = Localization.GetString("AllEmployees", LocalResourceFile)
                                        .ApplyToText = Localization.GetString("ApplyTo", LocalResourceFile)
                                        .PrintRosterText = Localization.GetString("PrintRoster", LocalResourceFile)
                                        .PrintRosterVisible = True
                                        .PrintRosterNavigateURL = NavigateURL(CType(Settings(C_Print_Roster_Action_URL), Integer))
                                        .ConfirmPrintRosterMessage = Localization.GetString("ConfirmPrintRosterMessage", LocalResourceFile)
                                        .RenewText = Localization.GetString("Renew", LocalResourceFile)
                                        .RenewVisible = True
                                        .RenewNavigateURL = NavigateURL()
                                        .SendEmailText = Localization.GetString("SendEmail", LocalResourceFile)
                                        .SendEmailVisible = True
                                        .SendEmailNavigateURL = NavigateURL(CType(Settings(C_Group_Email_Action_URL), Integer))
                                        .ConfirmSendEmailMessage = Localization.GetString("ConfirmSendEmailMessage", LocalResourceFile)
                                    End With
                                Case "GroupPurchase"
                                    '"Show Group Purchase Panel" was selected
                                    pnlMemberActions.Visible = True
                                    pnlMemberActionsBottom.Visible = True
                                    'set top memberActions bar
                                    With memberActions
                                        .GroupActionPanelVisible = False
                                        .GroupPurchasePanelVisible = True
                                        .PurchaseForAllText = Localization.GetString("PurchaseForAll", LocalResourceFile)
                                        .PurchaseForAllVisible = True
                                        .PurchaseForAllNavigateURL = NavigateURL(CType(Settings(C_Purchase_Action_URL), Integer))
                                        .PurchaseForSelectedText = Localization.GetString("PurchaseForSelected", LocalResourceFile)
                                        .PurchaseForSelectedVisible = True
                                        .PurchaseForSelectedNavigateURL = NavigateURL(CType(Settings(C_Purchase_Action_URL), Integer))
                                        .ConfirmPurchaseMessage = Localization.GetString("ConfirmPurchaseMessage", LocalResourceFile)
                                    End With
                                    'set bottom memberActions bar
                                    With memberActionsBottom
                                        .GroupActionPanelVisible = False
                                        .GroupPurchasePanelVisible = True
                                        .PurchaseForAllText = Localization.GetString("PurchaseForAll", LocalResourceFile)
                                        .PurchaseForAllVisible = True
                                        .PurchaseForAllNavigateURL = NavigateURL(CType(Settings(C_Purchase_Action_URL), Integer))
                                        .PurchaseForSelectedText = Localization.GetString("PurchaseForSelected", LocalResourceFile)
                                        .PurchaseForSelectedVisible = True
                                        .PurchaseForSelectedNavigateURL = NavigateURL(CType(Settings(C_Purchase_Action_URL), Integer))
                                        .ConfirmPurchaseMessage = Localization.GetString("ConfirmPurchaseMessage", LocalResourceFile)
                                    End With
                            End Select
                        End If

                        Select Case SegmentType
                            Case C_SEGMENT_EMPLOYEE
                                BuildEmployeeSegmentAffiliateList()
                            Case C_SEGMENT_MEMBERSHIP
                                BuildMembershipProductSegmentAffiliateList()
                            Case C_SEGMENT_GEOGRAPHIC
                                BuildGeographySegmentAffiliateList()
                            Case C_SEGMENT_COMMITTEE
                                BuildCommitteeSegmentAffiliateList()
                            Case C_SEGMENT_MISCELLANEOUS
                                BuildMiscellaneousSegmentAffiliateList()
                        End Select


                    Case "GroupAction"
                        Dim strQueryString As String = Request.Url.Query
                        Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
                        Dim strQueryParam As String

                        Dim toEmailAddresses As String = String.Empty
                        For Each strQueryParam In arrQueryString
                            If strQueryParam.IndexOf("EmailAddresses") <> -1 Then
                                Response.Redirect(NavigateURL(CType(Settings(C_Group_Email_Action_URL), Integer), "", strQueryParam))
                            End If
                            If strQueryParam.IndexOf("ShipCustomerId") <> -1 Then
                                Response.Redirect(NavigateURL(CType(Settings(C_Renew_Action_URL), Integer), "", strQueryParam))
                            End If
                        Next

                        pnlMemberActions.Visible = False
                        pnlMemberActionsBottom.Visible = False
                        Dim members() As GroupActionListInfo = Nothing
                        Select Case SegmentType
                            Case C_SEGMENT_EMPLOYEE
                                members = BuildGroupActionEmployeeSegmentAffiliateList()
                            Case C_SEGMENT_MEMBERSHIP
                                members = BuildGroupActionMembershipProductSegmentAffiliateList()
                            Case C_SEGMENT_GEOGRAPHIC
                                members = BuildGroupActionGeographySegmentAffiliateList()
                            Case C_SEGMENT_COMMITTEE
                                members = BuildGroupActionCommitteeSegmentAffiliateList()
                            Case C_SEGMENT_MISCELLANEOUS
                                members = BuildGroupActionMiscellaneousSegmentAffiliateList()
                        End Select



                        xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/GroupActionTemplate.xsl")
                        xslMembersView.AddObject("", members)
                        Dim groupActionMessage As String = String.Empty
                        Dim affGroupActionType As AffiliateManagementSessionHelper.enmGroupAction = AffiliateManagementSessionHelper.GetAffiliateGroupActionType(PortalId)
                        Dim segmentInfo As AffiliateManagementSessionHelper.SegmentInfo = AffiliateManagementSessionHelper.GetCurrentSegmentInfo(PortalId)

                        Dim btnCancel As ButtonCancelInfo = New ButtonCancelInfo
                        Dim btnConfirmAction As ButtonConfirmActionInfo = New ButtonConfirmActionInfo



                        Select Case affGroupActionType
                            Case AffiliateManagementSessionHelper.enmGroupAction.SENDEMAIL
                                groupActionMessage = Localization.GetString("GroupActionSendEmailMessage", LocalResourceFile)
                                With btnConfirmAction
                                    .NavigateURL = NavigateURL(CType(Settings(C_Group_Email_Action_URL), Integer))
                                    .Text = Localization.GetString("btnConfirmAction", LocalResourceFile)
                                End With
                                With btnCancel
                                    .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "EmailCancel")
                                    .Text = Localization.GetString("btnCancel", LocalResourceFile)
                                End With
                            Case AffiliateManagementSessionHelper.enmGroupAction.PRINTROSTER
                                groupActionMessage = Localization.GetString("GroupActionPrintRosterMessage", LocalResourceFile)
                                With btnConfirmAction
                                    .NavigateURL = NavigateURL(CType(Settings(C_Print_Roster_Action_URL), Integer))
                                    .Text = Localization.GetString("btnConfirmAction", LocalResourceFile)
                                End With
                                With btnCancel
                                    .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "PrintCancel")
                                    .Text = Localization.GetString("btnCancel", LocalResourceFile)
                                End With
                            Case AffiliateManagementSessionHelper.enmGroupAction.PURCHASE
                                groupActionMessage = Localization.GetString("GroupActionPurchaseMessage", LocalResourceFile)
                                With btnConfirmAction
                                    .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "PurchaseConfirmAction")
                                    'NavigateURL(CType(Settings(C_Buy_Product_Action_URL), Integer))
                                    .Text = Localization.GetString("btnConfirmAction", LocalResourceFile)
                                End With
                                With btnCancel
                                    .NavigateURL = "javascript: " & Page.ClientScript.GetPostBackEventReference(Me, "PurchaseCancel")
                                    .Text = Localization.GetString("btnCancel", LocalResourceFile)
                                End With
                        End Select



                        xslMembersView.AddObject("groupActionMessage", groupActionMessage)
                        Dim totalRecords As String = Localization.GetString("TotalRecords", LocalResourceFile)
                        xslMembersView.AddObject("TotalRecords", totalRecords & "-" & tMembers.Count)
                        xslMembersView.AddObject("", btnConfirmAction)
                        xslMembersView.AddObject("", btnCancel)
                        xslMembersView.Display()

                    Case "PurchaseConfirmation"

                        lblSegmentDesc.Text = ""

                        xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/GroupPurchaseConfirmationTemplate.xsl")
                        Dim BuyAnotherProductForTheSameGroup As ButtonBuyAnotherProductForTheSameGroupInfo = New ButtonBuyAnotherProductForTheSameGroupInfo
                        With BuyAnotherProductForTheSameGroup
                            .Text = Localization.GetString("btnBuyAnotherProductForTheSameGroup", LocalResourceFile)
                            .NavigateURL = NavigateURL(CType(Settings(C_Buy_Product_For_Same_Group_Action_URL), Integer))
                            .Explanation = Localization.GetString("btnBuyAnotherProductForTheSameGroupExplanation", LocalResourceFile)
                        End With
                        Dim BuyAnotherProductForDifferentGroup As ButtonBuyAnotherProductForDifferentGroupInfo = New ButtonBuyAnotherProductForDifferentGroupInfo
                        With BuyAnotherProductForDifferentGroup
                            .Text = Localization.GetString("btnBuyAnotherProductForDifferentGroup", LocalResourceFile)
                            .NavigateURL = NavigateURL(CType(Settings(C_Buy_Product_For_Different_Group_Action_URL), Integer))
                            .Explanation = Localization.GetString("btnBuyAnotherProductForDifferentGroupExplanation", LocalResourceFile)
                        End With
                        Dim Checkout As ButtonCheckoutInfo = New ButtonCheckoutInfo
                        With Checkout
                            .Text = Localization.GetString("btnCheckout", LocalResourceFile)
                            .NavigateURL = NavigateURL(CType(Settings(C_Checkout_Action_URL), Integer))
                        End With
                        xslMembersView.AddObject("", BuyAnotherProductForTheSameGroup)
                        xslMembersView.AddObject("", BuyAnotherProductForDifferentGroup)
                        xslMembersView.AddObject("", Checkout)
                        xslMembersView.Display()

                        If Page.IsPostBack AndAlso EventTarget.IndexOf("btnBuyAnotherProductForTheSameGroup") >= 0 Then
                            'button Buy Another Product For The Same Group was pressed
                            If Not Settings(C_AFFILIATELIST_GROUP_PURCHASE_CONFIRM_ACTION_URL) Is Nothing Then
                                AffiliateManagementSessionHelper.SetCurrentSegmentGroupPurchaseActionURL(PortalId, CInt(Settings(C_AFFILIATELIST_GROUP_PURCHASE_CONFIRM_ACTION_URL)))
                                Response.Redirect(NavigateURL(CType(Settings(C_Buy_Product_For_Same_Group_Action_URL), Integer)))
                            End If
                        End If
                        If Page.IsPostBack AndAlso EventTarget.IndexOf("btnBuyAnotherProductForDifferentGroup") >= 0 Then
                            'button Buy Another Product For Different Group was pressed
                            AffiliateManagementSessionHelper.SetCurrentSegmentGroupPurchaseActionURL(PortalId, 0)
                            Response.Redirect(NavigateURL(CType(Settings(C_Buy_Product_For_Different_Group_Action_URL), Integer)))
                        End If
                        If Page.IsPostBack AndAlso EventTarget.IndexOf("btnCheckout") >= 0 Then
                            'button Checkout was pressed
                            AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                            AffiliateManagementSessionHelper.RemoveCurrentSegmentInfo(PortalId)
                            Response.Redirect(NavigateURL(CType(Settings(C_Checkout_Action_URL), Integer)))
                        End If

                End Select
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("MissingSegmentInformation", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                pnlSegments.Visible = False
                Exit Sub
            End If

        End Sub

        'initialize JavaScript code used for selecting affiliate list members
        Private Sub InitializeJavaScript()
            'If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
            Dim InitializeJS As StringBuilder = New StringBuilder()
            InitializeJS.AppendLine("<script language='javascript'>")

            InitializeJS.AppendLine("var CcontrolSID = new Array(" & ItemsPerPage & ");")
            InitializeJS.AppendLine("curentItemsPerPage = " & CurrentItemsPerPage & ";")
            For i As Integer = 1 To CurrentItemsPerPage
                If FindControl("chk" & i) IsNot Nothing Then
                    InitializeJS.AppendLine("if (curentItemsPerPage >= " & i & ")")
                    Dim chk As CheckBox = New CheckBox
                    chk = CType(FindControl("chk" & i), CheckBox)
                    InitializeJS.AppendLine("{CcontrolSID[" & (i - 1) & "] = """ & chk.ClientID & """;}")
                Else
                    InitializeJS.AppendLine("if (curentItemsPerPage >= " & i & ")")
                    Dim chk As CheckBox = New CheckBox
                    chk = CType(FindControl("chk" & i), CheckBox)
                    InitializeJS.AppendLine("{CcontrolSID[" & (i - 1) & "] = """";}")

                End If
            Next

            InitializeJS.AppendLine("hdnSelected = ""hdnSelected"";")
            InitializeJS.AppendLine("hdn = returnObjById(hdnSelected);")
            If Page.IsPostBack Then
                If (EventTarget.IndexOf("searchControlMembers") > 0) Then
                    hdnSelectedValue = ""
                End If
            End If
            If hdnSelectedValue <> String.Empty Then
                Dim sels() As String = hdnSelectedValue.Split(CChar(";"))
                hdnSelectedValue = ""
                For i As Integer = 0 To sels.Length - 1
                    If sels(i) <> String.Empty Then
                        If Not CBool(tempMembers(CInt(sels(i)))) Then
                            hdnSelectedValue = hdnSelectedValue & ";" & CInt(sels(i))
                        End If
                    End If
                Next
            End If
            InitializeJS.AppendLine("hdn.value=""" & hdnSelectedValue & """;")
            InitializeJS.AppendLine("chkSelect = """ & chkSelectAll.ClientID & """;")
            InitializeJS.AppendLine("itemsNo = " & ItemsCount & ";")
            InitializeJS.AppendLine("actualItemsNo = " & ActualItemsCount & ";")
            InitializeJS.AppendLine("ItemsPerPage = " & ItemsPerPage & ";")
            InitializeJS.AppendLine("CurrentPage = " & CurrentPage - 1 & ";")
            InitializeJS.AppendLine("for (i=0; i<=curentItemsPerPage-1; i++){")
            InitializeJS.AppendLine("temp = "";""+((CurrentPage*ItemsPerPage)+i);")
            InitializeJS.AppendLine("if ((hdn.value.indexOf(temp+"";"")>=0) ||((hdn.value.indexOf(temp)>=0) && (hdn.value.indexOf(temp)+temp.length==hdn.value.length))){")
            InitializeJS.AppendLine("chki = returnObjById(CcontrolSID[i]);if (chki == null){} else {chki.checked = true;}}")
            InitializeJS.AppendLine("else {chki = returnObjById(CcontrolSID[i]);if (chki == null){} else {chki.checked = false;}}}")
            InitializeJS.AppendLine("if(hdn.value.split("";"").length-1 == actualItemsNo)")
            InitializeJS.AppendLine("{chkSelectAll = returnObjById(chkSelect);chkSelectAll.checked = true;}")
            InitializeJS.AppendLine("else")
            InitializeJS.AppendLine("{chkSelectAll = returnObjById(chkSelect);chkSelectAll.checked = false;}")
            Dim RecordsSelectedMessage As String = Localization.GetString("RecordsSelectedMessage", LocalResourceFile)
            InitializeJS.AppendLine("RecordsSelectedMessage=""" & RecordsSelectedMessage & """;")
            InitializeJS.AppendLine("selectedMembersNoDiv = returnObjById('selectedMembersNo');")
            InitializeJS.AppendLine("selectedMembersNoDiv.innerHTML = ""("" + (hdn.value.split(';').length-1) +"" ""+RecordsSelectedMessage +"")"" ;")
            InitializeJS.AppendLine("</script>")

            Me.Page.ClientScript.RegisterStartupScript(Me.GetType, "InitializeJS", InitializeJS.ToString)
            'End If
        End Sub


#Region "Employee Segment Affiliate List Helper Function"


        Private Sub BuildEmployeeSegmentAffiliateList()
            Dim dsMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList = Nothing
            'get the employee affiliate list for the current segment
            dsMembers = GetEmployeeSegmentAffiliateList()

            If Not dsMembers Is Nothing Then
                'set DataPager for AffiliateList
                ItemsCount = dsMembers.Count
                dpMembersView = New WebControls.DataPager()
                dpMembersView.PageSize = ItemsPerPage
                dpMembersView.PagingMode = WebControls.PagingModeType.PostBack

                dpMembersView.DataSource = dsMembers
                dpMembersView.DataBind()
                pnlSegments.Controls.Add(dpMembersView)
                dpMembersView.Visible = True

                tMembers = New Hashtable
                tempMembers = New ArrayList
                For i As Integer = 0 To dsMembers.Count - 1
                    If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                        tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next
                ActualItemsCount = tMembers.Count

                If Page.IsPostBack Then
                    If (EventArgument.IndexOf("SendEmail") >= 0) Or (EventArgument.IndexOf("PrintRoster") >= 0) Or _
                        (EventArgument.IndexOf("PurchaseForAll") >= 0) Or (EventArgument.IndexOf("PurchaseForSelected") >= 0) Then
                        'one of the Group Actions buttons was pressed
                        BuildEmployeeSegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("searchControlMembers") > 0) Then
                        'PostBack because of a Search
                        BuildEmployeeSegmentAffiliateListXSLTemplate()
                    End If
                    'ContextMenu was clicked
                    If (EventTarget.IndexOf("ctxChangeTitle", StringComparison.InvariantCultureIgnoreCase) > 0) Then
                        BuildEmployeeSegmentAffiliateListXSLTemplate()
                    End If
                    If sort Then
                        'after sorting the selection is reset
                        hdnSelectedValue = ""
                        BuildEmployeeSegmentAffiliateListXSLTemplate()
                    End If
                End If
                If Not Page.IsPostBack And (CurrentPage = 0) Then
                    'first load of the page
                    BuildEmployeeSegmentAffiliateListXSLTemplate()
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecords", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
        End Sub
        Private Sub BuildEmployeeSegmentAffiliateListXSLTemplate()

            If Page.IsPostBack AndAlso (EventTarget.IndexOf("searchControlMembers") > 0) Then
                'if coming from an SearchControl event CurrentPage will be reset
                CurrentPage = 1
                dpMembersView.CurrentPage = 1
            Else
                CurrentPage = dpMembersView.CurrentPage
            End If
            dpMembersView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1


            Dim members(dpMembersView.DataSourcePaged.Count) As EmployeeListInfo
            Dim i As Integer = 0
            Dim ie As IEnumerator = dpMembersView.DataSourcePaged.GetEnumerator

            Dim ctxChangeTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenu
            Dim lnkPageTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenuLink
            Dim lblName(dpMembersView.DataSourcePaged.Count) As Label

            While ie.MoveNext
                members(i) = New EmployeeListInfo
                members(i).Name = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).LabelName
                members(i).Phone = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).PrimaryPhone
                members(i).Email = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).PrimaryEmailAddress
                members(i).EmploymentDate = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).BeginDate.ToString("d")
                members(i).EmploymentType = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).RelationshipCodeString '.JobFunctionCodeString
                members(i).Supervisor = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).SupervisorName
                members(i).FullTime = CStr(IIf((CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).FullTimeFlag, "Yes", "No"))
                members(i).CustomerRelationshipId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).CustomerRelationshipId
                members(i).MasterCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).MasterCustomerId
                members(i).SubCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).SubCustomerId

                members(i).CheckBoxHidden = CBool(tempMembers((CurrentPage - 1) * ItemsPerPage + i))


                If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                    ctxChangeTitle(i) = New MarkItUp.WebControls.ContextMenu

                    ctxChangeTitle(i).ID = "ctxChangeTitle" & i

                    Dim AffiliateMasterCustomerId As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).MasterCustomerId
                    Dim AffiliateSubCustomerId As Integer = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).SubCustomerId
                    Dim AffiliateLabelName As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoView)).LabelName


                    AddHandler ctxChangeTitle(i).ItemClick, AddressOf ContextMenuItemClick
                    Dim omenuitem As MarkItUp.WebControls.ContextMenuItem


                    'test if Send Email item  criterias match
                    If Not members(i).Email Is Nothing AndAlso members(i).Email <> String.Empty Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem

                        With omenuitem
                            .Text = Localization.GetString("ContextMenuSendEmail", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Group_Email_Action_URL)), "", "&EmailAddresses=" & members(i).Email)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If


                    'test if Create Order item criterias match
                    'If segmentinfo.CanPlaceOrderFlag Then
                    'omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    'With omenuitem
                    '.Text = Localization.GetString("ContextMenuCreateOrder", LocalResourceFile)
                    '.CommandArgument = NavigateURL(CInt(Settings(C_Create_Order_Action_URL)))
                    '.ClientNotificationFunction = "Navigate"
                    'End With
                    'ctxChangeTitle(i).Items.Add(omenuitem)
                    'End If

                    'test if View Order History item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewOrderHistory", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewOrder" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if View Profile item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewProfile", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewProfile" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if Renew item criterias match
                    If segmentinfo.CanPlaceOrderFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuRenew", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Renew_Action_URL)), "", "&ShipCustomerId=" & members(i).MasterCustomerId & "-" & members(i).SubCustomerId)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'Edit Relationship  
                    omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    With omenuitem
                        If Not segmentinfo.ReadOnlyFlag Then
                            'READ_ONLY_FLAG = �N�
                            .Text = Localization.GetString("ContextMenuEditRelationship", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Employee_Action_URL)), "", "&action=EDIT&args=" & members(i).CustomerRelationshipId)
                            .ClientNotificationFunction = "Navigate"
                        End If
                    End With
                    ctxChangeTitle(i).Items.Add(omenuitem)


                    'View Relationship
                    omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    With omenuitem
                        .Text = Localization.GetString("ContextMenuViewRelationship", LocalResourceFile)
                        .CommandArgument = NavigateURL(CInt(Settings(C_Employee_Action_URL)), "", "&action=VIEW&args=" & members(i).CustomerRelationshipId)
                        .ClientNotificationFunction = "Navigate"
                    End With
                    ctxChangeTitle(i).Items.Add(omenuitem)


                    'test if Remove item criterias match
                    'CAN_REMOVE_MEMBER_FLAG = �Y�
                    If Not Settings(C_Allow_Segment_Details_Delete) Is Nothing Then
                        If CStr(Settings(C_Allow_Segment_Details_Delete)) = "Y" And segmentinfo.CanRemoveMemberFlag Then
                            omenuitem = New MarkItUp.WebControls.ContextMenuItem
                            With omenuitem
                                .Text = Localization.GetString("ContextMenuRemove", LocalResourceFile)
                                .CommandArgument = NavigateURL(TabId, "", "&action=REMOVE&args=" & members(i).CustomerRelationshipId)
                                .ClientNotificationFunction = "Navigate"
                            End With
                            ctxChangeTitle(i).Items.Add(omenuitem)
                        End If
                    End If

                    lnkPageTitle(i) = New MarkItUp.WebControls.ContextMenuLink
                    With lnkPageTitle(i)
                        .ID = "lnkPageTitle" & i
                        .ContextMenuToOpen = "ctxChangeTitle" & i
                        .Text = members(i).Name
                    End With

                Else
                    lblName(i) = New Label
                    With lblName(i)
                        .Text = members(i).Name
                        .ID = "lblName" & i
                    End With
                End If

                i = i + 1
            End While

            xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/AffiliateEmployeeListTemplate.xsl")
            xslMembersView.AddObject("", members)
            xslMembersView.Display()


            Dim j As Integer
            For j = 0 To i - 1
                Dim ph As New PlaceHolder
                ph = CType(Me.FindControl("ph" + (j + 1).ToString), PlaceHolder)
                If (ph IsNot Nothing) Then
                    If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                        ph.Controls.Add(lnkPageTitle(j))
                        ph.Controls.Add(ctxChangeTitle(j))
                    Else
                        ph.Controls.Add(lblName(j))
                    End If

                End If
            Next

            chkSelectAll = CType(Me.FindControl("chkSelectAll"), CheckBox)
            chkSelectAll.Attributes.Add("onclick", "addSelectAll()")

            CurrentItemsPerPage = i
            For t As Integer = 1 To ItemsPerPage
                If CurrentItemsPerPage >= t Then
                    If Me.FindControl("chk" & t) IsNot Nothing Then
                        Dim chk As CheckBox = New CheckBox
                        chk = CType(Me.FindControl("chk" & t), CheckBox)
                        chk.Attributes.Add("onclick", "addSelected(" & t & ")")
                    End If
                End If
            Next
            InitializeJavaScript()

        End Sub
        Protected Sub ContextMenuItemClick(ByVal sender As Object, ByVal e As MarkItUp.WebControls.ItemClickEventArgs)
            Dim url As String = String.Empty
            Dim temp() As String = e.MenuItemCommandArgument.Split(CChar(";"))
            Select Case temp(0)
                Case "ViewOrder"
                    url = NavigateURL(CInt(Settings(C_Order_History_Action_URL)))
                Case "ViewProfile"
                    url = NavigateURL(CInt(Settings(C_Profile_Action_URL)))
            End Select
            Dim AffiliateMasterCustomerId As String = temp(1)
            Dim AffiliateSubCustomerId As Integer = CInt(temp(2))
            Dim AffiliateLabelName As String = temp(3)
            'TODO get the values for AffiliateMasterCustomerId, AffiliatesubCustomerId, AffiliateLabelName, EditProfileFlag 
            AffiliateManagementSessionHelper.ManageAffiliate(PortalId, AffiliateMasterCustomerId, AffiliateSubCustomerId, AffiliateLabelName, True)
            Response.Redirect(url)
        End Sub
        Private Function GetEmployeeSegmentAffiliateList() As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList
            Try
                Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList
                Dim searchField As String = ""
                Dim searchValue As String = ""


                If Page.IsPostBack Then

                    If (EventTarget.IndexOf("searchControlMembers") > 0) And (EventArgument = "ShowAll") Then
                        'when "ShowAll" was clicked the Search bar is reset
                        CType(FindControl("searchControlMembers"), SearchControl).SearchText = ""
                        CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsIndex = 0
                    Else
                        If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
                            'obtain search Criteria and value
                            searchField = CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsValue
                            searchValue = CType(FindControl("searchControlMembers"), SearchControl).SearchText
                        End If
                    End If
                End If

                'get the employee list filtered based on the search criteria
                Select Case searchField
                    Case "LABELNAME"
                        oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, searchValue, Date.MinValue, Nothing)
                    Case "BEGINDATE"
                        If Not IsDate(searchValue) Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Return Nothing
                        Else
                            oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, Nothing, CDate(searchValue), Nothing)
                        End If
                    Case "RELATIONSHIPCODE"
                        oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, Nothing, Date.MinValue, searchValue)
                    Case Else
                        oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2)
                End Select

                'find the sorting criteria
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                    sort = True
                End If
                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                    sort = True
                End If

                If EventTarget.IndexOf("btnEmploymentDate") >= 0 Then
                    SortCriteria = "BeginDate"
                    sort = True
                End If

                If EventTarget.IndexOf("btnEmploymentType") >= 0 Then
                    SortCriteria = "RelationshipCode"
                    sort = True
                End If

                If EventTarget.IndexOf("btnSupervisor") >= 0 Then
                    SortCriteria = "SupervisorName"
                    sort = True
                End If

                If EventTarget.IndexOf("btnFullTime") >= 0 Then
                    SortCriteria = "FullTimeFlag"
                    sort = True
                End If


                'sort the items based on the sorting criteria
                If sort AndAlso SortDirection = "asc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                ElseIf sort AndAlso SortDirection = "desc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                    SortDirection = "asc"
                ElseIf Not sort Then
                    '3246-5727317
                    SortCriteria = "LabelName"
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                    'END 3246-5727317
                End If

                If oMembers.Count > 0 Then
                    GetEmployeeSegmentAffiliateList = oMembers
                Else
                    GetEmployeeSegmentAffiliateList = Nothing
                End If

                oMembers = Nothing
            Catch ex As Exception
                Throw ex
            Finally

            End Try
        End Function

#End Region

#Region "Committee Segment Affiliate List Helper Functions"
        Private Sub BuildCommitteeSegmentAffiliateList()
            Dim dsMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList = Nothing
            'get the items for the current segment - Committee
            dsMembers = GetCommitteeSegmentAffiliateList()

            If Not dsMembers Is Nothing Then
                'set DataPager
                ItemsCount = dsMembers.Count
                dpMembersView = New WebControls.DataPager()
                dpMembersView.PageSize = ItemsPerPage
                dpMembersView.PagingMode = WebControls.PagingModeType.PostBack

                dpMembersView.DataSource = dsMembers
                dpMembersView.DataBind()
                pnlSegments.Controls.Add(dpMembersView)
                dpMembersView.Visible = True

                tMembers = New Hashtable
                tempMembers = New ArrayList
                For i As Integer = 0 To dsMembers.Count - 1
                    If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                        tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next
                ActualItemsCount = tMembers.Count

                If Page.IsPostBack Then
                    If (EventArgument.IndexOf("SendEmail") >= 0) Or (EventArgument.IndexOf("PrintRoster") >= 0) Or _
                        (EventArgument.IndexOf("PurchaseForAll") >= 0) Or (EventArgument.IndexOf("PurchaseForSelected") >= 0) Then
                        'one of the GroupAction buttons was pressed
                        BuildCommitteeSegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("searchControlMembers") > 0) Then
                        'Search was clicked
                        BuildCommitteeSegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("ctxChangeTitle", StringComparison.InvariantCultureIgnoreCase) > 0) Then
                        'ContextMenu was clicked
                        BuildCommitteeSegmentAffiliateListXSLTemplate()
                    End If
                    If sort Then
                        'after sorting the Selection of items is reset
                        hdnSelectedValue = ""
                        BuildCommitteeSegmentAffiliateListXSLTemplate()
                    End If
                End If
                If Not Page.IsPostBack And (CurrentPage = 0) Then
                    'first load of AffiliateList
                    BuildCommitteeSegmentAffiliateListXSLTemplate()
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecords", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
        End Sub

        Private Function GetCommitteeSegmentAffiliateList() As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList
            Try
                Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList

                Dim searchField As String = ""
                Dim searchValue As String = ""


                If Page.IsPostBack Then
                    If (EventTarget.IndexOf("searchControlMembers") > 0) And (EventArgument = "ShowAll") Then
                        'if "ShowAll" was clicked the Search bar is reset
                        CType(FindControl("searchControlMembers"), SearchControl).SearchText = ""
                        CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsIndex = 0
                    Else
                        If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
                            'obtain search Criteria and value
                            searchField = CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsValue
                            searchValue = CType(FindControl("searchControlMembers"), SearchControl).SearchText
                        End If
                    End If
                End If

                'get the items filtered based on search criterias 
                Select Case searchField
                    Case "LABELNAME"
                        oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, searchValue, Date.MinValue, Nothing)
                    Case "ENDDATE"
                        If Not IsDate(searchValue) Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Return Nothing
                        Else
                            oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, Nothing, CDate(searchValue), Nothing)
                        End If
                    Case "POSITIONCODE"
                        oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, Nothing, Date.MinValue, searchValue)
                    Case Else
                        oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2)
                End Select

                'find the sorting criteria
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                    sort = True
                End If
                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                    sort = True
                End If

                If EventTarget.IndexOf("btnTermEndDate") >= 0 Then
                    SortCriteria = "EndDate"
                    sort = True
                End If

                If EventTarget.IndexOf("btnPosition") >= 0 Then
                    SortCriteria = "PositionCode"
                    sort = True
                End If

                If EventTarget.IndexOf("btnVotingStatus") >= 0 Then
                    SortCriteria = "VotingStatusCode"
                    sort = True
                End If

                'sort the items based on sorting criteria
                If sort AndAlso SortDirection = "asc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                ElseIf sort AndAlso SortDirection = "desc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                    SortDirection = "asc"
                ElseIf Not sort Then
                    '3246-5727317
                    SortCriteria = "LabelName"
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                    'END 3246-5727317
                End If

                If oMembers.Count > 0 Then
                    GetCommitteeSegmentAffiliateList = oMembers
                Else
                    GetCommitteeSegmentAffiliateList = Nothing
                End If

                oMembers = Nothing
            Catch ex As Exception
                Throw ex
            Finally

            End Try
        End Function

        Private Sub BuildCommitteeSegmentAffiliateListXSLTemplate()

            If Page.IsPostBack AndAlso (EventTarget.IndexOf("searchControlMembers") > 0) Then
                'if coming from an SearchControl event CurrentPage will be reset
                CurrentPage = 1
                dpMembersView.CurrentPage = 1
            Else
                CurrentPage = dpMembersView.CurrentPage
            End If
            dpMembersView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1


            Dim members(dpMembersView.DataSourcePaged.Count) As MemberListInfo
            Dim i As Integer = 0
            Dim ie As IEnumerator = dpMembersView.DataSourcePaged.GetEnumerator

            Dim ctxChangeTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenu
            Dim lnkPageTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenuLink
            Dim lblName(dpMembersView.DataSourcePaged.Count) As Label

            While ie.MoveNext
                members(i) = New MemberListInfo
                members(i).Name = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).LabelName
                members(i).Phone = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PrimaryPhone
                members(i).Email = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PrimaryEmailAddress
                members(i).TermEndDate = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).EndDate.ToString("d")
                members(i).Position = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PositionCode.Description
                members(i).VotingStatus = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).VotingStatusCodeString
                members(i).CommitteeMemberId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).CommitteeMemberId
                members(i).MasterCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).MasterCustomerId
                members(i).SubCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).SubCustomerId

                members(i).CheckBoxHidden = CBool(tempMembers((CurrentPage - 1) * ItemsPerPage + i))

                If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                    ctxChangeTitle(i) = New MarkItUp.WebControls.ContextMenu
                    AddHandler ctxChangeTitle(i).ItemClick, AddressOf ContextMenuItemClick

                    Dim AffiliateMasterCustomerId As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).MasterCustomerId
                    Dim AffiliateSubCustomerId As Integer = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).SubCustomerId
                    Dim AffiliateLabelName As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).LabelName


                    ctxChangeTitle(i).ID = "ctxChangeTitle" & i
                    Dim omenuitem As MarkItUp.WebControls.ContextMenuItem

                    'test if Send Email item  criterias match
                    If Not members(i).Email Is Nothing AndAlso members(i).Email <> String.Empty Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuSendEmail", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Group_Email_Action_URL)), "", "&EmailAddresses=" & members(i).Email)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If


                    'test if Create Order item criterias match
                    'If segmentinfo.CanPlaceOrderFlag Then
                    'omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    'With omenuitem
                    '.Text = Localization.GetString("ContextMenuCreateOrder", LocalResourceFile)
                    '.CommandArgument = NavigateURL(CInt(Settings(C_Create_Order_Action_URL)))
                    '.ClientNotificationFunction = "Navigate"
                    'End With
                    'ctxChangeTitle(i).Items.Add(omenuitem)
                    'End If

                    'test if View Order History item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewOrderHistory", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewOrder" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if View Profile item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewProfile", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewProfile" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if Renew item criterias match
                    If segmentinfo.CanPlaceOrderFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuRenew", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Renew_Action_URL)), "", "&ShipCustomerId=" & members(i).MasterCustomerId & "-" & members(i).SubCustomerId)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'Edit Committee Details 
                    omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    If Not segmentinfo.ReadOnlyFlag Then
                        'READ_ONLY_FLAG = �N�
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuEditCommitteeDetails", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Member_Action_URL)), "", "&action=EDIT&args=" & members(i).CommitteeMemberId)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'View Committee Details 
                    omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    With omenuitem
                        .Text = Localization.GetString("ContextMenuViewCommitteeDetails", LocalResourceFile)
                        .CommandArgument = NavigateURL(CInt(Settings(C_Member_Action_URL)), "", "&action=VIEW&args=" & members(i).CommitteeMemberId)
                        .ClientNotificationFunction = "Navigate"
                    End With
                    ctxChangeTitle(i).Items.Add(omenuitem)

                    'test if Expire Term item criterias match
                    'CAN_REMOVE_MEMBER_FLAG = �Y�
                    If Not Settings(C_Allow_Segment_Details_Delete) Is Nothing Then
                        If CStr(Settings(C_Allow_Segment_Details_Delete)) = "Y" And segmentinfo.CanRemoveMemberFlag Then
                            omenuitem = New MarkItUp.WebControls.ContextMenuItem
                            With omenuitem
                                .Text = Localization.GetString("ContextMenuExpireTerm", LocalResourceFile)
                                .CommandArgument = NavigateURL(TabId, "", "&action=REMOVE&args=" & members(i).CommitteeMemberId)
                                .ClientNotificationFunction = "Navigate"
                            End With
                            ctxChangeTitle(i).Items.Add(omenuitem)
                        End If
                    End If

                    lnkPageTitle(i) = New MarkItUp.WebControls.ContextMenuLink
                    With lnkPageTitle(i)
                        .ID = "lnkPageTitle" & i
                        .ContextMenuToOpen = "ctxChangeTitle" & i
                        .Text = members(i).Name
                    End With

                Else
                    lblName(i) = New Label
                    With lblName(i)
                        .Text = members(i).Name
                        .ID = "lblName" & i
                    End With
                End If

                i = i + 1
            End While

            xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/AffiliateCommitteeListTemplate.xsl")
            xslMembersView.AddObject("", members)
            xslMembersView.Display()

            Dim j As Integer
            For j = 0 To i - 1
                Dim ph As New PlaceHolder
                ph = CType(Me.FindControl("ph" + (j + 1).ToString), PlaceHolder)
                If (ph IsNot Nothing) Then
                    If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                        ph.Controls.Add(lnkPageTitle(j))
                        ph.Controls.Add(ctxChangeTitle(j))
                    Else
                        ph.Controls.Add(lblName(j))
                    End If
                End If
            Next

            chkSelectAll = CType(Me.FindControl("chkSelectAll"), CheckBox)
            chkSelectAll.Attributes.Add("onclick", "addSelectAll()")


            CurrentItemsPerPage = i
            For t As Integer = 1 To ItemsPerPage
                If CurrentItemsPerPage >= t Then
                    If Me.FindControl("chk" & t) IsNot Nothing Then
                        Dim chk As CheckBox = New CheckBox
                        chk = CType(Me.FindControl("chk" & t), CheckBox)
                        chk.Attributes.Add("onclick", "addSelected(" & t & ")")
                    End If
                End If
            Next
            InitializeJavaScript()

        End Sub
#End Region

#Region "Membership Helper Functions"
        Private Sub BuildMembershipProductSegmentAffiliateList()
            Dim dsMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList = Nothing
            'get the items for the current segment - Membership
            dsMembers = GetMembershipProductSegmentAffiliateList()

            If Not dsMembers Is Nothing Then
                'set DataPager
                ItemsCount = dsMembers.Count
                dpMembersView = New WebControls.DataPager()
                dpMembersView.PageSize = ItemsPerPage
                dpMembersView.PagingMode = WebControls.PagingModeType.PostBack

                dpMembersView.DataSource = dsMembers
                dpMembersView.DataBind()
                pnlSegments.Controls.Add(dpMembersView)
                dpMembersView.Visible = True

                tMembers = New Hashtable
                tempMembers = New ArrayList
                For i As Integer = 0 To dsMembers.Count - 1
                    If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                        tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next
                ActualItemsCount = tMembers.Count


                If Page.IsPostBack Then
                    If (EventArgument.IndexOf("SendEmail") >= 0) Or (EventArgument.IndexOf("PrintRoster") >= 0) Or _
                    (EventArgument.IndexOf("PurchaseForAll") >= 0) Or (EventArgument.IndexOf("PurchaseForSelected") >= 0) Then
                        'one of the GroupAction buttons were pressed
                        BuildMembershipProductSegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("searchControlMembers") > 0) Then
                        'Search is done
                        BuildMembershipProductSegmentAffiliateListXSLTemplate()
                    End If
                    'ContextMenu clicked
                    If (EventTarget.IndexOf("ctxChangeTitle", StringComparison.InvariantCultureIgnoreCase) > 0) Then
                        BuildMembershipProductSegmentAffiliateListXSLTemplate()
                    End If
                    If sort Then
                        'when sorting the selection of items is reset
                        hdnSelectedValue = ""
                        BuildMembershipProductSegmentAffiliateListXSLTemplate()
                    End If
                End If
                If Not Page.IsPostBack And (CurrentPage = 0) Then
                    'first load of Affiliatelist
                    BuildMembershipProductSegmentAffiliateListXSLTemplate()
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecords", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
        End Sub
        Private Sub BuildMembershipProductSegmentAffiliateListXSLTemplate()

            If Page.IsPostBack AndAlso (EventTarget.IndexOf("searchControlMembers") > 0) Then
                'if coming from an SearchControl event CurrentPage will be reset
                CurrentPage = 1
                dpMembersView.CurrentPage = 1
            Else
                CurrentPage = dpMembersView.CurrentPage
            End If
            dpMembersView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1


            Dim members(dpMembersView.DataSourcePaged.Count) As MembershipListInfo
            Dim i As Integer = 0
            Dim ie As IEnumerator = dpMembersView.DataSourcePaged.GetEnumerator

            Dim ctxChangeTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenu
            Dim lnkPageTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenuLink
            Dim lblName(dpMembersView.DataSourcePaged.Count) As Label

            While ie.MoveNext
                members(i) = New MembershipListInfo
                members(i).Name = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).LabelName
                members(i).Membership = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).ShortName
                members(i).MemberSince = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).InitialBeginDate.ToString("d")
                members(i).ExpirationDate = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).GraceDate.ToString("d")
                members(i).MasterCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).MasterCustomerId
                members(i).SubCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).SubCustomerId

                If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                    ctxChangeTitle(i) = New MarkItUp.WebControls.ContextMenu

                    Dim AffiliateMasterCustomerId As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).MasterCustomerId
                    Dim AffiliateSubCustomerId As Integer = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).SubCustomerId
                    Dim AffiliateLabelName As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).LabelName

                    AddHandler ctxChangeTitle(i).ItemClick, AddressOf ContextMenuItemClick
                    ctxChangeTitle(i).ID = "ctxChangeTitle" & i
                    Dim omenuitem As MarkItUp.WebControls.ContextMenuItem

                    'test if Send Email item  criterias match
                    If Not (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).PrimaryEmailAddress Is Nothing AndAlso (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).PrimaryEmailAddress <> String.Empty Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuSendEmail", LocalResourceFile)
                            'TODO actual email destination
                            .CommandArgument = "1"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If


                    'test if Create Order item criterias match
                    'If segmentinfo.CanPlaceOrderFlag Then
                    'omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    'With omenuitem
                    '.Text = Localization.GetString("ContextMenuCreateOrder", LocalResourceFile)
                    '.CommandArgument = NavigateURL(CInt(Settings(C_Create_Order_Action_URL)))
                    '.ClientNotificationFunction = "Navigate"
                    'End With
                    'ctxChangeTitle(i).Items.Add(omenuitem)
                    'End If

                    'test if View Order History item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewOrderHistory", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewOrder" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if View Profile item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewProfile", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewProfile" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if Renew item criterias match
                    If segmentinfo.CanPlaceOrderFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuRenew", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Renew_Action_URL)), "", "&ShipCustomerId=" & members(i).MasterCustomerId & "-" & members(i).SubCustomerId)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    lnkPageTitle(i) = New MarkItUp.WebControls.ContextMenuLink
                    With lnkPageTitle(i)
                        .ID = "lnkPageTitle" & i
                        .ContextMenuToOpen = "ctxChangeTitle" & i
                        .Text = members(i).Name
                    End With
                Else
                    lblName(i) = New Label
                    With lblName(i)
                        .Text = members(i).Name
                        .ID = "lblName" & i
                    End With
                End If
                i = i + 1
            End While

            xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/AffiliateMembershipListTemplate.xsl")
            xslMembersView.AddObject("", members)
            xslMembersView.Display()

            Dim j As Integer
            For j = 0 To i - 1
                Dim ph As New PlaceHolder
                ph = CType(Me.FindControl("ph" + (j + 1).ToString), PlaceHolder)
                If (ph IsNot Nothing) Then
                    If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                        ph.Controls.Add(lnkPageTitle(j))
                        ph.Controls.Add(ctxChangeTitle(j))
                    Else
                        ph.Controls.Add(lblName(j))
                    End If
                End If
            Next

            chkSelectAll = CType(Me.FindControl("chkSelectAll"), CheckBox)
            chkSelectAll.Attributes.Add("onclick", "addSelectAll()")

            CurrentItemsPerPage = i
            For t As Integer = 1 To ItemsPerPage
                If CurrentItemsPerPage >= t Then
                    Dim chk As CheckBox = New CheckBox
                    chk = CType(Me.FindControl("chk" & t), CheckBox)
                    chk.Attributes.Add("onclick", "addSelected(" & t & ")")
                End If
            Next

            InitializeJavaScript()
        End Sub

        Private Function GetMembershipProductSegmentAffiliateList() As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
            Try

                Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

                Dim searchField As String = ""
                Dim searchValue As String = ""

                If Page.IsPostBack Then
                    If (EventTarget.IndexOf("searchControlMembers") > 0) And (EventArgument = "ShowAll") Then
                        'if "ShowAll" was clicked Search bar is reset
                        CType(FindControl("searchControlMembers"), SearchControl).SearchText = ""
                        CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsIndex = 0
                    Else
                        If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
                            'obtain search Criteria and value
                            searchField = CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsValue
                            searchValue = CType(FindControl("searchControlMembers"), SearchControl).SearchText
                        End If
                    End If

                End If

                'get items filtered based on searching criterias
                Select Case searchField
                    Case "SEARCHNAME"
                        oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, searchValue, Date.MinValue, Date.MinValue)
                    Case "INITIALBEGINDATE"
                        oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, Nothing, CDate(searchValue), Date.MinValue)
                    Case "GRACEDATE"
                        oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, Nothing, Date.MinValue, CDate(searchValue))
                    Case Else
                        oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2)
                End Select

                'get the sorting criteria
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                    sort = True
                End If
                If EventTarget.IndexOf("btnMembership") >= 0 Then
                    SortCriteria = "ShortName"
                    sort = True
                End If

                If EventTarget.IndexOf("btnMemberSince") >= 0 Then
                    SortCriteria = "InitialBeginDate"
                    sort = True
                End If

                If EventTarget.IndexOf("btnExpirationDate") >= 0 Then
                    SortCriteria = "GraceDate"
                    sort = True
                End If

                'sort the items based on sorting criteria
                If sort AndAlso SortDirection = "asc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                ElseIf sort AndAlso SortDirection = "desc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                    SortDirection = "asc"
                ElseIf Not sort Then
                    '3246-5727317
                    SortCriteria = "LabelName"
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                    'END 3246-5727317
                End If

                If oMembers.Count > 0 Then
                    GetMembershipProductSegmentAffiliateList = oMembers
                Else
                    GetMembershipProductSegmentAffiliateList = Nothing
                End If

                oMembers = Nothing
            Catch ex As Exception
                Throw ex
            Finally

            End Try
        End Function
#End Region

#Region "Geographic Helper Functions"
        Private Sub BuildGeographySegmentAffiliateList()
            Dim dsMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList = Nothing
            'get the items for the current segment - Geography
            dsMembers = GetGeographySegmentAffiliateList()

            If Not dsMembers Is Nothing Then
                'set DataPager
                ItemsCount = dsMembers.Count
                dpMembersView = New WebControls.DataPager()
                dpMembersView.PageSize = ItemsPerPage
                dpMembersView.PagingMode = WebControls.PagingModeType.PostBack

                dpMembersView.DataSource = dsMembers
                dpMembersView.DataBind()
                pnlSegments.Controls.Add(dpMembersView)
                dpMembersView.Visible = True

                tMembers = New Hashtable
                tempMembers = New ArrayList
                For i As Integer = 0 To dsMembers.Count - 1
                    If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                        tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next
                ActualItemsCount = tMembers.Count


                If Page.IsPostBack Then
                    If (EventArgument.IndexOf("SendEmail") >= 0) Or (EventArgument.IndexOf("PrintRoster") >= 0) Or _
                        (EventArgument.IndexOf("PurchaseForAll") >= 0) Or (EventArgument.IndexOf("PurchaseForSelected") >= 0) Then
                        'one of the GroupAction buttons was pressed
                        BuildGeographySegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("searchControlMembers") > 0) Then
                        'Search is done
                        BuildGeographySegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("ctxChangeTitle", StringComparison.InvariantCultureIgnoreCase) > 0) Then
                        'ContextMenu clicked
                        BuildGeographySegmentAffiliateListXSLTemplate()
                    End If
                    If sort Then
                        'after sorting the selection of items is reset
                        hdnSelectedValue = ""
                        BuildGeographySegmentAffiliateListXSLTemplate()
                    End If
                End If
                If Not Page.IsPostBack And (CurrentPage = 0) Then
                    'first load of Affiliatelist page
                    BuildGeographySegmentAffiliateListXSLTemplate()
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecords", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
        End Sub
        Private Sub BuildGeographySegmentAffiliateListXSLTemplate()

            If Page.IsPostBack AndAlso (EventTarget.IndexOf("searchControlMembers") > 0) Then
                'if coming from an SearchControl event CurrentPage will be reset
                CurrentPage = 1
                dpMembersView.CurrentPage = 1
            Else
                CurrentPage = dpMembersView.CurrentPage
            End If
            dpMembersView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1


            Dim members(dpMembersView.DataSourcePaged.Count) As GeographicListInfo
            Dim i As Integer = 0
            Dim ie As IEnumerator = dpMembersView.DataSourcePaged.GetEnumerator

            Dim ctxChangeTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenu
            Dim lnkPageTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenuLink
            Dim lblName(dpMembersView.DataSourcePaged.Count) As Label


            While ie.MoveNext
                members(i) = New GeographicListInfo
                members(i).Name = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).LabelName
                members(i).City = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).City
                members(i).State = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).State
                members(i).Country = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).CountryCodeString
                members(i).Phone = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).PrimaryPhone
                members(i).MasterCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).MasterCustomerId
                members(i).SubCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).SubCustomerId

                If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                    ctxChangeTitle(i) = New MarkItUp.WebControls.ContextMenu
                    AddHandler ctxChangeTitle(i).ItemClick, AddressOf ContextMenuItemClick

                    Dim AffiliateMasterCustomerId As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).MasterCustomerId
                    Dim AffiliateSubCustomerId As Integer = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).SubCustomerId
                    Dim AffiliateLabelName As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductMembershipInfoView)).LabelName



                    ctxChangeTitle(i).ID = "ctxChangeTitle" & i
                    Dim omenuitem As MarkItUp.WebControls.ContextMenuItem

                    'test if Send Email item  criterias match
                    If Not (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PrimaryEmailAddress Is Nothing AndAlso (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PrimaryEmailAddress <> String.Empty Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuSendEmail", LocalResourceFile)
                            'TODO actual email destination
                            .CommandArgument = "1"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If


                    'test if Create Order item criterias match
                    'If segmentinfo.CanPlaceOrderFlag Then
                    'omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    'With omenuitem
                    '.Text = Localization.GetString("ContextMenuCreateOrder", LocalResourceFile)
                    '.CommandArgument = NavigateURL(CInt(Settings(C_Create_Order_Action_URL)))
                    '.ClientNotificationFunction = "Navigate"
                    'End With
                    'ctxChangeTitle(i).Items.Add(omenuitem)
                    'End If

                    'test if View Order History item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewOrderHistory", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewOrder" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if View Profile item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewProfile", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewProfile" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if Renew item criterias match
                    If segmentinfo.CanPlaceOrderFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuRenew", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Renew_Action_URL)), "", "&ShipCustomerId=" & members(i).MasterCustomerId & "-" & members(i).SubCustomerId)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If
                Else
                    lblName(i) = New Label
                    With lblName(i)
                        .Text = members(i).Name
                        .ID = "lblName" & i
                    End With
                End If
                i = i + 1
            End While

            xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/AffiliateGeographicListTemplate.xsl")
            xslMembersView.AddObject("", members)
            xslMembersView.Display()

            Dim j As Integer
            For j = 0 To i - 1
                Dim ph As New PlaceHolder
                ph = CType(Me.FindControl("ph" + (j + 1).ToString), PlaceHolder)
                If (ph IsNot Nothing) Then
                    If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                        ph.Controls.Add(lnkPageTitle(j))
                        ph.Controls.Add(ctxChangeTitle(j))
                    Else
                        ph.Controls.Add(lblName(j))
                    End If
                End If
            Next

            chkSelectAll = CType(Me.FindControl("chkSelectAll"), CheckBox)
            chkSelectAll.Attributes.Add("onclick", "addSelectAll()")

            CurrentItemsPerPage = i
            For t As Integer = 1 To ItemsPerPage
                If CurrentItemsPerPage >= t Then
                    Dim chk As CheckBox = New CheckBox
                    chk = CType(Me.FindControl("chk" & t), CheckBox)
                    chk.Attributes.Add("onclick", "addSelected(" & t & ")")
                End If
            Next

            InitializeJavaScript()

        End Sub

        Private Function GetGeographySegmentAffiliateList() As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList
            Try
                Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

                Dim searchField As String = ""
                Dim searchValue As String = ""

                If Page.IsPostBack Then
                    If (EventTarget.IndexOf("searchControlMembers") > 0) And (EventArgument = "ShowAll") Then
                        'if "ShowAll" was clicked Search bar is reset
                        CType(FindControl("searchControlMembers"), SearchControl).SearchText = ""
                        CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsIndex = 0
                    Else
                        If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
                            'obtain search Criteria and value
                            searchField = CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsValue
                            searchValue = CType(FindControl("searchControlMembers"), SearchControl).SearchText
                        End If
                    End If

                End If

                'get items filtered based on searching criterias
                Select Case searchField
                    Case "LABELNAME"
                        oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, searchValue, Nothing, Nothing, Nothing)
                    Case "CITY"
                        oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, Nothing, searchValue, Nothing, Nothing)
                    Case "STATE"
                        oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, Nothing, Nothing, searchValue, Nothing)
                    Case "COUNTRYCODE"
                        oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, Nothing, Nothing, Nothing, searchValue)
                    Case Else
                        oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2)
                End Select

                'get the sorting criterias
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                    sort = True
                End If
                If EventTarget.IndexOf("btnCity") >= 0 Then
                    SortCriteria = "City"
                    sort = True
                End If

                If EventTarget.IndexOf("btnState") >= 0 Then
                    SortCriteria = "State"
                    sort = True
                End If

                If EventTarget.IndexOf("btnCountry") >= 0 Then
                    SortCriteria = "CountryCode"
                    sort = True
                End If

                If EventTarget.IndexOf("btnPhone") >= 0 Then
                    SortCriteria = "PrimaryPhone"
                    sort = True
                End If

                'sort the items
                If sort AndAlso SortDirection = "asc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                ElseIf sort AndAlso SortDirection = "desc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                    SortDirection = "asc"
                ElseIf Not sort Then
                    '3246-5727317
                    SortCriteria = "LabelName"
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                    'END 3246-5727317
                End If

                If oMembers.Count > 0 Then
                    GetGeographySegmentAffiliateList = oMembers
                Else
                    GetGeographySegmentAffiliateList = Nothing
                End If

                oMembers = Nothing
            Catch ex As Exception
                Throw ex
            Finally

            End Try
        End Function
#End Region

#Region "Miscellaneous Segment Affiliate List Helper Function"
        Private Sub BuildMiscellaneousSegmentAffiliateList()
            Dim dsMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList = Nothing
            'get the items of the current segment -Miscellaneous
            dsMembers = GetMiscellaneousSegmentAffiliateList()

            If Not dsMembers Is Nothing Then
                'set DataPager
                ItemsCount = dsMembers.Count
                dpMembersView = New WebControls.DataPager()
                dpMembersView.PageSize = ItemsPerPage
                dpMembersView.PagingMode = WebControls.PagingModeType.PostBack

                dpMembersView.DataSource = dsMembers
                dpMembersView.DataBind()
                pnlSegments.Controls.Add(dpMembersView)
                dpMembersView.Visible = True

                tMembers = New Hashtable
                tempMembers = New ArrayList
                For i As Integer = 0 To dsMembers.Count - 1
                    If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                        tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next
                ActualItemsCount = tMembers.Count


                If Page.IsPostBack Then
                    If (EventArgument.IndexOf("SendEmail") >= 0) Or (EventArgument.IndexOf("PrintRoster") >= 0) Or _
                        (EventArgument.IndexOf("PurchaseForAll") >= 0) Or (EventArgument.IndexOf("PurchaseForSelected") >= 0) Then
                        'one of the GroupAction buttons was pressed
                        BuildMiscellaneousSegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("searchControlMembers") > 0) Then
                        'Search is done
                        BuildMiscellaneousSegmentAffiliateListXSLTemplate()
                    End If
                    If (EventTarget.IndexOf("ctxChangeTitle", StringComparison.InvariantCultureIgnoreCase) > 0) Then
                        'ContextMenu clicked
                        BuildMiscellaneousSegmentAffiliateListXSLTemplate()
                    End If
                    If sort Then
                        'when sorting selection of items is reset
                        hdnSelectedValue = ""
                        BuildMiscellaneousSegmentAffiliateListXSLTemplate()
                    End If
                End If
                If Not Page.IsPostBack And (CurrentPage = 0) Then
                    'first load of the Affiliatelist page
                    BuildMiscellaneousSegmentAffiliateListXSLTemplate()
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoRecords", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If
        End Sub
        Private Sub BuildMiscellaneousSegmentAffiliateListXSLTemplate()

            If Page.IsPostBack AndAlso (EventTarget.IndexOf("searchControlMembers") > 0) Then
                'if coming from an SearchControl event CurrentPage will be reset
                CurrentPage = 1
                dpMembersView.CurrentPage = 1
            Else
                CurrentPage = dpMembersView.CurrentPage
            End If
            dpMembersView.DataSourcePaged.CurrentPageIndex = CurrentPage - 1


            Dim members(dpMembersView.DataSourcePaged.Count) As MiscellaneousListInfo
            Dim i As Integer = 0
            Dim ie As IEnumerator = dpMembersView.DataSourcePaged.GetEnumerator

            Dim ctxChangeTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenu
            Dim lnkPageTitle(dpMembersView.DataSourcePaged.Count) As MarkItUp.WebControls.ContextMenuLink
            Dim lblName(dpMembersView.DataSourcePaged.Count) As Label


            While ie.MoveNext
                members(i) = New MiscellaneousListInfo
                members(i).Name = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).LabelName
                members(i).Product = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).ShortName
                members(i).PurchaseDate = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).OrderDate.ToString("d")
                members(i).MasterCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).MasterCustomerId
                members(i).SubCustomerId = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).SubCustomerId

                If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                    ctxChangeTitle(i) = New MarkItUp.WebControls.ContextMenu
                    AddHandler ctxChangeTitle(i).ItemClick, AddressOf ContextMenuItemClick

                    Dim AffiliateMasterCustomerId As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).MasterCustomerId
                    Dim AffiliateSubCustomerId As Integer = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).SubCustomerId
                    Dim AffiliateLabelName As String = (CType(ie.Current, TIMSS.API.WebInfo.IWebSegProductOthersInfoView)).LabelName


                    ctxChangeTitle(i).ID = "ctxChangeTitle" & i
                    Dim omenuitem As MarkItUp.WebControls.ContextMenuItem

                    'test if Send Email item  criterias match
                    If Not (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PrimaryEmailAddress Is Nothing AndAlso (CType(ie.Current, TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoView)).PrimaryEmailAddress <> String.Empty Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuSendEmail", LocalResourceFile)
                            'TODO actual email destination
                            .CommandArgument = "1"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If


                    'test if Create Order item criterias match
                    'If segmentinfo.CanPlaceOrderFlag Then
                    'omenuitem = New MarkItUp.WebControls.ContextMenuItem
                    'With omenuitem
                    '.Text = Localization.GetString("ContextMenuCreateOrder", LocalResourceFile)
                    '.CommandArgument = NavigateURL(CInt(Settings(C_Create_Order_Action_URL)))
                    '.ClientNotificationFunction = "Navigate"
                    'End With
                    'ctxChangeTitle(i).Items.Add(omenuitem)
                    'End If

                    'test if View Order History item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewOrderHistory", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewOrder" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if View Profile item criterias match
                    If Not segmentinfo.ReadOnlyFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuViewProfile", LocalResourceFile)
                            'CommandArgument is given as an array as "ItemType;AffiliateMasterCustomerIs;AffiliateSubCustomerId;AffiliateLabelName"
                            .CommandArgument = "ViewProfile" & ";" & AffiliateMasterCustomerId & ";" & CStr(AffiliateSubCustomerId) & ";" & AffiliateLabelName
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If

                    'test if Renew item criterias match
                    If segmentinfo.CanPlaceOrderFlag Then
                        omenuitem = New MarkItUp.WebControls.ContextMenuItem
                        With omenuitem
                            .Text = Localization.GetString("ContextMenuRenew", LocalResourceFile)
                            .CommandArgument = NavigateURL(CInt(Settings(C_Renew_Action_URL)), "", "&ShipCustomerId=" & members(i).MasterCustomerId & "-" & members(i).SubCustomerId)
                            .ClientNotificationFunction = "Navigate"
                        End With
                        ctxChangeTitle(i).Items.Add(omenuitem)
                    End If
                Else
                    lblName(i) = New Label
                    With lblName(i)
                        .Text = members(i).Name
                        .ID = "lblName" & i
                    End With
                End If
                i = i + 1
            End While

            xslMembersView.XSLfile = Server.MapPath(ModulePath + "/Templates/AffiliateMiscellaneousListTemplate.xsl")
            xslMembersView.AddObject("", members)
            xslMembersView.Display()

            Dim j As Integer
            For j = 0 To i - 1
                Dim ph As New PlaceHolder
                ph = CType(Me.FindControl("ph" + (j + 1).ToString), PlaceHolder)
                If (ph IsNot Nothing) Then
                    If (Not Settings(C_Show_Group_Panel) Is Nothing) AndAlso CStr(Settings(C_Show_Group_Panel)) = "GroupAction" Then
                        ph.Controls.Add(lnkPageTitle(j))
                        ph.Controls.Add(ctxChangeTitle(j))
                    Else
                        ph.Controls.Add(lblName(j))
                    End If
                End If
            Next

            chkSelectAll = CType(Me.FindControl("chkSelectAll"), CheckBox)
            chkSelectAll.Attributes.Add("onclick", "addSelectAll()")

            CurrentItemsPerPage = i
            For t As Integer = 1 To ItemsPerPage
                If CurrentItemsPerPage >= t Then
                    Dim chk As CheckBox = New CheckBox
                    chk = CType(Me.FindControl("chk" & t), CheckBox)
                    chk.Attributes.Add("onclick", "addSelected(" & t & ")")
                End If
            Next

            InitializeJavaScript()
        End Sub

        Private Function GetMiscellaneousSegmentAffiliateList() As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList
            Try

                Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList

                Dim searchField As String = ""
                Dim searchValue As String = ""


                If Page.IsPostBack Then
                    If (EventTarget.IndexOf("searchControlMembers") > 0) And (EventArgument = "ShowAll") Then
                        'if "ShowAll" is clicked Search bar is reset
                        CType(FindControl("searchControlMembers"), SearchControl).SearchText = ""
                        CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsIndex = 0
                    Else
                        If Not Settings(C_Show_Search) Is Nothing AndAlso CStr(Settings(C_Show_Search)) = "Y" Then
                            'obtain search Criteria and value
                            searchField = CType(FindControl("searchControlMembers"), SearchControl).SearchFieldsValue
                            searchValue = CType(FindControl("searchControlMembers"), SearchControl).SearchText
                        End If
                    End If
                End If

                'get the items filtered based on searching criterias
                Select Case searchField
                    Case "LABELNAME"
                        oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, searchValue, Nothing, Date.MinValue)
                    Case "COMPANYNAME"
                        oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, Nothing, searchValue, Date.MinValue)
                    Case "ORDERDATE"
                        If Not IsDate(searchValue) Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("InvalidDateError", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Return Nothing
                        Else
                            oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, Nothing, Nothing, CDate(searchValue))
                        End If
                    Case Else
                        oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2)
                End Select

                'get the sorting criteria
                If EventTarget.IndexOf("btnName") >= 0 Then
                    SortCriteria = "LabelName"
                    sort = True
                End If
                If EventTarget.IndexOf("btnProduct") >= 0 Then
                    SortCriteria = "ShortName"
                    sort = True
                End If

                If EventTarget.IndexOf("btnPurchaseDate") >= 0 Then
                    SortCriteria = "OrderDate"
                    sort = True
                End If

                'sort the items
                If sort AndAlso SortDirection = "asc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                ElseIf sort AndAlso SortDirection = "desc" Then
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                    SortDirection = "asc"
                ElseIf Not sort Then
                    '3246-5727317
                    SortCriteria = "LabelName"
                    oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                    SortDirection = "desc"
                    'END 3246-5727317
                End If

                If oMembers.Count > 0 Then
                    GetMiscellaneousSegmentAffiliateList = oMembers
                Else
                    GetMiscellaneousSegmentAffiliateList = Nothing
                End If

                oMembers = Nothing
            Catch ex As Exception
                Throw ex
            Finally

            End Try
        End Function
#End Region

#End Region

#Region "Get Members Count functions"
        Private Function GetCommitteeSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList
            oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2)

            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If

        End Function

        Private Function GetEmployeeSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList

            oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2)

            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function

        Private Function GetMembershipProductSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

            oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2)
            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function

        Private Function GetGeographySegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

            oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2)

            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function

        Private Function GetMiscellaneousSegmentAffiliateListCount(ByVal qualifier1 As String, ByVal qualifier2 As String) As Integer
            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList

            oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2)
            If oMembers Is Nothing Then
                Return 0
            Else
                '3246-5848465
                Dim tMembers As Hashtable = New Hashtable
                Dim tempMembers As ArrayList = New ArrayList
                For i As Integer = 0 To oMembers.Count - 1
                    If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                        tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                        tempMembers.Add(False)
                    Else
                        tempMembers.Add(True)
                    End If
                Next

                Return tMembers.Count
                'end '3246-5848465
            End If
        End Function
#End Region

#Region "Remove member"
        'check if ContextMenu Remove item was pressed
        Private Sub RemoveItemFromAffiliateList()
            Dim strQueryString As String = Request.Url.Query
            Dim arrQueryString() As String = strQueryString.Split(CChar("&"))
            Dim strQueryParam As String
            Dim remove As Boolean = False
            Dim SegmentMemberId As Integer

            'check if Remove item from contextMenu was pressed
            For Each strQueryParam In arrQueryString
                If strQueryParam.IndexOf("action") <> -1 Then
                    remove = True
                ElseIf strQueryParam.IndexOf("args") <> -1 Then
                    SegmentMemberId = CInt(strQueryParam.Replace("args=", ""))
                End If
            Next

            If remove Then
                Dim validationIssues As TIMSS.API.Core.Validation.IIssuesCollection = Nothing
                Select Case SegmentType
                    Case C_SEGMENT_COMMITTEE
                        'remove committee member
                        validationIssues = SaveCommitteeMember(PersonifyEnumerations.TransactionMode.DELETE, _
                            qualifier1, _
                            CInt(qualifier2), Nothing, -1, _
                            Nothing, Nothing, _
                            Nothing, _
                            Nothing, Nothing, Nothing, _
                            Nothing, Nothing, SegmentMemberId)


                    Case C_SEGMENT_EMPLOYEE
                        'remove employee
                        validationIssues = SaveEmployeeRelationship(PersonifyEnumerations.TransactionMode.DELETE, _
                            qualifier1, _
                            CInt(qualifier2), Nothing, -1, Nothing, _
                            Nothing, Nothing, Nothing, _
                            Nothing, Nothing, Nothing, Nothing, SegmentMemberId)
                End Select

                If Not oMessageControl.ValidationIssues Is Nothing Then
                    oMessageControl.Clear()
                End If

                If validationIssues.Count > 0 Then
                    'The save was not successfull
                    oMessageControl.Show(CType(validationIssues, TIMSS.API.Core.Validation.IssuesCollection))
                End If
            End If

        End Sub
#End Region

#Region "Group Action buttons: Send Email or Print Roster"

        'test if Group Action buttons(Send Email, Print Roster, Purchase All, Purchase Selected) were pressed 
        'test if AllEmployees or Selected Employees were selected
        'management of AffiliateGroupActionInfo - save, remove, get
        Private Function CheckIfGroupActions() As String
            Dim GroupActionNavigateURL As String = String.Empty
            Dim strucGroupActionInfo As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = Nothing
            Dim arrGroupActionInfo As New ArrayList

            If Page.IsPostBack Then
                If (EventArgument.IndexOf("SendEmail") >= 0) Or (EventArgument.IndexOf("PrintRoster") >= 0) Or _
                (EventArgument.IndexOf("PurchaseForAll") >= 0) Or (EventArgument.IndexOf("PurchaseForSelected") >= 0) Then


                    Dim ApplyTo As String = String.Empty
                    Dim ApplyToBottom As String = String.Empty
                    Dim selectedMembers As String = String.Empty
                    Dim purchase As Boolean = False


                    Dim ctl As String = String.Empty

                    For Each ctl In Request.Params.AllKeys
                        'test if rdApplyTo from Bottom Members Action Bar is checked
                        If ctl IsNot Nothing AndAlso ((ctl.IndexOf("memberActionsBottom:rdApplyTo") >= 0) Or (ctl.IndexOf("memberActionsBottom$rdApplyTo") >= 0)) Then
                            ApplyToBottom = Request.Params(ctl)
                        End If
                        'test if rdApplyTo from Top Members Action Bar is checked
                        If ctl IsNot Nothing AndAlso ((ctl.IndexOf("memberActions:rdApplyTo") >= 0) Or (ctl.IndexOf("memberActions$rdApplyTo") >= 0)) Then
                            ApplyTo = Request.Params(ctl)
                        End If
                        'test for the value of hdnSelected - which keeps the array of currently selected items
                        If ctl IsNot Nothing AndAlso ctl.IndexOf("hdnSelected") >= 0 Then
                            selectedMembers = Request.Params(ctl)
                        End If
                    Next
                    '"Purchase for all" button was pressed
                    If EventArgument.IndexOf("PurchaseForAll") >= 0 Then
                        ApplyTo = "AllEmployees"
                        purchase = True
                    End If
                    '"Purchase for selected" button was pressed
                    If EventArgument.IndexOf("PurchaseForSelected") >= 0 Then
                        ApplyTo = "Selected"
                        purchase = True
                    End If

                    'check the synchronization between the radio button checked and the members action button pressed
                    'when button from top bar is pressed the top radio is taken in consideration
                    'when button from bottom bar is pressed the bottom radio is taken in consideration
                    Dim bottomControl As Boolean = False
                    If EventTarget.IndexOf("memberActionsBottom") >= 0 Then
                        bottomControl = True
                        If selectedMembers = String.Empty AndAlso ApplyToBottom = "Selected" Then
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMembersSelected", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Return ""
                        End If
                    Else
                        If EventTarget.IndexOf("memberActions") >= 0 Then
                            bottomControl = False
                            If selectedMembers = String.Empty AndAlso ApplyTo = "Selected" Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMembersSelected", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Return ""
                            End If
                        End If
                    End If

                    'build the Affiliate List for each of the types of segments
                    Select Case SegmentType
                        Case C_SEGMENT_EMPLOYEE
                            'employee segment type
                            Dim dsMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList = Nothing
                            'get the members of this segment
                            dsMembers = GetEmployeeSegmentAffiliateList()

                            tMembers = New Hashtable
                            tempMembers = New ArrayList
                            For i As Integer = 0 To dsMembers.Count - 1
                                If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                                    tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                                    tempMembers.Add(False)
                                Else
                                    tempMembers.Add(True)
                                End If
                            Next

                            If Not dsMembers Is Nothing Then
                                If (purchase = True And ApplyTo = "AllEmployees") Or (ApplyTo = "AllEmployees" AndAlso bottomControl = False) Or (ApplyToBottom = "AllEmployees" AndAlso bottomControl = True) Then
                                    'if radio button "All" is checked then all the members will be saved to GroupActionAffiliateInfo
                                    Dim i As Integer
                                    For i = 0 To dsMembers.Count - 1
                                        If Not CBool(tempMembers(i)) Then
                                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                            With strucGroupActionInfo
                                                .AffiliateCustomerId.MasterCustomerId = dsMembers(i).MasterCustomerId
                                                .AffiliateCustomerId.SubCustomerId = dsMembers(i).SubCustomerId
                                                .AffiliateLabelName = dsMembers(i).LabelName
                                                .CustomerIdKey = dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId
                                                .EmailAddress = dsMembers(i).PrimaryEmailAddress()
                                            End With
                                            arrGroupActionInfo.Add(strucGroupActionInfo)
                                        End If
                                    Next
                                Else
                                    'if "Selected" radio button was checked only the selected items will be saved to GroupActionAffiliateInfo
                                    Dim i As Integer
                                    For i = 0 To dsMembers.Count - 1
                                        Dim members() As String = selectedMembers.Split(CChar(";"))
                                        Dim j As Integer
                                        For j = 0 To members.Length - 1
                                            If members(j) <> String.Empty Then
                                                If i = CInt(members(j)) Then
                                                    If Not CBool(tempMembers(CInt(members(j)))) Then
                                                        strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                                        With strucGroupActionInfo
                                                            .AffiliateCustomerId.MasterCustomerId = dsMembers(i).MasterCustomerId
                                                            .AffiliateCustomerId.SubCustomerId = dsMembers(i).SubCustomerId
                                                            .AffiliateLabelName = dsMembers(i).LabelName
                                                            .CustomerIdKey = dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId
                                                            .EmailAddress = dsMembers(i).PrimaryEmailAddress()
                                                        End With
                                                        arrGroupActionInfo.Add(strucGroupActionInfo)
                                                    End If
                                                    Exit For
                                                End If
                                            End If
                                        Next
                                    Next
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMembersSelected", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Return ""
                            End If

                        Case C_SEGMENT_COMMITTEE
                            'committee segment type
                            Dim dsMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList = Nothing
                            'get the members 
                            dsMembers = GetCommitteeSegmentAffiliateList()

                            tMembers = New Hashtable
                            tempMembers = New ArrayList
                            For i As Integer = 0 To dsMembers.Count - 1
                                If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                                    tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                                    tempMembers.Add(False)
                                Else
                                    tempMembers.Add(True)
                                End If
                            Next

                            If Not dsMembers Is Nothing Then
                                If (purchase = True And ApplyTo = "AllEmployees") Or (ApplyTo = "AllEmployees" AndAlso bottomControl = False) Or (ApplyToBottom = "AllEmployees" AndAlso bottomControl = True) Then
                                    'if radio button "All" is checked then all the members will be saved to GroupActionAffiliateInfo
                                    Dim i As Integer
                                    For i = 0 To dsMembers.Count - 1
                                        If Not CBool(tempMembers(i)) Then
                                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                            With strucGroupActionInfo
                                                .AffiliateCustomerId.MasterCustomerId = dsMembers(i).MasterCustomerId
                                                .AffiliateCustomerId.SubCustomerId = dsMembers(i).SubCustomerId
                                                .AffiliateLabelName = dsMembers(i).LabelName
                                                .CustomerIdKey = dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId
                                                .EmailAddress = dsMembers(i).PrimaryEmailAddress()
                                            End With
                                            arrGroupActionInfo.Add(strucGroupActionInfo)
                                        End If
                                    Next
                                Else
                                    'if "Selected" radio button was checked only the selected items will be saved to GroupActionAffiliateInfo
                                    Dim i As Integer
                                    For i = 0 To dsMembers.Count - 1
                                        Dim members() As String = selectedMembers.Split(CChar(";"))
                                        Dim j As Integer
                                        For j = 0 To members.Length - 1
                                            If members(j) <> String.Empty Then

                                                If i = CInt(members(j)) Then
                                                    If Not CBool(tempMembers(CInt(members(j)))) Then

                                                        strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                                        With strucGroupActionInfo
                                                            .AffiliateCustomerId.MasterCustomerId = dsMembers(i).MasterCustomerId
                                                            .AffiliateCustomerId.SubCustomerId = dsMembers(i).SubCustomerId
                                                            .AffiliateLabelName = dsMembers(i).LabelName
                                                            .CustomerIdKey = dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId
                                                            .EmailAddress = dsMembers(i).PrimaryEmailAddress()
                                                        End With
                                                        arrGroupActionInfo.Add(strucGroupActionInfo)
                                                    End If
                                                    Exit For
                                                End If
                                            End If
                                        Next
                                    Next
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMembersSelected", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Return ""
                            End If

                            'AN Defect 3246-8183108     .. not in love with this code. This needs to be refactored in a major way.
                        Case "PRODUCT"
                            'committee segment type
                            Dim dsMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList = Nothing

                            'get the members 
                            dsMembers = GetMembershipProductSegmentAffiliateList()

                            tMembers = New Hashtable
                            tempMembers = New ArrayList
                            For i As Integer = 0 To dsMembers.Count - 1
                                If Not tMembers.ContainsKey(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId) Then
                                    tMembers.Add(dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId, 0)
                                    tempMembers.Add(False)
                                Else
                                    tempMembers.Add(True)
                                End If
                            Next

                            If Not dsMembers Is Nothing Then
                                If (purchase = True And ApplyTo = "AllEmployees") Or (ApplyTo = "AllEmployees" AndAlso bottomControl = False) Or (ApplyToBottom = "AllEmployees" AndAlso bottomControl = True) Then
                                    'if radio button "All" is checked then all the members will be saved to GroupActionAffiliateInfo
                                    Dim i As Integer
                                    For i = 0 To dsMembers.Count - 1
                                        If Not CBool(tempMembers(i)) Then
                                            strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                            With strucGroupActionInfo
                                                .AffiliateCustomerId.MasterCustomerId = dsMembers(i).MasterCustomerId
                                                .AffiliateCustomerId.SubCustomerId = dsMembers(i).SubCustomerId
                                                .AffiliateLabelName = dsMembers(i).LabelName
                                                .CustomerIdKey = dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId
                                                .EmailAddress = dsMembers(i).PrimaryEmailAddress()
                                            End With
                                            arrGroupActionInfo.Add(strucGroupActionInfo)
                                        End If
                                    Next
                                Else
                                    'if "Selected" radio button was checked only the selected items will be saved to GroupActionAffiliateInfo
                                    Dim i As Integer
                                    For i = 0 To dsMembers.Count - 1
                                        Dim members() As String = selectedMembers.Split(CChar(";"))
                                        Dim j As Integer
                                        For j = 0 To members.Length - 1
                                            If members(j) <> String.Empty Then

                                                If i = CInt(members(j)) Then
                                                    If Not CBool(tempMembers(CInt(members(j)))) Then

                                                        strucGroupActionInfo = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                                                        With strucGroupActionInfo
                                                            .AffiliateCustomerId.MasterCustomerId = dsMembers(i).MasterCustomerId
                                                            .AffiliateCustomerId.SubCustomerId = dsMembers(i).SubCustomerId
                                                            .AffiliateLabelName = dsMembers(i).LabelName
                                                            .CustomerIdKey = dsMembers(i).MasterCustomerId & "-" & dsMembers(i).SubCustomerId
                                                            .EmailAddress = dsMembers(i).PrimaryEmailAddress()
                                                        End With
                                                        arrGroupActionInfo.Add(strucGroupActionInfo)
                                                    End If
                                                    Exit For
                                                End If
                                            End If
                                        Next
                                    Next
                                End If
                            Else
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("NoMembersSelected", LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                                Return ""
                            End If

                    End Select


                    'from an ArrayList of GroupActionAffiliateInfo items create an array of GroupActionAffiliateInfo to be saved later 
                    Dim arrTempGroupActionInfo(arrGroupActionInfo.Count - 1) As AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                    For i As Integer = 0 To arrGroupActionInfo.Count - 1
                        arrTempGroupActionInfo(i) = New AffiliateManagementSessionHelper.GroupActionAffiliateInfo
                        arrTempGroupActionInfo(i) = CType(arrGroupActionInfo.Item(i), AffiliateManagementSessionHelper.GroupActionAffiliateInfo)
                    Next

                    Select Case EventArgument
                        Case "SendEmail"
                            'if "Send Email" button was pressed set NavigateURL accordingly and save to AffiliateGroupActionInfo
                            GroupActionNavigateURL = NavigateURL(CInt(Settings(C_Group_Email_Action_URL)))
                            AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.SENDEMAIL, arrTempGroupActionInfo)
                        Case "PrintRoster"
                            'if "Print Roster" button was pressed set NavigateURL accordingly and save to AffiliateGroupActionInfo
                            GroupActionNavigateURL = NavigateURL(CInt(Settings(C_Print_Roster_Action_URL)))
                            AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PRINTROSTER, arrTempGroupActionInfo)

                            ' COMES HERE WHEN "PURCHASE ALL" button is clicked
                        Case "PurchaseForAll"
                            GroupActionNavigateURL = NavigateURL(CInt(Settings(C_Purchase_Action_URL)))
                            AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)


                            ' Comes here when "PURCHASE FOR SELECTED" button is clicked
                        Case "PurchaseForSelected"
                            GroupActionNavigateURL = NavigateURL(CInt(Settings(C_Purchase_Action_URL)))
                            AffiliateManagementSessionHelper.CreateAffiliateGroupActionInfo(PortalId, AffiliateManagementSessionHelper.enmGroupAction.PURCHASE, arrTempGroupActionInfo)

                            'if pressing Yes button in Group Purchase page
                        Case "PurchaseConfirmAction"
                            ' Add the items to the shopping cart for all members
                            AddProductsToCart(arrTempGroupActionInfo)
                            GroupActionNavigateURL = NavigateURL(CType(Settings(C_Buy_Product_Action_URL), Integer))

                            'if pressing Cancel button in Group Purchase page
                        Case "PurchaseCancel"
                            AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                            AffiliateManagementSessionHelper.RemoveGroupPurchaseInfo(PortalId)
                            GroupActionNavigateURL = NavigateURL(segmentinfo.AffiliateListTabId)

                        Case "EmailCancel"
                            'if pressing Cancel button in Email Group Action page
                            'remove from AffiliateGroupActionInfo
                            AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                            'set NavigateURL to AffiliateList TabId - back
                            GroupActionNavigateURL = NavigateURL(segmentinfo.AffiliateListTabId)
                        Case "PrintCancel"
                            'if pressing Cancel button in Print roster Group Action page
                            'remove from AffiliateGroupActionInfo
                            AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                            'set NavigateURL to AffiliateList TabId - back
                            GroupActionNavigateURL = NavigateURL(segmentinfo.AffiliateListTabId)
                    End Select
                End If
            End If
            If Page.IsPostBack Then
                Select Case EventArgument
                    'if pressing Yes button in Group Purchase page
                    Case "PurchaseConfirmAction"
                        Dim arrTempGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
                        ' Add the items to the shopping cart for all members
                        AddProductsToCart(arrTempGroupActionInfo)
                        GroupActionNavigateURL = NavigateURL(CType(Settings(C_Buy_Product_Action_URL), Integer))

                        'if pressing Cancel button in Group Purchase page
                    Case "PurchaseCancel"
                        AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                        AffiliateManagementSessionHelper.RemoveGroupPurchaseInfo(PortalId)
                        GroupActionNavigateURL = NavigateURL(segmentinfo.AffiliateListGroupPurchaseTabId) 'segmentinfo.AffiliateListTabId)

                    Case "EmailCancel"
                        'if pressing Cancel button in Email Group Action page
                        'remove from AffiliateGroupActionInfo
                        AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                        'set NavigateURL to AffiliateList TabId - back
                        GroupActionNavigateURL = NavigateURL(segmentinfo.AffiliateListTabId)
                    Case "PrintCancel"
                        'if pressing Cancel button in Email Group Action page
                        'remove from AffiliateGroupActionInfo
                        AffiliateManagementSessionHelper.RemoveAffiliateGroupActionInfo(PortalId)
                        'set NavigateURL to AffiliateList TabId - back
                        GroupActionNavigateURL = NavigateURL(segmentinfo.AffiliateListTabId)
                End Select
            End If

            Return GroupActionNavigateURL

        End Function

        Private Sub AddProductsToCart(ByVal arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo)

            ' Add the items to the shopping cart for all the members
            Dim Guid As String = AffiliateManagementSessionHelper.GetGroupPurchaseCartGUID(PortalId)

            Dim oShopCartController As New ShoppingCartManager.Business.ShoppingCartController
            'AM FIX - Affiliate Mgmt ticket 3246-8290097 
            Dim MeetingCartItemId As Integer
            Dim CartItemId As Integer

            'Get the list of products that need to be added for each member
            Dim oProductList As ArrayList = oShopCartController.GetCustomerCart(Guid, 0, False, True)

            Dim oCartInfo As ShoppingCartManager.Business.ShoppingCartInfo

            ' Loop through  each member in the list and add the products for the member

            For index1 As Integer = 0 To arrGroupActionInfo.Length - 1

                'First Add the Main Meeting to the cart ..ie items with related cart item id = 0
                For index2 As Integer = 0 To oProductList.Count - 1
                    oCartInfo = CType(oProductList(index2), ShoppingCartManager.Business.ShoppingCartInfo)

                    If oCartInfo.RelatedCartItemId = 0 Then
                        With oCartInfo
                            .MasterCustomerId = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
                            .SubCustomerId = Integer.Parse(UserInfo.Profile.GetPropertyValue("SubCustomerId"))
                            .ShipCustomerLabelName = arrGroupActionInfo(index1).AffiliateLabelName
                            .ShipMasterCustomerId = arrGroupActionInfo(index1).AffiliateCustomerId.MasterCustomerId
                            .ShipSubCustomerId = arrGroupActionInfo(index1).AffiliateCustomerId.SubCustomerId

                        End With

                        MeetingCartItemId = oShopCartController.AddToCart(oCartInfo)
                        Exit For
                    End If
                Next


                For index2 As Integer = 0 To oProductList.Count - 1
                    oCartInfo = CType(oProductList(index2), ShoppingCartManager.Business.ShoppingCartInfo)
                    If oCartInfo.RelatedCartItemId > 0 Then


                        With oCartInfo
                            .MasterCustomerId = UserInfo.Profile.GetPropertyValue("MasterCustomerId").ToString
                            .SubCustomerId = Integer.Parse(UserInfo.Profile.GetPropertyValue("SubCustomerId"))
                            .ShipCustomerLabelName = arrGroupActionInfo(index1).AffiliateLabelName
                            .ShipMasterCustomerId = arrGroupActionInfo(index1).AffiliateCustomerId.MasterCustomerId
                            .ShipSubCustomerId = arrGroupActionInfo(index1).AffiliateCustomerId.SubCustomerId

                            'AM FIX - Affiliate Mgmt ticket 3246-8290097 
                            'in case of meeting product, the Related Cart Item Id should be correctly updated
                            If .RelatedCartItemId > 0 Then
                                .RelatedCartItemId = MeetingCartItemId
                            End If
                        End With

                        CartItemId = oShopCartController.AddToCart(oCartInfo)
                    End If
                Next
            Next
            'Once all the items have been added to the cart for all the members , delete the item from the shopping cart table
            oShopCartController.DeleteCart(Guid, 0, PortalId)

            oShopCartController = Nothing

        End Sub
#End Region


#Region "Group Action Build List"
        Private Function BuildGroupActionCommitteeSegmentAffiliateList() As GroupActionListInfo()
            Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegCommitteeMembersInfoViewList

            oMembers = get_clsAffiliateManagement.GetCommitteeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "COMMITTEE", qualifier1, qualifier2, customerIDs)

            If EventTarget.IndexOf("btnAddress") >= 0 Then
                SortCriteria = "City"
                sort = True
            End If
            If EventTarget.IndexOf("btnName") >= 0 Then
                SortCriteria = "LabelName"
                sort = True
            End If

            If EventTarget.IndexOf("btnPhone") >= 0 Then
                SortCriteria = "PrimaryPhone"
                sort = True
            End If

            If EventTarget.IndexOf("btnEmail") >= 0 Then
                SortCriteria = "PrimaryEmailAddress"
                sort = True
            End If

            If sort AndAlso SortDirection = "asc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                SortDirection = "desc"
            ElseIf sort AndAlso SortDirection = "desc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                SortDirection = "asc"
            End If
            Dim group(oMembers.Count) As GroupActionListInfo
            tMembers = New Hashtable
            For i = 0 To oMembers.Count - 1

                If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                    tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)
                    group(i) = New GroupActionListInfo
                    'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                    'group(i).Address = oMembers(i).City & ", " & oMembers(i).State
                    'Else
                    group(i).Address = oMembers(i).FormattedAddress
                    'End If
                    group(i).Name = oMembers(i).LabelName
                    group(i).Phone = oMembers(i).PrimaryPhone
                    group(i).Email = oMembers(i).PrimaryEmailAddress

                End If


            Next

            Return group
        End Function

        Private Function BuildGroupActionEmployeeSegmentAffiliateList() As GroupActionListInfo()
            Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegEmploymentEmployeesInfoViewList

            oMembers = get_clsAffiliateManagement.GetEmployeeSegmentAffiliateList(PortalId, qualifier1, CInt(qualifier2), "EMPLOYEE", qualifier1, qualifier2, customerIDs)

            If EventTarget.IndexOf("btnAddress") >= 0 Then
                SortCriteria = "City"
                sort = True
            End If
            If EventTarget.IndexOf("btnName") >= 0 Then
                SortCriteria = "LabelName"
                sort = True
            End If

            If EventTarget.IndexOf("btnPhone") >= 0 Then
                SortCriteria = "PrimaryPhone"
                sort = True
            End If
            If EventTarget.IndexOf("btnEmail") >= 0 Then
                SortCriteria = "PrimaryEmailAddress"
                sort = True
            End If

            If sort AndAlso SortDirection = "asc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                SortDirection = "desc"
            ElseIf sort AndAlso SortDirection = "desc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                SortDirection = "asc"
            End If
            Dim group(oMembers.Count) As GroupActionListInfo
            tMembers = New Hashtable
            For i = 0 To oMembers.Count - 1
                If Not tMembers.ContainsKey(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId) Then
                    tMembers.Add(oMembers(i).MasterCustomerId & "-" & oMembers(i).SubCustomerId, 0)

                    group(i) = New GroupActionListInfo
                    'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                    'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                    'Else
                    group(i).Address = oMembers(i).FormattedAddress
                    'End If
                    group(i).Name = oMembers(i).LabelName
                    group(i).Phone = oMembers(i).PrimaryPhone
                    group(i).Email = oMembers(i).PrimaryEmailAddress
                End If
            Next

            Return group
        End Function

        Private Function BuildGroupActionGeographySegmentAffiliateList() As GroupActionListInfo()
            Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

            oMembers = get_clsAffiliateManagement.GetGeographySegmentAffiliateList(PortalId, qualifier1, qualifier2, "GEOGRAPHIC", qualifier1, qualifier2, customerIDs)

            If EventTarget.IndexOf("btnAddress") >= 0 Then
                SortCriteria = "City"
                sort = True
            End If
            If EventTarget.IndexOf("btnName") >= 0 Then
                SortCriteria = "LabelName"
                sort = True
            End If

            If EventTarget.IndexOf("btnPhone") >= 0 Then
                SortCriteria = "PrimaryPhone"
                sort = True
            End If

            If EventTarget.IndexOf("btnEmail") >= 0 Then
                SortCriteria = "PrimaryEmailAddress"
                sort = True
            End If

            If sort AndAlso SortDirection = "asc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                SortDirection = "desc"
            ElseIf sort AndAlso SortDirection = "desc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                SortDirection = "asc"
            End If
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Location = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function

        Private Function BuildGroupActionMembershipProductSegmentAffiliateList() As GroupActionListInfo()
            Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductMembershipInfoViewList

            Dim strSegmentRule As String = "PRODUCT"
            Dim strSegmentQualifier1 As String = qualifier1
            Dim strSegmentQualifier2 As String = qualifier2

            oMembers = get_clsAffiliateManagement.GetMembershipProductSegmentAffiliateList(PortalId, qualifier1, qualifier2, "PRODUCT", qualifier1, qualifier2, customerIDs)

            If EventTarget.IndexOf("btnAddress") >= 0 Then
                SortCriteria = "City"
                sort = True
            End If
            If EventTarget.IndexOf("btnName") >= 0 Then
                SortCriteria = "LabelName"
                sort = True
            End If

            If EventTarget.IndexOf("btnPhone") >= 0 Then
                SortCriteria = "PrimaryPhone"
                sort = True
            End If

            If EventTarget.IndexOf("btnEmail") >= 0 Then
                SortCriteria = "PrimaryEmailAddress"
                sort = True
            End If

            If sort AndAlso SortDirection = "asc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                SortDirection = "desc"
            ElseIf sort AndAlso SortDirection = "desc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                SortDirection = "asc"
            End If
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Address = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).City
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function

        Private Function BuildGroupActionMiscellaneousSegmentAffiliateList() As GroupActionListInfo()
            Dim arrGroupActionInfo() As AffiliateManagementSessionHelper.GroupActionAffiliateInfo = AffiliateManagementSessionHelper.GetAffiliateGroupActionInfo(PortalId)
            Dim customerIDs As String = String.Empty

            Dim i As Integer
            For i = 0 To arrGroupActionInfo.Length - 1
                If (i = arrGroupActionInfo.Length - 1) Then
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'"
                Else
                    customerIDs = customerIDs & "'" & arrGroupActionInfo(i).CustomerIdKey & "'" & ","
                End If
            Next

            Dim oMembers As TIMSS.API.WebInfo.IWebSegProductOthersInfoViewList

            Dim strSegmentRule As String = "MISCELLANEOUS"
            Dim strSegmentQualifier1 As String = qualifier1
            Dim strSegmentQualifier2 As String = qualifier2

            oMembers = get_clsAffiliateManagement.GetMiscellaneousSegmentAffiliateList(PortalId, qualifier1, qualifier2, "MISCELLANEOUS", qualifier1, qualifier2, customerIDs)

            If EventTarget.IndexOf("btnName") >= 0 Then
                SortCriteria = "LabelName"
                sort = True
            End If
            If EventTarget.IndexOf("btnProduct") >= 0 Then
                SortCriteria = "ShortName"
                sort = True
            End If

            If EventTarget.IndexOf("btnPurchaseDate") >= 0 Then
                SortCriteria = "OrderDate"
                sort = True
            End If

            If sort AndAlso SortDirection = "asc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Ascending)
                SortDirection = "desc"
            ElseIf sort AndAlso SortDirection = "desc" Then
                oMembers.Sort(SortCriteria, ComponentModel.ListSortDirection.Descending)
                SortDirection = "asc"
            End If
            Dim group(oMembers.Count) As GroupActionListInfo
            For i = 0 To oMembers.Count - 1
                group(i) = New GroupActionListInfo
                'If oMembers(i).State IsNot Nothing AndAlso oMembers(i).State <> String.Empty Then
                'group(i).Address = oMembers(i).City & ", " & oMembers(i).State
                'Else
                group(i).Address = oMembers(i).FormattedAddress
                'End If
                group(i).Name = oMembers(i).LabelName
                group(i).Phone = oMembers(i).PrimaryPhone
                group(i).Email = oMembers(i).PrimaryEmailAddress
            Next

            Return group
        End Function
#End Region

#Region "EmployeeListInfo"
        ' This class will be used to store information about each employees of the Employer selected
        Public Class EmployeeListInfo
            Public Name As String
            Public Phone As String
            Public Email As String
            Public EmploymentDate As String
            Public EmploymentType As String
            Public Supervisor As String
            Public FullTime As String
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
            Public CustomerRelationshipId As Long
            Public CheckBoxHidden As Boolean
        End Class
#End Region

#Region "MemberListInfo"
        ' This class will be used to store information about each members of the committee selected
        Public Class MemberListInfo
            Public Name As String
            Public Phone As String
            Public Email As String
            Public Position As String
            Public TermEndDate As String
            Public VotingStatus As String
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
            Public CommitteeMemberId As Long
            Public CheckBoxHidden As Boolean
        End Class

#End Region

#Region "MembershipListInfo"
        ' This class will be used to store information about each membership of the segment selected
        Public Class MembershipListInfo
            Public Name As String
            Public Membership As String
            Public MemberSince As String
            Public ExpirationDate As String
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
        End Class

#End Region

#Region "GeographicListInfo"
        ' This class will be used to store information about each record of the segment selected - Geographic
        Public Class GeographicListInfo
            Public Name As String
            Public City As String
            Public State As String
            Public Country As String
            Public Phone As String
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
        End Class

#End Region

#Region "MiscellaneousListInfo"
        ' This class will be used to store information about each record of the segment selected - Miscellaneous
        Public Class MiscellaneousListInfo
            Public Name As String
            Public Product As String
            Public PurchaseDate As String
            Public MasterCustomerId As String
            Public SubCustomerId As Integer
        End Class

#End Region

#Region "GroupActionListInfo"
        ' This class will be used to store information about each GroupAction member
        Public Class GroupActionListInfo
            Public Name As String
            Public Address As String
            Public Phone As String
            Public Email As String
        End Class
#End Region

#Region "Button  Continue Group Action"
        ' This class will be used to store information about Continue Button in Group Action
        Public Class ButtonConfirmActionInfo
            Public Text As String
            Public NavigateURL As String
        End Class
#End Region

#Region "Button Cancel Group Action"
        ' This class will be used to store information about Cancel Button in Group Action
        Public Class ButtonCancelInfo
            Public Text As String
            Public NavigateURL As String
        End Class
#End Region

#Region "Button BuyAnotherProductForTheSameGroup"
        Public Class ButtonBuyAnotherProductForTheSameGroupInfo
            Public Text As String
            Public NavigateURL As String
            Public Explanation As String
        End Class
#End Region

#Region "Button BuyAnotherProductForDifferentGroup"
        Public Class ButtonBuyAnotherProductForDifferentGroupInfo
            Public Text As String
            Public NavigateURL As String
            Public Explanation As String
        End Class
#End Region

#Region "Button Checkout"
        Public Class ButtonCheckoutInfo
            Public Text As String
            Public NavigateURL As String
            Public Explanation As String
        End Class
#End Region

#Region "Images functions"
        '3246-5774803
        Private Function GetArrowImageURL() As String

            Return ResolveUrl("~/" & SiteImagesFolder & "/arrow_right_blue.gif")
        End Function
        'END 3246-5774803
#End Region

        'GetClassAffiliateManagement
#Region "Personify Data"
        'Private Function get_clsAffiliateManagement() As ApplicationManager.AffiliateManagement

        '    Dim _clsAM As AffiliateManagement

        '    _clsAM = GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifyAffiliateManagementClassStructure, OrganizationId + OrganizationUnitId)

        '    If _clsAM Is Nothing Then
        '        _clsAM = New AffiliateManagement(OrganizationId, OrganizationUnitId)
        '        AddSessionObject(PersonifyEnumerations.SessionKeys.PersonifyAffiliateManagementClassStructure, _clsAM, OrganizationId + OrganizationUnitId)
        '    End If


        '    Return _clsAM
        'End Function

        Private Function SaveCommitteeMember(ByVal Mode As PersonifyEnumerations.TransactionMode, _
               ByVal CommitteeMasterCustomer As String, _
               ByVal CommitteeSubCustomer As Integer, ByVal MemberMasterCustomer As String, ByVal MemberSubCustomer As Integer, _
               ByVal MemberAddressId As Long, ByVal MemberAddressTypeCode As TIMSS.API.Core.ICode, _
               ByVal PositionCode As String, _
               ByVal VotingStatusCode As String, ByVal BeginDate As Date, ByVal EndDate As Date, _
               ByVal Comments As String, ByVal ParticipationStatusCode As String, ByVal CommitteeMemberId As Integer, _
         Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection



            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False





            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveCommitteeMemberGUIDKeys) Is Nothing Then
                    ClearSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveCommitteeMemberGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveCommitteeMemberGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "CommitteeMember"
                End With

            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveCommitteeMemberGUIDKeys), BusinessObjectGUIDStorage())
            End If

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            oCustomers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CommitteeMasterCustomer)
            oCustomers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, CommitteeSubCustomer)
            oCustomers.Fill()
            Dim oCommitteeMembers As TIMSS.API.CommitteeInfo.ICommitteeMembers = oCustomers(0).CommitteeMembers
            Dim oCommitteeMember As TIMSS.API.CommitteeInfo.ICommitteeMember


            If Mode = PersonifyEnumerations.TransactionMode.ADD Then
                oCommitteeMember = oCommitteeMembers.CreateNew()
                oCommitteeMembers.Add(oCommitteeMember)
                With oCommitteeMember
                    .CommitteeMasterCustomer = CommitteeMasterCustomer
                    .CommitteeSubCustomer = CommitteeSubCustomer
                    .MemberMasterCustomer = MemberMasterCustomer
                    .MemberSubCustomer = MemberSubCustomer
                    .PositionCode = .PositionCode.List(PositionCode).ToCodeObject
                    .VotingStatusCode = .VotingStatusCode.List(VotingStatusCode).ToCodeObject
                    .BeginDate = BeginDate
                    .EndDate = EndDate
                    .Comments = Comments
                    .ParticipationStatusCode = .ParticipationStatusCode.List(ParticipationStatusCode).ToCodeObject
                    .MemberAddressId = MemberAddressId
                    .MemberAddressTypeCode = MemberAddressTypeCode
                End With



            ElseIf Mode = PersonifyEnumerations.TransactionMode.EDIT Then

                Dim i As Integer
                For i = 0 To oCustomers(0).CommitteeMembers.Count - 1
                    With oCustomers(0).CommitteeMembers(i)
                        If CStr(.CommitteeMemberId) = CommitteeMemberId Then
                            .VotingStatusCode = .VotingStatusCode.List(VotingStatusCode).ToCodeObject
                            .BeginDate = BeginDate
                            .EndDate = EndDate
                            .Comments = Comments
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).CommitteeMembers(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).CommitteeMembers(i).Guid
                End If
            ElseIf Mode = PersonifyEnumerations.TransactionMode.DELETE Then
                Dim i As Integer
                For i = 0 To oCustomers(0).CommitteeMembers.Count - 1
                    With oCustomers(0).CommitteeMembers(i)
                        If CStr(.CommitteeMemberId) = CommitteeMemberId Then
                            'Remove Member
                            .EndDate = CDate(Format(Date.Now, "MM/dd/yyyy"))
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).CommitteeMembers(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).CommitteeMembers(i).Guid
                End If
            End If

            AddSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveCommitteeMemberGUIDKeys, oclsGUID)


            oCustomers.Save()

            If oCustomers.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)

                oCustomers.Save()
            End If

            ' Clear the cached communication methods if no validation issues exist
            If oCustomers.ValidationIssues.ErrorCount = 0 Then
                
                'Remove the guids
                ClearSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveCommitteeMemberGUIDKeys)
            End If
            Return oCustomers.ValidationIssues


        End Function

       
        Private Function SaveEmployeeRelationship(ByVal Mode As Personify.ApplicationManager.PersonifyEnumerations.TransactionMode, _
                    ByVal EmployerMasterCustomer As String, _
                    ByVal EmployerSubCustomer As Integer, ByVal RelatedMasterCustomer As String, ByVal RelatedSubCustomer As Integer, ByVal RelatedName As String, _
                    ByVal RelationshipType As String, ByVal RelationshipCode As String, ByVal ReciprocalCode As String, _
                    ByVal BeginDate As Date, ByVal SupervisorName As String, ByVal FullTimeFlag As Boolean, ByVal PrimaryEmployerFlag As Boolean, ByVal CustomerRelationshipId As Integer, _
              Optional ByVal RespondedValidationIssues As TIMSS.API.Core.Validation.IssuesCollection = Nothing) As TIMSS.API.Core.Validation.IIssuesCollection



            Dim oclsGUID(0) As BusinessObjectGUIDStorage
            Dim bGUIDExists As Boolean = False





            If RespondedValidationIssues Is Nothing Then
                If Not GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys) Is Nothing Then
                    ClearSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys)
                Else

                End If
            End If
            If GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys) Is Nothing Then
                bGUIDExists = False
                'initialize the GUID class
                oclsGUID(0) = New BusinessObjectGUIDStorage
                With oclsGUID(0)
                    .BusinessObjectName = "EmployeeRelationship"
                End With

            Else
                bGUIDExists = True
                'Fethc
                oclsGUID = CType(GetSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys), BusinessObjectGUIDStorage())
            End If

            Dim oCustomers As TIMSS.API.CustomerInfo.ICustomers

            oCustomers = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.CustomerInfo, "Customers")
            'oCustomers.Filter.Add("MasterCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, EmployerMasterCustomer)
            'oCustomers.Filter.Add("SubCustomerId", TIMSS.Enumerations.QueryOperatorEnum.Equals, EmployerSubCustomer)
            oCustomers.Fill(EmployerMasterCustomer, EmployerSubCustomer)
            Dim oRelationships As TIMSS.API.CustomerInfo.ICustomerRelationships = oCustomers(0).Relationships

            If Mode = PersonifyEnumerations.TransactionMode.ADD Then
                With oRelationships.AddNew()
                    .MasterCustomerId = EmployerMasterCustomer
                    .SubCustomerId = CInt(EmployerSubCustomer)
                    .RelatedName = RelatedName
                    .RelationshipType = .RelationshipType.List(RelationshipType).ToCodeObject
                    .RelationshipCode = .RelationshipCode.List(RelationshipCode).ToCodeObject
                    .ReciprocalCode = .ReciprocalCode.List(ReciprocalCode).ToCodeObject

                    .RelatedMasterCustomerId = RelatedMasterCustomer
                    .RelatedSubCustomerId = RelatedSubCustomer

                    .BeginDate = CDate(BeginDate)
                    .SupervisorName = SupervisorName
                    .FullTimeFlag = FullTimeFlag
                    .PrimaryEmployerFlag = PrimaryEmployerFlag

                End With

            ElseIf Mode = PersonifyEnumerations.TransactionMode.EDIT Then

                Dim i As Integer
                For i = 0 To oRelationships.Count - 1
                    With oRelationships(i)
                        If CStr(.ReciprocalId) = CustomerRelationshipId Then
                            .ReciprocalCode = .ReciprocalCode.List(ReciprocalCode).ToCodeObject
                            .BeginDate = BeginDate
                            .SupervisorName = SupervisorName
                            .FullTimeFlag = FullTimeFlag
                            .PrimaryEmployerFlag = PrimaryEmployerFlag
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).Relationships(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).Relationships(i).Guid
                End If

            ElseIf Mode = PersonifyEnumerations.TransactionMode.DELETE Then

                Dim i As Integer
                For i = 0 To oRelationships.Count - 1
                    With oRelationships(i)
                        If CStr(.ReciprocalId) = CustomerRelationshipId Then 'CustomerRelationshipId
                            .EndDate = CDate(Format(Date.Now, "MM/dd/yyyy"))
                            Exit For
                        End If
                    End With

                Next

                If bGUIDExists Then
                    oCustomers(0).Relationships(i).Guid = oclsGUID(0).GUID
                Else
                    oclsGUID(0).GUID = oCustomers(0).Relationships(i).Guid
                End If
            End If

            AddSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys, oclsGUID)


            oCustomers.Save()

            If oCustomers.ValidationIssues.ErrorCount > 0 AndAlso (Not RespondedValidationIssues Is Nothing) Then

                RespondToValidationIssues(oCustomers.ValidationIssues, RespondedValidationIssues)

                oCustomers.Save()
            End If

            ' Clear the cached communication methods if no validation issues exist
            If oCustomers.ValidationIssues.ErrorCount = 0 Then
              
                ClearSessionObject(PersonifyEnumerations.SessionKeys.PersonifySaveEmployeeRelationshipGUIDKeys)
            End If
            Return oCustomers.ValidationIssues



        End Function

#End Region
    End Class

End Namespace

