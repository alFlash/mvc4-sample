Option Strict Off
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports Personify.DNN.Modules.MyTranscripts.Business

Namespace Personify.DNN.Modules.MyTranscripts

    Public MustInherit Class MyTranscripts
       Inherits Personify.ApplicationManager.PersonifyDNNBaseForm

#Region "Controls"
		Protected MyTranscriptsXslTemplate As Personify.WebControls.XslTemplate
		Protected lblNothing As Label

		Const C_TEMPLATES As String = "Templates"
		Const C_DISPLAY_NUMBER As String = "DisplayNumber"
		Const C_DETAILS_ACTION As String = "DetailsActionURL"
		Const C_EDIT_ACTION As String = "EditActionURL"
		Const C_VIEWALL_ACTION As String = "ViewAllActionURL"
		Const C_ADDTRANSCRIPT_ACTION As String = "AddTranscript"
		Const C_SHOWADDTRANSCRIPT_ACTION As String = "ShowAddTranscript"
		Const C_SHOWDETAILS_ACTION As String = "ShowDetails"

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
                Dim role As String
                role = Me.GetUserRole(UserInfo)
                If role = "personifyuser" Or role = "personifyadmin" Then
                    If Not Settings(C_TEMPLATES) Is Nothing Then


                        Dim IsManagingAffiliate As Boolean = False

                        Try
                            IsManagingAffiliate = Personify.ApplicationManager.AffiliateManagementSessionHelper.IsManagingAffiliate(PortalId)
                        Catch ex As Exception

                        End Try




                        Dim Transcripts As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscripts
                        Transcripts = df_GetTranscripts(MasterCustomerId, SubCustomerId)




                        Dim DisplayNumber As Integer = 0
                        If Not Settings(C_DISPLAY_NUMBER) Is Nothing Then
                            DisplayNumber = CType(Settings(C_DISPLAY_NUMBER), Integer)
                        End If

                        Dim templatefile As String = ""
                        'templatefile = ModulePath + "Templates\MyTranscripts.xsl"
                        templatefile = ModulePath + "Templates\" + Settings(C_TEMPLATES).ToString

                        MyTranscriptsXslTemplate.XSLfile = Server.MapPath(templatefile)
                        MyTranscriptsXslTemplate.AddObject("ModuleId", ModuleId)
                        If Transcripts IsNot Nothing AndAlso Transcripts.Count > 0 Then

                            MyTranscriptsXslTemplate.AddObject("", Transcripts)

                        End If

                        MyTranscriptsXslTemplate.AddObject("DisplayNumber", DisplayNumber)

                        MyTranscriptsXslTemplate.Display()


                        Dim HyperLinkShowAll As HyperLink
                        HyperLinkShowAll = CType(Me.FindControl("HyperLinkShowAll" + ModuleId.ToString), HyperLink)
                        If HyperLinkShowAll IsNot Nothing Then
                            HyperLinkShowAll.NavigateUrl = NavigateURL(CType(Settings(C_VIEWALL_ACTION), Integer))
                        End If

                        Dim HyperLinkAddTranscript As HyperLink
                        HyperLinkAddTranscript = CType(Me.FindControl("HyperLinkAddTranscript" + ModuleId.ToString), HyperLink)
                        If HyperLinkAddTranscript IsNot Nothing Then
                            HyperLinkAddTranscript.NavigateUrl = NavigateURL(CType(Settings(C_ADDTRANSCRIPT_ACTION), Integer))

                            Dim ShowAddTranscript As Boolean = False
                            If Not Settings(C_SHOWADDTRANSCRIPT_ACTION) Is Nothing Then
                                ShowAddTranscript = CType(Settings(C_SHOWADDTRANSCRIPT_ACTION), Boolean)
                            End If
                            HyperLinkAddTranscript.Visible = ShowAddTranscript

                        End If

                        Dim HyperLinkDetails As HyperLink
                        HyperLinkDetails = CType(Me.FindControl("HyperLinkDetails" + ModuleId.ToString), HyperLink)
                        If HyperLinkDetails IsNot Nothing Then
                            HyperLinkDetails.NavigateUrl = NavigateURL(CType(Settings(C_DETAILS_ACTION), Integer))

                            Dim ShowDetails As Boolean = False
                            If Not Settings(C_SHOWDETAILS_ACTION) Is Nothing Then
                                ShowDetails = CType(Settings(C_SHOWDETAILS_ACTION), Boolean)
                            End If
                            HyperLinkDetails.Visible = ShowDetails

                        End If
                        'Const C_EDIT_ACTION As String = "EditActionURL"
                        If Transcripts IsNot Nothing AndAlso Transcripts.Count > 0 Then
                            For i As Integer = 0 To Transcripts.Count - 1
                                Dim hypTranscript As HyperLink
                                hypTranscript = CType(Me.FindControl("hypTranscript" + ModuleId.ToString + "_" + Transcripts(i).TranscriptCustomerTranscriptId.ToString), HyperLink)
                                If hypTranscript IsNot Nothing Then
                                    Dim aNavigateURL As String = NavigateURL(CType(Settings(C_EDIT_ACTION), Integer))
                                    If aNavigateURL.IndexOf("?") > 0 Then
                                        aNavigateURL += "&"
                                    Else
                                        aNavigateURL += "?"
                                    End If
                                    hypTranscript.NavigateUrl = aNavigateURL + "TID=" + Transcripts(i).TranscriptCustomerTranscriptId.ToString
                                End If
                            Next


                        Else
                            lblNothing.Visible = True
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "", ApplicationManager.LocalizedText.GetLocalizedText("PersonifyMissingSettings.Text", LocalResourceFile), ResolveUrl("~/" & SiteImagesFolder & "/administrator_info_48.gif"))
                    End If

                Else
                   DisplayUserAccessMessage(role)
                End If

				
			Catch exc As Exception
				ProcessModuleLoadException(Me, exc)
			End Try
        End Sub
       
      

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Function df_GetTranscripts(ByVal MasterCustomerID As String, ByVal SubCustomerID As Integer) As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscripts

            Dim oTranscripts As TIMSS.API.TranscriptInfo.ITranscriptCustomerTranscripts

            oTranscripts = Me.PersonifyGetCollection(TIMSS.Enumerations.NamespaceEnum.TranscriptInfo, "TranscriptCustomerTranscripts")

            oTranscripts.Filter.Add("MasterCustomerID", MasterCustomerID)
            oTranscripts.Filter.Add("SubCustomerID", SubCustomerID)

            oTranscripts.Fill()
            Return oTranscripts

        End Function

    End Class

End Namespace
